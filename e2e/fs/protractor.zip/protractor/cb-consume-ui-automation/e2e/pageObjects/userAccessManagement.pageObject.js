/**********************
 * Author : Mahendra
 **********************/

"use strict";

var extend = require('extend');
var url = browser.params.url;
var EC = protractor.ExpectedConditions;
var util = require('../../helpers/util.js');
var logGenerator = require("../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger();
var userPage = new userAccessManagement();

var defaultConfig = {
    pageUrl: url + '/admin',
    addNewTeamCss: 'button.bx--btn.bx--btn--primary.bx--btn--sm',
    addNewOrganizationXpath: '//button[contains(text(),"Organization")]',
    teamIdCss: '#teamcode input',
    teamNameCss: '#name input',
    organizationId: 'bx--list-box__menu bx--multi-select',
    organisnIdCss: '#ibm-label-0',
    organisnNameCss: '#ibm-label-1',
    organisnDescriptionCss: '#ibm-label-2',
    btnDeleteOrganiznXpath: '//button[contains(text(),"Delete")]',
    createXpath: '//button[text()=" Create "]',
    btnCreateOrgnsCss: '#orgCreateFormButton',
    rolesCss: 'button#roles',
    actionBtnCss: 'div.uam-data-table-overflow-menu svg',
    roleNameId: '[id*="dropdown"]',
    bsnEntityXpath: '//ul[contains(@id,"bx--dropdown-single-parent_teamOrg")]',
    bsnsEntityValueXpath: '//*[@id = "bx--dropdown-multi-parent_team"]',
    bsnsEntityOrgValueXpath: '//*[@id = "bx--search__wrapper_org"]',
    chkboxOrganization: '//input[@id="checkbox-teamorg-checkbox"]',
    chkboxEnv: '//input[@id="checkbox-0-context-checkbox"]',
    chkboxApp: '//input[@id="checkbox-1-context-checkbox"]',
    envId: 'bx--dropdown-multi-parent_env',
    appId: 'bx--dropdown-multi-parent_app',
    addCss: '#editViewUser',
    buttonOkUnassignXpath: "//button[text()='Ok']",
    btnRemoveRoleCss: "#alert-modal-button-1",
    usersCss: 'button#users',
    assignNewUserCss: '#teamlist-user-assignuser',
    //assignSelectedUser: '#bx--dropdown-multi-parent_assignUsers',
    assignSelectedUser: '#add-users-combobox input',
    assignUserBtnXpath: "//button[contains(text(),' Assign')]",
    userCheckboxCss: 'div#users-table td.bx--table-column-checkbox',
    unassignButtonCss: ".bx--action-list button",
    closeXpath: '//button[@class="bx--link bx--slide-over-panel--close"]',
    searchTeamCss: 'input.bx--search-input',
    searchContexttypeCss: 'input#search-0',
    teamDetailsCss: '//table[@id="carbon-deluxe-data-table-0"]//tr[1]//td',
    contextValuesXpath: '//*[contains(text(), "Context Values")]',
    teamsXpath: '//a[contains(text(), "Teams")]',
    OrganizationXpath: '//a[contains(text(), "Organizations")]',
    clickOnActionIconContextCss: '.bx--table-overflow',
    clickAddContextValueCss: '#carbon-deluxe-data-table-0-parent-row-1-option-2-button',
    AddnewContextValueIdICAMNamespaceCss: '#ibm-label-4',
    AddnewContextValueNameICAMnamespaceCss: '#ibm-label-3',
    addNewContextValueCss: '.bx--btn.bx--btn--primary.bx--btn--sm',
    newContextTypeId: 'text-input-contexttagtype',
    newContextValueIdCss: '#ibm-label-0',
    newContextValueName: '#ibm-label-1',
    //createContextbtnCss: '#createCtxBtn',    
    createContextbtnCss: '#create-context-type-submit-btn',
    createContextbtnCssICAM: '#createCtxBtn',
    userAddedSucsMsg: '.bx--inline-notification__subtitle',
    tblContextValueIdXpath: '//*[@class="bx--table-body"]/tr/td[2]',
    tblContextValueNameXpath: '//*[@class="bx--table-body"]/tr/td[3]',
    budgetaryPaginationDrpDwnCss: '#bx--pagination-select-id-1',
    roleListXpath: '//div[@id="team-roles-table"]//tr//td[1]',
    tblteamNameCss: '.team-table tbody tr:nth-child(1)  td:nth-child(1) span',
    tblteamIdCss: '.team-table tbody tr:nth-child(1)  td:nth-child(2) span',
    OrgNameCss: 'tr:nth-child(1) td:nth-child(4)',
    OrgIdCss: 'tr:nth-child(1) td:nth-child(3)',
    searchUserInTeamCss: "#text-input-users",
    btnActionCss: '[class$="overflow-menu"]',
    btnDeleteXpath: '//*[contains(text(),"Delete")]',
    btnCnfrmDeleteCss: '#button-org-delete',
    txtSucsMsgCss: '.bx--toast-notification__details',
    //txtEditTeamNameCss : '#text-input-teamlist-teamname-property',
    //strTeamUpdatedMsgCss : '#teamlist-roles-TeamEditSuccessNotification',    
    teamsTabCss: '.bx--tabs__nav-link',
    teamLnkXpath: '//a[contains(text(),"Teams")]',
    editBtnXpath: '//button[contains(text(),"Edit")]',
    txtEditTeamNameCss: '#name input',
    viewDetailsCss: '[class$="bx--overflow-menu-options__option-content"]',
    btnUpdateTeamXpath: '//button[contains(text(),"Update")]',
    addRoleXpath: '//button[contains(text(),"Add Role")]',
    //strTeamUpdatedMsgCss : 'div.bx--inine-notification__details',
    strTeamUpdatedMsgCss: '.bx--inline-notification__subtitle span',
    popupBtnUnassignUserCss: '#alert-modal-button-1',
    btnDeleteTeamContextOrganizCss: 'div.bx--overflow-menu-options__option-content',
    btnDeleteInConfrmnPopUpCss: '#alert-modal-button-1',
    btnCommnDeleteCss: 'button[id="alert-modal-button-1"]',
    rolesMenuIconCss: '.users-table .bx--overflow-menu__icon',
    rolesViewDetailIconCss: '.bx--overflow-menu-options__btn',
    btnSaveProviderAcntDetailsXpath: '//button[contains(text(),"Save")]',
    btnAsignUsrDropdownXpath: '//div[@id="add-users-combobox"]',
    envChkbxXpath: '//input[@id="checkbox-envAssociate"]/../label',
    appChkbxXpath: '//input[@id="checkbox-appAssociate"]/../label',
    appChkbxXpath: '//input[@id="checkbox-appAssociate"]/../label',
    expandIconXpath: "//button[@class='bx--table-expand__button']",
    threeDotIconXpath: "/ancestor::td/following-sibling::td[last()]//*[@class='bx--overflow-menu__icon']",
    deleteNamespaceButtonXpath: "//*/button/div[contains(text(),'Delete')]",
    deleteOkButtonXpath: "(//button[contains(text(),'Delete') and @id='button-context_tab-modal_carbon-button_ok'])[2]",
    forwardButtonXpath: "//button[@id='bx--pagination__forward-button-4']",
    searchMagnifierCss :".bx--search-magnifier",
    dropdownRoleSelectionValuesXpath: "//*[@class='bx--list-box__menu bx--multi-select']//li",
    OnThirthyPageValueXpath:'//*[@id="pagination-select-items-per-page-1"]//option[4]',
    addContextValueXpath:"//div[contains(text(),' Add context value ')]",
    paginationClickDropdownCss:"#pagination-select-items-per-page-1",
    deleteTeamConfrMsgCss:".bx--modal-content p",
    cancelDeletionBtnCss:"#alert-modal-button-0"
};

function userAccessManagement(selectorConfig) {
    if (!(this instanceof userAccessManagement)) {
        return new userAccessManagement(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

userAccessManagement.prototype.open = function () {
    browser.get(defaultConfig.pageUrl);
    browser.wait(EC.elementToBeClickable(element(by.css(this.teamsTabCss)), 120000)).then(function () {
        logger.info("Navigated to User Access Management page...");
        util.waitForAngular();
    });

};

userAccessManagement.prototype.openContextTypes = function () {
    browser.get(this.pageUrl + "/contexttypes");
    util.waitForAngular();
};


userAccessManagement.prototype.clickAddNewTeam = function () {
    util.waitForAngular();
    var elemToClick = element(by.css(this.addNewTeamCss));
    return browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on Add New team button.");
            util.waitForAngular();
        });

    });
};

userAccessManagement.prototype.setNewTeamDetails = function (teamDetails) {
    //Adding hardcore sleep as dropdown is not populating with values
    browser.sleep(5000);
    var elem = element(by.css(this.teamIdCss));
    var elmId = this.organizationId;
    browser.wait(EC.elementToBeClickable(elem), 60000);
//     elem.sendKeys(teamDetails["Team Id"]).then(function () {
//         logger.info("Team Id is enetred ");
//     });
    
    elem.clear().then(function () {        
        var ctrlA = protractor.Key.chord(protractor.Key.CONTROL, "a");
        elem.sendKeys(ctrlA);
        return elem.sendKeys(teamDetails["Team Id"]);
    });
    
    element(by.css(this.teamNameCss)).sendKeys(teamDetails["Team Name"]).then(function () {
        logger.info("Team Name is enetred ");
    });
    browser.sleep(6000);
    var orgDrpdwn = element(by.css("div#dropdown-0 div"));
    browser.wait(EC.elementToBeClickable(orgDrpdwn), 90000);
    return orgDrpdwn.click().then(function () {
        util.waitForAngular();
        browser.sleep(4000);
        var organisnValues = element.all(by.xpath("//*[@class='" + elmId + "']//li")).getText();
        //var organisnValues = element.all(by.css(this.organizationCss)).getText();
        organisnValues.then(function (values) {
            if (values.indexOf(teamDetails["Organization"]) != -1) {
                organisnValues.get(values.indexOf(teamDetails["Organization"])).click().then(function () {
                    logger.info("Organization is selected ");
                });
            } else {
                logger.info("Organization is not available");
            }
            util.waitForAngular();
        });
    });

};

userAccessManagement.prototype.clickUpdate = function () {
    var elemToClick = element(by.xpath(this.createXpath));
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    return elemToClick.click().then(function () {
        logger.info("Clicked on Create Team button");
        util.waitForAngular();
        browser.sleep(7000);
    });
};

userAccessManagement.prototype.clickRolesTab = function () {
    var elemToClick = element(by.css(this.rolesCss));
    return browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on Roles button");
            util.waitForAngular();
        });
    });
};

userAccessManagement.prototype.clickAddRole = function () {
    var elemToClick = element(by.xpath(this.addRoleXpath));
    return browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on Add Role button");
            util.waitForAngular();
        });
    });
};

userAccessManagement.prototype.selectRoleName = function (roleName) {

    var elemToClick = element(by.css(this.roleNameId));
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    return elemToClick.click().then(function () {
        var dropdownValues = element.all(by.xpath(defaultConfig.dropdownRoleSelectionValuesXpath));
        browser.wait(EC.elementToBeClickable(dropdownValues.first()), 30000).then(function(){
            logger.info("Role Selection dropdown opening");
        }).catch(function(err){
            logger.info("Role Selection dropdown not opened");
            elemToClick.click().then(function(){
                logger.info("Clicked on Role selection dropdown")
            }).catch(function(err){
                browser.executeScript("arguments[0].click();", elemToClick.getWebElement());
            });
        });
        
        userPage.selectDropDownValue(defaultConfig.roleNameId, roleName).then(function () {
            logger.info("Role Selected : " + roleName);
            util.waitForAngular();
        });
    });
};

userAccessManagement.prototype.selectBsnEntity = function (entity) {
    var elemToClick = element(by.xpath(this.bsnEntityXpath));
    return elemToClick.isEnabled().then(function (status) {
        if (status == true) {
            browser.wait(EC.elementToBeClickable(elemToClick), 60000);
            return elemToClick.click().then(function () {
                var bsnsEntity = element.all(by.xpath(defaultConfig.bsnEntityXpath + "//carbon-dropdown-option//li"));
                bsnsEntity.getText().then(function (values) {
                    var index = values.indexOf(entity);
                    bsnsEntity.get(index).click().then(function () {
                        logger.info("Organization is selected : " + entity);
                        util.waitForAngular();
                    });
                });
            }).catch(function (err) {
                logger.info("Exception occured " + err.description);
            });
        }
    });
};

userAccessManagement.prototype.selectEnv = function (env) {
    var elemToClick = element(by.id(this.envId));
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    return elemToClick.click().then(function () {
        util.waitForAngular();
        browser.sleep(3000);
        browser.executeScript("arguments[0].scrollIntoView(true);", elemToClick);
        var dropDownValues = element.all(by.xpath("//*[contains(@id,'bx--dropdown-item')]/.."));
        var dropDownValuesChkBox = element.all(by.xpath("//input[contains(@id,'bx--dropdown-item-')]/../label"));
        dropDownValues.getText().then(function (values) {
            var index = values.indexOf(env);
            dropDownValuesChkBox.get(index).click().then(function () {
                logger.info("Environment is selected : " + env);
                util.waitForAngular();
                //Close the dropdown
                elemToClick.click().then(function () {
                    //Associate environment  
                    var elem = element(by.xpath(defaultConfig.envChkbxXpath));
                    elem.click().then(function () {
                        logger.info("Clicked on Environment checkbox");
                    });
                    //browser.executeScript("javascript:document.getElementById('checkbox-0-context-checkbox').click()");

                });
            });
        });

    });

};

userAccessManagement.prototype.selectApp = function (app) {
    var elemToClick = element(by.id(this.appId));
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    return elemToClick.click().then(function () {
        browser.executeScript("arguments[0].scrollIntoView(true);", elemToClick);
        var dropDownValues = element.all(by.xpath("//*[contains(@id,'bx--dropdown-item')]/.."));
        var dropDownValuesChkBox = element.all(by.xpath("//input[contains(@id,'bx--dropdown-item-')]/../label"));
        dropDownValues.getText().then(function (values) {
            var index = values.indexOf(app);
            dropDownValuesChkBox.get(index).click().then(function () {
                logger.info("Application is selected : " + app);
                util.waitForAngular();
                //Close the dropdown
                elemToClick.click().then(function () {
                    //Associate Application

                    var elem = element(by.xpath(defaultConfig.appChkbxXpath));
                    elem.click().then(function () {
                        logger.info("Clicked on Application checkbox");
                    });
                    //browser.executeScript("javascript:document.getElementById('checkbox-1-context-checkbox').click()");
                });
            });
        });

    });

};


userAccessManagement.prototype.selectBsnEntityValue = function (entityValue) {
    util.waitForAngular();
    var elemToClick;

    var elemToClickTeam = element(by.xpath(this.bsnsEntityValueXpath));
    var elemToClickOrg = element(by.xpath(this.bsnsEntityOrgValueXpath));
    //Check if element TEAM is present on page, otherwise switch to organization element
    return elemToClickTeam.isPresent().then(function (status) {
        if (status == true) {
            elemToClick = elemToClickTeam;
        } else {
            elemToClick = elemToClickOrg;
        }
        browser.wait(EC.elementToBeClickable(elemToClick), 60000);
        return elemToClick.click().then(function () {
            util.waitForAngular();
            browser.sleep(3000);
            browser.executeScript("arguments[0].scrollIntoView(true);", elemToClick);
            var dropDownValues = element.all(by.xpath("//*[contains(@id,'bx--dropdown-item')]/.."));
            var dropDownValuesChkBox = element.all(by.xpath("//input[contains(@id,'bx--dropdown-item-')]/../label"));
            dropDownValues.getText().then(function (values) {
                var index = values.indexOf(entityValue);
                //Add Code to uncheck ALL context
                dropDownValuesChkBox.get(0).isSelected().then(function (status) {
                    if (status == true) {
                        dropDownValuesChkBox.get(0).click().then(function () {
                            logger.info("ALL is unselected");
                        });
                    }

                });
                dropDownValuesChkBox.get(index).isSelected().then(function (status) {
                    if (status == false) {
                        browser.sleep(2000);
                        dropDownValuesChkBox.get(index).click().then(function () {
                            logger.info("Organization is selected : " + entityValue);
                            util.waitForAngular();
                        }).catch(function () {
                            browser.sleep(10000);
                            dropDownValuesChkBox.get(index).click();
                            util.waitForAngular();
                        });

                        elemToClick.click().then(function () {
                            //Associate Organization
                            element(by.id('checkbox-teamOrgAssociate')).isSelected().then(function (status) {
                                if (status == false) {
                                    browser.executeScript("javascript:document.getElementById('checkbox-teamOrgAssociate').click()");
                                }
                            });

                        });

                    }
                });
            });
        });
    });

};
userAccessManagement.prototype.clickSave = function () {
    var elemToClick = element(by.css(this.addCss));
    return browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on Add button in Add Role Window");
            util.waitForAngular();
        });
    });
};

userAccessManagement.prototype.clickOkUnassignPopup = function () {
    var elemToClick = element(by.css(this.btnRemoveRoleCss));
    browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on Remove roles button");
            util.waitForAngular();
            browser.wait(EC.invisibilityOf(elemToClick), 90000).then(function () {
                logger.info("Wait till Unassign Role popup disappears");
            })
        });
    });

};

userAccessManagement.prototype.clickUserTab = function () {
    util.waitForAngular();
    var elemToClick = element(by.css(this.usersCss));
    return browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on User tab");
            util.waitForAngular();
        });

    });
};

userAccessManagement.prototype.searchUserInTeamTextbox = function (assignedUser) {
    var elemToClick = element(by.css(this.searchUserInTeamCss));
    return browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.sendKeys(assignedUser).then(function () {
            logger.info("Search for the assigned user");
        });
        elemToClick.sendKeys(protractor.Key.ENTER).then(function () {
            logger.info("Hit Enter");
        })

    });
};

userAccessManagement.prototype.clickAssignUserLink = function () {
    var elemToClick = element(by.css(defaultConfig.assignNewUserCss));
    return browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on User link");
            util.waitForAngular();
        });

    });
};

userAccessManagement.prototype.clickAssignedUserCheckbox = function () {
    var elemToClick = element(by.css(defaultConfig.userCheckboxCss));
    browser.wait(EC.visibilityOf(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on User Checkbox");
            util.waitForAngular();
        });

    });
};


userAccessManagement.prototype.clickUnassignButton = function () {

    var elemToClick = element.all(by.css(defaultConfig.unassignButtonCss));
    browser.wait(EC.elementToBeClickable(elemToClick.get(1)), 60000);

    elemToClick.get(1).click().then(function () {
        logger.info("Clicked on Unassign User button");
        util.waitForAngular();
    });

    return element(by.css(defaultConfig.popupBtnUnassignUserCss)).click().then(function () {
        logger.info("Clicked on Confirm Unassign user");
        util.waitForAngular();
    });


};

userAccessManagement.prototype.selctUserToBeAssigned = function (user) {

    var searchInputBox = element.all(by.css(defaultConfig.assignSelectedUser)).get(0);
    var assignUserBtn = element.all(by.xpath(defaultConfig.assignUserBtnXpath));
    //browser.executeScript("arguments[0].scrollIntoView();", elemToClick.first().getWebElement());
    browser.wait(EC.elementToBeClickable(searchInputBox), 60000);
    //searchInputBox.sendKeys(user);
    searchInputBox.click();
    //searchInputBox.sendKeys(protractor.Key.ENTER);	
    //util.waitForAngular();
    browser.sleep(5000);
    searchInputBox.sendKeys(user);
    //browser.executeScript("arguments[0].scrollIntoView(true);", elemToClick);
    var dropDownValues = element.all(by.xpath("//*[@class='bx--list-box__menu bx--multi-select']/li"));
    browser.wait(EC.visibilityOf(dropDownValues.get(0)), 60000);
    var dropDownValuesChkBox = element.all(by.xpath("//ul//label[@class='bx--checkbox-label']"));
    //dropDownValuesChkBox.click();
    return dropDownValues.getText().then(function (values) {
        //var index = values.indexOf(user);
        var index;
        for (var i = 0; i <= values.length - 1; i++) {
            if (values[i].includes(user)) {
                index = i;
                browser.executeScript("arguments[0].scrollIntoView(true);", dropDownValuesChkBox.get(index));
                util.waitForAngular();
                dropDownValuesChkBox.get(index).click().then(function () {
                    logger.info("User is selected : " + user);
                    util.waitForAngular();
                });
                // assignUserBtn.get(0).click().then(function () {
                //     logger.info("Clicked on assign user button");
                // });
                break;
            }
        }
    });
};

userAccessManagement.prototype.clickAssignUserButton = function () {
    util.waitForAngular();
    browser.sleep(2000);
    var elemToClick = element(by.xpath(defaultConfig.assignUserBtnXpath));
    return browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on User button");
            util.waitForAngular();
        });
    });
};

userAccessManagement.prototype.clickClose = function () {
    var elemToClick = element(by.xpath(this.closeXpath));
    return browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on Close button");
            util.waitForAngular();
        });

    });
};

userAccessManagement.prototype.searchTeam = function (teamName) {
    util.waitForAngular();
    browser.sleep(3000);
    var elem = element(by.css(this.searchTeamCss));
    browser.wait(EC.elementToBeClickable(elem), 60000);
    elem.clear();
    return elem.sendKeys(teamName).then(function () {
        logger.info("Searching for " + teamName);
        util.waitForAngular();
        elem.sendKeys(protractor.Key.ENTER);
        util.waitForAngular();
        var teamNameElem = element(by.css(defaultConfig.tblteamNameCss));
        browser.wait(EC.elementToBeClickable(teamNameElem), 90000).then(function(){
            logger.info("Team name is found under Teams table");
        }).catch(function(err){
            logger.info("Team name is not found under Teams table");
        });
    });
};

userAccessManagement.prototype.clickTeamsLink = function () {
    var elemToClick = element(by.xpath(this.teamsXpath));
    util.waitForAngular();
    return browser.wait(EC.elementToBeClickable(elemToClick), 500000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on Teams tab");
            util.waitForAngular();
        });

    });
};

userAccessManagement.prototype.clickContextValueLink = function () {
    util.waitForAngular();
    var elemToClick = element(by.xpath(this.contextValuesXpath));
    return browser.wait(EC.elementToBeClickable(elemToClick), 240000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on Context Values tab");
            util.waitForAngular();
        }).catch(function (err) {
            browser.sleep(3000);
            elemToClick.click();
        });

    });
};

userAccessManagement.prototype.clickAddnewContextValue = function () {
    var elemToClick = element(by.css(this.addNewContextValueCss));
    util.waitForAngular();
    browser.executeScript("window.scrollTo(0, -500)");
    return browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on Add New Context Value Xpath");
            util.waitForAngular();
        }).catch(function (err) {
            browser.sleep(3000);
            elemToClick.click();
        });

    });
};


userAccessManagement.prototype.selectContextType = function (contextType) {
    var elemToClick = element(by.css(this.newContextTypeCss));
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    return elemToClick.click().then(function () {
        var contxtTypes = element.all(by.css(defaultConfig.newContextTypeCss)).getText();
        var index = contxtTypes.indexOf(contextType);
        contxtTypes.get(index).click().then(function () {
            logger.info("Context selected is " + contextType);
            util.waitForAngular();
        });
    });
};

userAccessManagement.prototype.setNewContextValueDetails = function (contextValueDetails) {
    //Select Context Type
    // var elemToClick = element(by.id(defaultConfig.newContextTypeId));
    // browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    // elemToClick.click().then(function () {
    //     userPage.selectDropDownValue(defaultConfig.newContextTypeId, contextValueDetails["Context Type"]).then(function () {
    //         logger.info("Context Type selected is " + contextValueDetails["Context Type"]);
    //         util.waitForAngular();
    //     });
    //  });    
    var elem = element(by.css(defaultConfig.newContextValueName));
    browser.wait(EC.visibilityOf(elem), 60000);
    //Set Context Value Name
    elem.sendKeys(contextValueDetails["Context Value Name"]).then(function () {
        logger.info("Context Value Name is enetred ");
    });
    //Set Context Value Id
    element(by.css(defaultConfig.newContextValueIdCss)).sendKeys(contextValueDetails["Context Value ID"]).then(function () {
        logger.info("Context Value ID is enetred ");
    });

    return userPage.clickCreateContextValueBtn();

    //});

};

userAccessManagement.prototype.clickCreateContextValueBtn = function () {
    var elemToClick = element(by.css(defaultConfig.createContextbtnCss));
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    return elemToClick.click().then(function () {
        logger.info("Clicked on create button of context value");
        util.waitForAngular();
        browser.sleep(4000);
    });
};

userAccessManagement.prototype.clickCreateContextValueBtnICAM = function () {
    var elemToClick = element(by.css(defaultConfig.createContextbtnCssICAM));
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    return elemToClick.click().then(function () {
        logger.info("Clicked on create button of ICAM context value");
        util.waitForAngular();
    });
};

userAccessManagement.prototype.selectDropDownValue = function (elementId, valueToselect) {
    util.waitForAngular();
    browser.sleep(4000);
    var dropdownValues = element.all(by.xpath("//*[@class='bx--list-box__menu bx--multi-select']//li"));
    browser.wait(EC.elementToBeClickable(dropdownValues.first()), 90000);
    return dropdownValues.getText().then(function (values) {
        var index = values.indexOf(valueToselect);
        dropdownValues.get(index).click().then(function () {
            util.waitForAngular();
        });
    });
};


userAccessManagement.prototype.clickViewDetailsTeam = function (id) {

    //Add Search option
    util.waitForAngular();
    browser.sleep(3000);
    var actionBtn = element(by.css(this.actionBtnCss));
    var editBtn = element(by.css(this.viewDetailsCss));
    browser.wait(EC.elementToBeClickable(actionBtn), 60000);
    return actionBtn.click().then(function () {
        logger.info("Clicked on Action button for team");
        util.waitForAngular();
        browser.wait(EC.elementToBeClickable(editBtn), 60000);
        editBtn.click().then(function () {
            logger.info("Clicked on View Details button for team");
            util.waitForAngular();
        });
    });

};

userAccessManagement.prototype.deleteEntity = function () {
    util.waitForAngular();
    var actionBtn = element(by.css(this.actionBtnCss));
    var deleteBtn = element.all(by.css(this.btnDeleteTeamContextOrganizCss)).get(2);
    var okBtn = element(by.css(this.btnDeleteInConfrmnPopUpCss));

    browser.wait(EC.elementToBeClickable(actionBtn), 60000);
    return actionBtn.click().then(function () {
        logger.info("Clicked on Action button ");
        util.waitForAngular();
        browser.wait(EC.elementToBeClickable(deleteBtn), 60000);
        deleteBtn.click().then(function () {
            logger.info("Clicked on Delete button");
            util.waitForAngular();
        });
        okBtn.click().then(function () {
            logger.info("Clicked on Delete button in confirmation popup");
            util.waitForAngular();
        });
    });

};



userAccessManagement.prototype.AddMultipleRolesForTeam = function (rolesArray) {
    let promiseArr = [];
    var userAccess = new userAccessManagement();
    for (var i = 0; i < rolesArray.length; i++) {
        userAccess.clickAddRole();
        userAccess.selectRoleName(rolesArray[i]);

        //if (rolesArray[i] != "System Admin" && rolesArray[i] != "Catalog Administrator") {
        if (rolesArray[i] != "System Admin") {
            if (rolesArray[i] != 'Buyer') {
                userAccess.selectBsnEntity("Organization");
                userAccess.selectBsnEntityValue("MYORG");
            }

            if (rolesArray[i] == 'Technical Approver' || rolesArray[i] == 'Financial Approver' || rolesArray[i] == 'Buyer') {
                //select env and app
                userAccess.selectEnv("NONE");
                userAccess.selectApp("NONE");
            }
        }

        userAccess.clickSave();
        userAccess.getNotificationMsg();
        promiseArr.push(true);
    }

};

userAccessManagement.prototype.unassignRolesFromTeam = function (rolesId) {
    var userAccess = new userAccessManagement();
    util.waitForAngular();
    for (var i = 0; i < rolesId.length; i++) {
        element(by.xpath("//td[text()='" + rolesId[i] + "']/following-sibling::td")).click();
        userAccess.clickRemoveRolesBtn(rolesId[i]);
        userAccess.clickOkUnassignPopup();
        userAccess.getNotificationMsg();
    }

};

userAccessManagement.prototype.addNewuser = function (user) {
    userPage.clickAsignUserDropdown();
    userPage.selctUserToBeAssigned(user);
    userPage.clickAssignUserButton();
};

userAccessManagement.prototype.unassignUser = function () {
    util.waitForAngular();
    userPage.clickAssignedUserCheckbox();
    return userPage.clickUnassignButton();
};

userAccessManagement.prototype.getTextUserAdded = function () {
    var elem = element(by.css(defaultConfig.userAddedSucsMsg));
    browser.wait(EC.elementToBeClickable(elem), 60000);
    return elem.getText().then(function (text) {
        logger.info(text);
        return text;
    });
};

userAccessManagement.prototype.verifyContexts = function (contextId, contextName) {
    //var curr = this;
    util.waitForAngular();
    //Adding below wait to ignore stale element error
    browser.sleep(2000);
    //this.selectPaginationDropDown();                
    var contxtValueId = element.all(by.xpath(defaultConfig.tblContextValueIdXpath));
    var contxtValueName = element.all(by.xpath(defaultConfig.tblContextValueNameXpath));

    var indexNum;
    contxtValueId.getText().then(function (textArray) {
        indexNum = textArray.indexOf(contextId);
        if (indexNum == -1) {
            userPage.pagination().then(function (value) {
                if (value == true) {
                    //browser.wait(EC.visibilityOf(contxtValueName), 15000);              
                    userPage.verifyContexts(contextId, contextName);
                } else {
                    logger.info("Context Value Id is not displaying.");
                    return false;
                }
            });

        } else {
            logger.info(contextId + " | Context Id is succesfully validated on Contexts page.");
            contxtValueName.getText().then(function (textArray) {
                indexNum = textArray.indexOf(contextName);
                if (indexNum == -1) {
                    userPage.pagination().then(function (value) {
                        if (value == true) {
                            browser.wait(EC.visibilityOf(contxtValueName), 15000);
                            this.verifyContexts(contextId, contextName);
                        } else {
                            logger.info("Context Value Name is not displaying.");
                            return false;
                        }
                    });
                } else {
                    logger.info(contextName + " | ContextName is succesfully validated on Contexts page.");
                }
            });
        }
    });
};


userAccessManagement.prototype.pagination = function () {
    var currentPageNumber, totalPageNumber;
    var paginationElement = element.all(by.css('.bx--pagination__right .bx--pagination__text'));
    return paginationElement.getAttribute('innerText').then(function (paginationText) {
        logger.info("paginationText : " + paginationText.toString());
        var paginationArray = paginationText.toString().split(" ");
        currentPageNumber = paginationArray[0];
        totalPageNumber = paginationArray[2];
    }).then(function () {
        logger.info("Current Page Number..." + currentPageNumber);
        logger.info("Total Page Number..." + totalPageNumber);
        if (parseInt(currentPageNumber, 10) < parseInt(totalPageNumber, 10)) {
            browser.executeScript("window.scrollTo(0, 1200)");
            browser.wait(EC.elementToBeClickable(element(by.css('[id^=bx--pagination__forward-button]'))), 30000);
            return element(by.css('[id^=bx--pagination__forward-button]')).click().then(function () {
                logger.info("Clicked on next button for pagination...");
                util.waitForAngular();
                return true;
                //this.selectPaginationDropDown();                
            }).catch(function (err) {
                logger.info("User is on last page");
                return false;
            });
        } else {
            return false;
        }
    });

};

userAccessManagement.prototype.selectPaginationDropDown = function () {
    //browser.executeScript("window.scrollTo(0,1050)");
    var dropdown = element(by.css(this.budgetaryPaginationDrpDwnCss));
    util.waitForAngular();
    browser.wait(EC.elementToBeClickable(dropdown), 60000).then(function () {
        dropdown.isEnabled().then(function (enabled) {
            if (enabled) {
                dropdown.click().then(function () {
                    // var dropDownValuesArray = element.all(by.xpath("//*[contains(@id,'bx--pagination-select-id-')]/option"));
                    var dropDownValuesArray = element.all(by.css("select[id^=\"bx--pagination-select-id-\"] option"));
                    dropDownValuesArray.getText().then(function (textArray) {
                        dropDownValuesArray.get(textArray.length - 1).getText().then(function (text) {
                            dropDownValuesArray.get(textArray.length - 1).click().then(function () {
                                logger.info("Selected " + text.trim() + " from pagination dropdown");
                            });
                        });
                    });
                });
            }
        });

    });

};

userAccessManagement.prototype.validateNewlyAddedRoles = function (roles) {
    var elem = element.all(by.xpath(defaultConfig.roleListXpath));
    //browser.wait(EC.visibilityOf(elem), 60000);
    browser.sleep(4000);
    return elem.getText().then(function (roleList) {
        console.log("role list  are : roleList" + roleList);
        for (var i = 0; i < roles.length; i++) {
            if (roleList.indexOf(roles[i]) != -1) {
                logger.info("Role Added : " + roles[i]);
            } else {
                logger.info("Unable to add role : " + roles[i]);
                return false;
            }
        }
        return true;
    });
};

userAccessManagement.prototype.validateUnassignedRoles = function (roles) {
    var elem = element.all(by.xpath(defaultConfig.roleListXpath));
    //browser.wait(EC.visibilityOf(elem), 60000);
    browser.sleep(4000);
    return elem.getText().then(function (roleList) {
        for (var i = 0; i < roles.length; i++) {
            if (roleList.indexOf(roles[i]) == -1) {
                logger.info("Role Unassigned : " + roles[i]);
            } else {
                logger.info("Unable to unassign role : " + roles[i]);
                return false;
            }
        }
        return true;
    });
};

userAccessManagement.prototype.validateNewTeamDetails = function (teamNameExp, teamIdAct) {
    util.waitForAngular();
    browser.sleep(5000);
    var teamName = element(by.css(this.tblteamNameCss));
    var teamId = element(by.css(this.tblteamIdCss));
    browser.wait(EC.visibilityOf(teamName), 60000).then(function(){
        logger.info("Validating team on teams table");
    }).catch(function(err){
        logger.info("Team not displayed under teams table");
    });
    return teamName.getText().then(function (text) {
        if (text == teamNameExp) {
            logger.info("Team name is succesfully validated : " + teamNameExp);
            teamId.getText().then(function (text) {
                if (text == teamIdAct) {
                    logger.info("Team Id is succesfully validated : " + teamIdAct);
                } else {
                    logger.info("Team Id is not validated : " + teamIdAct);
                    return false;
                }
            });
        } else {
            logger.info("Team name is not validated : " + teamNameExp);
            return false;
        }

        return true;
    });
};

userAccessManagement.prototype.clickOrganizationsLink = function () {
    var elemToClick = element.all(by.xpath(this.OrganizationXpath));
    util.waitForAngular();
    return browser.wait(EC.elementToBeClickable(elemToClick.get(1)), 500000).then(function () {
        elemToClick.get(1).click().then(function () {
            logger.info("Clicked on Organization tab");
            util.waitForAngular();
        });
    });
};

userAccessManagement.prototype.clickAddNewOrganization = function () {
    util.waitForAngular();
    var elemToClick = element(by.xpath(this.addNewOrganizationXpath));
    return browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on Add New organization button.");
            util.waitForAngular();
        });

    });
};

userAccessManagement.prototype.setNewOrganizationDetails = function (OrganizationDetails) {

    var elem = element(by.css(this.organisnIdCss));

    browser.wait(EC.elementToBeClickable(elem), 60000);
    elem.sendKeys(OrganizationDetails["Organization Id"]).then(function () {
        logger.info("Organization Id is enetred " + OrganizationDetails["Organization Id"]);
    });

    element(by.css(this.organisnNameCss)).sendKeys(OrganizationDetails["Organization Name"]).then(function () {
        logger.info("Organization Name is enetred " + OrganizationDetails["Organization Name"]);
    });

    element(by.css(this.organisnDescriptionCss)).sendKeys(OrganizationDetails["Organization Description"]).then(function () {
        logger.info("Organization Description is enetred ");
    });

};

userAccessManagement.prototype.clickCreateOrganizn = function () {
    var elemToClick = element(by.css(this.btnCreateOrgnsCss));
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    return elemToClick.click().then(function () {
        logger.info("Clicked on Create Organization button");
        util.waitForAngular();
        browser.sleep(3000);
    });
};

userAccessManagement.prototype.validateNewOrganizationDetails = function (orgNameExp, orgIdAct) {

    util.waitForAngular();
    browser.sleep(3000);
    var orgName = element(by.css(this.OrgNameCss));
    var orgId = element(by.css(this.OrgIdCss));
    //browser.wait(EC.elementToBeClickable(orgId), 60000);
    return orgName.getText().then(function (text) {
        if (text == orgNameExp) {
            logger.info("Organization name is succesfully validated : " + orgNameExp);
            orgId.getText().then(function (text) {
                if (text == orgIdAct) {
                    logger.info("Organization Id is succesfully validated : " + orgIdAct);
                } else {
                    logger.info("Organization Id is not validated : " + orgIdAct);
                    return false;
                }
            });
        } else {
            logger.info("Organization name is not validated : " + orgNameExp);
            return false;
        }

        return true;
    });
};

userAccessManagement.prototype.clickActionBtn = function (contxt) {
    util.waitForAngular();
    browser.sleep(2000);
    var elemToClick = element(by.css(this.btnActionCss));
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    return elemToClick.click().then(function () {
        logger.info("Clicked on " + contxt + " Action button");
        util.waitForAngular();
    });
};

userAccessManagement.prototype.clickDeleteBtn = function (context) {
    var elemToClick = element.all(by.xpath(this.btnDeleteXpath));
    browser.wait(EC.elementToBeClickable(elemToClick.last()), 60000);
    return elemToClick.last().click().then(function () {
        logger.info("Clicked on " + context + " Delete button");
        util.waitForAngular();
    });
};

userAccessManagement.prototype.clickOrgCnfrmDeleteBtn = function () {
    var elemToClick = element.all(by.xpath(this.btnDeleteXpath));
    browser.wait(EC.elementToBeClickable(elemToClick.last()), 60000);
    return elemToClick.last().click().then(function () {
        logger.info("Clicked on Confirm Delete button for organization");
        util.waitForAngular();
    });
};

userAccessManagement.prototype.verifysuccessMsgnotPresent = function(){
    util.waitForAngular();
    browser.wait(EC.visibilityOf(element(by.css(this.txtSucsMsgCss))),30000).then(function () {
        logger.info("Waiting for success message to get disappear...");
    })
    browser.wait(EC.invisibilityOf(element(by.css(this.txtSucsMsgCss))),30000).then(function () {
        logger.info("Success Message got disappeared now...");
    });
};

userAccessManagement.prototype.getSuccessMsg = function () {

    var elemText = element(by.css(this.txtSucsMsgCss));
    browser.wait(EC.visibilityOf(elemText), 60000);
    return elemText.getText().then(function (text) {
        logger.info(text);
        util.waitForAngular();
        return text;
    });

};

userAccessManagement.prototype.teamUpdatedmsg = function () {
    util.waitForAngular();
    util.waitForLoader();
    var elemText = element(by.css(this.strTeamUpdatedMsgCss));
    browser.wait(EC.visibilityOf(elemText), 60000).then(function(){
        logger.info("Waiting for team notification message");
    }).catch(function(){
        logger.info("Waiting for team notification message");
    });
    return elemText.getText().then(function (text) {
        logger.info(text);
        util.waitForAngular();
        return text;
    });
};

userAccessManagement.prototype.setUpdatedTeamNameTextbox = function (newTeamName) {
    util.waitForAngular();
    var elem = element(by.css(this.txtEditTeamNameCss));
    browser.wait(EC.elementToBeClickable(elem), 60000);
    elem.clear();
    browser.sleep(2000);
    return elem.sendKeys(newTeamName).then(function () {
        logger.info("New Team Name enetred " + newTeamName);
        util.waitForAngular();
    });
};
userAccessManagement.prototype.clickUpdateTeamBtn = function () {
    var elemToClick = element(by.xpath(this.btnUpdateTeamXpath));
    //browser.executeScript("window.scrollTo(0,500)");
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    //elemToClick.click();
    return elemToClick.click().then(function () {
        logger.info("Clicked on Update Team button");
        util.waitForAngular();
        //browser.sleep(4000);
    });
};

userAccessManagement.prototype.navigateTeamPage = function () {
    var elemToClick = element(by.xpath(this.teamLnkXpath));
    util.waitForAngular();
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    return elemToClick.click().then(function () {
        logger.info("Clicked on Team link");
        util.waitForAngular();
        //browser.sleep(4000);
    });

}

userAccessManagement.prototype.clickEditBtn = function () {
    util.waitForAngular();
    var elemToClick = element(by.xpath(this.editBtnXpath));
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    return elemToClick.click().then(function () {
        logger.info("Clicked on Edit button for Team");
        util.waitForAngular();
        //browser.sleep(4000);
    });

}

userAccessManagement.prototype.getNotificationMsg = function () {

    //browser.ignoreSynchronization = true;
    var elem = element(by.css(".bx--toast-notification__subtitle"));
    browser.wait(EC.visibilityOf(elem), 35000);
    return elem.getText().then(function (text) {
        logger.info(text);
        var notfcnClosBtn = element(by.css(".bx--toast-notification__close-button"));
        notfcnClosBtn.click();
        return text;
    });

}

userAccessManagement.prototype.getNotificationMsgInsideFrame = function () {

    browser.ignoreSynchronization = true;
    var elem = element(by.css(".bx--inline-notification.bx--inline-notification--success"));
    browser.wait(EC.visibilityOf(elem), 15000);
    return elem.getText().then(function (text) {
        logger.info(text);
        return text;
    });

};

userAccessManagement.prototype.clickRemoveRolesBtn = function (roleName) {
    util.waitForAngular();
    //browser.sleep(2000);
    var elem = element.all(by.cssContainingText(".bx--overflow-menu-options__option-content", " Remove "));
 //   browser.wait(EC.elementToBeClickable(elem.last()), 20000);
    browser.executeScript("arguments[0].scrollIntoView(true);", elem.last());
    return elem.last().click().then(function () {
        logger.info("Clicked on Remove button for role " + roleName);
        util.waitForAngular();
    });
};

userAccessManagement.prototype.clickCnfrmDeleteBtn = function (contxt) {
    util.waitForAngular();
    var elem = element(by.css(this.btnCommnDeleteCss));
    browser.wait(EC.elementToBeClickable(elem), 20000);
    return elem.click().then(function () {
        logger.info("Clicked on Confirm Delete button for " + contxt);
        util.waitForAngular();
    });

}
userAccessManagement.prototype.clickFirstTeamRoleActionIcon = function () {
    util.waitForAngular();
    browser.wait(EC.elementToBeClickable(element.all(by.css(this.rolesMenuIconCss)).get(0)), 30000);
    element.all(by.css(this.rolesMenuIconCss)).get(0).click().then(function () {
        logger.info("clicked on first team role action Icon");
    })
}
userAccessManagement.prototype.clickFirstTeamRoleViewDetailBtn = function () {
    browser.wait(EC.elementToBeClickable(element.all(by.css(this.rolesViewDetailIconCss)).get(0)), 30000);
    element.all(by.css(this.rolesViewDetailIconCss)).get(0).click().then(function () {
        logger.info("clicked on first team role View Details Button");
    })
}
userAccessManagement.prototype.getTextBasedOnContextLabelName = function (labelName) {
    browser.wait(EC.visibilityOf(element.all(by.xpath("//strong[contains(text(), '" + labelName + "')]/following-sibling::span")).get(0)), 50000);
    return element(by.xpath("//strong[contains(text(), '" + labelName + "')]/following-sibling::span")).getText().then(function (text) {
        logger.info("The value for " + labelName + " is : " + text)
        return text;
    });
};

userAccessManagement.prototype.clickSaveProviderDeatailsBtn = function () {
    util.waitForAngular();
    var elem = element(by.xpath(this.btnSaveProviderAcntDetailsXpath));
    return browser.wait(EC.visibilityOf(elem), 15000).then(function () {
        return elem.click();
    }).catch(function (err) {
        logger.info("Save button not visible");
    });
}

userAccessManagement.prototype.clickAsignUserDropdown = function () {
    util.waitForAngular();
    var assgnUsrBtn = element(by.xpath("//button[contains(text(), 'Assign User(s) ')]"));
    assgnUsrBtn.click().then(function () {
        logger.info("Clicked on Assign user button");
    })
    var elem = element(by.xpath(defaultConfig.btnAsignUsrDropdownXpath));
    browser.wait(EC.elementToBeClickable(elem), 30000);

    // return elem.click().then(function () {
    //     logger.info("Clicked on Assign Users Dropdown");
    //     util.waitForAngular();
    // });
}

userAccessManagement.prototype.clickSearchBtn = function () {
    util.waitForAngular();
    browser.sleep(3000);
    //browser.ignoreSynchronization=true;
    var elem = element(by.css(".bx--search-magnifier"));
    browser.wait(EC.elementToBeClickable(elem), 60000).then(function(){
        logger.info("Waiting for Search button to be clickable");
    }).catch(function(err){
        logger.info("Search button not clickable");
    });
    elem.click().then(function () {
        logger.info("Clicked on Search button");
    }).catch(function(err){
        browser.sleep(10000);
        elem.click();
    });
};

userAccessManagement.prototype.searchContextType = function (ContextTypenme) {
    util.waitForAngular();
    browser.sleep(5000);
    var elem = element(by.css(this.searchContexttypeCss));
    browser.wait(EC.elementToBeClickable(elem), 60000);
    elem.clear();
    return elem.sendKeys(ContextTypenme).then(function () {
        logger.info("Searching for " + ContextTypenme);
        util.waitForAngular();
        elem.sendKeys(protractor.Key.ENTER);
        util.waitForAngular();
        browser.sleep(5000);
    });
};

userAccessManagement.prototype.clickContextValueIcon = function () {
    util.waitForAngular();
    var elemToClick = element(by.css(this.clickOnActionIconContextCss));
    return browser.wait(EC.elementToBeClickable(elemToClick), 10000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on Context Values Action Icon");
            util.waitForAngular();
        });

    });
};

userAccessManagement.prototype.clickAddContextValueforICAM = function () {
    var elemToClick = element(by.css(this.clickAddContextValueCss));
    browser.executeScript("window.scrollTo(0, -500)");
    return browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {
        elemToClick.click().then(function () {
            logger.info("Clicked on Add Context Value for ICAM ");
            util.waitForAngular();
        });

    });
};

userAccessManagement.prototype.setNewContextValueDetailsICAM = function (contextValueDetails) {
    var elem = element(by.css(defaultConfig.AddnewContextValueNameICAMnamespaceCss));
    util.waitForAngular();
    browser.wait(EC.elementToBeClickable(elem), 60000);
    //Set Context Value Name
    elem.sendKeys(contextValueDetails["Context Value Name"]).then(function () {
        logger.info("ICAM Context Value Name is entered ");
    });
    //Set Context Value Id
    element(by.css(defaultConfig.AddnewContextValueIdICAMNamespaceCss)).sendKeys(contextValueDetails["Context Value ID"]).then(function () {
        logger.info("ICAM Context Value ID is entered ");
    });
    util.scrollToBottom();
    return userPage.clickCreateContextValueBtnICAM();
};

//expandIcon
userAccessManagement.prototype.clickExpandMenu = function () {
    browser.wait(EC.elementToBeClickable(element.all(by.xpath(this.expandIconXpath)).get(0)), 30000);
    element.all(by.xpath(this.expandIconXpath)).get(0).click().then(function () {
        logger.info("click on expand menu");
    })
}

/**
 * Method to click on three dot icon menu from contex value namespace 
 */
userAccessManagement.prototype.clickOnThreeDotMenuIcon = function (contxtNameIcamNamspace) {
    util.waitForAngular();
    browser.wait(EC.elementToBeClickable(element(by.xpath("//span[contains(text(), '" + contxtNameIcamNamspace + "')]" + this.threeDotIconXpath))), 30000);
    element(by.xpath("//span[contains(text(), '" + contxtNameIcamNamspace + "')]" + this.threeDotIconXpath)).click().then(function () {
        logger.info("Clicked on three Dot Icon");
    });

};
//deleteNamespaceButton
userAccessManagement.prototype.clickOndeleteNamespaceButton = function () {
    util.waitForAngular();
    browser.wait(EC.elementToBeClickable(element(by.xpath(this.deleteNamespaceButtonXpath))), 30000);
    element(by.xpath(this.deleteNamespaceButtonXpath)).click().then(function () {
        logger.info("Clicked on delete button");

    });
};
//btnDeleteInConfrmnPopUpCss

userAccessManagement.prototype.clickbtnDeleteInConfrmnPopUp = function () {
    browser.wait(EC.elementToBeClickable(element(by.xpath(this.deleteOkButtonXpath))), 60000);
    element(by.xpath(this.deleteOkButtonXpath)).click().then(function () {
        logger.info("Clicked on OK delete popup");
    })
}
//forwardButton

userAccessManagement.prototype.clickforwardButton = function () {
    browser.wait(EC.elementToBeClickable(element(by.xpath(this.forwardButtonXpath))), 60000);
    element(by.xpath(this.forwardButtonXpath)).click().then(function () {
        logger.info("Clicked on forward button");
    })
}

//addContextValueXpath
userAccessManagement.prototype.clickaddContextValue = function () {
    browser.wait(EC.elementToBeClickable(element(by.xpath(this.addContextValueXpath))), 60000);
    element(by.xpath(this.addContextValueXpath)).click().then(function () {
        logger.info("Clicked on addContextValue button");
    })
}

//paginationClickDropdown
userAccessManagement.prototype.clickpaginationClickDropdown = function () {
    browser.wait(EC.elementToBeClickable(element(by.css(this.paginationClickDropdownCss))), 60000);
    element(by.css(this.paginationClickDropdownCss)).click().then(function () {
        logger.info("Clicked on paginationClick Dropdown");
    })
}
//OnThirthyPageValue
userAccessManagement.prototype.clickOnThirthyPageValue = function () {
    browser.wait(EC.elementToBeClickable(element(by.xpath(this.OnThirthyPageValueXpath))), 60000);
    element(by.xpath(this.OnThirthyPageValueXpath)).click().then(function () {
        logger.info("Clicked on OnThirthyPageValue button");
    })

};

userAccessManagement.prototype.getTeamName = function(teamName){
    var elem = element(by.css(defaultConfig.deleteTeamConfrMsgCss))
    var deletTeam
    browser.wait(EC.visibilityOf(elem), 60000)
    try {
        return elem.getText().then(function(text){
            logger.info(text)
            var msg = text.split("'")
            var team = msg[1].replace("'?", "")
            if (team == teamName) {
                deletTeam = true
            }else{
                deletTeam = false
            }
            
            return deletTeam
        });
    } catch (error) {
        return false
    }
};

userAccessManagement.prototype.clickCancelBtn = function(){
    var elem = element(by.css(defaultConfig.cancelDeletionBtnCss))
    browser.wait(EC.elementToBeClickable(elem), 60000)
    return elem.click().then(function(){
        logger.info("Clicked on Cancel button of Team Deletion Popup")
    })
};

module.exports = userAccessManagement;
