"use strict";

var extend = require('extend');
var url = browser.params.url;
var util = require('../../helpers/util.js');
var CatalogPage = require('../pageObjects/catalog.pageObject.js');
var mcmpUIDataTemplate = require('../../testData/mcmp/mcmpUIData.json');
var logGenerator = require("../../helpers/logGenerator.js"),
	logger = logGenerator.getApplicationLogger();
var EC = protractor.ExpectedConditions;

var defaultConfig = {
	pageUrl: url + '/consume/operationPolicies',

	//Create Operation Group Slidder page locator
	textPolicyNameFieldCss: '#text-input-name',
	addOprationGroupButtonTxt: 'Add Operation Group',

	//Operation Group page locator
	operationGroupTabCss: "[title='Operation Group']",
	//operationGroupTabCss: '.bx--tabs__nav-item',
	newOperationGroupButtonId: 'addPolicyGroup',
	searchBoxPolicyGroupCss: '.bx--search-input',
	actionPolicyGroupId: 'carbon-deluxe-data-table-operationGroupList-parent-row-1-overflow-menu-icon',
	viewDetailsButtonTextOperationGroupCss: 'View Details',
	searchResultNotFoundXpath: '//strong[contains(text(),"No Data Available")]',
	duplicateButtonTextOperationGroup: 'Duplicate',
	duplicateOperationGroupId: 'text-input-policyGroupName',
	duplicateButtonId: 'operation-group-duplicate-button',
	deleteButtonTextOfOperationGroup: 'Delete',
	deletepopupContinueButtonId: 'operation-group-delete-continue-button',
	createSuccessMsgOfOperationGroupCss: '.bx--toast-notification__subtitle span[class="body"]',
	closeNotificationIconCss: '.bx--toast-notification__close-icon',


	//Slidder pop-up of View operation Group
	slidderPanelOperationGroupNameTitleCss: '.bx--slide-over-panel-title',
	operationGroupNameId: 'text-input-name',
	//operationId: 'search-tag',
	operationId: '.bx--tag.bx--tag--filter.bx--tag--high-contrast.bx--tag--inverse',
	updateButtonOperationGroupText: 'Update',
	deleteButtonOperationGroupid: 'operation-group-delete-button',
	continueButtonIdOfDeletePopUpOperationGroup: 'operation-group-delete-continue-button-view-details',

    //Operation Policy Page Locators
	buttonIdAddPolicyCss:  '#addPolicy',
	operationPolicyTabCss: '.bx--tabs__nav-link',
	radioButtonOperationPolicyCss: '.bx--radio-button__label',
	buttonDeleteConfirmationPopUpCss: '#continue',	
	tableOperationPolicyCss: '#carbon-deluxe-data-table-policiesList tbody tr td',
	
	storeHeaderCss: '.bx--header__name',
	buttonLeftNavSubMenu: '.bx--side-nav__submenu',
	buttonLeftSubmenuCss: '.bx--side-nav__submenu-title',
	buttonLeftSubmenuExpandXpath: '//*[@class="bx--side-nav__submenu-title"]/parent::button',
	closeoperationGroupSliderCss:'bx--slide-over-panel--close',
};

function operationPolicy(selectorConfig) {
	if (!(this instanceof operationPolicy)) {
		return new operationPolicy(selectorConfig);
	}
	extend(this, defaultConfig);

	if (selectorConfig) {
		extend(this, selectorConfig);
	}
}

operationPolicy.prototype.open = async function () {
	/*await util.getUrl(this.pageUrl);
	browser.get(this.pageUrl);
	browser.wait(EC.urlContains("/consume/operationPolicies"), 90000).then(function(){
		logger.info("Opened the Operation Policy page");
	});
	browser.wait(EC.visibilityOf(element(by.css(this.storeHeaderCss))),90000);
  	browser.switchTo().frame(element(by.tagName('iframe')).getWebElement());
    util.waitForAngular();*/
	
	var catalogPage = new CatalogPage();
	util.switchToDefault();
	catalogPage.clickHamburgerCatalog();
	catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
	catalogPage.checkIfleftNavStoreExpanded();
	catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkOperationPolicies);
	util.switchToFrame();
    util.waitForAngular();			
};
//Operation Policy page functions
operationPolicy.prototype.clickOperationPolicyTab = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.operationPolicyTabCss))), 9000);
	element(by.css(this.operationPolicyTabCss)).click().then(function () {
		logger.info("Click on Operation Policy Tab");
	});
};


operationPolicy.prototype.clickAddOperationPolicyButton = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonIdAddPolicyCss))), 9000);
	element(by.css(this.buttonIdAddPolicyCss)).click().then(function () {
		logger.info("Click on Add New Operation Policy button");
	});
};

operationPolicy.prototype.clickOperationPolicyRetiredOption = function()
{ 	
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element.all(by.css(this.radioButtonOperationPolicyCss)).last()), 120000);
   	return element.all(by.css(this.radioButtonOperationPolicyCss)).last().click().then(function(){
		logger.info('Click on retired option');
	});
};

operationPolicy.prototype.getTextOperationPolicyStatusInOperationPolicyTable = function(operPolicyName){
	   var self = this;
	   var isTextPresent = false;	
	   var operationPolicyStatus;
	   util.waitForAngular();
	   browser.wait(EC.visibilityOf(element(by.css(self.tableOperationPolicyCss))), 30000);
	   var policyArray = element.all(by.css(self.tableOperationPolicyCss));
	   return policyArray.getText().then(function(policyDetailArray){
		for (var i = 0; i < policyDetailArray.length; i++){
			if(policyDetailArray[i]==operPolicyName){
				logger.info(operPolicyName +" Found");
				isTextPresent = true;
				logger.info("Operation policyStatus : "+policyDetailArray[i+5]);
				operationPolicyStatus = policyDetailArray[i+5];
				return operationPolicyStatus;			
			}					
		}
	}).then(function(){
		logger.info("status is : "+operationPolicyStatus);
		return operationPolicyStatus;			
	});	
};


operationPolicy.prototype.clickDeleteConfirmationPopUpApprovalPolicyBtn = function(){
util.waitForAngular();
browser.wait(EC.elementToBeClickable(element(by.css(this.buttonDeleteConfirmationPopUpCss))),30000);
return element(by.css(this.buttonDeleteConfirmationPopUpCss)).click().then(function(){
logger.info("Clicked on the delete approval policy confirmation button...");
	});
};
		
//Operation Group page functions
operationPolicy.prototype.openOperationGroup = function () {
	util.waitForOverlay()
	util.waitForAngular();
	browser.sleep(5000);
	var operationGroupBtn = element(by.css(this.operationGroupTabCss));
	browser.wait(EC.elementToBeClickable(operationGroupBtn), 90000);
	operationGroupBtn.click().then(function () {
		logger.info("Clicked on Operation Group Tab link");
		util.waitForAngular();
		browser.wait(EC.urlContains("/lite/consume/operationPolicies"), 10000);
	}).catch(function(err){
		browser.sleep(5000);
		operationGroupBtn.click();
	});
};

operationPolicy.prototype.clickNewOperationGroupButton = function () {
	util.waitForOverlay()
	browser.wait(EC.elementToBeClickable(element(by.id(this.newOperationGroupButtonId))), 30000);
	element(by.id(this.newOperationGroupButtonId)).click().then(function () {
		logger.info("Clicked on New Operation Group button");
	});
};

operationPolicy.prototype.clickOnAddOperationGroupButton = function () {
	var elementAddOperationGroup = element(by.buttonText(this.addOprationGroupButtonTxt));
	browser.wait(EC.elementToBeClickable(elementAddOperationGroup), 6000);
	elementAddOperationGroup.click().then(function () {
		util.waitForAngular();
		logger.info("clicked on the Add Operation Group button");
	});
};

operationPolicy.prototype.verifyTheToastMsgOfOperationGroupPopUP = function () {
	var msgElement = element(by.css(this.createSuccessMsgOfOperationGroupCss));
	browser.wait(EC.visibilityOf(msgElement), 90000);
	return msgElement.getText().then(function (successMsg) {
		logger.info(successMsg);
		browser.sleep(2000);
		return successMsg;
	});
};

operationPolicy.prototype.clickCloseBtnOfNotificationPopUp = function () {
	util.waitForAngular();
	browser.wait(EC.presenceOf(element(by.css(this.closeNotificationIconCss))), 10000);
	element(by.css(this.closeNotificationIconCss)).click().then(function () {
		logger.info("Clicked on Notification close button");
	});
}

operationPolicy.prototype.searchOperationGroup = function (operationGroupName) {
	util.waitForAngular();
	var elementOfSearchBox = element(by.css(this.searchBoxPolicyGroupCss));
	return browser.wait(EC.elementToBeClickable(elementOfSearchBox), 60000).then(function () {
		elementOfSearchBox.clear();
		elementOfSearchBox.sendKeys(operationGroupName).then(function () {
			logger.info("Text entered in operation group search box");
		});
		elementOfSearchBox.sendKeys(protractor.Key.ENTER).then(function () {
			logger.info("Press Enter");
		});
	});
};


operationPolicy.prototype.clickOnTheActionOverflowMenuIconOfOperationPolicyGroup = function () {
	var elementOfActionIcon = element(by.id(this.actionPolicyGroupId));
	browser.wait(EC.elementToBeClickable(elementOfActionIcon), 90000);
	elementOfActionIcon.click().then(function () {
		logger.info("Clicked on the Action Icon Of Operation Policy");
	})
}

operationPolicy.prototype.clickOnViewDetailsActionOfOperationGroup = function () {
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.viewDetailsButtonTextOperationGroupCss))), 60000);
	element(by.buttonText(this.viewDetailsButtonTextOperationGroupCss)).click().then(function () {
		logger.info("Clicked on the View Details button of operation group");
	});
	util.waitForAngular();
};

operationPolicy.prototype.getOperationPolicySlidderPanelTitle = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.slidderPanelOperationGroupNameTitleCss))));
	return element(by.css(this.slidderPanelOperationGroupNameTitleCss)).getText().then(function(text){
		console.log("Slidder panel title of operation group is "+text);
	})
};

operationPolicy.prototype.getOperationGroupNameFromTheViewDetailPage = function () {

	browser.wait(EC.elementToBeClickable(element(by.id(this.operationGroupNameId))), 9000);
	return element(by.id(this.operationGroupNameId)).getAttribute('title').then(function(grpName){
		logger.info("Operation Group name is "+grpName);
		return grpName
	})
}

operationPolicy.prototype.getOperationsFromTheViewDetailPage = function (opts) {
	var self = this;
	browser.wait(EC.visibilityOf(element.all(by.css(self.operationId)).last()), 300000);
	return element.all(by.css(self.operationId)).getText().then(function(operation){
		for(var i=0; i <= operation.length; i++){
			if(operation[i] == opts){
				logger.info("operation[i]: "+ operation[i]);
				logger.info("Operation of the group "+operation[i]);
				return operation[i];
			}
		}
	})
}

operationPolicy.prototype.clickOnUpdateButtonOfOperationGroup = function () {
	element(by.buttonText(this.updateButtonOperationGroupText)).click().then(function () {
		logger.info("Clicked on Update button of operation group");
		util.waitForAngular();
	});
}

operationPolicy.prototype.clickOnDeleteButtonOfOperationGroup = function () {
	element(by.id(this.deleteButtonOperationGroupid)).click().then(function () {
		logger.info("Clicked on Delete button of operation group");
		util.waitForAngular();
	})
}

operationPolicy.prototype.clickOnContinueButtonOfDeletePopupOfOperationGroup = function () {
	browser.wait(EC.elementToBeClickable(element(by.id(this.continueButtonIdOfDeletePopUpOperationGroup))), 60000);
	element(by.id(this.continueButtonIdOfDeletePopUpOperationGroup)).click().then(function () {
		logger.info("Clicked on Continue button of delete operation group confirmation pop-up");
		util.waitForAngular();
	});


}

operationPolicy.prototype.verifyTheOperationGroupDeleted = function () {
	util.waitForAngular();
	return element(by.xpath(this.searchResultNotFoundXpath)).isPresent().then(function(elemNotFound){
		logger.info("Searched operation group is not found");
		return elemNotFound;
	});
};

operationPolicy.prototype.clickOnDuplicateButtonOFOperationGroup = function () {
	var duplicateButtonElement = element(by.buttonText(this.duplicateButtonTextOperationGroup));
	duplicateButtonElement.click().then(function () {
		logger.info("Clicked on Duplicate button of operation Group From the Action menu");
	})
};


operationPolicy.prototype.enterTheDuplicateOperationGroupName = function (duplicateGrpName) {
	var elementOfOperationGroup = element(by.id(this.duplicateOperationGroupId));
	return browser.wait(EC.elementToBeClickable(elementOfOperationGroup), 60000).then(function () {
		elementOfOperationGroup.clear();
		elementOfOperationGroup.sendKeys(duplicateGrpName).then(function () {
			logger.info("Entered duplicate operation group name ");
		});
	});
};

operationPolicy.prototype.clickOnDuplicateButtonOfOperationGroup = function () {
	element(by.id(this.duplicateButtonId)).click().then(function () {
		logger.info("Clicked on the duplicate button of operation group");
		util.waitForAngular();
	})
};

operationPolicy.prototype.deleteOperationGroup = function () {
	element(by.buttonText(this.deleteButtonTextOfOperationGroup)).click().then(function () {
		logger.info("Clicked On Delete button from the Action of the oepration group");
		browser.wait(EC.elementToBeClickable(element(by.id(defaultConfig.deletepopupContinueButtonId))), 60000);
		element(by.id(defaultConfig.deletepopupContinueButtonId)).click().then(function () {
			logger.info("Clicked on Continue button of delete operation group confirmation pop-up");
			util.waitForAngular();
		})
	})
}
operationPolicy.prototype.closeOperationGroupSliderIfPresent = function () {
	var self = this;
	return element(by.css(self.closeoperationGroupSliderCss)).isPresent().then(function (res) {
		if (res) {
			browser.wait(EC.visibilityOf(element(by.xpath(self.closeoperationGroupSliderCss))), 30000);
			self.clickBudgetSliderCloseButton();
		}
		else {
			logger.info("operation Group Slider is closed");
		}
	});
};
module.exports = operationPolicy;
