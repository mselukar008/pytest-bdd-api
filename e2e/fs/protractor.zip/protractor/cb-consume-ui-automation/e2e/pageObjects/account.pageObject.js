"use strict";

var extend = require('extend');
var url = browser.params.url;
var EC = protractor.ExpectedConditions;
var util = require('../../helpers/util.js');
var CatalogPage = require('../pageObjects/catalog.pageObject.js');
var mcmpUIDataTemplate = require('../../testData/mcmp/mcmpUIData.json');
const { waitForAngular } = require('../../helpers/util.js');

var logGenerator = require("../../helpers/logGenerator.js"),
	logger = logGenerator.getApplicationLogger();


//Accounts pageObjects
var defaultConfig = {
	pageUrl: url + '/accounts',
	textPageHeaderCss: ".ibm--page-header__title",
	buttonAddAccountXpath: '//button[contains(.,"Add Account")]',

	accountLinkTextXpath: '//a[contains(text(), "ACCOUNTS")]',

	//Amazon Account
	buttonAmazonAddAccountXpath: '(//button[contains(.,"Select")])[0]',
	//SoftLayer
	buttonSoftLayerAddAccountXpath: '(//button[contains(.,"Select")])[1]',
	//VRA
	buttonVRAAddAccountXpath: '(//button[contains(.,"Select")])[2]',

	//Locators in Add Account page 
	buttonSelectAddAccountCss: '.button.button2',
	bluePrintAccountTitleCss: '.middle_vertical_align.upper_name',

	//Locators specific to providers
	textboxEndpointUrlVRACss: "#text-input-url",

	//Common
	linkMasterAssetAccountsCss: '.bx--tabs__nav-link',
	titleAddANewAccountCss: '.account-page-sub-heading',
	subtitleProviderNameCss: '.form-control-input-account-name',
	titleForCredentialsCss: 'h5',
	submitButon: '.button-submit',
	txtSearchProviderAccountCss: '.bx--search-input',
	lnkActionCss: 'carbon-icon[id$=overflow-menu-icon]',
	lnkViewDetailsCss: '.bx--overflow-menu-options__option li button',
	lnkCredntialsActionCss: 'carbon-icon[id^=carbon-data-table-simple-]',
	btnEditCss: '.btn button',
	buttonEditAccountDetailsCss: "carbon-button button",
	buttonSaveAccountDetailsCss: ".buttons-wrap button",
	textEditSuccessMsgCss: ".bx--inline-notification__text-wrapper",
	dropdownTeamValueCss: '#bx--dropdown-multi-parent_team button',
	//btnRemoveTeamXpath: '//span[contains(text(),"my_org")]/../carbon-icon | //span[contains(text(),"TEAM1")]/../carbon-icon',
	btnRemoveTeamXpath: '/span[contains(text(),"my_org")]/../carbon-icon | //span[contains(text(),"MYORG")]/../carbon-icon',
	btnSaveXpath: '//button[text()="Update"]',
	btnEditXpath: '//button[contains(text(),"Edit")]',
	dropdownTeamCss: '[for^="bx--dropdown-item-team-"]',
	buttonAddAccountIcamXpath: '//button[contains(.," New Asset Account ")]',
	IcamProvideButtonXpath: "//*[@class='bx--tile bx--tile--clickable']//span[contains(text(),'Terraform Automation')]",
	ProviderAccountNameXpath: "//*[@id='text-input-accountName']",
	ProviderAccountDesriptionXpath: "//*[@id='text-areadescription']",
	providerAccountVersionXpath: "//*[@id='text-input-icamVersion']",
	providerAccountTeamXpath: "//*[@id='text-input-icpTeam']",
	ProviderAccountIcamEndpointXpath: "//*[@id='text-areaicamEndpoint']",
	providerAccountCloudpackEndpointXpath: "//*[@id='text-input-icpEndpoint']",
	providerAccountTenantIdXpath: "//*[@id='text-input-tenantId']",
	ProviderAccountProxyXpath: "//*[@id='text-input-proxy']",
	providerAccountMcmpFlagXpath: "//*[@id='text-areaMCMP']",
	icamCreateAccountButtonXpath: '//button[contains(.,"Create Account")]',
	notificationMsgXpath: "//span[contains(.,'Success:')]",
	addCredentialsXpath: '//button[contains(.,"Add Credential")]',
	credAccountNameXpath: "//*[@id='text-input-credentialName']",
	CredAccountPurposeXpath: '//button[contains(.,"Select credential purpose")]',
	ProvisionPurposeXpath: "(//*[@class='bx--checkbox-label'])[1]",
	catalogIngetionPurposeXpath: "(//*[@class='bx--checkbox-label'])[2]",
	CredAccountUsernameXpath: "//*[@id='text-input-username']",
	CreateNewUpdateCredentialinVaultXpath: "#checkbox-addValueInVault",
	CredAccountPasswordXpath: "//*[@id='text-input-password']",
	TeamOrgCheckboxXpath: "div.context-table > div:nth-child(2) > div.bx--col-xs-5 > carbon-checkbox > div",
	ChooseBusinessEntityTeamXpath: '(//button[contains(text(),"Choose Entity")])[1]',
	SelectEntityTeamXpath: "//*[@id='dropdown-option_entity_team']",
	TeamValuesXpath: "//*[@id='bx--dropdown-multi-parent_team']",
	EnterTeamValueXpath: "//*[@id='bx--dropdown-multi-parent_team']//input[@placeholder='Search']",
	CheckBoxIcamTeamXpath: '//label[contains(.," ICAMteam ")]',
	AddCredButtonXpath: '//button[(contains(.,"Add"))and(@class="bx--btn bx--btn--primary")]',
	ThreeDotProviderAccountNameCss: "#carbon-deluxe-data-table-tableAccountsList-parent-row-1-overflow-menu-icon",
	deleteButtonXpath: "//li//button[contains(text(),'Delete')]",
	deleteConfirmButtonXpath: "//carbon-button//button[contains(text(),' Delete')]",
	credentialRefIDValueXpath: "//*[@placeholder='Enter Credential Reference ID']",
	credentialNameListXpath: "//*[@class='bx--list-box__menu-item']//div[1]",
	providerAccountSearchCss: "#data-table-search__input",
	deleteYesConfirmXpath:"//*[contains(text(),'Delete Account?')]"

};

function accounts(selectorConfig) {
	if (!(this instanceof accounts)) {
		return new accounts(selectorConfig);
	}
	extend(this, defaultConfig);

	if (selectorConfig) {
		extend(this, selectorConfig);
	}
}

accounts.prototype.isPresentAccountsLink = function () {
	return element(by.xpath(this.accountLinkTextXpath)).isPresent();
};

//Accounts pageObject's Actions
accounts.prototype.open = function () {
	var catalogPage = new CatalogPage();
	util.switchToDefault();
	catalogPage.clickHamburgerCatalog();
	catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonAdmin);
	catalogPage.checkIfleftNavAdminExpanded();
	catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkProviderAccount);
	util.waitForAngular();
};

accounts.prototype.getTextPageHeader = function () {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.textPageHeaderCss))), 60000);
	return element(by.css(this.textPageHeaderCss)).getText().then(function (text) {
		logger.info("Page header is: " + text);
		return text;
	});
};

//Amazon
accounts.prototype.clickAmazonAddAccount = function () {

};

//VRA
accounts.prototype.clickVRAAddAccount = function () {

};

//SoftLayer
accounts.prototype.clickSoftLayerAddAccount = function () {

};

accounts.prototype.clickAccountLink = function () {
	browser.wait(EC.visibilityOf(element(by.xpath(this.accountLinkTextXpath))), 5000);
	return element(by.xpath(this.accountLinkTextXpath)).click().then(function () {
		logger.info("Clicked on Account link.");
	});
};

//************Click Add Button**********//
accounts.prototype.clickButtonAddAccount = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.buttonAddAccountXpath))), 5000);
	return element(by.xpath(this.buttonAddAccountXpath)).click();
}
//************Add Accounts Section For Different Providers*************//
accounts.prototype.getIndexofBluePrintAccount = function (blueprintAccountName) {
	browser.wait(EC.elementToBeClickable(element(by.css(this.bluePrintAccountTitleCss))), 5000);
	return element.all(by.css(this.bluePrintAccountTitleCss)).getText().then(function (arr) {
		console.log("Got all the elemets. Going to find the index of " + blueprintAccountName);
		for (var i = 0; i < arr.length; i++) {
			console.log("Comparing " + arr[i] + " with " + blueprintAccountName);
			if (arr[i] == blueprintAccountName) {
				return i;
			}
		}
	})
};

accounts.prototype.clickSelectButtonBasedOnAccountName = function (blueprintAccountName) {
	var current = this;
	return this.getIndexofBluePrintAccount(blueprintAccountName).then(function (index) {
		element.all(by.css(current.buttonSelectAddAccountCss)).get(index).click();
		console.log("Clicked select button for" + blueprintAccountName)
	})
};

//*********Common functions to all Providers***********//
accounts.prototype.getTextAddANewAccount = function () {
	return element(by.css(this.titleAddANewAccountCss)).getText().then(function (text) {
		console.log(text);
		return text;
	})
};

accounts.prototype.getTextProviderName = function () {
	return element(by.css(this.subtitleProviderNameCss)).getAttribute("value").then(function (text) {
		console.log(text);
		return text;
	})
};

//**************Add Account for VRA Provider****************//
accounts.prototype.getTextCredentialsDetails = function () {
	return element(by.css(this.titleForCredentialsCss)).getText().then(function (text) {
		console.log(text);
		return text;
	})
};

accounts.prototype.getIndexofFormInputs = function (inputDetail) {
	browser.wait(EC.elementToBeClickable(element(by.css(this.formInputDetailsCss))), 5000);
	return element.all(by.css(this.formInputDetailsCss)).getText().then(function (arr) {
		console.log("Got all the elements. Going to find the index of " + inputDetail);
		for (var i = 0; i < arr.length; i++) {
			console.log("Comparing " + arr[i] + " with " + inputDetail);
			if (arr[i] == blueprintName) {
				return i;
			}
		}
	})
};

accounts.prototype.setTextFormDetailsBasedOnInput = function (inputDetail) {
	return element(by.xpath('//label[contains(text(),"' + inputDetail + '")]')).sendKeys("Test " + inputDetail).then(function () {
		logger.info("Entered text : " + inputDetail);
	});
};

accounts.prototype.checkShowHideCheckBox = function (inputDetail) {
	return element(by.xpath('//label[contains(text(),"' + inputDetail + '")]//input[@type = "checkbox"]')).click().then(function () {
		logger.info("Clicked on Show/Hide Checkbox");
	});
};

accounts.prototype.selectAccountType = function (inputDetail) {
	return element(by.xpath('//label[contains(text(),"' + inputDetail + '")]//input[@type = "radio"]')).click().then(function () {
		logger.info("CLicked on account type");
	});
};

//**************Check accounts list for dynamic filters on Inventory Page****************//
accounts.prototype.checkIfAccountExists = function (providerName) {
	var elem = element(by.xpath('//*[contains(text(), "' + providerName + ' MASTER ACCOUNTS")]'));
	return elem.isPresent().then(function (present) {
		console.log(providerName + " isPresent: " + present)
		return present
	})
};

accounts.prototype.clickAssetAccountsLink = function (accountName) {

	util.waitForAngular();
	browser.sleep(5000);
	var elem = element(by.cssContainingText(this.linkMasterAssetAccountsCss, "Asset Accounts"));
	browser.wait(EC.elementToBeClickable(elem), 10000);
	elem.click().then(function () {
		logger.info("Clicked on Asset Accounts link");
	}).catch(function (err) {
		browser.sleep(10000);
		elem.click();
	});
};

accounts.prototype.searchAccount = function (accountName) {

	var elemSearch = element(by.css(this.txtSearchProviderAccountCss));
	browser.wait(EC.elementToBeClickable(elemSearch), 60000);
	return elemSearch.sendKeys(accountName).then(function () {
		browser.sleep(2000);
		util.waitForAngular();
		//browser.actions().sendKeys(protractor.Key.ENTER).perform();
		elemSearch.sendKeys(protractor.Key.ENTER);
		browser.sleep(3000);
		util.waitForAngular();
		//Validate provider account is displayed
		var prvdrAcnt = element(by.xpath("//*[text() = ' " + accountName + " ']"));
		browser.wait(EC.visibilityOf(prvdrAcnt), 90000);
	});


};

accounts.prototype.clickViewDetailsofAccount = function () {
	util.waitForAngular();
	var elemActionBtn = element(by.css(this.lnkActionCss));
	browser.wait(EC.elementToBeClickable(elemActionBtn), 90000);
	elemActionBtn.click().then(function () {
		logger.info("Clicked on Action button for account");
		util.waitForAngular();
	});
	var elemViewDetails = element(by.css(this.lnkViewDetailsCss));
	browser.wait(EC.elementToBeClickable(elemViewDetails), 20000);
	elemViewDetails.click().then(function () {
		logger.info("Clicked on View Details of account");
		util.waitForAngular();
	});

	var elemActionBtnCreds = element(by.css(this.lnkCredntialsActionCss));
	browser.wait(EC.elementToBeClickable(elemActionBtnCreds), 20000);
	elemActionBtnCreds.click().then(function () {
		logger.info("Clicked on Action button for credentials");
		util.waitForAngular();
	});

	browser.wait(EC.elementToBeClickable(elemViewDetails), 20000);
	return elemViewDetails.click().then(function () {
		logger.info("Clicked on View Details of credentials");
		util.waitForAngular();
	});

};

accounts.prototype.clickAccountViewDetails = function () {

	var elemActionBtn = element(by.css(this.lnkActionCss));
	browser.wait(EC.elementToBeClickable(elemActionBtn), 20000);
	elemActionBtn.click().then(function () {
		logger.info("Clicked on Action button for account");
		util.waitForAngular();
	});
	var elemViewDetails = element(by.css(this.lnkViewDetailsCss));
	browser.wait(EC.elementToBeClickable(elemViewDetails), 20000);
	elemViewDetails.click().then(function () {
		logger.info("Clicked on View Details of account");
		util.waitForAngular();
	});
};

accounts.prototype.clickEditAccountDetailsButton = function () {
	util.waitForAngular();
	var Editbtn = element.all(by.css(this.buttonEditAccountDetailsCss)).first();
	browser.wait(EC.elementToBeClickable(Editbtn), 20000);
	return Editbtn.click().then(function () {
		logger.info("Clicked on Account details edit button");
	});
};

accounts.prototype.enterEndpointUrlVRATextbox = function (url) {
	var UrlTextbox = element(by.css(this.textboxEndpointUrlVRACss));
	browser.wait(EC.visibilityOf(UrlTextbox), 20000);
	UrlTextbox.clear().then(function () {
		return UrlTextbox.sendKeys(url).then(function () {
			logger.info("Entered endpoint url for VRA");
		})
	});
};

accounts.prototype.clickSaveAccountDetailsButton = function () {
	var Savebtn = element(by.css(this.buttonSaveAccountDetailsCss));
	browser.wait(EC.visibilityOf(Savebtn), 20000);
	return Savebtn.click().then(function () {
		logger.info("Clicked on Save button of Account details");
		util.waitForAngular();
	});
};

accounts.prototype.getEditSuccessMsgText = function () {
	var SuccessText = element(by.css(this.textEditSuccessMsgCss));
	browser.wait(EC.visibilityOf(SuccessText), 20000);
	return SuccessText.getText().then(function (message) {
		logger.info("Edit Success message: " + message);
		return message;
	});
};

accounts.prototype.clickEdit = function () {
	util.waitForAngular();
	//	browser.ignoreSynchronization = true;
	browser.sleep(10000);
	var Editbtn = element.all(by.xpath(this.btnEditXpath));
	browser.wait(EC.elementToBeClickable(Editbtn.get(1)), 90000).then(function () {
		logger.info("Edit button is clickable");
	}).catch(function () {
		logger.info("Element is not clickable")
	});
	return Editbtn.get(1).click().then(function () {
		logger.info("Clicked on Edit button of credentials");
		//util.waitForAngular();
	}).catch(function (err) {
		util.waitForLoader();
		browser.executeScript("arguments[0].click();", Editbtn.get(1).getWebElement());

	});
};


accounts.prototype.selectTeam = function (team) {

	util.waitForAngular();
	util.waitForLoader();
	browser.sleep(8000);
	//browser.ignoreSynchronization = false;
	var elemToClick = element(by.css(this.dropdownTeamValueCss));
	var srchBox = element.all(by.css(this.txtSearchProviderAccountCss)).get(0)
	browser.executeScript("arguments[0].scrollIntoView(true);", elemToClick);
	browser.wait(EC.elementToBeClickable(elemToClick), 90000);

	//Remove selected team
	browser.sleep(3000);
	element(by.xpath(this.btnRemoveTeamXpath)).isPresent().then(function (result) {
		if (result) {
			element(by.xpath(defaultConfig.btnRemoveTeamXpath)).click().then(function () {
				util.waitForAngular();
				logger.info("Removed existing team");
			});
		}
		else {
			logger.info("No existing team present");
		}
	});

	browser.sleep(3000);
	//elemToClick.click().then(function (){
	return elemToClick.click().then(function () {
		logger.info("Clicked on Team dropdown");
		util.waitForAngular();
		browser.sleep(3000);
		srchBox.sendKeys(team);
		srchBox.sendKeys(protractor.Key.ENTER);
		util.waitForAngular();
		browser.sleep(5000);
		var dropDownValuesChkBox = element.all(by.css(defaultConfig.dropdownTeamCss));
		dropDownValuesChkBox.getText().then(function (values) {
			var index = values.indexOf(team);
			browser.wait(EC.elementToBeClickable(dropDownValuesChkBox.get(index)), 50000).then(function () {
				browser.executeScript("arguments[0].scrollIntoView(true);", dropDownValuesChkBox.get(index));
				dropDownValuesChkBox.get(index).click().then(function () {
					logger.info("Team is selected : " + team);
					util.waitForAngular();
					//elemToClick.click();
				});
			});
		});
	});

};

accounts.prototype.clickSave = function () {
	var Editbtn = element(by.xpath(this.btnSaveXpath));
	browser.wait(EC.elementToBeClickable(Editbtn), 20000);
	return Editbtn.click().then(function () {
		logger.info("Clicked on Save button.");
		util.waitForAngular();
	});
};

accounts.prototype.updateTeam = function (providerAccount, team) {
	var self = this;
	this.open();
	this.clickAssetAccountsLink();
	this.searchAccount(providerAccount);
	this.clickViewDetailsofAccount();
	this.clickEdit().then(function () {
		self.selectTeam(team);
		return self.clickSave();
	});


};

accounts.prototype.editAccountDetails = function (providerAccount) {
	this.open();
	this.clickAssetAccountsLink();
	this.searchAccount(providerAccount);
	this.clickAccountViewDetails();
	this.clickEditAccountDetailsButton();
};

accounts.prototype.clickButtonAddAccountIcam = function () {
	waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.buttonAddAccountIcamXpath))), 12000);
	return element(by.xpath(this.buttonAddAccountIcamXpath)).click().then(function () {
		logger.info("click on Add account button");
	})
}
accounts.prototype.clickOnIcamAccount = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.IcamProvideButtonXpath))), 12000);
	return element(by.xpath(this.IcamProvideButtonXpath)).click().then(function () {
		logger.info("click on Add IcamAccount button");
	})
}
accounts.prototype.enterProviderAccountName = function (ProviderAccountNameUser) {
	var curr = this;
	browser.wait(EC.visibilityOf(element(by.xpath(curr.ProviderAccountNameXpath))), 13000).then(function () {
		return element(by.xpath(curr.ProviderAccountNameXpath)).sendKeys(ProviderAccountNameUser).then(function () {
			logger.info("Entered Provider Account Name : " + ProviderAccountNameUser);
		});
	});
};
//Description	
accounts.prototype.enterProviderAccountDesription = function (providerAccountDesriptionIcam) {
	var curr = this;
	browser.wait(EC.visibilityOf(element(by.xpath(curr.ProviderAccountDesriptionXpath))), 10000).then(function () {
		return element(by.xpath(curr.ProviderAccountDesriptionXpath)).sendKeys(providerAccountDesriptionIcam).then(function () {
			logger.info("Entered ProviderAccountDesriptionIcam : " + providerAccountDesriptionIcam);
		});
	});
};
//IcamVerssion	
accounts.prototype.enterproviderAccountVersion = function (providerAccountVersionIcam) {
	var curr = this;
	browser.wait(EC.visibilityOf(element(by.xpath(curr.providerAccountVersionXpath))), 10000).then(function () {
		return element(by.xpath(curr.providerAccountVersionXpath)).sendKeys(providerAccountVersionIcam).then(function () {
			logger.info("Entered providerAccountVersionIcam : " + providerAccountVersionIcam);
		});
	});
};
//providerAccountTeam	
accounts.prototype.enterproviderAccountTeam = function (providerAccountTeamIcam) {
	var curr = this;
	browser.wait(EC.visibilityOf(element(by.xpath(curr.providerAccountTeamXpath))), 10000).then(function () {
		return element(by.xpath(curr.providerAccountTeamXpath)).sendKeys(providerAccountTeamIcam).then(function () {
			logger.info("Entered providerAccountTeamIcam : " + providerAccountTeamIcam);
		});
	});
};
//ProviderAccountIcamEndpoint	
accounts.prototype.enterProviderAccountIcamEndpoint = function (providerAccountIcamEndpointIcam) {
	var curr = this;
	browser.wait(EC.visibilityOf(element(by.xpath(curr.ProviderAccountIcamEndpointXpath))), 10000).then(function () {
		return element(by.xpath(curr.ProviderAccountIcamEndpointXpath)).sendKeys(providerAccountIcamEndpointIcam).then(function () {
			logger.info("Entered ProviderAccountIcamEndpointIcam : " + providerAccountIcamEndpointIcam);
		});
	});
};
//providerAccountIcpEndpoint	
accounts.prototype.enterproviderAccountIcpEndpoint = function (providerAccountIcpEndpointIcam) {
	var curr = this;
	browser.wait(EC.visibilityOf(element(by.xpath(curr.providerAccountCloudpackEndpointXpath))), 10000).then(function () {
		return element(by.xpath(curr.providerAccountCloudpackEndpointXpath)).sendKeys(providerAccountIcpEndpointIcam).then(function () {
			logger.info("Entered providerAccountIcpEndpointIcam : " + providerAccountIcpEndpointIcam);
		});
	});
};
//providerAccountTenantId	
accounts.prototype.enterproviderAccountTenantId = function (providerAccountTenantIdIcam) {
	var curr = this;
	browser.wait(EC.visibilityOf(element(by.xpath(curr.providerAccountTenantIdXpath))), 10000).then(function () {
		return element(by.xpath(curr.providerAccountTenantIdXpath)).sendKeys(providerAccountTenantIdIcam).then(function () {
			logger.info("Entered providerAccountTenantId : " + providerAccountTenantIdIcam);
		});
	});
};
//ProviderAccountProxy	
accounts.prototype.enterProviderAccountProxy = function (providerAccountProxyIcam) {
	var curr = this;
	browser.wait(EC.visibilityOf(element(by.xpath(curr.ProviderAccountProxyXpath))), 10000).then(function () {
		return element(by.xpath(curr.ProviderAccountProxyXpath)).sendKeys(providerAccountProxyIcam).then(function () {
			logger.info("Entered ProviderAccountProxy : " + providerAccountProxyIcam);
		});
	});
};
//providerAccountMcmpFlag	
accounts.prototype.enterproviderAccountMcmpFlag = function (providerAccountMcmpFlagIcam) {
	var curr = this;
	browser.wait(EC.visibilityOf(element(by.xpath(curr.providerAccountMcmpFlagXpath))), 10000).then(function () {
		return element(by.xpath(curr.providerAccountMcmpFlagXpath)).sendKeys(providerAccountMcmpFlagIcam).then(function () {
			logger.info("Entered providerAccountMcmpFlagIcam : " + providerAccountMcmpFlagIcam);
		});
	});
};
//CreateAssetAccountButton	
accounts.prototype.clickOnCreateAssetAccountButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.icamCreateAccountButtonXpath))), 5000);
	return element(by.xpath(this.icamCreateAccountButtonXpath)).click().then(function () {
		logger.info("Click on Create AssetAccount Button");
	});
}
accounts.prototype.getTextSuccessAssetAccount = function () {
	browser.ignoreSynchronization = true;
	browser.wait(EC.visibilityOf(element(by.xpath(this.notificationMsgXpath))), 22000);
	return element(by.xpath(this.notificationMsgXpath)).getText().then(function (textSuccessMsg) {
		logger.info("Notification success message text : " + textSuccessMsg);
		return textSuccessMsg;
	});
};
//AddCredentials	
accounts.prototype.clickOnAddCredentials = function () {
	waitForAngular();
	var scrollToEle = element(by.xpath(this.addCredentialsXpath));
	util.scrollToWebElement(scrollToEle);
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.addCredentialsXpath))), 9000);
	return element(by.xpath(this.addCredentialsXpath)).click().then(function () {
		logger.info("click On AddCredentials button");
	});
}
//CredAccountNameIcam	
accounts.prototype.enterCredAccountName = function (CredAccountNameIcam) {
	var curr = this;
	browser.wait(EC.visibilityOf(element(by.xpath(curr.credAccountNameXpath))), 10000).then(function () {
		return element(by.xpath(curr.credAccountNameXpath)).sendKeys(CredAccountNameIcam).then(function () {
			logger.info("Entered CredAccountName :" + CredAccountNameIcam);
		});
	});
};
//CredAccountPurpose	
accounts.prototype.clickOnCredAccountPurpose = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.CredAccountPurposeXpath))), 5000);
	return element(by.xpath(this.CredAccountPurposeXpath)).click().then(function () {
		logger.info("click On Cred AccountPurpose");
	});
}
//provisoning purpose	
accounts.prototype.clickOnProvision = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.ProvisionPurposeXpath))), 5000);
	return element(by.xpath(this.ProvisionPurposeXpath)).click().then(function () {
		logger.info("click On Provision purpose");
	});
}
//catalogIngetionPurpose	
accounts.prototype.clickOnCatalogIngetionPurpose = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.catalogIngetionPurposeXpath))), 5000);
	return element(by.xpath(this.catalogIngetionPurposeXpath)).click().then(function () {
		logger.info("click On catalog Ingetion purpose");
	});
}
//	
accounts.prototype.enterCredAccountUserName = function (CredAccountUserName) {
	var curr = this;
	browser.wait(EC.visibilityOf(element(by.xpath(curr.CredAccountUsernameXpath))), 10000).then(function () {
		return element(by.xpath(curr.CredAccountUsernameXpath)).sendKeys(CredAccountUserName).then(function () {
			logger.info("Entered CredAccountUserName" + CredAccountUserName);
		});
	});
};
//CreateNewUpdateCredentialinVault	
accounts.prototype.clickCreateNewUpdateCredentialinVault = function (credsNameText) {
	var curr = this;
	waitForAngular();
	var scrollToEle = element(by.xpath(curr.credentialRefIDValueXpath));
	util.scrollToWebElement(scrollToEle);

	browser.wait(EC.elementToBeClickable(element(by.xpath(curr.credentialRefIDValueXpath))), 12000);
	return element(by.xpath(curr.credentialRefIDValueXpath)).click().then(function () {
		element(by.xpath(curr.credentialRefIDValueXpath)).sendKeys(credsNameText).then(function () {
			browser.wait(EC.elementToBeClickable(element(by.xpath(curr.credentialNameListXpath))), 12000);
			return element(by.xpath(curr.credentialNameListXpath)).click();
		})
		logger.info("clicked on Credential Reference ID input and entered value... ");

	});

	// browser.wait(EC.elementToBeClickable(element(by.css(this.CreateNewUpdateCredentialinVaultXpath))), 12000);	
	// return element(by.css(this.CreateNewUpdateCredentialinVaultXpath)).click().then(function(){	
	// 	logger.info("click On Create New or Update Credential in Vault ");	
	// });	
}
//password	
accounts.prototype.enterCredAccountPassword = function (CredAccountPasswordIcam) {
	var curr = this;
	var scrollToEle = element(by.xpath(curr.CredAccountPasswordXpath));
	util.scrollToWebElement(scrollToEle);
	waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(curr.CredAccountPasswordXpath))), 10000).then(function () {
		return element(by.xpath(curr.CredAccountPasswordXpath)).sendKeys(CredAccountPasswordIcam).then(function () {
			logger.info("Entered CredAccountUserName");
		});
	});
	waitForAngular();
};
//TeamOrgCheckbox	
accounts.prototype.clickTeamOrgCheckbox = function () {
	waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.TeamOrgCheckboxXpath))), 12000);
	return element(by.css(this.TeamOrgCheckboxXpath)).click().then(function () {
		logger.info("clicked TeamOrg Checkbox");
	});
}
//ChooseBusinessEntityTeam	
accounts.prototype.clickChooseBusinessEntityTeam = function () {
	waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.ChooseBusinessEntityTeamXpath))), 12000);
	return element(by.xpath(this.ChooseBusinessEntityTeamXpath)).click().then(function () {
		logger.info("click Choose Business Entity Team");
	});
}
//SelectEntityTeam	
accounts.prototype.clickSelectEntityTeam = function () {
	waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.SelectEntityTeamXpath))), 12000);
	return element(by.xpath(this.SelectEntityTeamXpath)).click().then(function () {
		logger.info("click Select Entity Team");
	});
}
//TeamValues	
accounts.prototype.clickTeamValues = function () {
	var curr = this;
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.TeamValuesXpath))), 12000);
	return element(by.xpath(this.TeamValuesXpath)).click().then(function () {
		logger.info("click Team Values");
	});
}
//enter ICAM team name	
accounts.prototype.enterTeamValueIcam = function (TeamValueIcam) {
	var curr = this;
	browser.wait(EC.visibilityOf(element(by.xpath(curr.EnterTeamValueXpath))), 10000).then(function () {
		element(by.xpath(curr.EnterTeamValueXpath)).sendKeys(TeamValueIcam).then(function () {
			logger.info("Entered TeamValueIcam" + TeamValueIcam);
			element(by.xpath(curr.EnterTeamValueXpath)).sendKeys(protractor.Key.ENTER);
			browser.wait(EC.visibilityOf(element(by.xpath(curr.CheckBoxIcamTeamXpath))), 50000)
			return element(by.xpath(curr.CheckBoxIcamTeamXpath)).click();
		});
	});
};
//Add credential button	
accounts.prototype.clickAddCreds = function () {
	var curr = this;
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.AddCredButtonXpath))), 12000);
	return element(by.xpath(this.AddCredButtonXpath)).click().then(function () {
		logger.info("click on add credentials button");
		waitForAngular();
	})
}
//accounts page open	
accounts.prototype.openaccountsPage = function () {
	browser.get(this.pageUrl);
	browser.sleep(50000);
	util.waitForAngular();
};
//click on ThreeDotProviderAccountName	
accounts.prototype.clickThreeDotProviderAccountName = function () {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.providerAccountSearchCss))), 50000);
	element(by.css(this.providerAccountSearchCss)).sendKeys("Terraform-Asset-Account-AutoUI").then(function () {
		logger.info("search for Terraform-Asset-Account-AutoUI account...");
	})
	browser.wait(EC.visibilityOf(element(by.css(this.ThreeDotProviderAccountNameCss))), 50000);
	element.all(by.css(this.ThreeDotProviderAccountNameCss)).click().then(function () {
		logger.info("clicked on three dots of account name");
	})

}
//click on DeleteButton	
accounts.prototype.clickDeleteButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.deleteButtonXpath))), 9000);
	return element(by.xpath(this.deleteButtonXpath)).click().then(function () {
		logger.info("click on delete button");
	})
}
//DeleteConfirmButton	
accounts.prototype.clickDeleteConfirmButton = function () {
	var eleDeleteButton = element(by.xpath(this.deleteYesConfirmXpath));
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.deleteConfirmButtonXpath))), 5000).then(function () {
	browser.wait(EC.visibilityOf(eleDeleteButton));
		logger.info("Delete confirmation box is visible now ....");
	})
	return element(by.xpath(this.deleteConfirmButtonXpath)).click().then(function () {
		logger.info("clicked on delete confirmation button");
	})

}


module.exports = accounts;
