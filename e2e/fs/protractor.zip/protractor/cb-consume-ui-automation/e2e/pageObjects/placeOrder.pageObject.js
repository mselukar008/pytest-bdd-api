"use strict";

var extend = require('extend');
var url = browser.params.url;
var EC = protractor.ExpectedConditions;
var util = require('../../helpers/util.js');
var logGenerator = require("../../helpers/logGenerator.js"),
	logger = logGenerator.getApplicationLogger();

var defaultConfig = {
    //Main Parameters
    serviceNameTextBoxCss:          		'#text-input-main_params-serviceName',
    serviceCIDR:                            '#text-inputVpcCIDR',
    //topRightCancelButtonCss:                '[id^=button-cancel-button]',
	topRightCancelButtonCss:                '[id^=cancel-button-mainParams]',
    providerTextCss:              			'#text-input-main_params-provider',
    categoryTxtCss:							'#text-input-main_params-category',
    estimatedPriceTxtCss:       		 	'.estimated-cost~p',
    buttonTextCancel:						'Cancel',
    buttonTextConfirmCancelCss:             'Yes',
     textNextButtonXpath:                		'.//div/button[contains(text(),"Next")]',
    nextButtonXpath:                         '//button[contains(@id,"next-button")]' ,
    txtNextBtnCss:                          '[title="Next"]',
    orderId:								'#order-number',
    //parameterWarningTextXpath :                '//div[contains(.," Please input \'Service Name\' in proper format") and @class="bx--form-requirement"]',
    parameterWarningTextCss :               'div.bx--form-requirement',
    bluePrintNameTextCss:					'.description>p',
    //bluePrintNameTextCss:                   '#service-progress_blueprint-name',
    buttonCloseParamterWarningCss:			'.bx--inline-notification__close-button',
    dropdownTeamXpath:                      '//*[@id="bx--dropdown-single-parent_team"]',
    dropdownEnvICAMXpath:                   '//*[@id="env"]//button', 
    dropdownEnvXpath: 			'//*[@id="Env" or @id="env"]/div',
    valuesEnvXpath:                         '//*[@id="env"]//ul//li',
    dropdownAppCss:                         '[id="bx--dropdown-single-parent_app"]',
    dropdownAppXpath:                       '//*[@id="App" or @id="app"]//button',
    valuesAppXpath:                         '//*[@id="App" or @id="app"]//ul//li',    
    dropdownProviderAccountXpath:           '//*[@id="bx--dropdown-single-parent_provider-account"]',
    textboxQunatityCss:                     'input#slider-input-box-main-params_multi-quantity',
    //Additional Parameters
    buttonTextPrevious:		 				'Previous',
    currentStepProgressSection:				'.bx--progress-step--current p',
    RootDiskSizeCss:                       '#text-input-vm_1_root_disk_size',                                
    VirtualmachineIPCss:                   '#text-input-vm_1_ipv4_address',
    dynamicErrorrootdisksizeCss:           ".bx--form-requirement", 
    dynamicErrorvirtualmachineipCss:       "#text-input-vm_1_ipv4_address + div",   
    editCurrentBOMButtonCss: '[data-tab-id="current_bom"]',
    editFieldTagCss:                        'ibm-tag[class*="bx--tag--blue"]',                     
    //Review Order
    providerNameTextReviewOrderPageXpath:				    '//span[contains(text(), "Provider Name")]/following-sibling::span',
    vmNameTextReviewOrderPageXpath:				            '//span[contains(text(), "VM Name")]/following-sibling::span',
    serviceNameTextReviewOrderPageXpath:				    '//span[contains(text(), "Service Instance")]/following-sibling::span', 
    categoryNameTextReviewOrderPageXpath:				    '//span[contains(text(), "Category Name")]/following-sibling::span',
    estimatedPriceReviewOrderPageXpath:					    '//span[contains(text(), "Estimated Price")]/following-sibling::span',
    //estimatedCostsReviewOrderPageXpath:					'//*[contains(text(), "Estimated Costs")]//p ',//.estimated-cost ~ p
    estimatedCostsReviewOrderPageCss:					    '.bx--side-nav__item.bx--side-nav__item--total span:nth-child(2) strong',
    additionalDetailsTextReviewOrderPageXpath:              '//span[contains(text(), "App server")]/following-sibling::span ',
    buttonTextSubmitOrder:								    'Submit Order',
    //submitOrderCss:                                         '#button-quickPurchaseSubmit-button-reviewOrder',
    submitOrderCss:                                         'button[id$="primary-btn-review-order"]',    
    buttonTextAddToCart:								    'Add to Cart',
    serviceDetailsCss:                                      'div > div.order-review-title.push--2 > span',
    additionalDetailsCss:                                   'div > display-configs > div.order-review-title.push--2 > span',
    breadcrumbMainParameterCss:                             'carbon-progress-indicator-item:nth-child(1) > li > p',
    breadcrumbResourceGroupCss:                             'carbon-progress-indicator-item:nth-child(2)',
    breadcrumbServiceNameCss:                               'carbon-progress-indicator-item:nth-child(3)',
    breadcrumbReviewOrderCss:                               'carbon-progress-indicator-item:nth-child(4)',

    //Cancel Order Popup:
    buttonYesCancelOrderPopupCss 	:					    'button[id$="order-cancel-modal_carbon-button_yes"]',
    buttonNoCancelOrderPopupCss     :					    'button[id$="order-cancel-modal_carbon-button_no"]',
    buttonCloseCancelOrderPopupCss	:					    'button[id$="order-cancel-modal"]',

    //Order Submission Popup
    orderSubmittedHeaderXpath:							    '//h2[contains(text(),"Order Submitted !")]',
    goToServiceCatalogCss:								    '#order-submitted-modal_carbon-button',
   // orderSubmittedModalHeaderXpath:							'//*[contains(text(),"Order Submitted")]',
    orderSubmittedModalHeaderXpath:					'//*[contains(text(),"Order Submitted")] | //*[contains(text(),"Order Request Initiated")]',
    orderSubmittedModalGoToServiceCatalogCss:				'#order-submitted-modal_carbon-button',
    orderSubmittedModalGoToInventoryCss:				    '#order-submitted-modal_carbon-button',
    orderSubmittedModalOrderNumberTextCss :					'[id$="order-number"],#order-submitted-number',
    orderSubmittedModalOrderDateTextXpath   :				'//p[contains(text(),"Date")]/span',
    orderSubmittedModalTotalPriceTextXpath  :				'//p[contains(text()," Total")]/span',
    orderSubmittedModalSubmittedByTextXpath :				'//p[contains(text()," Submitted by")]/span',
    orderSubmittedModalCartNameTextXpath  :				    '//p[contains(text(),"Cart Name")]/span',

    detailsPageTextXpath : 					                './/*[@id="service-details__service-name"]',

    errorMessageServicenameAlreadyExists    :               './/*[@id="same-service_error"]',
    errorMsgEditServiceCss :                              '.bx--toast-notification__subtitle span',
    errorMsgCloseBtnXpath :                                 '(//button[@class="bx--toast-notification__close-button"])',

    firewallTypeId   :                                      'firewalltype_value',
    totalCostValueId :                                      'div[class="total-cost-value"]',
    
    //Locators for shopping cart in place order page
    addNewServicesRadioButtonCss:							'radio-button-shoppingOptions_Add_service to new cart',
    addServicesToExistingCartRadioButtonCss:				'radio-button-shoppingOptions_Add_service to existing cart',
    quickPurchaseRadioButtonCss:							'radio-button-shoppingOptions_Quick_purchase',
    cartNameTextboxCss:										'text-input-main_params-cartName',
    cartIconXpath: 											'//*[@class="cart-icon"]',
    oneTimeChargesBOMTableXpath:                            '//tr//td[@class="data-number"]',
    moreLinkText:                                           'More',
    moreLinkXpath:                                           '//*[contains(text(),"More")]',
    lessLinkText:                                           'Less',
    totalQuntityBOMTableCss:                              '.bom-list-table tbody tr span',
    descriptionXpath : 					    '//*[@id="description"]',
    totalMonthlyChargeXpath : 				    '//*[@id="non-one-time-charge"]',
    dynamicErrorTextXpath:                  '//div[contains(text(), "already")]',
    textServiceOfferingNameCss:             '#carbon-deluxe-data-table-tableOrderServiceDetails td:nth-child(2) span',
	btnImiCss:'.provider',
	btnNextImiConfigCss:'#place-order-next-button',
	btnSaveImiConfigCss:'#button-place-order-save-button',
	txtImiOrderSubmittedModalXpath:         '//h2[contains(text(),"Configure IMI Managed Service")]',
    chkboxAddToCartCss:'input[name="useShoppingCart"]~label',
    //icam custom operation
    errorPopupForStartOnStart:'//div[contains(text()," Start action cannot be performed in On status. ")]',
    errorPopupForStopOnStop :'//div[contains(text()," Stop action cannot be performed in Off status. ")]',
    dropdownNamesapceXpath:   '//*[@id="ICAM_Namespace"]/div//button',
    valuesNamesapceXpath:     '//*[@id="ICAM_Namespace"]//ul//li',
    mutipleCostItemsCss:           'li[class="bx--side-nav__item"] span strong',
    expandTheCartItemsTabCss:    '#cart-items>button',
    btnSubmitOrderConfCss: '#submit-cart-order-confirmation-modal-carbon-button_submit',

    // ICAM/TA regex scenario locators
    sshkeyValueCss:"#text-areapublic_ssh_key",
    sshKeyNamecss:"#text-input-public_ssh_key_name",
    sshKeyErrorXpath:"//*[@class='bx--form-requirement required']",
    regexparamCustomTemplateCss: "#text-input-Regex_param",
    randomclickCss: "#additional-params_dynamic-form",
    regexParamCustomGetTextCss : "#additional-params_dynamic-form > form > form-textfield:nth-child(7) > div > carbon-text-input > div > div.bx--form-requirement",

    //pricing parameters
    CPUValueCss : "#text-input-CPU",
    RAMValueCss : "#text-input-RAM",
    DiskValueCss : "#text-input-Disk",
    pricingErrorMessageCss : "#configsNotValid_carbon-notification > div > div > p.bx--inline-notification__subtitle",


    // ICAM invisible param list
    sharedParamAwsDataLabelCss:"#aws-data > div > div > label",
    userPasswordLabelCss :"#additional-params_dynamic-form > form > form-password > div > carbon-text-input > div > label",
    sampleHiddenParamLabelCss:"#additional-params_dynamic-form > form > form-textfield:nth-child(6) > div > carbon-text-input > div > label",
    txtCompListXpath : "//li[@class='bx--side-nav__item']",
    txtCompName : "//*[@class='bx--side-nav__item']/span",
    txtCompPrice : "//*[@class='bx--side-nav__item']//span/strong",
	
};

function placeOrder(selectorConfig) {
    if (!(this instanceof placeOrder)) {
        return new placeOrder(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

//-----Function to get Blue print name on All 3 pages, Main parameters , Additional Parameters and Review Order
placeOrder.prototype.getTextBluePrintName = function() {
    browser.wait(EC.visibilityOf(element(by.css(this.bluePrintNameTextCss))),15000);
    return element(by.css(this.bluePrintNameTextCss)).getText().then(function(text){
        logger.info("Blue Print Name : "+text);
        return text;
    });
};

placeOrder.prototype.servicenameAlreadyExists = function()
{
    return browser.wait(EC.visibilityOf(element(by.xpath('.//*[@id="same-service_error"]'))),15000);
    logger.info("Service name already exists");

    };

//----Function to cancel Order on All 3 pages, Main parameters , Additional Parameters and Review Order
placeOrder.prototype.cancelOrder = function()
{
    element(by.buttonText(this.buttonTextCancel)).click();
    util.waitForAngular();
};

placeOrder.prototype.isNextButtonEnabled = function(){
	 util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.txtNextBtnCss))), 60000);
	return element(by.css(this.txtNextBtnCss)).isEnabled().then(function(isEnabled){
		logger.info("Is Next button enabled: "+isEnabled);
		return isEnabled;
	});
};

//-----Function to click on next Button in Main parameters and Additional Parameters
placeOrder.prototype.clickNextButton = function(){
    util.waitForAngular();
    var ele = element(by.css(this.txtNextBtnCss));
    if (this.isNextButtonEnabled()){
    ele.click().then(function(){
    	logger.info("Clicked on Next button");
    }).catch(function (err) {
        logger.info("unable to click next button..clicking again");
        browser.executeScript("arguments[0].click();", ele.getWebElement()); 
        logger.info("Clicked on Next button again");
    });
  };
};

//--------Function to click on previous button on 2 pages Additional Parameters and Review Order
placeOrder.prototype.clickPreviousButton = function()
{
	browser.wait(EC.visibilityOf(element(by.buttonText(this.buttonTextPrevious))), 15000);
	element(by.buttonText(this.buttonTextPrevious)).click().then(function(){
        logger.info("Clicked on Previous button");
    })
	
    util.waitForAngular();
};

//***********************************FUNCTIONS FOR CANCEL ORDER POPUP*******************************
placeOrder.prototype.clickYesInCancelOrderPopup = function()
{
    element(by.css(this.buttonYesCancelOrderPopupCss)).click();
    util.waitForAngular();
};

placeOrder.prototype.clickNoInCancelOrderPopup = function()
{
    element(by.css(this.buttonNoCancelOrderPopupCss)).click();
    util.waitForAngular();
};

placeOrder.prototype.closeCancelOrderPopup = function()
{
    element(by.css(this.buttonCloseCancelOrderPopupCss)).click();
    util.waitForAngular();
}

//***************************Functions for Main Parameters***********************************************************

//----Function to set Service Name
placeOrder.prototype.setServiceNameText = function (serviceName) {
    //browser.ignoreSynchronization = false;
    browser.wait(EC.visibilityOf(element(by.css(this.serviceNameTextBoxCss))), 25000);
    element(by.css(this.serviceNameTextBoxCss)).clear();
    element(by.css(this.serviceNameTextBoxCss)).sendKeys(serviceName).then(function () {
        logger.info("ServiceName " + serviceName + " entered");
    });

    //Selecting Team option
   // var elemTeam = element(by.css("#radio-button-team_TEAM1"));
    var elemTeam = element(by.css("#radio-button-team_Auto-TEAM1"));
    browser.wait(EC.elementToBeClickable(elemTeam), 60000);
    browser.executeScript("arguments[0].click();", elemTeam.getWebElement()).then(function () {
        logger.info("Team is Selected.| TEAM1");
    });   

    util.waitForAngular();
    browser.sleep(5000);
    var dropdownboxEnv = element(by.xpath(defaultConfig.dropdownEnvXpath));
    browser.wait(EC.elementToBeClickable(dropdownboxEnv), 90000).then(function () {
        browser.executeScript("arguments[0].scrollIntoView();", dropdownboxEnv.getWebElement());
        dropdownboxEnv.click().then(function () {
            util.waitForAngular();
            browser.sleep(5000);
            var dropDownValuesArray = element.all(by.xpath(defaultConfig.valuesEnvXpath));
            dropDownValuesArray.getText().then(function (textArray) {
                var isDropDownValuePresent = false;
                for (var i = 0; i < textArray.length; i++) {
                    if (textArray[i] == "NONE") {
                        dropDownValuesArray.get(i).click().then(function () {
                            logger.info("Selected Environment as NONE");

                        });
                        isDropDownValuePresent = true;
                    }
                }
                if (!isDropDownValuePresent) {
                    dropDownValuesArray.get(0).getText().then(function (text) {
                        dropDownValuesArray.get(0).click().then(function () {
                            logger.info("Selected Environment as NONE");
                        })
                    });
                }
            });
        });
    });

    var dropdownbox = element(by.xpath(this.dropdownAppXpath));
    util.waitForAngular();
    browser.sleep(5000);
    browser.wait(EC.elementToBeClickable(dropdownbox), 90000).then(function () {
        browser.executeScript("arguments[0].scrollIntoView();", dropdownbox.getWebElement());
        dropdownbox.click().then(function () {
            browser.sleep(1000);
            util.waitForAngular();
            var dropDownValuesArray = element.all(by.xpath(defaultConfig.valuesAppXpath));
            dropDownValuesArray.getText().then(function (textArray) {
                var isDropDownValuePresent = false;
                for (var i = 0; i < textArray.length; i++) {
                    if (textArray[i] == "NONE") {
                        dropDownValuesArray.get(i).click().then(function () {
                            logger.info("Selected Application as NONE");

                        });
                        isDropDownValuePresent = true;
                    }
                }
                if (!isDropDownValuePresent) {
                    dropDownValuesArray.get(0).getText().then(function (text) {
                        dropDownValuesArray.get(0).click().then(function () {
                            logger.info("Selected Application as NONE");
                        })
                    });
                }
            });
        });

    });
    return serviceName;
};


placeOrder.prototype.selectProviderAccount = function(providerAccount) {

    var elemProviderAccount = element(by.css("input[value='" + providerAccount + "']"));
    browser.wait(EC.elementToBeClickable(elemProviderAccount), 60000);
    browser.executeScript("arguments[0].scrollIntoView();", elemProviderAccount.getWebElement());
    browser.executeScript("arguments[0].click();", elemProviderAccount.getWebElement()).then(function () {
        logger.info("Provider Account Selected as " + providerAccount);
        util.waitForAngular();
    });
};

placeOrder.prototype.selectAddNewServiceCartRadioButton = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.addNewServicesRadioButtonCss))),5000);
	element(by.css(this.addNewServicesRadioButtonCss)).click().then(function(){
		logger.info("Clicked on Add new Services to cart radio button...");
	});
}

placeOrder.prototype.provideCartName = function(cartName) {
	browser.wait(EC.visibilityOf(element(by.css(this.cartNameTextboxCss))),5000);
	element(by.css(this.cartNameTextboxCss)).sendKeys(cartName).then(function(){
		logger.info("Entered cart name as "+cartName);
	});
}

placeOrder.prototype.addToShoppingCart = function() {
    var self = this;
	browser.wait(EC.visibilityOf(element(by.buttonText(this.buttonTextAddToCart))),60000);
    return element(by.buttonText(this.buttonTextAddToCart)).click().then(function(){
    	util.waitForAngular();
    	logger.info("Navigating to Shopping cart page...")
    	browser.sleep(20000);
        //Exapnd cart items
        // browser.wait(EC.visibilityOf(element(by.css(self.expandTheCartItemsTabCss))), 90000);
        // element(by.css(self.expandTheCartItemsTabCss)).click().then(function(){
        //     logger.info("Expanded cart items");
        // });
    });
}

placeOrder.prototype.searchCartFromList = function (cartName) {
	  return  element(by.xpath("//*[@title='" + cartName + "']"))

	};

placeOrder.prototype.clickServiceName = function()
{
    return element(by.css(this.serviceNameTextBoxCss)).click().then(function(){
        logger.info("clicked Service Name");
    });
};

placeOrder.prototype.clickCartIcon = function () {
    browser.wait(EC.elementToBeClickable(element(by.xpath(this.cartIconXpath))), 10000);
    return element(by.xpath(this.cartIconXpath)).click().then(function () {
   	 logger.info("clicked on Cart icon");
    });;
};

//----Function to set Additional attributes
placeOrder.prototype.getcurrentStepProgressSection = function(){
	return element(by.css(this.currentStepProgressSection)).getText().then(function(text){
		logger.info("Current step progress section is: "+text);
		return text;
	});
};

//----Function to get Provider Text
placeOrder.prototype.getTextProvider = function()
{
    return element(by.css(this.providerTextCss)).getAttribute("value").then(function(providerText){
        logger.info("The value of provider in Main Params is : " + providerText)
        return providerText;
    });
};

placeOrder.prototype.clickProvider = function()
{
    return element(by.css(this.providerTextCss)).click().then(function(){
        logger.info("clicked provider");
    });
};

//Click cancel button present at the top right corner of main,additional n review order page
placeOrder.prototype.clickRightTopCancelButtonInAllPages = function()
{
	browser.wait(EC.elementToBeClickable(element(by.css(this.topRightCancelButtonCss))), 10000);
	element(by.css(this.topRightCancelButtonCss)).click().then(function(){
		logger.info("Clicked on cancel button present at the top right corner");
	});
}

placeOrder.prototype.clickOkToCancel = function(){
	browser.wait(EC.visibilityOf(element(by.buttonText(this.buttonTextConfirmCancelCss))),25000);
    return element(by.buttonText(this.buttonTextConfirmCancelCss)).click().then(function(){
	logger.info("Clicked on cancel confirmation popup");
	util.waitForAngular();
});
}	

//-----Function to get Category
placeOrder.prototype.getTextCategory = function()
{
    return element(by.css(this.categoryTxtCss)).getAttribute("value").then(function(categoryText){
        logger.info("The value of category in Main Params is :" + categoryText)
        return categoryText;
    });
};

//-----Function to get Estimated Price
placeOrder.prototype.getTextEstimatedPrice = function()
{
    return element(by.css(this.estimatedPriceTxtCss)).getText().then(function(estimatedPrice){
        logger.info("The estimated price in Main Params is :" + estimatedPrice)
        return estimatedPrice;
    });
};

placeOrder.prototype.getTextEstimatedPriceForSnow = function()
{
    return element(by.css(this.estimatedPriceTxtCss)).getText().then(function(estimatedPrice){
        logger.info("The estimated price in Main Params is :" + estimatedPrice);
        var str = estimatedPrice.toString().split('+')[1];
    	var str1 = str.split('.')[0];
    	var estiMatedPriceNumeric = str1.match(/\d/g).join("");
    	estiMatedPriceNumeric = parseInt(estiMatedPriceNumeric);
    	logger.info("The estimated estiMatedPriceNumeric :" + estiMatedPriceNumeric);
        return estiMatedPriceNumeric;
    });
};


//----Function to click next button without service name
placeOrder.prototype.getWarningTextByClickingNextWithOurServicename = function() {
    return element(by.css(this.parameterWarningTextCss)).getText().then(function(text){
        logger.info(text)
        return text;
    });
};

//------Function to close the warning appeared when clicked without service name
placeOrder.prototype.closeParameterWarning = function() {
    return element(by.css(this.buttonCloseParamterWarningCss)).click();
}

placeOrder.prototype.isPresentcloseParameterWarningMessage = function() {
    return element(by.css(this.buttonCloseParamterWarningCss)).isPresent();
}

//*****************************Functions for Additional Parameters***********************************************************

placeOrder.prototype.setRegexRootdisksizeText = function(randomrootdisk)
{
    browser.wait(EC.visibilityOf(element(by.css(this.RootDiskSizeCss))),25000);
    element(by.css(this.RootDiskSizeCss)).clear();
    element(by.css(this.RootDiskSizeCss)).sendKeys(randomrootdisk).then(function(){
    	logger.info(" RegexRootdisksize "+randomrootdisk+" entered");    	
    });
    return randomrootdisk;
}

placeOrder.prototype.setRegexvirtualmachineipText = function(randomipaddress)
{
    browser.wait(EC.visibilityOf(element(by.css(this.VirtualmachineIPCss))),25000);
    element(by.css(this.VirtualmachineIPCss)).clear();
    element(by.css(this.VirtualmachineIPCss)).sendKeys(randomipaddress).then(function(){
    	logger.info(" RegexVirtualMachineIP "+randomipaddress+" entered");    	
    });
    return randomipaddress;
}

placeOrder.prototype.selectValueFromDropdownBasedonLabelName_AdditionalParamaters = function(labelID,value) {
    var elem = element(by.css("[id='"+labelID+"']"));
    browser.wait(EC.elementToBeClickable(elem), 5000);
    return elem.click().then(function(){
        var dropDownValuesArray = element.all(by.xpath("//*[@id='"+labelID+"']//carbon-dropdown-option//li"));
        dropDownValuesArray.getText().then(function(textArray){
            var isDropDownValuePresent = false;
            for (var i=0;i<textArray.length;i++){
                if (textArray[i] == value){
                    dropDownValuesArray.get(i).click();
                    isDropDownValuePresent =true;
                }
            }
            if(!isDropDownValuePresent)
            dropDownValuesArray.get(0).click();
        });
    });
}

placeOrder.prototype.selectRadioButtonBasedonLabelName_AdditionalParamaters = function(labelID,value) {
    var elem = element(by.css("[id=\""+labelID+"\"] ~ label span"));
    browser.wait(EC.presenceOf(elem), 5000);
    return elem.click().then(function(){
        logger.info("Selected "+value+" radio button.");
    });
}

placeOrder.prototype.enterValueForAdditionalParamatersBasedOnLabelName = function(labelID,value) {
    element(by.xpath("//*[@id='"+labelID+"']")).clear();
    return element(by.xpath("//*[@id='"+labelID+"']")).sendKeys(value);
}

placeOrder.prototype.selectValuesFromMultiSelectDropDown = function(labelID,value) {
    var elem = element(by.css("[id=\""+labelID+"\"]"));
    element.all(by.css("[type='checkbox']")).then(function(options) {
        options.forEach(function(option) {
            option.getText().then(function(text) {
                if (text.indexOf(value) != -1) {
                    return option.click();
                } 
            });
        });
    });
}

placeOrder.prototype.getTextFromTextBoxInAdditionalParametersBasedOnLabelName = function(labelID){
    return element(by.xpath("//*[@id='"+labelID+"']")).getAttribute('value')
}

placeOrder.prototype.getValuesFromDropDpwnInAdditionalParametersBasedOnLabelName = function(labelID){
    return element(by.xpath("//*[@id='"+labelID+"']/li")).getText().then(function(text){
        logger.info("Value is "+text);
        return text;
    })
}

placeOrder.prototype.isAttributePresentInAdditionalParametersPage = function(labelName){
	return element(by.xpath("//label[contains(text(), '" + labelName + "')]")).isPresent();
}
																  				
placeOrder.prototype.completeAdditionalAttributes = function(dropdownAttributes){

    for (var size=0;size <dropdownAttributes.dropdownLabels.length ; size++ ){
        this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(dropdownAttributes.dropdownLabels[size].dropdownLabelId, dropdownAttributes.dropdownLabels[size].value);
    }
    for (var sizeText=0;sizeText < dropdownAttributes.textinputdetails.length ; sizeText++ ){
        this.enterValueForAdditionalParamatersBasedOnLabelName(dropdownAttributes.textinputdetails[sizeText].textinputDetailsId, dropdownAttributes.textinputdetails[sizeText].value);
    }
}
//*****************************Functions for Review Order ***********************************************************

//Service Detail Section
placeOrder.prototype.getTextProviderName_ReviewOrder = function() {
	browser.wait(EC.visibilityOf(element(by.xpath(this.providerNameTextReviewOrderPageXpath))), 10000);
    return element(by.xpath(this.providerNameTextReviewOrderPageXpath)).getText().then(function(text){
        logger.info("Provider Name on Review Order page : "+text)
        return text;
    });
};

placeOrder.prototype.getTextServiceName_ReviewOrder = function() {
    util.waitForAngular();
    browser.sleep(3000);  
    browser.wait(EC.visibilityOf(element(by.xpath(this.serviceNameTextReviewOrderPageXpath))), 10000);
    return element(by.xpath(this.serviceNameTextReviewOrderPageXpath)).getText().then(function(text){
        logger.info("Service Name on Review Order page : "+text)
        return text;
    });
};

placeOrder.prototype.getTextVmName_ReviewOrder = function() {
	browser.wait(EC.visibilityOf(element(by.xpath(this.vmNameTextReviewOrderPageXpath))), 10000);
    return element(by.xpath(this.vmNameTextReviewOrderPageXpath)).getText().then(function(text){
        logger.info("Service Name on Review Order page : "+text)
        return text;
    });
};

placeOrder.prototype.getTextCategoryName_ReviewOrder = function() {
	browser.wait(EC.visibilityOf(element(by.xpath(this.categoryNameTextReviewOrderPageXpath))), 10000);
    return element(by.xpath(this.categoryNameTextReviewOrderPageXpath)).getText().then(function(text){
        logger.info("Category Name on Review Order page : "+text)
        return text;
    });
};

placeOrder.prototype.getEstimatedPrice_ReviewOrder = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.estimatedCostsReviewOrderPageCss))), 10000);
    return element(by.css(this.estimatedCostsReviewOrderPageCss)).getText().then(function(text){
        logger.info("Estimated price on Review Order page : "+text)
        return text;
    });
};

//Additional Detail Section
//TODO: Some pages changed to use spans instead of labels. The getTextBasedOnLabelName function was changed
// to make these work, but some element still us labels and this breaks them. There is a getTextBasedOnLabelName1 in
// orders.pageObject that can be used. Once those are all fixed we need to change the getTextBasedOnLabelName
// to getTextBasedOnSpanName.


placeOrder.prototype.getTextAdditonalDetails_ReviewOrder = function(labelName){
	return element(by.xpath("//span[contains(text(), '"+labelName+"')]/following-sibling::span")).getText().then(function(text){
        logger.info("The value for "+labelName+" is : "+text)
        return text;
    });
};

placeOrder.prototype.getTextBasedOnSpanName = function(labelName){
    return element(by.xpath("//span[contains(text(), '" + labelName + "')]/following-sibling::span")).getText().then(function(text){
        logger.info("The value for "+labelName+" is : "+text)
        return text;
    });
};

placeOrder.prototype.getTextBasedOnLabelName = function(labelName){
    if (labelName.includes(':')) {
        labelName = labelName.replace(':', '');
    };
    labelName = " " + labelName.trim() + " ";
    return element(by.xpath("//span[text()='" + labelName + "']/following-sibling::span")).getText().then(function(text){
        logger.info("The value for "+labelName+" is : "+text)
        return text;
    });
};

placeOrder.prototype.getFirewall = function(){
    return element(by.id(this.firewallTypeId)).getAttribute("value").then(function(text){
    logger.info("The value for the firewall type  is : " + text);
    return text;
    });
};

placeOrder.prototype.getTotalCost = function(){
    return element(by.css(this.totalCostValueId)).getText("value").then(function(text){
        logger.info("The value for the total cost is : " + text);
        return text;
    });
};



//Estimated Costs Section

placeOrder.prototype.getEstimatedCost_ReviewOrder = function(){
    return element(by.css(this.estimatedCostsReviewOrderPageCss)).getText().then(function(text){
        logger.info("Estimated cost on Review Order page : "+text)
        return text;
    });
};

//Function for submitting the order
placeOrder.prototype.submitOrder = function() {
    var self = this ;
	browser.wait(EC.elementToBeClickable(element(by.css(this.submitOrderCss))),60000);
    return element(by.css(this.submitOrderCss)).click().then(function(){
    	logger.info("Clicked on submit Order");
    	//util.waitForAngular();
    	//browser.sleep(3000);
    }).catch(function(err){
        browser.wait(EC.elementToBeClickable(element(by.css(self.submitOrderCss))),90000);
        logger.info("Submit button is not clickable within 60s....clicking again");
       return element(by.css(self.submitOrderCss)).click().then(function(){
            logger.info("Clicked on submit Order in 2nd attempt");
           // util.waitForAngular();
        });
    });
}

//*********************************Functions for ICD custom operation***********************************
placeOrder.prototype.submitOrderCustomOpsICD = function() {
	browser.wait(EC.visibilityOf(element(by.buttonText(this.buttonTextSubmitOrder))),25000);
    return element(by.buttonText(this.buttonTextSubmitOrder)).click().then(function(){
    	logger.info("Clicked on submit Order");
    	util.waitForAngular();
    });
}

//*********************************End of functions for ICD custom operation****************************

placeOrder.prototype.EditsubmitOrder = function() {
	browser.wait(EC.visibilityOf(element(by.buttonText(this.buttonTextSubmitOrder))),25000);
    return element(by.buttonText(this.buttonTextSubmitOrder)).click().then(function(){
    	logger.info("Clicked on submit order");
    	browser.sleep(6000);
    	
    });
}

placeOrder.prototype.getTextEditOrderErrorMsg = function() {
	//browser.ignoreSynchronization = true;
	browser.wait(EC.visibilityOf(element(by.css(this.errorMsgEditServiceCss))),90000).then(function(){
       		logger.info("Waiting for error message") 
	    }).catch(function(err){
		logger.info("Error message for negative edit scenario not generated within 2 min");
	    });
	return element(by.css(this.errorMsgEditServiceCss)).getText().then(function(error) {
		logger.info("Error message without editing and clicking on Submit is " + error);
		return error;
	});
};

placeOrder.prototype.clickOnNotificationCloseButton = function() {
	//browser.ignoreSynchronization = true;
	browser.wait(EC.visibilityOf(element(by.xpath(this.errorMsgCloseBtnXpath))),90000).then(function(){
        	logger.info("Waiting for error message") 
	}).catch(function(err){
         	logger.info("Error message for negative edit scenario not generated within 2 min");
        });
	element(by.xpath(this.errorMsgCloseBtnXpath)).click().then(function(){
		logger.info("Clicked on Notification close Button");
	});	
}

//****************FUNCTIONS IN ORDER SUBMITTED POP UP***************************
placeOrder.prototype.clickgoToServiceCatalogButtonOrderSubmittedModal = function() {
    return element(by.css(this.orderSubmittedModalGoToServiceCatalogCss)).click().then(function(){        
        util.waitForAngular().then(function(){
            logger.info("Clicked on Go to Service catalog button");
        });
    });
};

placeOrder.prototype.getTextOrderSubmittedHeaderOrderSubmittedModal = function() {
	//util.waitForAngular();
	//browser.sleep(2000);
	browser.wait(EC.visibilityOf(element(by.xpath(this.orderSubmittedModalHeaderXpath))),125000);
    return element(by.xpath(this.orderSubmittedModalHeaderXpath)).getText().then(function(text){
	logger.info(text)
	return text;
    });
};

placeOrder.prototype.getTextOrderNumberOrderSubmittedModal = function()
{
    browser.wait(EC.visibilityOf(element(by.css(this.orderSubmittedModalOrderNumberTextCss))), 190000);
    return element(by.css(this.orderSubmittedModalOrderNumberTextCss)).getText().then(function(text){
        logger.info("Order number : "+text);
        return text;
    });
};

placeOrder.prototype.getTextOrderedDateOrderSubmittedModal = function()
{
    return element(by.xpath(this.orderSubmittedModalOrderDateTextXpath)).getText().then(function(text){
        logger.info("Ordered Date : "+text);
        return text;
    });
};

placeOrder.prototype.getTextTotalPriceOrderSubmittedModal = function()
{
	browser.wait(EC.visibilityOf(element(by.xpath(this.orderSubmittedModalTotalPriceTextXpath))),25000);
	return element(by.xpath(this.orderSubmittedModalTotalPriceTextXpath)).getText().then(function(text){
		logger.info("Total Price : "+text);
		return text;		
	});
};

placeOrder.prototype.getTextSubmittedByOrderSubmittedModal = function()
{
    return element(by.xpath(this.orderSubmittedModalSubmittedByTextXpath)).getText().then(function(text){
        logger.info("Submitted By : "+text);
        return text;
    });
};

placeOrder.prototype.getTextCartNameOrderSubmittedModal = function()
{
	browser.wait(EC.visibilityOf(element(by.xpath(this.orderSubmittedModalCartNameTextXpath))),25000);
	return element(by.xpath(this.orderSubmittedModalCartNameTextXpath)).getText().then(function(cartName){
		logger.info("Cart Name : "+cartName);
		return cartName;		
	});
};

placeOrder.prototype.checkIfInDetailsPage = function()
{
	return element(by.xpath(this.detailsPageTextXpath)).isDisplayed()
};

placeOrder.prototype.clickgoToInventoryButtonOrderSubmittedModal = function() {
    return element(by.css(this.orderSubmittedModalGoToInventoryCss)).click();
};

placeOrder.prototype.createSLVirtualMachineOrderWithDefaultParameters = function(slVMObject, servicename){
    this.setServiceNameText(servicename);
    this.clickNextButton();
    //Instance Details Parameters
    var hostNameIndex = util.getTextInputLabelIndexBasedOnName(slVMObject,"Hostname");
    var domainIndex = util.getTextInputLabelIndexBasedOnName(slVMObject,"Domain");
    var dedicatedAccountFlagIndex = util.getRadioButtonLabelIndexBasedOnName(slVMObject,"Dedicated Account Flag");
    var billingTypeIndex = util.getRadioButtonLabelIndexBasedOnName(slVMObject,"Billing Type");
    var dataCenterIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Datacenter");
    this.enterValueForAdditionalParamatersBasedOnLabelName(slVMObject.textinputdetails[hostNameIndex].textinputDetailsId, slVMObject.textinputdetails[hostNameIndex].value);
    this.enterValueForAdditionalParamatersBasedOnLabelName(slVMObject.textinputdetails[domainIndex].textinputDetailsId, slVMObject.textinputdetails[domainIndex].value);
    this.selectRadioButtonBasedonLabelName_AdditionalParamaters(slVMObject.radioButtonLabels[dedicatedAccountFlagIndex].radioButtonId,slVMObject.radioButtonLabels[dedicatedAccountFlagIndex].value);
    this.selectRadioButtonBasedonLabelName_AdditionalParamaters(slVMObject.radioButtonLabels[billingTypeIndex].radioButtonId,slVMObject.radioButtonLabels[billingTypeIndex].value);
    this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[dataCenterIndex].dropdownLabelId, slVMObject.dropdownLabels[dataCenterIndex].value);
    this.clickNextButton();
    //System Specification Parameters
	var operatingSystemIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Operating System");
	var memoryIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Memory");
	var coresIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Cores");		
	this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[operatingSystemIndex].dropdownLabelId, slVMObject.dropdownLabels[operatingSystemIndex].value);
	this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[coresIndex].dropdownLabelId, slVMObject.dropdownLabels[coresIndex].value);
	this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[memoryIndex].dropdownLabelId, slVMObject.dropdownLabels[memoryIndex].value);
	this.clickNextButton();
	//Disk Details Parameters
	var diskTypeIndex = util.getRadioButtonLabelIndexBasedOnName(slVMObject,"Disk Type");
	var firstDiskIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "First Disk");
	this.selectRadioButtonBasedonLabelName_AdditionalParamaters(slVMObject.radioButtonLabels[diskTypeIndex].radioButtonId,slVMObject.radioButtonLabels[diskTypeIndex].value);
	this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[firstDiskIndex].dropdownLabelId, slVMObject.dropdownLabels[firstDiskIndex].value);
	this.clickNextButton();
	//Network Details Parameters
	//var privateVlanIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Private Vlan Id");
	//var privateSubnetIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Private Subnet");
	var networkTypeIndex = util.getRadioButtonLabelIndexBasedOnName(slVMObject,"Network Type");
	var networkSpeedIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Network Speed");
	var bandwidthUnlimitedIndex = util.getRadioButtonLabelIndexBasedOnName(slVMObject,"Bandwidth Unlimited");
	var bandwidthLimitedIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Bandwidth Limited");
	//var publicVlanIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Public Vlan Id");
	//var publicSubnetIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Public Subnet");
	//this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[privateVlanIndex].dropdownLabelId, slVMObject.dropdownLabels[privateVlanIndex].value);
	//this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[privateSubnetIndex].dropdownLabelId, slVMObject.dropdownLabels[privateSubnetIndex].value);
	this.selectRadioButtonBasedonLabelName_AdditionalParamaters(slVMObject.radioButtonLabels[networkTypeIndex].radioButtonId,slVMObject.radioButtonLabels[networkTypeIndex].value);
	this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[networkSpeedIndex].dropdownLabelId, slVMObject.dropdownLabels[networkSpeedIndex].value);
	this.selectRadioButtonBasedonLabelName_AdditionalParamaters(slVMObject.radioButtonLabels[bandwidthUnlimitedIndex].radioButtonId,slVMObject.radioButtonLabels[bandwidthUnlimitedIndex].value);
	this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[bandwidthLimitedIndex].dropdownLabelId, slVMObject.dropdownLabels[bandwidthLimitedIndex].value);
	//this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[publicVlanIndex].dropdownLabelId, slVMObject.dropdownLabels[publicVlanIndex].value);
	//this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[publicSubnetIndex].dropdownLabelId, slVMObject.dropdownLabels[publicSubnetIndex].value);
	this.clickNextButton();
	//Add-ons Parameters
//	var publicSecondaryIPIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Public Secondary IP Addresses");
//	var privateIpV6Index = util.getRadioButtonLabelIndexBasedOnName(slVMObject,"Primary IPv6 Addresses");
//	var publicIpv6Index = util.getRadioButtonLabelIndexBasedOnName(slVMObject,"Public Static IPv6 Addresses");
//	this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[publicSecondaryIPIndex].dropdownLabelId, slVMObject.dropdownLabels[publicSecondaryIPIndex].value);
//	this.selectRadioButtonBasedonLabelName_AdditionalParamaters(slVMObject.radioButtonLabels[privateIpV6Index].radioButtonId,slVMObject.radioButtonLabels[privateIpV6Index].value);
//	this.selectRadioButtonBasedonLabelName_AdditionalParamaters(slVMObject.radioButtonLabels[publicIpv6Index].radioButtonId,slVMObject.radioButtonLabels[publicIpv6Index].value);
	this.clickNextButton();
	//Other Details Parameters - not mondatory, hence not adding into order.
	this.clickNextButton();
};

placeOrder.prototype.setServiceNameTextSL = function(serviceName)
{
    browser.wait(EC.elementToBeClickable(element(by.css("[id='bx--dropdown-single-parent_team:']"))), 10000);
    element(by.xpath("//*[@id='bx--dropdown-single-parent_team:']")).click();
    //these is a temporary change as of now from naveen
    var teamsArray = element.all(by.xpath("//*[@id='bx--dropdown-single-parent_team:']//carbon-dropdown-option//li"));
    teamsArray.getText().then(function(textArray){
        var isTEAM1Present = false;
        //logger.info(teamsArray.getText());
        for (var i=0;i<textArray.length;i++){
            if (textArray[i] == "TEAM1"){
                teamsArray.get(i).click();
                isTEAM1Present =true;
            }
        }
        // if(!isTEAM1Present)
        //     teamsArray.get(0).click();
    })
    logger.info("Team selected from drop down");
    browser.wait(EC.visibilityOf(element(by.css(this.serviceNameTextBoxCss))),5000);
    element(by.css(this.serviceNameTextBoxCss)).clear();
    element(by.css(this.serviceNameTextBoxCss)).sendKeys(serviceName);
    logger.info("ServiceName entered");
    /* element(by.xpath("//*[@id='bx--dropdown-single-parent_team:'] //a[text()[normalize-space()='TEAM1']]")).click();
    browser.wait(EC.elementToBeClickable(element(by.css("[id='bx--dropdown-single-parent_application:']"))), 5000);
    element(by.xpath("//*[@id='bx--dropdown-single-parent_application:']")).click();
    element(by.xpath("//*[@id='bx--dropdown-single-parent_application:'] //a[text()[normalize-space()='app_all']]")).click();
    browser.wait(EC.elementToBeClickable(element(by.css("[id='bx--dropdown-single-parent_environment:']"))), 5000);
    element(by.xpath("//*[@id='bx--dropdown-single-parent_environment:']")).click();
    element(by.xpath("//*[@id='bx--dropdown-single-parent_environment:'] //a[text()[normalize-space()='env_all']]")).click();*/
    return serviceName;
};

placeOrder.prototype.createSLVirtualMachineOrderWithOnlyInstanceDetailsParameters = function(slVMObject, servicename){

    //Instance Details Parameters
    var hostNameIndex = util.getTextInputLabelIndexBasedOnName(slVMObject,"Hostname");
    var domainIndex = util.getTextInputLabelIndexBasedOnName(slVMObject,"Domain");
    var dedicatedAccountFlagIndex = util.getDropDownLabelIndexBasedOnName(slVMObject,"Dedicated Account Flag");
    var billingTypeIndex = util.getDropDownLabelIndexBasedOnName(slVMObject,"Billing Type");
    var dataCenterIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Datacenter");
    this.enterValueForAdditionalParamatersBasedOnLabelName(slVMObject.textinputdetails[hostNameIndex].textinputDetailsId, slVMObject.textinputdetails[hostNameIndex].value);
    this.enterValueForAdditionalParamatersBasedOnLabelName(slVMObject.textinputdetails[domainIndex].textinputDetailsId, slVMObject.textinputdetails[domainIndex].value);
    this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[dedicatedAccountFlagIndex].dropdownLabelId,slVMObject.dropdownLabels[dedicatedAccountFlagIndex].value);
    this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[billingTypeIndex].dropdownLabelId,slVMObject.dropdownLabels[billingTypeIndex].value);
    this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[dataCenterIndex].dropdownLabelId, slVMObject.dropdownLabels[dataCenterIndex].value);
    this.clickNextButton();
    //System Specification Parameters
    var operatingSystemIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Operating System");
    var memoryIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Memory");
    var coresIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Cores");
    this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[operatingSystemIndex].dropdownLabelId, slVMObject.dropdownLabels[operatingSystemIndex].value);
    this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[coresIndex].dropdownLabelId, slVMObject.dropdownLabels[coresIndex].value);
    this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[memoryIndex].dropdownLabelId, slVMObject.dropdownLabels[memoryIndex].value);
    this.clickNextButton();
    //Disk Details Parameters
    var diskTypeIndex = util.getDropDownLabelIndexBasedOnName(slVMObject,"Disk Type");
    var firstDiskIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "First Disk");
    this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[diskTypeIndex].dropdownLabelId,slVMObject.dropdownLabels[diskTypeIndex].value);
    this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[firstDiskIndex].dropdownLabelId, slVMObject.dropdownLabels[firstDiskIndex].value);
    this.clickNextButton();
    //Network Details Parameters
    //var privateVlanIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Private Vlan Id");
    //var privateSubnetIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Private Subnet");
    var networkTypeIndex = util.getDropDownLabelIndexBasedOnName(slVMObject,"Network Type");
    var networkSpeedIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Network Speed");
    var bandwidthUnlimitedIndex = util.getRadioButtonLabelIndexBasedOnName(slVMObject,"Bandwidth Unlimited");
    var bandwidthLimitedIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Bandwidth Limited");
    //var publicVlanIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Public Vlan Id");
    //var publicSubnetIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Public Subnet");
    //this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[privateVlanIndex].dropdownLabelId, slVMObject.dropdownLabels[privateVlanIndex].value);
    //this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[privateSubnetIndex].dropdownLabelId, slVMObject.dropdownLabels[privateSubnetIndex].value);
    this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[networkTypeIndex].dropdownLabelId,slVMObject.dropdownLabels[networkTypeIndex].value);
    browser.sleep(2000);
    this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[networkSpeedIndex].dropdownLabelId, slVMObject.dropdownLabels[networkSpeedIndex].value);
    browser.sleep(2000);
    //this.selectRadioButtonBasedonLabelName_AdditionalParamaters(slVMObject.radioButtonLabels[bandwidthUnlimitedIndex].radioButtonId,slVMObject.radioButtonLabels[bandwidthUnlimitedIndex].value);
    //this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[bandwidthLimitedIndex].dropdownLabelId, slVMObject.dropdownLabels[bandwidthLimitedIndex].value);
    //this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[publicVlanIndex].dropdownLabelId, slVMObject.dropdownLabels[publicVlanIndex].value);
    //this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[publicSubnetIndex].dropdownLabelId, slVMObject.dropdownLabels[publicSubnetIndex].value);
    this.clickNextButton();

    //Add-ons Parameters
//	var publicSecondaryIPIndex = util.getDropDownLabelIndexBasedOnName(slVMObject, "Public Secondary IP Addresses");
//	var privateIpV6Index = util.getRadioButtonLabelIndexBasedOnName(slVMObject,"Primary IPv6 Addresses");
//	var publicIpv6Index = util.getRadioButtonLabelIndexBasedOnName(slVMObject,"Public Static IPv6 Addresses");
//	this.selectValueFromDropdownBasedonLabelName_AdditionalParamaters(slVMObject.dropdownLabels[publicSecondaryIPIndex].dropdownLabelId, slVMObject.dropdownLabels[publicSecondaryIPIndex].value);
//	this.selectRadioButtonBasedonLabelName_AdditionalParamaters(slVMObject.radioButtonLabels[privateIpV6Index].radioButtonId,slVMObject.radioButtonLabels[privateIpV6Index].value);
//	this.selectRadioButtonBasedonLabelName_AdditionalParamaters(slVMObject.radioButtonLabels[publicIpv6Index].radioButtonId,slVMObject.radioButtonLabels[publicIpv6Index].value);
    this.clickNextButton();
    //Other Details Parameters - not mondatory, hence not adding into order.
    this.clickNextButton();
};

placeOrder.prototype.setQuantity = function(quantity){
    util.waitForAngular();
    var elem = element(by.css(this.textboxQunatityCss));
    browser.wait(EC.presenceOf(elem), 60000);          
    elem.clear().then(function () {
        logger.info("Cleared Quantity textbox");
        var ctrlA = protractor.Key.chord(protractor.Key.CONTROL, "a");
        elem.sendKeys(ctrlA);
    });
    elem.sendKeys(quantity).then(function () {
        logger.info("Entered value in Quantity textbox");            
    });    
 };

placeOrder.prototype.clickMoreLink = function(){
    var moreTextXpath = element.all(by.xpath(this.moreLinkXpath)).last();
    browser.wait(EC.elementToBeClickable(moreTextXpath), 30000);
    browser.executeScript("arguments[0].scrollIntoView();", moreTextXpath.getWebElement());
    moreTextXpath.click().then(function(){
        logger.info("Clicked on more link")
    });
}

placeOrder.prototype.clickLessLink = function(){
    var lessTextCSS = element(by.linkText(this.lessLinkText));
    browser.wait(EC.elementToBeClickable(lessTextCSS), 30000);
    browser.executeScript("arguments[0].scrollIntoView();", lessTextCSS.getWebElement());
    lessTextCSS.click().then(function(){
        logger.info("Clicked on less link")
    });
}

placeOrder.prototype.isServiceDetailsPresent = function(){
    return element(by.css(this.serviceDetailsCss)).isPresent().then(function(value){
        logger.info("Are Service Details present :"+value);
        return value;
    });
}


placeOrder.prototype.isAdditionalDetailsPresent = function(){
    return element(by.css(this.additionalDetailsCss)).isPresent().then(function(value){
        logger.info("Are Additional Details present :"+value);
        return value;
    });
}

placeOrder.prototype.isMainParameterPresent = function(){
    return element(by.css(this.breadcrumbMainParameterCss)).getText().then(function(text){
		logger.info("Section name present is: "+text);
		return text;
	});
}

placeOrder.prototype.isResourceGroupPresent = function(){
    return element(by.css(this.breadcrumbResourceGroupCss)).getText().then(function(text){
		logger.info("Section name present is: "+text);
		return text;
	});
}

placeOrder.prototype.isServiceNameParameterPresent = function(){
        return element(by.css(this.breadcrumbServiceNameCss)).getText().then(function(text){
		logger.info("Section name present is: "+text);
		return text;
	});
}

placeOrder.prototype.isSubmitButtonPresent = function(){
     browser.wait(EC.elementToBeClickable(element(by.css(this.submitOrderCss))),25000);
     return element(by.css(this.submitOrderCss)).isPresent().then(function(isPresent){
		logger.info("Is Submit button enabled: "+isPresent);
		return isPresent;
	});

}

placeOrder.prototype.isScrollPresent = function(){
    var elem = element.all(by.xpath(defaultConfig.oneTimeChargesBOMTableXpath)).get(0);
    browser.actions().mouseMove(elem).perform().then(function(){
        logger.info("Scroll bar is present");
    });

}

placeOrder.prototype.isPreviousButtonPresent = function(){
    browser.wait(EC.elementToBeClickable(element(by.buttonText(this.buttonTextPrevious))),25000);
    return element(by.buttonText(this.buttonTextPrevious)).isPresent().then(function(isPresent){
       logger.info("Is Previous button enabled: "+isPresent);
       return isPresent;
   });

}

placeOrder.prototype.getEditableFieldtext = function(){
    return element(by.css(this.editFieldTagCss)).getText().then(function(text){
		logger.info("Editable fields tag is: "+text);
		return text;
	});
}

placeOrder.prototype.getBOMTablePrice = function (oneTimeCharge) {
    this.clickMoreLink();
    var total = 0;
    var cost = 0;
    return new Promise(function (resolve, reject) {
        element.all(by.xpath(defaultConfig.oneTimeChargesBOMTableXpath)).getText().then(function (elm) {
            for (var i = 0; i < elm.length; i++) {
                if(elm[i] != ""){
                    cost = parseFloat(elm[i].replace("USD ", ""));
                    total = total + cost;
                }                
            };
            logger.info("Total price of BOM table is " + total);
            resolve(total);
        }).catch(function (ex) {
            reject("Failed to calculate the pricing from BOM Table");
        });
    });

}

placeOrder.prototype.getTextUpdatedBOMTablePrice = function (componentCount,oneTimeCharge) {
    this.clickMoreLink();
    var total = 0;
    var cost = 0;
    var tblXpath = element.all(by.xpath("//table[contains(@class,'review-order_bom-table')]//tr"));
    return new Promise(function (resolve, reject) {
        tblXpath.each(function(elem, index){
            var totalMonthlyCharges = element(by.xpath("//table[contains(@class,'review-order_bom-table')]//tr[" + index + "]//td[12]"));
            return totalMonthlyCharges.getText().then(function(text){
                if(text != ""){
                    cost = parseFloat(text.replace("USD ", ""));
                    total = total + cost;
                }
            }).catch(function(err){
                logger.info("Element not Found");
            });
        });
        logger.info("Total price of BOM table On Updated BOM is " + total);
        resolve(total);
    }).catch(function (ex) {
            logger.info(ex);
            reject("Failed to calculate the pricing from Updated BOM Table");
    });

    //table[contains(@class,'review-order_bom-table')]//tr[1]//td[12]
    // return new Promise(function (resolve, reject) {
    //     //browser.wait(EC.visibilityOf(element(by.xpath(defaultConfig.oneTimeChargesBOMTableXpath))), 60000);
    //     element.all(by.xpath(defaultConfig.oneTimeChargesBOMTableXpath)).getText().then(function (elm) {
    //         for (var i = 0; i < componentCount ; i++) {
    //            if(elm[i] != ""){
    //                 cost = parseFloat(elm[i].replace("USD ", ""));
    //                 total = total + cost;
    //            }   
    //         };
    //         logger.info("Total price of BOM table On Updated BOM is " + total);
    //         resolve(total);
    //     }).catch(function (ex) {
    //          logger.info(ex);
    //          reject("Failed to calculate the pricing from Updated BOM Table");
    //     });
    // });
}

placeOrder.prototype.getTextCurrentBOMTablePrice = function (componentCount,oneTimeCharge) {
    element(by.css(this.editCurrentBOMButtonCss)).click();
    var total = 0;
    var cost = 0;
    return new Promise(function (resolve, reject) {
        element.all(by.xpath(defaultConfig.oneTimeChargesBOMTableXpath)).getText().then(function (elm) {
            for (var i = componentCount; i < elm.length ; i++) {
                if(elm[i] != ""){
                    cost = parseFloat(elm[i].replace("USD ", ""));
                    total = total + cost;
                }
            
            };
            logger.info("Total price of BOM table On Current BOM is " + total);
            resolve(total);
        }).catch(function (ex) {
            reject("Failed to calculate the pricing from Current BOM Table");
        });
    });

}

placeOrder.prototype.verifyThePricingBOMTotalQuantity = function (oneTimeCharge) {
    var quntityMatch = false;
    return new Promise(function (resolve, reject) {
        element.all(by.css(defaultConfig.totalQuntityBOMTableCss)).getText().then(function (elm) {
            for (let qunt in elm) {
                if (elm[qunt] == oneTimeCharge) {
                    quntityMatch = true
                }
            }
            resolve(quntityMatch);
        }).catch(function (ex) {
            reject("Total quntity of the pricing does not BOM matched");
        });
    })
}

placeOrder.prototype.validatePricingCustomTemplate = function () {
    
    browser.executeScript("window.scrollTo(0, 150);");    
    let promiseArr = [];
    var pricingValidn = false;
    var expOrderTotal = 0;
    var val;    
    var placeOrderPage = new placeOrder();
    this.clickMoreLink();
    util.waitForAngular();

    var itemDescription = element.all(by.xpath(this.descriptionXpath));
    var totalMonthlyCharge = element.all(by.xpath(this.totalMonthlyChargeXpath));
    itemDescription.getText().then(function (itemsList) {
        totalMonthlyCharge.getText().then(function (monthlyChargeList) {
            for (var i = 0; i < monthlyChargeList.length; i++) {     
                
                expect(monthlyChargeList[i]).not.toContain("NA");
                if (monthlyChargeList[i] != "NA") {
                    val = parseFloat(monthlyChargeList[i].split("+")[0].split("/")[0].replace("USD ", ""));
                    if (val != "0.00") {
                        logger.info("Total Monthly charges for :" + itemsList[i] + " is = " + monthlyChargeList[i]); 
                        pricingValidn = true;
                    } else {
                        logger.info("Total Monthly charges for :" + itemsList[i] + " is =  - USD 0.00");
                    }
                    promiseArr.push(pricingValidn);
                    expOrderTotal = parseFloat(expOrderTotal) + parseFloat(val);
                } else {
                    logger.info("Total Monthly charges for :" + itemsList[i] + " is =  NA");
                    promiseArr.push(false);
                }            
            }
        });

        placeOrderPage.getEstimatedPrice_ReviewOrder().then(function(estimatedCost){
            val = parseFloat(estimatedCost.split("+")[1].split("/")[0].replace("USD ", ""));
            expect(val.toFixed(4)).toEqual(expOrderTotal.toFixed(4));
            logger.info("Pricing for custom template is succesfully verified on Review order page.");
        });
                                
    });
       
    return Promise.all(promiseArr).then(function (pricingValidn) {
        if (pricingValidn.indexOf(false) != -1) {
            return Promise.resolve(false);
        } else {
            return Promise.resolve(true);
        }
    });

};
placeOrder.prototype.getDynamicTextError = function() {
    browser.wait(EC.visibilityOf(element(by.xpath(this.dynamicErrorTextXpath))), 10000);
    return element(by.xpath(this.dynamicErrorTextXpath)).getText().then(function(text){
        logger.info("Error message : "+text);
        return text;
    });
};

placeOrder.prototype.dynamicErrorrootdisksize = function() {
    browser.wait(EC.visibilityOf(element(by.css(this.dynamicErrorrootdisksizeCss))), 10000);
    return element(by.css(this.dynamicErrorrootdisksizeCss)).getText().then(function(text){
        logger.info("Error message for Regex Root disk size : "+text);
        return text;
    });
};

placeOrder.prototype.dynamicErrorvirtualmachineip = function() {
    browser.wait(EC.visibilityOf(element(by.css(this.dynamicErrorvirtualmachineipCss))), 10000);
    return element(by.css(this.dynamicErrorvirtualmachineipCss)).getText().then(function(text){
        logger.info("Error message for Regex virtual machine IP : "+text);
        return text;
    });
};

placeOrder.prototype.getServiceNameOfferingText = function() { 
    browser.wait(EC.visibilityOf(element(by.css(this.textServiceOfferingNameCss))), 20000);
    return element(by.css(this.textServiceOfferingNameCss)).getText().then(function(text){
        logger.info("Service Offering name is: "+text);
        return text;
    });
};

placeOrder.prototype.roundOffPriceAmount = function(priceAmount) { 
	var amount = Promise.resolve(priceAmount);
	return amount.then(function(value) {
		value.substring(0, value.indexOf("+"));
		var priceValue = parseFloat(value.replace("USD ", "")).toFixed(5);
		logger.info("Round off value of price: " + priceValue);
		return priceValue;
	})
};

placeOrder.prototype.clickImiBtn = function(){
    var imi = element(by.css(this.btnImiCss));
    browser.wait(EC.elementToBeClickable(imi), 30000);    
    imi.click().then(function(){
        logger.info("Clicked on IMI button");
        util.waitForAngular();
    });
}

placeOrder.prototype.clickNextBtnImiConfiguration = function(){
    util.waitForAngular();
    var nextBtn = element(by.css(this.btnNextImiConfigCss));
    browser.wait(EC.elementToBeClickable(nextBtn), 30000);    
    nextBtn.click().then(function(){
        logger.info("Clicked on Next button in IMI configuration");
        util.waitForAngular();
    });
}

placeOrder.prototype.clickSaveInImiConfiguration = function(){
    var nextBtn = element(by.css(this.btnSaveImiConfigCss));
    browser.wait(EC.elementToBeClickable(nextBtn), 30000);    
    nextBtn.click().then(function(){
        logger.info("Clicked on Next button in IMI configuration");
        util.waitForAngular();
    });
}

placeOrder.prototype.getTextBasedOnLabelNameandIndex = function(labelName, index){
    var elemList = element.all(by.xpath("//span[contains(text(), '" + labelName + "')]/following-sibling::span"));
    return elemList.getText().then(function(textArray){
        logger.info("The value for "+labelName+" is : " + textArray[index])
        return textArray[index];
    });
};

placeOrder.prototype.getTextOrderSubmittedHeaderImi = function() {
    util.waitForAngular();
	browser.sleep(5000);
	browser.wait(EC.visibilityOf(element(by.xpath(this.txtImiOrderSubmittedModalXpath))),125000);
    return element(by.xpath(this.txtImiOrderSubmittedModalXpath)).getText().then(function(text){
        logger.info(text)
        return text;
    });
};

placeOrder.prototype.setServiceName = function(serviceName){    
    browser.wait(EC.visibilityOf(element(by.css(this.serviceNameTextBoxCss))),25000);
    element(by.css(this.serviceNameTextBoxCss)).clear();
    element(by.css(this.serviceNameTextBoxCss)).sendKeys(serviceName).then(function(){
    	logger.info("ServiceName "+serviceName+" entered");    	
    });
};

placeOrder.prototype.clickCheckboxAddToCart = function(){  
    util.waitForAngular(); 
    browser.sleep(3000);
    var checkBx = element(by.css(this.chkboxAddToCartCss));
    browser.wait(EC.elementToBeClickable(checkBx),25000);    
    checkBx.click().then(function(){
        logger.info("Selected the checkbox Add to cart");
        util.waitForAngular();
    });
};

placeOrder.prototype.selectExistingCart = function(cart){   
    var cartName = element(by.xpath("//strong[contains(text(), '" + cart + "')]"));
    browser.wait(EC.elementToBeClickable(cartName),25000);    
    cartName.click().then(function(){
        logger.info("Selected the existing shopping cart "+ cart);
    });
};

placeOrder.prototype.setServiceNameTextICAM = function(serviceName)
{
    browser.wait(EC.visibilityOf(element(by.css(this.serviceNameTextBoxCss))),25000);
    element(by.css(this.serviceNameTextBoxCss)).clear();
    element(by.css(this.serviceNameTextBoxCss)).sendKeys(serviceName).then(function(){
    	logger.info("ServiceName "+serviceName+" entered");    	
    });
    
    //Selecting Team option
    var elemTeam = element(by.css("#radio-button-team_ICAMteam"));
    browser.wait(EC.elementToBeClickable(elemTeam), 60000);
    browser.executeScript("arguments[0].click();", elemTeam.getWebElement()).then(function () {
        util.waitForAngular();
        browser.sleep(2000);
        logger.info("Team is Selected.| ICAMteam");
    }); 
    
    var scrollToEle = element(by.xpath(this.valuesNamesapceXpath));
    util.scrollToWebElement(scrollToEle);
    util.waitForAngular();
    browser.sleep(5000);
      //Namespace
     //Selecting Namesapce dropdown
     browser.wait(EC.elementToBeClickable(element(by.xpath(this.dropdownNamesapceXpath))), 60000);
     element(by.xpath(this.dropdownNamesapceXpath)).click();
     var namespaceArray = element.all(by.xpath(this.valuesNamesapceXpath));
     //util.waitForAngular();
     namespaceArray.getText().then(function(textArray){
         var isNamespacePresent = false;
         for (var i=0;i<textArray.length;i++){
             if (textArray[i] == "default"){
                 namespaceArray.get(i).click().then(function(){
                     logger.info("Namespace selected from drop down");
                 });
                 isNamespacePresent =true;
             }
         }
         if(!isNamespacePresent)
             namespaceArray.get(0).click();
     });
     var scrollToEle = element(by.xpath(this.valuesAppXpath));
   util.scrollToWebElement(scrollToEle);
   util.waitForAngular();
   browser.sleep(5000);
    //Selecting Application dropdown
     browser.wait(EC.elementToBeClickable(element(by.xpath(this.dropdownAppXpath))), 60000);
     element(by.xpath(this.dropdownAppXpath)).click();
     var applicationsArray = element.all(by.xpath(this.valuesAppXpath));
     applicationsArray.getText().then(function(textArray){
         var isAppPresent = false;
         for (var i=0;i<textArray.length;i++){
             if (textArray[i] == "icamApp"){
                 applicationsArray.get(i).click().then(function(){
                     logger.info("Application selected from drop down");
                 });
                 isAppPresent =true;
             }
         }
         if(!isAppPresent)
             applicationsArray.get(0).click();
     });
     //Selecting environment dropdown
   util.waitForAngular();
   browser.sleep(3000);
   browser.wait(EC.elementToBeClickable(element(by.xpath(this.dropdownEnvICAMXpath))), 60000);
   element(by.xpath(this.dropdownEnvICAMXpath)).click();
   var envArray = element.all(by.xpath(this.valuesEnvXpath));
   //util.waitForAngular();
   envArray.getText().then(function(textArray){
       var isEnvPresent = false;
       for (var i=0;i<textArray.length;i++){
           if (textArray[i] == "icamEnv"){
               envArray.get(i).click().then(function(){
                   logger.info("Environment selected from drop down");
               });
               isEnvPresent =true;
           }
       }
       if(!isEnvPresent)
           envArray.get(0).click();
   });

   
     util.waitForAngular();
   
     
     return serviceName;
 };
 placeOrder.prototype.getBOMTablePriceOnReviewOrder = function () {
    var curr =this
    var total = 0;
    var cost = 0;
     browser.wait(EC.visibilityOf(element(by.css(curr.mutipleCostItemsCss))),25000);
      return  element.all(by.css(curr.mutipleCostItemsCss)).getText().then(function (elm) {
            for (var i = 0; i < elm.length; i++) {
                cost = parseFloat(elm[i].replace("USD ", ""));
		if (isNaN(cost) != true){
                    total = total + cost;
                }               
            };
            total = "USD "+total.toFixed(3);
            logger.info("Total price of BOM table is " + total);
            return total;
        });
};

placeOrder.prototype.validateReviewOrderPageParams = function(reviewOrderExpActParamsMap){    
        var expctdParams = Object.keys(reviewOrderExpActParamsMap["Expected"]);
        var expValue,actValue;
        for(var i = 0; i < expctdParams.length; i++){
            expValue = reviewOrderExpActParamsMap["Expected"][expctdParams[i]];
            actValue = reviewOrderExpActParamsMap["Actual"][expctdParams[i]].replace("\nUpdated", "").replace("\nNew", "")
	    if (actValue.includes("... more")) {
             	actValue = actValue.split("... more")[0];
            }
           
            if(expValue == actValue){                
                logger.info("Review Order page parametr - " + expctdParams[i] + " = " + actValue);
            }else if(expValue.includes(actValue)){
                logger.info("Review Order page parametr - " + expctdParams[i] + " = " + actValue);
            }
            else{
                logger.info("Review Order page parametr - Actual --> " + expctdParams[i] + " = " + actValue + " | Expected --> " + expctdParams[i] + " = " + expValue);
                return false;
            }        
        }
        return true;    
};

placeOrder.prototype.clickOrderSubmitConfrmnBtn = function() {
    util.waitForLoader();
    var btnSubmit  = element(by.css(this.btnSubmitOrderConfCss));
    browser.wait(EC.elementToBeClickable(btnSubmit), 90000);
    btnSubmit.click().then(function(){
        logger.info("Clicked on Submit order confirmation button.");
        util.waitForAngular();
    });
};

placeOrder.prototype.getAndSaveOrderId = function (serviceName, orderType) {
    browser.wait(EC.visibilityOf(element(by.css(this.orderSubmittedModalOrderNumberTextCss))), 190000);
    return element(by.css(this.orderSubmittedModalOrderNumberTextCss)).getText().then(async function (text) {
        logger.info("Order number : " + text);
        await util.saveOrderId(serviceName, orderType, text);
        return text;
    });
};

//Function for e2e pricing validation of TA service
placeOrder.prototype.setCPUValueText = function(CPUValue)
{
    browser.wait(EC.visibilityOf(element(by.css(this.CPUValueCss))),25000);
    element(by.css(this.CPUValueCss)).clear();
    element(by.css(this.CPUValueCss)).sendKeys(CPUValue).then(function(){
    	logger.info(" CPU value: "+CPUValue+" entered");    	
    });
}

placeOrder.prototype.setRAMValueText = function(RAMValue)
{
    browser.wait(EC.visibilityOf(element(by.css(this.RAMValueCss))),25000);
    element(by.css(this.RAMValueCss)).clear();
    element(by.css(this.RAMValueCss)).sendKeys(RAMValue).then(function(){
    	logger.info(" RAM value: "+RAMValue+" entered");    	
    });
}

placeOrder.prototype.setDiskValueText = function(DiskValue)
{
    browser.wait(EC.visibilityOf(element(by.css(this.DiskValueCss))),25000);
    element(by.css(this.DiskValueCss)).clear();
    element(by.css(this.DiskValueCss)).sendKeys(DiskValue).then(function(){
    	logger.info(" Disk value: "+DiskValue+" entered");    	
    });
}

// function for fetching onetime charge for service
placeOrder.prototype.getTextpricingError = function () {
	logger.info("--Fetching Pricing Error message on additional configuration page--");
	browser.wait(EC.visibilityOf(element(by.css(this.pricingErrorMessageCss))), 60000);
	return element(by.css(this.pricingErrorMessageCss)).getText().then(function (pricingErrorMessage) {
		logger.info("Error Message : " + pricingErrorMessage);
		return pricingErrorMessage;
	});
};

//sshkeyValueCss
placeOrder.prototype.setsshkeyValueText = function(sshkeyvalue)
{
    browser.wait(EC.visibilityOf(element(by.css(this.sshkeyValueCss))),25000);
    element(by.css(this.sshkeyValueCss)).clear();
    element(by.css(this.sshkeyValueCss)).sendKeys(sshkeyvalue).then(function(){
    	logger.info(" sshKeyValue "+sshkeyvalue+" entered");    	
    });
}

//sshKeyNamecss
placeOrder.prototype.setsshKeyNamecssText = function(sshKeyName)
{
    browser.wait(EC.visibilityOf(element(by.css(this.sshKeyNamecss))),25000);
    element(by.css(this.sshKeyNamecss)).clear();
    element(by.css(this.sshKeyNamecss)).sendKeys(sshKeyName).then(function(){
    	logger.info(" sshKeyName "+sshKeyName+" entered");    	
    });
}
//sshKeyError
placeOrder.prototype.getTextsshKeyError = function() {
    browser.wait(EC.visibilityOf(element(by.xpath(this.sshKeyErrorXpath))),15000);
    return element(by.xpath(this.sshKeyErrorXpath)).getText().then(function(sshkey_error_text){
        logger.info("Error Message : "+sshkey_error_text);
        return sshkey_error_text;
    });
};

placeOrder.prototype.setCustomTemplateRegexValueText = function(regexparam)
{
    browser.wait(EC.visibilityOf(element(by.css(this.regexparamCustomTemplateCss))),25000);
    element(by.css(this.regexparamCustomTemplateCss)).clear();
    element(by.css(this.regexparamCustomTemplateCss)).sendKeys(regexparam);
    element(by.css(this.randomclickCss)).click();
    element(by.css(this.regexparamCustomTemplateCss)).clear();
    element(by.css(this.regexparamCustomTemplateCss)).sendKeys(regexparam).then(function(){
    	logger.info(" regexparam for custom template : "+regexparam+" is entered");    	
    });
}

//regex param for custom template
placeOrder.prototype.getTextregexparamcustomtemplate = function() {
    browser.wait(EC.visibilityOf(element(by.css(this.regexParamCustomGetTextCss))),15000);
    return element(by.css(this.regexParamCustomGetTextCss)).getText().then(function(regexparam_customtemplate_error_text){
        logger.info("Error Message : "+regexparam_customtemplate_error_text);
        return regexparam_customtemplate_error_text;
    });
};

//Invisible param checks
placeOrder.prototype.checkIfsharedparam = function()
{
	return element(by.css(this.sharedParamAwsDataLabelCss)).isPresent()
};

placeOrder.prototype.checkIfSampleHiddenparam = function()
{
	return element(by.css(this.sampleHiddenParamLabelCss)).isDisplayed()
}; 

placeOrder.prototype.checkIfUserPasswordparam = function()
{
	return element(by.css(this.userPasswordLabelCss)).isDisplayed()
};

placeOrder.prototype.getActBOMOnReviewOrderPage = function(){
    var actualBillOfMaterialsMap = {};   
    var j=0;
    browser.wait(EC.visibilityOf(element(by.css(this.estimatedCostsReviewOrderPageCss))), 10000);   
    return element.all(by.xpath(this.txtCompListXpath)).getText().then(function(compList){
        compList.forEach(function(elem, index){
            element.all(by.xpath(defaultConfig.txtCompName)).get(index * 2).getText().then(function(compName){
                return element.all(by.xpath(defaultConfig.txtCompPrice)).get(j).getText().then(function(compPrice){
                    actualBillOfMaterialsMap[compName] = compPrice;
                    j = j + 1;                         
                });
            });            
        });        
        return actualBillOfMaterialsMap
    });
};

placeOrder.prototype.validateBOMOnReviewOrderPage = function(expPricingMap){
    var expPrice,actPrice;
    return this.getActBOMOnReviewOrderPage().then(function(actBomPricingMap){
        Object.keys(expPricingMap).forEach(function(key){
            expPrice = expPricingMap[key];
            actPrice = actBomPricingMap[key];
            if(expPrice == actPrice){
                logger.info("Pricing for " + key + " is : " + expPrice);
            }else{
                logger.info("Pricing do not match for " + key + " | Expected : " + expPrice + " | Actual : " + actPrice);
                return false;
            }
        });
        return true;
    });    
};

module.exports = placeOrder;
