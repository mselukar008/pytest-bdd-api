/************************************************
	AUTHOR: SANTOSH HADAWALE
************************************************/
"use strict";

const { browser, element } = require('protractor');

var snowUrl 		       = require('../../testData/SNOW/SnowUserCreds.json'),
	snowDropletCreds       = require('../../testData/SNOW/SnowDropletUserCreds.json'),
	logGenerator           = require("../../helpers/logGenerator.js"),
	util 			       = require('../../helpers/util.js'),
	apiUtil				   = require('../../helpers/APIs/apiUtil.js'),
	orderFlowUtil          = require('../../helpers/orderFlowUtil.js'),
	extend 			       = require('extend'),
	logger 				   = logGenerator.getApplicationLogger(),
	snowLoginObj 	       = JSON.parse(JSON.stringify(snowUrl.snowParameters)),
	snowDropletLoginObj    = JSON.parse(JSON.stringify(snowDropletCreds.snowParameters)),
	snowQuickstartLoginObj = JSON.parse(JSON.stringify(snowDropletCreds.snowQuickStartParameters)),
	snowQSICDSLoginObj     = JSON.parse(JSON.stringify(snowDropletCreds.snowQSICDSParameters)),
	snowDevLoginObj        = JSON.parse(JSON.stringify(snowDropletCreds.snowDevParameters)),
	EC 				       = protractor.ExpectedConditions;	

var defaultConfig = {
	usernameInputCss						:			"#user_name",
	passwordInputCss						:			"#user_password",
	loginButtonCss							:			"#sysverb_login",
	mainIframeId							:			"gsft_main",
	frameConfigValuesCss                    :           "[id='sc_req_item.x_ibmg3_hcms_broker_approval_item_json_ifr']",
	frameAddOnValuesCss						:			"[id='sc_req_item.x_ibmg3_hcms_addonservice_values_ifr']",
	frameBOMcss                             :           "[id='sc_req_item.x_ibmg3_hcms_broker_approval_item_summary_ifr']",
	addOnTableCaptionCss					:			"table[class='mce-item-table'] caption",
	addOnServiceBOMTotalMonthlyXpath		:			"//td[contains(text(), '{0}')]/following-sibling::td[contains(text(),'{1}')]/following-sibling::td[6]",
	addOnServiceBOMCurrencyXpath			:			"//td[contains(text(), '{0}')]/following-sibling::td[contains(text(),'{1}')]/following-sibling::td[2]",
	addContentButtonCss						:			"#homepage_header_table #add_icon",
	homeTitleCss							:			"#home_title",
	favouritestStarCss						:			"#favorites_tab",
	searchFilterCss							:			"#filter",
	catalogRequests                         :           "Service Catalog",
	serviceCatalogRequestXpath				:			"//div[@class = 'sn-widget-list-title' and text() = 'Requests']", //"//a/div/span[contains(text(),'Service Catalog - Requests')]",
	goToDropdownCss							:			"[class='input-group-addon input-group-select'] select",
	numberOptionFromGoToDropdownCss			:			"[class='input-group-addon input-group-select'] select option[value='number']",
	searchInputCss							:			"[id$='_text']",
	//allLinkXpath							:			"//a/span[contains(text(), 'All')]/..",
	allLinkXpath                            :           "All",
	searchOrderNumberCss                    :           "td[name='x_ibmg3_hcms_order_number'] input, td[name='correlation_id'] input",
	OrderNumNotExistsCss                    :           'tbody[class="list2_body"] tr[class="list2_no_records"] td',
	requestNumberBreadcrumbLinkCss			:			"a[class='breadcrumb_link']:nth-of-type(5) span[class='sr-only']",
	requestNumberLinkXpath					:			"//a[@class = 'linked formlink' and contains(text(),'REQ')]",
	requestNumberInputBoxCss				:			"input[id='sc_request.number']",
	approversTabCss							:			"#tabs2_list span[class='tab_header']:nth-of-type(2) span[class='tab_caption_text']",	
	approverRequestedXpath					:			"//td[@class='vt']/a[contains(text(), 'Requested')]",
	approverApprovededXpath					:			"//a[contains(text(), 'Approved')]",
	approveButtonCss						:			"span[class='navbar_ui_actions'] #approve,#approve_approval",
	rejectButtonCss                         :           "#reject",
	transactionCancelButtonCss				:			"#transaction_cancel",
	requestedItemsTabCss					:			"#tabs2_list span[class='tab_header']:nth-of-type(1) span[class='tab_caption_text']",
	linkRequestedItemXpath			        :			"//a[contains(text(), 'RITM')]",
	requestedItemStateDropdownCss			:			"select[id='sc_req_item.state']",
	requestedItemClosedCompleteOptionCss	:			"select[id='sc_req_item.state'] option:nth-of-type(4)",
	navbarUpdateButtonCss					:			"span[class='navbar_ui_actions'] #sysverb_update",
	catalogTasksTabCss						:			"#tabs2_list span[class='tab_header']:nth-of-type(1) span[class='tab_caption_text']",
	linkCatalogTaskXpath				    :			"//a[contains(text(), 'SCTASK')]",
	catalogTaskNumberInputCss				:			"input[id='sc_task.number']",
	textCatalogTaskStateCss				    :			"[id='sc_task.state'] option[selected='SELECTED']",
	catalogTaskClosedCompleteOptionCss		:			"select[id='sc_task.state'] option:nth-of-type(4)",
	requestItemStageCss						:			"[id='sys_readonly.sc_req_item.stage'] option[selected='SELECTED']",
	approverStateCss						:			"[id='sysapproval_approver.state'] option[selected='SELECTED']",
	userInfoDropdownCss						:			"#user_info_dropdown",
	approvalControllerCss					:			"[id='sc_request.x_ibmg3_hcms_approval_controller'] option[selected='SELECTED']",
	approvalCss								:			"[id*='sc_request.approval'] option[selected='SELECTED']",
	textApprovalAfterFirstApprovalCss       :           "[id='sc_request.approval']",
	requestedStateCss						:			"[id='sc_request.request_state'] option[selected='SELECTED']",
	textRequestedStateAfterFirstApprovalCss :			"[id='sc_request.request_state']",
	textExternalApprovalCss					:			"[id='sc_request.x_ibmg3_hcms_external_approval'] option[selected='SELECTED']",
	textStageCss                            :           "[id='sc_request.stage'] option[selected='SELECTED']",
	textStageAfterFirstApprovalCss          :           "[id='sc_request.stage']",
	textShortDescCss                        :           "[id='sc_request.short_description']",
	orderNumberCss							:			"[id='sc_request.x_ibmg3_hcms_order_number']",
	textCldBrokerLocCss                     :           "[id='sc_request.x_ibmg3_hcms_cloud_broker_location']",
	textRequestedItemCss                    :           "[id='sys_display.sc_req_item.cat_item']",
	textRequestedItemStageCss               :           "[id='sys_readonly.sc_req_item.stage'] option[selected='SELECTED']",
	textRequestedItemStateCss               :           "[id='sc_req_item.state'] [selected='SELECTED']",
	textRequestedItemShortDescCss           :           "[id='sc_req_item.short_description']",
	textReqItemVariableSerOfferNameCss      :           "[class='container_table'] tr:nth-child(4) input:nth-of-type(2)",
	textReqItemVariableSerOfferDescCss      :           "[class='container_table'] tr:nth-child(6) input:nth-of-type(2)",
	textReqItemVariableChangeTypeCss        :           "[class='container_table'] tr:nth-child(8) [selected='SELECTED']",
	textReqItemVariableSerOfferingIDCss     :           "[class='container_table'] tr:nth-child(12) input:nth-of-type(2)",
	textReqItemVariableSOProviderCss        :           "[class='container_table'] tr:nth-child(14) input:nth-of-type(2)",
	textReqItemVariableConCategoryCss       :           "[class='container_table'] tr:nth-child(15) input:nth-of-type(2)",
	textReqItemVariableServiceNameCss       :           "[class='container_table'] tr:nth-child(16) input:nth-of-type(2)", 
	textSerInstanceCIsResourceIdCss         :           "[id='x_ibmg3_hcms_cmdb_ci_mcms.resource_id']",
	textSerInstanceCIsObjectIdCss           :           "[id='x_ibmg3_hcms_cmdb_ci_mcms.object_id']",
	textSerInstanceCIsStatusCss             :           "[id='x_ibmg3_hcms_cmdb_ci_mcms.install_status'] [selected='SELECTED']",
	textSerInstanceCIsStatusDiscCss         :           "[id='cmdb_ci_vm_instance.install_status'] [selected='SELECTED'],[id='x_ibmg3_hcms_cmdb_ci_mcms.install_status'] [selected='SELECTED']",
	textSerInstanceCIsStatusVRACss          :           "[id='cmdb_ci_vmware_instance.install_status'] [selected='SELECTED'],[id='x_ibmg3_hcms_cmdb_ci_mcms.install_status'] [selected='SELECTED']",
	brokerRequestTypeCss					:			"[id='sc_request.x_ibmg3_hcms_broker_request_type'] option[selected='SELECTED']",
	favouriteTabXpath						:			"//a[contains(@data-original-title,'Favorites')]",
	brokerCatalogItemsXpath					: 			"(//*[text()[contains(.,'Broker Catalog Items')]])",
	icbProvisionXpath						:			"//table//a[text()[contains(.,'IBM Cloud Broker Provision')]]",
	variableSetXpath						:			"(//span[contains(@class,'tab_caption_text') and contains(text(),'Variable')])[2]",
	vs_item_variable_setXpath				:			"//a[text()[contains(.,'vs_item_variables_set')]]",
	var_change_typeXpath					:			"//a[text()[contains(.,'var_change_type')]]",
	defaultValueXpath						:			"//span[text()[contains(.,'Default Value')]]",
	defaultValueTextAreaXpath				:			"//textarea[@id='item_option_new.default_value']",
	filterCss								: 			"[id='filter']",
	requestsXpath							:			"(//div[text()[contains(.,'Requests')]])[3]",
	relatedChangeRequestButtonCss			:			"[id='viewr.sc_req_item.x_ibmg3_hcms_related_change_request']",
	openRecordButtonXpath					:			"//a[text()[contains(.,'Open Record')]]",
	approversTabInChangeRequestXpath		:			"//span[contains(@class,'tab_caption_text') and contains(text(),'Approvers')]",
	changeTasksTabInChangeRequestXpath      :           "//span[contains(@class,'tab_caption_text') and contains(text(),'Tasks')]",
	changeRequestLinkXpath                  :           "//b[contains(text(),'Change request')]",
	checkboxInChangeRequestXpath			:			"(//label[@class='checkbox-label'])[5]",
	approveButtonInChangeInRequestCss		:			"[id='listv2_931a3be24ff8b700a428b5e18110c7ad_labelAction']",
	approveOptionInChangeRequestCss			:			"[id='846762e1c611227d00d8f3173b5d29db']",	
	logoutLinkCss							:			".dropdown-menu>li>a[href='logout.do']", //#transaction_cancel
	txtReqstNumberCss            			: 			'input[id = "sc_request.number"]',
	catalogItemCss                          :           "input[name='sys_display.sc_req_item.cat_item']",
	leftNavBarButtonCss                     :           ".btn.btn-default.icon-chevron-left.navbar-btn",
	buttonConfigurationItemCss              :           "[id='viewr.sc_req_item.configuration_item']",
	dropdownChangeRequestStateCss           :           "[id='change_request.state']",
	dropdownValuesChangeRequestStateCss     :           "[id='change_request.state'] option",
	textboxAssignmentGroupCss               :           "[id='sys_display.change_request.assignment_group']",
	textboxAssignmentGroupValue             :           "CAB Approval",
	buttonChangeRequestChangeTasksCss       :           "[id='change_request.change_task.change_request_breadcrumb'] button",
	linkNotifySerDeskNumXpath               :           "//td[contains(text(),'Notify Service Desk')]/preceding-sibling::td[1]/a",
	linkImplementNumXpath                   :           "//td[contains(text(),'Implement')]/preceding-sibling::td[1]/a",
	linkPostImplementNumXpath               :           "//td[contains(text(),'Post implementation testing')]/preceding-sibling::td[1]/a",
	buttonCloseTaskCss                      :           "[id='change_task_to_closed']",
	buttonCloseChangeRequestCss             :           "[id='state_model_move_to_closed']",
	tabChangeReqClosureInfoXpath            :           "//span[contains(text(), 'Closure Information') and @class='tab_caption_text']",
	dropdownChangeReqCloseCodeCss           :           "[id='change_request.close_code']",
	dropdownValuesChangeReqCloseCodeCss     :           "[id='change_request.close_code'] option",
	textChangeReqCloseNotesCss              :           "[id='change_request.close_notes']",
	closeNotesText                          :           "Success",
	textChangeRequestStateCss               :           "[id='change_request.close_code']",
	textChangeRequestCurrentStateCss        :           "a[aria-selected='true']",
	textChangeTaskProvTaskStateXpath        :           "//td[contains(text(), 'Provisioning Task')]/following-sibling::td[2]",
	textChangeReqClosedMsgCss               :           "[class='outputmsg_text']",
	buttonBackCss                           :           "[id='sysverb_back'] + button",
	discoverySchedule                       :           "Discovery Schedules",
	linkDiscoveryScheduleXpath              :           "//div[@class = 'sn-widget-list-title' and text() = 'Discovery Schedules']",
	linkTextAWSacct                         :           "Cloud Service Account - AWS service account",
	linkTextAzureAcct                       :           "Cloud Service Account - Azure-SNOW-MCMP-Test",
	linkTextVRAcct                          :           "Cloud Service Account - Vmware account",
	linkTextDiscoverNow                     :           "Discover now",
	textDiscoveryStateCss                   :           "tr[id^='row_discovery_status'] td:nth-child(8)",
	linkSysIDCss                            :           "#discovery_status_breadcrumb a:nth-child(3)",
	checkboxValueResourceMappingCss         :           "[id='ni.x_ibmg3_hcms_cmdb_ci_mcms.resource_mapping']",
	linkVMInstanceInCIXpath                 :           "//a[text()[contains(.,'EC2InstanceEdit')] and @class='ng-binding']",
	linkVMInstanceInCIAzXpath               :           "//a[text()[contains(.,'auto-VM101')] and @class='ng-binding']",
	textVMInstanceStateCss                  :           "[id='cmdb_ci_vm_instance.state'] option[selected='SELECTED']",
	textVMInstanceVRACss                    :           "[id='cmdb_ci_vmware_instance.state'] option[selected='SELECTED']",
	textVMcpuCss                            :           "[id='cmdb_ci_vmware_instance.cpus']",
	textVMmemoryCss                         :           "[id='cmdb_ci_vmware_instance.memory']",
	textBOMcostXpath                        :           "//body[@id='tinymce']//th/../following-sibling::tr//td[8]",
	textRejectCommentsCss                   :           "#activity-stream-textarea",
	rejectComment                           :           "Test Reject Order",
	textChangeTaskXpath                     :           "//a[contains(text(),'CTASK')]",
	textChangeTaskState                     :           "[id='change_task.state'] [selected='SELECTED'],[id='sys_readonly.change_task.state'] [selected='SELECTED']",
	textChangeTaskActivityCss               :           ".sn-widget-textblock-body.sn-widget-textblock-body_formatted",
	buttonOtherActiveTasksInChangeTaskCss   :           "[id='show_related_tasks_change_task.cmdb_ci']",
	textIncidentXpath                       :           "//a[contains(text(),'INC')]",
	textIncidentState                       :           "[id='incident.state'] [selected='SELECTED']",
	textIncAssignmentGroupCss               :           "[id='sys_display.incident.assignment_group']",
	textIncShortDescCss                     :           "[id='incident.short_description']",
	textIncResCodeCss                       :           "[id='incident.close_code'] [selected='SELECTED']",
	textIncResNotesCss                      :           "[id='incident.close_notes']",
	tabIncResolutionInfoXpath               :           "//span[contains(text(), 'Resolution Information')]",
	textNavbarTitleCss                      :           "#header_add_attachment",
	textCancelChangeXpath                   :           "//div[contains(text(), 'Cancel')]",
	textareaCancelChangeReasonCss           :           "#change_confirm_reason_text",
	cancelChangeReason                      :           "Test Cancel Change",
	buttonCancelChangeOkCss                 :           "#change_confirm_ok_btn",
	textChangeReqStateCss                   :           "[id='change_request.state']",
	textareaChangeTaskDescCss               :           "[id='change_task.description']",
	changeTaskDesc                          :           "Test Cancel Change Task",
	
	/*****************************SnowV3 Page Objects***************************************************/
	checkboxReqApprovalHoldCss              :           "input[checked='checked']",
	
	/****************************QUICKSTART Page Objects***************************************************/
	textApprovalStateQSCss                  :           "[id='sys_readonly.sc_request.approval'] [selected='SELECTED']",
	textAssignmentGrpQSCss                  :           "[id='sys_display.sc_request.assignment_group']",
	textCorrelationIdCss                    :           "[id='sc_request.correlation_id']",
	textCorrelationDisplayCss				:			"['id=sc_request.correlation_display']",
	textReqItemApprovalQSCss                :           "[id='sys_readonly.sc_req_item.approval'] [selected='SELECTED']",
	textReqItemAssignGrpQSCss               :           "[id='sys_display.sc_req_item.assignment_group']",
	textReqItemDescQSCss                    :           "[id='sc_req_item.description']",
	tabReqItemVarQSCss                      :           "#tabs2_section span:nth-child(2) span",
	linkChangeRequestQSXpath                :           "//a[contains(text(),'CH')]",
	textChangeReqApprovalQSCss              :           "[id='sys_readonly.change_request.approval'] [selected='SELECTED']",
	textChangeReqTypeQSCss                  :           "[id='sys_readonly.change_request.type'] [selected='SELECTED']",
	textChangeReqStateQSCss                 :           "[id='change_request.state'] [selected='SELECTED']",
	textChangeReqConfItemQSCss              :           "[id='sys_display.change_request.cmdb_ci']",
	SysDefScheduledJobs                     :           "Scheduled Jobs",
	linkScheduledJobsXpath                  :           "//div[@class = 'sn-widget-list-title' and text() = 'Scheduled Jobs']",
	searchTextboxScheduledJobsCss           :           "#sysauto_table_header_search_control",
	QSSetChangeToInProg                     :           "QS Set Change to In Progress",
	linkSetChangeToInProgXpath              :           "//a[contains(text(), 'QS Set Change to In Progress')]",
	buttonExecuteNowCss                     :           "#execute",
	textChangeTasksStateXpath               :           "//tr[starts-with(@id,'row_change_request.change_task.change_request_')]/td[6]",
	colorStateCss                           :           ".list2_cell_background",
	buttonApproveCss                        :           "#approve_approval",
	HCMSproperties                          :           "Properties",
	linkPropertiesXpath                     :           "//span[contains(text(), 'HCMS Broker Integration')]/ancestor::li//div[contains(text(), 'Properties')]",
	searchTextboxQSApprovalCss              :           "#sys_properties_table_header_search_control",
	QSMCMPReqApprovalGrp                    :           "QS_MCMP_Request_Approval_Group",
	linkQSReqApprovalGrpXpath               :           "//a[contains(text(), 'QS_MCMP_Request_Approval_Group')]",
	textareaValueCss                        :           "[id='sys_properties.value']",
	QSApproveManager                        :           "QS Approving Manager",
	tabApproversAtRITMCss                   :           "#tabs2_list span[class='tab_header']:nth-of-type(3) span[class='tab_caption_text']",
	buttonImplementCss                      :           "#state_model_move_to_implement",
	dropdownImpactCss                       :           "[id='change_request.impact']",
	dropdownValueImpactCss                  :           "[id='change_request.impact'] option[value='1']",
	dropdownUrgencyCss                      :           "[id='change_request.urgency']",
	dropdownValueUrgencyCss                 :           "[id='change_request.urgency'] option[value='1']",
	searchTextAssignGrpCss                  :           "[id='sys_display.change_request.assignment_group']",
	searchTextAssignedToCss                 :           "[id='sys_display.change_request.assigned_to']",
	dropdownFailureProbCss                  :           "[id='change_request.u_qsfailureprobability']",
	dropdownValueFailureProbCss             :           "[id='change_request.u_qsfailureprobability'] option[value='1']",
	dropdownExcepReasonCss                  :           "[id='change_request.u_qs_exception_reason']",
	dropdownValueExcepReasonCss             :           "[id='change_request.u_qs_exception_reason'] option[value='Customer']",
	textareaJustificationsCss               :           "[id='change_request.justification']",
	textareaImplementPlanCss                :           "[id='change_request.implementation_plan']",
	textareaRiskAnalysisCss                 :           "[id='change_request.risk_impact_analysis']",
	textareaBackoutPlanCss                  :           "[id='change_request.backout_plan']",
	textareaTestPlanCss                     :           "[id='change_request.test_plan']",
	textareaExcepJustificationCss           :           "[id='change_request.u_qs_exception_justification']",
	textScheduleTabXpath                    :           "//span[contains(text(), 'Schedule')]",
	textPlanningTabXpath                    :           "//span[contains(text(), 'Planning')]",
	buttonCalendarStartDateCss              :           "[id='change_request.start_date.ui_policy_sensitive']",
	buttonCalendarEndDateCss                :           "[id='change_request.end_date.ui_policy_sensitive']",
	calendarStartDateXpath                  :           "//*[@class='calText calCurrentDate']/following-sibling::td[1]",//"//*[@class='calText calCurrentDate']/parent::tr/following-sibling::tr/td[2]",
	calendarEndDateXpath                    :           "//*[@class='calText calCurrentDate']/following-sibling::td[1]",//"//*[@class='calText calCurrentDate']/parent::tr/following-sibling::tr/td[2]",
	buttonDatePickerOkCss                   :           "[id='GwtDateTimePicker_ok']",
	linkTextCalculateRisk                   :           "Calculate Risk",
	buttonAssessCss                         :           "[id='assess.change']",
	dropdownChangeTaskStateCss              :           "[id='change_task.state']",
	dropdownValueCTStateCss                 :           "[id='change_task.state'] option[value='3']",
	textNotesTabXpath                       :           "//span[contains(text(), 'Notes')]",
	textareaAdditionalCommentsCss           :           "#activity-stream-comments-textarea",
	textChangeRequestCurrentStateQSCss      :           "[data-state='current'] a",
	dropdownValuesChangeTaskStateCss        :           "[id='change_task.state'] option",
	textareaChangeTaskDescCss               :           "[id='change_task.description']",
	buttonCancelCss                         :           "#change_task_to_cancelled",
	linkProvTaskXpath                       :           "//td[contains(text(),'Provisioning Task')]/preceding-sibling::td[1]/a",
	textReqItemCorrIDCss                    :           "[id='sc_req_item.correlation_id']",
	buttonCancelICDSCss                     :           "#u_qs_cancel_this_change",
	linkEditRecordPropCss                   :           ".outputmsg_nav_inner a:nth-child(3)",
	cmdbCIFormHeaderCss                     : 			"div.container-fluid",
	cmdbCIFormHeaderViewXpath 				:  			"//div[contains(text(), 'View')]",//"//div[@class = 'context_item' and text() = 'View']",
	cmdbCIFormHeaderDefaultViewXpath		: 			"//div[contains(text(), 'Default view')]",//"//div[@class = 'context_item' and text() = 'Default view']"

	cmdbShellCINameCss						: 			"[id='x_ibmg3_hcms_cmdb_ci_mcms.name']",
	cmdbShellCIAssignedToCss 				: 			"[id='sys_display.x_ibmg3_hcms_cmdb_ci_mcms.assigned_to']",
	cmdbShellCIInstanceIDCss 				: 			"[id='x_ibmg3_hcms_cmdb_ci_mcms.instance_id']",
	cmdbShellCIAssignmentGroupCss 			: 			"[id='sys_display.x_ibmg3_hcms_cmdb_ci_mcms.assignment_group']",
	cmdbShellCIOperationalStatusCss 		: 			"[id='x_ibmg3_hcms_cmdb_ci_mcms.operational_status'] [selected='SELECTED'] ",
	cmdbShellCICorrelationIDCss				: 			"[id='x_ibmg3_hcms_cmdb_ci_mcms.correlation_id']",
	cmdbShellCIAccountIDCss 				: 			"[id='x_ibmg3_hcms_cmdb_ci_mcms.account_id']",
	cmdbShellCIAccountNameCss 				: 			"[id='x_ibmg3_hcms_cmdb_ci_mcms.account_name']",

	cmdbActualCINameCss 					: 			"input[id='cmdb_ci_vmware_instance.name']",
	cmdbActualCIObjectIDHCMSViewCss 		: 			"[id='cmdb_ci_vmware_instance.object_id']",
	cmdbActualCIDiskSizeDefaultViewCss 		:			"[id='cmdb_ci_vmware_instance.disks_size']",
	requestNumberInRequestPageCss 			:			"[id='sys_readonly.sc_request.number']",
	requestedForInRequestPageCss 			: 			"[id='sys_display.sc_request.requested_for']",
	ritmNumberInRITMPageCss 				: 			"[id='sys_readonly.sc_req_item.number']",
	requestNumberInRITMPageCss 				: 			"[id='sys_display.sc_req_item.request']",
	requestedForInRITMPageCss 				: 			"[id='sys_display.sc_req_item.request.requested_for']",
	shellCIInRITMPageCss					:			"[id='sys_display.sc_req_item.configuration_item']",
	changeReqNumberCss 						: 			"[id='sys_display.sc_req_item.x_ibmg3_hcms_related_change_request']",
	changeReqShortDescCss 					: 			"[id='change_request.short_description']",
	changeReqDescCss 						: 			"[id='change_request.description']",
	catalogTaskNumberCss 					: 			"[id='sys_readonly.sc_task.number']",
	shellCIInCatalogTaskPageCss 			: 			"[id='sys_display.sc_task.cmdb_ci']",
	ritmNumberInCatalogTaskPageCss 			: 			"[id='sys_display.sc_task.request_item']",
	catalogTaskShortDecCss 					: 			"[id='sc_task.short_description']",
	catalogTaskAssignmentGroupCss 			: 			"[id='sys_display.sc_task.assignment_group']",
	mcmpVersionRITMVariableCss 				: 			"[class='container_table'] tr:nth-child(18) input:nth-of-type(2)",
	labelsRITMVariableCss  					: 			"[class='container_table'] tr:nth-child(20) input:nth-of-type(2)",
	changeRequiredRITMVariableCss  			: 			"[class='container_table'] tr:nth-child(21) input:nth-of-type(2)",
	provisioningChangeTaskClosureMsgCss 	: 			"[class='sn-widget-textblock-body sn-widget-textblock-body_formatted']",
	changeTaskNumberCss 					: 			"[id='sys_readonly.change_task.number']",
 	shellCIInChangeTaskPageCss 				: 			"[id='sys_display.change_task.cmdb_ci']",
 	changeRequestNumberInChangeTaskPageCss 	: 			"[id='sys_display.change_task.change_request']",
 	changeTaskShortDescCss 					: 			"[id='change_task.short_description']",
	changeTaskReadOnlyStateCss 				: 			"[id='sys_readonly.change_task.state'] [selected='SELECTED']",
	changeTaskStateCss 						: 			"[id='change_task.state'] [selected='SELECTED']",
 	assignmentGroupChangeTaskCss 			:			"[id='sys_display.change_task.assignment_group']",
	assignedToChangeTaskCss 				: 			"[id='sys_display.change_task.assigned_to']",
	textChangeTaskDescCss              		:         	"[id='change_task.description']",
	clickClosureInfoInChangeTaskCss 		:			"[class='tabs2_tab default-focus-outline last_tab_closure']",
	provisioningSuccesfulChangeTaskMsgCss 	:			"[id='change_task.close_notes']",

	textIncidentNumberCss 					: 			"[id='sys_readonly.incident.number']",
	shellCIInIncidentPageCss 				: 			"[id='sys_display.incident.cmdb_ci']",

	requestApprovalInChangeRequestPageCss	: 			"[id='u_qs_request.approval']",
	selectAssignGrpValueChangeTaskCss		:			"[id='sys_display.change_task.assignment_group']",
	selectAssignedToValueChangeTaskCss		:			"[id='sys_display.change_task.assigned_to']",

	changeRequestCopySysIdXpath 				:  			"//div[contains(text(), 'Copy sys_id')]"


};

function snow(selectorConfig) {
    if (!(this instanceof snow)) {
        return new snow(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

snow.prototype.clickFavouritesStar = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.favouritestStarCss))),90000).then(function(){
		logger.info("Wait till Favourite Star icon is displayed");
	});
	element(by.css(this.favouritestStarCss)).click().then(function(){
		logger.info("Clicked on Favourites star");
    });
}

snow.prototype.clickOnFavouriteTab = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.favouriteTabXpath))),30000).then(function(){
		logger.info("Wait till favourite tab is displayed");
	});
	element(by.xpath(this.favouriteTabXpath)).click().then(function(){
		logger.info("Clicked on favourite Tab");
    });
}

snow.prototype.clickHCMSBrokerIntegration = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.hcmsBrokerIntegrationXpath))),30000).then(function(){
		logger.info("Wait till HCMS Broker Integration tab is displayed");
	});
	element(by.xpath(this.hcmsBrokerIntegrationXpath)).click().then(function(){
		logger.info("Clicked on HCMS Broker Integration");
    });
}

snow.prototype.clickBrokerCatalogItems = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.brokerCatalogItemsXpath))),30000).then(function(){
		logger.info("Wait till Broker Catalog Items tab is displayed");
	});
	element(by.xpath(this.brokerCatalogItemsXpath)).click().then(()=>{
		logger.info("Clicked on Broker Catalog Items");
	})
		
   
}

snow.prototype.clickICBProvision = function(){
	this.switchToParentFrame();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.icbProvisionXpath))),50000).then(function(){
		logger.info("Wait till IBM Cloud Broker Provision link is displayed");
	});
	element(by.xpath(this.icbProvisionXpath)).click().then(function(){
		logger.info("Clicked on IBM Cloud Broker Provision link");
    });
}

snow.prototype.clickOnVariableSet = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.variableSetXpath))),30000).then(function(){
		logger.info("Wait till Variable Set tab is displayed");
	});
	element(by.xpath(this.variableSetXpath)).click().then(function(){
		logger.info("Clicked on Variable Set tab");
	});

}

snow.prototype.clickOnVsItemVariableSet = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.vs_item_variable_setXpath))),30000).then(function(){
		logger.info("Wait till vs_item_variable_set is displayed");
	});
	element(by.xpath(this.vs_item_variable_setXpath)).click().then(function(){
		logger.info("Clicked on vs_item_variable_set");
	});
}

snow.prototype.clickOnVarChangeType = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.var_change_typeXpath))),30000).then(function(){
		logger.info("Wait till IBM Cloud Broker Provision link is displayed");
	});
	element(by.xpath(this.var_change_typeXpath)).click().then(function(){
		logger.info("Clicked on IBM Cloud Broker Provision link");
    });
}

snow.prototype.clickOnDefaultValue = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.defaultValueXpath))),50000).then(function(){
		logger.info("Wait till Default Value tab is displayed");
	});
	element(by.xpath(this.defaultValueXpath)).click().then(function(){
		logger.info("Clicked on Default Value tab");
	});
}

snow.prototype.setValueToNormal = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.defaultValueTextAreaXpath))),30000).then(function(){
		logger.info("Wait till text Area is displayed");
	});
	element(by.xpath(this.defaultValueTextAreaXpath)).click().then(function(){
		logger.info("Clicked on Default Value Text Area");
	});
	element(by.xpath(this.defaultValueTextAreaXpath)).clear().then(()=>{
		logger.info("Cleared Text Area");
	});
	element(by.xpath(this.defaultValueTextAreaXpath)).sendKeys("normal");
	element(by.css(this.navbarUpdateButtonCss)).click().then(()=>{
			logger.info("Set Flag to --> normal");
		
    });
}


snow.prototype.setValueToStandard = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.defaultValueTextAreaXpath))),30000).then(function(){
		logger.info("Wait till text Area is displayed");
	});
	element(by.xpath(this.defaultValueTextAreaXpath)).click().then(function(){
		logger.info("Clicked on Default Value Text Area");
	});
	element(by.xpath(this.defaultValueTextAreaXpath)).clear().then(()=>{
		logger.info("Cleared Text Area");
	});
	element(by.xpath(this.defaultValueTextAreaXpath)).sendKeys("standard");
	element(by.css(this.navbarUpdateButtonCss)).click().then(()=>{
			logger.info("Set Flag to --> standard");
		
    });
}

snow.prototype.clickOnRequests = function(){
	//element(by.xpath(this.filter)).click();
	element(by.css(this.filterCss)).click().then(function(){
		element(by.css(filterCss)).clear();
		logger.info("Cleared filter Area");
		element(by.css(filterCss)).sendKeys("open records");
		element(by.xpath(requestsXpath)).click().then(()=>{
			logger.info("Clicked on requests");
		});
    });
}

snow.prototype.clickOnRelatedChangeRequestButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.relatedChangeRequestButtonCss))),90000).then(function(){
		logger.info("Wait till Related Change Request Button is displayed");
	});
	element(by.css(this.relatedChangeRequestButtonCss)).click().then(function(){
		logger.info("Clicked on Related Change Request Button");
    });
}


snow.prototype.clickOnOpenRecordButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.openRecordButtonXpath))),30000).then(function(){
		logger.info("Wait till Open Record Button is displayed");
	});
	element(by.xpath(this.openRecordButtonXpath)).click().then(function(){
		logger.info("Clicked on Open Record Button");
    });
}


snow.prototype.clickOnApproversTabInChangeRequest = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.approversTabInChangeRequestXpath))),30000).then(function(){
		logger.info("Wait till Approvers tab in Change Request is displayed");
	});
	element(by.xpath(this.approversTabInChangeRequestXpath)).click().then(function(){
		logger.info("Clicked on Approvers tab in Change Request");
    });
}

snow.prototype.clickChangeTaskTabInChangeRequest = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.changeTasksTabInChangeRequestXpath))),30000).then(function(){
		logger.info("Wait till Change Tasks tab in Change Request is displayed");
	});
     element(by.xpath(this.changeTasksTabInChangeRequestXpath)).click().then(function(){
		logger.info("Clicked on Change Tasks tab in Change Request");
    }).catch(function(err){
		logger.info("Exception occured while clicking change task tab.");
    });
}


snow.prototype.clickOnCheckboxInChangeRequest = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.checkboxInChangeRequestXpath))),30000).then(function(){
		logger.info("Wait till checkbox in ChangeRequest is displayed");
	});
	element(by.xpath(this.checkboxInChangeRequestXpath)).click().then(function(){
		logger.info("Clicked on checkbox in ChangeRequest");
    });
}


snow.prototype.clickOnApproveInChangeRequest = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.approveButtonInChangeInRequestCss))),30000).then(function(){
		logger.info("Wait till approve drop-down is displayed");
	});
	element(by.css(this.approveButtonInChangeInRequestCss)).click().then(function(){
		logger.info("Clicked on approve drop-down ");
    });
}

snow.prototype.clickLeftNavigation = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.leftNavBarButtonCss))),30000).then(function(){
		logger.info("Wait till left navigation button is displayed");
	});
	element(by.css(this.leftNavBarButtonCss)).click().then(function(){
		logger.info("Click on left navigation button ");
    });
}


snow.prototype.approveInChangeRequest = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.approveOptionInChangeRequestCss))),30000).then(function(){
		logger.info("Wait till approve option is displayed in dropdown");
	});
	element(by.css(this.approveOptionInChangeRequestCss)).click().then(function(){
		logger.info("Clicked on approve option ");
    });
}

snow.prototype.getFlagText = function(){
	this.clickOnVarChangeType();
	this.clickOnDefaultValue();
	var webElement = element(by.xpath(this.defaultValueTextAreaXpath))
	browser.wait(EC.visibilityOf(webElement),30000).then(function(){
		logger.info("Wait till default value is displayed");
	});
	return webElement.getText().then(function(flag){
		logger.info("Default value is : "+flag);
		return flag;
	});
}

snow.prototype.searchRequestsText = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.searchFilterCss))),30000).then(function(){
		logger.info("Wait till search Text box is displayed");
	});
	element(by.css(this.searchFilterCss)).clear().then(function(){
		logger.info("Cleared search textbox");
    });
	element(by.css(this.searchFilterCss)).sendKeys(this.catalogRequests).then(function(){
		logger.info("Entered Requests text in search textbox");
    });
}

snow.prototype.searchDiscoveryText = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.searchFilterCss))),30000).then(function(){
		logger.info("Wait till search Text box is displayed");
	});
	element(by.css(this.searchFilterCss)).sendKeys(this.discoverySchedule).then(function(){
		logger.info("Entered Discovery Schedules text in search textbox");
    });
}

snow.prototype.clickServiceCatalogRequestLink = function(){
	browser.wait(EC.elementToBeClickable(element.all(by.xpath(this.serviceCatalogRequestXpath)).get(0)),90000).then(function(){
		logger.info("Wait till Service Catalog Request link is displayed");
	});
	element.all(by.xpath(this.serviceCatalogRequestXpath)).get(0).click().then(function(){
		logger.info("Clicked on Service Catalog - Requests link");
		browser.sleep(5000);
    });
}

snow.prototype.clickDiscoverySchedulesLink = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.linkDiscoveryScheduleXpath))),30000).then(function(){
		logger.info("Wait till Service Catalog Request link is displayed");
	});
	element(by.xpath(this.linkDiscoveryScheduleXpath)).click().then(function(){
		logger.info("Clicked on Discovery Schedules link");
		browser.sleep(2000);
    });
}

snow.prototype.searchSRNumber = function(ticketID){
	this.switchToParentFrame();
	browser.wait(EC.elementToBeClickable(element(by.css(this.goToDropdownCss))),30000).then(function(){
		logger.info("Wait till Go To dropdown displayed");
	});
	element(by.css(this.goToDropdownCss)).click().then(function(){
		logger.info("Clicked on Go To dropdown");
	});
	element(by.css(this.numberOptionFromGoToDropdownCss)).isDisplayed().then(function(){
		logger.info("Number option from Go To dropdown is diplayed");
	})
	element(by.css(this.numberOptionFromGoToDropdownCss)).click().then(function(){
		logger.info("Selected Number option from Go To dropdown");
	})
	browser.wait(EC.visibilityOf(element(by.css(this.searchInputCss))),30000).then(function(){
		logger.info("Wait till Search input box is displayed");
	}); 
	element(by.css(this.searchInputCss)).sendKeys(ticketID).then(function(){
		ticketID.then(function(srNo){
			logger.info("Entered "+srNo+" in Search input box");
		})
    });
	element(by.css(this.searchInputCss)).sendKeys(protractor.Key.ENTER).then(function(){
		logger.info("Hit Enter after entering request number");
	})
	
	/*browser.wait(EC.visibilityOf(element(by.css(this.requestNumberBreadcrumbLinkCss))),30000).then(function(){
		logger.info("Wait till Request Number breadcrumb link is displayed");
	});	*/
}

snow.prototype.searchOrderNumber = function(ticketID){
	this.switchToParentFrame();
	browser.wait(EC.visibilityOf(element(by.css(this.goToDropdownCss))),30000).then(function(){
		logger.info("Wait till Go To dropdown displayed");
	});
	browser.wait(EC.elementToBeClickable(element(by.linkText(this.allLinkXpath))),30000).then(function(){
		logger.info("Wait till All link displayed");
		browser.sleep(5000);
	});
	element(by.linkText(this.allLinkXpath)).click().then(function(){
		logger.info("Clicked on All link");
	});
	browser.wait(EC.elementToBeClickable(element(by.css(this.goToDropdownCss))),30000).then(function(){
		logger.info("Wait till Go To dropdown displayed");
	});
	element(by.css(this.goToDropdownCss)).click().then(function(){
		logger.info("Clicked on Go To dropdown");
	})
	element(by.css(this.numberOptionFromGoToDropdownCss)).isDisplayed().then(function(){
		logger.info("Number option from Go To dropdown is diplayed");
	})
	element(by.cssContainingText('option', 'Order Number')).click().then(function(){
		logger.info("Selected Order Number option from Go To dropdown");
	})
	browser.wait(EC.visibilityOf(element(by.css(this.searchInputCss))),30000).then(function(){
		logger.info("Wait till Search input box is displayed");
	}); 
	element(by.css(this.searchInputCss)).sendKeys(ticketID).then(function(){
		//ticketID.then(function(orderNum){
			logger.info("Entered "+ticketID+" in Search input box");
		//})
		
    });
	element(by.css(this.searchInputCss)).sendKeys(protractor.Key.ENTER).then(function(){
		logger.info("Hit Enter after entering request number");
	})
	browser.sleep(5000);
}


snow.prototype.searchOrderNumColumn = function(ticketID) {
	this.switchToParentFrame();
	browser.wait(EC.elementToBeClickable(element(by.linkText(this.allLinkXpath))),30000).then(function(){
		logger.info("Wait till All link displayed");
		browser.sleep(2000);
	});
	
	element(by.linkText(this.allLinkXpath)).click().then(function(){
		logger.info("Clicked on All link");
	});
	
	browser.wait(EC.visibilityOf(element(by.css(this.searchOrderNumberCss))),30000).then(function(){
		logger.info("Wait till Order Search input box is displayed");
	});
	
	element(by.css(this.searchOrderNumberCss)).clear().then(function(){
			logger.info("Cleared Order Search input box");
	});
	
	element(by.css(this.searchOrderNumberCss)).sendKeys(ticketID).then(function(){
		//ticketID.then(function(orderNum){
			logger.info("Entered "+ticketID+" in Search input box");
		//})
	});
	
	element(by.css(this.searchOrderNumberCss)).sendKeys(protractor.Key.ENTER).then(function(){
		logger.info("Hit Enter after entering request number");
	});
	
	browser.sleep(2000);
}

snow.prototype.getTextOrderNotExists = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.OrderNumNotExistsCss))),20000).then(function(){
		logger.info("Wait till message displayed");
	})
	return element(by.css(this.OrderNumNotExistsCss)).getText().then( function(message){
		logger.info("Message on searching order number: " + message);
			return message;
		
	});
}

snow.prototype.clickRequestNumberLink = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.requestNumberLinkXpath))),30000).then(function(){
		logger.info("Wait till Request Number link is displayed");
	});
    element(by.xpath(this.requestNumberLinkXpath)).click().then(function(){
		logger.info("Clicked on Request Number link");
    });	
}

snow.prototype.clickApproversTab = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.approversTabCss))),30000).then(function(){
		logger.info("Wait till Approvers tab is displayed");
	});
	element(by.css(this.approversTabCss)).isDisplayed().then(function(){
		logger.info("Approver tab is displayed");
    });
	element(by.css(this.approversTabCss)).click().then(function(){
		logger.info("Clicked on Approvers tab");
    });
}

snow.prototype.clickRequestedLinkFromApproversTab = function(){
	var self = this;
	element(by.xpath(self.approverRequestedXpath)).isPresent().then(function(bool){
		if(bool) {
			browser.wait(EC.elementToBeClickable(element(by.xpath(self.approverRequestedXpath))),30000).then(function(){
				logger.info("Wait till Requested link displayed");
			});
			element(by.xpath(self.approverRequestedXpath)).click().then(function(){
				logger.info("Clicked on Request State link under Approvers tab");
		    });
		}
		else {
			logger.info("There is no approver");
		}
	})	
}

snow.prototype.clickApprovedLinkFromApproversTab = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.approverApprovededXpath))),30000).then(function(){
		logger.info("Wait till Approved link displayed");
	});
	element(by.xpath(this.approverApprovededXpath)).isDisplayed().then(function(){
		logger.info("Approver approved is displayed");
    });
	element(by.xpath(this.approverApprovededXpath)).click().then(function(){
		logger.info("Clicked on Approved State link under Approvers tab");
    });
}


snow.prototype.clickApproveButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.approveButtonCss))),90000).then(function(){
		logger.info("Wait till Approve button is displayed");
	});
	element(by.css(this.approveButtonCss)).click().then(function(){
		logger.info("Clicked Approve button");
		browser.sleep(10000);//Intentional sleep as sometimes - Transaction Running popup will appear after some time
    });
	browser.wait(EC.invisibilityOf(element(by.css(this.transactionCancelButtonCss))),240000).then(function(){
		logger.info("Wait till Transaction Cancel button disappears");
	});
}

snow.prototype.clickRejectButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.rejectButtonCss))),90000).then(function(){
		logger.info("Wait till Reject button is displayed");
	});
	element(by.css(this.rejectButtonCss)).click().then(function(){
		logger.info("Clicked Reject button");
		browser.sleep(10000);//Intentional sleep as sometimes - Transaction Running popup will appear after some time
    });
	browser.wait(EC.invisibilityOf(element(by.css(this.transactionCancelButtonCss))),240000).then(function(){
		logger.info("Wait till Transaction Cancel button disappears");
	});
}

snow.prototype.clickRequestedItemsTab = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.requestedItemsTabCss))),90000);
	element(by.css(this.requestedItemsTabCss)).click().then(function(){
		logger.info("Clicked on Requested Items tab");
    });
}

snow.prototype.clickRequestedItemLink = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.linkRequestedItemXpath))),90000).then(function(){
		logger.info("Wait till Requested Item displayed");
	});
	element(by.xpath(this.linkRequestedItemXpath)).isDisplayed().then(function(){
		logger.info("RITM is displayed");
    });
	element(by.xpath(this.linkRequestedItemXpath)).click().then(function(){
		logger.info("Clicked on Requested Item - RITM Link");
    });
}

snow.prototype.clickStateDropdownFromRequestedItemsTab = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.requestedItemStateDropdownCss))),30000).then(function(){
		logger.info("Wait till Requested Item State dropdown displayed");
	});
	element(by.css(this.requestedItemStateDropdownCss)).click().then(function(){
		logger.info("Clicked on Requested Item - State dropdown");
    });
}

snow.prototype.selectCloseCompleteStateFromRequestedItemsTab = function(){
	element(by.css(this.requestedItemClosedCompleteOptionCss)).click().then(function(){
		logger.info("Clicked on Requested Item - Close Complete option from State dropdown");
    });
}

snow.prototype.clickUpdateButton = function(){
	element(by.css(this.navbarUpdateButtonCss)).click().then(function(){
		logger.info("Clicked on Update button");
		browser.sleep(3000);
    });
}

snow.prototype.clickCatalogTasksTab = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.catalogTasksTabCss))),30000).then(function(){
		logger.info("Wait till Catalog Tasks tab displayed");
	});
	element(by.css(this.catalogTasksTabCss)).click().then(function(){
		logger.info("Clicked on Catalog Task tab");
    });
}

snow.prototype.clickCatalogTaskLink = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.linkCatalogTaskXpath))),90000);
	element(by.xpath(this.linkCatalogTaskXpath)).click().then(function(){
		logger.info("Clicked on Catalog Task link");
    });
}

snow.prototype.clickConfigurationItemButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonConfigurationItemCss))),90000);
	element(by.css(this.buttonConfigurationItemCss)).click().then(function(){
		logger.info("Clicked on Configuration Item Button in Requested Item page");
    });
}

snow.prototype.clickChangeRequestStateDropdown = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.dropdownChangeRequestStateCss))),90000);
	element(by.css(this.dropdownChangeRequestStateCss)).click().then(function(){
		logger.info("Clicked on Change Request Type dropdown");
    });
}

snow.prototype.clickChangeRequestChangeTasksButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonChangeRequestChangeTasksCss))),90000);
	element(by.css(this.buttonChangeRequestChangeTasksCss)).click().then(function(){
		logger.info("Clicked on Change Request in Change Tasks");
    });
}

snow.prototype.clickNotifySerDeskNumLink = function(){
	var elem = element(by.xpath(this.linkNotifySerDeskNumXpath));
	browser.wait(EC.elementToBeClickable(elem),90000);	
	elem.click().then(function(){
		logger.info("Clicked on Notify Service Desk Number Link");
    });
}

snow.prototype.clickImplementNumLink = function(){
	var elem = element(by.xpath(this.linkImplementNumXpath));
	browser.wait(EC.elementToBeClickable(elem),90000);
	browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());
	elem.click().then(function(){
		logger.info("Clicked on Implement Number Link");
    });
}

snow.prototype.clickPostImplementNumLink = function(){
	var elem = element(by.xpath(this.linkPostImplementNumXpath));
	browser.wait(EC.elementToBeClickable(elem),90000);	
	elem.click().then(function(){
		logger.info("Clicked on Post Implement Number Link");
    });
}

snow.prototype.clickCloseTaskButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonCloseTaskCss))),90000);
	element(by.css(this.buttonCloseTaskCss)).click().then(function(){
		logger.info("Clicked on Close Task button");
    });
}

snow.prototype.clickChangeReqClosureInfoTab = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.tabChangeReqClosureInfoXpath))),90000);
	element(by.xpath(this.tabChangeReqClosureInfoXpath)).click().then(function(){
		logger.info("Clicked Closure Information in Change Request");
    });
}

snow.prototype.clickChangeReqCloseCodeDropdown = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.dropdownChangeReqCloseCodeCss))),90000);
	element(by.css(this.dropdownChangeReqCloseCodeCss)).click().then(function(){
		logger.info("Clicked on Close Code dropdown");
    });
}

snow.prototype.enterChangeReqCloseNotesText = function(){
	var elem = element(by.css(this.textChangeReqCloseNotesCss));
	browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());
	browser.wait(EC.visibilityOf(elem),90000);
	elem.sendKeys(this.closeNotesText).then(function(){
		logger.info("Entered Success in Close Notes");
    });
}

snow.prototype.clickCloseChangeRequestButton = function(){
	var close = element(by.css(this.buttonCloseChangeRequestCss));
	//browser.executeScript("arguments[0].scrollIntoView();", close.getWebElement());
	browser.executeScript('window.scrollTo(0,0)');
	browser.wait(EC.elementToBeClickable(close),90000);
	close.click().then(function(){
		logger.info("Clicked on Close Request button");
		browser.sleep(6000);
    });
}

snow.prototype.clickBackButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonBackCss))),90000);
	element(by.css(this.buttonBackCss)).click().then(function(){
		logger.info("Clicked on Back button");
    });
}

snow.prototype.clickAWServiceAcctLink = function(){
	this.switchToParentFrame();
	browser.wait(EC.elementToBeClickable(element(by.linkText(this.linkTextAWSacct))),90000);
	element(by.linkText(this.linkTextAWSacct)).click().then(function(){
		logger.info("Clicked on AWS service account link");
    });
}

snow.prototype.clickAzureServiceAcctLink = function(){
	this.switchToParentFrame();
	browser.wait(EC.elementToBeClickable(element(by.linkText(this.linkTextAzureAcct))),90000);
	element(by.linkText(this.linkTextAzureAcct)).click().then(function(){
		logger.info("Clicked on Azure service account link");
    });
}

snow.prototype.clickVRAServiceAcctLink = function(){
	this.switchToParentFrame();
	browser.wait(EC.elementToBeClickable(element(by.linkText(this.linkTextVRAcct))),90000);
	element(by.linkText(this.linkTextVRAcct)).click().then(function(){
		logger.info("Clicked on VRA service account link");
    });
}

snow.prototype.clickDiscoverNowLink = function(){
	browser.wait(EC.elementToBeClickable(element(by.linkText(this.linkTextDiscoverNow))),90000);
	element(by.linkText(this.linkTextDiscoverNow)).click().then(function(){
		logger.info("Clicked on Discover now link");
		browser.sleep(5000);
    });
}

snow.prototype.clickSysIDLink = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.linkSysIDCss))),90000);
	element(by.css(this.linkSysIDCss)).click().then(function(){
		logger.info("Clicked on SysID link to refresh status");
    });
}

snow.prototype.clickVMInstanceInCILink = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.linkVMInstanceInCIXpath))),90000);
	element(by.xpath(this.linkVMInstanceInCIXpath)).click().then(function(){
		logger.info("Clicked on VM Instance in CI");
    });
}

snow.prototype.clickVMInstanceInCILinkVRA = function(name){
	browser.wait(EC.elementToBeClickable(element.all(by.xpath("//a[text()[contains(.,'"+name+"')] and @class='ng-binding']")).get(1)),90000);
	element.all(by.xpath("//a[text()[contains(.,'"+name+"')] and @class='ng-binding']")).get(1).click().then(function(){
		logger.info("Clicked on VM Instance in CI");
    });
}

snow.prototype.clickVMInstanceInCILinkAzure = function(){
	browser.wait(EC.elementToBeClickable(element.all(by.xpath(this.linkVMInstanceInCIAzXpath)).get(0)),90000);
	element.all(by.xpath(this.linkVMInstanceInCIAzXpath)).get(0).click().then(function(){
		logger.info("Clicked on VM Instance in CI");
    });
}

//Change task link in Change Request
snow.prototype.clickChangeTaskLinktext = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.textChangeTaskXpath))),90000);
	element(by.xpath(this.textChangeTaskXpath)).click().then(function(){
		logger.info("Clicked on Change Task link");
    });
}

//Show other active tasks button in Change task
snow.prototype.clickOtherActiveTasksInChangeTaskButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonOtherActiveTasksInChangeTaskCss))),90000);
	element(by.css(this.buttonOtherActiveTasksInChangeTaskCss)).click().then(function(){
		logger.info("Clicked on Show other active tasks button in Change task");
    });
}

//Incident link in Change Task
snow.prototype.clickIncidentLinktext = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.textIncidentXpath))),90000);
	element(by.xpath(this.textIncidentXpath)).click().then(function(){
		logger.info("Clicked on Incident link");
    });
}

//Resolution Information tab in Incident
snow.prototype.clickIncResolutionInfoTab = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.tabIncResolutionInfoXpath))),90000);
	element(by.xpath(this.tabIncResolutionInfoXpath)).click().then(function(){
		logger.info("Clicked on Resolution Information tab");
    });
}

snow.prototype.selectChangeRequestStateDropdownValue = function(state){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(self.dropdownValuesChangeRequestStateCss))),90000);
	element.all(by.css(self.dropdownValuesChangeRequestStateCss)).getText().then(function(value){
		for(var i=0; i<value.length; i++) {
			if(value[i] == state) {
				element.all(by.css(self.dropdownValuesChangeRequestStateCss)).get(i).click().then(function(){
					logger.info("Selected " + state + " from Change Request State dropdown");
				})
			}
		}
    });
}

snow.prototype.selectAssignmentGroupValue = function(){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(self.textboxAssignmentGroupCss))),90000);
	element(by.css(self.textboxAssignmentGroupCss)).clear().then(function(){
		element(by.css(self.textboxAssignmentGroupCss)).sendKeys("CAB");
		browser.sleep(2000);
		element(by.css(self.textboxAssignmentGroupCss)).sendKeys(protractor.Key.ARROW_DOWN).then(function(){
			element(by.css(self.textboxAssignmentGroupCss)).sendKeys(protractor.Key.ENTER).then(function(){
				logger.info("Selected CAB approval");
			});
		});
	})
}

snow.prototype.selectCloseCompleteStateFromCatalogTasksTab = function(){
	element(by.css(this.catalogTaskClosedCompleteOptionCss)).click().then(function(){
		logger.info("Clicked on Catalog Task - Close Complete option from State dropdown");
    });
}

snow.prototype.selectChangeReqCloseCodeDropdownValue = function(option){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(self.dropdownValuesChangeReqCloseCodeCss))),90000);
	element.all(by.css(self.dropdownValuesChangeReqCloseCodeCss)).getText().then(function(value){
		for(var i=0; i<value.length; i++) {
			if(value[i] == option) {
				element.all(by.css(self.dropdownValuesChangeReqCloseCodeCss)).get(i).click().then(function(){
					logger.info("Selected " + option + " from Close Code dropdown");
				})
			}
		}
    });
	self.clickChangeReqCloseCodeDropdown();
}

snow.prototype.enterRejectComments = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textRejectCommentsCss))),90000);
	element(by.css(this.textRejectCommentsCss)).sendKeys(this.rejectComment).then(function() {
		logger.info("Entered Reject comment");
	})
}

snow.prototype.getTextItemStage = function(){
	return element(by.css(this.requestItemStageCss)).getText().then(function(state){
		logger.info("Request State: "+state);
		return state;
	})
}

snow.prototype.getApproverStatus = function(){
	return element(by.css(this.approverStateCss)).getText().then(function(state){
		logger.info("Approver State: "+state);
		return state;
	})
}


snow.prototype.getApprovalControllerText = function(){
	var webElement = element(by.css(this.approvalControllerCss));
	browser.wait(EC.visibilityOf(webElement),90000)
	return webElement.getText().then(function(state){
		logger.info("Approval Controller is: "+state);
		return state;
	})
}

snow.prototype.getApprovalText = function(){
	var webElement = element(by.css(this.approvalCss));
	browser.wait(EC.visibilityOf(webElement),90000)
	return webElement.getText().then(function(state){
		logger.info("Approval is : "+state);
		return state;
	})
}

snow.prototype.getTextApprovalAfterFirstApproval = function(){
	var webElement = element(by.css(this.textApprovalAfterFirstApprovalCss));
	browser.wait(EC.visibilityOf(webElement),90000)
	return webElement.getAttribute("value").then(function(state){
		logger.info("Approval is : "+state);
		return state;
	})
}

snow.prototype.getRequestedStateText = function(){
	var webElement = element(by.css(this.requestedStateCss));
	browser.wait(EC.visibilityOf(webElement),90000)
	return webElement.getText().then(function(state){
		logger.info("Requested state is : "+state);
		return state;
	})
}

snow.prototype.getTextRequestedStateAfterFirstApproval = function(){
	var webElement = element(by.css(this.textRequestedStateAfterFirstApprovalCss));
	browser.wait(EC.visibilityOf(webElement),90000)
	return webElement.getAttribute("value").then(function(state){
		logger.info("Requested state value is : "+state);
		return state;
	})
}

snow.prototype.getTextExternalApproval = function(){
	var webElement = element(by.css(this.textExternalApprovalCss));
	browser.wait(EC.visibilityOf(webElement),90000)
	return webElement.getText().then(function(state){
		logger.info("External Approval is : "+state);
		return state;
	})
}

snow.prototype.getTextStage = function(){
	var webElement = element(by.css(this.textStageCss));
	browser.wait(EC.visibilityOf(webElement),90000)
	return webElement.getText().then(function(state){
		logger.info("Stage is : "+state);
		return state;
	})
}

snow.prototype.getTextStageAfterFirstApproval = function(){
	var webElement = element(by.css(this.textStageAfterFirstApprovalCss));
	browser.wait(EC.visibilityOf(webElement),90000)
	return webElement.getAttribute("value").then(function(state){
		logger.info("Stage value is : "+state);
		return state;
	})
}

snow.prototype.getTextShortDescription = function(){
	var webElement = element(by.css(this.textShortDescCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute("value").then(function(state){
		logger.info("Short Description is : "+state);
		return state;
	})
}

snow.prototype.getOrderNumberText = function(){
	var webElement = element(by.css(this.orderNumberCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute('value').then(function(state){
		logger.info("Order Number is : "+state);
		return state;
	})
}

snow.prototype.getTextCloudBrokerLocation = function(){
	var webElement = element(by.css(this.textCldBrokerLocCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute('value').then(function(state){
		logger.info("Cloud Broker Location is : "+state);
		return state;
	})
}

snow.prototype.getTextRequestedItem = function(){
	var webElement = element(by.css(this.textRequestedItemCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute('value').then(function(state){
		logger.info("Requested Item is : "+state);
		return state;
	})
}

snow.prototype.getTextRequestedItemStage = function(){
	var webElement = element(by.css(this.textRequestedItemStageCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute('value').then(function(state){
		logger.info("Requested Item Stage is : "+state);
		return state;
	})
}

snow.prototype.getTextRequestedItemState = function(){
	var webElement = element(by.css(this.textRequestedItemStateCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(state){
		logger.info("Requested Item State is : "+state);
		return state;
	})
}

snow.prototype.getTextRequestedItemShortDesc = function(){
	var webElement = element(by.css(this.textRequestedItemShortDescCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute('value').then(function(state){
		logger.info("Requested Item Short Description is : "+state);
		return state;
	})
}

snow.prototype.getTextReqItemVariableSerOfferName = function(){
	var webElement = element(by.css(this.textReqItemVariableSerOfferNameCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute('value').then(function(state){
		logger.info("Requested Item Variables Service Offering Name is : "+state);
		return state;
	})
}

snow.prototype.getTextReqItemVariableSerOfferDesc = function(){
	var webElement = element(by.css(this.textReqItemVariableSerOfferDescCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute('value').then(function(state){
		logger.info("Requested Item Variables Service Offering Description is : "+state);
		return state;
	})
}

snow.prototype.getTextReqItemVariableChangeType = function(){
	var webElement = element(by.css(this.textReqItemVariableChangeTypeCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(state){
		logger.info("Requested Item Variables Change Type is : "+state);
		return state;
	})
}

snow.prototype.getTextReqItemVariableSerOfferingID = function(){
	var webElement = element(by.css(this.textReqItemVariableSerOfferingIDCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute('value').then(function(state){
		logger.info("Service Offering ID is : "+state);
		return state;
	})
}

snow.prototype.getTextReqItemVariableSOProvider = function(){
	var webElement = element(by.css(this.textReqItemVariableSOProviderCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute('value').then(function(state){
		logger.info("Requested Item Variables Service Offering Provider is : "+state);
		return state;
	})
}

snow.prototype.getTextReqItemVariableConCategory = function(){
	var webElement = element(by.css(this.textReqItemVariableConCategoryCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute('value').then(function(state){
		logger.info("Requested Item Variables Consume Category is : "+state);
		return state;
	})
}

snow.prototype.getTextReqItemVariableServiceName = function(){
	var webElement = element(by.css(this.textReqItemVariableServiceNameCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute('value').then(function(state){
		logger.info("Requested Item Variables Service Name is : "+state);
		return state;
	})
}

snow.prototype.getTextReqItemConfigValuesBasedOnName = function(name){
	this.switchToDefaultContent();
	this.switchToParentFrame();
	browser.switchTo().frame(element(by.css(this.frameConfigValuesCss)).getWebElement());
	return element(by.xpath('//td[contains(text(), "'+name+'")]/following-sibling::td[1]')).getText().then(function(value){
        logger.info("Value for "+name+" in Requested Item is : "+value);
        return value;
    });
}

snow.prototype.getTextReqItemConfigValuesBasedOnNameAz = function(name){
	this.switchToDefaultContent();
	this.switchToParentFrame();
	browser.switchTo().frame(element(by.css(this.frameConfigValuesCss)).getWebElement());
	return element.all(by.xpath('//td[contains(text(), "'+name+'")]/following-sibling::td')).get(1).getText().then(function(value){
        logger.info("Value for "+name+" in Requested Item is : "+value);
        return value;
    });
}

snow.prototype.getTextReqItemConfigValuesBasedOnNameAzII = function(name){
	this.switchToDefaultContent();
	this.switchToParentFrame();
	browser.switchTo().frame(element(by.css(this.frameConfigValuesCss)).getWebElement());
	return element.all(by.xpath('//td[contains(text(), "'+name+'")]/following-sibling::td')).get(2).getText().then(function(value){
        logger.info("Value for "+name+" in Requested Item is : "+value);
        return value;
    });
}

snow.prototype.getTextReqItemAddOnValuesBasedOnName = function(name){
	this.switchToDefaultContent();
	this.switchToParentFrame();
	browser.switchTo().frame(element(by.css(this.frameAddOnValuesCss)).getWebElement());
	return element(by.xpath('//td[contains(text(), "'+name+'")]/following-sibling::td[1]')).getText().then(function(value){
        logger.info("Value for "+name+" in Requested Item is : "+value);
        return value;
    });
}

snow.prototype.getAddOnServiceNameFromRITM = function(){
	this.switchToDefaultContent();
	this.switchToParentFrame();
	browser.switchTo().frame(element(by.css(this.frameAddOnValuesCss)).getWebElement());
	return element.all(by.css(this.addOnTableCaptionCss)).first().getText().then(function(value){
        logger.info("Add-on Values Table Caption is: "+value);
		var addOnServiceName = value.split("-SNOW")[0];
		logger.info("Add-on Service name in Request Item is: "+addOnServiceName);
        return addOnServiceName;
    });
}

snow.prototype.getTextReqItemBOMCurrencyBasedServiceName = function(name,item){
	this.switchToDefaultContent();
	this.switchToParentFrame();
	browser.switchTo().frame(element(by.css(this.frameBOMcss)).getWebElement());
	var currencyXpath = this.addOnServiceBOMCurrencyXpath.format(name,item);
	return element (by.xpath(currencyXpath)).getText().then(function(value){
        logger.info("Currency for "+name+", "+item+" is : "+value);
        return value;
    });
}

snow.prototype.getTextReqItemBOMTotalBasedServiceName = function(name,item){
	this.switchToDefaultContent();
	this.switchToParentFrame();
	browser.switchTo().frame(element(by.css(this.frameBOMcss)).getWebElement());
	var totalMonthlyXpath = this.addOnServiceBOMTotalMonthlyXpath.format(name,item);
	return element (by.xpath(totalMonthlyXpath)).getText().then(function(value){
        logger.info("Total Monthly Cost for "+name+", "+item+" is : "+value);
        return value;
    });
}

snow.prototype.getTextReqItemBOMTotalVRA = function(){
	var self = this;
	self.switchToDefaultContent();
	self.switchToParentFrame();
	browser.switchTo().frame(element(by.css(self.frameBOMcss)).getWebElement());
	return browser.wait(EC.visibilityOf(element(by.xpath(self.textBOMcostXpath))),90000).then(function(){
		var sum = 0;		
		return element.all(by.xpath(self.textBOMcostXpath)).getText().then(function(value){
			for(var i=0; i<value.length; i++) {
				sum = parseInt(value[i]) + sum;
			}
			logger.info("Total cost is: " + sum);
			sum = sum.toString();
			self.switchToDefaultContent();
			return sum;
		});						
	})	
}

snow.prototype.getTextSerInstanceCIsResourceId = function(){
	var webElement = element(by.css(this.textSerInstanceCIsResourceIdCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(text){
		logger.info("Resource Id is : "+text);
		return text;
	})
}

snow.prototype.getTextSerInstanceCIsObjectId = function(){
	var webElement = element(by.css(this.textSerInstanceCIsObjectIdCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(text){
		logger.info("Object Id is : "+text);
		return text;
	})
}

snow.prototype.getTextSerInstanceCIsStatus = function(){
	var webElement = element(by.css(this.textSerInstanceCIsStatusCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(text){
		logger.info("Status is : "+text);
		return text;
	})
}

snow.prototype.getTextSerInstanceCIsStatusVRA = function(){
	var webElement = element(by.css(this.textSerInstanceCIsStatusVRACss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(text){
		logger.info("Status is : "+text);
		return text;
	})
}

snow.prototype.getTextSerInstanceCIsStatusDisc = function(){
	var webElement = element(by.css(this.textSerInstanceCIsStatusDiscCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(text){
		logger.info("Status is : "+text);
		return text;
	})
}

snow.prototype.getTextChangeRequestState = function(){
	var webElement = element(by.css(this.textChangeRequestStateCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(text){
		logger.info("Change Request State is : "+text);
		return text;
	})
}

snow.prototype.getTextChangeRequestCurrentState = function(){
	var webElement = element(by.css(this.textChangeRequestCurrentStateCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute("aria-label").then(function(text){
		logger.info("Current Change Request State is : "+text);
		return text;
	})
}

snow.prototype.getTextChangeReqClosedMsg = function(){
	var webElement = element(by.css(this.textChangeReqClosedMsgCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(text){
		logger.info("Change Request Closed message is : "+text);
		return text;
	})
}

snow.prototype.getCatalogItemText = function(){
	var webElement = element(by.css(this.catalogItemCss));
	browser.wait(EC.visibilityOf(webElement),30000).then(function(){
		logger.info("Wait till catalog item text is displayed");
	});
	return webElement.getAttribute('value').then(function(text){
		logger.info("Catalog Item is : "+text);
		return text;
	});
}

snow.prototype.getTextVMInstanceState = function(){
	var webElement = element(by.css(this.textVMInstanceStateCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(text){
		logger.info("VM Instance state is : "+text);
		return text;
	})
}

snow.prototype.getTextVMInstanceStateVRA = function(){
	var webElement = element(by.css(this.textVMInstanceVRACss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(text){
		logger.info("VM Instance state is : "+text);
		return text;
	})
}

snow.prototype.getTextIfResourceMappingIsChecked = function(){
	var webElement = element(by.css(this.checkboxValueResourceMappingCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute("checked").then(function(text){
		if(text=="true") {
			logger.info("Resource Mapping is checked : "+text);
		}
		else {
			logger.info("Resource Mapping is not checked : "+text);
			return text;
		}
	return text;		
	})
}

snow.prototype.getTextDiscoveryState= function(){
	var webElement = element(by.css(this.textDiscoveryStateCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(text){
		logger.info("Discovery state is : "+text);
		return text;
	})
}

snow.prototype.getTextVMCPU = function(){
	var webElement = element(by.css(this.textVMcpuCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute("value").then(function(text){
		logger.info("VM CPU value is : "+text);
		return text;
	})
}

snow.prototype.getTextVMemory = function(){
	var webElement = element(by.css(this.textVMmemoryCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute("value").then(function(text){
		logger.info("VM Memory value is : "+text);
		return text;
	})
}

//Retrieve State of Catalog Task
snow.prototype.getTextCatalogTaskState= function(){
	var webElement = element(by.css(this.textCatalogTaskStateCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(text){
		logger.info("Catalog Task state is : "+text);
		return text;
	})
}

//Retrieve State of Change Task
snow.prototype.getTextChangeTaskState = function(){
	var webElement = element(by.css(this.textChangeTaskState));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(state){
		logger.info("Change Task state is: "+state);
		return state;
	})
}

//Retrieve the first activity log in Change task
snow.prototype.getTextChangeTaskFirstActivity = function(){
	var webElement = element.all(by.css(this.textChangeTaskActivityCss)).get(0);
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(state){
		logger.info("Change Task first activity is: "+state);
		return state;
	})
}

//Retrieve the second activity log in Change task
snow.prototype.getTextChangeTaskSecondActivity = function(){
	var webElement = element.all(by.css(this.textChangeTaskActivityCss)).get(1);
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(state){
		logger.info("Change Task second activity is: "+state);
		return state;
	})
}

//Retrieve State of Incident
snow.prototype.getTextIncidentState = function(){
	var webElement = element(by.css(this.textIncidentState));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(state){
		logger.info("Incident state is: "+state);
		return state;
	})
}

//Retrieve Assignment group of Incident
snow.prototype.getTextIncAssignmentGroup = function(){
	var webElement = element(by.css(this.textIncAssignmentGroupCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute("value").then(function(state){
		logger.info("Incident Assignment Group is: "+state);
		return state;
	})
}

//Retrieve Short description of Incident
snow.prototype.getTextIncShortDesc = function(){
	var webElement = element(by.css(this.textIncShortDescCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute("value").then(function(state){
		logger.info("Incident Short Description is: "+state);
		return state;
	})
}

//Retrieve Resolution code of Incident
snow.prototype.getTextIncResCode = function(){
	var webElement = element(by.css(this.textIncResCodeCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(state){
		logger.info("Incident Resolution code is: "+state);
		return state;
	})
}

//Retrieve Resolution code of Incident
snow.prototype.getTextIncResNotes = function(){
	var webElement = element(by.css(this.textIncResNotesCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(state){
		logger.info("Incident Resolution notes is: "+state);
		return state;
	})
}

snow.prototype.isPresentVMInstanceInCI = function(){
	browser.sleep(5000);
	return element(by.xpath(this.linkVMInstanceInCIXpath)).isPresent().then(function(state){
		if(state) {
			logger.info("Instance is present in CI : "+state);
		}
		else {
			logger.info("Instance is not present in CI : "+state);
			return state;
		}
	return state;		

	})
}

snow.prototype.isPresentVMInstanceInCIVRA = function(name){
	browser.sleep(5000);
	return element(by.xpath("//a[text()[contains(.,'"+name+"')] and @class='ng-binding']")).isPresent().then(function(state){
		if(state) {
			logger.info("Instance is present in CI : "+state);
		}
		else {
			logger.info("Instance is not present in CI : "+state);
			return state;
		}
	return state;		

	})
}

snow.prototype.isPresentVMInstanceInCIAzure = function(){
	browser.sleep(5000);
	return element(by.xpath(this.linkVMInstanceInCIAzXpath)).isPresent().then(function(state){
		if(state) {
			logger.info("Instance is present in CI : "+state);
		}
		else {
			logger.info("Instance is not present in CI : "+state);
			return state;
		}
	return state;		

	})
}

snow.prototype.isCatalogItemPresent = function(){
	return element(by.xpath(this.catalogTaskNumberLinkXapth)).isPresent().then(function(state){
		logger.info("Is Catalog Item Present : "+state);
		return state;
	})
}

snow.prototype.isChangeTaskCreated = function(repeatCount){
	let self = this;
	if(repeatCount == undefined){
		repeatCount = 10;
	}
	repeatCount = repeatCount-1;	
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.changeRequestLinkXpath))),30000).then(function(){
		logger.info("Wait till Change Request link is displayed");
	})
	element(by.xpath(this.changeRequestLinkXpath)).click().then(function(){
		logger.info("Clicked on Change Request link");
	});	
	if(repeatCount>0){	
		var changeTask = "//td[contains(text(),'Provisioning Task')]";
		element(by.xpath(changeTask)).isPresent().then(function(state){
		    logger.info("Is Change Task Created : " +state);	
			if(state)
				{
					logger.info("Change task is created");
					repeatCount = 0;
					return;
				}
			else
				{
					browser.sleep(10000);
					self.isChangeTaskCreated(repeatCount);
					logger.info("Waiting for Change Task to be created");
				}
    		});   
		}	
}


snow.prototype.getBrokerRequestTypeText = function(){
	var webElement = element(by.css(this.brokerRequestTypeCss));
	browser.wait(EC.visibilityOf(webElement),30000).then(function(){
		logger.info("Wait till broker request type text is displayed");
	});
	return webElement.getText().then(function(state){
		logger.info("Broker Request type is : "+state);
		return state;
	});
}


snow.prototype.loginToSNOWPortal = function () {
	isAngularApp(false);
	browser.get(snowLoginObj.url+"/logout.do").then(function(){
		logger.info("Pre-Condition :: Logged out from SNOW portal");
	})
	browser.get(snowLoginObj.url).then(function(){
		logger.info("Opened snow portal");
	})
	orderFlowUtil.waitForSNOWLoginPage();
	element(by.css(this.usernameInputCss)).sendKeys(snowLoginObj.username).then(function(){
		logger.info("Entered username");
	})
	element(by.css(this.passwordInputCss)).sendKeys(snowLoginObj.password).then(function(){
		logger.info("Entered password");
	})
	element(by.css(this.loginButtonCss)).click().then(function(){
		logger.info("Clicked on Login button");
		browser.sleep(10000);//Sleep, as it takes some time to load page completely
	})
	this.switchToParentFrame();
	/*browser.wait(EC.visibilityOf(element(by.css(this.addContentButtonCss))),60000).then(function(){
		logger.info("Wait till Add Content button is displayed");
	});*/
	this.switchToDefaultContent();
}

snow.prototype.loginToSNOWDropletPortal = function () {
	isAngularApp(false);
	browser.get(snowDropletLoginObj.url+"/logout.do").then(function(){
		logger.info("Pre-Condition :: Logged out from SNOW portal");
	})
	browser.get(snowDropletLoginObj.url).then(function(){
		logger.info("Opened snow portal");
	})
	orderFlowUtil.waitForSNOWLoginPage();
	element(by.css(this.usernameInputCss)).sendKeys(snowDropletLoginObj.username).then(function(){
		logger.info("Entered username");
	})
	element(by.css(this.passwordInputCss)).sendKeys(snowDropletLoginObj.password).then(function(){
		logger.info("Entered password");
	})
	element(by.css(this.loginButtonCss)).click().then(function(){
		logger.info("Clicked on Login button");
		browser.sleep(10000);//Sleep, as it takes some time to load page completely
	})
	this.switchToDefaultContent();
	//browser.switchTo().frame(browser.driver.findElement(protractor.By.id(this.mainIframeId)));
	/*browser.wait(EC.visibilityOf(element(by.css(this.addContentButtonCss))),60000).then(function(){
		logger.info("Wait till Add Content button is displayed");
	});*/
	//browser.switchTo().defaultContent();
}

snow.prototype.logoutFromSNOWPortal = function(){
	browser.get(snowLoginObj.url+"/logout.do").then(function(){
		logger.info("Logged out from SNOW portal");
	})
}

snow.prototype.approveCatalogTask = function(){
	this.clickCatalogTasksTab();
	this.clickNumberLinkFromCatalogTasksTab();
	this.clickStateDropdownFronCatalogTasksTab();
	this.selectCloseCompleteStateFromCatalogTasksTab();
	this.clickUpdateButton();
}

snow.prototype.logInToSnowPortalAndCompleteTheRequest = function(ticketID, estimatedPrice){
	//Login to SNOW Portal
	this.loginToSNOWPortal();
	//Approve the request
	this.clickFavouritesStar();
	this.searchRequestsText();
	this.clickServiceCatalogRequestLink();
	this.searchSRNumber(ticketID);
	this.clickRequestNumberLink();
	logger.info("Estimated Price before if : "+ estimatedPrice);
	if(parseInt(estimatedPrice) > 1000){
		logger.info("Estimated Price from if : "+ estimatedPrice);
		this.clickApproversTab();
		this.clickRequestedLinkFromApproversTab();
		this.clickApproveButton();
	}
	this.clickRequestedItemsTab();
	this.clickRequestedItemLink();
	this.clickStateDropdownFromRequestedItemsTab();
	this.selectCloseCompleteStateFromRequestedItemsTab();
	this.clickUpdateButton();
	//Complete Catalog Task 1
	this.clickRequestedItemsTab();
	this.clickRequestedItemLink();
	this.approveCatalogTask();
	//Complete Catalog Task 2
	this.approveCatalogTask();
	//Complete Catalog Task 3
	this.approveCatalogTask();
	//Complete Catalog Task 4
	this.approveCatalogTask();
	//Final Order status and logout
	return this.getRequestStatus().then(function(status){
		browser.get(snowLoginObj.url+"/logout.do").then(function(){
			logger.info("Logged out from SNOW portal");
		})
		return status;
	});
}


snow.prototype.logInToSnowDropletPortalAndSearchOrder = function(ticketID){
	//Login to SNOW Portal
	this.loginToSNOWDropletPortal();
	this.clickFavouritesStar();
	this.searchRequestsText();
	this.clickServiceCatalogRequestLink();
	this.searchOrderNumberUntilExists(ticketID);
	this.clickRequestNumberLink();
}

snow.prototype.logInToSnowDropletPortalAndSearchOrderNotExists = function(ticketID){
	//Login to SNOW Portal
	this.loginToSNOWDropletPortal();
	this.clickFavouritesStar();
	this.searchRequestsText();
	this.clickServiceCatalogRequestLink();
	this.searchOrderNumColumn(ticketID);
}

snow.prototype.approveTheServiceNowRequestFromSnowPortal = function(){
	//Approve the request
	this.clickApproversTab();
	this.clickRequestedLinkFromApproversTab();
	this.clickApproveButton();
	this.clickRequestedItemsTab();
}

snow.prototype.rejectTheServiceNowRequestFromSnowPortal = function(){
	//Reject the request
	this.clickApproversTab();
	this.clickRequestedLinkFromApproversTab();
	this.enterRejectComments();
	this.clickRejectButton();
	this.clickRequestedItemsTab();
}

snow.prototype.secondApprovalWithChangeTaskCreated = function(){	
	this.clickOnRequestedItemsTab();
	this.clickRequestedItemLink();
	this.clickOnRelatedChangeRequestButton();
	this.clickOnOpenRecordButton();
	this.clickOnApproversTabInChangeRequest();
	this.clickOnCheckboxInChangeRequest();
	this.clickRequestedLinkFromApproversTab();
	this.clickApproveButton();
	this.clickChangeTaskTabInChangeRequest();
	this.isChangeTaskCreated();	
}

snow.prototype.verifytheApprovalLinkFromSnowPortal = function(ticketID){	
	browser.get(snowDropletLoginObj.url);
	this.clickFavouritesStar();
	this.searchRequestsText();
	this.clickServiceCatalogRequestLink();
	this.searchOrderNumber(ticketID);
	this.clickRequestNumberLink();
	this.clickApproversTab();
	this.clickApprovedLinkFromApproversTab();
}

snow.prototype.verifyCatalogItemFromSnowPortal = function(){	
	this.clickLeftNavigation();
	this.clickOnRequestedItemsTab();
	this.clickRequestedItemLink();
}

snow.prototype.navigateToSnowPortal = function(ticketID){	
	browser.get(snowDropletLoginObj.url);
	this.clickFavouritesStar();
	this.searchRequestsText();
	this.clickServiceCatalogRequestLink();
	this.searchOrderNumber(ticketID);
	this.clickRequestNumberLink();
}

snow.prototype.setFlagToNormal = function(){	
	browser.get(snowDropletLoginObj.url);
	this.switchToDefaultContent();
	this.clickOnFavouriteTab();
	//this.clickHCMSBrokerIntegration();
	this.clickBrokerCatalogItems();
	this.clickICBProvision();
	this.clickOnVariableSet();
	this.clickOnVsItemVariableSet();
	this.clickOnVarChangeType();
	this.clickOnDefaultValue();
	this.setValueToNormal();
}

snow.prototype.setFlagToStandard = function(){	
	browser.get(snowDropletLoginObj.url);
	this.switchToDefaultContent();
	this.clickOnFavouriteTab();
	//this.clickHCMSBrokerIntegration();
	this.clickBrokerCatalogItems();
	this.clickICBProvision();
	this.clickOnVariableSet();
	this.clickOnVsItemVariableSet();
	this.clickOnVarChangeType();
	this.clickOnDefaultValue();
	this.setValueToStandard();
}

snow.prototype.validateExtraApproval = function(){	
	//browser.get(snowDropletLoginObj.url);
	this.clickRequestedItemsTab();
	this.clickRequestedItemLink();
	this.clickOnRelatedChangeRequestButton();
	this.clickOnOpenRecordButton();
	this.clickOnApproversTabInChangeRequest();
	this.clickOnCheckboxInChangeRequest();
	this.clickRequestedLinkFromApproversTab();
	this.clickApproveButton();
	this.clickRequestedItemsTab();
}

snow.prototype.getRequestNumber = function(){
	var webElement = element(by.css(this.txtReqstNumberCss));
	//webElement.click();
	browser.wait(EC.elementToBeClickable(webElement),60000).then(function(){
		return webElement.getAttribute('value').then(function(requestNumber){
			logger.info("Request Number is : " + requestNumber);
			return requestNumber;
		});	
	});	
}

snow.prototype.openConfItemServiceInstanceCIs = function(){	
	this.clickConfigurationItemButton();
	this.clickOnOpenRecordButton();	
}

snow.prototype.openRelatedChangeRequest = function(){	
	this.clickOnRelatedChangeRequestButton();
	this.clickOnOpenRecordButton();
}

snow.prototype.selectChangeReqStatesWithAssignGrpAndUpdate = function(dropdownValue){	
	this.openRelatedChangeRequest();
	this.clickChangeRequestStateDropdown();
	this.selectChangeRequestStateDropdownValue(dropdownValue);
	this.selectAssignmentGroupValue();
	this.clickUpdateButton();
}

snow.prototype.selectChangeReqStatesAndUpdate = function(dropdownValue){	
	this.clickChangeRequestStateDropdown();
	this.selectChangeRequestStateDropdownValue(dropdownValue);
	this.clickUpdateButton();
}

snow.prototype.selectChangeReqStateOnChangeReqPage = function(dropdownValue){	
	this.clickChangeRequestStateDropdown();
	this.selectChangeRequestStateDropdownValue(dropdownValue);
	this.selectAssignmentGroupValue();
	this.clickUpdateButton();
}

snow.prototype.selectChangeReqState = function(dropdownValue){	
	this.clickChangeRequestStateDropdown();
	this.selectChangeRequestStateDropdownValue(dropdownValue);
}

snow.prototype.approveChangeRequestForEachState = function(){	
	this.clickOnApproversTabInChangeRequest();
	this.clickRequestedLinkFromApproversTab();
	this.clickApproveButton();
}

snow.prototype.rejectChangeRequest = function(){	
	this.clickOnApproversTabInChangeRequest();
	this.clickRequestedLinkFromApproversTab();
	this.enterRejectComments();
	this.clickRejectButton();
}

snow.prototype.checkIfProvisioningTaskClosed = function(){	
	this.clickChangeTaskTabInChangeRequest();
	this.waitUntilProvisioningTaskClosed();
}

snow.prototype.closeNotifySerDeskTask = function(){	
	this.clickNotifySerDeskNumLink();
	this.selectCTStateDropdownValue();
	this.selectAssignGrpValueChangeTask();
	this.selectAssignedToValueChangeTask();
	this.enterChangeTaskDescription();
	this.clickUpdateButton();
}

snow.prototype.closeImplementTask = function(){	
	this.clickImplementNumLink();
	this.selectCTStateDropdownValue();
	this.selectAssignGrpValueChangeTask();
	this.selectAssignedToValueChangeTask();
	this.enterChangeTaskDescription();
	this.clickUpdateButton();
}

snow.prototype.closePostImplementTestTask = function(){	
	this.clickPostImplementNumLink();
	this.selectCTStateDropdownValue();
	this.clickUpdateButton();
}

snow.prototype.closeChangeRequest = function(codeValue){	
	this.clickChangeReqClosureInfoTab();
	this.clickChangeReqClosureInfoTab();
	this.clickChangeReqCloseCodeDropdown();
	this.selectChangeReqCloseCodeDropdownValue(codeValue);
	this.enterChangeReqCloseNotesText();			
	this.clickCloseChangeRequestButton();
	util.switchToAlertIfPresent();
}

snow.prototype.openDiscoverySchedules = function(){
	this.loginToSNOWDropletPortal();
	this.searchDiscoveryText();
	this.clickDiscoverySchedulesLink();
}

snow.prototype.runDiscoveryForAWS = function(){	
	this.clickAWServiceAcctLink();
	this.clickDiscoverNowLink();
	this.waitUntilDiscoveryCompleted();
}

snow.prototype.runDiscoveryForAzure = function(){	
	this.clickAzureServiceAcctLink();
	this.clickDiscoverNowLink();
	this.waitUntilDiscoveryCompleted();
}

snow.prototype.runDiscoveryForVRA = function(){	
	this.clickVRAServiceAcctLink();
	this.clickDiscoverNowLink();
	this.waitUntilDiscoveryCompleted();
}

snow.prototype.openChangeTask = function(){	
	this.clickChangeTaskTabInChangeRequest();
	this.clickChangeTaskLinktext();
}

snow.prototype.openIncident = function(){	
	this.clickOtherActiveTasksInChangeTaskButton();
	this.clickIncidentLinktext();
}

snow.prototype.searchOrderNumberUntilExists = function(orderNum,repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 80;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0){
		self.searchOrderNumColumn(orderNum);
		element(by.xpath(self.requestNumberLinkXpath)).isPresent().then(function(value) {
			if(value) {
				logger.info("Order Found");
				repeatCount = 0;
				return;
			}
			else {
				logger.info("Order not found, searching again");
				self.switchToDefaultContent();
				self.searchOrderNumberUntilExists(orderNum,repeatCount);
			}
		})
	}
}

snow.prototype.waitUntilApprovalIsReqExtAppTrue = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 35;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		element(by.css(self.approvalCss)).isPresent().then(function(state) {
			if(state) {
				logger.info("Approval is not Requested, waiting: " + state);
				browser.sleep(2000);
				self.waitUntilApprovalIsReqExtAppTrue(repeatCount);
			}
			else {
				logger.info("Approval is Requested: " + state);
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilApprovalIsRequested = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 35;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		element(by.css(self.approvalCss)).isPresent().then(function(state) {
			if(state) {
				browser.wait(EC.visibilityOf(element(by.css(self.approvalCss))),90000);
				element(by.css(self.approvalCss)).getText().then(function(state) {
					if(state == "Not Yet Requested") {
						logger.info("Approval is not Requested, refreshing page: " + state);
						browser.navigate().refresh();
						self.switchToParentFrame();
						self.waitUntilApprovalIsRequested(repeatCount);
					}
					else if(state == "Approved") {
						logger.info("Approval is not Requested, refreshing page: " + state);
						browser.navigate().refresh();
						self.switchToParentFrame();
						self.waitUntilApprovalIsRequested(repeatCount);
					}
					else {
						logger.info("Approval is Requested: " + state);
						repeatCount = 0;
						return;
					}
				})
			}
			else {
					browser.wait(EC.visibilityOf(element(by.css(self.buttonBackCss))),90000).then(function () {
						logger.info("Approval is not in stable requested state: ");
					}).catch(function (err) {
						browser.sleep(30000);
						logger.info("Exception occured as No Such Window");
					});
					self.clickBackButton();
					self.clickRequestNumberLink();
					self.waitUntilApprovalIsRequested(repeatCount);
			}
		})		
	}
}

snow.prototype.waitUntilApprovalIsApproved = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 10;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		browser.wait(EC.visibilityOf(element(by.css(self.approvalCss))),90000);
		element(by.css(self.approvalCss)).getText().then(function(state) {
			if(state == "Not Yet Requested") {
				logger.info("Approval is not Approved, refreshing page: " + state);
				browser.navigate().refresh();
				browser.sleep(30000);
				self.switchToParentFrame();
				self.waitUntilApprovalIsApproved(repeatCount);
			}
			else {
				logger.info("Approval is Approved: " + state);
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilProvisioningTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element(by.xpath(self.textChangeTaskProvTaskStateXpath));
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());
		browser.wait(EC.visibilityOf(task),30000);
		browser.sleep(2000);
		task.getText().then(function(state) {
			if(state == "Open") {
				logger.info("Provisioning task is Open => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilProvisioningTaskClosed(repeatCount);
			}
			else if(state == "In Progress") {
				logger.info("Provisioning task is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilProvisioningTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Provisioning task is Closed");
				repeatCount = 0;
				return;
			}
			else {
				logger.info("Provisioning task is Pending");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitForProvisioningTaskChange = function(expectedState,repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		browser.wait(EC.visibilityOf(element(by.xpath(self.textChangeTaskProvTaskStateXpath))),30000);
		element(by.xpath(self.textChangeTaskProvTaskStateXpath)).getText().then(function(state) {
			if(state == expectedState) {
				logger.info("Provisioning task is changed to " + expectedState + ", breaking the loop");
				repeatCount = 0;
				return;
			}
			else {
				logger.info("Waiting for Provisioning task to be " + expectedState + ", continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitForProvisioningTaskChange(expectedState,repeatCount);
			}
		})
	}
}

snow.prototype.waitUntilDiscoveryCompleted = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 100000;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		browser.wait(EC.visibilityOf(element(by.css(self.textDiscoveryStateCss))),90000);
		element(by.css(self.textDiscoveryStateCss)).getText().then(function(state) {
			if(state == "Active") {
				logger.info("Discovery State is Active => Continue looping");
				self.clickSysIDLink();
				browser.sleep(6000);
				self.waitUntilDiscoveryCompleted(repeatCount);
			}
			else if(state == "Completed") {
				logger.info("Discovery State is Completed");
				repeatCount = 0;
				return;
			}
			else {
				logger.info("Discovery State is Starting => Continue looping");
				self.clickSysIDLink();
				browser.sleep(3000);
				self.waitUntilDiscoveryCompleted(repeatCount);
			}
		})
	}
}

snow.prototype.switchToParentFrame = function(){	
	browser.switchTo().frame(element(by.id(this.mainIframeId)).getWebElement());
}

snow.prototype.switchToDefaultContent = function(){	
	browser.switchTo().defaultContent();
}

//Right click on Navigation bar title
snow.prototype.rightClickNavbarTitle = function(){
	var navbarTitle = element(by.css(this.textNavbarTitleCss));
	browser.wait(EC.visibilityOf(navbarTitle),90000);
	browser.actions().mouseMove(navbarTitle).perform().then(function(){
		browser.sleep(2000);
		return browser.actions().click(protractor.Button.RIGHT).perform().then(function(){
	    	logger.info("Right Clicked on the navigation bar title");
	    })		
	})    
}

//Cancel Change in Change request page
snow.prototype.clickCancelChange = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.textCancelChangeXpath))),90000);
	element(by.xpath(this.textCancelChangeXpath)).click().then(function(){
		logger.info("Clicked on Cancel Change");
    });
}

//Cancel Change Request reason
snow.prototype.enterCancelChangeReason = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaCancelChangeReasonCss))),90000);
	element(by.css(this.textareaCancelChangeReasonCss)).sendKeys(this.cancelChangeReason).then(function(){
		logger.info("Entered reason for Cancel Change request");
    });
}

//Cancel Change Request reason OK button
snow.prototype.clickOkCancelChangeRequest = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.buttonCancelChangeOkCss))),90000);
	element(by.css(this.buttonCancelChangeOkCss)).click().then(function(){
		logger.info("Clicked on OK button of Cancel Change Request");
    });
}

snow.prototype.cancelChangeWithReason = function(){	
	this.rightClickNavbarTitle();
	this.clickCancelChange();
	//this.enterCancelChangeReason();
	//this.clickOkCancelChangeRequest();
}

//Retrieve Change Request state
snow.prototype.getTextChangeReqState= function(){
	var changeReqState = element(by.css(this.textChangeReqStateCss));
	browser.wait(EC.visibilityOf(changeReqState),90000);
	return changeReqState.getText().then(function(changeReqStateText){
		logger.info("Change Request State is: "+changeReqStateText);
		return changeReqStateText;
	})
}

snow.prototype.enterChangeTaskDescription = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaChangeTaskDescCss))),90000);
	element(by.css(this.textareaChangeTaskDescCss)).sendKeys(this.changeTaskDesc).then(function() {
		logger.info("Entered Change Task description");
	})
}

snow.prototype.isPresentCancelChange = function(){
	return element(by.xpath(this.textCancelChangeXpath)).isPresent().then(function(state){
		if(state) {
			logger.info("Cancel Change option is present : "+state);
		}
		else {
			logger.info("Cancel Change option is not present : "+state);
			return state;
		}
	return state;		

	})
}

/************************************SnowV2Cart FUNCTIONS******************************************/

//Retrieve total number of RITM links
snow.prototype.getCountOfRITMlinks = function(){
	browser.wait(EC.visibilityOf(element.all(by.xpath(this.linkRequestedItemXpath)).get(1)),30000);
	return element.all(by.xpath(this.linkRequestedItemXpath)).count().then(function(num){
		logger.info("Count of RITM links: " + num);
		return num;
    });
}

snow.prototype.clickFirstRequestedItemLink = function(){
	browser.wait(EC.elementToBeClickable(element.all(by.xpath(this.linkRequestedItemXpath)).get(0)),30000);
	element.all(by.xpath(this.linkRequestedItemXpath)).get(0).click().then(function(){
		logger.info("Clicked on First Requested Item - RITM Link");
    });
}

snow.prototype.clickSecondRequestedItemLink = function(){
	browser.wait(EC.elementToBeClickable(element.all(by.xpath(this.linkRequestedItemXpath)).get(1)),30000);
	element.all(by.xpath(this.linkRequestedItemXpath)).get(1).click().then(function(){
		logger.info("Clicked on Second Requested Item - RITM Link");
    });
}

snow.prototype.clickThirdRequestedItemLink = function(){
	browser.wait(EC.elementToBeClickable(element.all(by.xpath(this.linkRequestedItemXpath)).get(2)),30000);
	element.all(by.xpath(this.linkRequestedItemXpath)).get(2).click().then(function(){
		logger.info("Clicked on Third Requested Item - RITM Link");
    });
}

snow.prototype.clickFourthRequestedItemLink = function(){
	browser.wait(EC.elementToBeClickable(element.all(by.xpath(this.linkRequestedItemXpath)).get(3)),30000);
	element.all(by.xpath(this.linkRequestedItemXpath)).get(3).click().then(function(){
		logger.info("Clicked on Fourth Requested Item - RITM Link");
    });
}

snow.prototype.clickFifthRequestedItemLink = function(){
	browser.wait(EC.elementToBeClickable(element.all(by.xpath(this.linkRequestedItemXpath)).get(4)),30000);
	element.all(by.xpath(this.linkRequestedItemXpath)).get(4).click().then(function(){
		logger.info("Clicked on Fifth Requested Item - RITM Link");
    });
}

/************************************SnowV3 FUNCTIONS******************************************/

snow.prototype.loginToSnowDevPortal = function () {
	isAngularApp(false);
	browser.get(snowDevLoginObj.url+"/logout.do").then(function(){
		logger.info("Pre-Condition :: Logged out from SNOW portal");
	})
	browser.get(snowDevLoginObj.url).then(function(){
		logger.info("Opened snow portal");
	})
	orderFlowUtil.waitForSNOWLoginPage();
	element(by.css(this.usernameInputCss)).sendKeys(snowDevLoginObj.username).then(function(){
		logger.info("Entered username");
	})
	element(by.css(this.passwordInputCss)).sendKeys(snowDevLoginObj.password).then(function(){
		logger.info("Entered password");
	})
	element(by.css(this.loginButtonCss)).click().then(function(){
		logger.info("Clicked on Login button");
		browser.sleep(10000);//Sleep, as it takes some time to load page completely
	})
	this.switchToDefaultContent();
}

snow.prototype.logInToSnowDevPortalAndSearchOrder = function(ticketID){
	this.loginToSnowDevPortal();
	this.clickFavouritesStar();
	this.searchRequestsText();
	this.clickServiceCatalogRequestLink();
	this.searchOrderNumberUntilExists(ticketID);
	this.clickRequestNumberLink();
}

snow.prototype.logInToSnowDevPortalAndSearchOrderNotExists = function(ticketID){
	//Login to SNOW Portal
	this.loginToSnowDevPortal();
	this.clickFavouritesStar();
	this.searchRequestsText();
	this.clickServiceCatalogRequestLink();
	this.searchOrderNumColumn(ticketID);
}

snow.prototype.isCheckedRequestApprovalHold = function(){
	var reqApprovalHoldElem = element(by.css(this.checkboxReqApprovalHoldCss));
	return reqApprovalHoldElem.isPresent().then(function(value) {
		logger.info("Request approval hold: " + value);
		return value;
	})
}

snow.prototype.openDiscoverySchedulesDev = function(){
	this.loginToSnowDevPortal();
	this.searchDiscoveryText();
	this.clickDiscoverySchedulesLink();
}



/************************************QUICKSTART FUNCTIONS******************************************/

snow.prototype.loginToSnowQuickstartPortal = function () {
	isAngularApp(false);
	browser.get(snowQuickstartLoginObj.url+"/logout.do").then(function(){
		logger.info("Pre-Condition :: Logged out from SNOW portal");
	})
	browser.get(snowQuickstartLoginObj.url).then(function(){
		logger.info("Opened snow portal");
	})
	orderFlowUtil.waitForSNOWLoginPage();
	element(by.css(this.usernameInputCss)).sendKeys(snowQuickstartLoginObj.username).then(function(){
		logger.info("Entered username");
	})
	element(by.css(this.passwordInputCss)).sendKeys(snowQuickstartLoginObj.password).then(function(){
		logger.info("Entered password");
	})
	element(by.css(this.loginButtonCss)).click().then(function(){
		logger.info("Clicked on Login button");
		browser.sleep(10000);//Sleep, as it takes some time to load page completely
	})
	this.switchToDefaultContent();
}

snow.prototype.logInToSnowQuickstartPortalAndSearchOrder = function(ticketID){
	this.loginToSnowQuickstartPortal();
	this.clickFavouritesStar();
	this.searchRequestsText();
	this.clickServiceCatalogRequestLink();
	this.searchOrderNumberUntilExists(ticketID);
	this.clickRequestNumberLink();
}

snow.prototype.loginToSnowQSICDSPortal = function () {
	isAngularApp(false);
	browser.get(snowQSICDSLoginObj.url+"/logout.do").then(function(){
		logger.info("Pre-Condition :: Logged out from SNOW portal");
	})
	util.switchToAlertIfPresent();
	browser.get(snowQSICDSLoginObj.url).then(function(){
		logger.info("Opened snow portal");
	})
	orderFlowUtil.waitForSNOWLoginPage();
	element(by.css(this.usernameInputCss)).sendKeys(snowQSICDSLoginObj.username).then(function(){
		logger.info("Entered username");
	})
	element(by.css(this.passwordInputCss)).sendKeys(snowQSICDSLoginObj.password).then(function(){
		logger.info("Entered password");
	})
	element(by.css(this.loginButtonCss)).click().then(function(){
		logger.info("Clicked on Login button");
		browser.sleep(10000);//Sleep, as it takes some time to load page completely
	})
	this.switchToDefaultContent();
}

snow.prototype.logInToSnowQSICDSPortalAndSearchOrder = function(ticketID){
	this.loginToSnowQSICDSPortal();
	this.clickFavouritesStar();
	this.searchRequestsText();
	this.clickServiceCatalogRequestLink();
	this.searchOrderNumberUntilExists(ticketID);
	this.clickRequestNumberLink();
}

snow.prototype.logInToSnowQuickstartPortalAndSearchOrderNotExists = function(ticketID){
	//Login to SNOW Portal
	this.loginToSnowQuickstartPortal();
	this.clickFavouritesStar();
	this.searchRequestsText();
	this.clickServiceCatalogRequestLink();
	this.searchOrderNumColumn(ticketID);
}

snow.prototype.logInToSnowICDSPortalAndSearchOrderNotExists = function(ticketID){
	//Login to SNOW Portal
	this.loginToSnowQSICDSPortal();
	this.clickFavouritesStar();
	this.searchRequestsText();
	this.clickServiceCatalogRequestLink();
	this.searchOrderNumColumn(ticketID);
}

//Retrieve Approval status in request page
snow.prototype.getTextApprovalStateQS= function(){
	var approvalState = element(by.css(this.textApprovalStateQSCss));
	browser.wait(EC.visibilityOf(approvalState),90000);
	return approvalState.getText().then(function(approvalStateText){
		logger.info("Approval state is : "+approvalStateText);
		return approvalStateText;
	})
}

//Retrieve Assignment group in request page
snow.prototype.getTextAssignmentGrpQS= function(){
	var assignGrp = element(by.css(this.textAssignmentGrpQSCss));
	browser.wait(EC.visibilityOf(assignGrp),90000);
	return assignGrp.getAttribute("value").then(function(assignGrpText){
		logger.info("Assignment Group is : "+assignGrpText);
		return assignGrpText;
	})
}

//Retrieve Correlation id in request page
snow.prototype.getTextCorrelationIdQS= function(){
	var correlId = element(by.css(this.textCorrelationIdCss));
	browser.wait(EC.visibilityOf(correlId),90000);
	return correlId.getAttribute("value").then(function(correlIdText){
		logger.info("Correlation Id is : "+correlIdText);
		return correlIdText;
	})
}

snow.prototype.clickApproveButtonQS = function(){
	var self = this;
	element(by.css(self.buttonApproveCss)).isPresent().then(function(bool){
		if(bool){
			browser.wait(EC.elementToBeClickable(element(by.css(self.buttonApproveCss))),90000);
			element(by.css(self.buttonApproveCss)).click().then(function(){
				logger.info("Clicked Approve button");
				browser.sleep(10000);//Intentional sleep as sometimes - Transaction Running popup will appear after some time
		    });
			browser.wait(EC.invisibilityOf(element(by.css(self.transactionCancelButtonCss))),240000).then(function(){
				logger.info("Wait till Transaction Cancel button disappears");
			});
		}
		else {
			logger.info("No approve button");
		}
	})	
}

snow.prototype.approveRequestFromSnowQS = function(){
	this.clickApproversTab();
	this.clickRequestedLinkFromApproversTab();
	this.clickApproveButtonQS();
	this.clickRequestedItemsTab();
}

//Retrieve Approval state in requested item page
snow.prototype.getTextReqItemApprovalQS= function(){
	var itemApproval = element(by.css(this.textReqItemApprovalQSCss));
	browser.wait(EC.visibilityOf(itemApproval),90000);
	return itemApproval.getText().then(function(itemApprovalText){
		logger.info("Approval state in Requested Item page is : "+itemApprovalText);
		return itemApprovalText;
	})
}

//Retrieve Assignment group in requested item page
snow.prototype.getTextReqItemAssignGrpQS= function(){
	var itemAssignGrp = element(by.css(this.textReqItemAssignGrpQSCss));
	browser.wait(EC.visibilityOf(itemAssignGrp),90000);
	return itemAssignGrp.getAttribute("value").then(function(itemAssignGrpText){
		logger.info("Assignment Group in Requested Item page is : "+itemAssignGrpText);
		return itemAssignGrpText;
	})
}

//Retrieve Description in requested item page
snow.prototype.getTextReqItemDescriptionQS= function(){
	var itemDesc = element(by.css(this.textReqItemDescQSCss));
	browser.wait(EC.visibilityOf(itemDesc),90000);
	return itemDesc.getText().then(function(itemDescText){
		logger.info("Description in Requested Item page is : "+itemDescText);
		return itemDescText;
	})
}

//Click Requested Item Variables tab in requested item page
snow.prototype.clickReqItemVarTabQS= function(){
	var itemVar = element.all(by.css(this.tabReqItemVarQSCss)).first();
	browser.wait(EC.elementToBeClickable(itemVar),90000);
	itemVar.click().then(function(){
		logger.info("Clicked on Requested Item Variables tab");
	})
}

snow.prototype.getTextReqItemVarSearchTextboxBasedOnNameQS= function(name){
	var item = element(by.xpath("//span[text()= '" + name + "']/ancestor::div/following-sibling::div/div/input"));
	browser.wait(EC.visibilityOf(item),90000);
	return item.getAttribute("value").then(function(item){
		logger.info("Requested Item Variables- " + name + " : " + item);
		return item;
	})
}

snow.prototype.getTextReqItemVarDropdownBasedOnNameQS= function(name){
	var item = element(by.xpath("//span[text()= '" + name + "']/ancestor::div/following-sibling::div//select/option[@selected='SELECTED']"));
	browser.wait(EC.visibilityOf(item),90000);
	return item.getText().then(function(item){
		logger.info("Requested Item Variables- " + name + " : " + item);
		return item;
	})
}

snow.prototype.getTextReqItemVarTextboxBasedOnNameQS= function(name){
	var item = element(by.xpath("//span[text()= '" + name + "']/ancestor::div/following-sibling::div/input[2]"));
	browser.wait(EC.visibilityOf(item),90000);
	return item.getAttribute("value").then(function(item){
		logger.info("Requested Item Variables- " + name + " : " + item);
		return item;
	})
}

//Click Change Request link in requested item page
snow.prototype.clickChangeRequestLinkQS= function(){
	browser.sleep(6000);
	var changeReqLink = element(by.xpath(this.linkChangeRequestQSXpath));
	browser.executeScript("arguments[0].scrollIntoView(true);", changeReqLink.getWebElement());
	browser.wait(EC.elementToBeClickable(changeReqLink),90000);
	changeReqLink.click().then(function(){
		logger.info("Clicked on Change Request link");
	})
}

//Retrieve Approval state in change request page
snow.prototype.getTextChangeReqApprovalQS= function(){
	var changeReqApp = element(by.css(this.textChangeReqApprovalQSCss));
	browser.wait(EC.visibilityOf(changeReqApp),90000);
	return changeReqApp.getText().then(function(changeReqAppText){
		logger.info("Approval state in Change Request page is : "+changeReqAppText);
		return changeReqAppText;
	})
}

//Retrieve Type in change request page
snow.prototype.getTextChangeReqTypeQS= function(){
	var changeReqType = element(by.css(this.textChangeReqTypeQSCss));
	browser.wait(EC.visibilityOf(changeReqType),90000);
	return changeReqType.getText().then(function(changeReqTypeText){
		logger.info("Type in Change Request page is : "+changeReqTypeText);
		return changeReqTypeText;
	})
}

//Retrieve State in change request page
snow.prototype.getTextChangeReqStateQS= function(){
	var changeReqState = element(by.css(this.textChangeReqStateQSCss));
	browser.wait(EC.visibilityOf(changeReqState),90000);
	return changeReqState.getText().then(function(changeReqStateText){
		logger.info("State in Change Request page is : "+changeReqStateText);
		return changeReqStateText;
	})
}

//Retrieve Configuration Item in change request page
snow.prototype.getTextChangeReqConfItemQS= function(){
	var changeReqConfItem = element(by.css(this.textChangeReqConfItemQSCss));
	browser.wait(EC.visibilityOf(changeReqConfItem),90000);
	return changeReqConfItem.getText().then(function(changeReqConfItemText){
		logger.info("Configuration Item in Change Request page is : "+changeReqConfItemText);
		return changeReqConfItemText;
	})
}

snow.prototype.searchScheduledJobsTextQS = function(){
	this.switchToDefaultContent();
	browser.wait(EC.visibilityOf(element(by.css(this.searchFilterCss))),90000).then(function(){
		logger.info("Wait till search Text box is displayed");
	});
	element(by.css(this.searchFilterCss)).clear().then(function(){
		logger.info("Cleared search textbox");
    });
	element(by.css(this.searchFilterCss)).sendKeys(this.SysDefScheduledJobs).then(function(){
		logger.info("Entered Scheduled Jobs in search textbox");
    });
}

snow.prototype.clickScheduledJobsLinkQS = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.linkScheduledJobsXpath))),90000);
	element(by.xpath(this.linkScheduledJobsXpath)).click().then(function(){
		logger.info("Clicked on Scheduled Jobs link");
		browser.sleep(2000);
    });
}

snow.prototype.searchSetChangeToInProgQS = function(){
	var self = this;
	self.switchToParentFrame();
	browser.wait(EC.visibilityOf(element(by.css(self.searchTextboxScheduledJobsCss))),90000);
	element(by.css(self.searchTextboxScheduledJobsCss)).sendKeys(self.QSSetChangeToInProg).then(function(){
		logger.info("Entered " + self.QSSetChangeToInProg + " text in search textbox");
    });
	element(by.css(self.searchTextboxScheduledJobsCss)).sendKeys(protractor.Key.ENTER).then(function(){
		logger.info("Hit Enter");
	})
}
	
snow.prototype.clickSetChangeToInProgLinkQS = function(){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.xpath(self.linkSetChangeToInProgXpath))),90000)
	element(by.xpath(self.linkSetChangeToInProgXpath)).click().then(function(){
		logger.info("Clicked on " + self.QSSetChangeToInProg + " link");
    });
}
	
snow.prototype.clickExecuteNowButtonQS = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonExecuteNowCss))),90000)
	element(by.css(this.buttonExecuteNowCss)).click().then(function(){
		logger.info("Clicked on Execute Now button");
		browser.sleep(2000);
    });
}

snow.prototype.waitUntilApprovalIsRequestedQS = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 35;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		element(by.css(self.textApprovalStateQSCss)).isPresent().then(function(state) {
			if(state) {
				browser.wait(EC.visibilityOf(element(by.css(self.textApprovalStateQSCss))),90000);
				element(by.css(self.textApprovalStateQSCss)).getText().then(function(state) {
					if(state == "Not Yet Requested") {
						logger.info("Approval is not Requested, refreshing page: " + state);
						browser.navigate().refresh();
						self.switchToParentFrame();
						self.waitUntilApprovalIsRequestedQS(repeatCount);
					}
					else if(state == "Approved") {
						logger.info("Approval is not Requested, refreshing page: " + state);
						browser.navigate().refresh();
						self.switchToParentFrame();
						self.waitUntilApprovalIsRequestedQS(repeatCount);
					}
					else {
						logger.info("Approval is Requested: " + state);
						repeatCount = 0;
						return;
					}
				})
			}
			else {
				browser.wait(EC.visibilityOf(element(by.css(self.buttonBackCss))),90000).then(function () {
					logger.info("Approval is not in stable requested state: ");
				}).catch(function (err) {
					browser.sleep(30000);
					logger.info("Exception occured as No Such Window");
				});
				self.clickBackButton();
				self.clickRequestNumberLink();
				self.waitUntilApprovalIsRequestedQS(repeatCount);
			}
		})		
	}
}

snow.prototype.waitUntilApprovalIsApprovedQS = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 35;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		element(by.css(self.textApprovalStateQSCss)).isPresent().then(function(state) {
			if(state) {
				browser.wait(EC.visibilityOf(element(by.css(self.textApprovalStateQSCss))),90000);
				element(by.css(self.textApprovalStateQSCss)).getText().then(function(state) {
					if(state == "Not Yet Requested") {
						logger.info("Approval is not Requested, refreshing page: " + state);
						browser.navigate().refresh();
						self.switchToParentFrame();
						self.waitUntilApprovalIsApprovedQS(repeatCount);
					}
					else {
						logger.info("Approval is Approved: " + state);
						repeatCount = 0;
						return;
					}
				})
			}
		})		
	}
}
	
snow.prototype.executeScheduledScript = function(){
	this.searchScheduledJobsTextQS();
	this.clickScheduledJobsLinkQS();
	this.searchSetChangeToInProgQS();
	this.clickSetChangeToInProgLinkQS();
	this.clickExecuteNowButtonQS();
}

snow.prototype.waitUntilOrderFails = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.css(self.colorStateCss)).first();
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());	
		browser.wait(EC.visibilityOf(task),90000);
		task.getAttribute("style").then(function(color){
			logger.info("Status color: " + color)
			if(color.includes("green")) {
				logger.info("Change Task 1 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilOrderFails(repeatCount);
			}
			else {
				logger.info("Change Task 1 Failed");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilFirstChangeTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.xpath(self.textChangeTasksStateXpath)).get(0);
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());	
		browser.wait(EC.visibilityOf(task),90000);
		task.getText().then(function(state){
			if(state == "In Progress") {
				logger.info("Change Task 1 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilFirstChangeTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Change Task 1 is Closed");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilSecondChangeTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.xpath(self.textChangeTasksStateXpath)).get(1);
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());
		browser.wait(EC.visibilityOf(task),90000);
		task.getText().then(function(state){
			if(state == "In Progress") {
				logger.info("Change Task 2 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilSecondChangeTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Change Task 2 is Closed");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilThirdChangeTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.xpath(self.textChangeTasksStateXpath)).get(2);
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());
		browser.wait(EC.visibilityOf(task),90000);
		task.getText().then(function(state){
			if(state == "In Progress") {
				logger.info("Change Task 3 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilThirdChangeTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Change Task 3 is Closed");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilFourthChangeTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.xpath(self.textChangeTasksStateXpath)).get(3);
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());
		browser.wait(EC.visibilityOf(task),90000);
		task.getText().then(function(state){
			if(state == "In Progress") {
				logger.info("Change Task 4 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilFourthChangeTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Change Task 4 is Closed");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilFifthChangeTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.xpath(self.textChangeTasksStateXpath)).get(4);
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());
		browser.wait(EC.visibilityOf(task),90000);
		task.getText().then(function(state){
			if(state == "In Progress") {
				logger.info("Change Task 5 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilFifthChangeTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Change Task 5 is Closed");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilSixthChangeTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.xpath(self.textChangeTasksStateXpath)).get(5);
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());
		browser.wait(EC.visibilityOf(task),90000);
		task.getText().then(function(state){
			if(state == "In Progress") {
				logger.info("Change Task 6 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilSixthChangeTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Change Task 6 is Closed");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilSeventhChangeTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.xpath(self.textChangeTasksStateXpath)).get(6);
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());
		browser.wait(EC.visibilityOf(task),90000);
		task.getText().then(function(state){
			if(state == "In Progress") {
				logger.info("Change Task 7 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilSeventhChangeTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Change Task 7 is Closed");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilEighthChangeTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.xpath(self.textChangeTasksStateXpath)).get(7);
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());
		browser.wait(EC.visibilityOf(task),90000);
		task.getText().then(function(state){
			if(state == "In Progress") {
				logger.info("Change Task 8 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilEighthChangeTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Change Task 8 is Closed");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilNinthChangeTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.xpath(self.textChangeTasksStateXpath)).get(8);
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());
		browser.wait(EC.visibilityOf(task),90000);
		task.getText().then(function(state){
			if(state == "In Progress") {
				logger.info("Change Task 9 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilNinthChangeTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Change Task 9 is Closed");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilTenthChangeTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.xpath(self.textChangeTasksStateXpath)).get(9);
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());
		browser.wait(EC.visibilityOf(task),90000);
		task.getText().then(function(state){
			if(state == "In Progress") {
				logger.info("Change Task 10 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilTenthChangeTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Change Task 10 is Closed");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.waitUntilEleventhChangeTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.xpath(self.textChangeTasksStateXpath)).get(10);
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());
		browser.wait(EC.visibilityOf(task),90000);
		task.getText().then(function(state){
			if(state == "In Progress") {
				logger.info("Change Task 11 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilEleventhChangeTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Change Task 11 is Closed");
				repeatCount = 0;
				return;
			}
		})
	}
}

snow.prototype.checkIfChangeTaskFailed = function(){	
	this.clickChangeTaskTabInChangeRequest();
	this.waitUntilOrderFails();
}

snow.prototype.checkIfAllChangeTasksClosed = function(){	
	this.clickChangeTaskTabInChangeRequest();
	this.waitUntilFirstChangeTaskClosed();
	this.waitUntilSecondChangeTaskClosed();
	this.waitUntilThirdChangeTaskClosed();
	this.waitUntilFourthChangeTaskClosed();
	this.waitUntilFifthChangeTaskClosed();
}

snow.prototype.checkIfAllSevenChangeTasksClosed = function(){	
	this.clickChangeTaskTabInChangeRequest();
	this.waitUntilFirstChangeTaskClosed();
	this.waitUntilSecondChangeTaskClosed();
	this.waitUntilThirdChangeTaskClosed();
	this.waitUntilFourthChangeTaskClosed();
	this.waitUntilFifthChangeTaskClosed();
	this.waitUntilSixthChangeTaskClosed();
	this.waitUntilSeventhChangeTaskClosed();
}

snow.prototype.checkIfAllEightChangeTasksClosed = function(){	
	this.clickChangeTaskTabInChangeRequest();
	this.clickChangeRequestChangeTasksButton();
	browser.sleep(2000);
	this.waitUntilFirstChangeTaskClosed();
	this.waitUntilSecondChangeTaskClosed();
	this.waitUntilThirdChangeTaskClosed();
	this.waitUntilFourthChangeTaskClosed();
	this.waitUntilFifthChangeTaskClosed();
	this.waitUntilSixthChangeTaskClosed();
	this.waitUntilSeventhChangeTaskClosed();
	browser.sleep(2000);
	this.waitUntilEighthChangeTaskClosed();
}

snow.prototype.checkIfAllNineChangeTasksClosed = function(){	
	this.clickChangeTaskTabInChangeRequest();
	this.waitUntilFirstChangeTaskClosed();
	this.waitUntilSecondChangeTaskClosed();
	this.waitUntilThirdChangeTaskClosed();
	this.waitUntilFourthChangeTaskClosed();
	this.waitUntilFifthChangeTaskClosed();
	this.waitUntilSixthChangeTaskClosed();
	this.waitUntilSeventhChangeTaskClosed();
	this.waitUntilEighthChangeTaskClosed();
	this.waitUntilNinthChangeTaskClosed();
}

snow.prototype.checkIfAllFourChangeTasksClosed = function(){	
	this.clickChangeTaskTabInChangeRequest();
	this.clickChangeRequestChangeTasksButton();
	browser.sleep(2000);
	this.waitUntilFirstChangeTaskClosed();
	this.waitUntilSecondChangeTaskClosed();
	this.waitUntilThirdChangeTaskClosed();
	this.waitUntilFourthChangeTaskClosed();
}

snow.prototype.checkIfAllTwoChangeTasksClosed = function(){	
	this.clickChangeTaskTabInChangeRequest();
	this.clickChangeRequestChangeTasksButton();
	browser.sleep(2000);
	this.waitUntilFirstChangeTaskClosed();
	this.waitUntilSecondChangeTaskClosed();
}

snow.prototype.checkIfAllTwelveChangeTasksClosed = function(){	
	this.clickChangeTaskTabInChangeRequest();
	this.clickChangeRequestChangeTasksButton();
	browser.sleep(2000);
	this.waitUntilFirstChangeTaskClosed();
	this.waitUntilSecondChangeTaskClosed();
	this.waitUntilThirdChangeTaskClosed();
	this.waitUntilFourthChangeTaskClosed();
	this.waitUntilFifthChangeTaskClosed();
	this.waitUntilSixthChangeTaskClosed();
	this.waitUntilSeventhChangeTaskClosed();
	this.waitUntilEighthChangeTaskClosed();
	this.waitUntilNinthChangeTaskClosed();
	browser.sleep(2000);
	this.waitUntilTenthChangeTaskClosed();
	this.waitUntilEleventhChangeTaskClosed();
	this.waitUntilTwelfthChangeTaskClosed();

}

snow.prototype.searchPropertiesTextQS = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.searchFilterCss))),90000).then(function(){
		logger.info("Wait till search Text box is displayed");
	});
	element(by.css(this.searchFilterCss)).clear().then(function(){
		logger.info("Cleared search textbox");
    });
	element(by.css(this.searchFilterCss)).sendKeys(this.HCMSproperties).then(function(){
		logger.info("Entered Properties in search textbox");
    });
}

snow.prototype.clickPropertiesLinkQS = function(){
	browser.wait(EC.visibilityOf(element.all(by.xpath(this.linkPropertiesXpath)).get(0)),90000);
	element.all(by.xpath(this.linkPropertiesXpath)).get(0).click().then(function(){
		logger.info("Clicked on Properties link");
		browser.sleep(2000);
    });
}

snow.prototype.searchPropertiesQS = function(prop){
	var self = this;
	self.switchToParentFrame();
	element(by.linkText(this.allLinkXpath)).click().then(function(){
		logger.info("Clicked on All link");
	});
	browser.wait(EC.visibilityOf(element(by.css(self.searchTextboxQSApprovalCss))),90000);
	element(by.css(self.searchTextboxQSApprovalCss)).sendKeys(prop).then(function(){
		logger.info("Entered " + prop + " text in search textbox");
    });
	element(by.css(self.searchTextboxQSApprovalCss)).sendKeys(protractor.Key.ENTER).then(function(){
		logger.info("Hit Enter");
	})
}

snow.prototype.clickPropertyLinkQS = function(prop){
	var self = this;
	var propertyQS = element(by.xpath("//a[contains(text(), '" + prop + "')]"));
	browser.wait(EC.elementToBeClickable(propertyQS),90000)
	propertyQS.click().then(function(){
		logger.info("Clicked on " + prop + " link");
    });
}

snow.prototype.clearValueTextareaQS = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaValueCss))),90000);
	element(by.css(this.textareaValueCss)).clear().then(function(){
		logger.info("Cleared Value textarea");
    });
}

snow.prototype.enterValueTextareaQS = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaValueCss))),90000);
	element(by.css(this.textareaValueCss)).clear().then(function(){
		logger.info("Cleared Value textarea");
    });
	element(by.css(this.textareaValueCss)).sendKeys(this.QSApproveManager).then(function(){
		logger.info("Entered text in Value textarea");
    });
}

snow.prototype.clickImplementButtonQS = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonImplementCss))),90000)
	element(by.css(this.buttonImplementCss)).click().then(function(){
		logger.info("Clicked on Implement button");
		browser.sleep(10000);
    });
}

snow.prototype.clickEditRecordPropLink = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.linkEditRecordPropCss))),90000)
	element(by.xpath(this.linkEditRecordPropCss)).click().then(function(){
		logger.info("Clicked on Edit record link");
		browser.sleep(2000);
    });
}

snow.prototype.enterValuePropertyQS = function(val){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaValueCss))),90000);
	element(by.css(this.textareaValueCss)).clear().then(function(){
		logger.info("Cleared Value textarea");
    });
	element(by.css(this.textareaValueCss)).sendKeys(val).then(function(){
		logger.info("Entered " + val + " in textarea");
    });
}

snow.prototype.getTextValuePropertyQS = function(){
	var propertyValueQS = element(by.css(this.textareaValueCss));
	browser.wait(EC.visibilityOf(propertyValueQS),90000);
	return propertyValueQS.getText().then(function(propertyValueQStext){
		logger.info("The property value is set to : "+propertyValueQStext);
		return propertyValueQStext;
	})
}


snow.prototype.enableAutoApprovalQS = function(property){
	this.searchPropertiesTextQS();
	this.clickPropertiesLinkQS();
	this.searchPropertiesQS(property);
	this.clickPropertyLinkQS(property);
	this.clearValueTextareaQS();
	this.clickUpdateButton();
}

snow.prototype.enableManualApprovalQS = function(property){
	this.searchPropertiesTextQS();
	this.clickPropertiesLinkQS();
	this.searchPropertiesQS(property);
	this.clickPropertyLinkQS(property);
	this.enterValueTextareaQS();
	this.clickUpdateButton();
}

snow.prototype.setQSflag = function(property,value){
	this.searchPropertiesTextQS();
	this.clickPropertiesLinkQS();
	this.searchPropertiesQS(property);
	this.clickPropertyLinkQS(property);
	//this.clickEditRecordPropLink();
	this.enterValuePropertyQS(value);
	//this.clickUpdateButton();
}

snow.prototype.getQSflag = function(property){
	this.searchPropertiesTextQS();
	this.clickPropertiesLinkQS();
	this.searchPropertiesQS(property);
	this.clickPropertyLinkQS(property);
	this.getTextValuePropertyQS();
	this.clickUpdateButton();
}

snow.prototype.clickApproversTabAtRITMQS = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.tabApproversAtRITMCss))),90000);
	element(by.css(this.tabApproversAtRITMCss)).click().then(function(){
		logger.info("Clicked on Approvers tab");
    });
}

snow.prototype.approveRequestFromSnowAtRITMQS = function(){
	this.clickApproversTabAtRITMQS();
	this.clickRequestedLinkFromApproversTab();
	this.clickApproveButtonQS();
	this.clickRequestedItemsTab();
}

snow.prototype.selectImpactDropdownValue = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.dropdownImpactCss))),90000);
	element(by.css(this.dropdownImpactCss)).click().then(function(){
		logger.info("Clicked on Impact dropdown");
    });
	browser.wait(EC.elementToBeClickable(element(by.css(this.dropdownValueImpactCss))),90000);
	element(by.css(this.dropdownValueImpactCss)).click().then(function(){
		logger.info("Selected Impact dropdown value");
    });	
}

snow.prototype.selectUrgencyDropdownValue = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.dropdownUrgencyCss))),90000);
	element(by.css(this.dropdownUrgencyCss)).click().then(function(){
		logger.info("Clicked on Urgency dropdown");
    });
	browser.wait(EC.elementToBeClickable(element(by.css(this.dropdownValueUrgencyCss))),90000);
	element(by.css(this.dropdownValueUrgencyCss)).click().then(function(){
		logger.info("Selected Urgency dropdown value");
    });	
}

snow.prototype.selectAssignGrpValue = function(){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(self.searchTextAssignGrpCss))),90000);
	element(by.css(self.searchTextAssignGrpCss)).clear().then(function() {
		element(by.css(self.searchTextAssignGrpCss)).sendKeys("Change");
		browser.sleep(2000);
		element(by.css(self.searchTextAssignGrpCss)).sendKeys(protractor.Key.ARROW_DOWN).then(function(){
			element(by.css(self.searchTextAssignGrpCss)).sendKeys(protractor.Key.ENTER).then(function(){
				logger.info("Selected Assignment Group value");
			});
		});
	});
}

snow.prototype.selectAssignedToValue = function(){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(this.searchTextAssignedToCss))),90000);
	element(by.css(this.searchTextAssignedToCss)).sendKeys("Change");
	browser.sleep(2000);
	element(by.css(self.searchTextAssignedToCss)).sendKeys(protractor.Key.ARROW_DOWN).then(function(){
		element(by.css(self.searchTextAssignedToCss)).sendKeys(protractor.Key.ENTER).then(function(){
			logger.info("Selected Assigned To value");
		});
	});
}

snow.prototype.selectFailureProbDropdownValue = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.dropdownFailureProbCss))),90000);
	element(by.css(this.dropdownFailureProbCss)).click().then(function(){
		logger.info("Clicked on Failure Probability dropdown");
    });
	browser.wait(EC.elementToBeClickable(element(by.css(this.dropdownValueFailureProbCss))),90000);
	element(by.css(this.dropdownValueFailureProbCss)).click().then(function(){
		logger.info("Selected Failure Probability dropdown value");
    });	
}

snow.prototype.selectExcepReasonDropdownValue = function(){
	var self= this;
	browser.wait(EC.elementToBeClickable(element(by.css(self.dropdownExcepReasonCss))),90000);
	element(by.css(self.dropdownExcepReasonCss)).click().then(function(){
		logger.info("Clicked on Exception Reason dropdown");
    });
	browser.wait(EC.elementToBeClickable(element(by.css(self.dropdownValueExcepReasonCss))),90000);
	element(by.css(self.dropdownValueExcepReasonCss)).click().then(function(){
		logger.info("Selected Exception Reason dropdown value");
		element(by.css(self.dropdownExcepReasonCss)).click();
    });	
}

snow.prototype.enterChangeReqValues = function(){
	this.selectImpactDropdownValue();
	this.selectUrgencyDropdownValue();
	this.selectAssignGrpValue();
	this.selectAssignedToValue();
	this.selectFailureProbDropdownValue();
	this.selectExcepReasonDropdownValue();
}

snow.prototype.clickPlanningTab = function(){
	var elem = element(by.xpath(this.textPlanningTabXpath));
	browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());
	browser.wait(EC.elementToBeClickable(elem),90000)
	elem.click().then(function(){
		logger.info("Clicked on Planning tab");
    });
}

snow.prototype.enterJustificationText = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaJustificationsCss))),90000);
	element(by.css(this.textareaJustificationsCss)).sendKeys("abcd").then(function(){
		logger.info("Entered Justification value");
    });
}

snow.prototype.enterImplementPlanText = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaImplementPlanCss))),90000);
	element(by.css(this.textareaImplementPlanCss)).sendKeys("abcd").then(function(){
		logger.info("Entered Implementation Plan value");
    });
}

snow.prototype.enterRiskAnalysisText = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaRiskAnalysisCss))),90000);
	element(by.css(this.textareaRiskAnalysisCss)).sendKeys("abcd").then(function(){
		logger.info("Entered Risk and impact analysis value");
    });
}

snow.prototype.enterBackoutPlanText = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaBackoutPlanCss))),90000);
	element(by.css(this.textareaBackoutPlanCss)).sendKeys("abcd").then(function(){
		logger.info("Entered Backout Plan value");
    });
}

snow.prototype.enterTestPlanText = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaTestPlanCss))),90000);
	element(by.css(this.textareaTestPlanCss)).sendKeys("abcd").then(function(){
		logger.info("Entered Test Plan value");
    });
}

snow.prototype.enterExcepJustificationText = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaExcepJustificationCss))),90000);
	element(by.css(this.textareaExcepJustificationCss)).sendKeys("abcd").then(function(){
		logger.info("Entered Exception Justification value");
    });
}

snow.prototype.enterPlanningValues = function(){
	this.clickPlanningTab();
	this.enterJustificationText();
	this.enterImplementPlanText();
	this.enterRiskAnalysisText();
	this.enterBackoutPlanText();
	this.enterTestPlanText();
	this.enterExcepJustificationText();
}

snow.prototype.clickScheduleTab = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.textScheduleTabXpath))),90000)
	element(by.xpath(this.textScheduleTabXpath)).click().then(function(){
		logger.info("Clicked on Schedule tab");
    });
}

snow.prototype.clickCalendarStartDateButton = function(){
	browser.wait(EC.elementToBeClickable(element.all(by.css(this.buttonCalendarStartDateCss)).last()),90000)
	element.all(by.css(this.buttonCalendarStartDateCss)).last().click().then(function(){
		logger.info("Clicked on Calendar Start Date button");
    });
}

snow.prototype.selectStartDate = function(){
	browser.wait(EC.visibilityOf(element.all(by.xpath(this.calendarStartDateXpath)).get(0)),90000)
	element.all(by.xpath(this.calendarStartDateXpath)).get(0).click().then(function(){
		logger.info("Selected Start date");
    });
}

snow.prototype.clickCalendarEndDateButton = function(){
	browser.wait(EC.visibilityOf(element.all(by.css(this.buttonCalendarEndDateCss)).last()),90000)
	element.all(by.css(this.buttonCalendarEndDateCss)).last().click().then(function(){
		logger.info("Clicked on Calendar End Date button");
    });
}

snow.prototype.selectEndDate = function(){
	browser.wait(EC.visibilityOf(element.all(by.xpath(this.calendarEndDateXpath)).get(0)),90000)
	element.all(by.xpath(this.calendarEndDateXpath)).get(0).click().then(function(){
		logger.info("Selected End date");
    });
}

snow.prototype.clickDatePickerOkButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonDatePickerOkCss))),90000)
	element(by.css(this.buttonDatePickerOkCss)).click().then(function(){
		logger.info("Clicked on OK button");
    });
}

snow.prototype.enterScheduleValues = function(){
	this.clickScheduleTab();
	this.clickCalendarStartDateButton();
	this.selectStartDate();
	this.clickDatePickerOkButton();
	this.clickCalendarEndDateButton();
	this.selectEndDate();
	this.clickDatePickerOkButton();
}

snow.prototype.clickCalculateRiskLink = function(){
	browser.wait(EC.elementToBeClickable(element(by.linkText(this.linkTextCalculateRisk))),90000)
	element(by.linkText(this.linkTextCalculateRisk)).click().then(function(){
		logger.info("Clicked on Calculate Risk link");
    });
}

snow.prototype.clickAssessButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonAssessCss))),90000)
	element(by.css(this.buttonAssessCss)).click().then(function(){
		logger.info("Clicked on Assess button");
		browser.sleep(10000);
    });
	util.switchToAlertIfPresent();
}

snow.prototype.selectCTStateDropdownValue = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.dropdownChangeTaskStateCss))),90000);
	element(by.css(this.dropdownChangeTaskStateCss)).click().then(function(){
		logger.info("Clicked on Change Task State dropdown");
    });
	browser.wait(EC.visibilityOf(element(by.css(this.dropdownValueCTStateCss))),90000);
	element(by.css(this.dropdownValueCTStateCss)).click().then(function(){
		logger.info("Selected Change Task State value");
    });	
}

snow.prototype.approveRequestQS = function(){
	this.clickOnApproversTabInChangeRequest();
	this.clickRequestedLinkFromApproversTab();
	this.clickApproveButtonQS();
}

snow.prototype.openDiscoverySchedulesQS = function(){
	this.loginToSnowQuickstartPortal();
	this.searchDiscoveryText();
	this.clickDiscoverySchedulesLink();
}

snow.prototype.clickNotesTab = function(){
	browser.sleep(6000);
	var notesTab = element(by.xpath(this.textNotesTabXpath));
	browser.executeScript("arguments[0].scrollIntoView();", notesTab.getWebElement());
	//browser.executeScript('window.scrollTo(0,0)');
	browser.wait(EC.visibilityOf(notesTab),90000);
	notesTab.click().then(function(){
		logger.info("Clicked on Notes tab");
    });
}

snow.prototype.enterAdditionalCommentsText = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaAdditionalCommentsCss))),90000);
	element(by.css(this.textareaAdditionalCommentsCss)).sendKeys("Test Cancel change").then(function(){
		logger.info("Entered additional comments");
    });
}

snow.prototype.getTextChangeRequestCurrentStateQS = function(){
	var webElement = element(by.css(this.textChangeRequestCurrentStateQSCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getText().then(function(text){
		logger.info("Current Change Request State is : "+text);
		return text;
	})
}

snow.prototype.clickChangeRequestCurrentStateQS = function(){
	var webElement = element(by.css(this.textChangeRequestCurrentStateQSCss));
	browser.wait(EC.elementToBeClickable(webElement),90000);
    webElement.click().then(function(text){
		logger.info("Clicked on Current Change Request");
	})
}

snow.prototype.clickChangeTaskStateDropdown = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.dropdownChangeTaskStateCss))),90000);
	element(by.css(this.dropdownChangeTaskStateCss)).click().then(function(){
		logger.info("Clicked on Change Task Type dropdown");
    });
}

snow.prototype.selectChangeTaskStateDropdownValue = function(state){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(self.dropdownValuesChangeTaskStateCss))),90000);
	element.all(by.css(self.dropdownValuesChangeTaskStateCss)).getText().then(function(value){
		for(var i=0; i<value.length; i++) {
			if(value[i] == state) {
				element.all(by.css(self.dropdownValuesChangeTaskStateCss)).get(i).click().then(function(){
					logger.info("Selected " + state + " from Change Task State dropdown");
				})
			}
		}
    });
}

snow.prototype.enterChangeTaskDescription = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textareaChangeTaskDescCss))),90000);
	element(by.css(this.textareaChangeTaskDescCss)).sendKeys(this.changeTaskDesc).then(function() {
		logger.info("Entered Change Task description");
	})
}

snow.prototype.cancelChangeTask = function(dropdownValue){	
	this.clickChangeTaskStateDropdown();
	this.selectChangeTaskStateDropdownValue(dropdownValue);
	this.enterChangeTaskDescription();
	this.clickUpdateButton();
}

snow.prototype.clickProvTaskLink = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.linkProvTaskXpath))),90000);
	element(by.xpath(this.linkProvTaskXpath)).click().then(function(){
		logger.info("Clicked on Provisioning task link");
    });
}

snow.prototype.clickCancelButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonCancelCss))),90000);
	element(by.css(this.buttonCancelCss)).click().then(function(){
		logger.info("Clicked on Cancel button");
    });
}

snow.prototype.getTextReqItemCorrIDQS = function(){
	var webElement = element(by.css(this.textReqItemCorrIDCss));
	browser.wait(EC.visibilityOf(webElement),90000);
	return webElement.getAttribute("value").then(function(text){
		logger.info("Correlation ID is : "+text);
		return text;
	})
}

snow.prototype.clickCancelButtonICDS = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonCancelICDSCss))),90000);
	element(by.css(this.buttonCancelICDSCss)).click().then(function(){
		logger.info("Clicked on Cancel button");
		browser.sleep(5000);
    });
}

snow.prototype.cancelChangeRequest = function(){
	this.clickCancelButtonICDS();
	this.clickNotesTab();
	this.enterAdditionalCommentsText();
	this.clickCancelButtonICDS();
}

snow.prototype.rightClickOnCMDBCIFormHeader = function(){
	var headerTitle =  element.all(by.css(this.cmdbCIFormHeaderCss)).get(0);
	browser.wait(EC.visibilityOf(headerTitle),90000);
	browser.actions().mouseMove(headerTitle).perform().then(function(){
		browser.sleep(2000);
		return browser.actions().click(protractor.Button.RIGHT).perform().then(function(){
	    	logger.info("Right Clicked on the Form Header");
	    });	
	}) ;  
}

snow.prototype.clickOnViewOptionInCMDBCIFormHeader = function(){	
		browser.wait(EC.elementToBeClickable(element(by.xpath(this.cmdbCIFormHeaderViewXpath))),90000);
		element(by.xpath(this.cmdbCIFormHeaderViewXpath)).click().then(function(){
		logger.info("Clicked on View button");
    });

   // });
}

snow.prototype.clickOnDefaultViewOptionInCMDBCIFormHeader = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.cmdbCIFormHeaderDefaultViewXpath))),90000);
	element(by.xpath(this.cmdbCIFormHeaderDefaultViewXpath)).click().then(function(){
	logger.info("Clicked on Default View Option");
	});
}

snow.prototype.switchCMDBCIViewToDefaultView = function(){
	this.rightClickOnCMDBCIFormHeader();
	this.clickOnViewOptionInCMDBCIFormHeader();
	this.clickOnDefaultViewOptionInCMDBCIFormHeader();
}

snow.prototype.getTextCMDBShellCIName = function(){
	var cmdShellICIName = element(by.css(this.cmdbShellCINameCss));
	browser.wait(EC.visibilityOf(cmdShellICIName),90000);
	return cmdShellICIName.getAttribute('value').then(function(cmdShellICINametext){
		logger.info("CMDB Shell CI Name is : "+cmdShellICINametext);
		return cmdShellICINametext;
	})
}

snow.prototype.getTextCMDBShellCIAssignedTo = function(){
	var cmdbShellCIAssignedTo = element(by.css(this.cmdbShellCIAssignedToCss));
	browser.wait(EC.visibilityOf(cmdbShellCIAssignedTo),90000);
	return cmdbShellCIAssignedTo.getAttribute('value').then(function(cmdbShellCIAssignedTotext){
		logger.info("CMDB Shell CI Assigned To is : "+cmdbShellCIAssignedTotext);
		return cmdbShellCIAssignedTotext;
	})
}

snow.prototype.getTextCMDBShellCIInstanceID = function(){
	var cmdbShellCIInstanceID = element(by.css(this.cmdbShellCIInstanceIDCss));
	browser.wait(EC.visibilityOf(cmdbShellCIInstanceID),90000);
	return cmdbShellCIInstanceID.getAttribute('value').then(function(cmdbShellCIInstanceIDtext){
		logger.info("CMDB Shell CI Instance ID is : "+cmdbShellCIInstanceIDtext);
		return cmdbShellCIInstanceIDtext;
	})
}

snow.prototype.getTextCMDBShellCIAssignmentGroup = function(){
	var cmdbShellCIAssignmentGroup = element(by.css(this.cmdbShellCIAssignmentGroupCss));
	browser.wait(EC.visibilityOf(cmdbShellCIAssignmentGroup),90000);
	return cmdbShellCIAssignmentGroup.getAttribute('value').then(function(cmdbShellCIAssignmentGrouptext){
		logger.info("CMDB Shell CI Assignment Group is : "+cmdbShellCIAssignmentGrouptext);
		return cmdbShellCIAssignmentGrouptext;
	})
}

snow.prototype.getTextCMDBShellCIOperationalStatus = function(){
	var cmdbShellCIOperationalStatus = element(by.css(this.cmdbShellCIOperationalStatusCss));
	browser.wait(EC.visibilityOf(cmdbShellCIOperationalStatus),90000);
	return cmdbShellCIOperationalStatus.getText().then(function(cmdbShellCIOperationalStatustext){
		logger.info("CMDB Shell CI Operational Status is : "+cmdbShellCIOperationalStatustext);
		return cmdbShellCIOperationalStatustext;
	})
}

snow.prototype.getTextCMDBShellCICorrelationID = function(){
	var cmdbShellCICorrelationID = element(by.css(this.cmdbShellCICorrelationIDCss));
	browser.wait(EC.visibilityOf(cmdbShellCICorrelationID),90000);
	return cmdbShellCICorrelationID.getText().then(function(cmdbShellCICorrelationIDtext){
		logger.info("CMDB Shell CI Correlation ID is : "+cmdbShellCICorrelationIDtext);
		return cmdbShellCICorrelationIDtext;
	})
}

snow.prototype.getTextCMDBShellCIAccountID = function(){
	var cmdbShellCIAccountID = element(by.css(this.cmdbShellCIAccountIDCss));
	browser.wait(EC.visibilityOf(cmdbShellCIAccountID),90000);
	return cmdbShellCIAccountID.getAttribute('value').then(function(cmdbShellCIAccountIDtext){
		logger.info("CMDB Shell CI Account ID is : "+cmdbShellCIAccountIDtext);
		return cmdbShellCIAccountIDtext;
	})
}

snow.prototype.getTextCMDBShellCIAccountName = function(){
	var cmdbShellCIAccountName = element(by.css(this.cmdbShellCIAccountNameCss));
	browser.wait(EC.visibilityOf(cmdbShellCIAccountName),90000);
	return cmdbShellCIAccountName.getAttribute('value').then(function(cmdbShellCIAccountNametext){
		logger.info("CMDB Shell CI Account Name is : "+cmdbShellCIAccountNametext);
		return cmdbShellCIAccountNametext;
	})
}

snow.prototype.getTextCMDBActualCIName = function(){
	var cmdbActualCIName = element(by.css(this.cmdbActualCINameCss));
	browser.wait(EC.visibilityOf(cmdbActualCIName),90000);
	return cmdbActualCIName.getAttribute('value').then(function(cmdbActualCINametext){
		logger.info("CMDB Actual CI Name is : "+cmdbActualCINametext);
		return cmdbActualCINametext;
	})
}

snow.prototype.getTextCMDBActualCIObjectIDHCMSView = function(){
	var cmdbActualCIObjectIDHCMSView = element(by.css(this.cmdbActualCIObjectIDHCMSViewCss));
	browser.wait(EC.visibilityOf(cmdbActualCIObjectIDHCMSView),90000);
	return cmdbActualCIObjectIDHCMSView.getText().then(function(cmdbActualCIObjectIDHCMSViewtext){
		logger.info("CMDB Actual CI Object ID HCMS View is : "+cmdbActualCIObjectIDHCMSViewtext);
		return cmdbActualCIObjectIDHCMSViewtext;
	})
}

snow.prototype.getTextCMDBActualCIDiskSizeDefaultView = function(){
	var cmdbActualCIDiskSizeDefaultView = element(by.css(this.cmdbActualCIDiskSizeDefaultViewCss));
	browser.wait(EC.visibilityOf(cmdbActualCIDiskSizeDefaultView),90000);
	return cmdbActualCIDiskSizeDefaultView.getAttribute('value').then(function(cmdbActualCIDiskSizeDefaultViewtext){
		logger.info("CMDB Actual CI Disk Size Default View is : "+cmdbActualCIDiskSizeDefaultViewtext);
		return cmdbActualCIDiskSizeDefaultViewtext;
	})
}

snow.prototype.getTextRequestNumberInRequestPage = function(){
	var requestNumberInRequestPage = element(by.css(this.requestNumberInRequestPageCss));
	browser.wait(EC.visibilityOf(requestNumberInRequestPage),90000);
	return requestNumberInRequestPage.getAttribute('value').then(function(requestNumberInRequestPagetext){
		logger.info("Request Number in Request Page is :" +requestNumberInRequestPagetext);
		return requestNumberInRequestPagetext;
	})
}

snow.prototype.getTextRequestedForInRequestPage = function(){
	var requestedForInRequestPage = element(by.css(this.requestedForInRequestPageCss));
	browser.wait(EC.visibilityOf(requestedForInRequestPage),90000);
	return requestedForInRequestPage.getAttribute('value').then(function(requestedForInRequestPagetext){
		logger.info("Requested For in Request Page is :" +requestedForInRequestPagetext);
		return requestedForInRequestPagetext;
	})
}

snow.prototype.getTextRITMNumberInRITMPage = function(){
	var ritmNumberInRITMPage = element(by.css(this.ritmNumberInRITMPageCss));
	browser.wait(EC.visibilityOf(ritmNumberInRITMPage),90000);
	return ritmNumberInRITMPage.getAttribute('value').then(function(ritmNumberInRITMPagetext){
		logger.info("RITM Number in RITM Page is :" +ritmNumberInRITMPagetext);
		return ritmNumberInRITMPagetext;
	})
}

snow.prototype.getTextRequestNumberInRITMPage = function(){
	var requestNumberInRITMPage = element(by.css(this.requestNumberInRITMPageCss));
	browser.wait(EC.visibilityOf(requestNumberInRITMPage),90000);
	return requestNumberInRITMPage.getAttribute('value').then(function(requestNumberInRITMPagetext){
		logger.info("Request Number in RITM Page is :" +requestNumberInRITMPagetext);
		return requestNumberInRITMPagetext;
	})
}

snow.prototype.getTextRequestedForInRITMPage = function(){
	var requestedForInRITMPage = element(by.css(this.requestedForInRITMPageCss));
	browser.wait(EC.visibilityOf(requestedForInRITMPage),90000);
	return requestedForInRITMPage.getAttribute('value').then(function(requestedForInRITMPagetext){
		logger.info("Requested For in RITM Page is :" +requestedForInRITMPagetext);
		return requestedForInRITMPagetext;
	})
}

snow.prototype.getTextShellCIInRITMPage = function(){
	var shellCIInRITMPage = element(by.css(this.shellCIInRITMPageCss));
	browser.wait(EC.visibilityOf(shellCIInRITMPage),90000);
	return shellCIInRITMPage.getAttribute('value').then(function(shellCIInRITMPagetext){
		logger.info("Shell CI in RITM Page is :" +shellCIInRITMPagetext);
		return shellCIInRITMPagetext;
	})
}

snow.prototype.getTextChangeReqNumber = function(){
	var changeReqNumber = element(by.css(this.changeReqNumberCss));
	browser.wait(EC.visibilityOf(changeReqNumber),90000);
	return changeReqNumber.getAttribute('value').then(function(changeReqNumbertext){
		logger.info("Change Request Number is :" +changeReqNumbertext);
		return changeReqNumbertext;
	})
}

snow.prototype.getTextChangeReqShortDesc = function(){
	var changeReqShortDesc = element(by.css(this.changeReqShortDescCss));
	browser.wait(EC.visibilityOf(changeReqShortDesc),90000);
	return changeReqShortDesc.getAttribute('value').then(function(changeReqShortDesctext){
		logger.info("Change Request Short Description is :" +changeReqShortDesctext);
		return changeReqShortDesctext;
	})
}


snow.prototype.getTextChangeReqDesc = function(){
	var changeReqDesc = element(by.css(this.changeReqDescCss));
	browser.executeScript("arguments[0].scrollIntoView();", changeReqDesc.getWebElement());
	browser.wait(EC.visibilityOf(changeReqDesc),90000);
	return changeReqDesc.getAttribute('value').then(function(changeReqDesctext){
		logger.info("Change Request Description is :" +changeReqDesctext);
		return changeReqDesctext;
	})
}

snow.prototype.getTextCatalogTaskNumber = function(){
	var catalogTaskNumber = element(by.css(this.catalogTaskNumberCss));
	browser.wait(EC.visibilityOf(catalogTaskNumber),90000);
	return catalogTaskNumber.getAttribute('value').then(function(catalogTaskNumbertext){
		logger.info("Catalog Task Number is :" +catalogTaskNumbertext);
		return catalogTaskNumbertext;
	})
}

snow.prototype.getTextShellCIInCatalogTaskPage = function(){
	var shellCIInCatalogTaskPage = element(by.css(this.shellCIInCatalogTaskPageCss));
	browser.wait(EC.visibilityOf(shellCIInCatalogTaskPage),90000);
	return shellCIInCatalogTaskPage.getAttribute('value').then(function(shellCIInCatalogTaskPagetext){
		logger.info("Shell CI in Catalog Task Page is :" +shellCIInCatalogTaskPagetext);
		return shellCIInCatalogTaskPagetext;
	})
}

snow.prototype.getTextRITMNumberInCatalogTaskPage = function(){
	var ritmNumberInCatalogTaskPage = element(by.css(this.ritmNumberInCatalogTaskPageCss));
	browser.wait(EC.visibilityOf(ritmNumberInCatalogTaskPage),90000);
	return ritmNumberInCatalogTaskPage.getAttribute('value').then(function(ritmNumberInCatalogTaskPagetext){
		logger.info("RITM Number in Catalog Task Page is :" +ritmNumberInCatalogTaskPagetext);
		return ritmNumberInCatalogTaskPagetext;
	})
}

snow.prototype.getTextCatalogTaskShortDec = function(){
	var catalogTaskShortDec = element(by.css(this.catalogTaskShortDecCss));
	browser.wait(EC.visibilityOf(catalogTaskShortDec),90000);
	return catalogTaskShortDec.getAttribute('value').then(function(catalogTaskShortDectext){
		logger.info("Catalog Task Short Description is :" +catalogTaskShortDectext);
		return catalogTaskShortDectext;
	})
}

snow.prototype.getTextCatalogTaskAssignmentGroup = function(){
	var catalogTaskAssignmentGroup = element(by.css(this.catalogTaskAssignmentGroupCss));
	browser.wait(EC.visibilityOf(catalogTaskAssignmentGroup),90000);
	return catalogTaskAssignmentGroup.getAttribute('value').then(function(catalogTaskAssignmentGrouptext){
		logger.info("Catalog Task Assignment Group is :" +catalogTaskAssignmentGrouptext);
		return catalogTaskAssignmentGrouptext;
	})
}

snow.prototype.getTextMCMPVersionRITMVariable = function(){
	var mcmpVersionRITMVariable = element(by.css(this.mcmpVersionRITMVariableCss));
	browser.wait(EC.visibilityOf(mcmpVersionRITMVariable),90000);
	return mcmpVersionRITMVariable.getAttribute('value').then(function(mcmpVersionRITMVariabletext){
		logger.info("MCMP Version is : "+mcmpVersionRITMVariabletext);
		return mcmpVersionRITMVariabletext;
	})
}

snow.prototype.getTextLabelsRITMVariable = function(){
	var labelsRITMVariable = element(by.css(this.labelsRITMVariableCss));
	browser.wait(EC.visibilityOf(labelsRITMVariable),90000);
	return labelsRITMVariable.getAttribute('value').then(function(labelsRITMVariabletext){
		logger.info("Label is : "+labelsRITMVariabletext);
		return labelsRITMVariabletext;
	})
}

snow.prototype.getTextChangeRequiredRITMVariable = function(){
	var changeRequiredRITMVariable = element(by.css(this.changeRequiredRITMVariableCss));
	browser.wait(EC.visibilityOf(changeRequiredRITMVariable),90000);
	return changeRequiredRITMVariable.getAttribute('value').then(function(changeRequiredRITMVariabletext){
		logger.info("Change Required Text is: "+changeRequiredRITMVariabletext);
		return changeRequiredRITMVariabletext;
	})
}

snow.prototype.getTextProvisioningChangeTaskClosureMsg = function(){
	var provisioningChangeTaskClosureMsg = element(by.css(this.provisioningChangeTaskClosureMsgCss));
	browser.wait(EC.visibilityOf(provisioningChangeTaskClosureMsg),90000);
	return provisioningChangeTaskClosureMsg.getAttribute('value').then(function(provisioningChangeTaskClosureMsgtext){
		logger.info("Provisioning Change Task Message is : "+provisioningChangeTaskClosureMsgtext);
		return provisioningChangeTaskClosureMsgtext;
	})
}

snow.prototype.getTextChangeTaskNumber = function(){
	var changeTaskNumber = element(by.css(this.changeTaskNumberCss));
	browser.wait(EC.visibilityOf(changeTaskNumber),90000);
	return changeTaskNumber.getAttribute('value').then(function(changeTaskNumbertext){
		logger.info("Provisioning Change Task Number is : "+changeTaskNumbertext);
		return changeTaskNumbertext;
	})
}

snow.prototype.getTextShellCIInChangeTaskPage = function(){
	var shellCIInChangeTaskPage = element(by.css(this.shellCIInChangeTaskPageCss));
	browser.wait(EC.visibilityOf(shellCIInChangeTaskPage),90000);
	return shellCIInChangeTaskPage.getAttribute('value').then(function(shellCIInChangeTaskPagetext){
		logger.info("Shell CI Linked to Provisioning Change Task is : "+shellCIInChangeTaskPagetext);
		return shellCIInChangeTaskPagetext;
	})
}

snow.prototype.getTextChangeRequestNumberInChangeTaskPage = function(){
	var changeRequestNumberInChangeTaskPage = element(by.css(this.changeRequestNumberInChangeTaskPageCss));
	browser.wait(EC.visibilityOf(changeRequestNumberInChangeTaskPage),90000);
	return changeRequestNumberInChangeTaskPage.getAttribute('value').then(function(changeRequestNumberInChangeTaskPagetext){
		logger.info("Change Request Number in Provisioning Change Task is : "+changeRequestNumberInChangeTaskPagetext);
		return changeRequestNumberInChangeTaskPagetext;
	})
}

snow.prototype.getTextChangeTaskShortDesc = function(){
	var changeTaskShortDesc = element(by.css(this.changeTaskShortDescCss));
	browser.wait(EC.visibilityOf(changeTaskShortDesc),90000);
	return changeTaskShortDesc.getAttribute('value').then(function(changeTaskShortDesctext){
		logger.info("Provisioning Change Task Short Description is : "+changeTaskShortDesctext);
		return changeTaskShortDesctext;
	})
}

snow.prototype.getTextProvisioningChangeTaskReadOnlyState = function(){
	var changeTaskReadOnlyState = element(by.css(this.changeTaskReadOnlyStateCss));
	browser.wait(EC.visibilityOf(changeTaskReadOnlyState),90000);
	return changeTaskReadOnlyState.getText().then(function(changeTaskReadOnlyStateText){
		logger.info("Provisioning Change Task Sate is : "+changeTaskReadOnlyStateText);
		return changeTaskReadOnlyStateText;
	})
}

snow.prototype.getTextProvisioningChangeTaskState = function(){
	var changeTaskState = element(by.css(this.changeTaskStateCss));
	browser.wait(EC.visibilityOf(changeTaskState),90000);
	return changeTaskState.getText().then(function(changeTaskStateText){
		logger.info("Provisioning Change Task Sate is : "+changeTaskStateText);
		return changeTaskStateText;
	})
}

snow.prototype.getTextAssignmentGroupChangeTask = function(){
	var assignmentGroupChangeTask = element(by.css(this.assignmentGroupChangeTaskCss));
	browser.wait(EC.visibilityOf(assignmentGroupChangeTask),90000);
	return assignmentGroupChangeTask.getAttribute('value').then(function(assignmentGroupChangeTasktext){
		logger.info("Provisioning Change Task Assignment Group is : "+assignmentGroupChangeTasktext);
		return assignmentGroupChangeTasktext;
	})
}

snow.prototype.getTextAssignedToChangeTask = function(){
	var assignedToChangeTask = element(by.css(this.assignedToChangeTaskCss));
	browser.wait(EC.visibilityOf(assignedToChangeTask),90000);
	return assignedToChangeTask.getAttribute('value').then(function(assignedToChangeTasktext){
		logger.info("Provisioning Change Task Assignment To is : "+assignedToChangeTasktext);
		return assignedToChangeTasktext;
	})
}

snow.prototype.enterDescTextinProvisioningChangeTask = function(){
	var elem = element(by.css(this.textChangeTaskDescCss));
	browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());
	browser.wait(EC.visibilityOf(elem),90000);
	elem.sendKeys(this.closeNotesText).then(function(){
		logger.info("Entered Success in Change Task Description");
    });
}

snow.prototype.openProvisioningChangeTask = function(){
	this.clickChangeTaskTabInChangeRequest();
	this.clickProvTaskLink();
}

snow.prototype.closeProvisioningChangeTask = function(){
	this.enterDescTextinProvisioningChangeTask();
	this.clickUpdateButton();
}

snow.prototype.clickClosureInfoInChangeTask = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.tabChangeReqClosureInfoXpath))),30000).then(function(){
		logger.info("Wait till Closure Information tab in Change Task is displayed");
	});
     element(by.xpath(this.tabChangeReqClosureInfoXpath)).click().then(function(){
		logger.info("Clicked on Closure Information tab in Change Task");
    }).catch(function(err){
		logger.info("Exception occured while clicking Closure Information tab in Change Task.");
    });
}

snow.prototype.getTextProvisioningSuccesfulChangeTaskMsg = function(){
	var provisioningChangeTaskClosureMsg = element(by.css(this.provisioningSuccesfulChangeTaskMsgCss));
	browser.wait(EC.visibilityOf(provisioningChangeTaskClosureMsg),90000);
	return provisioningChangeTaskClosureMsg.getText().then(function(provisioningChangeTaskClosureMsgText){
		logger.info("Provisioning Change Task Message is : "+provisioningChangeTaskClosureMsgText);
		return provisioningChangeTaskClosureMsgText;
	})
}

snow.prototype.getTextIncidentNumber = function(){
	var textIncidentNumber = element(by.css(this.textIncidentNumberCss));
	browser.wait(EC.visibilityOf(textIncidentNumber),90000);
	return textIncidentNumber.getText().then(function(textIncidentNumbervalue){
		logger.info("Incident Number is: "+textIncidentNumbervalue);
		return textIncidentNumbervalue;
	})
}

snow.prototype.getTextShellCIInIncidentPage = function(){
	var shellCIInIncidentPage = element(by.css(this.shellCIInIncidentPageCss));
	browser.wait(EC.visibilityOf(shellCIInIncidentPage),90000);
	return shellCIInIncidentPage.getAttribute('value').then(function(shellCIInIncidentPagetext){
		logger.info("Shell CI Linked to Incident created is : "+shellCIInIncidentPagetext);
		return shellCIInIncidentPagetext;
	})
}

snow.prototype.clickRequestApprovalInChangeRequestPage = function(){
	browser.navigate().refresh();
	this.switchToParentFrame();
	browser.sleep(5000);
	var requestApprovalInChangeRequestPage = element(by.css(this.requestApprovalInChangeRequestPageCss));
	browser.wait(EC.elementToBeClickable(requestApprovalInChangeRequestPage),90000);
	requestApprovalInChangeRequestPage.click().then(function(){
		logger.info("Clicked on Request Approval in Change Request Page");
		browser.sleep(5000);
	});
}

snow.prototype.selectAssignGrpValueChangeTask = function(){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(self.selectAssignGrpValueChangeTaskCss))),90000);
	element(by.css(self.selectAssignGrpValueChangeTaskCss)).clear().then(function() {
		element(by.css(self.selectAssignGrpValueChangeTaskCss)).sendKeys("Change");
		browser.sleep(2000);
		element(by.css(self.selectAssignGrpValueChangeTaskCss)).sendKeys(protractor.Key.ARROW_DOWN).then(function(){
			element(by.css(self.selectAssignGrpValueChangeTaskCss)).sendKeys(protractor.Key.ENTER).then(function(){
				logger.info("Selected Assignment Group value");
			});
		});
	});
}

snow.prototype.selectAssignedToValueChangeTask = function(){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(this.selectAssignedToValueChangeTaskCss))),90000);
	element(by.css(this.selectAssignedToValueChangeTaskCss)).sendKeys("Change");
	browser.sleep(2000);
	element(by.css(self.selectAssignedToValueChangeTaskCss)).sendKeys(protractor.Key.ARROW_DOWN).then(function(){
		element(by.css(self.selectAssignedToValueChangeTaskCss)).sendKeys(protractor.Key.ENTER).then(function(){
			logger.info("Selected Assigned To value");
		});
	});
}

snow.prototype.clickOnCopySysIDChangeRequest = function(){	
	browser.wait(EC.visibilityOf(element(by.xpath(this.changeRequestCopySysIdXpath))),90000);
 	return	element(by.xpath(this.changeRequestCopySysIdXpath)).getAttribute("href").then(function(copiedChangeRequestSysIDValue){
		logger.info("Copied Sys_Id Value of Change Request is :",copiedChangeRequestSysIDValue);
		var changeRequestSysIDValue =  copiedChangeRequestSysIDValue.substr(17,32);
		logger.info("Sys_Id Value of Change Request is :",changeRequestSysIDValue);
		return changeRequestSysIDValue;
	});
}

//Retrieve Correlation Display in request page
snow.prototype.getTextCorrelationDisplayQS= function(){
	var correlDisplay = element(by.css(this.textCorrelationDisplayCss));
	browser.wait(EC.visibilityOf(correlDisplay),90000);
	return correlDisplay.getAttribute("value").then(function(correlDisplayText){
		logger.info("Correlation Display is : "+correlDisplayText);
		return correlDisplayText;
	})
}

snow.prototype.waitUntilTwelfthChangeTaskClosed = function(repeatCount){
	var self = this;
	if(repeatCount == undefined){
		repeatCount = 1500;
	}
	repeatCount = repeatCount-1;
	if(repeatCount>0) {
		var task = element.all(by.xpath(self.textChangeTasksStateXpath)).get(11);
		browser.executeScript("arguments[0].scrollIntoView();", task.getWebElement());
		browser.wait(EC.visibilityOf(task),90000);
		task.getText().then(function(state){
			if(state == "In Progress") {
				logger.info("Change Task 12 is in progress => Continue looping");
				self.clickChangeRequestChangeTasksButton();
				browser.sleep(3000);
				self.waitUntilTwelfthChangeTaskClosed(repeatCount);
			}
			else if(state == "Closed") {
				logger.info("Change Task 12 is Closed");
				repeatCount = 0;
				return;
			}
		})
	}
}





 module.exports = snow;    

