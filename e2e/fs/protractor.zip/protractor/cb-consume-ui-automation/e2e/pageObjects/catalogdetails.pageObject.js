"use strict";

var extend = require('extend');
var url = browser.params.url;
var util = require('../../helpers/util.js');
var logGenerator = require("../../helpers/logGenerator.js"),
logger = logGenerator.getApplicationLogger();
var timeout = require('../../testData/timeout.json');
var EC = protractor.ExpectedConditions;

var defaultConfig = {
    buttonTextConfigure: 'Configure',
    configureButtonId:'#configure-service',
    buttonTextCancel: 'Close',
    titleLabelCss: 'span.details-title',
    featureInfo: '.features-list',
    detailsInfo: '#details-terms',
    textServiceLabelCss : "[type='ibm'] span span",
    linkTextLinkToProviderSite: 'Provider Site',
    ProvidersiteButtonCss : '#provider-link',
    catalogLinkText: 'Catalog',
    catalogNameLabelCss: 'h1.ibm--page-header__title',
    estimatedPriceTxtCss: '.details-price>p>strong',
    textServiceLabelCss: 'ibm-tag',
    textSameVersionValidationMsgCss:'edit-service-details div.bx--modal-content>div>p'
};

function catalogDetails(selectorConfig) {
    if (!(this instanceof catalogDetails)) {
        return new catalogDetails(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

// Verify Configure button is displayed or not from details page
catalogDetails.prototype.isDisplayedConfigureButtonOnDetails = function () {
    let configBtn = element(by.css(this.configureButtonId));
    browser.wait(EC.visibilityOf(configBtn),9000).then(function(){
        logger.info("Configure Button is present on Details page");
    });
    return configBtn.isDisplayed(); 
};

// Click on configure button from details page
catalogDetails.prototype.clickConfigureButtonCatalogDetailsPage = function () {
    var configBtn = element(by.css(this.configureButtonId));
    browser.wait(EC.visibilityOf(configBtn),9000).then(function(){
		configBtn.click().then(function(){
			logger.info("Clicked on Configure button from Details page");
		})
	});
};

catalogDetails.prototype.isDisplayedCancelButtonCatalogDetailsPage = function () {
    return element(by.buttonText(this.buttonTextCancel)).isDisplayed();
    util.waitForAngular();
};

catalogDetails.prototype.clickCancelButtonCatalogDetailsPage = function () {
    //browser.refresh().then(function () {
    	//browser.sleep(5000);
            //browser.wait(EC.visibilityOf(element(by.buttonText(this.buttonTextCancel))), 30000);
       // }
   // );

    return element(by.buttonText(this.buttonTextCancel)).click();
    util.waitForAngular();
};

// Get service name from details page
catalogDetails.prototype.getServiceName = function () {
    let serviceName = element(by.css(this.catalogNameLabelCss));
    browser.wait(EC.visibilityOf(serviceName), timeout.timeoutInMilis);
    return serviceName.getText().then(function (text) {
        logger.info("Service name is : " + text)
        return text;
    });

};


/**
 * Method to get labels name from details section
 */
catalogDetails.prototype.getLabelsName = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.textServiceLabelCss))), timeout.timeoutInMilis);
    return element.all(by.css(this.textServiceLabelCss)).getText().then(function(text) {
        logger.info("labels name are : " + text);
        var msg;
        if(text.length == 1){
            msg = text.toString(); 
        }else{
            msg = text;
        }
        return msg;
    });

};


// Get text of Features label from details page
catalogDetails.prototype.getTextFeaturesLabel = function () {
    var featureLabel = element.all(by.css(this.titleLabelCss)).get(1);
    browser.wait(EC.visibilityOf(featureLabel),9000);
    return featureLabel.getText().then(function (text) {
        logger.info("Text in Feature label : " + text)
        return text;
    });
};

// Verify Feature label is present or not on details page
catalogDetails.prototype.isPresentFeaturesLabel = function () {
    let featureLabel = element.all(by.css(this.titleLabelCss)).get(0);
    browser.wait(EC.visibilityOf(featureLabel),9000).then(function(){
        logger.info("Feature label is present on Details page");
    });
    return featureLabel.isPresent();
};

// Get text of Details label from details page
catalogDetails.prototype.getTextDetailsLabel = function () {
    return element.all(by.css(this.titleLabelCss)).get(2).getText().then(function (text) {
        logger.info("Text in Details label : " + text)
        return text;
    });
};

// Get text/validaton for upgrade or downgrade a service version to same version 
catalogDetails.prototype.getTextSameVersionValidationMsg = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.textSameVersionValidationMsgCss))), timeout.timeoutInMilis);
        return element.all(by.css(this.textSameVersionValidationMsgCss)).getText().then(function (text) {
            logger.info("Text in unable to configure : " + text)
            var msg;
            if(text.length == 1){
                msg = text.toString(); 
            }else{
                msg = text;
            }
            return msg;
        });
};

// Verify Details label is present or not on details page
catalogDetails.prototype.isPresentDetailsLabel = function () {
    let detailsLabel = element.all(by.css(this.titleLabelCss)).get(1);
    browser.wait(EC.visibilityOf(detailsLabel),9000).then(function(){
        logger.info("Details label is present on Details page");
    });
    return detailsLabel.isPresent();
};

// Verify Feature label info is present or not on details page
catalogDetails.prototype.isPresentFeaturesInfo = function () {
    let featureInfo = element(by.css(this.featureInfo));
    browser.wait(EC.visibilityOf(featureInfo),9000).then(function(){
        logger.info("Feature Info is present on Details page");
    });
    return featureInfo.isPresent();
};

// Verify Details label info is present or not on details page
catalogDetails.prototype.isPresentDetailsInfo = function () {
    let detailsInfo = element(by.css(this.detailsInfo));
    browser.wait(EC.visibilityOf(detailsInfo),9000).then(function(){
        logger.info("Details Info is present on Details page");
    });
    return detailsInfo.isPresent();
};

// Get the estimated cost from details page
catalogDetails.prototype.getTextEstimatedPrice = function()
{
    let estimatedCost = element(by.css(this.estimatedPriceTxtCss)); 
    browser.wait(EC.visibilityOf(estimatedCost),9000);
    return estimatedCost.getText().then(function(estimatedPrice){
        logger.info("The estimated price on Details page is : " + estimatedPrice)
        return estimatedPrice;
    });
};

catalogDetails.prototype.getTextKnowMoreLabel = function () {
    return element.all(by.css(this.titleLabelCss)).get(2).getText().then(function (text) {
        logger.info("Text in Catalog details page is : " + text)
        return text;
    });
};

catalogDetails.prototype.isPresentKnowMoreLabel = function () {
    return element.all(by.css(this.titleLabelCss)).get(2).isPresent();
};

catalogDetails.prototype.clickLinkToProviderSite = function () {
    return element(by.linkText(this.linkTextLinkToProviderSite)).click();
};

// Verify Provider site button is present or not on details page
catalogDetails.prototype.isPresentLinkToProviderSite = function () {
    let providerSiteBtn = element(by.css(this.ProvidersiteButtonCss));
    browser.wait(EC.visibilityOf(providerSiteBtn),9000).then(function(){
        logger.info("Provider site Button is present on Details page");
    });
    return providerSiteBtn.isPresent();
};

// Click on Catalog bread-crumb navigation from details page
catalogDetails.prototype.clickCatalogFromBreadCrumbNav = function () {
    var catalogBreadCrumbLink = element(by.linkText(this.catalogLinkText));
    browser.wait(EC.elementToBeClickable(catalogBreadCrumbLink),90000).then(function(){
        browser.executeScript("arguments[0].click();", catalogBreadCrumbLink.getWebElement()).then(function(){
			logger.info("Clicked on Catalog bread-crumb nav.");

		})
	});
}

catalogDetails.prototype.getTextServiceLabel = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textServiceLabelCss))),90000);
	return element.all(by.css(this.textServiceLabelCss)).getText().then(function(label){
		logger.info("Service label is: " + label);
		return label;
	})
};
module.exports = catalogDetails;
