/**********************
 * Author : Pushpraj
 **********************/
"use strict";
var extend = require('extend');
var url = browser.params.url;
var logGenerator = require("../../helpers/logGenerator.js"),
	logger = logGenerator.getApplicationLogger();
var timeout = require('../../testData/timeout.json');
var appUrls = require('../../testData/appUrls.json');
var EC = protractor.ExpectedConditions;
var path = require('path');
var util = require('../../helpers/util.js');
//const {keyboard, Key} = require("@nut-tree/nut-js");
//var robot = require("robotjs");

var defaultConfig = {
	pageUrl:                      		url + '/consume/catalogAdmin',
	headerNameCss:						"a.bx--header__name",
	headerTitleCss:						"#page-title",
	historyPageTileCss:					"#catalog-admin-history_header-title",
	startCatalogDiscoveryCss:			"#show-catalog-discovery-panel",
	startProviderCatalogDiscvryXpath:	"//h3[@id='card-title-2'][contains(text(),'",
	chooseAccountFromDropDownCss:		"#bx--dropdown-single-parent_provider-account",
	//selectValueFromAccDropDwnXpath:		"//li[@class='bx--dropdown-item']//label[contains(text(), '",
	selectValueFromAccDropDwnXpath:		"//button[contains(text(), '",
	okButtonFromDiscoveryPopupCss:		"#privacy-policy-modal_carbon-confirm-button_ok",
	discoveryStartedPopupMsgCss:		"#privacy-policy-content p",
	okFromDiscoveryStartedPopupCss:		'#privacy-policy-modal_carbon-button_ok',
	discoveryIsInProgressXpath:			"//p[@class='provider-date'][contains(text(), 'In Progress')]",
	discoveryStatusCss:					".provider-date",
	vraHistoryLinkCss:					"a[href='/catalogAdmin/history?providerCode=vra']",
	icamHistoryLinkCss:					"a[href='/consume/catalogAdmin/catalogManagement/history?providerCode=icam&providerName=Terraform%20Automation']",
	accountNameFromHistoryCss:			".header-account-name-value",
	statusFromHistoryCss:				"span.bx--tag.bx--tag--community",
	headerFromHistoryCss:				"strong",
	discoveryStartedXpath:				"//h2[@class='bx--modal-header__heading'][contains(text(), 'Discovery Started')]",
	draftSectionCss:					"#tab-control-catalog-admin--draft-tab",
	publishedSectionCss:				"#tab-control-catalog-admin--published-tab",
	retiredSectionCss:					"#tab-control-catalog-admin--retired-tab",
	searchServiceOrProviderCss:			"input[class='bx--search-input']:nth-child(3)",
	threeDotIconXpath:					"/ancestor::td/following-sibling::td[last()]//*[@class='bx--overflow-menu__icon']",
	viewDetailsCss:						"//*[@class='bx--overflow-menu-options__btn'][contains(text(),' View Details ')]",
	editButtonCss:						"#editSelectedConfig",
	categoryDrpDwnFromEditCss:			"#bx--dropdown-single-parent_service-detail-category",
	selectComputeOptionFrmDrpDwnCss:	"#dropdown-option_service-detail-category_compute",
	fileUploadInputBoxCss:				"#text-input-fileName",
	storeHeaderCss: 					'.bx--header__name',
	uploadBtnCss:						"#button-uploadFile",
	addLabelInputCss:					"#tag-input",
	removeAddedLableCss:				"app-tag-input svg.close",
	labelsTextCss:						".tag-text",
	saveBtnCss:							"#save",
	cancelBtnCss:						"#cancelSelectedConfig",
	cancelYesBtnCss:					"#service_details_panel_yes",
	sliderCloseBtnCss:					"span.bx--slide-over-panel--close",
	catalogDiscoveryLinkCss:			"#catalog-discovery-link",
	editedServiceStatusXpath:			"/ancestor::td/following-sibling::td[last()-1][1]",
	publishServiceLinkCss:				 "//*[@class='bx--overflow-menu-options__btn'][contains(text(),'Publish')]",
	serviceNameFromSearchSectionCss: 	"#carbon-deluxe-data-table-2 tr td:nth-child(2) span",
	serviceNameFromDraftSearchSecCss: 	"#carbon-deluxe-data-table-1 tr:nth-child(1) td:nth-child(2) span",
	publishedSerivceDateCss:			"div[type='overflow']",
	noDataAvailabeCss:					"h4 strong",
	retireButtonXpath:					"//*[@class='bx--overflow-menu-options__btn'][contains(text(),'Retire')]",   
	unretireButtonXpath:					"//*[@class='bx--overflow-menu-options__btn'][contains(text(),' Unretire ')]",
	deleteButtonCss:					"#carbon-deluxe-data-table-1-parent-row-1-option-6-button",
	serviceConfirmationOKCss:		"#services-action-confirm-modal-ok",
	GroupToggleBtnCss:                 '.bx--link.bom-toggle.group-chevron',
	ServiceGroupDropdown: 				"//*[@class='bx--dropdown-text']",
	ServiceGroupSearchTextboxXpath: 	"//div[@class='bx--search__trigger']//*[@class='bx--label']//following-sibling::input[@class='bx--search-input']",
	versionText: 						"//tr[@class='bx--table-row bx--parent-row']//td[3]",
	ServiceGroupNameTextCss: 			"[class='bx--table-row bx--parent-row'] td:nth-child(4)",
	IsGroupFiledEnable: 				"//*[@id='text-input-group_name']",

	//-------------- Alert Notification ---------------//
	alertNotificationTitleCss:			"carbon-notification[role='alert'] div.bx--toast-notification__details p.bx--toast-notification__title",
	alertNotificationSubTitleCss:		"carbon-notification[role='alert'] div.bx--toast-notification__details p.bx--toast-notification__subtitle",
	alertNotificationCaptionCss:		"carbon-notification[role='alert'] div.bx--toast-notification__details p.bx--toast-notification__caption",
	//-------------- header locator -------------------//
	headerHumburgerCss:					"ibm-hamburger button svg",
	storeSideBarXpath:					"//*[@class='bx--side-nav__submenu']/span[contains(text(), 'Enterprise Marketplace')]/..",
	catalogAdminXpath:					"//*[@class='bx--side-nav__link-text'][contains(text(), ' Catalog Management')]",
    providerToggleBtnCss:               ".bx--link.bom-toggle.provider-chevron",
    providerSearchTextBoxCss:           "#search__input-provider-search",
	pricingTabCss:                      ".bx--tabs__nav-link",

	// --------------- Terraform automation catalog discovery locators-------------- //
	clickOkImportServiceCss: 			"#import-model-ok-button #select-provider-account",
	okButtonIbmDiscoverryStarted: 		"#privacy-policy-modal_carbon-button_ok",
	catalogDiscoveryStatus:				"(//div[@class='header-line header-pills']//ibm-tag)[1]",
	cancelDiscoveryLinkXpath: 					"//a[@id='icam-provider-cancel-discovery']",
	okCancelDiscoveryCss: 					"#cancel-discovery-modal-ok",
	MultipleAccountsDetectedText: 		"//div//label[@class='bx--label bx--form-field-required']",
	DiscoveryStartedText: 				"//h2[contains(text(),'Terraform Automation Discovery Started')]",
	// ---------------- Instance is present or not for published service (TA) ----//
	viewInstanceXpath:					"//*[@class='bx--overflow-menu-options__btn'][contains(text(),'View Instances')]",
	searchServiceInstanceNameCss:       "#data-table-search__input",
	ServiceInstanceNameCss:             "tbody tr td:nth-child(1) div div span",

	ClickOnPublishServiceCss:"//*[@class='bx--overflow-menu-options__btn'][contains(text(),'Publish')]",
	ClickOnDeleteServiceXpath: "//*[@class='bx--overflow-menu-options__btn'][contains(text(),'Delete')]",
	//------------------catalog management service life cycle locators------------//
	getServiceNameFromRetiredSearchSectionXpath:"//*[@class='bx--responsive-table-container']//*[contains(text(),' TA_Pricing service without condition ')]",
	//---------------------ok button for navigates to publish and retire section
	okNevigatesButtonCss:"#catalog-listing_action-modal_carbon-button_ok",
	//-----------------------Locators for delete service from retire section and retrire to unretire service
	deleteServiceFromRetiredCss:"#carbon-deluxe-data-table-0-parent-row-1-option-7-button",
	unretiredServiceFromRetiredCss:"#carbon-deluxe-data-table-0-parent-row-1-option-6-button",
	 //----------------------------service configurations on catalog adminpage------
	 configurationParametersCss: "a[title='Configuration Parameters']",
	 expandAllLinkXpath:"//a[contains(text(),'Expand all')]",
	 configurationText:".attribute-name",
	 viewDetailsLinkxpath:"//a[contains(text(),'View Details')]",
	 discoveryFailuretextXpath:"//p[contains(text(),'Credentials or Asset account details are not valid!')]"
}; 

function catalogDiscovery(selectorConfig) {
    if (!(this instanceof catalogDiscovery)) {
        return new catalogDiscovery(selectorConfig);
    }
    extend(this, defaultConfig);
    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

/**
 * Method to navigate to consume/catalogAdmin Page and switch to iframe
 */
catalogDiscovery.prototype.open = function(){
	util.switchToDefault();
	this.clickOnHeaderName();
	this.clickOnHeaderHumburgerLink();
	this.clickOnStoreSideBarLink();
	this.clickOnCatalogAdminLink();
	browser.wait(EC.urlContains("consume/catalogAdmin"), timeout.timeoutInMilis).then( function(){
		logger.info("Navigated to catalog Admin page ");
	});
	util.switchToFrame();
	browser.sleep(3000);
	util.waitForAngular();
};

/**
 * Method to click on Draft section link
 */
catalogDiscovery.prototype.clickOnDraftSectionLink = function(){
	util.waitForAngular();
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.elementToBeClickable(element(by.css(this.publishedSectionCss))), timeout.timeoutInMilis);
	element(by.css(this.draftSectionCss)).click().then(function(){
		logger.info("Clicked on Draft section link");
	});
};

/**
 * Method to click on Publish section link
 */
catalogDiscovery.prototype.clickOnPublishSectionLink = function(){
	util.waitForCircleStrokeToDisappear();
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.publishedSectionCss))), timeout.timeoutInMilis);	
	element(by.css(this.publishedSectionCss)).click().then(function(){
		logger.info("Clicked on publish section link");
	});
};

catalogDiscovery.prototype.clickOnGroupToggleBtn = function () {
	util.waitForAngular();
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.elementToBeClickable(element(by.css(this.GroupToggleBtnCss))), timeout.timeoutInMilis);
	element(by.css(this.GroupToggleBtnCss)).click().then(function () {
		logger.info("Clicked on group toggle button");
	});
};

catalogDiscovery.prototype.clickOnServiceGroupDropdown = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.ServiceGroupDropdown))), timeout.timeoutInMilis);
	element(by.xpath(this.ServiceGroupDropdown)).click().then(function () {
		logger.info("Clicked on group toggle button");
	});
};

catalogDiscovery.prototype.enterGroupName = function (ServiceGroupName) {
	var curr = this;
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(curr.ServiceGroupSearchTextboxXpath))), 10000).then(function () {
		element(by.xpath(curr.ServiceGroupSearchTextboxXpath)).sendKeys(ServiceGroupName).then(function () {
			logger.info("Entered ServiceGroupName");
			element(by.xpath(curr.ServiceGroupSearchTextboxXpath)).sendKeys(protractor.Key.ENTER);
			browser.sleep(5000);
			browser.wait(EC.visibilityOf(element(by.xpath("//label[contains(text(), ' " + ServiceGroupName + " ')]"))), 150000);
			browser.wait(EC.elementToBeClickable(element(by.xpath("//label[contains(text(), ' " + ServiceGroupName + " ')]"))), 60000);
			element(by.xpath("//label[contains(text(), ' " + ServiceGroupName + " ')]")).click().then(function(){
				logger.info("Clicked on service group name successfully..");
			});
		});
	});
};

catalogDiscovery.prototype.clickOnGroupName = function (ServiceGroupName) {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath("//*[contains(text(), ' " + ServiceGroupName + " ')]"))), timeout.timeoutInMilis);
	element(by.xpath("//*[contains(text(), ' " + ServiceGroupName + " ')]")).click();
	logger.info("Clicked on service group name successfully..")

};

catalogDiscovery.prototype.getVersionText = function () {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.versionText))), timeout.timeoutInMilis);
	return element(by.xpath(this.versionText)).getText().then(function (versionText) {
		logger.info("Vesrion title text : " + versionText);
		return (versionText.toString()).trim();
	});
};

catalogDiscovery.prototype.getServiceGroupNameText = function () {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.ServiceGroupNameTextCss))), 60000);
	return element(by.css(this.ServiceGroupNameTextCss)).getText().then(function (servicenametext) {
		logger.info("ServiceGroupNameText title text : " + servicenametext);
		return (servicenametext.toString()).trim();
	});
};

catalogDiscovery.prototype.EnterInvalidGroupName = function (InvalidGroupNmae) {
	util.waitForAngular();
	var elemToClick = element(by.xpath(this.IsGroupFiledEnable));
	browser.executeScript("arguments[0].scrollIntoView(true);", elemToClick);
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.IsGroupFiledEnable))), 25000);
	var searchInputBox = element(by.xpath(this.IsGroupFiledEnable));
	searchInputBox.clear();
	searchInputBox.sendKeys(InvalidGroupNmae);
	searchInputBox.sendKeys(protractor.Key.ENTER).then(function () {
		logger.info("Entered InvalidGroup Name");
		util.waitForAngular();
	});

};

catalogDiscovery.prototype.getNotificationErrorForSameGroup = function () {
	util.waitForAngular();
	return element(by.xpath(this.NotificationErrorForSameGroup)).getText().then(function (NotificationErrorForSameGroup) {
		logger.info("NotificationErrorForSameGroup text : " + NotificationErrorForSameGroup);
		return (NotificationErrorForSameGroup.toString()).trim();
	})

};

/**
 * Method to click on REtired section link
 */
catalogDiscovery.prototype.clickOnRetiredSectionLink = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.retiredSectionCss))), timeout.timeoutInMilis);
	element(by.css(this.retiredSectionCss)).click().then(function(){
		logger.info("Clicked on retired section link");
	});
};

/**
 * Method to click on start catalog discovery button
 */
catalogDiscovery.prototype.clickOnStartCatalogDiscoveryBtn = function(){
	util.waitForCircleStrokeToDisappear();
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.startCatalogDiscoveryCss))), timeout.timeoutInMilis);
	element(by.css(this.startCatalogDiscoveryCss)).click().then(function(){
		logger.info("Clicked on Start Catalog discovery button");
	});
};

/**
 * Method to click on start discovey based on provider details provided
 */
catalogDiscovery.prototype.clickOnProviderToStartDiscovery = function(serviceCategoryProvider){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.startProviderCatalogDiscvryXpath + serviceCategoryProvider + "')]"))), timeout.timeoutInMilis);
	element(by.xpath(this.startProviderCatalogDiscvryXpath + serviceCategoryProvider + "')]")).click().then(function(){
		logger.info("Clicked on Start "+serviceCategoryProvider+" discovery button");
	});
};

/**
 * Method to select VRA account based on input provided
 */
catalogDiscovery.prototype.selectVraAccountFromDrpDwn = function(serviceAccount){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.chooseAccountFromDropDownCss))), timeout.timeoutInMilis);
	element(by.css(this.chooseAccountFromDropDownCss)).click().then(function(){
		logger.info("Clicked DropDown Icon to select VRA Account");
	});
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.selectValueFromAccDropDwnXpath +serviceAccount+"')]"))), timeout.timeoutInMilis);
	element(by.xpath(this.selectValueFromAccDropDwnXpath +serviceAccount+"')]")).click().then(function(){
		logger.info("Selected "+serviceAccount+" value from drop down");
	});
};

/**
 * Method to click on OK button from discovery popup
 */
catalogDiscovery.prototype.clickOnOKBtnFromDiscoveryPopup = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.okButtonFromDiscoveryPopupCss))), timeout.timeoutInMilis);
	element(by.css(this.okButtonFromDiscoveryPopupCss)).click().then(function(){
		logger.info("Clicked on ok button from discovery popup");
	});
};

/**
 * Method to get discovery started popup message for VRA
 */
catalogDiscovery.prototype.getDiscoveryStartedPopupMsg = function(serviceName){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element.all(by.css(this.discoveryStartedPopupMsgCss)).get(2)), timeout.timeoutInMilis);
	return element.all(by.css(this.discoveryStartedPopupMsgCss)).get(2).getAttribute('innerText').then(function(text){
		logger.info("Discovery started message popup : "+text);
		return (text.toString()).trim();
	});	
};

/**
 * Method to get discovery started popup message for ICAM
 */
catalogDiscovery.prototype.getICAMDiscoveryStartedPopupMsg = function(serviceName){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element.all(by.css(this.discoveryStartedPopupMsgCss)).get(1)), timeout.timeoutInMilis);
	return element.all(by.css(this.discoveryStartedPopupMsgCss)).get(1).getAttribute('innerText').then(function(text){
		logger.info("Discovery started message popup : "+text);
		return (text.toString()).trim();
	});	
};

/**
 * Method to wait for discovery started popup and click on OK button for the VRA
 */
catalogDiscovery.prototype.discoveryStartedPopup = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.discoveryStartedXpath))), timeout.timeoutInMilis).then(function(){
		logger.info("Discovery started message displayed");
	});
	browser.wait(EC.elementToBeClickable(element.all(by.css(this.okFromDiscoveryStartedPopupCss)).get(2)), timeout.timeoutInMilis);
	element.all(by.css(this.okFromDiscoveryStartedPopupCss)).get(2).click().then(function(){
		logger.info("Cliked on OK button from discovery started popup");
	});
};

/**
 * Method to wait for discovery started popup and click on OK button for the ICAM
 */
catalogDiscovery.prototype.discoveryStartedPopupICAM = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.discoveryStartedXpath))), timeout.timeoutInMilis).then(function(){
		logger.info("Discovery started message displayed");
	});
	browser.wait(EC.elementToBeClickable(element.all(by.css(this.okFromDiscoveryStartedPopupCss)).get(1)), timeout.timeoutInMilis);
	element.all(by.css(this.okFromDiscoveryStartedPopupCss)).get(1).click().then(function(){
		logger.info("Cliked on OK button from discovery started popup");
	});
};

/**
 * click on the provider toggle btn and search for Provider.
 */

catalogDiscovery.prototype.clickOnProvidersToggleBtn = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.providerToggleBtnCss))), timeout.timeoutInMilis);
	element(by.css(this.providerToggleBtnCss)).click().then(function(){
		logger.info("Clicked on provider toggle button");
	});
};

catalogDiscovery.prototype.searchProviderByName = function(providerName){
	browser.wait(EC.visibilityOf(element(by.css(this.providerSearchTextBoxCss))),50000);
	var searchInputBox = element(by.css(this.providerSearchTextBoxCss));
	searchInputBox.clear();
	searchInputBox.sendKeys(providerName);
	searchInputBox.sendKeys(protractor.Key.ENTER).then(function(){
		logger.info("Entered VRA in search box");
		//util.waitForAngular();
	});
	
};


/**
 * Method to get status of discovery for VRA
 */
catalogDiscovery.prototype.getDiscoveryStatus = function(){
	browser.wait(EC.visibilityOf(element.all(by.css(this.discoveryStatusCss)).get(0)), timeout.timeoutInMilis);
	return element.all(by.css(this.discoveryStatusCss)).get(0).getText().then(function(text){
		logger.info("Discovery status : "+text);
		return text;
	});
	
};

/**
 * Method to get status of discovery for ICAM
 */
catalogDiscovery.prototype.getICAMDiscoveryStatus = function(){
	browser.wait(EC.visibilityOf(element.all(by.css(this.discoveryStatusCss)).get(1)), timeout.timeoutInMilis);
	return element.all(by.css(this.discoveryStatusCss)).get(1).getText().then(function(text){
		logger.info("Discovery status : "+text);
		return text;
	});
	
};

/**
 * Method to click on VRA History Link
 */
catalogDiscovery.prototype.clickOnVraHistoryLink = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.vraHistoryLinkCss))), timeout.timeoutInMilis);
	element(by.css(this.vraHistoryLinkCss)).click().then(function(){
		logger.info("Clicked on VRA History Link");
	});
};


/**
 * Method to click on VRA History Link
 */
catalogDiscovery.prototype.clickOnICAMHistoryLink = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.icamHistoryLinkCss))), timeout.timeoutInMilis);
	element(by.css(this.icamHistoryLinkCss)).click().then(function(){
		logger.info("Clicked on ICAM History Link");
	});
};

/**
 * Method to wait for discovery completed status..
 * This method will wait for 2:30 min for every unsuccessfull message
 * This process will repeat upto 30
 */
catalogDiscovery.prototype.waitToCompletDiscoveryStatus = function(repeatCount,providerName){
	var curr = this;
	if (repeatCount == undefined) {
        repeatCount = 30;
    }
	if (providerName == undefined) {
		providerName = "VRA";
    }
    repeatCount = repeatCount - 1;
	if (repeatCount > 0) {
		curr.open();
		curr.clickOnProvidersToggleBtn();
		curr.searchProviderByName(providerName);
		curr.getDiscoveryStatus().then(function(status){
			if(status == "In Progress"){
				logger.info("Discovery is in progress wait for some time");
				browser.sleep(100000);
				curr.waitToCompletDiscoveryStatus();
			}
			else {
			        logger.info("Discovery completed at "+status+" breaking the loop");
                    repeatCount = 0;
                    return;
                }
		});
		/*curr.getICAMDiscoveryStatus().then(function(status){
			if(status=="In Progress"){
				logger.info("Discovery is in progress wait for some time");
				browser.sleep(150000);
				curr.waitToCompletDiscoveryStatus();
			}
		});*/
	} else{
		logger.info("Maximum tries "+repeatCount + "is exceeded and dicovery is not completed");
	}
};

/**
 * Method to get first Account name from history section
 */
catalogDiscovery.prototype.getAccountNameFromHistroySec = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element.all(by.css(this.accountNameFromHistoryCss)).get(0)), timeout.timeoutInMilis);
	return element.all(by.css(this.accountNameFromHistoryCss)).get(0).getText().then(function(text){
		logger.info("Account Name From History section : "+text);
		return (text.toString()).trim();
	});	
};

/**
 * Method to get status from history section
 */
catalogDiscovery.prototype.getStatusFromHistorySec = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element.all(by.css(this.statusFromHistoryCss)).get(0)), timeout.timeoutInMilis);
	return element.all(by.css(this.statusFromHistoryCss)).get(0).getText().then(function(text){
		logger.info("Status From History section : "+text);
		return (text.toString()).trim();
	});	
};

/**
 * Method to get first header text from history section
 */
catalogDiscovery.prototype.getHeaderTextFromHistorySec = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element.all(by.css(this.headerFromHistoryCss)).get(0)), timeout.timeoutInMilis);
	return element.all(by.css(this.headerFromHistoryCss)).get(0).getText().then(function(text){
		logger.info("Header text From History section : "+text);
		return text;
	});	
};


/**
 * Method to click on Header Name at top
 */
catalogDiscovery.prototype.clickOnHeaderName = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.headerNameCss))), timeout.timeoutInMilis);
	element(by.css(this.headerNameCss)).click().then(function(){
		logger.info("Clicked on header name at top");
	});
};


/**
 * Method to click on header humber link
 */
catalogDiscovery.prototype.clickOnHeaderHumburgerLink = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.headerHumburgerCss))), timeout.timeoutInMilis);
	element(by.css(this.headerHumburgerCss)).click().then(function(){
		logger.info("Clicked on header Humburger Link");
	});
};

/**
 * Method to click on store side bar link
 */
catalogDiscovery.prototype.clickOnStoreSideBarLink = function(){
	var self = this;
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(self.storeSideBarXpath))), timeout.timeoutInMilis);
	element(by.xpath(self.storeSideBarXpath)).getAttribute("aria-expanded").then(function(bool){
		logger.info("Bool .............. "+bool);
		if(bool=="true"){
			logger.info("Store is already expanded");
		}else{
			element(by.xpath(self.storeSideBarXpath)).click().then(function(){
				logger.info("Clicked on Store side bar Link");
			});
		}
	});
};

/**
 * Method to click Catalog Admin link
 */
catalogDiscovery.prototype.clickOnCatalogAdminLink = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.catalogAdminXpath))), timeout.timeoutInMilis);
	element(by.xpath(this.catalogAdminXpath)).click().then(function(){
		logger.info("Clicked on catalog Admin Link");
		browser.sleep(1000);
	});
};

/**
 * Method to get header title text
 */
catalogDiscovery.prototype.getheaderTitleText = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.headerTitleCss))), timeout.timeoutInMilis);
	return element(by.css(this.headerTitleCss)).getText().then(function(text){
		logger.info("Header title text : "+text);
		return (text.toString()).trim();
	});	
};

/**
 * Method to get history Page title text
 */
catalogDiscovery.prototype.getHistoryPageTitleText = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.historyPageTileCss))), timeout.timeoutInMilis);
	return element(by.css(this.historyPageTileCss)).getText().then(function(text){
		logger.info("History page title text : "+text);
		return (text.toString()).trim();
	});	
};


/**
 * Method to Navigate to catalog Admin page by navigating to humburger
 * Wrapper method called to switch back to deafult content, since there will no iframe
 * Again after performing opertion to navigate switching back to iframe tag
 */
catalogDiscovery.prototype.navigateToCatalogAdminByHumburger = function(){
	util.waitForAngular();
	browser.wait(EC.urlContains(url), timeout.timeoutInMilis).then( function(){
		logger.info("url: "+url);
	});
	util.switchToDefault();
	this.clickOnHeaderHumburgerLink();
	this.clickOnStoreSideBarLink();
	this.clickOnCatalogAdminLink();
	util.switchToFrame();
};


/**
 * Method to search service or provider name based on input provided
 */
catalogDiscovery.prototype.searchServiceOrProviderName = function(ServiceOrProviderName){
	util.waitForAngular();
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.elementToBeClickable(element.all(by.css(this.searchServiceOrProviderCss)).first()), 45000);
	element.all(by.css(this.searchServiceOrProviderCss)).first().click().then(function(){
		logger.info("Searching Service or Provider name");
	});
	element(by.css(this.searchServiceOrProviderCss)).clear();
	element(by.css(this.searchServiceOrProviderCss)).sendKeys(ServiceOrProviderName);
	util.waitForAngular();
	element(by.css(this.searchServiceOrProviderCss)).sendKeys(protractor.Key.ENTER);
	browser.sleep(2000);
	util.waitForAngular();
};

/**
 * Method to click on three dot icon menu from serched service table
 */
catalogDiscovery.prototype.clickOnThreeDotMenuIcon = function(serviceName){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath("//span[contains(text(), '"+serviceName+"')]"+this.threeDotIconXpath))), timeout.timeoutInMilis);
	element(by.xpath("//span[contains(text(), '"+serviceName+"')]"+this.threeDotIconXpath)).click().then(function(){
		logger.info("Clicked on three Dot Icon");
	});
};

/**
 * Method to click on view details link
 */
catalogDiscovery.prototype.clickOnViewDetailsLink = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.viewDetailsCss))), 60000);
	element(by.xpath(this.viewDetailsCss)).click().then(function(){
		logger.info("Clicked on view details link from three dot icon option");
	});
};

/**
 * Method to click on edit button
 */
catalogDiscovery.prototype.clickOnEditButton = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.editButtonCss))), timeout.timeoutInMilis);
	element(by.css(this.editButtonCss)).click().then(function(){
		logger.info("Clicked on edit button");
	});
};

/**
 * Method to click on category drop down from edit form
 */
catalogDiscovery.prototype.clickOnCategoryDrpDwnFromEdit = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.categoryDrpDwnFromEditCss))), timeout.timeoutInMilis);
	element(by.css(this.categoryDrpDwnFromEditCss)).click().then(function(){
		logger.info("Clicked on category Drop Down from edit page");
	});
};

/**
 * Method to click on compute option from frop down
 */
catalogDiscovery.prototype.clickOnComputeOptionFrmDrpDwn = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.selectComputeOptionFrmDrpDwnCss))), timeout.timeoutInMilis);
	element(by.css(this.selectComputeOptionFrmDrpDwnCss)).click().then(function(){
		logger.info("Clicked on Compute Option from drop down");
	});
};

/**
 * Click on pricing tab to upload file
 */

catalogDiscovery.prototype.clickPricingTab = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.pricingTabCss))), timeout.timeoutInMilis);
	element.all(by.css(this.pricingTabCss)).get(1).click().then(function(){
		logger.info("Clicked on pricing tab to upload pricing file");
	});
};

/**
 * Method to enable File Upload Input Box by javascript executescript
 */
catalogDiscovery.prototype.enableFileUploadInputBox = function(){
	util.waitForAngular();	
	browser.wait(EC.visibilityOf(element(by.css(this.fileUploadInputBoxCss))), timeout.timeoutInMilis).then(function(){
		logger.info("File upload input box is visible");
	});

	browser.executeScript("document.getElementById('text-input-fileName').removeAttribute('disabled')");
	// var fileInputElem = element(by.css(this.fileUploadInputBoxCss));
    // browser.executeScript(
	//   "arguments[0].disabled='false'; arguments[0].enabled='true'; arguments[0].style.visibility='visible'",
    //   fileInputElem.getWebElement());
};


/**
 * Method to send file path to input box after enabling the input box
 */
catalogDiscovery.prototype.sendFilePathToInputBox = function(fileToUpload){
	util.waitForAngular();
	this.enableFileUploadInputBox();
	var dirName = this.getCurrentWorkingDirectoryName();
	logger.info("dirname : "+dirName);
	logger.info("fileToUpload : "+fileToUpload);
	var url = dirName + fileToUpload;
	logger.info("url : "+url);
	var absolutePath = path.resolve(url);
	logger.info("absolutePath : "+ absolutePath);
	var fileInputElem = element(by.css(this.fileUploadInputBoxCss));
	browser.wait(EC.elementToBeClickable(fileInputElem), timeout.timeoutInMilis);
	fileInputElem.sendKeys(absolutePath);
};

/**
 * Method to send file path to input box after enabling the input box
 */
catalogDiscovery.prototype.fileUploadByRobotJs = function(fileToUpload){
	// util.waitForAngular();
	// robot.typeString(fileToUpload);
	// robot.keyTap("enter");

	util.waitForAngular();
	var dirName = this.getCurrentWorkingDirectoryName();
	logger.info("dirname : "+dirName);
	logger.info("fileToUpload : "+fileToUpload);
	var url = dirName + fileToUpload;
	logger.info("url : "+url);
	var absolutePath = path.resolve(url);
	logger.info("absolutePath : "+ absolutePath);

	//keyboard.type(absolutePath);
	//keyboard.type(Key.Enter);

};

/**
 * Method to add the labels during edit service configuration
 */
catalogDiscovery.prototype.addLabelInEditServiceConf = function(labelName){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.addLabelInputCss))), timeout.timeoutInMilis);
	element(by.css(this.addLabelInputCss)).clear();
	element(by.css(this.addLabelInputCss)).sendKeys(labelName);
	element(by.css(this.addLabelInputCss)).sendKeys(protractor.Key.ENTER);
};

/**
 * Method to delete all labels from edit service configuration
 */
catalogDiscovery.prototype.removeAllLabelFromEditServiceConf = function(){
	var curr = this;
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element.all(by.css(curr.removeAddedLableCss)).get(0)), timeout.timeoutInMilis);
	element.all(by.css(curr.removeAddedLableCss)).count().then(function(count){
		for(var i = 0; i < count; i++){
			browser.wait(EC.elementToBeClickable(element.all(by.css(curr.removeAddedLableCss)).get(0)), timeout.timeoutInMilis);
			element.all(by.css(curr.removeAddedLableCss)).get(0).click();
		}
	})
};

/**
 * Method to get labels text from service view details page
 */
catalogDiscovery.prototype.getLabelsNameFromViewDetails = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element.all(by.css(this.labelsTextCss)).get(0)), timeout.timeoutInMilis);
	return element.all(by.css(this.labelsTextCss)).getText().then(function(text){
		logger.info("Labels name from view details page : "+text);
		return text;
	});	
};

/**
 * Method to click on the save button
 */
catalogDiscovery.prototype.clickOnSaveBtn = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.saveBtnCss))), timeout.timeoutInMilis);
	element(by.css(this.saveBtnCss)).click().then(function(){
		logger.info("Clicked on saved button");
	});
};

/**
 * Method to click on the cancel button
 */
catalogDiscovery.prototype.clickOnCancelBtn = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.cancelBtnCss))), timeout.timeoutInMilis);
	element(by.css(this.cancelBtnCss)).click().then(function(){
		logger.info("Clicked on cancel button");
	});
};

/**
 * Method to click on the warning cancel yes button
 */
catalogDiscovery.prototype.clickOnCancelYesBtn = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.cancelYesBtnCss))), timeout.timeoutInMilis);
	element(by.css(this.cancelYesBtnCss)).click().then(function(){
		logger.info("Clicked on cancel Yes button");
	});
};


/**
 * Method to click on the slider close button
 */
catalogDiscovery.prototype.clickOnSliderCloseBtn = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element.all(by.css(this.sliderCloseBtnCss)).get(0)), timeout.timeoutInMilis);
	element.all(by.css(this.sliderCloseBtnCss)).get(0).click().then(function(){
		logger.info("Clicked on slider close button");
	});
};

/**
 * Method to click on Catalog category link
 */
catalogDiscovery.prototype.clickOnCatalogCategoryLink = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.catalogDiscoveryLinkCss))), timeout.timeoutInMilis);
	element(by.css(this.catalogDiscoveryLinkCss)).click().then(function(){
		logger.info("Clicked on catalog category link");
	});
	util.waitForAngular();
};


/**
 * Method to click on the upload button
 */
catalogDiscovery.prototype.clickOnUploadBtn = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.uploadBtnCss))), timeout.timeoutInMilis);
	element(by.css(this.uploadBtnCss)).click().then(function(){
		logger.info("Clicked on upload button");
	});
};

/**
 * Method to get edit service editted service status
 */
catalogDiscovery.prototype.getEditedServiceStatus = function(serviceName){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath("//span[contains(text(), '"+serviceName+"')]"+this.editedServiceStatusXpath))), timeout.timeoutInMilis);
    return element(by.xpath("//span[contains(text(), '"+serviceName+"')]"+this.editedServiceStatusXpath)).getAttribute('innerText').then(function(text){
		logger.info("Status From edited service : "+text);
		return (text.toString()).trim();
	});	
};

/**
 * Method to click on Publish service link/option
 */
catalogDiscovery.prototype.clickOnPublishService = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.ClickOnPublishServiceCss))), 30000);
	element(by.xpath(this.publishServiceLinkCss)).click().then(function(){
		logger.info("Clicked on publish service link");
	});
};

/**
 * Method to click on retire service link/option
 */
catalogDiscovery.prototype.clickOnRetireServiceOption = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.retireButtonXpath))),120000);
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.retireButtonXpath))),9000);
	element(by.xpath(this.retireButtonXpath)).click().then(function(){
		logger.info("Clicked on retire service link");
	});
};

/**
 * Method to click on unretire service link/option
 */
catalogDiscovery.prototype.clickOnUnretireServiceOption = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.unretireButtonXpath))), timeout.timeoutInMilis);
	element(by.xpath(this.unretireButtonXpath)).click().then(function(){
		logger.info("Clicked on unretire service link option");
	});
};

/**
 * Method to click on delete service link/option
 */
catalogDiscovery.prototype.clickOnDeleteServiceOption = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.deleteButtonCss))), timeout.timeoutInMilis);
	element(by.css(this.deleteButtonCss)).click().then(function(){
		logger.info("Clicked on delete service link");
	});
};

/**
 * Method to click on service confirmation OK button
 */
catalogDiscovery.prototype.clickOnServiceConfirmationOKBtn = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.serviceConfirmationOKCss))), timeout.timeoutInMilis);
	element(by.css(this.serviceConfirmationOKCss)).click().then(function(){
		logger.info("Clicked on retired service confirmation OK button");
	});
};


/**
 * Method to get title from Alert notification
 */
catalogDiscovery.prototype.getAlertNotificationTitle = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.alertNotificationTitleCss))), timeout.timeoutInMilis);
	return element(by.css(this.alertNotificationTitleCss)).getText().then(function(text){
		logger.info("Title of alert notification : "+text);
		return (text.toString()).trim();
	});	
};

/**
 * Method to get sub title from alert notification
 */
catalogDiscovery.prototype.getAlertNotificationSubTitle = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.alertNotificationSubTitleCss))), timeout.timeoutInMilis);
	return element(by.css(this.alertNotificationSubTitleCss)).getText().then(function(text){
		logger.info("Subtitle of alert notification : "+text);
		return (text.toString()).trim();
	});	
};

/**
 * Method to get caption from alert notification
 */
catalogDiscovery.prototype.getAlertNotificationCaption = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.alertNotificationCaptionCss))), timeout.timeoutInMilis);
	return element(by.css(this.alertNotificationCaptionCss)).getText().then(function(text){
		logger.info("caption of alert notification : "+text);
		return (text.toString()).trim();
	});	
};

/**
 * Method to get service name from published and retired section
 */
catalogDiscovery.prototype.getServiceNameFromSearchSection = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.serviceNameFromSearchSectionCss))), timeout.timeoutInMilis);
	return element(by.css(this.serviceNameFromSearchSectionCss)).getAttribute('innerText').then(function(text){
		logger.info("Service name from search section : "+text);
		return (text.toString()).trim();
	});	
};

/**
 * Method to get service name from draft section
 */
catalogDiscovery.prototype.getServiceNameFromDraftSearchSection = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.serviceNameFromDraftSearchSecCss))), timeout.timeoutInMilis);
	return element(by.css(this.serviceNameFromDraftSearchSecCss)).getAttribute('innerText').then(function(text){
		logger.info("Service name from draft search section : "+text);
		return (text.toString()).trim();
	});	
};

/**
 * Method to get published service date from published section
 */
catalogDiscovery.prototype.getPublishedSerivceDate = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element.all(by.css(this.publishedSerivceDateCss)).last()), timeout.timeoutInMilis);
	return element.all(by.css(this.publishedSerivceDateCss)).last().getAttribute('innerText').then(function(text){
		logger.info("published service date : "+text);
		return (text.toString()).trim();
	});	
};


/**
 * Method to get No data available text from published section
 */
catalogDiscovery.prototype.getNoDataAvailableTextPublishedSection = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.noDataAvailabeCss))), timeout.timeoutInMilis);
	return element(by.css(this.noDataAvailabeCss)).getAttribute('innerText').then(function(text){
		logger.info("Service is not available : "+text);
		return (text.toString()).trim();
	});	
};

/**
 * To retrieve current project directory name based on the provided input
 * @returns local path 
 */
catalogDiscovery.prototype.getCurrentWorkingDirectoryName = function(){
	var array = __dirname.split(path.sep);
	for(var i = array.length-1; i > 0; i--){
		if(array[i] == "cb-consume-ui-automation"){
			break;
		}else{
			array.pop();
		}
	}

	var absolutePath = "";
	for(var i = 0; i < array.length; i++){
		if(absolutePath.length>0){
			absolutePath = absolutePath +"/"+ array[i];
		}else if(absolutePath.length == 0){
			absolutePath = absolutePath + array[i];
		}
	}

	return absolutePath;
}



/**
 * To retrieve the date based on the parameter passed
 * @returns Month date, year
 */
catalogDiscovery.prototype.currenDate = function(){
	var CurrentDate = new Date();
	CurrentDate.setMonth(CurrentDate.getMonth());
	var M = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
	var d = new Date(CurrentDate),
	month = '' + M[d.getMonth()],
	day = '' + d.getDate(),
	year = d.getFullYear();
	if (month.length < 2) month = '0' + month;

	var monthDate = day+" " +month;
	return   [monthDate, year].join(" ");
}

/**
* Method to is used to check Service instance is present or not. 
*/

catalogDiscovery.prototype.isServiceInstancePresent = function (serviceInstanceName) {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath("//span[contains(text(), '" + serviceInstanceName + "')]"))), 20000);
		return element(by.css(this.ServiceInstanceNameCss)).getText().then(function(serviceInstanceName){
		logger.info("Service instance present on catalog management page: "+ serviceInstanceName);
		return (serviceInstanceName.toString()).trim();
	})
};


/**
* Method to click on viewInstance
*/
catalogDiscovery.prototype.clickOnviewInstanceLink = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.viewInstanceXpath))), 60000);
	element(by.xpath(this.viewInstanceXpath)).click().then(function () {
		logger.info("Clicked on view Instance link");
	});
};


catalogDiscovery.prototype.searchForServiceInstanceName = function (blueprintName) {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element.all(by.css(this.searchServiceInstanceNameCss)).last()), 45000);
	var searchInputBox = (element.all(by.css(this.searchServiceInstanceNameCss)).last());
	searchInputBox.clear().then(function () {
		searchInputBox.sendKeys(blueprintName);
		searchInputBox.sendKeys(protractor.Key.ENTER);
		logger.info("Searching order on catalog management page : "+blueprintName);
	})

};

	//clickOkImportService
	catalogDiscovery.prototype.clickOkImportService = function(){
		util.waitForAngular();
		browser.wait(EC.elementToBeClickable(element(by.css(this.clickOkImportServiceCss))), timeout.timeoutInMilis);
		element(by.css(this.clickOkImportServiceCss)).click().then(function(){
			logger.info("Clicked on Ok button for add service");
		});
	};

	/**
	 * Method to select TA account based on input provided
 */
catalogDiscovery.prototype.selectIcamAccountFromDrpDwn = function(serviceAccount){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.chooseAccountFromDropDownCss))), timeout.timeoutInMilis);
	element(by.css(this.chooseAccountFromDropDownCss)).click().then(function(){
		logger.info("Clicked DropDown Icon to select TA Account");
	});
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.selectValueFromAccDropDwnXpath +serviceAccount+"')]"))), timeout.timeoutInMilis);
	element(by.xpath(this.selectValueFromAccDropDwnXpath +serviceAccount+"')]")).click().then(function(){
		logger.info("Selected "+serviceAccount+" value from drop down");
	});
};

catalogDiscovery.prototype.clickOnokButtonIbmDiscoverryStarted = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element.all(by.css(this.okButtonIbmDiscoverryStarted)).last()), timeout.timeoutInMilis);
	element.all(by.css(this.okButtonIbmDiscoverryStarted)).last().click().then(function(){
		logger.info("Clicked on ok button from discovery popup IBM discovry started");
	});
};

/**
 * Method to wait for discovery completed status..
 * This method will wait for 2:30 min for every unsuccessfull message
 * This process will repeat upto 30
 */
catalogDiscovery.prototype.waitToCompletDiscoveryStatusTA = function(repeatCount,providerName){
	var curr = this;
	if (repeatCount == undefined) {
        repeatCount = 30;
    }
	if (providerName == undefined) {
		providerName = "Terraform Automation";
    }
    repeatCount = repeatCount - 1;
	if (repeatCount > 0) {
		curr.open();
		curr.clickOnProvidersToggleBtn();
		curr.searchProviderByName(providerName);
		curr.getDiscoveryStatus().then(function(status){
			if(status == "In Progress"){
				logger.info("Discovery is in progress wait for some time");
				browser.sleep(9000);
				curr.waitToCompletDiscoveryStatusTA();
			}
			else {
			        logger.info("Discovery completed at "+status+" breaking the loop");
                    repeatCount = 0;
                    return;
                }
		});
	} else{
		logger.info("Maximum tries "+repeatCount + "is exceeded and dicovery is not completed");
	}
};

//catalogDiscoveryStatus
catalogDiscovery.prototype.getcatalogDiscoveryStatusText = function () {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.catalogDiscoveryStatus))), 90000);
	return element(by.xpath(this.catalogDiscoveryStatus)).getText().then(function (catalogDiscoveryStatus) {
		logger.info("catalog discovery status text : " + catalogDiscoveryStatus);
		return (catalogDiscoveryStatus.toString()).trim();
	});
};
//cancelDiscovery
catalogDiscovery.prototype.clickOncancelDiscovery = function () {
	//util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.cancelDiscoveryLinkXpath))), 10000);
	element(by.xpath(this.cancelDiscoveryLinkXpath)).click().then(function () {
		logger.info("Clicked on cancelDiscovery link");
	});
};
catalogDiscovery.prototype.clickOncancelDiscoveryOk = function () {
	//util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.okCancelDiscoveryCss))), 10000);
	element(by.css(this.okCancelDiscoveryCss)).click().then(function () {
		logger.info("Clicked on cancelDiscoveryOk");
	});
};

catalogDiscovery.prototype.getMultipleAccountsDetectedText = function () {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.MultipleAccountsDetectedText))), 90000);
	return element(by.xpath(this.MultipleAccountsDetectedText)).getText().then(function (MultipleAccountsDetectedText) {
		logger.info("Multiple Accounts Detected Text : " + MultipleAccountsDetectedText);
		return (MultipleAccountsDetectedText.toString()).trim();
	});
};
//DiscoveryStartedText
catalogDiscovery.prototype.getDiscoveryStartedText = function () {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.DiscoveryStartedText))), 90000);
	return element(by.xpath(this.DiscoveryStartedText)).getText().then(function (DiscoveryStartedText) {
		logger.info("Multiple Accounts Detected Text : " + DiscoveryStartedText);
		return (DiscoveryStartedText.toString()).trim();
	});
};

	//ClickOnDeleteServiceCss	
	catalogDiscovery.prototype.ClickOnDeleteService = function () {	
		//util.waitForAngular();	
		browser.wait(EC.elementToBeClickable(element(by.xpath(this.ClickOnDeleteServiceXpath))), 30000);	
		element(by.xpath(this.ClickOnDeleteServiceXpath)).click().then(function () {	
			logger.info("Clicked on DeleteServiceCss");	
		});

	};

	/**
 * 
 * Method to get service name from publish section for TA
 */
catalogDiscovery.prototype.getServiceNameFromPublishSearchSection = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.getServiceNameFromPublishSearchSectionCss))), timeout.timeoutInMilis);
	return element(by.css(this.getServiceNameFromPublishSearchSectionCss)).getAttribute('innerText').then(function(text){
		logger.info("Service name from publish search section : "+text);
		return (text.toString()).trim();
	});	
};

/* Method to get service name from retired section  */
catalogDiscovery.prototype.getServiceNameFromRetiredSearchSection = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.getServiceNameFromRetiredSearchSectionXpath))), timeout.timeoutInMilis);
	return element(by.xpath(this.getServiceNameFromRetiredSearchSectionXpath)).getAttribute('innerText').then(function(text){
		logger.info("Service name from retired search section : "+text);
		return (text.toString()).trim();
	});	
};
//ok NavigatesButton
		
	catalogDiscovery.prototype.ClickOnokNevigatesButton = function () {		
		browser.wait(EC.elementToBeClickable(element(by.css(this.okNevigatesButtonCss))), 30000);	
		element(by.css(this.okNevigatesButtonCss)).click().then(function () {	
			logger.info("Clicked ok Nevigates Button");	
		});

	};

//deleteServiceFromRetiredCss
catalogDiscovery.prototype.ClickOndeleteServiceFromRetired = function () {	
	browser.wait(EC.elementToBeClickable(element(by.css(this.deleteServiceFromRetiredCss))), 30000);	
	element(by.css(this.deleteServiceFromRetiredCss)).click().then(function () {	
		logger.info("Clicked delete Service From Retired section");	
	});

};

//unretiredServiceFromRetiredCss
catalogDiscovery.prototype.ClickOnunretiredServiceFromRetired = function () {	
	browser.wait(EC.elementToBeClickable(element(by.css(this.unretiredServiceFromRetiredCss))), 30000);	
	element(by.css(this.unretiredServiceFromRetiredCss)).click().then(function () {	
		logger.info("Clicked unretired Service From Retired section");	
	});

};
//click on configureparameter links
catalogDiscovery.prototype.clickOnConfigurationParameterTA = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.configurationParametersCss))), 40000);
    element(by.css(this.configurationParametersCss)).click().then(function () {
        logger.info("clicked on Configuration Parameters Tab");
    });
};
//click on expand link
catalogDiscovery.prototype.clickOnexpandAllLink = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.expandAllLinkXpath))), 30000);
	element(by.xpath(this.expandAllLinkXpath)).click().then(function () {
		logger.info("Clicked on expandAll link");
	});
};
// get service configuration text
catalogDiscovery.prototype.getServiceConfigurationstext = function () {   
	browser.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.configurationText))),30000);
	var ele = element.all(by.css(this.configurationText));
	return ele.getText().then(function(configuraionList){
		logger.info("Service Configurations are: " + configuraionList);
		return configuraionList;
		
	});	
}

/* Method to get service name from retired section  */
catalogDiscovery.prototype.getServiceNameFromRetiredSearchSectionICAM = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.getServiceNameFromRetiredSearchSectionXpath))), timeout.timeoutInMilis);
	return element(by.xpath(this.getServiceNameFromRetiredSearchSectionXpath)).getText().then(function(GetNametext){
		logger.info("Service name from retired search section : "+GetNametext);
		return GetNametext;
	});	
};


/**
 * Method to view failure reason 
 */
 catalogDiscovery.prototype.ClickViewDiscoveryFailure = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element.all(by.xpath(this.viewDetailsLinkxpath)).get(1)),60000);
	element.all(by.xpath(this.viewDetailsLinkxpath)).get(1).click().then(function(){
	logger.info("Successfully clicked on view details link...");

	});

};
/**
 * Method to verify failure reason 
 */
 catalogDiscovery.prototype.VerifyDiscoveryFailure = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element.all(by.xpath(this.discoveryFailuretextXpath)).get(1)),90000);
	return element.all(by.xpath(this.discoveryFailuretextXpath)).get(1).getText().then(function(failuretext){
	logger.info("Failure text for catalog discovery is visible... "+failuretext);
		util.waitForAngular();
		return failuretext;
	});
};

module.exports = catalogDiscovery;
