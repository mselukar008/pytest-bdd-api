/**********************
 * Author : Atiksha
 **********************/
 var extend = require('extend');
 var logGenerator = require("../../helpers/logGenerator.js"),
     logger = logGenerator.getApplicationLogger();
 var mcmpUIDataTemplate = require('../../testData/mcmp/mcmpUIData.json');
 var timeout = require('../../testData/timeout.json');
 var CatalogPage = require('../pageObjects/catalog.pageObject.js');
 var EC = protractor.ExpectedConditions;
 var fs = require('fs-extra');
 var path = require('path');
 var serviceZipDir = path.resolve("downloads/exportedServices");
 var util = require('../../helpers/util.js');
 var countStatus = 0;
 var defaultConfig = {
     expandProvidersCss: "button.bx--link.bom-toggle.provider-chevron",
     expandGroupsCss: "button.bx--link.bom-toggle.group-chevron",
     providersCheckBoxCss: "[id*='provider-checkbox-label']",
     providersHistoryLinkCss: "[id*='catalog-history-link']",
     catalogLstingActionCss: "button#catalog-listing_action-modal_carbon-button_ok",
     draftTabCss: "a#tab-control-catalog-admin--draft-tab",
     publishedTabCss: "a#tab-control-catalog-admin--published-tab",
     retiredTabcss: "a#tab-control-catalog-admin--retired-tab",
     searchBarForProviderOrServiceCss: "div.catalog-admin--main-content input#data-table-search__input",
     serviceInstanceSearchBarCss: "#service-instances-panel input#data-table-search__input",
     menuIconBasedonServiceNameXpath: "//span[contains(text(),'{0}')]/ancestor::td/following-sibling::td[@class='bx--table-overflow']//*[contains(@id,'overflow-menu-icon')]",
     viewDetailsButtonBasedOnServiceNameXpath: "//span[contains(text(),'{0}')]/ancestor::td/following-sibling::td[@class='bx--table-overflow']//button[contains(text(),'View Details')]",
     exportButtonBasedOnServiceNameXpath: "//span[contains(text(),'{0}')]/ancestor::td/following-sibling::td[@class='bx--table-overflow']//button[contains(text(),'Export')]",
     previewButtonBasedOnServiceNameXpath: "//span[contains(text(),'{0}')]/ancestor::td/following-sibling::td[@class='bx--table-overflow']//button[contains(text(),'Preview')]",
     deleteButtonBasedOnServiceNameXpath: "//span[contains(text(),'{0}')]/ancestor::td/following-sibling::td[@class='bx--table-overflow']//button[contains(text(),'Delete')]",
     publishButtonBasedOnServiceNameXpath: "//span[contains(text(),'{0}')]/ancestor::td/following-sibling::td[@class='bx--table-overflow']//button[contains(text(),'Publish')]",
     viewInstancesButtonBasedOnServiceNameXpath: "//span[contains(text(),'{0}')]/ancestor::td/following-sibling::td[@class='bx--table-overflow']//button[contains(text(),'View Instances')]",
     retireButtonBasedOnServiceNameXpath: "//span[contains(text(),'{0}')]/ancestor::td/following-sibling::td[@class='bx--table-overflow']//button[contains(text(),'Retire')]",
     unretireButtonBasedOnServiceNameXpath: "//span[contains(text(),'{0}')]/ancestor::td/following-sibling::td[@class='bx--table-overflow']//button[contains(text(),'Unretire')]",
     serviceDetailsCss: "a[title='Service Details']",
     configurationParametersCss: "a[title='Configuration Parameters']",
     pricingCss: "a[title='Pricing']",
     EditServiceDetailsCss: "#editSelectedConfig",
     cancelServiceDetailsCss: "#cancelSelectedConfig",
     saveServiceDetailsCss: "button#save",
     confirmationOkButtonCss: "#services-action-confirm-modal-ok",
     addServiceCss: "button#show-catalog-discovery-panel",
     importFromProviderAccountRadioCss: "[for='radio-button-import-provider-service_provider']",
     importFromFileRadioCss: "[for='radio-button-import-provider-service_file']",
     providerAccountCardCss: "#card-title-2",
     multiAccDropdownId: '//*[@id="bx--dropdown-single-parent_provider-account"]',
     multiAccDropdownValuesXpath: '//*[@id="bx--dropdown-single-parent_provider-account"]//carbon-dropdown-option//li',
     multiAccOkButtonCss: '#privacy-policy-modal_carbon-confirm-button_ok',
     providerSelectedOkXpath: "//p[contains(text(),' Discovery has started and you will be notified by email when completed. ')]//parent::div/../following-sibling::div",
     providerAccountImportMsgXpath: "//p[contains(text(),' Discovery has started and you will be notified by email when completed. ')]",
     importOptionOkButtonCss: "div#import-model-ok-button #select-provider-account",
     notificationSuccessMsgCss: ".bx--toast-notification.bx--toast-notification--success",
     importButtonFromFileCss: "#Import-file #select-provider-account ~ button",
     uploadFileCss: "[for='fileImporter']",
     uploadFileInputCss: "[for='fileImporter'] ~ input",
     providersLabelCss: "[id*='provider-checkbox-label']",
     serviceDiscoveredStatus: "[class*='bx--tag bx--tag--']",
     categoryDropdownButtonCss: "#bx--dropdown-single-parent_service-detail-category",
     categoryDropdownListCss: "#bx--dropdown-single-parent_service-detail-category li",
     categoryDropdownValueTextCss: "#bx--dropdown-single-parent_service-detail-category>button",
     viewInstanceStatusCss: "tbody tr td:nth-child(2) div div span:nth-child(1)",
     viewInstanceNameXpath: "//td//span[contains(text(),'{0}')]",
     viewDetailsForFirstFailedDiscoveryCss: "div.view >a",
     closeFailedStatusPopupCss: "button.bx--modal-close",
     FailedStatusMessageStatusCss: "div.bx--modal-content p",
     ImportDateButtonCss: "[id*='import-date-col-6'] button",
     publishDateButtonCss: "[id*='published-date-col-5'] button",
     retireDateButtonCss: "[id*='retired-date-col-5'] button",
 
 };
 
 function catalogManagement(selectorConfig) {
     if (!(this instanceof catalogManagement)) {
         return new catalogManagement(selectorConfig);
     }
     extend(this, defaultConfig);
 
     if (selectorConfig) {
         extend(this, selectorConfig);
     }
 }
 catalogManagement.prototype.open = function () {
     var catalogPage = new CatalogPage();
     util.switchToDefault();
     catalogPage.clickHamburgerCatalog();
     catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
     catalogPage.checkIfleftNavStoreExpanded();
     catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkCatalogMgmt);
     util.waitForAngular();
     util.switchToFrame();
     util.waitForAngular();
     browser.sleep(15000);
 };
 
 catalogManagement.prototype.clickOnProvidersChevron = function () {
     util.waitForAngular();
     browser.wait(EC.elementToBeClickable(element(by.css(this.expandProvidersCss))), timeout.timeoutInMilis);
     return element(by.css(this.expandProvidersCss)).click().then(function () {
         logger.info("clicked on Provider's Chevron");
     });
 };
 
 catalogManagement.prototype.clickOnGroupsChevron = function () {
     browser.wait(EC.elementToBeClickable(element(by.css(this.expandGroupsCss))), timeout.timeoutInMilis);
     return element(by.css(this.expandGroupsCss)).click().then(function () {
         logger.info("clicked on Group's Chevron");
     });
 };
 
 catalogManagement.prototype.clickOnProviderCheckboxBasedOnName = function (providerName) {
     var current = this;
     browser.wait(EC.elementToBeClickable(element.all(by.css(current.providersCheckBoxCss)).get(0)), timeout.timeoutInMilis);
     return element.all(by.css(current.providersCheckBoxCss)).getText().then(function (providersArray) {
         for (var i = 0; i < providersArray.length; i++) {
             if (providersArray[i] == providerName) {
                 element.all(by.css(current.providersCheckBoxCss)).get(i).click().then(function () {
                     logger.info("click on " + providerName + "'s checkbox");
                 });
             };
         };
     });
 };
 
 catalogManagement.prototype.clickOnProvidersHistoryLinkBasedOnName = function (providerName) {
     var current = this;
     browser.wait(EC.elementToBeClickable(element.all(by.css(current.providersHistoryLinkCss)).get(0)), timeout.timeoutInMilis);
     return element.all(by.css(current.providersLabelCss)).getText().then(function (providersArray) {
         for (var i = 0; i < providersArray.length; i++) {
             if (providersArray[i] == providerName) {
                 element.all(by.css(current.providersHistoryLinkCss)).get(i).click().then(function () {
                     logger.info("click on " + providerName + "'s History Link");
                 });
             };
         };
     });
 };
 
 catalogManagement.prototype.catalogListingActionModal = function () {
     browser.wait(EC.elementToBeClickable(element(by.css(this.catalogLstingActionCss))), timeout.timeoutInMilis);
     return element(by.css(this.catalogLstingActionCss)).click().then(function () {
         logger.info("clicked on Catalog Listing Action Modal Ok button.");
         util.waitForAngular();
     });
 
 }
 
 catalogManagement.prototype.clickOnDraftTab = function () {
     var self = this;
     util.waitForAngular();
     browser.wait(EC.elementToBeClickable(element(by.css(this.draftTabCss))), timeout.timeoutInMilis);
     browser.sleep(8000); // added for syncronization betwwen the click and spinner loading
     return element(by.css(this.draftTabCss)).click().then(function () {
        util.waitForAngular();
        logger.info("clicked on Draft Tab");
     });
 };
 
 catalogManagement.prototype.clickOnPublishedTab = function () {
     var self = this;
     util.waitForAngular();
     browser.wait(EC.elementToBeClickable(element(by.css(this.publishedTabCss))), timeout.timeoutInMilis);
     return element(by.css(this.publishedTabCss)).click().then(function () {
        util.waitForAngular();
        logger.info("clicked on Published Tab");
     });
 };
 
 catalogManagement.prototype.clickOnRetiredTab = function () {
     var self = this;
     util.waitForAngular();
     browser.wait(EC.elementToBeClickable(element(by.css(this.retiredTabcss))), timeout.timeoutInMilis);
     return element(by.css(this.retiredTabcss)).click().then(function () {
        util.waitForAngular();
        logger.info("clicked on Retired Tab");
     });
 };
 
 catalogManagement.prototype.clickOnServiceMenuIcon = function (serviceName) {
     var menuIcon = this.menuIconBasedonServiceNameXpath.format(serviceName);
     browser.wait(EC.elementToBeClickable(element(by.xpath(menuIcon))), timeout.timeoutInMilis);
     return element(by.xpath(menuIcon)).click().then(function () {
         logger.info("clicked on " + serviceName + " Menu's Icon");
     });
 };
 
 catalogManagement.prototype.clickOnServiceViewDetails = function (serviceName) {
     util.waitForAngular();
     var viewDetails = this.viewDetailsButtonBasedOnServiceNameXpath.format(serviceName);
     browser.wait(EC.elementToBeClickable(element(by.xpath(viewDetails))), timeout.timeoutInMilis);
     browser.sleep(3000);// added static wait due to click interception issue
     return element(by.xpath(viewDetails)).click().then(function () {
         logger.info("clicked on " + serviceName + " View Details Button");
         util.waitForAngular();
     });
 };
 
 catalogManagement.prototype.deleteAllZipFiles = function () {
     var files = fs.readdirSync(serviceZipDir);
     if (!files.length) {
         logger.info(serviceZipDir + " directory is empty.");
     }
     else {
         for (var i = 0; i < files.length; i++) {
             logger.info("Deleting file: " + files[i]);
             fs.unlinkSync(serviceZipDir + path.sep + files[i]);
         }
         // Read directory again to check directory is empty
         files = fs.readdirSync(serviceZipDir);
         if (!files.length) {
             logger.info("Deleted all files from directory " + serviceZipDir);
         }
         else {
             logger.info(serviceZipDir + " directory is not empty");
         }
     }
 };
 
 catalogManagement.prototype.clickOnServiceExportButton = function (serviceName) {
     util.waitForAngular();
     return new Promise(
         (resolve, reject) => {
             this.deleteAllZipFiles();
             var exportButton = this.exportButtonBasedOnServiceNameXpath.format(serviceName);
             browser.wait(EC.elementToBeClickable(element(by.xpath(exportButton))), timeout.timeoutInMilis);
             element(by.xpath(exportButton)).click().then(function () {
                 logger.info("clicked on " + serviceName + " Export Button");
                 setTimeout(() => resolve("done"), 30000);
             });
         });
 };
 
 catalogManagement.prototype.clickOnServicePreviewButton = function (serviceName) {
     var previewButton = this.previewButtonBasedOnServiceNameXpath.format(serviceName);
     browser.wait(EC.elementToBeClickable(element(by.xpath(previewButton))), timeout.timeoutInMilis);
     return element(by.xpath(previewButton)).click().then(function () {
         logger.info("clicked on " + serviceName + " Preview Button");
     });
 };
 
 catalogManagement.prototype.clickOnServiceDeleteButton = function (serviceName) {
     var deleteButton = this.deleteButtonBasedOnServiceNameXpath.format(serviceName);
     browser.wait(EC.elementToBeClickable(element(by.xpath(deleteButton))), timeout.timeoutInMilis);
     return element(by.xpath(deleteButton)).click().then(function () {
         logger.info("clicked on " + serviceName + " Delete Button");
     });
 };
 
 catalogManagement.prototype.clickOnServiceViewInstancesButton = function (serviceName) {
     var previewButton = this.viewInstancesButtonBasedOnServiceNameXpath.format(serviceName);
     browser.wait(EC.elementToBeClickable(element(by.xpath(previewButton))), timeout.timeoutInMilis);
     return element(by.xpath(previewButton)).click().then(function () {
         logger.info("clicked on " + serviceName + " View Instances Button");
         util.waitForAngular();
     });
 };
 
 catalogManagement.prototype.clickOnServiceRetireButton = function (serviceName) {
     var retireButton = this.retireButtonBasedOnServiceNameXpath.format(serviceName);
     browser.wait(EC.elementToBeClickable(element(by.xpath(retireButton))), timeout.timeoutInMilis);
     return element(by.xpath(retireButton)).click().then(function () {
         logger.info("clicked on " + serviceName + " retire Button");
     });
 };
 
 catalogManagement.prototype.clickOnServicePublishButton = function (serviceName) {
     var publishButton = this.publishButtonBasedOnServiceNameXpath.format(serviceName);
     browser.wait(EC.elementToBeClickable(element(by.xpath(publishButton))), timeout.timeoutInMilis);
     return element(by.xpath(publishButton)).click().then(function () {
         logger.info("clicked on " + serviceName + " Publish Button");
     });
 };
 
 
 catalogManagement.prototype.clickOnServiceUnretireButton = function (serviceName) {
     var unretireButton = this.unretireButtonBasedOnServiceNameXpath.format(serviceName);
     browser.wait(EC.elementToBeClickable(element(by.xpath(unretireButton))), timeout.timeoutInMilis);
     return element(by.xpath(unretireButton)).click().then(function () {
         logger.info("clicked on " + serviceName + " Unretire Button");
     });
 };
 
 
 catalogManagement.prototype.clickOnServiceDetailsTab = function () {
     browser.wait(EC.elementToBeClickable(element(by.css(this.serviceDetailsCss))), timeout.timeoutInMilis);
     return element(by.css(this.serviceDetailsCss)).click().then(function () {
         logger.info("clicked on Service Details Tab");
     });
 };
 
 catalogManagement.prototype.clickOnEditServiceDetailsbutton = function () {
     browser.wait(EC.elementToBeClickable(element(by.css(this.EditServiceDetailsCss))), timeout.timeoutInMilis);
     return element(by.css(this.EditServiceDetailsCss)).click().then(function () {
         logger.info("clicked on Edit Service Details Button");
     });
 };
 
 catalogManagement.prototype.clickOnSaveServiceDetailsbutton = function () {  
    let saveBtn = element(by.css(this.saveServiceDetailsCss));
    browser.wait(EC.elementToBeClickable(saveBtn), 20000);
    return browser.executeScript("arguments[0].click();", saveBtn.getWebElement()).then(function(){
       logger.info("clicked on Save Service Details Button");
       browser.sleep(5000);//taking time to visible the changes
   })  
};

 catalogManagement.prototype.clickOnConfigurationParametersTab = function () {
     browser.wait(EC.elementToBeClickable(element(by.css(this.configurationParametersCss))), timeout.timeoutInMilis);
     return element(by.css(this.configurationParametersCss)).click().then(function () {
         logger.info("clicked on Configuration Parameters Tab");
     });
 };
 
 catalogManagement.prototype.clickOnPricingParametersTab = function () {
     browser.wait(EC.elementToBeClickable(element(by.css(this.pricingCss))), timeout.timeoutInMilis);
     return element(by.css(this.pricingCss)).click().then(function () {
         logger.info("clicked on Pricing Parameters Tab");
     });
 };
 
 catalogManagement.prototype.clickOnConfirmationOkButton = function () {
     browser.wait(EC.elementToBeClickable(element(by.css(this.confirmationOkButtonCss))), timeout.timeoutInMilis);
     return element(by.css(this.confirmationOkButtonCss)).click().then(function () {
         logger.info("clicked on Confirmation Ok Button");
         util.waitForAngular();
     });
 };
 
 catalogManagement.prototype.SearchServiceOrProviderDraft = function (serviceName) {
     var current = this;
     //util.waitForAngular();
     browser.wait(EC.visibilityOf(element(by.css(current.searchBarForProviderOrServiceCss))), timeout.timeoutInMilis);
     element(by.css(current.searchBarForProviderOrServiceCss)).clear();
     return element(by.css(current.searchBarForProviderOrServiceCss)).sendKeys(serviceName).then(function () {
         element(by.css(current.searchBarForProviderOrServiceCss)).sendKeys(protractor.Key.ENTER);
         logger.info("Searched for Service/provider :" + serviceName);
         util.waitForAngular();
         element(by.css(current.ImportDateButtonCss)).click().then(function () {
             util.waitForAngular();
             element(by.css(current.ImportDateButtonCss)).click().then(function () {
                 logger.info("Sorted searched Item with latest Import Date");
                 util.waitForAngular();
             })
         })
     });
 };
 
 catalogManagement.prototype.SearchServiceOrProviderForPublish = function (serviceName) {
     var current = this;
     util.waitForAngular();
     browser.wait(EC.visibilityOf(element(by.css(current.searchBarForProviderOrServiceCss))), timeout.timeoutInMilis);
     element(by.css(current.searchBarForProviderOrServiceCss)).clear();
     return element(by.css(current.searchBarForProviderOrServiceCss)).sendKeys(serviceName).then(function () {
         element(by.css(current.searchBarForProviderOrServiceCss)).sendKeys(protractor.Key.ENTER);
         logger.info("Searched for Service/provider :" + serviceName);
         util.waitForAngular();
         element(by.css(current.publishDateButtonCss)).click().then(function () {
             util.waitForAngular();
             element(by.css(current.publishDateButtonCss)).click().then(function () {
                 logger.info("Sorted searched Item with latest Publish Date");
                 util.waitForAngular();
             })
         })
     });
 };
 
 catalogManagement.prototype.SearchServiceOrProviderForRetire = function (serviceName) {
     var current = this;
     util.waitForAngular();
     browser.wait(EC.visibilityOf(element(by.css(current.searchBarForProviderOrServiceCss))), timeout.timeoutInMilis);
     element(by.css(current.searchBarForProviderOrServiceCss)).clear();
     return element(by.css(current.searchBarForProviderOrServiceCss)).sendKeys(serviceName).then(function () {
         element(by.css(current.searchBarForProviderOrServiceCss)).sendKeys(protractor.Key.ENTER);
         logger.info("Searched for Service/provider :" + serviceName);
         util.waitForAngular();
         element(by.css(current.retireDateButtonCss)).click().then(function () {
             util.waitForAngular();
             element(by.css(current.retireDateButtonCss)).click().then(function () {
                 logger.info("Sorted searched Item with latest Import Date");
                 util.waitForAngular();
             })
         })
     });
 };
 
 catalogManagement.prototype.SearchServiceInstance = function (serviceName) {
     var current = this;
     browser.sleep(12000);//Instances take some time to load
     browser.wait(EC.visibilityOf(element(by.css(current.serviceInstanceSearchBarCss))), timeout.timeoutInMilis);
     element(by.css(current.serviceInstanceSearchBarCss)).clear();
     return element(by.css(current.serviceInstanceSearchBarCss)).sendKeys(serviceName).then(function () {
         browser.sleep(10000);
         element(by.css(current.serviceInstanceSearchBarCss)).sendKeys(protractor.Key.ENTER);
         util.waitForAngular();
         logger.info("Searched for Service Instance :" + serviceName);
     });
 };
 catalogManagement.prototype.clickOnAddServiceButton = function () {
     util.waitForAngular();
     browser.wait(EC.elementToBeClickable(element(by.css(this.addServiceCss))), timeout.timeoutInMilis);
     return element(by.css(this.addServiceCss)).click().then(function () {
         logger.info("clicked on Add Service Button");
     });
 };
 
 catalogManagement.prototype.selectInportFromFileRadioButton = function () {
     browser.wait(EC.elementToBeClickable(element(by.css(this.importFromFileRadioCss))), timeout.timeoutInMilis);
     return element(by.css(this.importFromFileRadioCss)).click().then(function () {
         logger.info("clicked on Add Service Button");
     });
 };
 
 catalogManagement.prototype.selectInportThroughProviderAccountRadioButton = function () {
     browser.wait(EC.elementToBeClickable(element(by.css(this.importFromProviderAccountRadioCss))), timeout.timeoutInMilis);
     return element(by.css(this.importFromProviderAccountRadioCss)).click().then(function () {
         logger.info("clicked on Import Through Provider Account Radio Button");
     });
 };
 
 catalogManagement.prototype.clickOnProvidersAccountBasedOnName = function (providerName) {
     var current = this;
     browser.wait(EC.elementToBeClickable(element.all(by.css(current.providerAccountCardCss)).get(0)), timeout.timeoutInMilis);
     return element.all(by.css(current.providerAccountCardCss)).getText().then(function (providersArray) {
         for (var i = 0; i < providersArray.length; i++) {
             if (providersArray[i] == providerName) {
                 element.all(by.css(current.providerAccountCardCss)).get(i).click().then(function () {
                     logger.info("click on " + providerName + "'s Card");
                 });
             };
         };
     });
 };
 
 catalogManagement.prototype.selectValueFromMultiAccDropdown = function (providerAccountValue) {
     var curr = this;
     var dropdown = element(by.xpath(curr.multiAccDropdownId));
     util.waitForAngular();
     browser.wait(EC.presenceOf(dropdown), 30000);
     dropdown.click().then(function () {
         var dropDownValuesArray = element.all(by.xpath(curr.multiAccDropdownValuesXpath));
         dropDownValuesArray.getText().then(function (textArray) {
             var isDropDownValuePresent = false;
             for (var i = 0; i < textArray.length; i++) {
                 if (textArray[i] == providerAccountValue) {
                     dropDownValuesArray.get(i).click().then(function () {
                         logger.info("Selected " + providerAccountValue + " from multiple account dropdown");
                     });
                     isDropDownValuePresent = true;
                 }
             }
         });
     });
 }
 
 catalogManagement.prototype.clickOnConfirmationOkButtonForMultiAcc = function () {
     browser.wait(EC.elementToBeClickable(element(by.css(this.multiAccOkButtonCss))), timeout.timeoutInMilis);
     return element(by.css(this.multiAccOkButtonCss)).click().then(function () {
         logger.info("clicked on confirmation ok button for Multiple Account provider");
         util.waitForAngular();
     });
 };
 
 catalogManagement.prototype.getTextForDiscoverIntiatedViaProviderAccountSuccessMsg = function () {
     browser.wait(EC.visibilityOf(element(by.xpath(this.providerAccountImportMsgXpath))), timeout.timeoutInMilis);
     return element(by.xpath(this.providerAccountImportMsgXpath)).getText().then(function (successMsg) {
         logger.info("Discover Initiated Msg : " + successMsg);
         return successMsg;
     });
 };
 
 catalogManagement.prototype.getTextForSelectedCategoryOnServiceDetailsPage = function () {
     util.waitForAngular();
     browser.sleep(3000); // as it takes few seconds to update the service details from default value added static wait
     browser.wait(EC.visibilityOf(element(by.css(this.categoryDropdownValueTextCss))), timeout.timeoutInMilis);
     return element(by.css(this.categoryDropdownValueTextCss)).getText().then(function (category) {
         logger.info("Service Category value on details Page: " + category);
         return category;
     });
 };
 
 catalogManagement.prototype.getTextForNotificationMsg = function () {
     util.waitForAngular();
     browser.wait(EC.visibilityOf(element(by.css(this.notificationSuccessMsgCss))), timeout.timeoutInMilis);
     return element(by.css(this.notificationSuccessMsgCss)).getText().then(function (Message) {
         logger.info("Notification Message: " + Message);
         return Message;
     });
 };
 
 catalogManagement.prototype.getTextForDiscoveredServicesStatus = function (providerName) {
     var current = this;
     browser.wait(EC.visibilityOf(element.all(by.css(current.serviceDiscoveredStatus)).get(0)), timeout.timeoutInMilis);
     return element.all(by.css(current.serviceDiscoveredStatus)).get(0).getText().then(function (statusTxt) {
         logger.info("Service Discovered Status :" + statusTxt);
         if (statusTxt == "In-Progress" && countStatus < 50) {
             current.open();
             current.clickOnProvidersChevron();
             current.clickOnProvidersHistoryLinkBasedOnName(providerName);
             countStatus++;
             return current.getTextForDiscoveredServicesStatus(providerName);
         }
         else {
             return statusTxt;
         }
 
     });
 };
 
 catalogManagement.prototype.clickOnConfirmationOkButtonForServiceDiscoveryStarted = function () {
     browser.wait(EC.elementToBeClickable(element(by.xpath(this.providerSelectedOkXpath))), timeout.timeoutInMilis);
     return element(by.xpath(this.providerSelectedOkXpath)).click().then(function () {
         logger.info("clicked on confirmation ok button for service Discovery Started");
         util.waitForAngular();
     });
 };
 
 catalogManagement.prototype.clickOnConfirmationOkButtonForServiceImport = function () {
     browser.wait(EC.elementToBeClickable(element(by.css(this.importOptionOkButtonCss))), timeout.timeoutInMilis);
     return element(by.css(this.importOptionOkButtonCss)).click().then(function () {
         logger.info("clicked on confirmation ok button for service import");
     });
 };
 
 catalogManagement.prototype.clickOnFileUploadButtonForServiceImport = function () {
     browser.wait(EC.visibilityOf(element(by.css(this.importButtonFromFileCss))), timeout.timeoutInMilis);
     return element(by.css(this.importButtonFromFileCss)).click().then(function () {
         logger.info("clicked on confirmation Import button for service import");
     });
 };
 
 catalogManagement.prototype.isZipFileExists = function () {
     browser.sleep(4000);
     var files = fs.readdirSync(serviceZipDir);
     if (!files.length) {
         logger.info("No file found in " + serviceZipDir);
         return false;
     }
     else {
         var filePath = serviceZipDir + path.sep + files[files.length - 1];
         logger.info("File found and file path is: " + filePath);
         return fs.existsSync(filePath);
     }
 };
 
 catalogManagement.prototype.sendFilePathToUploadFileBox = function (uploadPath) {
     var serviceZipDir = path.resolve(uploadPath);
     var files = fs.readdirSync(serviceZipDir);
     if (!files.length) {
         logger.info("No file found in " + serviceZipDir);
         return false;
     }
     else {
         var filePath = serviceZipDir + path.sep + files[files.length - 1];
         logger.info("File found and file path is: " + filePath);
         browser.wait(EC.elementToBeClickable(element(by.css(this.uploadFileCss))), timeout.timeoutInMilis);
         element(by.css(this.uploadFileInputCss)).sendKeys(filePath);
     }
 };
 
 catalogManagement.prototype.getCurrentWorkingDirectoryName = function () {
     var array = __dirname.split(path.sep);
     for (var i = array.length - 1; i > 0; i--) {
         if (array[i] == "cb-consume-ui-automation") {
             break;
         } else {
             array.pop();
         }
     }
 
     var absolutePath = "";
     for (var i = 0; i < array.length; i++) {
         if (absolutePath.length > 0) {
             absolutePath = absolutePath + "/" + array[i];
         } else if (absolutePath.length == 0) {
             absolutePath = absolutePath + array[i];
         }
     }
 
     return absolutePath;
 };
 
 catalogManagement.prototype.selectCategoryDropdownValue = function (elementValue) {
     var current = this
     var dropdownbox = element(by.css(current.categoryDropdownButtonCss));
     browser.wait(EC.presenceOf(dropdownbox), 10000).then(function () {
         dropdownbox.click().then(function () {
             util.waitForAngular();
             browser.sleep(3000);
             var dropDownValuesArray = element.all(by.css(current.categoryDropdownListCss));
             dropDownValuesArray.getText().then(function (textArray) {
                 for (var i = 0; i < textArray.length; i++) {
                     if (textArray[i] == elementValue) {
                         dropDownValuesArray.get(i).click().then(function () {
                             logger.info("Selected " + elementValue + " from  category dropdown");
                         });
                     }
                 }
             });
         });
     });
 
 };
 
 catalogManagement.prototype.serviceInstanceIsPresent = function (serviceName) {
     var ServiceInstanceName = this.viewInstanceNameXpath.format(serviceName);
     browser.sleep(8000); // as it takes few seconds to update the Instance details  static wait
     util.waitForAngular();
     return element(by.xpath(ServiceInstanceName)).isPresent().then(function (status) {
         if (status == true) {
             logger.info("service Instance " + serviceName + "is present");
             return true;
         }
         else {
             logger.info("service Instance " + serviceName + "is not present");
             return false;
         }
     });
 };
 
 catalogManagement.prototype.getServiceInstanceStatus = function (serviceName) {
    var serviceInstanceName = this.viewInstanceNameXpath.format(serviceName);
    var serviceInstanceStatus = element(by.cssContainingText(this.viewInstanceStatusCss, 'Deleted'));
    browser.sleep(5000); // as it takes few seconds to update the Instance details added static wait
    return element(by.xpath(serviceInstanceName)).isPresent().then(function (status) {
        if (status == true) {
            logger.info("service Instance " + serviceName + " is present")
            return serviceInstanceStatus.getText().then(function (instanceStatus) {
                logger.info("service instance status is : " + instanceStatus);
                return instanceStatus;
            });
        }
    });
 };
 
 catalogManagement.prototype.clickOnFailedDiscoveryViewDetailsLink = function () {
     util.waitForAngular();
     browser.wait(EC.elementToBeClickable(element.all(by.css(this.viewDetailsForFirstFailedDiscoveryCss)).get(0)), timeout.timeoutInMilis);
     return element.all(by.css(this.viewDetailsForFirstFailedDiscoveryCss)).get(0).click().then(function () {
         logger.info("clicked on Failed Discovery View Details Link");
     });
 };
 
 catalogManagement.prototype.clickOnCloseButtonforFailedDialogStatusBox = function () {
     util.waitForAngular();
     browser.wait(EC.elementToBeClickable(element.all(by.css(this.closeFailedStatusPopupCss)).get(1)), timeout.timeoutInMilis);
     return element.all(by.css(this.closeFailedStatusPopupCss)).get(1).click().then(function () {
         logger.info("clicked on Close Button for Failed Dialog Status Box");
     });
 };
 
 catalogManagement.prototype.getFailedDiscoveryMessageText = function () {
     util.waitForAngular();
     var MsgCssElement = element.all(by.css(this.FailedStatusMessageStatusCss)).get(0);
     browser.wait(EC.visibilityOf(MsgCssElement), timeout.timeoutInMilis);
     return MsgCssElement.getText().then(function (MessageText) {
         logger.info("Failed discovery Message status is : " + MessageText);
         return MessageText;
     });
 };
 module.exports = catalogManagement;
 