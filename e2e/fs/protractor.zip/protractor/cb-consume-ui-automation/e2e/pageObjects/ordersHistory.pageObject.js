"use strict";
var extend = require('extend');
var url = browser.params.url;
var util = require('../../helpers/util.js');
var CatalogPage = require('../pageObjects/catalog.pageObject.js');
var mcmpUIDataTemplate = require('../../testData/mcmp/mcmpUIData.json');
var logGenerator = require("../../helpers/logGenerator.js"),
	logger = logGenerator.getApplicationLogger();
var jsonUtil = require('../../helpers/jsonUtil.js');
var CartListPage = require('../pageObjects/cartList.pageObject.js');

var EC = protractor.ExpectedConditions;

var defaultConfig = {
	pageUrl: url + '/consume/orders/my-orders',
	allOrderTextByXpath: '//span[contains(text(), "All Orders")]',
	orderSearchTextBoxCss: '#search__input-orders-search',
	orderStatusByXpath: '//span[@id="status"]',

	//******************Locators for Order Details Section*******************
	orderTableDetailsExpandArrowCss: 'svg.bx--accordion__arrow',
	orderTableActionIconCss: '.bx--overflow-menu__icon',
	orderTableActionsRetryCss: '.bx--overflow-menu__group button',
	orderTableActionsCancelCss: '#carbon-deluxe-data-table-0-parent-row-1-option-2-button',
	orderTableActionsCancelXpath: '(//button[contains(text(),"Cancel")])[3]',
	//******************Locators for Order Update Section*********************
	orderCompletedTextCss: '.order-updates__tile',
	orderCompletedTextXpath: './/div[@class="order-updates xl-padding"]/descendant::div[@class="order-updates__tile" and contains(text(),"Submitted by") ]',
	approvalStatusClassName: 'approval-card__status',
	expandApprovalTileCss: '.bx--tile-content__above-the-fold',
	approvalDetailsTileCss: '.bx--tile-content__below-the-fold',

	//orderTableActionsViewCommentsCss:			'#carbon-deluxe-data-table-0-parent-row-1-option-4-button',
	orderTableActionsViewCommentsCss: '[id*="-parent-row-1-option-4-button"]',
	orderTableActionsViewCommentsModelCss: '.bx--modal is-visible',
	orderTableActionsViewCommentsModelHeaderXpath: '//h2[contains(text(), "Service Status Details")]',
	orderTableActionsViewCommentsModelErrorMsgCss: 'ibm-overlay > section > div > div > p',
	orderTableActionsViewCommentsModelCloseXpath: '//h2[contains(text(), "Service Status Details")]/following-sibling::button',
	orderTableOrderIDColumnCss: '#order-id-header',
	orderTableCreatedDateColumnCss: '#created-date',
	orderTableOrderStatusColumnCss: 'div.first-row span',
	orderTableActionsRetryYesCss: '#btn-retry-modal-retry',
	orderTableActionsRetryNoCss: '#order_retry_no',
	orderTableActionsRetryCloseCss: '#close-btn_retry-service-modal',
	orderTableActionsRetryModelCss: '.bx--modal is-visible',
	orderTableActionsRetryModelHeaderXpath: '//h2[contains(text(), "Retry Service Fulfillment")]',
	orderTableActionsRetryModelMsgXpath: '//span[@id="retry_message"][contains(text(), "Are you sure you want to retry provisioning for this service?")]',
	orderTableActionsRetryModelSuccessMsgCss: '#body',
	orderTableActionsRetryModelOkButtonCss: '#order_retry_ok',
	orderTableActionsCancelYesCss: '#order_cancel_yes',
	orderTableActionsCancelYesXpath: '//cancel-service-modal//button[@id="order_cancel_yes"]',
	orderTableActionsCancelNoCss: '#order_cancel_no',
	orderTableActionsCancelCloseCss: '#close-btn_cancel-service-modal',
	orderTableActionsCancelModelCss: '.bx--modal is-visible',
	orderTableActionsCancelModelHeaderXpath: '//h2[contains(text(), "Cancel Service")]',
	orderTableActionsCancelModelMsgXpath: '//span[@id="cancel_message"][contains(text(), "Are you sure you want to cancel this service?")]',
	orderTableActionsCancelModelSuccessMsgXpath: '//carbon-notification[contains(@class, "bx--inline-notification bx--inline-notification--success")][@type="success"]',
	orderTableActionsCancelModelOkButtonXpath: '//*[@id="order_cancel_ok"]',
	textEstimatedCostCss: ".order-accordion-item-header span",
	//txtOrderTotalXpath: '//div[@id ="total-cost"]',
	txtOrderTotalXpath: '//div[@class ="third-column cost"]/div',
	txtEstimatedCostXpath: '//span[contains(text(),"USD")]',
	lnkBillOfMaterialXapth: '//a[contains(text(), "Bill of Materials")]',
	lnkBOMServiceDetailsCss: "[cust-id='estimated-cost-link']",
	orderDetailsCss: 'span a[cust-id="order-details-link"]',
	orderUpdatescss: 'button[data-tab-id="order_updates"]',
	lnkBillOfMaterialsTabCss: "button[data-tab-id='bill_of_materials']",
	txtBOMestimatedCost: ".total-cost-value",
	lnkMoreXpath: '//*[text()="More"]',
	btnCloseXpath: '//*[text()="Service Details"]/../button/carbon-icon',
	orderTotalCostBillofMaterialsTabCss: '#total_cost_value',
	loadingcss: 'div>div>svg>circle',

	//Cancel order locators in order history page
	buttonCancelCss: 'div.first-row > div.adjustSpace > button',

	//buttonCancelOrderConfirmationCss: '#button-order_cancel_yes',
	buttonTextCancelOrderConfirmationCss: 'Yes',
	textCancelOrderSuccessMsgCss: '//*[@class="title" and @id="body"]',
	buttonCancelOrderOkCss: '#order_cancel_ok',
	textCancelStatusCss: 'div.first-column.status.status-red > span',
	serviceWithAddonStatusCss: '.bx--data-table tbody td:nth-child(6) span',
	txtImiAddOnCss: 'ibm-tag',
	btnExpandAddOnCss: 'svg.bx--table-expand__svg',
	btnExpandAddOnDetailCss: 'svg.bx--table-expand__svg',
	tblAddOnDetailXpath: '//table[@id="_subId0"]//tr[1]//td',
	btnAddOnCss: '[data-tab-id=add-on_details_]',


	//**********   Filter by Period  ***************
	selectOrdersFromCreatedTimeByCss: '#bx--dropdown-single-parent_ordercreatedtime',


	//*********   Filter by Order Status ******************
	selectOrdersFromOrderStatusByCss: '#bx--dropdown-single-parent_orderstatus',

	storeHeaderCss: '.bx--header__name',
	buttonLeftNavSubMenu: '.bx--side-nav__submenu',
	buttonLeftSubmenuCss: '.bx--side-nav__submenu-title',
	buttonLeftSubmenuExpandXpath: '//*[@class="bx--side-nav__submenu-title"]/parent::button',
	txtImiPlanLvelCss: '#planlevel_value',
	txtImimangmntLvelCss: '#managementlevel_value',
	btncloseServiceDetlPopUpCss: '#alert-modal-button-0',
	//**********
	TotalMonthlyPricing: '.bx--table-body tr td',
	orderNotFoundTextXpath:	'//p[@class = "bx--inline-notification__subtitle"]/span',
	selectOrderCssOption:'#dropdown-option_orderstatus_',
	orderIdXpath:'//*[contains(text(),"Order ID:")]/..',

	//Service logs and resource logs locators for order history page
	viewFailureLinkCss:"app-cart-order-card:nth-child(1) > div > div.first-row > div.fourth-column.cost > div > span.failures > a",
	ViewLogsLinkCss:".bx--slide-over-panel-content > div > div > div:nth-child(2) > div > a",
	serviceLogsCss:'#tab-control-service_details',
	resourceLogsCss:"#tab-control-activity",
	serviceLogTextCss:".service-display-log",
	ResourceLogTextCss: ".activity-display-log",
	txtBillOfMaterialXPath:"//div[text()=' Bill of Materials ']",
	btnServiceDetailsXpath:"//div[text() = ' Service Details ']",
	txtBillOfMaterialXTACss:"app-cart-order-card > ibm-placeholder > ibm-overflow-menu-pane > ul > ibm-overflow-menu-option:nth-child(1) > button > div",   
	linkServiceDetailsTACss:"app-cart-order-card > ibm-placeholder > ibm-overflow-menu-pane > ul > ibm-overflow-menu-option:nth-child(2) > button > div",

	//*Retry Edit option for TA services
	orderTableActionsRetryeditCss : '#btn-retry-modal-edit'
};


//******** Order status *************
global.failedStatus = "Failed";
global.approvalInProgressStatus = 'Approval In Progress';
global.provisioningInProgressStatus = 'Provisioning in Progress';


function ordersHistory(selectorConfig) {
	if (!(this instanceof ordersHistory)) {
		return new ordersHistory(selectorConfig);
	}
	extend(this, defaultConfig);

	if (selectorConfig) {
		extend(this, selectorConfig);
	}
}

ordersHistory.prototype.open = function () {
	/*//browser.ignoreSynchronization = true;
	await util.getUrl(this.pageUrl);
	browser.wait(EC.urlContains("/consume/orders/my-orders"), 90000).then( function(){
		logger.info("Navigated to Orders History page");
	})
	browser.wait(EC.visibilityOf(element(by.css(this.storeHeaderCss))),90000);
		browser.switchTo().frame(element(by.tagName('iframe')).getWebElement());
		//browser.ignoreSynchronization = false;
	util.waitForAngular();*/

	var catalogPage = new CatalogPage();
	util.switchToDefault();
	//browser.ignoreSynchronization = true;
	catalogPage.clickHamburgerCatalog();
	catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
	catalogPage.checkIfleftNavStoreExpanded();
	catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkOrderHistory);
	util.switchToFrame();
	util.waitForAngular();
	//browser.ignoreSynchronization = false;
};


//******************************Function for checking visibility of element********//

ordersHistory.prototype.verifyAllOrderText = function () {
	browser.wait(EC.visibilityOf(element(by.xpath(this.allOrderTextByXpath))), 30000).then(function () {
		logger.info("All Orders Text is shown...");
	});
};

ordersHistory.prototype.verifyOrdersFromCreatedTime = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.selectOrdersFromCreatedTimeByCss))), 30000).then(function () {
		logger.info("Orders from created time dropdown is shown...");
	});
};

ordersHistory.prototype.verifyOrdersFromOrderStatus = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.selectOrdersFromOrderStatusByCss))), 30000).then(function () {
		logger.info("Orders from order status dropdown is shown...");
	});
};

//******************************Function for searching an Order*******************//

ordersHistory.prototype.searchOrderById = function (orderId) {
	var curr = this
	browser.wait(EC.visibilityOf(element(by.css(this.orderSearchTextBoxCss))), 90000);
	var searchInputBox = element(by.css(this.orderSearchTextBoxCss));
	//util.waitForAngular();
	searchInputBox.clear();
	searchInputBox.sendKeys(orderId);
	logger.info("Searching Order in Order History page");
	//util.waitForAngular();
	browser.wait(EC.invisibilityOf(element.all(by.css(curr.loadingcss)).first()), 65000);
	return element(by.xpath(curr.orderNotFoundTextXpath)).getText().then(function (message) {
		logger.info(message);
		if (message === "No orders found") {
			browser.sleep(5000);	
			element(by.css(curr.selectOrdersFromOrderStatusByCss)).click();
			element(by.css(curr.selectOrderCssOption)).click();
		}
	}).catch(function () {
		return "Order Found";
	});	
};

//*********************Function for Order Table to get values for First Order *************//

ordersHistory.prototype.getTextFirstOrderIdOrdersTable = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.orderTableOrderIDColumnCss))), 10000);
	return element.all(by.css(this.orderTableOrderIDColumnCss)).first().getText().then(function (text) {
		var orderId = text;
		if (orderId.includes('Order ID:')) {
			orderId = orderId.replace('Order ID:', '');
		}
		logger.info("Order ID :: " + orderId);
		return orderId;
	});
};

ordersHistory.prototype.getTextFirstCreatedDateOrdersTable = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.orderTableCreatedDateColumnCss))), 10000);
	return element.all(by.css(this.orderTableCreatedDateColumnCss)).first().getText().then(function (text) {
		logger.info("Order Created Date :: " + text);
		return text;
	});
};


ordersHistory.prototype.getTextFirstOrderStatusOrdersTable = function () {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.orderTableOrderStatusColumnCss))), 10000);
	return element.all(by.css(this.orderTableOrderStatusColumnCss)).first().getText().then(function (text) {
		logger.info("Order status of the first order from Order table is: " + text);
		return text;
	});
};


//************************  FUNCTIONS FOR Orders Action Items********************************

ordersHistory.prototype.clickOnOrderTableDetailsExpandArrow = function () {
	var curr = this;
	util.waitForAngular();
	browser.sleep(3000);
	browser.wait(EC.elementToBeClickable(element(by.css(this.orderTableDetailsExpandArrowCss))), 70000).then(function () {
		logger.info("Order details exapand arrow is shown...");
		return element(by.css(curr.orderTableDetailsExpandArrowCss)).click().then(function () {
			logger.info("Expanded the row");
			util.waitForAngular();
		});
	});
};

ordersHistory.prototype.clickOrdersTableActionIcon = function () {
	var curr = this;
	util.waitForAngular();	
	var elemActnBtn = element.all(by.css(curr.orderTableActionIconCss));
	browser.wait(EC.elementToBeClickable(elemActnBtn.first()), 20000).then(function () {
		return elemActnBtn.get(0).isPresent().then(function(status){
			browser.wait(EC.elementToBeClickable(elemActnBtn.first()), 70000).then(function () {
				return elemActnBtn.first().click().then(function () {
					logger.info("Clicked on the Actions icon of the first row on Orders page");
					util.waitForAngular();
				});
			}).catch(function(err){
				elemActnBtn.last().click();
			});
		});
	}).catch(function(err){
		elemActnBtn.last().click();
	});	
};

ordersHistory.prototype.isDisplayedViewDetailsUnderActionsButton = function () {
	var curr = this;
	return element.all(by.css(this.orderTableActionIconCss)).first().click().then(function () {
		logger.info("Clicked on the first Actions Icon")
		return element(by.buttonText(curr.buttonTextViewDetails)).isDisplayed();
	});
};
//Functions for Cancelling the Order.
ordersHistory.prototype.clickCancelOrderButton = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonCancelCss))), 30000);
	return element(by.css(this.buttonCancelCss)).click().then(function () {
		logger.info("Clicked the Cancel Button in order history page...");
	});
};

ordersHistory.prototype.clickCancelOrderConfirmationButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.buttonTextCancelOrderConfirmationCss))), 30000);
	return element(by.buttonText(this.buttonTextCancelOrderConfirmationCss)).click().then(function () {
		logger.info("Clicked the Cancel Button confirmation popup in order history page...");
	});
};

ordersHistory.prototype.getTextCancelOrderSuccessFulMsg = function () {
	browser.wait(EC.visibilityOf(element(by.xpath(this.textCancelOrderSuccessMsgCss))), 30000);
	return element(by.xpath(this.textCancelOrderSuccessMsgCss)).getText().then(function (cancelOrderSuccessMsg) {
		logger.info("Cancel Order success msg :" + cancelOrderSuccessMsg);
		return cancelOrderSuccessMsg;
	});
};

ordersHistory.prototype.getTextCancelOrderStatusInOrderHistory = function () {
	var curr = this
	browser.wait(EC.visibilityOf(element(by.css(curr.textCancelStatusCss))), 30000);
	browser.sleep(2000);
	return element(by.css(curr.textCancelStatusCss)).getText().then(function (cancelOrderStatus) {
		logger.info("Cancel Order status in order history :" + cancelOrderStatus);
		return cancelOrderStatus;
	});
};

ordersHistory.prototype.clickCancelOrderOkButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonCancelOrderOkCss))), 30000);
	return element(by.css(this.buttonCancelOrderOkCss)).click().then(function () {
		logger.info("Clicked the Cancel order Ok button in history page...");
	});
};

ordersHistory.prototype.searchOrderClickCancelOrder = function (sampleOrder1) {
	this.open();
	this.searchOrderById(sampleOrder1);
	this.clickCancelOrderButton();
};

ordersHistory.prototype.searchOrder = function (sampleOrder1) {
	this.open();
	this.searchOrderById(sampleOrder1);
};

//************************  FUNCTIONS FOR View Comments and Retry order from order Action Model****************

ordersHistory.prototype.clickOnOrderTableActionsRetryOption = function () {
	browser.wait(EC.elementToBeClickable(element.all(by.css(this.orderTableActionsRetryCss)).first()), 30000).then(function () {
		logger.info("Retry option is shown from Action Icon click...");
	});
	return element.all(by.css(this.orderTableActionsRetryCss)).first().click().then(function () {
		logger.info("Clicked on Retry option");
	})
};

ordersHistory.prototype.clickOnOrderTableActionsCancelOption = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.orderTableActionsCancelCss))), 30000).then(function () {
		logger.info("Cancel option is shown from Action Icon click...");
	});
	return element(by.css(this.orderTableActionsCancelCss)).click().then(function () {
		logger.info("Clicked on Cancel option");
	})
};

ordersHistory.prototype.clickOnOrderTableActionsCancelOptionXpath = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.orderTableActionsCancelXpath))), 30000).then(function () {
		logger.info("Cancel option is shown from Action Icon click...");
	});
	return element(by.xpath(this.orderTableActionsCancelXpath)).click().then(function () {
		logger.info("Clicked on Cancel option");
	})
};

ordersHistory.prototype.clickOnOrderTableActionsViewCommentsOption = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.orderTableActionsViewCommentsCss))), 30000).then(function () {
		logger.info("View comments option is shown from Action Icon click...");
	});
	return element(by.css(this.orderTableActionsViewCommentsCss)).click();
};


ordersHistory.prototype.verifyOrderTableActionsViewCommentsModelVisibility = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.orderTableActionsViewCommentsModelCss))), 30000).then(function () {
		browser.wait(EC.visibilityOf(element(by.xpath(this.orderTableActionsViewCommentsModelHeaderXpath))), 30000);
	});
};

ordersHistory.prototype.getTextOrderTableActionsViewCommentsModelErrorMsg = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.orderTableActionsViewCommentsModelErrorMsgCss))), 10000);
	return element(by.css(this.orderTableActionsViewCommentsModelErrorMsgCss)).getText().then(function (text) {
		logger.info("Table Actions View Comments Model Error Msg :: " + text);
		//Close popup
		return element(by.css(defaultConfig.btncloseServiceDetlPopUpCss)).click().then(function () {
			logger.info("Closed service details pop up.");
			return text;
		});
	});
};

ordersHistory.prototype.clickOnorderTableActionsViewCommentsModelCloseButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.orderTableActionsViewCommentsModelCloseXpath))), 30000).then(function () {
		logger.info("View comments model close button is shown...");
	});
	return element(by.xpath(this.orderTableActionsViewCommentsModelCloseXpath)).click();
};

ordersHistory.prototype.verifyOrderTableActionsViewRetryModelVisibility = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.orderTableActionsRetryModelCss))), 30000).then(function () {
		browser.wait(EC.visibilityOf(element(by.xpath(this.orderTableActionsRetryModelHeaderXpath))), 30000).then(function () {
			browser.wait(EC.visibilityOf(element(by.xpath(this.orderTableActionsRetryModelMsgXpath))), 30000);
		});
	});
};

ordersHistory.prototype.clickOnOrderTableActionsRetryYesButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.orderTableActionsRetryYesCss))), 30000).then(function () {
		logger.info("Table Action Retry model's Yes button is shown...");
	});
	return element(by.css(this.orderTableActionsRetryYesCss)).click().then(function () {
		logger.info("Clicked on retry option pop up message");
	})
	util.waitForAngular();
};

ordersHistory.prototype.clickOnOrderTableActionsRetryNoButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.orderTableActionsRetryNoCss))), 30000).then(function () {
		logger.info("Table Action Retry model's No button is shown...");
	});
	return element(by.css(this.orderTableActionsRetryNoCss)).click();
};

ordersHistory.prototype.verifyOrderTableActionsRetryModelSuccessMsgVisibility = function () {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.orderTableActionsRetryModelSuccessMsgCss))), 50000).then(function () {
		logger.info("Table Action Rety Model is shown...");
	});
	return element(by.css(this.orderTableActionsRetryModelSuccessMsgCss)).getText().then(function (msg) {
		logger.info("Retry success message: " + msg);
		return msg;
	})
};

ordersHistory.prototype.clickOnOrderTableActionsRetryModelOkButton = function () {
	browser.wait(EC.elementToBeClickable(element.all(by.css(this.orderTableActionsRetryModelOkButtonCss)).last()), 30000).then(function () {
		logger.info("Table Action Retry Model OK button is shown...");
	});
	return element.all(by.css(this.orderTableActionsRetryModelOkButtonCss)).last().click().then(function () {
		logger.info("Clicked on Ok button for retry");
	})
};

ordersHistory.prototype.verifyOrderTableActionsViewCancelModelVisibility = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.orderTableActionsCancelModelCss))), 30000).then(function () {
		browser.wait(EC.visibilityOf(element(by.xpath(this.orderTableActionsCancelModelHeaderXpath))), 30000).then(function () {
			browser.wait(EC.visibilityOf(element(by.xpath(this.orderTableActionsCancelModelMsgXpath))), 30000);
		});
	});
};

ordersHistory.prototype.clickOfJustPlaceOrderYesButton = function () {

	util.waitForAngular();
	var elemToClick = element(by.xpath(this.orderTableActionsCancelYesXpath));
	browser.wait(EC.elementToBeClickable(elemToClick), 30000);
	return elemToClick.click().then(function () {
		logger.info("Clicked on Order History --> Service Details link");
		util.waitForAngular();
	});
};

ordersHistory.prototype.clickOnOrderTableActionsCancelYesButton = function () {

	util.waitForAngular();
	var elemToClick = element.all(by.css(this.orderTableActionsCancelYesCss)).first();
	browser.wait(EC.elementToBeClickable(elemToClick), 30000);
	return elemToClick.click().then(function () {
		logger.info("Clicked on Cancel Yes button");
		util.waitForAngular();
	});
};

ordersHistory.prototype.clickOnOrderTableActionsCancelYesButtonXpath = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.orderTableActionsCancelYesXpath))), 30000).then(function () {
		logger.info("Table Action Cancel Model Yes Button is shown...");
	});
	return element(by.xpath(this.orderTableActionsCancelYesXpath)).click();
};

ordersHistory.prototype.clickOnOrderTableActionsCancelNoButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.orderTableActionsCancelNoCss))), 30000).then(function () {
		logger.info("Table Action Cancel Model No Button is shown...");
	});
	return element(by.css(this.orderTableActionsCancelNoCss)).click();
};

ordersHistory.prototype.verifyOrderTableActionsCancelModelSuccessMsgVisibility = function () {
	browser.wait(EC.visibilityOf(element(by.xpath(this.orderTableActionsCancelModelSuccessMsgXpath))), 30000).then(function () {
		logger.info("Table Action Cancel Model's Success message is shown...");
	});
	return element(by.xpath(this.orderTableActionsCancelModelSuccessMsgXpath)).getText().then(function (msg) {
		logger.info("Cancel Order success message is: " + msg);
		return msg;
	})
};

ordersHistory.prototype.clickOnOrderTableActionsCancelModelOkButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.orderTableActionsCancelModelOkButtonXpath))), 30000).then(function () {
		logger.info("Table Action Cancel Model's OK button is shown...");
	});
	return element(by.xpath(this.orderTableActionsCancelModelOkButtonXpath)).click();
};

ordersHistory.prototype.getOrderTotal = function () {
	var elmOrderTotal = element(by.xpath(this.txtOrderTotalXpath));
	browser.wait((EC.elementToBeClickable(elmOrderTotal)), 40000);
	return elmOrderTotal.getText().then(function (text) {
		logger.info("Order total on Order History Page is : " + text);
		return text;
	});

};

ordersHistory.prototype.validatePricingonOrderHistory = function (orderId, orderTotal, serviceListExp) {
	var ordersHistoryPage = new ordersHistory();
	var cartListPage = new CartListPage();
	
	var actualOrderTotal = 0;
	let promiseArr = [];
	var finlValidn = false;
	var self = this;
	orderTotal = parseFloat(orderTotal.replace("USD ", ""));
	//Get order total of all services of cart
	ordersHistoryPage.open();
	ordersHistoryPage.searchOrderById(orderId);
	ordersHistoryPage.getOrderTotal().then(function (cost) {
		cost = parseFloat(cost.replace("USD ", ""));
		expect(cost.toFixed(4)).toEqual(orderTotal.toFixed(4));
		logger.info("Order total is succesfully validated on order history page.");
	});
	var eleEstimatedCost = element.all(by.xpath(this.txtEstimatedCostXpath));
	var estimatedCost;
	browser.sleep(4000);
	//Validate Estimated cost of all services of cart
	eleEstimatedCost.getText().then(function (arr) {
		for (var i = 0; i < arr.length; i++) {
			estimatedCost = arr[i].split(" /")[0];
			if (estimatedCost == serviceListExp[Object.keys(serviceListExp)[i]]) {
				logger.info("Estimated cost for " + Object.keys(serviceListExp)[i] + " is : " + estimatedCost);
				actualOrderTotal = parseFloat(actualOrderTotal) + parseFloat(estimatedCost.replace("USD ", ""));
				//Validate BOM
				//Click on BOM
				self.clickOrdersTableActionIconBasedOnIndex(i);
				self.clickBillOfMaterialsBtn();
				//ordersHistoryPage.clickBillOfMaterials(i).then(function () {
					//Validate estimated cost
					expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toBe(serviceListExp[Object.keys(serviceListExp)[i]]);
					//click on More link
					ordersHistoryPage.clickMoreLinkBom();
					cartListPage.clickExpandQuantity();
					//Validate pricing
					finlValidn = cartListPage.getTotalPriceOfAllInstances();
					//Close slider
					ordersHistoryPage.closeServiceDetailsSlider();
					promiseArr.push(finlValidn);

				//});
			}
		}
		expect(actualOrderTotal.toFixed(4)).toEqual(orderTotal.toFixed(4));
		if (actualOrderTotal.toFixed(4) == orderTotal.toFixed(4)) {
			logger.info("Order Total of all services of cart matches to USD " + actualOrderTotal);
		} else {
			logger.info("Order Total of all services of cart do not match | Actual : USD " + actualOrderTotal + " | Expected : " + orderTotal);
			return false;
		}

	});

	return Promise.all(promiseArr).then(function (finlValidn) {
		if (finlValidn.indexOf(false) != -1) {
			return Promise.resolve(false);
		} else {
			return Promise.resolve(true);
		}
	});
};

ordersHistory.prototype.clickServiceDetailsLink = function () {
	
	util.waitForAngular();
	browser.sleep(3000);
	this.clickOrdersTableActionIcon();
	var elemToClick = element(by.xpath(this.btnServiceDetailsXpath));
	//browser.wait(EC.visibilityOf(elemToClick)), 30000;
	browser.wait(EC.elementToBeClickable(elemToClick), 90000).then(function () {
		logger.info("Waiting for Order history Service details link to be clickbale");
	}).catch(function (err) {
		logger.info("Timeout - Order history --> service details link");
	});
	return elemToClick.click().then(function () {
		logger.info("Clicked on Order History --> Service Details link");
		util.waitForAngular();
	});
};

ordersHistory.prototype.clickBillOfMaterials = function (index) {
	util.waitForAngular();
	browser.sleep(3000);
	this.clickOrdersTableActionIcon();
	var elemToClick = element(by.xpath(this.txtBillOfMaterialXPath));
	browser.wait(EC.elementToBeClickable(elemToClick), 30000);
	return elemToClick.click().then(function () {
		logger.info("Clicked on Order History --> Bill of Materials for service - ");
		util.waitForAngular();
	});
};

ordersHistory.prototype.clickOnOrderDetails = function (index) {
	var self = this;
	var elemToClick = element(by.css(this.orderDetailsCss));
	browser.wait(EC.elementToBeClickable(elemToClick), 30000);
	elemToClick.click().then(function () {
		logger.info("Clicked on Order History --> order details link - ");
	}).catch(function(){
		logger.info("Unable to clicked order details link, so clicking again...");
		elemToClick.click().then(function () {
			logger.info("Clicked on Order History --> order details link - ");
		})
	});
		util.waitForAngular();
		browser.sleep(4000);
		self.clickOnOrderUpdates();
};

ordersHistory.prototype.clickOnOrderUpdates = function () {
	var elemToClick = element.all(by.css(this.orderUpdatescss)).get(1);
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(elemToClick), 80000).then(function () {
		return elemToClick.click().then(function () {
			logger.info("Clicked on More link in Order details--> Order updates section");
		});
	});
};

ordersHistory.prototype.clickMoreLinkBom = function () {
	util.waitForAngular();
	var elemToClick = element.all(by.xpath(this.lnkMoreXpath)).get(1);
	browser.wait(EC.elementToBeClickable(elemToClick), 30000).then(function () {
		util.waitForAngular();
		browser.sleep(3000);
		return elemToClick.click().then(function () {
			logger.info("Clicked on More link in Order History --> Bill of Materials section");
		});
	});
};

ordersHistory.prototype.getTextTotalCostOnBillofMaterials = function () {
	var elem = element.all(by.css(this.orderTotalCostBillofMaterialsTabCss)).get(1);
	return browser.wait(EC.visibilityOf(elem), 30000).then(function () {
		elem.getText().then(function (text) {
			logger.info('\n' + "Total Cost on Bill of Materials tab on Order History page : " + text);
			return text;
		});
	});
};

ordersHistory.prototype.closeServiceDetailsSlider = function () {
	var elemToClick = element.all(by.xpath(this.btnCloseXpath)).get(1);
	return browser.wait(EC.elementToBeClickable(elemToClick), 30000).then(function () {
		return elemToClick.click().then(function () {
			logger.info("Clicked on Close button of Service details page");
			util.waitForAngular();
			browser.sleep(6000);
		});
	});
};

ordersHistory.prototype.getTextServiceDetailsBasedOnLabelName = function (labelName) {
	browser.wait(EC.visibilityOf(element.all(by.xpath('//label[contains(text(), "' + labelName + '")]/following-sibling::p')).last()), 55000);
	return element.all(by.xpath('//label[contains(text(), "' + labelName + '")]/following-sibling::p')).last().getText().then(function (text) {
		logger.info("The value for " + labelName + " is : " + text)
		return text;
	});
};

ordersHistory.prototype.clickBillOfMaterialsTabInServiceDetails = function () {
	browser.wait(EC.visibilityOf(element.all(by.css(this.lnkBillOfMaterialsTabCss)).last()), 60000);
	return element.all(by.css(this.lnkBillOfMaterialsTabCss)).last().click().then(function () {
		logger.info("Clicked on Bill of Materials tab");
	});
};

ordersHistory.prototype.getTextEstimatedCostOrderHistory = function () {
	util.waitForAngular();
	browser.sleep(4000);
	browser.wait(EC.visibilityOf(element.all(by.css(this.textEstimatedCostCss)).get(3)), 60000);
	var ele = element.all(by.css(this.textEstimatedCostCss)).get(3)
	return ele.getText().then(function (text) {
		logger.info("Estimated Cost in Order History page is :: " + text);
		return text;
	});
}

ordersHistory.prototype.getEstimatedCostFromBillOfMaterialsTab = function () {
	browser.wait(EC.visibilityOf(element.all(by.css(this.txtBOMestimatedCost)).last()), 60000);
	return element.all(by.css(this.txtBOMestimatedCost)).last().getText().then(function (text) {
		logger.info("Estimated Cost in Bill of Materials tab is :: " + text);
		return text;
	});
}




ordersHistory.prototype.searchOrderClickRetry = function (sampleOrder1) {
	this.open();
	this.searchOrderById(sampleOrder1);
	this.clickOnOrderTableDetailsExpandArrow();
	this.clickOrdersTableActionIcon();
	this.clickOnOrderTableActionsRetryOption();
	this.clickOnOrderTableActionsRetryYesButton();
};

ordersHistory.prototype.searchOrderClickCancel = function (sampleOrder1) {
	this.open();
	this.searchOrderById(sampleOrder1);
	this.clickOnOrderTableDetailsExpandArrow();
	this.clickOrdersTableActionIcon();
	this.clickOnOrderTableActionsCancelOption();
	this.clickOnOrderTableActionsCancelYesButtonXpath();
};

ordersHistory.prototype.getOrderFailureReason = function (orderId) {

	this.open();
	this.searchOrderById(orderId);
	this.clickOnOrderTableDetailsExpandArrow();
	this.clickOrdersTableActionIcon();
	this.clickOnOrderTableActionsViewCommentsOption();
	return this.getTextOrderTableActionsViewCommentsModelErrorMsg();
};

ordersHistory.prototype.getTextServiceDetailsBasedOnExactLabelName = function (labelName) {
	browser.wait(EC.visibilityOf(element.all(by.xpath('//label[text()="' + labelName + '"]/following-sibling::p')).get(1)), 10000);
	return element.all(by.xpath('//label[text()="' + labelName + '"]/following-sibling::p')).get(1).getText().then(function (text) {
		logger.info("The value for " + labelName + " is : " + text)
		return text;
	});
};

ordersHistory.prototype.verifyApprovalOrderStatus = function (approvalStatus) {
	return element.all(by.className(this.approvalStatusClassName)).getText().then(function (status) {
		for (let i = 2; i < 3; i++) {
			if (status[i] != approvalStatus) {
				return false;
			};
		};
		logger.info("Approval Status matched");
		return true;
	});
};

ordersHistory.prototype.expandTheFinancialApprovalFromTheOrderDetailsPage = function () {
	let webElementFinancialApprovalTab = element.all(by.css(this.expandApprovalTileCss)).get(3);
	browser.actions().mouseMove(webElementFinancialApprovalTab).click().perform().then(function () {
		logger.info("Expanded the Financial Approval tab")
	})
};

ordersHistory.prototype.getFinancialApprovalDetails = function () {
	let webElementFinancialApprovall = element.all(by.css(this.approvalDetailsTileCss)).get(3);
	return webElementFinancialApprovall.getText().then(function (text) {
		//logger.info("Financial aproval users are : " + text);
		return text;
	})
};

ordersHistory.prototype.getTechnicalApproversDetails = function () {
	let webElementFinancialApprovall = element.all(by.css(this.approvalDetailsTileCss)).get(2);
	browser.wait(EC.visibilityOf(webElementFinancialApprovall), 60000);
	return webElementFinancialApprovall.getText().then(function (text) {
		//logger.info("Technical approval users are : " + text);
		return text;
	})
};


ordersHistory.prototype.expandTheTechnicalApprovalFromTheOrderDetailsPage = function () {
	let webElementFinancialApprovalTab = element.all(by.css(this.expandApprovalTileCss)).get(2);
	browser.actions().mouseMove(webElementFinancialApprovalTab).click().perform().then(function () {
		logger.info("Expanded the Technical Approval tab");
	})
};

ordersHistory.prototype.getTextServiceDetailsBasedOnExactLabelName = function (labelName) {
	browser.wait(EC.visibilityOf(element.all(by.xpath('//label[text()="' + labelName + '"]/following-sibling::p')).get(1)), 10000);
	return element.all(by.xpath('//label[text()="' + labelName + '"]/following-sibling::p')).get(1).getText().then(function (text) {
		logger.info("The value for " + labelName + " is : " + text)
		return text;
	});
};

ordersHistory.prototype.getTextImiAddOn = function () {
	return element(by.css(this.txtImiAddOnCss)).getText().then(function (text) {
		logger.info("The value for Imi addon - " + text);
		return text;
	});
};

ordersHistory.prototype.clickExpandArrowForServiceAddOn = function () {
	browser.sleep(3000);
	var elem = element(by.css(this.btnExpandAddOnDetailCss));
	browser.wait(EC.elementToBeClickable(element.all(by.css(this.btnExpandAddOnCss)).get(0)), 30000).then(function () {
		logger.info("Service details exapand arrow is shown for add on...");
	});
	browser.executeScript("arguments[0].scrollIntoView();", elem);
	return elem.click().then(function () {
		logger.info("Expanded the row for Service Add-Ons");
		util.waitForAngular();
	});
};

ordersHistory.prototype.getAddOnDetails = function () {
	util.waitForAngular();
	return element.all(by.xpath(this.tblAddOnDetailXpath)).getText().then(function (addOnDetails) {
		logger.info("The Add on Details - " + addOnDetails[1] + "|" + addOnDetails[3] + "|" + addOnDetails[4] + "|" + addOnDetails[5]);
		return addOnDetails;
	});
};

ordersHistory.prototype.clickAddOnDetails = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.btnAddOnCss)), 10000));
	return element.all(by.css(this.btnAddOnCss)).click().then(function () {
		logger.info("Clicked on Add On Details");
		util.waitForAngular();
	});
};

ordersHistory.prototype.getImiManagedServiceDetails = function () {
	util.waitForAngular();
	browser.sleep(2000);
	var manageServiceDetails = [];
	var elemPlanLevel = element.all(by.css(this.txtImiPlanLvelCss));
	var elemManagmntLevel = element.all(by.css(this.txtImimangmntLvelCss));
	return new Promise(function (resolve, reject) {
		elemManagmntLevel.last().getText().then(function (mangmntLevl) {
			manageServiceDetails.push(mangmntLevl);
			logger.info("order history : Management level -" + mangmntLevl);
			elemPlanLevel.last().getText().then(function (planLevl) {
				manageServiceDetails.push(planLevl);
				logger.info("order history : Plan level -" + planLevl);
				resolve(manageServiceDetails);
			});
		});
	});

};

ordersHistory.prototype.getTextBasedOnLabelName = function (labelName) {
	util.waitForAngular();
	var elemList = element.all(by.xpath('//label[contains(text(), "' + labelName + '")]/following-sibling::p'));
	//browser.wait(EC.visibilityOf(elemList),10000);
	return elemList.getText().then(function (text) {
		logger.info("The value for " + labelName + " is : " + text);
		return text;
	});
};

ordersHistory.prototype.clickArrowIconBasedOnServiceName = function (serviceName) {
	util.waitForAngular();
	// Need static wait for data to load
	browser.sleep(5000);
	var arrowIcon = "//td[contains(text(), '" + serviceName + "')]/ancestor::button";
	browser.wait(EC.elementToBeClickable(element(by.xpath(arrowIcon)), 30000));
	element(by.xpath(arrowIcon)).click().then(function () {
		logger.info("Clicked on " + serviceName + " arrow icon");
		util.waitForAngular();
	}).catch(function(){
		element(by.xpath(arrowIcon)).click().then(function () {
			logger.info("Clicked on " + serviceName + " arrow icon again..");
		});
	});
};

ordersHistory.prototype.getTextOrderStatusBasedOnServiceName = function (serviceName) {
	var orderStatus = "//span[contains(text(), '" + serviceName + "')]/ancestor::td/following-sibling::td[3]";
	browser.wait(EC.elementToBeClickable(element(by.xpath(orderStatus)), 30000));
	return element(by.xpath(orderStatus)).getText().then(function (srvcName) {
		logger.info("Order status of " + serviceName + " is " + srvcName);
		return srvcName;
	});
};

ordersHistory.prototype.getStatusBasedOnServiceNameWithAddOn = function(serviceName) {
	var orderStatus = "//span[contains(text(), '" + serviceName + "')]/ancestor::td/following-sibling::td[4]";
	browser.wait(EC.elementToBeClickable(element(by.xpath(orderStatus)), 30000));
	return element(by.xpath(orderStatus)).getText().then(function (addOnSrvcName) {
		logger.info("Order status of " + serviceName + " is " + addOnSrvcName);
		return addOnSrvcName;
	});
}

//lnkBillOfMaterialXapth

ordersHistory.prototype.clicklnkBillOfMaterialXapth = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.lnkBillOfMaterialXapth)), 10000));
	return element.all(by.xpath(this.lnkBillOfMaterialXapth)).click().then(function () {
		logger.info("Clicked on lnkBillOfMaterialXapth");
		util.waitForAngular();
	});
};

//TotalMonthlyPricing
ordersHistory.prototype.getTotalMonthlyPricing = function () {
	browser.wait(EC.visibilityOf(element.all(by.css(this.TotalMonthlyPricing)).last()), 10000);
	return element.all(by.css(this.TotalMonthlyPricing)).last().getText().then(function (text) {
		logger.info("Total cost from orderhistory" + text);
		return text;
	});
};

ordersHistory.prototype.getOrderId = function (serviceName) {
	this.open();
	this.searchOrderById(serviceName);	
	var elemOrderId = element.all(by.xpath(this.orderIdXpath));
	return elemOrderId.first().getText().then(function(text){
		var deleteOrderNumber = text.toString().split(":")[1];
		logger.info("Delete Order Number:" + deleteOrderNumber.trim());
		return deleteOrderNumber.trim();
	})
};

//viewFailureLink
ordersHistory.prototype.ClickOnViewFailureLink = function () {
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.elementToBeClickable(element(by.css(this.viewFailureLinkCss))), 10000);
	return element(by.css(this.viewFailureLinkCss)).click().then(function () {
		logger.info("Clicked on view failure link");
		util.waitForAngular();
	});
};

//ViewLogsLink
ordersHistory.prototype.ClickOnViewLogsLink = function () {
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.elementToBeClickable(element(by.css(this.ViewLogsLinkCss))), 10000);
	return element(by.css(this.ViewLogsLinkCss)).click().then(function () {
		logger.info("Clicked on view logs link");
		util.waitForAngular();
	});
};

//checkServiceLogsTab
ordersHistory.prototype.checkServiceLogsTab = function () {
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.presenceOf(element(by.css(this.serviceLogsCss))), 5000);
	return element(by.css(this.serviceLogsCss)).isPresent().then(function (status) {
		logger.info("Service log Tab is present.."+status);
		return status;
	})
};

//checkResourceLogsTab
ordersHistory.prototype.checkResourceLogsTab = function () {
	browser.wait(EC.presenceOf(element(by.css(this.resourceLogsCss))), 5000);
	return element(by.css(this.resourceLogsCss)).isPresent().then(function (status) {
		logger.info("Resource log Tab is present.."+status);
		return status;
	})
};

//checkserviceLogTextPresent
ordersHistory.prototype.checkserviceLogTextPresent = function(){
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.presenceOf(element.all(by.css(this.serviceLogTextCss)).get(0)), 5000);
	return element(by.css(this.serviceLogTextCss)).getText().then(function(ServicelogText){
        logger.info("Service log text: "+ServicelogText);
        return ServicelogText;
    });
};

//clickonResourceLog
ordersHistory.prototype.clickonResourceLog = function(){
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.presenceOf(element(by.css(this.resourceLogsCss))), 9000);
	return element(by.css(this.resourceLogsCss)).click().then(function () {
		logger.info("Clicked on view logs link");
		util.waitForAngular();
    });
};

//checkResourceLogTextPresent
ordersHistory.prototype.checkResourceLogTextPresent = function(){
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.presenceOf(element.all(by.css(this.ResourceLogTextCss)).get(0)), 5000);
	return element(by.css(this.ResourceLogTextCss)).getText().then(function(ResourcelogText){
        logger.info("Resource log text: "+ResourcelogText);
        return ResourcelogText;
    });
};

ordersHistory.prototype.clickOrdersTableActionIconBasedOnIndex = function (index) {
	var curr = this;
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element.all(by.css(curr.orderTableActionIconCss)).get(index)), 70000).then(function () {
		return element.all(by.css(curr.orderTableActionIconCss)).get(index).click().then(function () {
			logger.info("Clicked on the Actions icon of the first row on Orders page");
			util.waitForAngular();
		});
	});
};

ordersHistory.prototype.clickBillOfMaterialsBtn = function() {	
	var elem = element(by.xpath(this.txtBillOfMaterialXPath));
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(elem), 60000);
	return elem.click().then(function(){
		logger.info("Clicked on Bill of Materials button");
		util.waitForAngular();
	});

}

ordersHistory.prototype.clickServiceDetailsLinkForTA = function () {
	util.waitForAngular();
	browser.sleep(3000);
	var elemToClick = element(by.css(this.linkServiceDetailsTACss));
	browser.wait(EC.elementToBeClickable(elemToClick), 90000).then(function () {
		logger.info("Waiting for Order history Service details link to be clickbale");
	}).catch(function (err) {
		logger.info("Timeout - Order history --> service details link");
	});
	return elemToClick.click().then(function () {
		logger.info("Clicked on Order History --> Service Details link");
		util.waitForAngular();
	});
};

ordersHistory.prototype.clickBillOfMaterialsForTA = function (index) {
	util.waitForAngular();
	browser.sleep(3000);
	var elemToClick = element(by.css(this.txtBillOfMaterialXTACss));
	browser.wait(EC.elementToBeClickable(elemToClick), 30000);
	return elemToClick.click().then(function () {
		logger.info("Clicked on Order History --> Bill of Materials for service - ");
		util.waitForAngular();
	});
};

ordersHistory.prototype.clickOnOrderTableActionsRetryEditButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.orderTableActionsRetryeditCss))), 60000).then(function () {
	});
	return element(by.css(this.orderTableActionsRetryeditCss)).click().then(function () {
		logger.info("Clicked on retry Edit option pop up message");
	})
	util.waitForAngular();
};

module.exports = ordersHistory;
