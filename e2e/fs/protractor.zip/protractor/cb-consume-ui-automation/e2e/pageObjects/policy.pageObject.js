"use strict";

var extend = require('extend');
var url = browser.params.url;
var util = require('../../helpers/util.js');
var CatalogPage = require('../pageObjects/catalog.pageObject.js');
var mcmpUIDataTemplate = require('../../testData/mcmp/mcmpUIData.json');
var appUrls = require('../../testData/appUrls.json');
var logGenerator = require("../../helpers/logGenerator.js"),
CartListPage = require('../pageObjects/cartList.pageObject.js'),
logger = logGenerator.getApplicationLogger();
var jsonUtil = require('../../helpers/jsonUtil.js');


var EC = protractor.ExpectedConditions;
var dropdownArrowCss = "#bx--dropdown-multi-parent_operations";

var defaultConfig = {
		pageUrl:                      		  url + appUrls.policyApprovalUrl,
		titlePolicyCss:                       '//div[contains(text(), "Approval Policies")]',
		buttonNewPolicyCss:                   "#addPolicy",
		
		//Approval policy page locators
		textPolicyNameFieldCss:               '#text-input-name',
		checkboxDoesNotExpireCss:             '.bx--checkbox-label',
	    startDatePickerCss:                   'input[name="duration-from"]',
		radioButtonStatusActiveCss:           '#radio-button-status_active',
		radioButtonStatusDraftCss:            '#radio-button-status_draft',
		radioButtonOptionsBasicCss:           '#radio-button-contextSwitchOptions_idBasic',
		radioButtonOptionsAdvancedCss:        '#radio-button-contextSwitchOptions_idAdvanced',
		dropdownBusinessEntityCss:      	  '#bx--dropdown-single-parent_entity',
		buttonApplyRulePolicyCss:       	  '#applyRule',
		datePickerStartCss:			    	  '#date--range-picker-from-duration',
		datePickerXpath:               		  '//div[@class="dayContainer"]/span[@class = "flatpickr-day today"]',
		buttonCreatePolicyText:       	      'Create Policy',
		textboxSearchPolicyInPolicyCss:		  '.bx--search-input',
		policyDetailIconCss:      			  '.bx--overflow-menu__icon',
		policyViewDetailButtonText:			  'Edit Policy',
		policyViewDetailtext:				'View Details',
		policyViewDetailCss:				'button.bx--overflow-menu-options__btn',
		radioButtonOptionRetiredCss: 		  'label[for="radio-button-status_retired"]',
		buttonUpdatePolicyCss:         	      '#submitPolicy',
		buttonDeletePolicyXpath:     		  "//button[contains(text(), 'Delete')]",
		buttonDeleteConfirmationPopUpCss:		  '#approval-policy-component-delete-modal_carbon-button_ok',
		successfulPolicyUpdateNotifiMsgCss:   '.bx--toast-notification__subtitle',
		textAddRuleSuccessMsgCss:             '.bx--inline-notification__text-wrapper',
        ButtonCloseNotificationCss:			  '.bx--toast-notification__close-icon',
        textGetAllPolicyTableCss:		      'span.cell--truncate',
        butttonActionIconApprovalPolicyCss:   '#carbon-deluxe-data-table-1-parent-row-1-overflow-menu-icon',
        buttonViewDetailsApprovalPolicyCss:   '#carbon-deluxe-data-table-1-parent-row-1-option-1-button',
        buttonCancelApprovalPolicyCss:        '#button-',
		
		//Add rule policy page locators:
		textAddRulePolicyNameCss:             '.bx--text-input.ng-untouched.ng-pristine.textbox-disabled',
		textProviderNameCss:                  '.bx--dropdown--selected-options--text',
		textTotalMonthlyCostCss:              '#bx--dropdown-single-parent_price',
		textBudgetStatusCss:                  '#bx--dropdown-single-parent_budget_status',
		textTechnicalApprovalCss:             '#bx--dropdown-single-parent_technical',
		textFinancialApprovalCss:             '#bx--dropdown-single-parent_financial',
		textPolicyNoDataXpath:                '//strong[contains(text(),"No Data Available")]',
		//iconAddRulePageCloseXpath:            '//carbon-icon[@name="close--outline"]'
		iconAddRulePageCloseCss:              'carbon-icon[name="close--outline"]',
		buttonAddRuleXpath:'//button[text()="Add Rule "]',
		dropdownRankingCss: '[class$="ranking"] carbon-icon',
		dropdownValueRankingCss:'[class="bx--table-cell--ranking__option"]',
		textRuleNameCss: 'table[id^="carbon-deluxe-data-table"] tr:nth-child(2) td:nth-child(2)',
		textRuleAddedMsgCss:'div.bx--inline-notification__text-wrapper',
		
		storeHeaderCss: '.bx--header__name',
		buttonLeftNavSubMenu: '.bx--side-nav__submenu',
		buttonLeftSubmenuCss: '.bx--side-nav__submenu-title',
		buttonLeftSubmenuExpandXpath: '//*[@class="bx--side-nav__submenu-title"]/parent::button',
		boxPaginationCss: 'select[id^="bx--pagination-select"]',
		optionPaginationNumberCss: 'select[id^="bx--pagination-select"] option',
		dropdownExternalCss: '#bx--dropdown-single-parent_legalexternal, #bx--dropdown-single-parent_financialexternal, #bx--dropdown-single-parent_technicalexternal',
		dropdownOptionExternalCss: '#dropdown-option_legalexternal_service_now, #dropdown-option_financialexternal_service_now, #dropdown-option_technicalexternal_service_now',
		
		textRuleNameInApprovalPolicyPageCss : "[class='cell--truncate bx--tooltip__trigger']",
		rowPolicyCss: "tbody tr.bx--table-row.bx--parent-row",
		iconRetiredPolicyXpath: "(//span[contains(text(), 'Retired')])[2]/ancestor::td/following-sibling::td[6]//carbon-icon",
		textPolicyStatusCss: "tr td:nth-child(3) span",

	};

function policy(selectorConfig) {
	if (!(this instanceof policy)) {
		return new policy(selectorConfig);
	}
	extend(this, defaultConfig);

	if (selectorConfig) {
		extend(this, selectorConfig);
	}
}

/**
 * Navigate to Policy page/URL
 */
policy.prototype.open = async function()
{
	/*await util.getUrl(this.pageUrl);
	browser.wait(EC.urlContains("/consume/policies"), 90000).then(function(){
		logger.info("Policy page opened");
	});
	browser.wait(EC.visibilityOf(element(by.css(this.storeHeaderCss))),90000);
  	browser.switchTo().frame(element(by.tagName('iframe')).getWebElement());
    util.waitForAngular();*/
	var catalogPage = new CatalogPage();
	var cartListPage = new CartListPage();
	catalogPage.checkIfUserIconIsDisplayed().then(function(status){
		if(status == false){
			var pageUrl = browser.params.url + appUrls.launchpadUrl;
			util.getUrl(pageUrl);
			cartListPage.loginFromUserSNOW(browser.params.username, browser.params.password);
		}
	});
	util.switchToDefault();
	catalogPage.clickHamburgerCatalog();
	catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
	catalogPage.checkIfleftNavStoreExpanded();
	catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkPolicyApprovals);
	util.switchToFrame();
    util.waitForAngular();		
    browser.wait(EC.elementToBeClickable(element(by.css(this.buttonNewPolicyCss))), 90000).then(function () {
		logger.info("New policy button is visible");
	}).catch(function (err) {
			browser.sleep(30000);
			logger.info("Exception occured as No Such Window");
	});
};

/*
 * Approval Policy Page functions
 */

policy.prototype.isPresentPolicyTitle = function(){
	util.waitForAngular();
	 browser.waitForAngular();
	  browser.wait(EC.visibilityOf(element(by.css(this.titlePolicyCss))),30000);
	   return element(by.css(this.titlePolicyCss)).isDisplayed().then(function(){
	  logger.info("Policy Title is displayed...");
	return true;
  });
};

policy.prototype.clickAddNewPolicyBtn = function(){
	util.waitForAngular();	
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonNewPolicyCss))),90000).then(function(){
		logger.info("Waiting for button to be enabled");
	}).catch(function(err){
		browser.sleep(15000);
		logger.info("Exception occured while clicking on Add New policy button");
	});
	 return element(by.css(this.buttonNewPolicyCss)).click().then(function(){
		 logger.info("Clicked on the create New policy Button...");
		 //util.waitForAngular();	
	 });
 };

policy.prototype.clickApplyRulePolicyBtn = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonApplyRulePolicyCss))),90000);
	 return element(by.css(this.buttonApplyRulePolicyCss)).click().then(function(){
		logger.info("Clicked on the Apply Rule policy Button...");
	});
};

policy.prototype.clickActionIconApprovalPolicyBtn = function(){
	browser.waitForAngular();
	var scrollToEle=element(by.css(".bx--table-header.bx--table-column.bx--table-sort"));
	util.scrollToWebElement(scrollToEle);
	  browser.wait(EC.elementToBeClickable(element(by.css(this.butttonActionIconApprovalPolicyCss))),30000);
	   return element(by.css(this.butttonActionIconApprovalPolicyCss)).click().then(function(){
		logger.info("Clicked on the approval policy page action icon Button...");
	});
};


policy.prototype.clickViewDetailApprovalPolicyBtn = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonViewDetailsApprovalPolicyCss))),30000);
	  return element(by.css(this.buttonViewDetailsApprovalPolicyCss)).click().then(function(){
		logger.info("Clicked on the approval policy view detail Button...");
	});
};

policy.prototype.clickCreatePolicyButton = function()
{
	//util.waitForAngular();
	browser.sleep(5000);
	 browser.wait(EC.visibilityOf(element(by.buttonText(this.buttonCreatePolicyText))), 15000);
	  element(by.buttonText(this.buttonCreatePolicyText)).click().then(function(){
        logger.info("Clicked on create policy button");
    })
};

policy.prototype.clickCancelApprovePolicyBtn = function(){
	browser.waitForAngular();
	 browser.wait(EC.elementToBeClickable(element(by.css(this.buttonCancelApprovalPolicyCss))),30000);
	  return element(by.css(this.buttonCancelApprovalPolicyCss)).click().then(function(){
		logger.info("Clicked on the cancel approve policy Button...");
	});
};

policy.prototype.searchPolicyInPolicyTextbox = function (policyName) {
    var elemToClick = element(by.css(this.textboxSearchPolicyInPolicyCss));
    browser.wait(EC.elementToBeClickable(elemToClick), 60000).then(function () {    	
		logger.info("Waiting for Policy search box to be Enabled.");
    }).catch(function(err){
		logger.info("No Such WIndow excption.");
		browser.sleep(5000);
	});

	elemToClick.clear().then(function() {
		logger.info("Cleared Policy search box");
	})
	elemToClick.sendKeys(policyName).then(function () {
		logger.info("Search for policy");
	});
	return elemToClick.sendKeys(protractor.Key.ENTER).then(function(){
		logger.info("Hit Enter");
		util.waitForAngular();
	})
};

policy.prototype.clickPolicyDetailIcon = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.policyDetailIconCss))),30000);
	  return element(by.css(this.policyDetailIconCss)).click().then(function(){
		logger.info("Clicked on the Policy detail icon...");
	});
};

policy.prototype.clickPolicyViewDetailButton = function()
{
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.cssContainingText(this.policyViewDetailCss, this.policyViewDetailButtonText))), 60000);
	return element(by.cssContainingText(this.policyViewDetailCss, this.policyViewDetailButtonText)).click().then(function(){
		logger.info("Clicked on policy view detail button");
	})
};

policy.prototype.clickRadioButtonRetiredOption = function()
{
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.radioButtonOptionRetiredCss))), 15000);
	  element(by.css(this.radioButtonOptionRetiredCss)).click().then(function(){
        logger.info("Clicked on retired radio button option");
    })
};


policy.prototype.clickUpdatePolicyBtn = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonUpdatePolicyCss))),30000);
	  return element(by.css(this.buttonUpdatePolicyCss)).click().then(function(){
		logger.info("Clicked on the update policy button...");
		util.waitForAngular();
	});
};

policy.prototype.clickButtonDeletePolicyText = function()
{
	util.waitForAngular();
	var button = element(by.xpath(this.buttonDeletePolicyXpath));
	browser.wait(EC.visibilityOf(button), 15000);
	browser.executeScript("arguments[0].scrollIntoView();", button.getWebElement());
	button.click().then(function(){
        logger.info("Clicked on delete policy button");
    })
};

policy.prototype.clickDeleteConfirmationPopUpPolicyBtn = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonDeleteConfirmationPopUpCss))),30000);
	  return element(by.css(this.buttonDeleteConfirmationPopUpCss)).click().then(function(){
		logger.info("Clicked on the delete policy confirmation button...");
	});
};

policy.prototype.getTextSuccessfulToastPolicyNotification = function() {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.successfulPolicyUpdateNotifiMsgCss))),90000);
	 return element(by.css(this.successfulPolicyUpdateNotifiMsgCss)).getText().then(function(text){
	   logger.info("Notification message text : "+text);
		return text;
	});
};

policy.prototype.getAddRuleSuccessMsgText = function() {
	util.waitForAngular();
	//browser.wait(EC.visibilityOf(element(by.css(this.textAddRuleSuccessMsgCss))),20000);
	 return element(by.css(this.textAddRuleSuccessMsgCss)).getText().then(function(text){
	   logger.info("Add Rule success message : "+text);
		return text;
	});
};

policy.prototype.selectStartDate = function()
{
	var picker = element(by.css(this.datePickerStartCss));
   // get today's date
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();
	today = mm+'/'+dd+'/'+yyyy;
	picker.click();
	element(by.xpath(this.datePickerXpath)).click().then(function(){
	logger.info("Selected Start date :: "+today);
	});
};
	
policy.prototype.getTextPolicyNameInPolicyTable = function (policyName) {
	var policyName;
	var self = this;
	return util.waitForAngular().then(function () {
		browser.wait(EC.visibilityOf(element.all(by.css(self.textRuleNameInApprovalPolicyPageCss)).first()), 30000);
		var policyArray = element.all(by.css(self.textRuleNameInApprovalPolicyPageCss));
		return policyArray.getText().then(function (policyDetailArray) {
			for (var i = 0; i < policyDetailArray.length; i++) {
				if (policyDetailArray[i] == policyName) {
					logger.info(policyName + " Found");
					policyName = policyDetailArray[i];
					return policyName;
				}
			}
		});
	});
};


policy.prototype.getTextPolicyStatusInPolicyTable = function (policyName) {
	var self = this;
	var isTextPresent = false;
	var policyStatus;
	var self = this;
	return util.waitForAngular().then(function () {
		browser.wait(EC.visibilityOf(element.all(by.css(self.textRuleNameInApprovalPolicyPageCss)).first()), 30000);
		var policyArray = element.all(by.css(self.textRuleNameInApprovalPolicyPageCss));
		return policyArray.getText().then(function (policyDetailArray) {
			for (var i = 0; i < policyDetailArray.length; i++) {
				if (policyDetailArray[i] == policyName) {
					logger.info(policyName + " Found");
					isTextPresent = true;
					logger.info("policyStatus : " + policyDetailArray[i + 1]);
					policyStatus = policyDetailArray[i + 1];
					return policyStatus;
				}
			}
		});
	}).then(function () {
		logger.info("status is : " + policyStatus);
		return policyStatus;
	});
};

policy.prototype.getTextRuleNameInApprovalPolicyPage = function (policyRule) {
	var self = this;
	var policyRuleName;
	var self = this;
	return browser.sleep(2000).then(function () {
		browser.wait(EC.visibilityOf(element(by.css(self.textRuleNameInApprovalPolicyPageCss))), 30000);
		var policyArray = element.all(by.css(self.textRuleNameInApprovalPolicyPageCss));
		return policyArray.getText().then(function (policyRuleDetailArray) {
			for (var i = 0; i < policyRuleDetailArray.length; i++) {
				if (policyRuleDetailArray[i] == policyRule) {
					logger.info(policyRule + " Found");
					policyRuleName = policyRuleDetailArray[i];
					return policyRuleName;
				}
			}
		});
	});
};
	
policy.prototype.clickNotificationCloseButton = function(){
   var NotificationClose = element(by.css(this.ButtonCloseNotificationCss));
	browser.wait(EC.visibilityOf(NotificationClose),10000);
	 logger.info(" policy close notification Button visible");
			
	   element(by.css(this.ButtonCloseNotificationCss)).click().then(function(){
		logger.info("Clicked on policy close notification Button...");
	  });	
  };
	
	/*
	 * Add rule Policy page functions
	 */

policy.prototype.getTextPolicyRuleName = function() {
	browser.waitForAngular();
	 browser.wait(EC.visibilityOf(element(by.css(this.textAddRulePolicyNameCss))),90000);
	  return element(by.css(this.textAddRulePolicyNameCss)).getText().then(function(text){
	  logger.info("Policy Rule Name  : "+text);
	return text;
 });
}

policy.prototype.getTextProviderName = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.textProviderNameCss))),90000);
	 return element(by.css(this.textProviderNameCss)).getText().then(function(text){
	  logger.info("Provider Name in ddd rule policy page  : "+text);
	 return text;
   });
}

policy.prototype.getTextTotalMonthlyCost = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.textTotalMonthlyCostCss))),90000);
	 return element(by.css(this.textTotalMonthlyCostCss)).getText().then(function(text){
	  logger.info("Total Monthly Cost in ddd rule policy page : "+text);
	return text;
  });
}

policy.prototype.getTextBudgetStatus = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.textBudgetStatusCss))),90000);
	 return element(by.css(this.textBudgetStatusCss)).getText().then(function(text){
	  logger.info("Budget Status in add rule policy page  : "+text);
	return text;
  });
}

policy.prototype.getTextTechnicalApproval = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.textTechnicalApprovalCss))),90000);
	 return element(by.css(this.textTechnicalApprovalCss)).getText().then(function(text){
	  logger.info("Technical Approval Status in add rule policy page  : "+text);
	return text;
	});
}

policy.prototype.getTextFinacialApproval = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.textFinancialApprovalCss))),90000);
	return element(by.css(this.textFinancialApprovalCss)).getText().then(function(text){
	logger.info("Financial Approval Status in add rule policy page  : "+text);
	return text;
	});
}

policy.prototype.getTextPolicyNoData = function() {
	browser.wait(EC.visibilityOf(element(by.xpath(this.textPolicyNoDataXpath))),90000);
	return element(by.xpath(this.textPolicyNoDataXpath)).getText().then(function(text){
		logger.info("Message on searching policy after deleting is  : "+text);
		return text;
	});
}

policy.prototype.clickAddRulePolicyCloseButton = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.iconAddRulePageCloseCss))),30000);
	return element(by.css(this.iconAddRulePageCloseCss)).click().then(function(){
	logger.info("Clicked on the close button...");
		});
	};

	
policy.prototype.fillPolicyDetails = function(jsonTemplate, modifiedParamMap) {
	var deferred = protractor.promise.defer();
	var requiredReturnMap = {}, expectedMap = {}, actualMap = {};
	var EC = protractor.ExpectedConditions;
	var jsonObject = JSON.parse(JSON.stringify(jsonTemplate));
	var elem = null;
	var policyParameters,jsonObjectForParameters;
	if (modifiedParamMap["EditService"] == true){
	policyParameters = Object.keys(jsonObject["Edit Parameters"]);
	jsonObjectForParameters = jsonObject["Edit Parameters"];
}else{
	policyParameters = Object.keys(jsonObject["Policy Parameters"]);
	jsonObjectForParameters = jsonObject["Policy Parameters"];
}	

Object.keys(policyParameters).forEach(function (detailSection) {
	browser.executeScript('window.scrollTo(0,0);')
	var webElements = Object.keys(jsonObjectForParameters[policyParameters[detailSection]]);
	Object.keys(webElements).forEach(function (webElement) {
		var environment = browser.params.url.includes("cb-qa-1") ? "QA 1" :  browser.params.url.includes("cb-qa-2") ? "QA 2" : browser.params.url.includes("customer1") ? "Customer 1" : browser.params.url.includes("d2ops-test") ? "D2OPS" : "QA 4";
		var webElementObject = Object.keys(jsonObjectForParameters[policyParameters[detailSection]][webElements[webElement]]);
		var elementType = Object.values(jsonObjectForParameters[policyParameters[detailSection]][webElements[webElement]][webElementObject[0]]).join("");
		var elementID = Object.values(jsonObjectForParameters[policyParameters[detailSection]][webElements[webElement]][webElementObject[1]]).join("");
		var elementValue = Object.values(jsonObjectForParameters[policyParameters[detailSection]][webElements[webElement]][webElementObject[2]][environment]).join("");
		elem = elementID;
		if (modifiedParamMap != undefined) {
			if (Object.keys(modifiedParamMap).includes(webElements[webElement]))
				elementValue = modifiedParamMap[webElements[webElement]];
		}
		if (!elementValue == "") {
			if (elementType == "Dropdown") {		
			var dropdown = element(by.css("[id=\"" + elementID + "\"]"));
			//browser.ignoreSynchronization = false;
			browser.sleep(1000);
			util.waitForAngular();	
			browser.wait(EC.elementToBeClickable(dropdown), 60000).then(function(){
				util.waitForAngular();	
					dropdown.isEnabled().then(function (enabled) {
						if(enabled){
							browser.executeScript("arguments[0].scrollIntoView();", dropdown.getWebElement());
							dropdown.click().then(function(){
								browser.sleep(3000);
								var dropDownValuesArray = element.all(by.xpath("//*[@id='" + elementID + "']//carbon-dropdown-option//li"));
								dropDownValuesArray.getText().then(function (textArray) {
									var isDropDownValuePresent = false;
									for (var i = 0; i < textArray.length; i++) {
										if (textArray[i] == elementValue) {
											var element= dropDownValuesArray.get(i);
											browser.wait(EC.elementToBeClickable(element), 140000);
											element.click().then(function () {
												logger.info("Selected " + elementValue + " from " + webElements[webElement] + " dropdown");
												expectedMap[webElements[webElement].trim()] = elementValue.trim();
												deferred.fulfill(expectedMap);
											});
											 isDropDownValuePresent = true;
										}
									  }
									if (!isDropDownValuePresent) {
										dropDownValuesArray.get(0).getText().then(function (text) {
										dropDownValuesArray.get(0).click().then(function () {
										logger.info("Selected " + text + " from " + webElements[webElement] + " dropdown");
										expectedMap[webElements[webElement].trim()] = text.trim();
										deferred.fulfill(expectedMap);
											});
										});
									}
								});
							});
						}
					});                      

				});                    
			}
			if (elementType == "RadioButton") {
				var radioButtion = element(by.xpath(elementID));
				util.waitForAngular();	
				browser.wait(EC.presenceOf(radioButtion), 60000);
				radioButtion.click().then(function () {
				logger.info("Selected " + elementValue + " radio button for " + webElements[webElement]);
				expectedMap[webElements[webElement].trim()] = elementValue.trim();
				deferred.fulfill(expectedMap);
				})
			}
			if (elementType == "Textbox") {
				var textbox = element(by.css("[id^=\"" + elementID + "\"]"));
				util.waitForAngular();	
				browser.wait(EC.presenceOf(textbox), 60000);
				textbox.clear().then(function () {
				logger.info("Cleared " + webElements[webElement] + " textbox");
				var ctrlA = protractor.Key.chord(protractor.Key.CONTROL, "a");
				textbox.sendKeys(ctrlA);
				});
				textbox.sendKeys(elementValue).then(function () {
				logger.info("Entered " + elementValue + " in " + webElements[webElement] + " textbox");
				expectedMap[webElements[webElement].trim()] = elementValue.trim();
				deferred.fulfill(expectedMap);
				util.waitForAngular();
				})
			}
			if (elementType == "MultiselectDropdownOpgrp") {
				//var multiElementValue = jsonObject["Policy Parameters"][policyParameters[detailSection]][webElements[webElement]][webElementObject[2]][environment];
				//element value is already retrived, no need to retrive again since it impacts modified param map
				//var multiElementValue = jsonObject["Policy Parameters"][policyParameters[detailSection]][webElements[webElement]][webElementObject[2]][environment];
				var multiElementValue = elementValue;
				var n = multiElementValue.toString().search(",");
				var multiElementValueArray;
									
				if(n != -1){
					multiElementValueArray = multiElementValue.toString().split(",");
				}else{
					multiElementValueArray = [multiElementValue];
				}
				var checkBoxDropDown = element(by.css("[id=\"" + elementID + "\"]"));
				util.waitForAngular();	
				browser.sleep(5000);
				browser.wait(EC.elementToBeClickable(checkBoxDropDown), 60000);
				checkBoxDropDown.click().then(function () {
				logger.info("Clicked on " + webElements[webElement] + " multi-select dropdown");
				});
				var dropDownValues = element.all(by.css("[id^=dropdown-option__]"));
				browser.wait(EC.presenceOf(dropDownValues), 60000);
				dropDownValues.getText().then(function (dropDownValuesArray) {
					logger.info("Dropdown Values: " + dropDownValuesArray);
					for (var i = 0; i < multiElementValueArray.length; i++) {
						for (var j = 0; j < dropDownValuesArray.length; j++) {
							if (multiElementValueArray[i].toString().trim() == dropDownValuesArray[j].toString().trim() && dropDownValuesArray[j-1].toString().trim() != dropDownValuesArray[j].toString().trim()) {
								element.all(by.css("[id^=bx--dropdown-item-]")).get(j).click();
								logger.info("Clicked on checkbox " + multiElementValueArray[i] + " from " + webElements[webElement] + " multi-select dropdown");
								expectedMap[webElements[webElement].trim()] = multiElementValueArray.toString().trim();
								deferred.fulfill(expectedMap);
							}
						}
					}
					element(by.css(dropdownArrowCss)).click();
				});
			}
			if (elementType == "MultiselectDropdown") {
				//var multiElementValue = jsonObject["Policy Parameters"][policyParameters[detailSection]][webElements[webElement]][webElementObject[2]][environment];
				//element value is already retrived, no need to retrive again since it impacts modified param map
				//var multiElementValue = jsonObject["Policy Parameters"][policyParameters[detailSection]][webElements[webElement]][webElementObject[2]][environment];
				var multiElementValue = elementValue;
				var n = multiElementValue.toString().search(",");
				var multiElementValueArray;
									
				if(n != -1){
					multiElementValueArray = multiElementValue.toString().split(",");
				}else{
					multiElementValueArray = [multiElementValue];
				}
				var checkBoxDropDown = element(by.css("[id=\"" + elementID + "\"]"));
				util.waitForAngular();	
				browser.sleep(5000);
				browser.wait(EC.elementToBeClickable(checkBoxDropDown), 60000);
				checkBoxDropDown.click().then(function () {
				logger.info("Clicked on " + webElements[webElement] + " multi-select dropdown");
				});
				var dropDownValues = element.all(by.css("[id^=dropdown-option__]"));
				browser.wait(EC.presenceOf(dropDownValues), 60000);
				dropDownValues.getText().then(function (dropDownValuesArray) {
					logger.info("Dropdown Values: " + dropDownValuesArray);
					for (var i = 0; i < multiElementValueArray.length; i++) {
						for (var j = 0; j < dropDownValuesArray.length; j++) {
							if (multiElementValueArray[i].toString().trim() == dropDownValuesArray[j].toString().trim()) {
								element.all(by.css("[id^=dropdown-option__]")).get(j).click();
								logger.info("Clicked on checkbox " + multiElementValueArray[i] + " from " + webElements[webElement] + " multi-select dropdown");
								expectedMap[webElements[webElement].trim()] = multiElementValueArray.toString().trim();
								deferred.fulfill(expectedMap);
							}
						}
					}
					checkBoxDropDown.click();
				});
			}
			if(elementType == "DropdownSearch"){
				var dropdownbox = element(by.xpath("//*[@id='"+elementID + "' or @id = '" + elementID.toLowerCase() +"']/div"));
				util.waitForAngular();	
	            browser.sleep(5000);
				browser.wait(EC.presenceOf(dropdownbox), 10000).then(function(){
					dropdownbox.click().then(function(){
						browser.sleep(1000);
						util.waitForAngular();
						var dropDownValuesArray = element.all(by.xpath("//*[@id='"+elementID + "' or @id = '" + elementID.toLowerCase() + "']//ul//li"));
						dropDownValuesArray.getText().then(function(textArray){
								var isDropDownValuePresent = false;
								for (var i=0;i<textArray.length;i++){
									if (textArray[i] == elementValue){
										dropDownValuesArray.get(i).click().then(function(){
										logger.info("Selected "+elementValue+" from "+webElements[webElement]+" dropdown");
										expectedMap[webElements[webElement].trim()] = elementValue.trim();
				                    	deferred.fulfill(expectedMap);
					                    });
					                    isDropDownValuePresent =true;
					                }
					            }
					            if(!isDropDownValuePresent){
					            	dropDownValuesArray.get(0).getText().then(function(text){
					            		dropDownValuesArray.get(0).click().then(function(){
				            			logger.info("Selected "+text+" from "+webElements[webElement]+" dropdown");
				            			expectedMap[webElements[webElement].trim()] = text.trim();
				            			deferred.fulfill(expectedMap);
					            		})
					            	})
					            }
					        });
					});
				});
				
            }
			if(elementType == "Button"){
				elementValue = " ";
				var button = element(by.css(elementID));
				util.waitForAngular();
				browser.executeScript("arguments[0].scrollIntoView();", button.getWebElement());
				browser.wait(EC.elementToBeClickable(button), 30000).then(function(){
				button.click().then(function(){
				logger.info("Clicked on the Button "+ webElements[webElement]);
					});
				});
			}
			if(elementType == "Checkbox"){
				elementValue = " ";
				var checkBox = element(by.xpath(elementID));
				util.waitForAngular();	
				browser.wait(EC.elementToBeClickable(checkBox), 30000).then(function(){
				checkBox.click().then(function(){
				logger.info("Clicked on the checkbox "+ webElements[webElement]);
					});
				});
			}
		}else
		{
		 browser.sleep(5000);	
	}
	});

	util.waitForAngular();
});

requiredReturnMap["Actual"] = actualMap;
requiredReturnMap["Expected"] = expectedMap;
	deferred.fulfill(requiredReturnMap);
	return deferred.promise;

};

policy.prototype.clickAddNewPolicyRuleBtn = function(){
	var elem = element.all(by.xpath(this.buttonAddRuleXpath));
	browser.wait(EC.elementToBeClickable(elem.last()),30000);
	 return elem.last().click().then(function(){
		 logger.info("Clicked on the Add New policy Rule button...");
		 util.waitForAngular();
	 });
 };

 policy.prototype.clickRankingDropdown = function(){
	var elem = element.all(by.css(this.dropdownRankingCss));
	browser.wait(EC.elementToBeClickable(elem.get(0)),30000);
	 return elem.get(0).click().then(function(){
		 logger.info("Clicked on Ranking Dropdown...");
		 util.waitForAngular();
		 element(by.css(defaultConfig.dropdownValueRankingCss)).click().then(function(){
			 logger.info("Ranking changed to 2nd rule");
		 });
	 });
 };

 policy.prototype.getRuleNameFromRankingTable = function(){
	var elem = element(by.css(this.textRuleNameCss));
	browser.wait(EC.elementToBeClickable(elem),30000);
	 return elem.getText().then(function(text){
		 logger.info("Rule name is : " + text);
		 return text;		 
	 });
 };

policy.prototype.getSuccessMsgForRule = function(){
	var elem = element(by.css(this.textRuleAddedMsgCss));
	browser.wait(EC.presenceOf(elem),30000);
	 return elem.getText().then(function(text){
		 logger.info("Success message for rule creation : " + text);
		 return text;		 
	 });
 };
 
policy.prototype.clickPaginationBox = function(){
	var paginationBox = element(by.css(this.boxPaginationCss));
	browser.executeScript("arguments[0].scrollIntoView();", paginationBox.getWebElement());
	browser.wait(EC.elementToBeClickable(paginationBox),30000);
	elem.click().then(function(){
		 logger.info("Clicked on Policy pagination box");
		 util.waitForAngular();
	 });
};

policy.prototype.selectPaginationNumber = function(num){
	var paginationNumber = element.all(by.css(this.optionPaginationNumberCss));
	browser.wait(EC.elementToBeClickable(paginationNumber),30000);
	paginationNumber.getText().then(function(values){
		for(i=0; i<values.length; i++) {
			if(values[i]==num) {
				paginationNumber.get(i).click().then(function() {
					logger.info("Selected " + num + " from pagination box");
					util.waitForAngular();
				})
			 }			
		 }		
	});
};

policy.prototype.selectExternalApprovalDropdownSNOW = function(){
	var externalApproval = element(by.css(this.dropdownExternalCss));
	var exterApprovalValue = element(by.css(this.dropdownOptionExternalCss));
	browser.wait(EC.elementToBeClickable(externalApproval),90000);
	externalApproval.click().then(function() {
		logger.info("Clicked on external dropdown");
		browser.wait(EC.elementToBeClickable(exterApprovalValue),90000);
		exterApprovalValue.click().then(function() {
			logger.info("Selected service_now from external dropdown");
		})
	})
};

policy.prototype.clickRetiredPolicyIcon = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.iconRetiredPolicyXpath))),90000);
	element(by.xpath(this.iconRetiredPolicyXpath)).click().then(function(){
		logger.info("Clicked on Retired policy icon");
	})
};

policy.prototype.clickPolicyViewDetailText = function()
{
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.cssContainingText(this.policyViewDetailCss, this.policyViewDetailtext))), 60000);
	return element(by.cssContainingText(this.policyViewDetailCss, this.policyViewDetailtext)).click().then(function(){
		logger.info("Clicked on policy view detail button");
	})
};

policy.prototype.deletePoliciesIfExist = function(){
	var self = this;
	return element.all(by.css(self.rowPolicyCss)).count().then(function(rowCount){
		if(rowCount > 0){
			for(var i=0; i<rowCount; i++){
				browser.wait(EC.visibilityOf(element(by.css(self.textPolicyStatusCss))),90000);
				return element.all(by.css(self.textPolicyStatusCss)).getText().then(function(status){
					for(var j=0; j<status.length; j++) {
						if(status[j].includes("Active")) {
							self.clickPolicyDetailIcon();
							self.clickPolicyViewDetailButton();
							self.clickRadioButtonRetiredOption();
							browser.sleep(2000);
							self.clickUpdatePolicyBtn();
							browser.sleep(5000);
						}
						else {
							self.clickPolicyDetailIcon();
							self.clickButtonDeletePolicyText();
							self.clickDeleteConfirmationPopUpPolicyBtn();
							util.waitForAngular();
							browser.sleep(5000);
							self.deletePoliciesIfExist();
						}
					}
					
				})
				
			}
		}
		else {
			logger.info("No Policies found");
		}
	})
};


module.exports = policy;
