"use strict";

var extend = require('extend');
var url = browser.params.url;
var util = require('../../helpers/util.js');
var CatalogPage = require('../pageObjects/catalog.pageObject.js');
var mcmpUIDataTemplate = require('../../testData/mcmp/mcmpUIData.json');
var logGenerator = require("../../helpers/logGenerator.js"),
logger = logGenerator.getApplicationLogger();
var jsonUtil = require('../../helpers/jsonUtil.js');
var CartListPage = require('../pageObjects/cartList.pageObject.js');

var EC = protractor.ExpectedConditions;
//var tempFinancialApproveCheckbox - Financial Approval ID defect on Customer1 is fixed;

var defaultConfig = {
    pageUrl:                      		url + '/consume/orders/approver-orders',
    ordersLinkTextXpath:        		'//a[contains(text(), "ALL ORDERS")]',
    pendingOrdersTabUnderOrdersLinkText: 'Pending approval',
    allOrdersTabUnderOrdersLinkText:	'All orders',
    orderSearchTextBoxCss:	  			'#search__input-orders-search',
    // Locators for Order Details Section
    orderTableOrderIDColumnCss:    		'.order-items a',
    orderTableCreatedDateColumnCss:    	'.bx--table-body tr td:nth-child(2) span',
    //orderTableUpdatedDateColumnCss:   '[id^="Updated_Date_"]',
    orderTablePlacedByColumnCss:    	'.bx--table-body tr td:nth-child(5) span',
    orderTableOrderTypeColumnCss:    	'.bx--table-body tr td:nth-child(4) span',
    orderTableOrderStatusColumnCss:    	'.bx--table-body tr td:nth-child(3) span',
    orderTableAmountColumnCss:   	 	'.bx--table-body tr td:nth-child(1) span',
    orderTableActionIconCss:   	 		'.bx--overflow-menu__icon',
    //orderTableViewDetailsButtonCss:   '.bx--overflow-menu-options__btn',
    //orderViewDetailsButtonCss: 		'#-icon svg',
	buttonTextViewDetails: 			'View Details',
	submittedByUserDeatilsClassName: "order-updates__tile",
	estimatedCostOnOrdersPageCss: '.bx--tooltip-trigger.bx--tooltip-text',
	textOrderStatusCss:".bx--table-body tr td:nth-child(3) span",
	//Service Details Section
	serviceNameServiceDetailsCss:		 '#service-instance-name',
	serviceOfferingNameServiceDetailsCss:'#service-offering-name',
	providerNameServiceDetailsCss:		 '#provider.property-value',
	priceServiceDetailsCss:				 '#price.property-value',
	feesServiceDetailsCss:			     '#fees.property-note',
	//viewDetailsServiceDetailsLinkText:	 'View Details',
	spinnerCss: '.bx--loading__svg',
	orderHeaderCss:              ".order-header",

	//Order Updates Section
  orderStatusOrderUpdateSection:		 '.statusWithoutSubmitter span',
  viewUpdatesServiceDetailsLinkText:	 'View Updates',
	closeServiceDetailsSliderCss:		 '.bx--slide-over-panel-header svg',
	viewOrderDetailsLinkID: 			'view-updates-link',
	orderUpdateTabId: 'button[data-tab-id="order_updates"]',
	closeButtonOfOrderDetailsSlidderCss :'.bx--slide-over-panel--close',
	expandApprovalTileCss : '.bx--tile-content__above-the-fold',
	approvalDetailsTileCss:'.bx--tile-content__below-the-fold',
	approvalStatusClassName: 'approval-card__status',
	orderCompletedTextCss: '.order-updates__tile',

    //*********LOCATORS FOR ORDER DETAILS SECTION*************
	orderNumberOrderDetailsPageCss :	  				'#orderName',
	//orderServiceNameOrderDetailsPageXpath : 				'//label[contains(text(),"Service Instance Prefix")]/following-sibling::p',
	orderProviderNameOrderDetailsPageXpath: 				'//label[text()="Provider"]/following-sibling::p',
	orderExternalcontextCustomerXpath:						'//*[contains(text(), "Customer")]/following-sibling::div',
    	orderServiceNameOrderDetailsPageXpath : 			'//*[@id="carbon-deluxe-data-table-tableOrderServiceDetails"]//td[1]//span',
	orderCreatedDataOrderDetailsPageCss : 				'#createdDate',
    orderUpdatedDateOrderDetailsPageCss : 				'#updatedDate',
	orderStatusOrderDetailsPageCss      :		  		'.first-column.status.status-red',
	orderHistoryPageActionIconCss		:				'#carbon-deluxe-data-table-fulfill_carbon-data-table-deluxe-parent-row-1-overflow-menu-icon',
	orderServiceTypeOrderDetailsPageCss	:				'#serviceType',
	orderTeamOrderDetailsPageCss        :	  			'#context-app_team',
 //   orderTypeOrderDetailsPageCss		:		  		'#type',
    orderTypeOrderDetailsPageCss		:		  		'#carbon-deluxe-data-table-orderDetailsTable > tbody > tr > td:nth-child(4)',
    orderTotalCostOrderDetailsPageCss   :		  		'#orderAmount',
    orderSubmittedByOrderDetailsPageCss :		  		'.bx--table-body tr td:nth-child(5) span',
    viewOrderDetailsTextCss             :         		'.bx--slide-over-panel-action',
	approveButtonOrderDetailsPageCss    :         	'#order_approve_button',
	approverCheckBoxCss	: 'input[type="checkbox"].bx--checkbox',
	closeApproveModalCss : '#close-btn_approve-modal',
    //approveButtonText :									'APPROVE',
	denyButtonOrderDetailsPageCss		:		  		'#order_deny_button',
	//denyButtonText:										'DENY',
	cancelButtonOrderDetailsPageCss     : 		  		'#button-order_details_button_cancel',
	retryButtonOrderDetailsPageCss		:				'#button-order_details_button_retry',
	failureReasonOrderDetailsPageCss	:		  		"#failure-reason",
	//serviceConfigurationsTabOrderDetailsPageCss:		'#service_configurations',
	//billOfMaterialsTabOrderDetailsPageCss:			'#bill_of_materials',
    orderRejectionOrderDetailsPageId: 					'reject-reason',
	serviceDetailsButtonServiceDetailsBtnText:			'Service Details',
	estimatedCostsButtonServiceDetailsBtnText:			'Bill of Materials',
	orderUpdatesButtonServiceDetailsBtnText:			'Order Updates',
	textApprovalErrorCss:                               '#approve-fail-body',

   //*** Service Configuration  and Bill of Materials for VRA SingleVM CentOS
	orderCPUServiceConfigurationTabCss  	:			'#cpu_value',
	orderMemoryServiceConfigurationTabCss	:			'#memorymb_value',
	orderStorageServiceConfigurationTabCss	:			'#storagegb_value',
	orderTotalCostBillofMaterialsTabCss		:			'.total-cost-value',

    quantityFromBOMCss:                                 '#quantity svg',
    clickMoreLinkXpath: '                               //a[contains(text(),"More")]',

    tableClassCSS:			                            '.review-order_bom-table',
    bomTotalCss:                                        '.total-quantity',

  //*********** LOCATORS FOR ORDER APPROVAL POPUP***********
    OrderApprovalModalApproveButtonCss:                  '#order_details_approval_approve',
	OrderApprovalModalCancelButtonCss:					 '#order_details_approval_cancel',
	OrderCancelPopupYesButtonCss:						 '#order_cancel_yes',
    OrderCancelPopupOkButtonCss:						 '#order_cancel_ok',
    // OrderApprovalModalTitleCss:						 'h2',
    OrderApprovalModalTitleXpath:						 '//h2[contains(text(),"Order Approval Flow")]',
    //OrderApprovalModalTechincalApprovalCheckboxCss:  	 '#checkbox-technical',
    OrderApprovalModalTechincalApprovalCheckboxCss:  	 'label[for="technical_input"]',
 	//OrderApprovalModalFinancialApprovalCheckboxCss:  	 '#checkbox-financial',
    OrderApprovalModalFinancialApprovalCheckboxCss:  	 'label[for="financial_input"]',
    OrderApprovalModalLegalApprovalCheckboxCss:  	     'label[for="legal_input"]',
    OrderApprovalModalCloseXCss :      					 '#close-btn_approve-modal',
    OrderApprovalModalErrorMessageCss :	  				 '#order_details_approval_error',
    OrderApprovalModalSuccessMessageCss :				 '#order_details_approval_success',
    OrderApprovalModalOkButtonCss:						 '#order_details_approval_ok',

	//****************** LOCATORS FOR ADMN/BUYER ORDER PAGE  *******
	pageBuyerOrdersUrl: 					        url + '/consume/orders/my-orders',

    orderHistoryLinkCss:                            '#myordersLinkId',
	//Be careful, this "Search" is from ORDER HISTORY (different from ALL ORDERS)
    orderBuyerSearchTextBoxCss:  		  	        '[id^="search__input-orders-search"]',
	//orderOrderDetailsLinkCss:			        	'//a[contains(.,"Order Details")]',
    orderOrderDetailsLinkCss:			        	'#order-details-link',
	orderServiceDetailsTabCss:			        	'#service_details',
    orderEstimatedCostTabCss:			        	'#estimated_costs',
	orderOrderUpdateTabCss:			        		'#order_updates',
    orderBuyerServiceDetailsCloseButtonCss:         '#button-',
	ordersTotalCss:					        		'#ordersCounterValue',

    orderExpandOrderCss:							'.bx--accordion__arrow',
    orderServiceFulfillmentMsgCss:					'.bx--inline-notification__subtitle span',
    orderOrderHistoryDetailsCss:                    '#-icon',
	orderRetryServiceButtonCss:						'[id^="carbon-deluxe-data-table-fulfill_carbon-data-table-deluxe-parent-row-1-option-1-button"]',
	orderCancelServiceButtonCss:					'[id^="cancel-service-"]',
	orderRetryModalOkayId: 							'button-order_retry_ok',


	//**********   Filter by Period  ***************
    selectAllOrdersStatusCss:						'#dropdown-option_ordercreatedtime_AllOrders',
	orderFirstOrderFromTableCss:     	        	'#order-number',
    ordersCounterValueCss:                     		'#bx--dropdown-single-parent_ordercreatedtime',
    selectOptionLastDayCss:  			        	'#dropdown-option_ordercreatedtime_LastDay',
    selectOptionLastWeekCss:  			        	'#dropdown-option_ordercreatedtime_LastWeek',
    selectOptionLastMonthCss: 	                	'#dropdown-option_ordercreatedtime_LastMonth',
    selectOptionLastThreeMonthsCss:  		    	'#dropdown-option_ordercreatedtime_Last3Months',
    selectOptionLastSixMonthsCss:  					'#dropdown-option_ordercreatedtime_Last6Months',
    selectOptionLastYearCss:  			        	'#dropdown-option_ordercreatedtime_LastYear',

    //*********   Filter by Order Status ******************
    selectAllOrdersFromOrderStatusCss:				'#dropdown-option_orderstatus_AllOrders',
	selectApprovalInProgressStatusCss:	        	'#dropdown-option_orderstatus_ApprovalInProgress',
    selectOrderStatusCss:							'#bx--dropdown-single-parent_orderstatus',
	selectSubmittedOrderStatusCss:					'#dropdown-option_orderstatus_Submitted',
    selectProvisioningInProgressOrderStatusCss:     '#dropdown-option_orderstatus_ProvisioninginProgress',
	selectRejectedOrderStatusCss:					'#dropdown-option_orderstatus_Rejected',



    //************************  LOCATORS FOR ADMN/APPROVER ORDER PAGE  *****************

    pageApproverOrdersUrl: 					        url + '/orders/approver-orders',

    orderApproverPendingOrderTabCss:                '#pending_approval_tab',
    orderApproverAllOrdersTabCss:                   '#all_orders_tab',
    orderApproverResetButtonCss:                    '#button-reset',

    orderApproverFilterByDropBoxCss:                '#bx--dropdown-single-parent_order-type',
    orderApproverFilterByNewestFirstCss:            '#dropdown-option_order-type_NewestFirst',
    orderApproverFilterByOldestFirstCss:            '#dropdown-option_order-type_OldestFirst',

	orderApproverViewDetailsLinkCss:				'#view-details-link',
	orderApproverViewUpdatesLinkCss:				'#view-updates-link',

	orderApproverDenyButtonCss:						'#order_deny_button',
	orderApproverApproveButtonCss:					'#order_approve_button',

    orderApproverFilterByTodayCss:                   '#today',
    orderApproverFilterByWeekCss:                    '#week',
    orderApproverFilterByMonthCss:                   '#month',
    orderApproverFilterByYearCss:                    '#year',

    orderApproverErrorApprovalCss:                   '#order_details_approval_error',



    //Estimated Costs from Order Details for orders
    orderEstimatedCostsQuantityCss:                  '#quantity',
    orderEstimatedCostsItemCss:                      '#description',
    orderEstimatedCostsRecurringValueCss:            '#recurring-charge-value',
    orderEstimatedCostsRecurringFrequencyValueCss:   '#recurring-charge-frequency-value',
    orderEstimatedCostsUsageChargeValueCss:          '#usage-charge-value',
    orderEstimatedCostsUsageUOMValueCss:             '#usage-charge-uom-value',
    orderEstimatedCostsUsageUOMCodeCss:              '#usage-charge-uom-code',


    orderOrderUpdatesApprovalInProgressCss:          '#approvalinprogress',
    orderOrderUpdatesSubmittedCss:                   '#submitted',
    lnkMoreXpath:					'//*[text()="More"]',
    tblServiceNameXpath:				'//*[@id="tableOrderServiceDetails"]/div//tr//td[1]',
    //tblViewDetailsXpath:				'//carbon-icon[contains(@id,"carbon-data-table-simple-0-parent-row")]',
    tblViewDetailsXpath:				'//carbon-icon[contains(@id,"carbon-deluxe-data-table-tableOrderServiceDetails")]',

	//***********LOCATORS FOR ORDER DENIAL POPUP***********
    OrderDenyModalYesButtonCss:                     '#order_details_denial_yes',
    OrderDenyModalCancelButtonCss:					'#order_details_denial_cancel',
    OrderDenyModalTitleXpath:						'//h2[contains(text(),"Order Denial Flow")]',
    //OrderDenyModalTechincalApprovalCheckboxCss:  	'#checkbox-denial-technical',
    OrderDenyModalTechincalApprovalCheckboxCss:  	'label[for="denial-technical_input"]',	
    OrderDenyModalFinancialApprovalCheckboxCss:  	'#denial-financial_inputt ~ label',
    OrderDenyModalCommentsTextAreaCss:				'#text-areadenial-reason',
    OrderDenyModalCommentsValueRequiredCss:			'.bx--form-requirement',
    OrderDenyModalCloseXCss :      					'#close-btn_denial-modal',
    OrderDenyModalErrorMessageCss :	  				'#order_details_denial_error',
    OrderDenyModalSuccessMessageCss :				'.bx--inline-notification__details',
    OrderDenyModalOkButtonCss:						'#order_details_deny_approve',
	OrderDenyModalCloseErrorEnterRejectionReasonCss:'[id^=order_details_denial_error] > button',
	OrderDenyModalOkayButtonCss:					'#order_details_deny_ok',
	OrderDenyModalCloseButtonCss:                    "#close-btn_deny-modal",

	//*********** LOCATORS FOR RETRY POPUP
	OrderRetryModalYesButtonCss:					'#button-order_retry_yes',
    OrderRetryModalNoButtonCss:						'#button-order_retry_no',
	OrderRetryModalMessageCss:						'#cancel_message',
	orderNotFoundTextXpath:						'//p[@class = "bx--inline-notification__subtitle"]/span',
	orderTotalCostXpath:						'//*[@id="total_cost_value"]',
	bomTotalCostCss: 							'div.total-cost-value',

	//******** LOCATORS FOR BUDGET DETAILS ************
	textBudgetNameAllOrdersCss: ".stepId",
	budgetAmmountXpath: '//*[@id="currentBdgAmt-"]',
	budgetAmountCss:'span[id*="currentBdgAmt"]',
	availableBudgetCss: 'span[id*="currentBdgAvailable"],span[id*="availableBdgt"]',
	CommittedAmmountCss: 'span[id*="currentCmtedAmt"],span[id*="cuxrrentCmtedAmt"]',				
	spendAmmountCss: 'span[id*="currentSpendAmt"]',		
	estimatedAmmountforOrderCss:'span[id*="currentEstAmt"]',		
	awaitingApprovalOrderAmountCss: 'span[id*="awaitappr"]',
	budgetDropdown: '//*[@id="bx--dropdown-single-parent_budgets"]',
	budgetDropdownId: "//*[@id='bx--dropdown-single-parent_budget-approval-' or @id='bx--dropdown-single-parent_budgets']",
	budgetDropdownListXpath:"//*[@id='bx--dropdown-single-parent_budget-approval-' or @id='bx--dropdown-single-parent_budgets']//carbon-dropdown-option//li",
	submitButtonBudgetXpath: '//button[@id="order_budget_select"]',
	budgetID: 'currentBdgAmt',
	txtTrackingNumberCss: 'input[id="externalApprovalRequestNumber"]',
	descriptionXpath : '//*[@id="description"]',
	totalMonthlyChargeXpath : '//*[@id="non-one-time-charge"]',
	textImiAddOnCss : 'carbon-tag',
	btnImiAddOnCss: '[data-tab-id="add-on_details_"]',
	txtDescriptionInBomTblCss:'td#description',
	txtCostInBomTblCss:'td#non-one-time-charge',
	storeHeaderCss: '.bx--header__name',
	btnBomImiCss:'[data-tab-id="bill_of_materials"]',
	buttonLeftNavSubMenu: '.bx--side-nav__submenu',
	buttonCloseServiceDetailSliderCss: '[class="is-active"] button.bx--slide-over-panel--close',
	buttonLeftSubmenuCss: '.bx--side-nav__submenu-title',
	buttonLeftSubmenuExpandXpath: '//*[@class="bx--side-nav__submenu-title"]/parent::button',
	txtDescriptionInBomTblXpath : '//*[@class="bx--side-nav__item"]/span',
	ApprovalSucessMsgXpath:'//span[contains(text(), "Approval Processed")]'
};

//******** Order status *************
global.failedStatus = "Failed";
global.approvalInProgressStatus = 'Approval In Progress';
global.provisioningInProgressStatus = 'Provisioning in Progress';






function orders(selectorConfig) {
    if (!(this instanceof orders)) {
        return new orders(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}



orders.prototype.clickQuantity = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.quantityFromBOMCss))),5000);
    return element(by.css(this.quantityFromBOMCss)).click();
};

orders.prototype.clickMoreOrLessLink = function(){
    browser.wait(EC.elementToBeClickable(element(by.xpath(this.clickMoreLinkXpath))),5000);
    return element(by.xpath(this.clickMoreLinkXpath)).click();

};
orders.prototype.open = function()
{
	//browser.ignoreSynchronization = true;
	  /*await util.getUrl(this.pageUrl);
	  browser.wait(EC.urlContains("/consume/orders/approver-orders"), 90000).then( function(){
		  logger.info("Navigated to orders page");
	  });
	    browser.wait(EC.visibilityOf(element(by.css(this.storeHeaderCss))),900000);
	  	browser.switchTo().frame(element(by.tagName('iframe')).getWebElement());
	  //	browser.ignoreSynchronization = false;
	    util.waitForAngular();*/

	var catalogPage = new CatalogPage();
	util.switchToDefault();
	//browser.ignoreSynchronization = true;
	browser.waitForAngularEnabled(false);
	catalogPage.clickHamburgerCatalog();
	catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
	catalogPage.checkIfleftNavStoreExpanded();
	catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkApproveOrders);
	browser.sleep(2000);
	util.switchToFrame();
	util.waitForAngular();	
	//browser.ignoreSynchronization = false;
	//Close any pop up window if already opened
	this.clickServiceDetailSliderCloseButton();
};

orders.prototype.clickPendingApprovalUnderOrdersSection = function(){
	//util.waitForAngular();
	browser.sleep(5000);
	browser.wait(EC.elementToBeClickable(element(by.linkText(this.pendingOrdersTabUnderOrdersLinkText))), 90000);
	element(by.linkText(this.pendingOrdersTabUnderOrdersLinkText)).click().then(function(){
		logger.info("Clicked on Pending approval Tab...");
	})
}

orders.prototype.clickAllOrdersUnderOrdersSection = function(){
// 	util.waitForAngularOnOrdersPage();
// 	util.waitForCircleStrokeToDisappear();
 	browser.sleep(5000);
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.orderHeaderCss))), 90000);
	browser.wait(EC.elementToBeClickable(element(by.linkText(this.allOrdersTabUnderOrdersLinkText))), 90000);
	element(by.linkText(this.allOrdersTabUnderOrdersLinkText)).click().then(function(){
		logger.info("Clicked on All Orders Tab...");
	})
}

orders.prototype.isPresentOrderHistoryLink = function(){
    return element(by.css(this.orderHistoryLinkCss)).isPresent();
};

orders.prototype.isPresentOrdersLink = function(){
    return element(by.xpath(this.ordersLinkTextXpath)).isPresent();
};

orders.prototype.isPresentFinancialApprovalCheckbox = function(){
    return element(by.css(this.OrderApprovalModalFinancialApprovalCheckboxCss)).isPresent();
};

orders.prototype.clickordersLink = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.ordersLinkTextXpath))),5000);
    return element(by.xpath(this.ordersLinkTextXpath)).click();
};

orders.prototype.openNew = function()
{
   browser.get(this.pageBuyerOrdersUrl);
};

//Click Cancel on Order detail page.
orders.prototype.clickCancelButtonOrdersDetailsPage = function(){
    browser.waitForAngular();
    element(by.css(this.cancelButtonOrderDetailsPageCss)).click();
    util.waitForAngular();
};

//Click Retry on Order detail page.
orders.prototype.clickRetryButtonOrdersDetailsPage = function(){
    browser.waitForAngular();
    //expect(element(by.css(this.viewOrderDetailsTextCss)).getText()).toMatch('View order details');
    //expect(element(by.css(this.orderStatusOrderDetailsPageCss))).toMatch('Provisioning in Progress');
    //browser.navigate().refresh();
    browser.waitForAngular();
    element(by.css(this.retryButtonOrderDetailsPageCss)).click();
    util.waitForAngular();
};


//******************************Function for searching an Order*************//

/*orders.prototype.searchOrderById = function (orderId, totalRepeatCountApproveOrder) {
	var self = this;
	var orgOrderId = orderId;
	var currentRepeatCountApproveOrder = 1;
	if (totalRepeatCountApproveOrder == undefined) {
		totalRepeatCountApproveOrder = 30;
		currentRepeatCountApproveOrder = 1;
	}
	
	var expOrderId;
	if(typeof orderId.then === 'function'){
		orderId.then(function (order) {
			expOrderId = order;
		});
	}else{
		expOrderId = orderId;
	}

	browser.wait(EC.visibilityOf(element(by.css(self.orderSearchTextBoxCss))), 65000).then(function () {
		logger.info("Waiting for search order id field to be enabled.");
	}).catch(function (err) {
		browser.sleep(30000);
		logger.info("Exception occured as No Such Window");
	});
	var searchInputBox = element(by.css(self.orderSearchTextBoxCss));	
	searchInputBox.clear();	
	//Wait till order Ids are displayed on left panel
	var orderList = element.all(by.css(this.orderTableOrderIDColumnCss));	
	browser.wait(EC.visibilityOf(orderList.get(0)),90000).then(function(){
		logger.info("Waiting for Order id's to display");
	}).catch(function(err){
		logger.info("Order is not displayed on orders page");
	});

	searchInputBox.sendKeys(orderId);
	util.waitForAngular();	
	browser.sleep(3000);
	if(orderId !== orgOrderId){
		searchInputBox.clear();	
		searchInputBox.sendKeys(orgOrderId);	
		logger.info("Searched original order id");
	}
	return element(by.xpath(self.orderNotFoundTextXpath)).getText().then(function (message) {
		if (message === "No Orders Found" || message === "No Pending Orders") {
			logger.info(message);
			self.isDisplayedApproveButtonOrderDetails().then(function (isApproveButtonDisplayed) {
				//Check if Apporve button displayed belongs to same orderId
				if(isApproveButtonDisplayed == true) {
					return self.validateOrderId(expOrderId, totalRepeatCountApproveOrder - 1);
				}else{
					while (currentRepeatCountApproveOrder < totalRepeatCountApproveOrder && isApproveButtonDisplayed == false) {
						logger.info("Searching orderId again ....");
						totalRepeatCountApproveOrder = totalRepeatCountApproveOrder - 1;
						self.open();
						self.clickAllOrdersUnderOrdersSection();
						self.searchOrderById(expOrderId, totalRepeatCountApproveOrder);
						isApproveButtonDisplayed = self.isDisplayedApproveButtonOrderDetails().then(function (displayStatus) {
							logger.info("Approve button display status - within loop: " + displayStatus);
							browser.sleep(5000);
						});
					}
				}
			});

		}
		return;
	}).catch(function () {
		return self.validateOrderId(expOrderId, totalRepeatCountApproveOrder - 1);		
	});
};*/

orders.prototype.searchOrderById = function (orderId, totalRepeatCountApproveOrder) {
	var self = this;
	var orgOrderId = orderId;
	var currentRepeatCountApproveOrder = 1;
	if (totalRepeatCountApproveOrder == undefined) {
		totalRepeatCountApproveOrder = 7;
		currentRepeatCountApproveOrder = 1;
	}	
	
	browser.wait(EC.visibilityOf(element(by.css(self.orderSearchTextBoxCss))), 65000).then(function () {
		logger.info("Waiting for search order id field to be enabled.");
	}).catch(function (err) {
		//browser.sleep(30000);
		logger.info("Exception occured as No Such Window");
	});
	var searchInputBox = element(by.css(self.orderSearchTextBoxCss));	
	searchInputBox.clear();	
	//Wait till order Ids are displayed on left panel
	var orderList = element.all(by.css(this.orderTableOrderIDColumnCss));	
	browser.wait(EC.visibilityOf(orderList.get(0)),90000).then(function(){
		logger.info("Waiting for Order id's to display");
	}).catch(function(err){
		logger.info("Order is not displayed on orders page");
	});

	searchInputBox.sendKeys(orderId);
	//Commenting below line as a workaround
	//util.waitForAngular();	
	//browser.sleep(3000);
	if(orderId !== orgOrderId){
		searchInputBox.clear();	
		searchInputBox.sendKeys(orgOrderId);	
		logger.info("Searched original order id");
	}
	//Commenting below code as Performance issues are now addressed
// 	element(by.xpath(self.orderNotFoundTextXpath)).getText().then(function (message) {		
// 		logger.info(message);			
// 	}).catch(function () {		
// 		logger.info("Order Id is displayed");		
// 	});
	
	if(typeof orderId.then === 'function'){
		orderId.then(function (order) {			
			return self.validateOrderId(order, totalRepeatCountApproveOrder - 1);
		});
	}else{
		return self.validateOrderId(orderId, totalRepeatCountApproveOrder - 1);		
	}
	//Commenting below code as Performance issues are now addressed
	//Check if small spinner is loading
	browser.wait(EC.invisibilityOf(element(by.css('.bx--loading__svg'))), 10000).then(function(){
	}).catch(function(err){
		logger.info("Spinner is still loading Orders page; click on view updates link ");
		element(by.css(defaultConfig.orderApproverViewUpdatesLinkCss)).click();
		self.clickServiceDetailSliderCloseButton();
	});
};


orders.prototype.searchOrderByStatus = function(orderStatus){
	var searchInputBox = element(by.css(this.orderSearchTextBoxCss));
	util.waitForAngular();
    logger.info('Status: '+ orderStatus);
	searchInputBox.sendKeys(orderStatus);
	searchInputBox.sendKeys(protractor.Key.ENTER);
	util.waitForAngular();
};

orders.prototype.getEstimatedPrice_OrdersPage = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.estimatedCostOnOrdersPageCss))), 10000);
    return element(by.css(this.estimatedCostOnOrdersPageCss)).getText().then(function(text){
        logger.info("Estimated price on Pending Approval Order page: "+text)
        return text;
    });
};
//*********************Function for Order Table to get values for First Order *************//

orders.prototype.getTextFirstOrderIdOrdersTable = function(){	
	//util.waitForAngular();
	//Adding static wait since orderIds take time to load irrespective of dom elements
	browser.sleep(3000);
	browser.wait(EC.visibilityOf(element(by.css(defaultConfig.orderTableOrderIDColumnCss))),90000).then(function(){
		logger.info("Order Id is displayed on orders page");	
	}).catch(function(err){		
		logger.info("Order is not displayed on orders page");		
	});
	return element(by.css(defaultConfig.orderTableOrderIDColumnCss)).getText().then(function(text){
		var orderId=text;
		if(orderId.includes('ORDER #')){
			orderId=orderId.replace('ORDER # ','');
		}
		logger.info("Order ID :: "+orderId);
		return orderId.trim();
	}).catch(function(err){		
		logger.info("Order is not displayed on orders page");
		return "";		
	});
};

orders.prototype.getTextFirstCreatedDateOrdersTable = function(){
    browser.wait(EC.visibilityOf(element(by.css(this.orderTableCreatedDateColumnCss))),10000);
    return element.all(by.css(this.orderTableCreatedDateColumnCss)).first().getText().then(function(text){
		logger.info("Order Created Date :: "+text);
		return text;
    });
};

/*orders.prototype.getTextFirstUpdatedDateOrdersTable = function()
{
    return element.all(by.css(this.orderTableUpdatedDateColumnCss)).first().getText().then(function(text){
    	logger.info("Order ID :: "+text);
    });
};*/

orders.prototype.getTextFirstPlacedByOrdersTable = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.orderTablePlacedByColumnCss))),10000);
    return element.all(by.css(this.orderTablePlacedByColumnCss)).first().getText().then(function(text){
		logger.info("Order Placed By :: "+text);
		return text;
    });
};

orders.prototype.getTextFirstOrderTypeOrdersTable = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.orderTableOrderTypeColumnCss))),10000);
	return element.all(by.css(this.orderTableOrderTypeColumnCss)).first().getText().then(function(text){
		logger.info("Order Type in orders Table is :: "+text);
		return text;
    });
};

orders.prototype.getTextFirstOrderStatusOrdersTable = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.orderTableOrderStatusColumnCss))),10000);
	return element.all(by.css(this.orderTableOrderStatusColumnCss)).first().getText().then(function(text){
		logger.info("Order status of the first order from Order table is: "+text);
		return text;
	});
};

orders.prototype.getTextFirstAmountOrdersTable = function(){
	browser.sleep(10000);
	browser.wait(EC.visibilityOf(element(by.css(this.orderTableAmountColumnCss))),60000);
     return element.all(by.css(this.orderTableAmountColumnCss)).first().getText().then(function(text){
		//return text.toString().replace(",","");
	     logger.info("Estimated price on approve order page is : " + text);
	     return text;
    });
};

orders.prototype.getTextTotalPriceBillOfMaterial = function(){
    return element.all(by.css(this.orderTableAmountColumnCss)).first().getText().then(function(text){
        logger.info("Total Price : "+text);
        var str1 = text.substr(3,4);
		var str2 = text.substr(20,6);
		var str4 = parseFloat(str1)+parseFloat(str2);
		//str4 = str4.toString();
		str4 = Math.round(str4);
		//var total = "USD"+str4.toString();
		console.log("Total Price :: "+str4);
        return str4;
    });
};

//*******************Functions for Service Details Section************************

orders.prototype.getTextserviceNameServiceDetails = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.serviceNameServiceDetailsCss))),10000);
    return element(by.css(this.serviceNameServiceDetailsCss)).getText().then(function(text){
		logger.info("Service Name under Service Details :: "+text);
		return text;
    });
};

orders.prototype.getTextServiceOfferingNameServiceDetails = function(){
    return element(by.css(this.serviceOfferingNameServiceDetailsCss)).getText().then(function(text){
		logger.info("Service Offering Name under Service Details :: "+text);
		return text;
    });
};

orders.prototype.getTextProviderNameServiceDetails = function(){
    return element(by.css(this.providerNameServiceDetailsCss)).getText().then(function(text){
		logger.info("Provider Name under Service Details :: "+text);
		return text;
    });
};

orders.prototype.getTextPriceServiceDetails = function()
{
    return element(by.css(this.priceServiceDetailsCss)).getText().then(function(text){
		logger.info("Price under Service Details :: "+text);
		return text;
    });
};

orders.prototype.getTextFeeServiceDetails = function(){
    return element(by.css(this.feesServiceDetailsCss)).getText().then(function(text){
		logger.info("Fee under Service Details :: "+text);
		return text;
    });
};

orders.prototype.clickFirstViewDetailsOrdersTable = function (){
	var curr = this;
	browser.sleep(2000);
	util.waitForAngular();
	//browser.ignoreSynchronization = true;
	var eleToClick = element(by.css(curr.orderTableActionIconCss));
	browser.wait(EC.elementToBeClickable(element.all(by.css(curr.orderTableActionIconCss)).first()), 180000).then(function () {
		browser.executeScript("arguments[0].scrollIntoView();", eleToClick.getWebElement()).then(function(){
			browser.sleep(5000);
			element.all(by.css(curr.orderTableActionIconCss)).first().click().then(function () {
				logger.info("Clicked on the Actions icon of the first row on Orders page");
				browser.wait(EC.visibilityOf(element(by.buttonText(curr.buttonTextViewDetails))), 60000).then(function(){
					 element(by.buttonText(curr.buttonTextViewDetails)).click().then(function () {
						logger.info("Clicked on View Details link to get Order Details page");
						util.waitForAngular();
						//Adding hardcoded sleep since it takes time to load order details page.
						browser.sleep(4000);
						element.all(by.css(curr.spinnerCss)).then(function (textArray) {
							for (var i = 0; i < textArray.length; i++) {
								browser.wait(EC.invisibilityOf(textArray[i]), 5 * 60 * 1000).then(function(){
								}).catch(function(err){
									logger.info("Timeout-->Spinner is still loading after 5 mins");
								});
							}
						});
						//return;
					}).catch(function(err){
						browser.sleep(3000);
						eleToClick.click();
					});
				});
			});
		});
	});
	//browser.ignoreSynchronization = false;
};

orders.prototype.clickServiceDetailSliderCloseButton = function(counter) {
	var self = this;
	var count = 1;
	if(counter == undefined){
		counter=3
	}

	element(by.css(self.buttonCloseServiceDetailSliderCss)).isPresent().then(function (res) {
		if (res) {
			while(count <= counter){
				var sliderClosebtn = element(by.css(self.buttonCloseServiceDetailSliderCss));	
				browser.wait(EC.elementToBeClickable(sliderClosebtn), 60000).then(function(){				
				}).catch(function(){
					logger.info("Service details not displayed");
				});
				return sliderClosebtn.click().then(function(){
					logger.info("Closed the Service detail Slider");
					counter=0;
                    			return;
				}).catch(function(err){
					logger.info("Service detail Slider close button not displayed");			
					counter = counter - 1;
					self.clickServiceDetailSliderCloseButton(counter);
				});
			}

		}
		else {
			logger.info("Slider is already closed");
		}
	})
	
}

orders.prototype.isDisplayedViewDetailsUnderActionsButton = function(){
	var curr = this;
	return element.all(by.css(curr.orderTableActionIconCss)).first().click().then(function(){
		logger.info("Clicked on the first Actions Icon")
		return element(by.buttonText(curr.buttonTextViewDetails)).isDisplayed();
	});
};

orders.prototype.clickViewDetailsButton = function(){
    browser.actions().mouseMove(element(by.buttonText(curr.buttonTextViewDetails))).perform();
    browser.wait(EC.elementToBeClickable(element(by.buttonText(curr.buttonTextViewDetails))),10000);
    return element(by.buttonText(curr.buttonTextViewDetails)).click();
};

//--------------Functions for View Updates Section---------------------
orders.prototype.clickViewUpdateUnderServiceDetails = function() {
	browser.wait(EC.elementToBeClickable(element(by.linkText(this.viewUpdatesServiceDetailsLinkText))), 60000);
	return element(by.linkText(this.viewUpdatesServiceDetailsLinkText)).click().then(function(){
		logger.info("Clicked on Update Details Link...");
	});
}

orders.prototype.closeServiceDetailsSlider = function() {
	browser.wait(EC.elementToBeClickable(element(by.css(this.closeServiceDetailsSliderCss))), 60000);
	return element(by.css(this.closeServiceDetailsSliderCss)).click().then(function(){
		logger.info("Closed the Slider...");
	});
}

//****************************************************************************************************//

//********************FUNCTIONS FOR ORDER DETAILS for Approvers and Buyer PAGE*************************

orders.prototype.getTextViewOrderDetailsTitle = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.viewOrderDetailsTextCss))),25000);
	return element(by.css(this.viewOrderDetailsTextCss)).getText().then(function(text){
		return text;
	});
};

orders.prototype.getTextOrderIdOrderDetails = function(){
	return element(by.css(this.orderNumberOrderDetailsPageCss)).getAttribute("value").then(function(text){
		logger.info("Order Number in Order details page : "+text);
		return text;
	});
};

orders.prototype.getTextOrderServiceNameOrderDetails = function(){
    browser.wait(EC.visibilityOf(element(by.xpath(this.orderServiceNameOrderDetailsPageXpath))),5000);
	return element(by.xpath(this.orderServiceNameOrderDetailsPageXpath)).getText().then(function(text){
	logger.info("Order Service Name in Order details page : "+text);
		return text;
	});
};

orders.prototype.getTextOrderProviderNameOrderDetails = function(){
    browser.wait(EC.visibilityOf(element(by.xpath(this.orderProviderNameOrderDetailsPageXpath))),5000);
	return element(by.xpath(this.orderProviderNameOrderDetailsPageXpath)).getText().then(function(text){
	logger.info("Order Provider Name in Order details page : "+text);
		return text;
	});
};

orders.prototype.getTextOrderExternalcontext = function(){
    browser.wait(EC.visibilityOf(element(by.xpath(this.orderExternalcontextCustomerXpath))),5000);
	return element.all(by.xpath(this.orderExternalcontextCustomerXpath)).first().getText().then(function(Externalcontexttext){
	logger.info("Customer context in Order details page : "+Externalcontexttext);
		return Externalcontexttext;
	});
};

orders.prototype.getTextOrderCreatedDateOrderDetails = function(){
    browser.wait(EC.visibilityOf(element(by.css(this.orderCreatedDataOrderDetailsPageCss))),5000);
	return element(by.css(this.orderCreatedDataOrderDetailsPageCss)).getAttribute("value").then(function(text){
		logger.info("Order Created Date in Order details page : "+text);
		return text;
	});
};

orders.prototype.getTextOrderUpdatedDateOrderDetails = function(){
    browser.wait(EC.visibilityOf(element(by.css(this.orderUpdatedDateOrderDetailsPageCss))),5000);
	return element(by.css(this.orderUpdatedDateOrderDetailsPageCss)).getAttribute("value").then(function(text){
		logger.info("Order Updated Date in Order details page : "+text);
		return text;
	});
};

orders.prototype.getTextOrderStatusOrderDetails = function(){
	return element(by.css(this.orderStatusOrderDetailsPageCss)).getAttribute("value").then(function(text){
		logger.info("Status in Order details page : "+text);
		return text;
	});
};

orders.prototype.getTextOrderRejectionReasonOrderDetails = async function(){
    // var value = element(by.css(this.orderRejectionOrderDetailsPageCss)).getAttribute("value");
    // logger.info("Rejection in Order details page : " + value);
    //
    // return value;
    element(by.id(this.orderRejectionOrderDetailsPageId)).getAttribute("value").then(function(text){
        logger.info("Rejection in Order details page : "+text);
        return text;
    });
};

orders.prototype.getTextOrderServiceTypeOrderDetails = function(){
	//return element(by.css(this.orderServiceTypeOrderDetailsPageCss)).getAttribute("value").then(function(text){
	return element(by.css(this.orderServiceTypeOrderDetailsPageCss)).getText().then(function(text){
		logger.info("Service Type in Order details page : "+text);
		return text;
	});
};

orders.prototype.getOrderStatusFirstOrder = function(){
	return element(by.css(this.orderStatusofFirstOrderCss)).getAttribute("value").then(function(text){
		logger.info("Status First Order details page : "+text);
		return text;
	});
};

orders.prototype.getTextOrderTypeOrderDetails = function(){
	return element.all(by.css(this.orderTypeOrderDetailsPageCss)).getText().then(function(text){
		var text= text.toString();
		logger.info("Order type in Order details page : "+text);
		return text;
	});
};

orders.prototype.getTextTeamOrderDetails = function(){
	return element(by.css(this.orderTeamOrderDetailsPageCss)).getText().then(function(text){
		logger.info("Order Team in Order details page : "+text);
		return text;
	});
};

orders.prototype.getTextTotalCostOrderDetails = function(){
	return element(by.css(this.orderTotalCostOrderDetailsPageCss)).getText().then(function(text){
		logger.info("Total Cost in Order details page : "+text);
		return text;
	});
};

orders.prototype.getTextSubmittedByOrderDetails = function(){
	return element(by.css(this.orderSubmittedByOrderDetailsPageCss)).getText().then(function(text){
		logger.info("Order submitted by : "+text);
		return text;
	});
};

orders.prototype.getTextCPUOnServiceConfigurationOrderDetails = function(){
	return element(by.css(this.orderCPUServiceConfigurationTabCss)).getAttribute("value").then(function(text){
		logger.info("CPU on Buyer Order details page : "+ text);
		return text;
	});
};

orders.prototype.getTextMemoryOnServiceConfigurationOrderDetails = function(){
	return element(by.css(this.orderMemoryServiceConfigurationTabCss)).getAttribute("value").then(function(text){
		logger.info("Memory on Buyer Order details page : "+ text);
		return text;
	});
};

orders.prototype.getTextStorageOnServiceConfigurationOrderDetails = function(){
	return element(by.css(this.orderStorageServiceConfigurationTabCss)).getAttribute("value").then(function(text){
		logger.info("Storage on Buyer Order details page : "+ text);
		return text;
	});
};

orders.prototype.getTextCPUOnServiceConfigurationApproversOrderDetails = function(){
    return element(by.css(this.orderCPUServiceConfigurationTabCss)).getText("value").then(function(text){
        logger.info("\nCPU on Approver Order details page : "+ text);
        return text;
    });
};

orders.prototype.getTextMemoryOnServiceConfigurationApproversOrderDetails = function(){
    return element(by.css(this.orderMemoryServiceConfigurationTabCss)).getText("value").then(function(text){
        logger.info("Memory on Approver Order details page : "+ text);
        return text;
    });
};

orders.prototype.getTextStorageOnServiceConfigurationApproversOrderDetails = function(){
    return element(by.css(this.orderStorageServiceConfigurationTabCss)).getText("value").then(function(text){
        logger.info("Storage on Approver Order details page : "+ text);
        return text;
    });
};

orders.prototype.getTextTotalCostOnBillofMaterialsOrderDetails = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.orderTotalCostBillofMaterialsTabCss))),30000);
	return element(by.css(this.orderTotalCostBillofMaterialsTabCss)).getText("value").then(function(text){
		logger.info('\n' + "Total Cost on Bill of Materials tab on Order details page : "+ text);
		return text;
	});
};

orders.prototype.getTextSubmittedStatusfromOrderUpdates = function(){
    browser.wait(EC.visibilityOf(element(by.css(this.orderOrderUpdatesSubmittedCss))),5000);
    return element(by.css(this.orderOrderUpdatesSubmittedCss)).getText("value").then(function(text){
        logger.info('\n' + "First order status from Order Updates: "+ text);
        return text;
    });
};

orders.prototype.getTextApprovalStatusfromOrderUpdates = function(){
    browser.wait(EC.visibilityOf(element(by.css(this.orderOrderUpdatesApprovalInProgressCss))),5000);
    return element(by.css(this.orderOrderUpdatesApprovalInProgressCss)).getText("value").then(function(text){
        logger.info("Second order status from Order Updates: " + text);
        return text;
    });
};

orders.prototype.isDisplayedApproveButtonOrderDetails = function(){
	//return element(by.buttonText(this.approveButtonText)).isPresent().then(function (flag, err) {
	//Commenting below line as if button is not available script will imeout and wont move further for getting status of button.
	//browser.wait(EC.visibilityOf(element(by.css(this.approveButtonOrderDetailsPageCss))),20000);
	browser.wait(EC.visibilityOf(element(by.css(this.approveButtonOrderDetailsPageCss))),60000).then(function(){
		logger.info("Waiting to display Approve button");
	}).catch(function(){
		logger.info("Approve button not displayed in 60s");
	});
	return element(by.css(this.approveButtonOrderDetailsPageCss)).isPresent().then(function (flag, err) {
		if(err){
			return false;
		}
		logger.info("Approve button display status: "+flag);
		return flag;
    });
};

orders.prototype.isPresentApproveButtonOrderDetails = function(){
    return element(by.css(this.approveButtonOrderDetailsPageCss)).isPresent();//element(by.buttonText(this.approveButtonText))
};

orders.prototype.isPresentCancelButtonOrderDetails = function(){
    return element(by.css(this.cancelButtonOrderDetailsPageCss)).isPresent().then(function(flag,err){
    	if(err){
			return false;
		}
    	logger.info("Cancel button display status : "+flag)
		return flag;
    });
};

orders.prototype.isPresentRetryButtonOrderDetails = function(){
    return element(by.css(this.retryButtonOrderDetailsPageCss)).isPresent();
};

orders.prototype.clickApproveButtonOrderDetails = function(repeatCount){
	/*browser.wait(EC.visibilityOf(element(by.css(this.orderNumberOrderDetailsPageCss))),60000).then(function(){
		logger.info("Order Details page is loaded, now waiting for Approve/Deny/Cancel button to be displayed");
	});*/
	var self = this;
	if(repeatCount == undefined){
	   repeatCount = 1;
	}

	var approveBtn = element(by.css(this.approveButtonOrderDetailsPageCss));
	browser.wait(EC.elementToBeClickable(approveBtn),300000).then(function(){
		logger.info("Approve/Deny button is shown and clickable...");
	});
	while(repeatCount < 3){
		browser.executeScript("document.getElementById('order_approve_button').scrollIntoView()");
		//Adding exception handling for "element not clickable" error
		return approveBtn.click().then(function(){
			logger.info("Clicked on approve Button");
			util.waitForAngular();
			//Check if Technical/Financial approval is displayed
			browser.wait(EC.elementToBeClickable(element(by.css(defaultConfig.OrderApprovalModalFinancialApprovalCheckboxCss))), 30000).then(function(){
				logger.info("Technical/Financial Approval is displayed");
			}).catch(function(err){
				repeatCount = repeatCount + 1;
				self.clickApproveButtonOrderDetails(repeatCount);
			});
		}).catch(function(err){
			repeatCount = repeatCount + 1;
			self.clickApproveButtonOrderDetails(repeatCount);
		});
	}
};

orders.prototype.isPresentDenyButtonOrderDetails = function(){
    return element(by.css(this.denyButtonOrderDetailsPageCss)).isPresent();//element(by.buttonText(this.denyButtonText))

    //  **** This is not working for some reason. It looks right but I get the message
	// 'Expected undefined to be true, 'The deny button was not present.'.'
// 	return element(by.buttonText(this.denyButtonText)).isPresent().then(function(status){
// 		logger.info("Deny element present status: "+status);
// 	});
};


orders.prototype.isDisplayedDenyButtonOrderDetails = function(){
	return element(by.css(this.denyButtonOrderDetailsPageCss)).isPresent().then(function (flag, err) {
		if(err){
			return false;
		}
		logger.info("Deny button display status: "+flag);
		return flag;
    });
};

orders.prototype.isDisplayedCancelButtonOrderDetails = function(){
    return element(by.css(this.cancelButtonOrderDetailsPageCss)).isDisplayed();
};

orders.prototype.clickDenyButtonOrderDetails = function () {
	/*browser.wait(EC.visibilityOf(element(by.css(this.orderNumberOrderDetailsPageCss))),60000).then(function(){
		logger.info("Order Details page is loaded, now waiting for Approve/Deny/Cancel button to be displayed");
	});*/

	var denybtn = element(by.css(this.denyButtonOrderDetailsPageCss));
	//browser.wait(EC.visibilityOf(denybtn), 300000);
	browser.wait(EC.elementToBeClickable(denybtn), 300000).then(function () {
		logger.info("Approve/Deny button is shown and clickable...");
	});
	return denybtn.click().then(function () {
		logger.info("Clicked on deny Button");
	}).catch(function (err) {
		browser.sleep(6000);
		logger.info("2nd attempt to click on deny button");
		return denybtn.click();
	});

};

orders.prototype.getTextFailureReason = function() {
    browser.wait(EC.visibilityOf(element(by.css(this.failureReasonOrderDetailsPageCss))),15000);
	return element(by.css(this.failureReasonOrderDetailsPageCss)).getAttribute("value").then(function(text){
		logger.info("Reason of Failure : "+text);
		return text;
	})
}

orders.prototype.clickServiceConfigurationsTabOrderDetails = function(){
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.serviceDetailsButtonServiceDetailsBtnText))),5000);
	return element(by.buttonText(this.serviceDetailsButtonServiceDetailsBtnText)).click().then(function(){
		logger.info("Clicked on Service Configurations tab")
	});
};

orders.prototype.clickBillOfMaterialsTabOrderDetails = function(){
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.estimatedCostsButtonServiceDetailsBtnText))),20000);
	return element(by.buttonText(this.estimatedCostsButtonServiceDetailsBtnText)).click().then(function(){
		logger.info("Clicked on Bill of Materials tab")
	});
};

orders.prototype.getEstimatedCostFromEstimatedCostTab = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.bomTotalCostCss))),5000);
	return element(by.css(this.bomTotalCostCss)).getText().then(function(text){
		if(text == 'N/A'){
			logger.info("Cost under Estimated Costs Tab is :: "+text);
		}
		else{
			var str1 = text.substr(3,9);
			console.log(str1);
			text = Math.round(str1).toString();
			logger.info("Cost under Estimated Costs Tab is :: "+text);
		}
		return text;
	})
}

orders.prototype.getEstimatedCostFromBillOfMaterialsTab = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.bomTotalCostCss))),20000);
	return element(by.css(this.bomTotalCostCss)).getText().then(function(text){
		logger.info("Cost under Estimated Costs Tab is :: "+text);
		return text;
	});
}

orders.prototype.clickOrderUpdatesServiceDetails = function(){
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.orderUpdatesButtonServiceDetailsBtnText))),5000);
	return element(by.buttonText(this.orderUpdatesButtonServiceDetailsBtnText)).click().then(function(){
		logger.info("Clicked on Order Updates tab")
	});
};

orders.prototype.clickBuyerOrderDetailsLink = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderOrderDetailsLinkCss))),5000);
    return element(by.css(this.orderOrderDetailsLinkCss)).click();
};

orders.prototype.clickBuyerServiceDetailsTab = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderServiceDetailsTabCss))),5000);
    return element(by.css(this.orderServiceDetailsTabCss)).click();
};

orders.prototype.clickBuyerEstimatedCostTab = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderEstimatedCostTabCss))),5000);
    return element(by.css(this.orderEstimatedCostTabCss)).click();
};

orders.prototype.clickBuyerOrderUpdateTab = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderOrderUpdateTabCss))),5000);
    return element(by.css(this.orderOrderUpdateTabCss)).click();
};

orders.prototype.clickBuyerServiceDetailsCloseButton = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderBuyerServiceDetailsCloseButtonCss))),5000);
    return element(by.css(this.orderBuyerServiceDetailsCloseButtonCss)).click();
};

//***********************  FUNCTIONS FOR CANCEL ORDER  ************************************ */
orders.prototype.clickCancelButtonOrderApprovalModal = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.OrderApprovalModalCancelButtonCss))),20000);
	return element(by.css(this.OrderApprovalModalCancelButtonCss)).click();
};
orders.prototype.clickYesButtonOnCancelPopup = function(){

	browser.wait(EC.elementToBeClickable(element(by.xpath(this.OrderApprovalModalTitleXpath))),20000);
    return element(by.css(this.OrderCancelPopupYesButtonCss)).click();
};

orders.prototype.clickOkButtonOnCancelPopup = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.OrderCancelPopupOkButtonCss))),40000);
    return element(by.css(this.OrderCancelPopupOkButtonCss)).click();
};



//************************  FUNCTIONS FOR RETRY ORDER *****************************************

orders.prototype.clickOkayOrderRetryModal = function () {
	browser.wait(EC.elementToBeClickable(element(by.id(this.orderRetryModalOkayId))), 9000);
    return element(by.id(this.orderRetryModalOkayId)).click().then(function(){
		logger.info("Clicked on the Okay button of the success pop-up of Retry");
	})
};

orders.prototype.clickNoOrderRetryModal = function () {
    browser.wait(EC.elementToBeClickable(element(by.id(this.OrderRetryModalNoButtonId))), 6000);
    return element(by.id(this.OrderRetryModalNoButtonId)).click();
};
//***********************FUNCTIONS FOR APPROVING ORDER************************************************//

orders.prototype.getTextOrderApprovalModalTitle = function(){
	return element(by.xpath(this.OrderApprovalModalTitleXpath)).getText().then(function(text){
		logger.info(text);
		return text;
	});
};

orders.prototype.clickFinancialApprovalCheckBoxOrderApprovalModal = function () {
	// //This is a temporary fix to accomodate changes in object identifier.
	// //In customer1, FinancialApproveCheckbox is '#checkbox-Financial ~ label'
	// //and, all other QA envs, it is '#checkbox-financial ~ label'
	// if (url.toLowerCase().includes('customer1')){
	//     tempFinancialApproveCheckbox = '#checkbox-Financial ~ label';
	// }else{
	//     tempFinancialApproveCheckbox = this.OrderApprovalModalFinancialApprovalCheckboxCss;
	// }
	//util.waitForAngular();
	var curr = this;
	browser.sleep(3000);
	browser.wait(EC.elementToBeClickable(element(by.css(curr.OrderApprovalModalFinancialApprovalCheckboxCss))), 120000);
	var approval = element(by.css(curr.OrderApprovalModalFinancialApprovalCheckboxCss))
	return browser.executeScript("arguments[0].click();", approval).then(function() {		
		logger.info("Checked Financial Approval checkbox");
		//util.waitForAngular();
	}).catch(function (err) {
		return element(by.css(curr.OrderApprovalModalFinancialApprovalCheckboxCss)).isDisplayed().then(function (value) {
			if (value) {
				//Make sure that checkbox is checked
				return browser.executeScript("return document.getElementById('checkbox-financial').checked;").then(function (checkboxChecked) {
					if (checkboxChecked == false) {
						return element(by.css(defaultConfig.OrderApprovalModalFinancialApprovalCheckboxCss)).click().then(function () {
							logger.info("Selected financial checkbox in 2nd attempt");
							util.waitForAngular();
						});

					}
				});
			}
			else {
				return element(by.css(curr.closeApproveModalCss)).isPresent().then(function (resp) {
					if (resp) {
						return element(by.css(curr.closeApproveModalCss)).click().then(function () {
							logger.info("closed Order Approval Flow as Financial Approver check box was not present trying again. ");
							curr.clickApproveButtonOrderDetails();
							return element(by.css(curr.OrderApprovalModalFinancialApprovalCheckboxCss)).click().then(function () {
								logger.info("Checked Financial Approval checkbox  in 2nd attempt");
							});

						});
					}

				});
			}
		});
	});


};

orders.prototype.clickTechnicalApprovalCheckBoxOrderApprovalModal = function(){
	var curr = this;
	browser.wait(EC.elementToBeClickable(element(by.css(curr.OrderApprovalModalTechincalApprovalCheckboxCss))),90000);
	var approval = element(by.css(curr.OrderApprovalModalTechincalApprovalCheckboxCss))
	return browser.executeScript("arguments[0].click();", approval).then(function() {
		logger.info("Checked Technical Approval checkbox");
	}).catch(function (err) {
		return element(by.css(curr.OrderApprovalModalTechincalApprovalCheckboxCss)).isDisplayed().then(function (value) {
			if (value) {
				//Make sure that checkbox is checked
				return browser.executeScript("return document.getElementById('checkbox-technical').checked;").then(function (checkboxChecked) {
					if (checkboxChecked == false) {
						return element(by.css(defaultConfig.OrderApprovalModalTechincalApprovalCheckboxCss)).click().then(function () {
							logger.info("Selected technical checkbox in 2nd attempt");
							util.waitForAngular();
						});

					}
				});
			}
			else {
				return element(by.css(curr.closeApproveModalCss)).isPresent().then(function (resp) {
					if (resp) {
						return element(by.css(curr.closeApproveModalCss)).click().then(function () {
							logger.info("closed Order Approval Flow as Technical Approver check box was not present trying again. ");
							curr.clickApproveButtonOrderDetails();
							return element(by.css(curr.OrderApprovalModalTechincalApprovalCheckboxCss)).click().then(function () {
								logger.info("Checked Technical Approval checkbox in 2nd attempt");
							});

						});
					}

				});
			}
		});
	});
};

orders.prototype.clickLegalApprovalCheckBoxOrderApprovalModal = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.OrderApprovalModalLegalApprovalCheckboxCss))),90000);
	var approval = element(by.css(this.OrderApprovalModalLegalApprovalCheckboxCss))
	return browser.executeScript("arguments[0].click();", approval).then(function() {
		logger.info("Checked Legal Approval checkbox");
	});
};

orders.prototype.checkIfLegalApprovalDisabled = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.OrderApprovalModalLegalApprovalCheckboxCss))),90000);
	return element(by.css(this.OrderApprovalModalLegalApprovalCheckboxCss)).getAttribute("class").then(function(text){
		if(text.includes("disabled")) {
			logger.info("Legal approval is disabled");
			return text;
		}
	});
};

orders.prototype.getTextApprovalErrorMsgSNOW = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textApprovalErrorCss))),90000);
	return element(by.css(this.textApprovalErrorCss)).getText().then(function(msg){
		logger.info("Approval error: " + msg);
		return msg;
	});
};

orders.prototype.clickApproveButtonOrderApprovalModal = function(){
	var curr = this;
	browser.wait(EC.elementToBeClickable(element(by.css(curr.OrderApprovalModalApproveButtonCss))),90000);
	return element(by.css(curr.OrderApprovalModalApproveButtonCss)).click().then(function(){
		logger.info("Clicked Approve button on Order Approval modal dialog");
		util.waitForAngular();
		element.all(by.css(curr.spinnerCss)).then(function (textArray) {
			for (var i = 0; i < textArray.length; i++) {
				browser.wait(EC.invisibilityOf(textArray[i]), 3 * 60 * 1000).then(function(){
				}).catch(function(err){
					logger.info("Timeout-->Spinner is still loading after 3 mins");
				});
			}
		});
	});
	
};

/*orders.prototype.clickApproveButtonOrderApprovalModal = function(orderObject){
	var self = this;
	return element(by.css(this.OrderApprovalModalApproveButtonCss)).click().then(function(){
		logger.info("Clicked Approve button on Order Approval modal dialog");
		util.waitForAngular();
		var elem = element(by.xpath(self.ApprovalSucessMsgXpath));
		return elem.isPresent().then(function(res){
			if(res){
				logger.info("Approval processed successfully..");
				return;
			}
			else{
				return element(by.css(self.closeApproveModalCss)).click().then(function(){
					logger.info("Closed approve modal");
					logger.info("Approval not processed. Click approve button again..");
					self.open();
					self.clickAllOrdersUnderOrdersSection();
					self.searchOrderById(orderObject);
				    browser.wait(EC.visibilityOf(element.all(by.css(self.textOrderStatusCss)).first()), 30000).then(function () {
					element.all(by.css(self.textOrderStatusCss)).first().getText().then(function (text) {
						if(text == 'Approval In Progress')
						{
							self.clickApproveButtonOrderDetails();
							self.clickFinancialApprovalCheckBoxOrderApprovalModal();
							self.clickTechnicalApprovalCheckBoxOrderApprovalModal();
							self.clickApproveButtonOrderApprovalModal();
						}
						else
						{
							logger.info("Order Status is: "+ text);
						}
					});
				});
			});
				}
			});
		});
	}; */		


orders.prototype.clickOkInOrderApprovalModal = function () {
	var orderApprove = element(by.css(this.OrderApprovalModalOkButtonCss));
	browser.sleep(3000);
	//browser.wait(EC.presenceOf(orderApprove), 90000); //Added this to avoid element not interactable issue
	browser.wait(EC.elementToBeClickable(orderApprove), 150000).then(function(){
		browser.actions().mouseMove(orderApprove).click().perform().then(function () {
			logger.info("Clicked on Ok button on Order Approval modal dialog");
		});
	}).catch(function(err){
		logger.info("Ok button on Order Approval modal dialog not displayed, clicking Cancel button")
		element(by.css(defaultConfig.OrderApprovalModalCancelButtonCss)).click()		
	});
};

orders.prototype.getErrorMessageOrderApprovalModal = function(){
	return element(by.css(this.OrderApprovalModalErrorMessageCss)).getText().then(function(text){
		logger.info(text);
		return text;
	});
};

orders.prototype.getTextOrderSuccessOrderApprovalModal = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.OrderApprovalModalSuccessMessageCss))),90000);
	return element(by.css(this.OrderApprovalModalSuccessMessageCss)).getText().then(function(text){
		logger.info(text);
		return text;
	});
};

orders.prototype.clickCloseXOrderApprovalModal = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.OrderApprovalModalCloseXCss))),15000);
	return element(by.css(this.OrderApprovalModalCloseXCss)).click();
	browser.wait(EC.invisibilityOf(element(by.xpath(this.OrderApprovalModalTitleXpath))),20000);
};


//************** FUNCTION for Search/Filters for BUYER Order page *******************

orders.prototype.getBuyerTotalOrdersfromUI = function(){
    //return element(by.xpath(this.BuyerUIOrdersTotalXpath)).getText().then(function(text){
	return element(by.css(this.ordersTotalCss)).getText().then(function(text){

	var splitText = text.split(" ");
		logger.info("\n\nOrders count from UI: " + splitText[0] + '\n');
		 return parseInt(splitText[0]);
	});
};

//Click Buyer Order Total
orders.prototype.clickBuyerOrderTotal = function(){
	return element(by.css(this.ordersTotalCss)).click();
};

orders.prototype.getTextOrderStatusOrderHistory = function(){
	browser.sleep("2000");
    return element(by.css(this.orderStatusOrderDetailsPageCss)).getText().then(function(text){
        logger.info("Status in Order details page : " + text);
        return text;
    });
};


//******************  Filter by Period *****************

// Get Buyer Order Counter
orders.prototype.getTextBuyerOrderPeriod = function(){
    browser.wait(EC.visibilityOf(element(by.css(this.ordersCounterValueCss))),6000);
    return element(by.css(this.ordersCounterValueCss)).getText();
};

// Click Buyer Order Counter
orders.prototype.clickBuyerOrderPeriod = function(){
    this.getTextBuyerOrderPeriod().click();
};

// Buyer Order Last Day period
orders.prototype.clickBuyerLastDayOrderPeriod = function(){
	return element(by.css(this.selectOptionLastDayCss)).click();
};

// Buyer Order Last Week period
orders.prototype.clickBuyerLastWeekOrderPeriod = function(){
    return element(by.css(this.selectOptionLastWeekCss)).click();
};

// Buyer Order Last Month period
orders.prototype.clickBuyerLastMonthOrderPeriod = function(){
	return element(by.css(this.selectOptionLastMonthCss)).click();
};

// Buyer Order Last 3 Months period
orders.prototype.clickBuyerLastThreeOrderPeriod = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.selectOptionLastThreeMonthsCss))),6000);
    return element(by.css(this.selectOptionLastThreeMonthsCss)).click();
};

// Buyer Order Last 6 Months period
orders.prototype.clickBuyerLastSixOrderPeriod = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.selectOptionLastSixMonthsCss))),6000);
    return element(by.css(this.selectOptionLastSixMonthsCss)).click();
};

// Buyer Order Last Year period
orders.prototype.clickBuyerLastYearOrderPeriod = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.selectOptionLastYearCss))),6000);
    return element(by.css(this.selectOptionLastYearCss)).click();
};

//Click Buyer "All Orders" status filter by Period
orders.prototype.clickBuyerAllOrderStatus = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.selectAllOrdersStatusCss))),6000);
	return element(by.css(this.selectAllOrdersStatusCss)).click();
};


//****************  Filter by Order Status  **************

// Get Select Order Status
orders.prototype.getTextSelectOrderStatus = function(){
    browser.wait(EC.visibilityOf(element(by.css(this.selectOrderStatusCss))),6000);
    return element(by.css(this.selectOrderStatusCss)).getText();
};

// Click "Select Order Status"
orders.prototype.clickSelectOrderStatus = function(){
    this.getTextSelectOrderStatus().click();
};

//Click "All Orders"  status filter by Order Status
orders.prototype.clickAllOrderFromOrderStatus = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.selectAllOrdersFromOrderStatusCss))),6000);
    return element(by.css(this.selectAllOrdersFromOrderStatusCss)).click();
};

//Click Buyer "Approval in Progress" status filter
orders.prototype.clickApprovalInProgress = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.selectApprovalInProgressStatusCss))),9000);
	return element(by.css(this.selectApprovalInProgressStatusCss)).click();
};

//Click Buyer "Submitted" status filter
orders.prototype.clickSubmitted = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.selectSubmittedOrderStatusCss))),9000);
    return element(by.css(this.selectSubmittedOrderStatusCss)).click();
};

//Click Buyer "Provisioning in Progress" status filter
orders.prototype.clickProvisionInginProgress = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.selectProvisioningInProgressOrderStatusCss))),9000);
    return element(by.css(this.selectProvisioningInProgressOrderStatusCss)).click();
};

//Click Buyer "Rejected" status filter
orders.prototype.clickRejectedOrderStatus = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.selectRejectedOrderStatusCss))),9000);
    return element(by.css(this.selectRejectedOrderStatusCss)).click();
};

orders.prototype.getTextFirstBuyerOrderNumber = function(){
    //return element(by.xpath(this.BuyerUIOrdersTotalXpath)).getText().then(function(text){
    return element(by.css(this.orderFirstOrderFromTableCss)).getText().then(function(text){

        var splitText = text.split(" ");
        logger.info("Buyer Order Number from Search result = " + splitText[1]);
        return splitText[1];
    });
};

//Search on Buyer Order page
orders.prototype.searchBuyerOrderNumber = function(buyerOrderNumber){
	var searchBuyerOrderInputBox = element(by.css(this.orderBuyerSearchTextBoxCss));

	browser.wait(EC.visibilityOf(element(by.css(this.orderBuyerSearchTextBoxCss))),6000);
	searchBuyerOrderInputBox.clear();
	searchBuyerOrderInputBox.sendKeys(buyerOrderNumber);
    searchBuyerOrderInputBox.sendKeys(protractor.Key.ENTER);
	util.waitForAngular();
	return;
};

orders.prototype.clickOrderExpandLink = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderExpandOrderCss))),5000);
    return element(by.css(this.orderExpandOrderCss)).click().then(function(){
		logger.info("Expanded the order");
	});
};

orders.prototype.getTextOrderServiceFulfillmentMsg = function(){
    browser.wait(EC.visibilityOf(element(by.css(this.orderServiceFulfillmentMsgCss))),5000);
    return element(by.css(this.orderServiceFulfillmentMsgCss)).getText().then(function(text){
        logger.info("***** Message from Expand Rejected order: " + text);
        return text;
    });
};

orders.prototype.clickOrderHistoryDetails = function(){
    return element(by.css(this.orderOrderHistoryDetailsCss)).click();
};

orders.prototype.clickServiceRetryButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.orderRetryServiceButtonCss))),6000);
	return element(by.css(this.orderRetryServiceButtonCss)).click().then(function(){
		logger.info("Clicked on the Retry button");
	});
};

orders.prototype.isEnabledRetryLink = function(){
    return element(by.css(this.orderRetryServiceButtonCss)).isEnabled();
};

orders.prototype.isPresentRetryLink = function(){
    return element(by.css(this.orderRetryServiceButtonCss)).isPresent();
};

orders.prototype.isPresentCancelLink = function(){
    return element(by.css(this.orderCancelServiceButtonCss)).isPresent();
};
//***********************FUNCTIONS FOR DENYING ORDER************************************************//

orders.prototype.getTextOrderDenyModalTitle = function(){
	browser.wait(EC.visibilityOf(element(by.xpath(this.OrderDenyModalTitleXpath))),25000);
	return element(by.xpath(this.OrderDenyModalTitleXpath)).getText().then(function(text){
		logger.info(text);
		return text;
	});
};

orders.prototype.clickFinancialApprovalCheckBoxOrderDenyModal = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.OrderDenyModalFinancialApprovalCheckboxCss))),20000);
	return element(by.css(this.OrderDenyModalFinancialApprovalCheckboxCss)).click();
};

// orders.prototype.clickFinancialApprovalCheckBoxOrderDenyModal = function(){
// 	//This is a temporary fix to accomodate changes in object identifier.
// 	//In customer1, FinancialApproveCheckbox- Deny is '#checkbox-denial-Financial ~ label'
// 	//and, all other QA envs, it is '#checkbox-denial-financial ~ label'
// 	if (url.toLowerCase().includes('customer1')){
//         tempFinancialApproveCheckbox = '#checkbox-denial-Financial ~ label';
// 	} else {
//         tempFinancialApproveCheckbox = this.OrderDenyModalFinancialApprovalCheckboxCss;
// 	}
// 	browser.wait(EC.visibilityOf(element(by.css(tempFinancialApproveCheckbox))),20000);
// 	return element(by.css(tempFinancialApproveCheckbox)).click().then(function(){
// 		logger.info("Checked Financial Approval checkbox for Deny Order");
// 	});
// };

orders.prototype.clickTechnicalApprovalCheckBoxOrderDenyModal = function(){
	util.waitForAngular();
	browser.sleep(4000);
	browser.wait(EC.elementToBeClickable(element(by.css(this.OrderDenyModalTechincalApprovalCheckboxCss))),60000);
// 	element(by.css(this.OrderDenyModalTechincalApprovalCheckboxCss)).click().then(function(){
// 		logger.info("Checked Technical Approval checkbox for Deny Order");
// 	});
	
	browser.executeScript("document.getElementById('denial-technical_input').click();").then(function(){
		logger.info("Checked Technical Approval checkbox for Deny Order using JS");
	});
	//Make sure that checkbox is checked
	return browser.executeScript("return document.getElementById('denial-technical_input').checked;").then(function(checkboxChecked){
		if(checkboxChecked == false){
			element(by.css(defaultConfig.OrderDenyModalTechincalApprovalCheckboxCss)).click().then(function(){
				logger.info("Selected Technical checkbox in 2nd attempt");
				util.waitForAngular();
			});			
		}else{
			logger.info("Technical checkbox is in checked state");
		}
	});
};


 orders.prototype.clickYesButtonOrderDenyModal = function(){
	return element(by.css(this.OrderDenyModalYesButtonCss)).click();
};

orders.prototype.clickYesButtonOrderRetryModal = function(){
	//return element(by.css(this.OrderRetryModalYesButtonCss)).click();
	element.all(by.css(this.OrderRetryModalYesButtonCss)).get(1).click().then(function(){
		logger.info("Clicked on Yes button of Retry confirmation pop-up");
	})
};

orders.prototype.clickCancelButtonOrderDenyModal = function(){
	return element(by.css(this.OrderDenyModalCancelButtonCss)).click();
	browser.wait(EC.invisibilityOf(element(by.css(this.OrderDenyModalTitleCss))),20000);
};

orders.prototype.clickOkInOrderDenyModal = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.OrderDenyModalOkButtonCss))),90000);
    return element(by.css(this.OrderDenyModalOkButtonCss)).click();
};

orders.prototype.clickDenyInOrderDenyModal = function(){
	var self = this;
	browser.wait(EC.elementToBeClickable(element(by.css(this.OrderDenyModalOkButtonCss))),9000);
	//Validate if checkbox is checked
	browser.executeScript("return document.getElementById('denial-technical_input').checked;").then(function(checkboxChecked){
		if(checkboxChecked == false){
			element(by.css(defaultConfig.OrderDenyModalTechincalApprovalCheckboxCss)).click().then(function(){
				logger.info("Selected Technical checkbox before Clicking on Deny button");
				util.waitForAngular();
			});			
		}else{
			logger.info("Technical checkbox is in checked state Before Clicking on Deny button");
		}
	});

	return element(by.css(this.OrderDenyModalOkButtonCss)).click().then(function(){
		logger.info("confirm for Deny Order");
	});
};

orders.prototype.getErrorMessageOrderDenyModal = function(){
	return element(by.css(this.OrderDenyModalErrorMessageCss)).getText().then(function(text){
		logger.info(text);
		return text;
	});
};

orders.prototype.clickCloseXOrderDenyModal = function(){
	return element(by.css(this.OrderDenyModalCloseXCss)).click();
	browser.wait(EC.invisibilityOf(element(by.css(this.OrderDenyModalTitleCss))),5000);
};


orders.prototype.clickCloseXRejectionReasonOrderDenyModal = function(){
	return element(by.css(this.OrderDenyModalCloseErrorEnterRejectionReasonCss)).click();
};

orders.prototype.setTextCommentsTextareaOrderDenyModal = function(reason){
	var msgTextbox = element(by.css(this.OrderDenyModalCommentsTextAreaCss));
	// browser.wait(EC.visibilityOf(msgTextbox), 60000);
	// return msgTextbox.sendKeys(reason).then(function(){
	// 	logger.info("Entered order deny comment as " + reason);
	// });	
	util.waitForAngular();	
	browser.sleep(3000);
	browser.wait(EC.elementToBeClickable(msgTextbox), 60000);
// 	msgTextbox.clear().then(function () {
// 		logger.info("Cleared Comments textarea box");
// 		var ctrlA = protractor.Key.chord(protractor.Key.CONTROL, "a");
// 		msgTextbox.sendKeys(ctrlA);
// 	}).catch(function(err){
// 		browser.sleep(4000);
// 		textbox.clear();
// 		var ctrlA = protractor.Key.chord(protractor.Key.CONTROL, "a");
// 		msgTextbox.sendKeys(ctrlA);
// 	});
	return msgTextbox.sendKeys(reason).then(function () {
		logger.info("Entered order deny comment as " + reason);
	})
};

orders.prototype.clickOkDenialWasProcessed = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.OrderDenyModalOkayButtonCss))),60000);
     element(by.css(this.OrderDenyModalOkayButtonCss)).click().then(function(){
		logger.info("click Ok Denial Was Processed");
	})
};

orders.prototype.isDisplayedCommentsValueRequiredMessage = function(){
	return element(by.css(this.OrderDenyModalCommentsValueRequiredCss)).isDisplayed();

};


//*********************  FUNCTION FOR ADMIN/APPROVER PAGE ***************************

orders.prototype.openApproverPage = function(){
    browser.get(this.pageApproverOrdersUrl);
};

orders.prototype.clickApproverPedingApprovalTab = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderApproverPendingOrderTabCss))),5000);
    return element(by.css(this.orderApproverPendingOrderTabCss)).click();
};

orders.prototype.clickApproverAllOrdersTab = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderApproverAllOrdersTabCss))),5000);
    return element(by.css(this.orderApproverAllOrdersTabCss)).click();
};

orders.prototype.clickApproverViewDetailsLink = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderApproverViewDetailsLinkCss))),5000);
    return element(by.css(this.orderApproverViewDetailsLinkCss)).click();
};

orders.prototype.clickApproverViewUpdatesLink = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderApproverViewUpdatesLinkCss))),5000);
    return element(by.css(this.orderApproverViewUpdatesLinkCss)).click();
};

orders.prototype.clickApproverFilterByTodayTab = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderApproverFilterByTodayCss))),5000);
    return element(by.css(this.orderApproverFilterByTodayCss)).click();
};

orders.prototype.clickApproverFilterByWeekTab = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderApproverFilterByWeekCss))),5000);
    return element(by.css(this.orderApproverFilterByWeekCss)).click();
};

orders.prototype.clickApproverFilterByMonthTab = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderApproverFilterByMonthCss))),5000);
    return element(by.css(this.orderApproverFilterByMonthCss)).click();
};

orders.prototype.clickApproverFilterByYearTab = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderApproverFilterByYearCss))),5000);
    return element(by.css(this.orderApproverFilterByYearCss)).click();
};

orders.prototype.clickApproverApproveButton = function(){
    browser.wait(EC.elementToBeClickable(element(by.css(this.orderApproverApproveButtonCss))),5000);
    return element(by.css(this.orderApproverApproveButtonCss)).click();
};

orders.prototype.getApproverErrorApproveMessage = function(){
    browser.wait(EC.visibilityOf(element(by.css(this.orderApproverErrorApprovalCss))),5000);
    return element(by.css(this.orderApproverErrorApprovalCss)).getText().then(function(text){
        logger.info(text);
        return text;
    });
};

//Additional Details Section

orders.prototype.getTextBasedOnLabelName = function(labelName){
	//util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath('//*[contains(text(), "'+labelName+'")]/following-sibling::p'))),60000);
	return element(by.xpath('//label[contains(text(), "'+labelName+'")]/following-sibling::p')).getText().then(function(text){
        logger.info("The value for "+labelName+" is : "+text)
        return text;
    });
};

orders.prototype.getSshKeyBasedOnLabelName = function(labelName){
	return element(by.xpath("//label[text()='"+labelName+"']/following-sibling::p")).getText().then(function(text){
        logger.info("The value for "+labelName+" is : "+text)
        return text;
    });
};

orders.prototype.getAllTextBasedOnLabelName = function(labelName){
	return element.all(by.xpath("//label[contains(text(), '"+labelName+"')]/following-sibling::p")).getText().then(function(textArray){
		var textList = [];
		logger.info("The length for "+labelName+" is : "+textArray.length);
		for (var i = 0; i < textArray.length; i++) {
			logger.info("The value for "+labelName+" is : "+textArray[i]);
			var str = textArray[i];
			if(str.includes(",")){
				textList.push(str.toString().split(","));
				logger.info("The value for "+labelName+" is : "+textList)
			}
		}
		var arrayList = [].concat.apply([], textList);
		var finalArray = [];
		for(i=0;i<arrayList.length;i++)
	    {
			finalArray[i] = arrayList[i].replace(/^\s\s*/, '').replace(/\s\s*$/, '');
	    }
		return finalArray;
	});
};

orders.prototype.getTextBasedOnExactLabelName = function (labelName) {
	browser.wait(EC.visibilityOf(element(by.xpath("//label[(text()='" + labelName + "')]/following-sibling::p"))),30000);
	browser.executeScript('window.scrollTo(0,0);');
	return element(by.xpath("//label[(text()='" + labelName + "')]/following-sibling::p")).getText().then(function (text) {
		logger.info("The value for " + labelName + " is : " + text)
		return text;
	});
};

//Check if order No found
orders.prototype.checkIfOrderFound = function(){
	return element(by.xpath(this.orderNotFoundTextXpath)).getText().then(function(message){
		//logger.info(text);
		return message.trim();
	}).catch(function(){
		return "Order Found";
	});
};

orders.prototype.validateOrderSummaryDetailsFields = function (loadBalObj, labelName) {

	var indexOfElem="undefined";
	var locatorValue = null;
	var elem = null;
	var flag;

	try {
		locatorValue = jsonUtil.getValueOfLocator(loadBalObj, labelName);

		if (labelName.includes("-")) {
			elem = labelName.split("-");
			indexOfElem = parseInt(elem[1]);
		}

		if (labelName.includes("_xpath")) {
			if (indexOfElem == "undefined") {
				return element(by.xpath(locatorValue)).getText().then(function (text) {
					flag = util.cmpValues(loadBalObj, labelName, text);
					return flag;
				});
			} else {
				return element.all(by.xpath(locatorValue)).get(indexOfElem).getText().then(function (text) {
					flag = util.cmpValues(loadBalObj, labelName, text);
					return flag;
				}).catch(function (error) {
					logger.info(error);
				});
			}
		} else {
			if (indexOfElem == "undefined") {
				return element(by.css(locatorValue)).getText().then(function (text) {
					flag = util.cmpValues(loadBalObj, labelName, text);
					return flag;
				});
			} else {
				return	element.all(by.css(locatorValue)).get(indexOfElem).getText().then(function (text) {
					flag = util.cmpValues(loadBalObj, labelName, text);
					return flag;
				});
			}
		}

	}
	catch (e) {
		logger.info(e);
	}

};

//validate cost of google service
orders.prototype.validatePriceForGoogleService = function(price) {

	return element(by.xpath(this.orderTotalCostXpath)).getText().then(function(text){
		price = price.split("/");
		if(text == price[0].trim()){
			logger.info("Total cost on Review order page and summary details page is : " + text);
			return Promise.resolve(true);
		}else{
			logger.info("Total cost on Review order page : " + price + " and on Orders Summary Details page : " + text);
			return Promise.resolve(false);
		}
	});

};

orders.prototype.clickMoreLinkBom = function(){
	return element(by.xpath(this.lnkMoreXpath)).click().then(function(){
		logger.info("Clicked on More link in Orders Page-->Bill of Materials section");

	});
};

orders.prototype.validateEstimatedCostAllServicesofCart = function(serviceListExp)
{
    var elmServiceName = element.all(by.xpath(this.tblServiceNameXpath));
	var cartListPage = new CartListPage();
	var ordersPage = new orders();
    let promiseArr = [];
	var finlValidn = false;

	browser.executeScript("arguments[0].scrollIntoView();", elmServiceName.last().getWebElement()).then(function(){
		elmServiceName.getText().then(function(textArray){
			for(var i = 0; i < textArray.length; i++){
				ordersPage.clickViewDetailsBasedOnIndex(i);
				//verify details from Bill of Materials Page.
				ordersPage.clickBillOfMaterialsTabOrderDetails();
				expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(serviceListExp[Object.keys(serviceListExp)[i]]);
				//Click on More link
				ordersPage.clickMoreLinkBom();
				cartListPage.clickExpandQuantity();
				finlValidn = cartListPage.getTotalPriceOfAllInstances();
				ordersPage.closeServiceDetailsSlider();
				promiseArr.push(finlValidn);
			}
		});

	}).catch(function(err){
		console.log(err);
	});

	return Promise.all(promiseArr).then(function(finlValidn) {
		if(finlValidn.indexOf(false) != -1){
			return Promise.resolve(false);
		}else{
			return Promise.resolve(true);
		}
	});
};

orders.prototype.clickViewDetailsBasedOnIndex = function (index){
	var curr = this;
	var eleToClick = element.all(by.xpath(this.tblViewDetailsXpath)).get(index + 2);
	var lnkViewDetails = element.all(by.buttonText(curr.buttonTextViewDetails)).get(index + 2);
	browser.wait(EC.elementToBeClickable(eleToClick), 60000).then(function () {
		browser.executeScript("arguments[0].scrollIntoView();", eleToClick.getWebElement()).then(function(){
			browser.sleep(5000);
			return eleToClick.click().then(function () {
				logger.info("Clicked on the Actions icon of the first row on Orders page");
				browser.wait(EC.visibilityOf(lnkViewDetails), 30000).then(function(){
					return lnkViewDetails.click().then(function () {
						logger.info("Clicked on View Details link to get Order Details page of service : " + index + 1);
						//Adding hardcoded sleep since it takes time to load order details page.
						browser.sleep(6000);
					});
				});

				util.waitForAngular();
			});
		});
	});
};

orders.prototype.getBudgetNameAllOrdersText = function () {
	var elem = element.all(by.css(this.textBudgetNameAllOrdersCss)).last();
	browser.wait(EC.visibilityOf(elem), 80000);
	return elem.getText().then(function (text) {
        logger.info("Budget name: " + text);
        return text;
    });
};

orders.prototype.getTextBudgetAmmount = function () {
	util.waitForAngular();
	var elem = element(by.css(this.budgetAmountCss));
	browser.wait(EC.visibilityOf(elem), 80000);
	browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());
	return element(by.css(this.budgetAmountCss)).getText().then(function (text) {
        logger.info("Budget Ammount : " + text);
        return text;
    });
};

orders.prototype.getTextAvailableBudget = function () {
	//util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.availableBudgetCss))), 120000);		
	return element(by.css(this.availableBudgetCss)).getText().then(function (text) {
        logger.info("Available Budget : " + text);
        return text;
    });
};
orders.prototype.getTextBudgetaryCommittedAmmount = function () {
	util.waitForAngular();
	var elem = element(by.css(this.CommittedAmmountCss));
	browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());

    return element(by.css(this.CommittedAmmountCss)).getText().then(function (text) {
        logger.info("Committed Ammount : " + text);
        return text;
    });
};
orders.prototype.getTextBudgetarySpendAmmount = function () {
	util.waitForAngular();
	var elem = element(by.css(this.spendAmmountCss));
	browser.wait(EC.visibilityOf(elem), 60000);		
	browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());
    return element(by.css(this.spendAmmountCss)).getText().then(function (text) {
        logger.info("Spend Ammount : " + text);
        return text;
	});
}
orders.prototype.getTextBudgetaryEstimatedAmmountforOrder = function () {
	util.waitForAngular();
	var elem = element(by.css(this.estimatedAmmountforOrderCss));
	browser.wait(EC.elementToBeClickable(elem), 60000);
	browser.executeScript("arguments[0].scrollIntoView(false);", elem.getWebElement());

	return elem.getText().then(function (text) {
		logger.info("Estimated Ammount of Order : " + text);
		return text;
		});
}
orders.prototype.getTextOtherOrdersAwaitingApproval = function () {
	util.waitForAngular();
	var elem = element(by.css(this.awaitingApprovalOrderAmountCss));
	browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());

	return element(by.css(this.awaitingApprovalOrderAmountCss)).getText().then(function (text) {
		logger.info("Othe Order Awaiting Approval Amount : " + text);
		return text;
		});
}
//Function to click on Select button from the Confirmation Budgetary Unit Selection pop-up
orders.prototype.clickOnSubmitButtonOfBudget = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.submitButtonBudgetXpath))), 9000);
	return element(by.xpath(this.submitButtonBudgetXpath)).click().then(function () {
		logger.info("Succesfully clicked on Select button");
	});

}


//This function will select the budget from the drop-down ons Approve order page
orders.prototype.selectBudgetaryUnit = function (BudgetName) {
	util.waitForAngular();
	var curr = this;
	//browser.ignoreSynchronization = true;
	var ordersPage = new orders();
	//browser.sleep(6000);
	var dropdown = element(by.xpath(curr.budgetDropdownId));
	browser.wait(EC.elementToBeClickable(dropdown), 180000).then(function(){
		logger.info("Budgetary dropdown is clickable");
	}).catch(function(err){
		logger.info("Dropdown is not displayed.");
	});
	//Select budget only if dropdown has multiple values
	return dropdown.isDisplayed().then(function (status, err) {
		if (err) {
			return false;
		}
		if(status == true){
			browser.executeScript("arguments[0].scrollIntoView();", dropdown.getWebElement());//.then(function () {
				// var dropdown = element(by.css("[id=\"" + defaultConfig.budgetDropdownCSS + "\"]"));
				browser.wait(EC.elementToBeClickable(dropdown), 300000).then(function () {
					dropdown.isEnabled().then(function (enabled) {
						if (enabled) {
							//dropdown.click().then(function(){ //*******Added below line of code for click***//
							browser.actions().mouseMove(dropdown).click().perform().then(function () {
								var dropDownValuesArray = element.all(by.xpath(curr.budgetDropdownListXpath));
								dropDownValuesArray.getText().then(function (textArray) {
									var isDropDownValuePresent = false;
									for (var i = 0; i < textArray.length; i++) {
										if (textArray[i] == BudgetName) {
											dropDownValuesArray.get(i).click().then(function () {
												logger.info("Selected " + BudgetName + " from budget dropdown");

											});
											isDropDownValuePresent = true;
										}
									}
									if (!isDropDownValuePresent) {
										dropDownValuesArray.get(0).getText().then(function (text) {
											dropDownValuesArray.get(0).click().then(function () {
												logger.info("Selected " + text + " from budget dropdown");
											});
										});
									}
								});
							});
						}
					});

				});
			//});
			ordersPage.clickOnSubmitButtonOfBudget();

		}
	}).catch(function(){
		logger.info("Budgetray dropdown not present");
	});
}

orders.prototype.calculateBudgetaryEstimatedAmmountforOrder = function (budgetDuration, totalCost) {
	var cost = parseFloat(("" + totalCost).replace(/[^\d\.]*/g, ''), 2).toFixed(2);
	var amount = cost * budgetDuration;
	amount = amount.toFixed(2);
	var estCost = amount.toString();
	var estCost1 = estCost.slice(0, (estCost.indexOf(".")) + 3);

	//append the currency unit
	var currencyUnit = ("" + totalCost).replace(/\d+([,.]\d+)?/g, '');
	var actualCostcost = currencyUnit + estCost1;

	logger.info("Calculated estimated amount for this order: " + actualCostcost);
	return actualCostcost;
}

orders.prototype.calculateAvailableBudgetAfterProvCompleted = function (availCost, estCost) {
	var availCost1 = parseFloat(("" + availCost).replace(/[^\d\.]*/g, ''), 2);
	var estCost1 = parseFloat(("" + estCost).replace(/[^\d\.]*/g, ''), 2);
	var amount = availCost1 - estCost1
	var amountAvail = amount.toString();
	amount = amount.toFixed(2);
	var actualAvailCost = (Number(amountAvail)).toFixed(2);

	//append the currency unit
	var currencyUnit = ("" + estCost).replace(/\d+([,.]\d+)?/g, '');
	var actualCost = currencyUnit + actualAvailCost;

	logger.info("Calculated Available Budget for this order after provisioning completed: " + actualCost);
	return actualCost;
}

orders.prototype.calculateCommittedAmountAfterProvCompleted = function (committedAmnt, estCost) {

	var committedCost1 = parseFloat(("" + committedAmnt).replace(/[^\d\.]*/g, ''), 2);
	var estCost1 = parseFloat(("" + estCost).replace(/[^\d\.]*/g, ''), 2);

	var amount = committedCost1 + estCost1
	amount = amount.toFixed(2);
	var amountToCommit = amount.toString();
	var actualCommitCost = (Number(amountToCommit)).toFixed(2);

	//append the currency unit
	var currencyUnit = ("" + estCost).replace(/\d+([,.]\d+)?/g, '');
	var actualCost = currencyUnit + actualCommitCost;

	logger.info("Calculated Committed Amount for this order after provisioning completed: " + actualCost);
	return actualCost;

}

orders.prototype.calculateEstCostAfterDeleting1MonthOrder = function (estCost, oneMonthCost) {
	var oneMonthCost = parseFloat(("" + oneMonthCost).replace(/[^\d\.]*/g, ''), 2);
	var estCost1 = parseFloat(("" + estCost).replace(/[^\d\.]*/g, ''), 2);
	var amount = estCost1 - oneMonthCost;
	amount = amount.toFixed(2);
	var estAmount = amount.toString();
	var actualEstCost = (Number(estAmount)).toFixed(2);

	//append the currency unit
	var currencyUnit = ("" + estCost).replace(/\d+([,.]\d+)?/g, '');
	var actualCost = "(" + currencyUnit + actualEstCost + ")";

	logger.info("Calculated Estimated Amount for the delete order: " + actualCost);
	return actualCost;

}

orders.prototype.calculateDeleteCommittedAmount = function (committedAmnt, estCost) {
	var commitCost = parseFloat(("" + committedAmnt).replace(/[^\d\.]*/g, ''), 2);
	var estCost1 = parseFloat(("" + estCost).replace(/[^\d\.]*/g, ''), 2);
	var amount = commitCost - estCost1;
	amount = amount.toFixed(2);
	var estAmount = amount.toString();
	var actualEstCost = (Number(estAmount)).toFixed(2);

	//append the currency unit
	var currencyUnit = ("" + committedAmnt).replace(/\d+([,.]\d+)?/g, '');
	var actualCost = currencyUnit + actualEstCost;

	logger.info("Calculated Committed Amount after one month order deleted: " + actualCost);
	return actualCost
}

orders.prototype.calculateAfterDeletingAvailBudget = function (availBudget, estCost) {
	var availBudget1 = parseFloat(("" + availBudget).replace(/[^\d\.]*/g, ''), 2);
	var estCost1 = parseFloat(("" + estCost).replace(/[^\d\.]*/g, ''), 2);
	var amount = availBudget1 + estCost1;
	amount = amount.toFixed(2);
	var estAmount = amount.toString();
	var actualAvailCost = (Number(estAmount)).toFixed(2);

	//append the currency unit
	var currencyUnit = ("" + availBudget).replace(/\d+([,.]\d+)?/g, '');
	var actualCost = currencyUnit + actualAvailCost;

	logger.info("Calculated Available Budget after deleting the order: " + actualCost);
	return actualCost

}

orders.prototype.calculateAfterProvOtherOrderAwaitingApprovalAmount = function (beforeProvOrderAwaitingApprovalAmount, estCost) {
	var costBeforeProvOrderAwaitingApproval = parseFloat(("" + beforeProvOrderAwaitingApprovalAmount).replace(/[^\d\.]*/g, ''), 2);
	var estCost1 = parseFloat(("" + estCost).replace(/[^\d\.]*/g, ''), 2);
	var amount = costBeforeProvOrderAwaitingApproval - estCost1;
	amount = amount.toFixed(2);
	var estAmount = amount.toString();
	var actualOrderAwaitingApprovalAmount = (Number(estAmount)).toFixed(2);

	//append the currency unit
	var currencyUnit = ("" + estCost).replace(/\d+([,.]\d+)?/g, '');
	var actualCost = currencyUnit + actualOrderAwaitingApprovalAmount;

	logger.info("Calculated Other Order Awaiting Approval Amount after provision: " + actualCost);
	return actualCost

};
//Function to verify the budget is present on the Approve order page
orders.prototype.checkInvisibilityOfBudgetDetails = function(){
       logger.info("Checking the visibility of budget on approve order page.");
	return element(by.id(this.budgetID)).isPresent();
}
orders.prototype.getEstimatedCost = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.bomTotalCostCss))),5000);

	return element(by.css(this.bomTotalCostCss)).getText().then(function(text){
		logger.info("Total Cost on Orders Page: " + text);
			return text;
		});
}

orders.prototype.getTrackingNumber = function(){
	var webElement = element(by.css(this.txtTrackingNumberCss));
	browser.wait(EC.visibilityOf(webElement),60000).then(function(){
		return webElement.getAttribute('value').then(function(requestNumber){
			logger.info("External tracking number is : " + requestNumber);
			return requestNumber;
		});
	});

}

orders.prototype.validatePricingCustomTemplate = function () {

    browser.executeScript("window.scrollTo(0, 150);");
    let promiseArr = [];
    var pricingValidn = false;
    var expOrderTotal = 0;
    var val;
    var orderPage = new orders();
    util.waitForAngular();

    var itemDescription = element.all(by.xpath(this.descriptionXpath));
    var totalMonthlyCharge = element.all(by.xpath(this.totalMonthlyChargeXpath));
    itemDescription.getText().then(function (itemsList) {
        totalMonthlyCharge.getText().then(function (monthlyChargeList) {
            for (var i = 0; i < monthlyChargeList.length; i++) {

                expect(monthlyChargeList[i]).not.toContain("NA");
                if (monthlyChargeList[i] != "NA") {
                    val = parseFloat(monthlyChargeList[i].split("+")[0].split("/")[0].replace("USD ", ""));
                    if (val != "0.00") {
                        logger.info("Total Monthly charges for :" + itemsList[i] + " is = " + monthlyChargeList[i]);
                        pricingValidn = true;
                    } else {
                        logger.info("Total Monthly charges for :" + itemsList[i] + " is =  - USD 0.00");
                    }
                    promiseArr.push(pricingValidn);
                    expOrderTotal = parseFloat(expOrderTotal) + parseFloat(val);
                } else {
                    logger.info("Total Monthly charges for :" + itemsList[i] + " is =  NA");
                    promiseArr.push(false);
                }
            }
        });

        orderPage.getTextTotalCostOnBillofMaterialsOrderDetails().then(function(estimatedCost){
            val = parseFloat(estimatedCost.replace("USD ", ""));
            expect(val.toFixed(4)).toEqual(expOrderTotal.toFixed(4));
            logger.info("Pricing for custom template is succesfully verified on Approve order page.");
        });

    });

    return Promise.all(promiseArr).then(function (pricingValidn) {
        if (pricingValidn.indexOf(false) != -1) {
            return Promise.resolve(false);
        } else {
            return Promise.resolve(true);
        }
    });

};

orders.prototype.getCurrencyFromEstimatedCostsTab = function(){
	browser.wait(EC.visibilityOf(element(by.xpath(this.orderTotalCostXpath))),5000);
	return element(by.xpath(this.orderTotalCostXpath)).getText().then(function(text){
		if(text == 'N/A'){
			logger.info("Cost under Estimated Costs Tab is :: "+text);
		}
		else{
			var str1 = text.substr(0,3);
			console.log(str1);
			//text = Math.round(str1).toString();
			logger.info("Currency shown in Orders Page :: "+text);
		}
		return text;
	})
}
orders.prototype.clickOnActionIcon = function(){
	var webElement = element(by.css(this.orderHistoryPageActionIconCss));
	browser.wait(EC.elementToBeClickable(webElement),60000).then(function(){
		webElement.click().then(function(){
			logger.info("Clicked on the Action Icon of the order review page");

		})
	});
}
orders.prototype.clickOnViewDetailsLink = function () {
	browser.ignoreSynchronization = true;
	let webElement = element(by.id(this.viewOrderDetailsLinkID));
	var self = this;
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(webElement), 900000).then(function () {
		webElement.click().then(function () {
			logger.info("Clicked on the View Details link from the order review page");
			util.waitForAngular();
			browser.sleep(5000);
			self.clickOnOrderUpdatesTab();
		});
	});
	browser.ignoreSynchronization = false;
}

orders.prototype.clickOnOrderUpdatesTab = function () {
	let webElement = element(by.css(this.orderUpdateTabId));
	browser.wait(EC.elementToBeClickable(webElement), 900000).then(function () {
		webElement.click().then(function () {
			logger.info("Clicked on the Update Details tab");
			util.waitForAngular();
			browser.sleep(2000);
		});
	});
}

orders.prototype.getTextSubmittedByUserDetails = function () {
	let elementOfSubmittedByUserDetails = element.all(by.className(this.submittedByUserDeatilsClassName)).get(0);
	//return browser.wait(EC.visibilityOf(elementOfSubmittedByUserDetails), 900000).then(function () {
		return elementOfSubmittedByUserDetails.getText().then(function (text) {
			//logger.info("Submitted By Text is " + text);
			return text;
		})
	//});
}


orders.prototype.verifyApprovalOrderStatus = function (approvalStatus) {
	return element.all(by.className(this.approvalStatusClassName)).getText().then(function (status) {
		for (let i = 0; i < 2; i++) {
			if (status[i] != approvalStatus) {
				return false;
			};
		};
		logger.info("Approval Status matched");
		return true;
	});
};


orders.prototype.expandTheFinancialApprovalFromTheOrderDetailsPage = function () {
	let webElementFinancialApprovalTab = element.all(by.css(this.expandApprovalTileCss)).get(0);
	//browser.wait(EC.elementToBeClickable(webElementFinancialApprovalTab), 9000).then(function () {
		webElementFinancialApprovalTab.click().then(function () {
			logger.info("Expanded the Financial Approval tab")
		})
	//})
};

orders.prototype.getFinancialApprovalDetails = function () {
	browser.wait(EC.visibilityOf(element.all(by.css(this.approvalDetailsTileCss)).get(0)))
	let webElementFinancialApprovall = element.all(by.css(this.approvalDetailsTileCss)).get(0);
	//browser.wait(EC.visibilityOf(webElementFinancialApprovall),9000);
	return webElementFinancialApprovall.getText().then(function (text) {
		//logger.info("Financial aproval users are : " + text);
		return text;
	})
};

orders.prototype.getTechnicalApproversDetails = function () {
	browser.wait(EC.visibilityOf(element.all(by.css(this.approvalDetailsTileCss)).get(0)))
	let webElementFinancialApprovall = element.all(by.css(this.approvalDetailsTileCss)).get(1);
	//browser.wait(EC.visibilityOf(webElementFinancialApprovall),9000);
	return webElementFinancialApprovall.getText().then(function (text) {
		//logger.info("Technical approval users are : " + text);
		return text;
	})
};


orders.prototype.expandTheTechnicalApprovalFromTheOrderDetailsPage = function () {
	let webElementFinancialApprovalTab = element.all(by.css(this.expandApprovalTileCss)).get(1);
	//browser.wait(EC.elementToBeClickable(webElementFinancialApprovalTab), 9000).then(function () {
		webElementFinancialApprovalTab.click().then(function () {
			logger.info("Expanded the Technical Approval tab");
		})
	//})
};

orders.prototype.clickOnCloseButtonOfViewDetailSlidder = function () {
	let webElement = element.all(by.css(this.closeButtonOfOrderDetailsSlidderCss)).get(1);
	//browser.wait(EC.visibilityOf(element(by.css(webElement))),9000);
	webElement.click().then(function () {
		logger.info("Clicked on closed button of view details slidder");
	})
};


orders.prototype.getOrderCompletedData = function(){
	//browser.wait(EC.visibilityOf(element(by.css(this.orderCompletedTextCss))),9000);
	return element.all(by.css(this.orderCompletedTextCss)).get(3).getText().then(function (text) {
		//logger.info("Completed Details are : " + text);
		return text;
	})
}
/*
 This function verifies the order update phases for both order and order history page 
 Input 1: orderstate : Values can vary between Submitted, Approved , Provisioning and Completed as mentioned in orderDetails.json file
 input 2: flag contains either 0 or 1
          flag 0: will consider Order--> order updates page
		  flag 1: will consider Order History--> order updates page
*/
orders.prototype.getTextOrderStateOnOrderUpdateTab = function (orderstate, flag) {
	browser.wait(EC.visibilityOf(element.all(by.xpath('//h3[text()="' + orderstate + '"]//parent::div//span//span')).get(flag).getText()), 120000);
	return element.all(by.xpath('//h3[text()="' + orderstate + '"]//parent::div//span//span')).get(flag).getText().then(function (text) {
		logger.info("Value taken from Order update page is :" + text);
		return text;    
	});
}
orders.prototype.getTextImiAddOn = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textImiAddOnCss))), 60000);
	return element(by.css(this.textImiAddOnCss)).getText().then(function(text){
        logger.info("The value for Imi addon - " +text);
        return text;
    });
};

orders.prototype.clickAddOnDetails = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.btnImiAddOnCss))),10000);
	return element.all(by.css(this.btnImiAddOnCss)).click().then(function(){
		logger.info("Approve Orders-->Order details -->Clicked on Add On Details");
		util.waitForAngular();
	});
};

orders.prototype.validateBOMDetailsWithImiAddOn = function(priceMap){
	var itemCostExp, priceMapCost;		
	return new Promise(async(resolve, reject) => {
		var itemDescription = element.all(by.css(this.txtDescriptionInBomTblCss)).getText();
		var itemCost = element.all(by.css(this.txtCostInBomTblCss)).getText();
		itemDescription.then(function(itemDescriptionList){
			itemCost.then(function(itemCostList){
				for(var i = 0; i<itemDescriptionList.length; i++){
					if((Object.keys(priceMap).includes(itemDescriptionList[i]))){
						//Validate pricing upto 2 decimals only
						itemCostExp = parseFloat((itemCostList[i]).replace("USD ", ""));
						itemCostExp = itemCostExp.toFixed(2);
						priceMapCost = parseFloat((priceMap[itemDescriptionList[i]]).replace("USD ", ""));
						priceMapCost = priceMapCost.toFixed(2);

						if(itemCostExp == priceMapCost){
							logger.info("Estimated cost matches for " + itemDescriptionList[i] + " = " + itemCostList[i])
						}else{
							logger.info("Estimated cost do not match for " + itemDescriptionList[i] + " = " + itemCostList[i])
							resolve(false);
						}

					}
				}			
				resolve(true);
			});		
		});	
	});	
};

orders.prototype.getTextBasedOnLabelNameandIndex = function(labelName, index){
    util.waitForAngular();
    browser.sleep(10000);
    var elemList = element.all(by.xpath("//*[contains(text(), '" + labelName + "')]/following-sibling::p"));
    return elemList.getText().then(function(textArray){
        logger.info("The value for "+labelName+" is : " + textArray[index])
        return textArray[index];
    });
};

orders.prototype.clickBOMTabImi = function(){
	util.waitForAngular();
	var elem = element(by.css(this.btnBomImiCss));
	browser.wait(EC.elementToBeClickable(elem), 30000);
	return elem.click().then(function(){
		logger.info("Clicked on bill of materials tab in IMI details");
	});
};

orders.prototype.validateBOMDetailsManagedService = function(priceMap){
	var itemCostExp, priceMapCost;		
	//return new Promise(async(resolve, reject) => {
		var itemDescription = element.all(by.xpath(defaultConfig.txtDescriptionInBomTblXpath)).getText();		
		return itemDescription.then(function(itemDescriptionList){			
				for(var i = 0; i<itemDescriptionList.length; i++){
					if((Object.keys(priceMap).includes(itemDescriptionList[i].replace("Pricing for ","")))){
						//Validate pricing upto 2 decimals only
						itemCostExp = parseFloat((itemDescriptionList[i+1]).replace("USD ", ""));
						itemCostExp = itemCostExp.toFixed(2);
						priceMapCost = parseFloat((priceMap[itemDescriptionList[i].replace("Pricing for ","")]).replace("USD ", ""));
						priceMapCost = priceMapCost.toFixed(2);

						if(itemCostExp == priceMapCost){
							logger.info("Estimated cost matches for " + itemDescriptionList[i] + " = " + itemCostExp)
						}else{
							logger.info("Estimated cost do not match for " + itemDescriptionList[i] + " = " + itemCostExp)
							return false;
						}

					}
				}			
				return true;			
		});	
	//});	
};

orders.prototype.roundOffEstimatedPricing = function(actPrice, expPrice){
	var priceExp = expPrice.split(" /Month")[0];
	priceExp = parseFloat(priceExp.replace("USD ", ""));
	priceExp = util.roundOffNumber(priceExp);
	
	//var priceExp = lambdaInstanceTemplate.EstimatedPriceWithAddOn
	var priceAct = actPrice.split(" /Month")[0];
	priceAct = parseFloat(priceAct.replace("USD ", ""));
	priceAct = util.roundOffNumber(priceAct);

	priceExp = "USD " + priceExp.toFixed(2) + " /Month + USD 0.00 one time charges apply"
	priceAct = "USD " + priceAct.toFixed(2) + " /Month + USD 0.00 one time charges apply"

	return[priceExp,priceAct];
};

orders.prototype.roundOffTotalCost = function(actPrice, expPrice){	
	var priceExp = parseFloat(expPrice.replace("USD ", ""));
	priceExp = util.roundOffNumber(priceExp);	
	
	var priceAct = parseFloat(actPrice.replace("USD ", ""));
	priceAct = util.roundOffNumber(priceAct);

	priceExp = "USD " + priceExp.toFixed(2); 
	priceAct = "USD " + priceAct.toFixed(2);

	return[priceExp,priceAct];
};

orders.prototype.validateOrderId = function(expOrderId, repeatCounter){
	var self = this;
// 	browser.wait(EC.visibilityOf(element(by.css("[id='" + expOrderId + "']"))),10000).then(function(){
// 		if(global.serviceName != undefined){
// 			var servicePrfx = element(by.xpath("//*[@id='carbon-deluxe-data-table-tableOrderServiceDetails']//td[1]//span[text()=' " + global.serviceName + " ']"));
// 			browser.wait(EC.visibilityOf(servicePrfx), 60000).then(function(){
// 				logger.info("Waiting for Service instance to display on orders page");
// 				return true;
// 			}).catch(function(){
// 				logger.info("Service instance matching orderId is not displayed");
// 				self.clickPendingApprovalUnderOrdersSection();
// 				self.clickAllOrdersUnderOrdersSection();					
// 				self.searchOrderById(expOrderId, repeatCounter - 1);
// 			});

// 		}else {
// 			return true;
// 		}
// 	}).catch(function(err){
// 		logger.info("Order id on orders page do not mactch with the searched orderId");
// 		self.clickPendingApprovalUnderOrdersSection();
// 		self.clickAllOrdersUnderOrdersSection();
// 		self.searchOrderById(expOrderId, repeatCounter - 1);
// 	});
	
	self.getTextFirstOrderIdOrdersTable().then(function (actOrdId) {			
		if (actOrdId === expOrderId) {
			//Validate if service instance name is matching
			if(global.serviceName != undefined){
				var servicePrfx = element(by.xpath("//*[@id='carbon-deluxe-data-table-tableOrderServiceDetails']//td[1]//span[text()=' " + global.serviceName + " ']"));
				browser.wait(EC.visibilityOf(servicePrfx), 60000).then(function(){
					logger.info("Waiting for Service instance to display on orders page");
					return true;
				}).catch(function(){
					logger.info("Service instance matching orderId is not displayed, Expected service instance - " + global.serviceName);
					self.clickPendingApprovalUnderOrdersSection();
					self.clickAllOrdersUnderOrdersSection();					
					self.searchOrderById(expOrderId, repeatCounter - 1);
				});

			}else {
				return true;
			}
		} else {
			logger.info("Order id on orders page do not mactch with the searched orderId");
			self.clickPendingApprovalUnderOrdersSection();
			self.clickAllOrdersUnderOrdersSection();
			self.searchOrderById(expOrderId, repeatCounter - 1);
		}			
	});
};

module.exports = orders;
