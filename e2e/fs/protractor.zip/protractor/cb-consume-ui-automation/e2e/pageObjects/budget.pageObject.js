"use strict";

var extend = require('extend');
var url = browser.params.url;
var util = require('../../helpers/util.js');
var CatalogPage = require('../pageObjects/catalog.pageObject.js');
var mcmpUIDataTemplate = require('../../testData/mcmp/mcmpUIData.json');
var logGenerator = require("../../helpers/logGenerator.js"),
logger = logGenerator.getApplicationLogger();
var jsonUtil = require('../../helpers/jsonUtil.js');
var timeout = require('../../testData/timeout.json');
var orderFlowUtil = require('../../helpers/orderFlowUtil.js');
var EC = protractor.ExpectedConditions;

var defaultConfig = {
		pageUrl:                      		url + '/budget',
		headerNameCss:						"a.header_nav",
		budgetTabCss:                       '#budgetLinkId',
		budgetTileCss:						'ibm-tile',
		//*******************Budgetry Page Web Elements**************************
		budgetryUnitsTextXpath:        		'//button[@id="addBudgetaryUnitBtn"]',
		addNewBudgetryUnitBtnXpath: 		'//button[@id="addBudgetaryUnitBtn"]',
		budgetryUnitsTableXpath:			"//*[@id='table-budgetaryUnitsTable']/table",
		addNewBudgetryUnitPanelXpath:		'//div[starts-with(@class, "bx--slide-over-panel show animating")]',
		addNewBudgetryUnitTextXpath:		'//h3[contains(text(), "Add New Budgetary Unit")]',
		textBudgetaryNameCss:               'input[name="name"]',
		budgetryNameCss:					"#name",
		budgetryUnitCodeCss:				"input[name='budgetUnitCode']",
		budgetryDescriptionCss:				"textarea[name='description']",
		budgetryExternalRefIdCss:			"textarea[name='budgetUnitExternalRefId']",
		budgetryOrganizationCss:			'#bx--dropdown-single-parent_team',
		budgetryEnvironmentCss:				'#dropdown-wrapper-env',
		budgetryApplicationCss:				'#dropdown-wrapper-app, #dropdown-wrapper-App',
		budgetryTeamCss:					'#bx--dropdown-single-parent_team',
		budgetryTermCss:					'#bx--dropdown-single-parent_term',
		budgetrySaveBtnXpath:				'(//button[@id="button-saveBudgetaryUnit"])[1]',
		budgetryCancelBtnCss:				'#button-cancelAddBudgetaryUnit',
		budgetaryPaginationDrpDwnCss:		"[id^='pagination-select-items-per-page']",
		budgetaryPaginationForwardbtnCss:	'#bx--pagination__forward-button-0',
		budgetaryPaginationTxt1Xpth:		'(//div[@class="bx--pagination__right"]//span[@class="bx--pagination__text"]/span)[1]',
		budgetaryPaginationTxt2Xpth:		'(//div[@class="bx--pagination__right"]//span[@class="bx--pagination__text"]/span)[2]',
		budgetMgmtSubHeadingCss:			'.ibm--page-header__sub-title',
		userNameCss:						'div.header.mcmp-header > div h1',
		budgetaryUnitTableColHeaderXpath:	'(//table[contains(@id,"carbon-deluxe-data-table-")])[1]//span//parent::th',
		budgetaryUnitTableColNamesXpath:	'(//table[contains(@id,"carbon-deluxe-data-table-")])[1]//th/span',
		budgetaryUnitTableRowsXpath:		'(//table[contains(@id,"carbon-deluxe-data-table-")])[1]//tbody/tr',
		buttonViewDetailsCss:               ".bx--overflow-menu-options__btn",
		//************************Budgetry Link WebElements*************************
		budgetryDetailsLinkCss:				'#tab-details-header',
		budgetryBudgetsLinkCss:				'#tab-budgets-header',
		relatedBudgetryUnitLinkCss:			'#related_budgetary_units',

		//************************Budgetry Submitted Page Details*******************
		budgetryDetailsUnitPanelXpath:			'//div[@class="bx--slide-over-panel show animating"]',
		budgetryDetailsUnitTextXpath:			'//h3[@class="bx--slide-over-panel-title"])[1]',
		budgetryDetailsNameXpath:				'//label[@class="bx--label"][contains(text(), "Name")]/following-sibling::div',
		budgetryDetailsUnitCodeXpath:			'//label[@class="bx--label"][contains(text(), "Budgetary Unit Identifier")]/following-sibling::div',
		budgetryDetailsDescriptionXpath:		'//label[@class="bx--label"][contains(text(), "Description")]/following-sibling::div',
		budgetryDetailsExternalRefIdXpath:		'//label[@class="bx--label"][contains(text(), "External Reference Id")]/following-sibling::div',
		budgetryDetailsOrganizationXpath:		'//span[@class="contextKey bold"][contains(text(), "Organization")]/following-sibling::span[@class="contextValue"]',
		budgetryDetailsEnvironmentXpath:		'//span[@class="contextKey bold"][contains(text(), "Environment")]/following-sibling::span[@class="contextValue"]',
		budgetryDetailsApplicationXpath:		'//span[@class="contextKey bold"][contains(text(), "Application")]/following-sibling::span[@class="contextValue"]',
		budgetryDetailsTermXpath:				'//label[@class="bx--label"][contains(text(), "Term")]/following-sibling::div',
		budgetryDetailsStatus:					'//label[@class="bx--label"][contains(text(), "Status")]/following-sibling::div',
		budgetryNoAssociationErrorMsgCss:		'[class^=bx--inline-notification__text-wrapper]',
		//budgetryNoAssociationErrorMsgXpath :      '(//div[@class="bx--inline-notification__text-wrapper"])[2]',
		budgetryAssociateCheckboxesXpath:		'//input[@class="bx--checkbox"][@type="checkbox"]/following-sibling::label[contains(@for, "checkbox")]',
		deleteBudgetryUnitBtnCss:				'#button-delete-budget-unit',
		deleteBudgetBtnCss:						'#budget-delete-button',
		deleteConfirmationBtnCss:				'#budget-confirm-delete',
		deactivateConfirmationBtnCss:			'#budget-confirm-inactivate',
		notificationMessageCss:					".bx--toast-notification__details",
		budgetDeletedMsgCss:					".bx--inline-notification__details span.body",
		deleteButtonXpath:					"//button[contains(text(), 'Delete')]",
		deactivateButtonXpath:					"//*[@id='inactivate-budgets']",
		budgetStatusTextXpath:					"//*[@id='carbon-deluxe-data-table-dataTableBudget']//tbody//td[2]//span[contains(text(),'{0}')]/ancestor::tr//td[8]//span/span",

		//************************Budgetary Details Edit Page Web Element****************************//
		budgetryEditBtnXpath:					'//button[@id="button-edit-budget-unit--button"]',
		budgetaryEditUnitTextXpath:				'//h3[contains(text(), "Edit Budgetary Unit")]',	
		budgetaryChangeStatusXpath:				'//span[@class="bx--toggle__text--left"]',
		budgetaryEditCancelButtonXpath:			'//button[@id="button-cancelEditBudgetaryUnit"]',
		budgetaryEditSaveButtonXpath:			'//*[@id="button-saveBudgetaryUnit"]',
		budgetaryEditUpdateSuccessMsgCss:		'.bx--toast-notification__title',
		budgetaryEditUpdateSuccessCloseXpath:	'//button[@class="bx--toast-notification__close-button"]',
		budgetryEnvironmentTextCss:             '#dropdown-wrapper-env',
		budgetryApplicationTextCss:             '#dropdown-wrapper-app, #dropdown-wrapper-App',
		budgataryEditErrorMsgCss:				'.bx--inline-notification__subtitle>span',
		budgetaryEditErrorMsgCloseBtnCss:		'.bx--inline-notification__close-icon',
		editBudgetButtonCss:					'#button-edit-budget-unit--button',
		
		
		//************************Budgetary budgets Web Element**************************************//
		budgetaryBudgetsAddBudgetButtonCss:			'#addBudget',
		budgetaryAddNewBudgetsTxtXpath:				'(//h3[contains(text(), "Add New Budget")])[1]',
		BudgetaryBudgetsCreateBudgetNameCss:		'input[name="name"]',
		BudgetaryBudgetsStatusActive:				'//label[text()="Status"]/following-sibling::carbon-toggle//span[@class="bx--toggle__text--right"]',
		CreateNewBudgetButtonCss:					'#createBudget',
		//NotificationMsgXpath:						'//carbon-notification[contains(@class, "bx--toast-notification")]//span',
		NotificationMsgCss:                         '.bx--toast-notification__title',
		NotificationErrorMsgCss:                    '.bx--toast-notification__subtitle',
		//NotificationCloseBtnCss:					'.bx--toast-notification__close-icon',
		NotificationCloseBtnXpath:                  '(//button[@class="bx--toast-notification__close-button"])[1]',
		BudgetDetailsStartPeriodCss:					'#create-budget-start-period-input',
		BudgetDetailsEndPeriodCss:					'#create-budget-end-period',
		buttonBackBudgetCss:					    '#button-cancelViewBudget',
		buttonEditBudgetCss:                        '#button-budget-edit-button',
		buttonSaveBudgetText:                        'Save',
	    buttonBudgetBackCss:                         '#button-cancelViewBudget',
	    actionIconbudgetViewDetailCss:               '#budget-overflow button',
	    buttonBudgetViewDetailCss:                   '.bx--overflow-menu-options__option-content',
		textBudgetInactivestatusCss:                 '#edit-toggle2 + label span:nth-child(2)',
		textBudgetSoftQuotaCss:						 '[for="add-toggle3"] span.bx--toggle__switch',
		textBudgetHardQuotaCss:						 '[for="add-toggle4"] span.bx--toggle__switch',
	    buttonBudgetSliderCloseCss:                  '[class="is-active"] button.bx--slide-over-panel--close',
		buttonLeftNavSubMenu:                        '.bx--side-nav__submenu',
		formValidationTextCss:						 "(//*[@name='{0}']/parent::div/following-sibling::div)[1]",
		formNameValidationTextXpath:				"//input[@name='{0}']/parent::div/following-sibling::div",
		thresholdRadioButton:						 "//*[@id='{0}']//input[@class='bx--radio-button' and @value='{1}']/following-sibling::label",
	    
         
		//************************Search Page Web Element********************************************//
		orderSearchTextBoxCss:	  			'#search__input-orders-search',

		//*****************Budget Details**************
		budgetTableXpath: '//table[@class="bx--data-table--sort bx--data-table--no-border bx--data-table"]',
		budgetTableMsgCss:						"#carbon-deluxe-data-table-dataTableBudget tbody h4 strong",
		budgetNameFromTableCss:					"#carbon-deluxe-data-table-dataTableBudget tbody td.bx--table-column:nth-child(2) .bx--tooltip-trigger.bx--tooltip-text",
		budgetTableCss:							"#carbon-deluxe-data-table-dataTableBudget",
        BudgetAmmountXpath: '//*[@id="text-input-create-budget-budget-amount"]',
		AvailableAmmountXpath: '//*[@id="text-input-create-budget-availableAmount"]',
		textCommittedAmountCss: '#create-budget-committedAmount',
		textUnderApprovalAmountCss: '#create-budget-underApprovalAmount',
		textActualCharges: '#create-budget-actualCharges',
        GetDetailsCss: ".table-cell-tooltip-width-reference",

		tblBudgetUnitXpath: '//*[@id="table-budgetaryUnitsTable"]/table//tr/td[2]',
		tblBudgetsXpath: '//table[@id="carbon-deluxe-data-table-2"]//tr/td[1]',
		buttonLeftSubmenuCss: '.bx--side-nav__submenu-title',
		buttonLeftSubmenuExpandXpath: '//*[@class="bx--side-nav__submenu-title"]/parent::button',
		budgetTableColHeaderXpath: '//table[@id="carbon-deluxe-data-table-dataTableBudget"]//span//parent::th',
		budgetTableColNamesXpath: '//table[@id="carbon-deluxe-data-table-dataTableBudget"]//th/span',
		budgetTableRowsXpath: '//table[@id="carbon-deluxe-data-table-dataTableBudget"]//tbody/tr',


		softQuotaMailTextboxCss : '#edit-budget-soft-threshold-emails',
		softQuotaEditedMailTextboxCss:'#create-budget-soft-threshold-emails',
		hardQuotaMailTextboxCss :'#edit-budget-hard-threshold-emails',
		hardQuotaEditedMailTextboxCss:'#budget-hard-threshold-emails',
		budgetAmountCss : '[name="budgetAmount"] input', 
		hardQuotaTextboxCss :'input[name="hqthresholdText"]',
		softQuotaTextboxCss :'input[name="sqthresholdText"]',
		softQuotaEditTextboxCss :'#create-budget-soft-threshold-text',
		hardQuotaEditTextboxCss :'#create-budget-hard-threshold-text',
		budgetaryNameDetailPageCss: 'div:nth-child(2) > p',
		budgetaryDescriptionCss : '#description',
		budgetaryExternalRefId : '#external_ref_id',
		budgetExternalRefIdCss:  'textarea[name="budgetExternalRefId"]',
		budgetRows: '#dataTableBudget tbody tr',
		bdgtPageForwardBtnCss:	'[class$="bx--pagination__button bx--pagination__button--forward bx--btn bx--btn--ghost bx--btn--icon-only"]',
		tblBudgetListCss : "[headers^='table-header-']",
		drpdownPagnCss: '.bx--pagination__right',
		btnAddBudgetSetCss: '#duplicateSet',
		textboxTotalBudgetAmount: '#text-input-total-amount',
		textboxBudgetAmount: 'input[name="budgetAmount"]',
		textboxBudgetAmountForEachQuarterCss: 'input[name="budgetAmount"]',
		textboxQuatBudgetName: '[id*="text-input-create-budget-name"]',
		tblQuatBdgtNameListCss: '#carbon-deluxe-data-table-dataTableBudget td:nth-child(2)',
		tblQuatBdgtAmntListCss: '#carbon-deluxe-data-table-dataTableBudget td:nth-child(3)',
		bdgtStatusToglBtnCss:'[for="edit_budgetary_status_toggle"]',
		btnBdgtSaveCss: '#button-saveEditBudget',
		bdgtUnitActionBtnCss : ".bx--overflow-menu svg",
		bdgtUnitViewDetailCss : ".bx--overflow-menu-options__option-content",
		bdgtActnBtnCss: "#budget-overflow svg",
		bdgtViewDetlBtnCss : "button[role='menuitem']",
		searchBoxBudgetaryUnitCss: "input[class^='bx--search-input']",
		searchIconCss: "div[id='budgetaryUnitsTable'] [class^='bx--search-magnifier']"
	};

//******** Order status *************
global.failedStatus = "Failed";
global.approvalInProgressStatus = 'Approval In Progress';
global.provisioningInProgressStatus = 'Provisioning in Progress';


function budget(selectorConfig) {
	if (!(this instanceof budget)) {
		return new budget(selectorConfig);
	}
	extend(this, defaultConfig);

	if (selectorConfig) {
		extend(this, selectorConfig);
	}
}

/**
 * Navigate to Budget page/URL
 */
budget.prototype.open = function()
{	
	var catalogPage = new CatalogPage();
	util.switchToDefault();
	this.clickOnHeaderName();
	//browser.waitForAngularEnabled(false);
	catalogPage.clickHamburgerCatalog();
	catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonAdmin);
	catalogPage.checkIfleftNavAdminExpanded();
	catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkBudget);
	//Validate if budget page is Displayed
	this.isPresentbudgetryUnitsText().then(function(budgetDisplayed){
		if(budgetDisplayed == false){
			//Navigate to budget page using url
			browser.get(url + "/budget");
			util.waitForAngular();
		}
	});
	this.waitForTableToLoad("1-10")
	browser.wait(EC.elementToBeClickable(element(by.css(this.searchIconCss))), 60000);

};

/**
 * Method to click on Header Name at top
 */
budget.prototype.clickOnHeaderName = function(){
	util.waitForAngular();	
	browser.sleep(2000);
	browser.wait(EC.elementToBeClickable(element(by.css(this.headerNameCss))), timeout.timeoutInMilis);
	element(by.css(this.headerNameCss)).click().then(function(){
		logger.info("Clicked on header name at top");
	});
};

/**
 * Verify 'Budgetary Units' text is present/displayed at top'
 */
budget.prototype.isPresentbudgetryUnitsText = function(){
	util.waitForAngular();
	browser.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.budgetryUnitsTextXpath))),40000).then(function(){
		logger.info("Waiting for budgetary page to display");
	}).catch(function(err){
		logger.info("Budgetary page is not displayed.")
	});
	return element(by.xpath(this.budgetryUnitsTextXpath)).isDisplayed().then(function(Status){
		logger.info("Budgetry units text is displayed..." + Status);
		return Status;
	});
};

/**
 * Verify 'Add New Budgetary Unit' button is displayed/Visible
 */

budget.prototype.isPresentAddNewBudgetryUnitBtn = function(){
	browser.wait(EC.visibilityOf(element(by.xpath(this.addNewBudgetryUnitBtnXpath))),30000);
	return element(by.xpath(this.addNewBudgetryUnitBtnXpath)).isDisplayed().then(function(){
		logger.info("Add New Budgetry Unit Btn is present...");
	});
};

/**
 * Click on the 'Add New Budgetary Unit' button
 */
budget.prototype.clickOnAddNewBudgetryUnitBtn = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.addNewBudgetryUnitBtnXpath))),30000);
	return element(by.xpath(this.addNewBudgetryUnitBtnXpath)).click().then(function(){
		logger.info("Clicked on the Add New Budgatry Unit Button...");
	});
};


/**
 * Verify Budgetary Unit table is displayed
 */
budget.prototype.isPresentBudgetryUnitsTable = function(){
	util.waitForAngular();
	browser.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.budgetryUnitsTableXpath))),30000);
	return element(by.xpath(this.budgetryUnitsTableXpath)).isDisplayed().then(function(){
		logger.info("budgetry Units Table is Displayed...");
		browser.waitForAngular();
	});
};

/**
 * Verify Add New budgetary unit panel is visible/Displayed
 */
budget.prototype.isPresentAddNewBudgetryUnitPanel = function(){
	browser.wait(EC.visibilityOf(element(by.xpath(this.addNewBudgetryUnitPanelXpath))),30000);
	return element(by.xpath(this.addNewBudgetryUnitPanelXpath)).isDisplayed().then(function(){
		logger.info("budgetry Units Pannel is displayed...");
	});
};

budget.prototype.closeBudgetSliderIfPresent = function(){
	var self = this;
	return element(by.xpath(self.addNewBudgetryUnitPanelXpath)).isPresent().then(function(res){
		if(res) {
			browser.wait(EC.visibilityOf(element(by.xpath(self.addNewBudgetryUnitPanelXpath))),30000);
			self.clickBudgetSliderCloseButton();
		}
		else {
			logger.info("Budget Slider is closed");
		}
	});
};

/**
 * Verify Add New budgetary unit panel is not visible
 */
budget.prototype.verifyAddNewBudgetryUnitPanelnotPresent = function(){
	browser.wait(EC.invisibilityOf(element(by.xpath(this.addNewBudgetryUnitPanelXpath))),30000).then(function(){
		logger.info("budgetry Units Pannel is not visible...");
	});
};

/**
 * Verify Form validations text under fields
 */
budget.prototype.verifyBudgetFormValidations = function(fieldName) {
	util.waitForAngular();
	var validationText = this.formValidationTextCss.format(fieldName);
	browser.wait(EC.presenceOf(element(by.xpath(this.addNewBudgetryUnitPanelXpath))),80000);
	return element(by.xpath(validationText)).isPresent().then(function(result){
		if (result == true){
			return element(by.xpath(validationText)).getText().then(function(text){
				logger.info("Validation text: " + text);
				return text;
			});
		}
		else{
			return result;
		}
	});
};
/**
 * Verify Form validations text under namefields
 */
budget.prototype.verifyBudgetFormNameValidations = function(fieldName) {
	var validationText = this.formNameValidationTextXpath.format(fieldName);
	browser.wait(EC.presenceOf(element(by.xpath(this.addNewBudgetryUnitPanelXpath))),30000);
	return element(by.xpath(validationText)).isPresent().then(function(result){
		if (result == true){
			return element(by.xpath(validationText)).getText().then(function(text){
				logger.info("Validation text: " + text);
				return text;
			});
		}
		else{
			return result;
		}
	});
};

/**
 * Verify Form validations text length inside fields
 */
budget.prototype.verifyBudgetFieldTextLength = function (fieldValue, len) {
	util.waitForAngular();
	browser.sleep(10000);
	return browser.wait(EC.presenceOf(element(by.xpath(this.addNewBudgetryUnitPanelXpath))), 90000).then(function () {
		logger.info("Actual length: " + fieldValue.length);
		if (fieldValue.length == len) {
			return true;
		}
		else if (fieldValue.length > len) {
			return false;
		}
	});
};

/**
 * Verify 'Add New Budgetary Unit' text is present at top while filling the form for 'New Budgetary unit'
 */
budget.prototype.isPresentAddNewBudgetryUnitText = function(){
	browser.wait(EC.visibilityOf(element(by.xpath(this.addNewBudgetryUnitTextXpath))),30000);
	return element(by.xpath(this.addNewBudgetryUnitTextXpath)).isDisplayed().then(function(){
		logger.info("budgetry Units Text is present...");
	});
};

/**
 * Set input for Name text box while filling the form for 'New Budgetary unit'
 */
budget.prototype.setTextBudgetryName = function(budgetryName){
	util.scrollToWebElement(element(by.css(this.textBudgetaryNameCss)));
	util.scrollToTop();
	browser.wait(EC.visibilityOf(element(by.css(this.textBudgetaryNameCss))),30000);
	util.waitForAngular();
	element(by.css(this.textBudgetaryNameCss)).clear();
	return element(by.css(this.textBudgetaryNameCss)).sendKeys(budgetryName).then(function(){
		logger.info("Budgetry name is entered...");
	});
};

/**
 * Set input for Budgetary_Unit_Identifier text box while filling the form for 'New Budgetary unit'
 */
budget.prototype.setTextBudgetryUnitCode = function(budgetryUnitCode){
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryUnitCodeCss))),30000);
	return element(by.css(this.budgetryUnitCodeCss)).sendKeys(budgetryUnitCode).then(function(){
		logger.info("Budgetry Unit Code is entered...");
	});
};

/**
 * Set input for budgetary Description text box while filling the form for 'New Budgetary unit'
 */
budget.prototype.setTextBudgetryDescription = function(budgetryDescription){
	var self = this;
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryDescriptionCss))),30000);
	util.waitForAngular();
	element(by.css(this.budgetryDescriptionCss)).clear().then(function(){
		logger.info("Cleared Budgetary Description");
		element(by.css(self.budgetryDescriptionCss)).sendKeys(budgetryDescription).then(function(){
			logger.info("Budgetry Description is entered...");
			// element(by.css(self.budgetryDescriptionCss)).sendKeys(protractor.Key.TAB);
			// browser.sleep(2000);
			browser.executeScript("document.activeElement.blur();")
		});
	})	
};

/**
 * Set input for budgetary External_Ref_ID text box while filling the form for 'New Budgetary unit'
 */
budget.prototype.setTextBudgetryExternalRefId = function (budgetryExternalRefId) {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryExternalRefIdCss))), 30000);
	util.waitForAngular();
	element(by.css(this.budgetryExternalRefIdCss)).clear();
	element(by.css(this.budgetryExternalRefIdCss)).sendKeys(budgetryExternalRefId).then(function () {
		logger.info("Budgetry ref Id is entered...");
		// element(by.css(defaultConfig.budgetryExternalRefIdCss)).sendKeys(protractor.Key.TAB);
		// browser.sleep(2000);
		browser.executeScript("document.activeElement.blur();")
	});
};

/**
 * Click on Save button available during filling the form for 'New Budgetary unit'
 */
budget.prototype.clickOnBudgetrySaveBtn = function(){
	//util.waitForAngular();
	//browser.wait(EC.visibilityOf(element(by.xpath(this.budgetrySaveBtnXpath))),30000);
	/*element(by.xpath(this.budgetrySaveBtnXpath)).getAttribute('disabled').then(function(attr){
	    expect(attr).toBe(false);
	});*/
	//expect(element(by.xpath(this.budgetrySaveBtnXpath)).isEnabled()).toBe(true);	
	//browser.waitForAngularEnabled(true);
	//browser.ignoreSynchronization = true;
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.budgetrySaveBtnXpath))),120000);
	return element(by.xpath(this.budgetrySaveBtnXpath)).click().then(function(){
		logger.info("Clicked on Save button for Budgatry...");
	});
};
/**
 * click on budget tab
 */
budget.prototype.clickBudgetTab = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.budgetTabCss))),30000);
	return element(by.css(this.budgetTabCss)).click().then(function(){
		logger.info("Clicked on Budget Tab...");
	});
};

/**
 * click on budget Edit tab
 */
budget.prototype.clickBudgetEditButton = function(){
	util.waitForAngular();
	browser.sleep(2000);
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonEditBudgetCss))),30000);
	return element(by.css(this.buttonEditBudgetCss)).click().then(function(){
		logger.info("Clicked on Budget Edit button...");
	});
};

/**
 * click on budget Inactive status option
 */
budget.prototype.clickBudgetInactiveStatusText = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.textBudgetInactivestatusCss))),30000);
	return element(by.css(this.textBudgetInactivestatusCss)).click().then(function(){
		logger.info("Clicked on Budget page Inactive Status...");
	});
};

/**
 * click on budget soft quota option
 */
budget.prototype.clickBudgetSoftQuotaText = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.textBudgetSoftQuotaCss))),60000);
	return element(by.css(this.textBudgetSoftQuotaCss)).click().then(function(){
		logger.info("Clicked on Budget page Soft quota...");
	});
};

/**
 * click on budget hard quota option
 */
budget.prototype.clickBudgetHardQuotaText = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.textBudgetHardQuotaCss))),30000);
	return element(by.css(this.textBudgetHardQuotaCss)).click().then(function(){
		logger.info("Clicked on Budget page Hard quota...");
	});
};

/**
 * click on save budget after Editing 
 */
budget.prototype.clickSaveBudgetButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.btnBdgtSaveCss))),30000);
	return element(by.css(this.btnBdgtSaveCss)).click().then(function(){
		logger.info("Clicked on Save Budget button...");
	});
};

/**
 *  click on budget back button after Editing
 */
budget.prototype.clickAfterEditingBudgetaryBackButton = function(){
   util.waitForAngular();
   browser.sleep(3000);
   browser.executeScript("document.getElementById('button-cancelViewBudget').scrollIntoView()");
   var backBudgetBtnEle = element(by.css(this.buttonBudgetBackCss));
    browser.wait(EC.elementToBeClickable(backBudgetBtnEle),30000).then(function(){
     logger.info("Budgatary Back Budget Button is Clickable...");
    });	
    element(by.css(this.buttonBudgetBackCss)).click().then(function(){
    	logger.info("Clicked on Budget back Button after editing ...");
    });	
    //browser.wait(EC.visibilityOf(element(by.css(this.budgetTableCss))), timeout.timeoutInMilis);
};

/**
 * click on budget view detail action icon
 */
budget.prototype.clickViewDetailActionIcon = function(){
	browser.wait(EC.visibilityOf(element(by.xpath(this.budgetTableXpath))), timeout.timeoutInMilis)
	browser.wait(EC.elementToBeClickable(element(by.css(this.actionIconbudgetViewDetailCss))),30000);
	return element(by.css(this.actionIconbudgetViewDetailCss)).click().then(function(){
		logger.info("Clicked on Budget action icon ...");
	});
};

/**
 * click on budget view detail button
 */
budget.prototype.clickViewDetailBtn = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonBudgetViewDetailCss))),30000);
	return element(by.css(this.buttonBudgetViewDetailCss)).click().then(function(){
		logger.info("Clicked on Budget view detail button...");
		util.waitForAngular();
	});
};

/**
 * Method to select the budgetary unit and budget based on input provided
 * @input budgetaryUnit name or budget name
 */
budget.prototype.selectCheckBoxBasedOnName = function(input){
	//util.waitForAngular();
	var checkBoxEleme = element.all(by.css("label[aria-label*='Select row']"));
	browser.wait(EC.elementToBeClickable(checkBoxEleme.first()),30000).then(function(){
		checkBoxEleme.first().isDisplayed().then(function(){
			logger.info("Checkbox displayed...");
			browser.sleep(2000);
			checkBoxEleme.first().click().then(function(){
				logger.info("Selected checkbox for the budgetary unit or budget for name ..."+ input);
			});
		});
	});
};

/**
 * click on Delete button for the selected items
 */
budget.prototype.clickonDeleteBtnForSelectedItem = function(){
	browser.wait(EC.elementToBeClickable(element.all(by.xpath(this.deleteButtonXpath)).first()), timeout.timeoutInMilis);
	return element.all(by.xpath(this.deleteButtonXpath)).first().click().then(function(){
		logger.info("Clicked on Delete button for the selected items...");
	});
};

/**
 * click on Deactivate button for the selected items
 */
budget.prototype.clickonDeactivateBtnForSelectedItem = function(){
	browser.wait(EC.elementToBeClickable(element.all(by.xpath(this.deactivateButtonXpath)).last()), timeout.timeoutInMilis);
	return element.all(by.xpath(this.deactivateButtonXpath)).last().click().then(function(){
		logger.info("Clicked on Deactivate button for the selected items...");
	});
};

/**
 * Click on delete confirmation button for selected items based on index
 */
budget.prototype.clickOnDeleteConfirmationBtn = function(index){
	var deleteConfButtonEle = element.all(by.css(this.deleteConfirmationBtnCss)).get(0);
	browser.wait(EC.elementToBeClickable(deleteConfButtonEle),30000);
	deleteConfButtonEle.click().then(function(){
		logger.info("Clicked on budgatary delete confirmation Button...");
	});
};

/**
 * Click on deactivate confirmation button for selected items
 */
budget.prototype.clickOnDeactivateConfirmationBtn = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.deactivateConfirmationBtnCss))),30000);
	element(by.css(this.deactivateConfirmationBtnCss)).click().then(function(){
		browser.sleep(5000);
		logger.info("Clicked on budget deactivate confirmation Button...");
	});
};

/**
 * Check whether the budget is active or inactive
 */
budget.prototype.isBudgetActive = function(budgetName){
	var status = this.budgetStatusTextXpath.format(budgetName);
	browser.wait(EC.visibilityOf(element(by.xpath(status))),30000);
	return element(by.xpath(status)).getText().then(function(text){
		if(text.includes("Active")){
			logger.info("Budget Status is : " + text);
			return true;
		}
		else{
			logger.info("Budget Status is : " + text);
			return false;
		}
	});
};

/**
 * Click on Cancel button available during filling the form for 'New Budgetary unit'
 */
budget.prototype.clickOnBudgetryCancelBtn = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryCancelBtnCss))),30000);
	browser.wait(EC.elementToBeClickable(element(by.css(this.budgetryCancelBtnCss))),30000);
	browser.sleep(5000);
	return element(by.css(this.budgetryCancelBtnCss)).click().then(function(){
		logger.info("Clicked on Cancel button for Budgatry...");
	});
};

/**
 * Click on Details links from budgetary unit panel
 */
budget.prototype.clickOnBudgetryDetailsLink = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.budgetryDetailsLinkCss))),30000);
	return element(by.css(this.budgetryDetailsLinkCss)).click().then(function(){
		logger.info("Clicked on budgatry Details Link...");
	});
};

/**
 * Click on budgets links from budgetary unit panel
 */
budget.prototype.clickOnBudgetryBudgetsLink = function(){
	util.waitForAngular();
	var budgetsLink = element(by.css(this.budgetryBudgetsLinkCss));
	browser.wait(EC.visibilityOf(budgetsLink),90000)
	browser.wait(EC.elementToBeClickable(budgetsLink),90000).then(function(){
		budgetsLink.isDisplayed().then(function(){
			logger.info("Budgets link displayed...");
			browser.sleep(3000);
			return budgetsLink.click().then(function(){
				logger.info("Clicked on budgatry Budgets Link...");
			});
		})
	});
};

/**
 * Click on Related_budgetary_Unit links from budgetary unit panel
 */
budget.prototype.clickOnRelatedBudgetryUnitLink = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.relatedBudgetryUnitLinkCss))),30000);
	return element(by.css(this.relatedBudgetryUnitLinkCss)).click().then(function(){
		logger.info("Clicked on budgatry Details Link...");
	});
};


//*********************Function for Budgetary Submitted Page**********************//
/**
 * Verify budgetary details unit panel is present in the budgetary details page
 */
budget.prototype.isPresentBudgetryDetailsUnitPanel = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.budgetryDetailsUnitPanelXpath))),30000);
	return element(by.xpath(this.budgetryDetailsUnitPanelXpath)).isDisplayed().then(function(){
		logger.info("budgetry Details Unit Panel is present...");
	});
};

/**
 * Verify Budgetary Title is present in budgetary details page
 */
budget.prototype.isPresentBudgetryDetailsUnitText = function(){
	browser.wait(EC.visibilityOf(element(by.xpath(this.budgetryDetailsUnitTextXpath))),30000);
	return element(by.xpath(this.budgetryDetailsUnitTextXpath)).isDisplayed().then(function(){
		logger.info("budgetry details unit text is present.....");
	});
};

/**
 * Retrieve budgetary Name text from budgetary details page
 */
budget.prototype.getTextBudgetryDetailsName = function() {
	browser.wait(EC.visibilityOf(element.all(by.xpath(this.budgetryDetailsNameXpath)).get(1)),30000);
	browser.sleep(3000);
	return element.all(by.xpath(this.budgetryDetailsNameXpath)).get(1).getText().then(function(text){
		logger.info("budgetry Details Name text :  "+text);
		return text;
	});
};

/**
 * Retrieve budgetary Unit Code text from budgetary details page
 */
budget.prototype.getTextBudgetryDetailsUnitCode = function() {
	browser.wait(EC.visibilityOf(element.all(by.xpath(this.budgetryDetailsUnitCodeXpath)).get(1)),30000);
	return element.all(by.xpath(this.budgetryDetailsUnitCodeXpath)).get(1).getText().then(function(text){
		logger.info("budgetry Details UnitCode text :  "+text);
		return text;
	});
};

/**
 * Retrieve budgetary Description text from budgetary details page
 */
budget.prototype.getTextBudgetryDetailsDescription = function() {
	browser.wait(EC.visibilityOf(element.all(by.xpath(this.budgetryDetailsDescriptionXpath)).get(1)),30000);
	return element.all(by.xpath(this.budgetryDetailsDescriptionXpath)).get(1).getText().then(function(text){
		logger.info("budgetry Details Description text :  "+text);
		return text;
	});
};

/**
 * Retrieve budgetary External-Ref-Id text from budgetary details page
 */
budget.prototype.getTextBudgetryDetailsExternalRefId = function() {
	browser.wait(EC.visibilityOf(element.all(by.xpath(this.budgetryDetailsExternalRefIdXpath)).get(1)),30000);
	return element.all(by.xpath(this.budgetryDetailsExternalRefIdXpath)).get(1).getText().then(function(text){
		logger.info("budgetry Details ExternalRefId text :  "+text);
		return text;
	});
};

/**
 * Retrieve budgetary organization text from budgetary details page
 */
budget.prototype.getTextBudgetryDetailsOrganization = function() {
	browser.wait(EC.visibilityOf(element(by.xpath(this.budgetryDetailsOrganizationXpath))),30000);
	return element(by.xpath(this.budgetryDetailsOrganizationXpath)).getText().then(function(text){
		logger.info("budgetry Details Organization text :  "+text);
		return text;
	});
};

/**
 * Retrieve budgetary environment text from budgetary details page
 */
budget.prototype.getTextBudgetryDetailsEnvironment = function() {
	browser.wait(EC.visibilityOf(element(by.xpath(this.budgetryDetailsEnvironmentXpath))),30000);
	return element(by.xpath(this.budgetryDetailsEnvironmentXpath)).getText().then(function(text){
		logger.info("budgetry Details Environment text :  "+text);
		return text;
	});
};

/**
 * Retrieve budgetary application text from budgetary details page
 */
budget.prototype.getTextBudgetryDetailsApplication = function() {
	browser.wait(EC.visibilityOf(element(by.xpath(this.budgetryDetailsApplicationXpath))),30000);
	return element(by.xpath(this.budgetryDetailsApplicationXpath)).getText().then(function(text){
		logger.info("budgetry Details Application text :  "+text);
		return text;
	});
};

/**
 * Retrieve budgetary Term text from budgetary details page
 */
budget.prototype.getTextBudgetryDetailsTerm = function() {
	browser.wait(EC.visibilityOf(element(by.xpath(this.budgetryDetailsTermXpath))),30000);
	return element(by.xpath(this.budgetryDetailsTermXpath)).getText().then(function(text){
		logger.info("budgetry Details Term text :  "+text);
		return text;
	});
};

/**
 * Retrieve budgetary status text from budgetary details page
 */
budget.prototype.getTextBudgetryDetailsStatus = function() {
	browser.wait(EC.visibilityOf(element(by.xpath(this.budgetryDetailsStatus))),30000);
	return element(by.xpath(this.budgetryDetailsStatus)).getText().then(function(text){
		logger.info("budgetry Details status text : "+text);
		return text;
	});
};

/**
 * Retrieve error text message for creating the new budgetary unit without checking any Association check-box while adding the new budgetary unit.. 
 */
budget.prototype.getTextBudgetryNoAssociationErrorMessage = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryNoAssociationErrorMsgCss))),30000);
	return element(by.css(this.budgetryNoAssociationErrorMsgCss)).getText().then(function(text){
		logger.info("budgetry Details No Association error message :  "+text);
		return text;
	});
};

/**
 * Click on the all the budgetary association check box while adding the new budgetary unit 
 */
budget.prototype.checkAlltheBudgetryAssociateCheckboxes = function() {
	element.all(by.xpath(this.budgetryAssociateCheckboxesXpath)).then(function(array){
		logger.info("Check Box Ele Length : "+ array.length);	
	});

	element.all(by.xpath(this.budgetryAssociateCheckboxesXpath)).each(function(element, index){
		browser.wait(EC.elementToBeClickable(element),30000);
		element.click().then(function(text){
			logger.info("Checked Association check box : "+ index);
		});
	});
};

//*********************Function for Budgetary Edit Page**********************//

/**
 * Check budgetary details unit panel is displayed.. 
 */
budget.prototype.isPresentBudgetryDetailsUnitPanel = function(){
	browser.wait(EC.visibilityOf(element(by.xpath(this.budgetryDetailsUnitPanelXpath))),30000);
	return element(by.xpath(this.budgetryDetailsUnitPanelXpath)).isDisplayed().then(function(){
		logger.info("budgetary Details Unit Panel is present...");
	});
};

/**
 * Click on edit budgetary button from budgetary unit details page
 */
budget.prototype.clickOnEditBudgetaryButton = function(){
	util.waitForAngular();
	browser.sleep(3000);
	var editButton = element(by.xpath(this.budgetryEditBtnXpath));
	browser.wait(EC.elementToBeClickable(editButton),30000);
	//element(by.xpath(this.budgetryEditBtnXpath)).click().then(function(){
	browser.executeScript("arguments[0].click();", editButton.getWebElement()).then(function(){
		logger.info("Clicked on budgatary Edit Button...");
		util.waitForAngular();
	});
};

/**
 * Click on delete budgetary button from budgetary unit details page
 */
budget.prototype.clickOnDeleteBtnFromBudgetaryDetailsPage = function(){
	var deleteButtonEle = element(by.css(this.deleteBudgetryUnitBtnCss));
	browser.wait(EC.elementToBeClickable(deleteButtonEle),60000);
	browser.executeScript("arguments[0].click();", deleteButtonEle.getWebElement()).then(function(){
		logger.info("Clicked on budgatary delete Button...");
		browser.sleep(2000);
	});
};


/**
 * Click on delete budget button from budget details page
 */
budget.prototype.clickOnDeleteBtnFromBudgetDetailsPage = function(){
	var deleteButtonEle = element(by.css(this.deleteBudgetBtnCss));
	browser.wait(EC.elementToBeClickable(deleteButtonEle),30000);
	browser.executeScript("arguments[0].click();", deleteButtonEle.getWebElement()).then(function(){
		logger.info("Clicked on budget delete Button...");
	});
};

/**
 * Click on delete confirmation button from budgetary unit details page
 */
budget.prototype.clickOnDeleteConfirmationButton = function(){
	var deleteConfButtonEle = element.all(by.css(this.deleteConfirmationBtnCss)).get(0);
	browser.wait(EC.elementToBeClickable(deleteConfButtonEle),60000);
	deleteConfButtonEle.click().then(function(){
		logger.info("Clicked on budgatary delete confirmation Button...");
	});
};


/**
 * Notification message
 */
budget.prototype.getNotificationMsg = function(){
	browser.wait(EC.visibilityOf(element.all(by.css(this.notificationMessageCss)).get(0)),90000);
	return element.all(by.css(this.notificationMessageCss)).get(0).getText().then(function(text){
		logger.info("Notification message :  "+text);
		return text;
	});
}

/**
 * Budget deleted message
 */
budget.prototype.getBudgetDeletedMsg = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.budgetDeletedMsgCss))),9000);
	return element(by.css(this.budgetDeletedMsgCss)).getText().then(function(text){
		logger.info("Budget deleted message :  "+text);
		return text;
	});
}

/**
 * No data available message if there is no budget available
 */
budget.prototype.getBudgetTableMessage = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.budgetTableMsgCss))),9000);
	return element(by.css(this.budgetTableMsgCss)).getText().then(function(text){
		logger.info("Budget table message :  "+text);
		return text.toString().trim();
	});
}

/**
 * Method to get budget name from budget table
 */
budget.prototype.getBudgetName = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.budgetNameFromTableCss))),9000);
	return element(by.css(this.budgetNameFromTableCss)).getText().then(function(text){
		logger.info("Budget name :  "+text);
		return text.toString().trim();
	});
}

/**
 * Verify Edit budgetary Unit text is present while editing budgetary unit
 */
budget.prototype.isPresentBudgetryEditDetailsTxt = function(){
	browser.wait(EC.visibilityOf(element(by.xpath(this.budgetaryEditUnitTextXpath))),30000);
	return element(by.xpath(this.budgetaryEditUnitTextXpath)).isDisplayed().then(function(){
		logger.info("Edit budgetary Unit text is present...");
	});
};

budget.prototype.getNoOfRowsBudget = function(){
	var rows = element.all(by.css(this.budgetRows));
	return rows.count().then(function(rowCount){
		logger.info("Row count is: " + rowCount);
		return rowCount;
	});
};

/**
 * Verify Warning message when deleting budget
 */
budget.prototype.getTextDeleteBudgetWarningMsg = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.budgataryEditErrorMsgCss))),9000);
	return element(by.css(this.budgataryEditErrorMsgCss)).getText().then(function(text){
		logger.info("Budget delete warning message :  "+text);
		return text;
	});
}

/**
 * Verify Success message when deactivating budget
 */
budget.prototype.getTextDeactivatingBudgetSuccessMsg = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.budgataryEditErrorMsgCss))),9000);
	return element(by.css(this.budgataryEditErrorMsgCss)).getText().then(function(text){
		logger.info("Budget deactivate success message :  "+text);
		return text;
	});
}

/**
 * Verify Error message when editing budgetary unit having active budget
 */
budget.prototype.getTextEditBudgetaryUnitErrorMsg = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.budgataryEditErrorMsgCss))),9000);
	return element(by.css(this.budgataryEditErrorMsgCss)).getText().then(function(text){
		logger.info("Budgetary unit edit error message :  "+text);
		return text;
	});
}

/**
 * Click on close icon from error message while editing budgetary unit 
 */
budget.prototype.clickOnErrorMsgCloseBtn = function(){
	var errMsgClose = element(by.css(this.budgetaryEditErrorMsgCloseBtnCss));
	browser.wait(EC.visibilityOf(errMsgClose),9000);		
	errMsgClose.click().then(function(){
		logger.info("Clicked on Error Message close Button...");
	});	
};

/**
 * Retrieve text message from 'Edit budgetary unit' text box while editing budgetary unit 
 */
budget.prototype.getTextBudgetryNameFromEditPage = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryNameCss))),30000);
	return element(by.css(this.budgetryNameCss)).getAttribute("value").then(function(text){
		logger.info("budgetary Name from Edit details page text :  "+text);
		return text;
	});
};

/**
 * Retrieve text message from budget unit-code text field while editing budgetary unit 
 */
budget.prototype.getTextBudgetryUnitCodeFromEditPage = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryUnitCodeCss))),30000);
	return element(by.css(this.budgetryUnitCodeCss)).getAttribute("value").then(function(text){
		logger.info("budgetary Unit Code from Edit details page text :  "+text);
		return text;
	});
};

/**
 * Retrieve text message from description text box while editing budgetary unit 
 */
budget.prototype.getTextBudgetryDescriptionFromEditPage = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryDescriptionCss))),30000);
	return element(by.css(this.budgetryDescriptionCss)).getAttribute("value").then(function(text){
		logger.info("budgetary Description from Edit details page text :  "+text);
		return text;
	});
};

/**
 * Retrieve text message from external reference id text box while editing budgetary unit
 */
budget.prototype.getTextBudgetryExternalRefIdFromEditPage = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryExternalRefIdCss))),30000);
	return element(by.css(this.budgetryExternalRefIdCss)).getAttribute("value").then(function(text){
		logger.info("budgetary External Ref Id from Edit details page text :  "+text);
		return text;
	});
};

/**
 * Retrieve text message from organization drop-down while editing budgetary unit
 */
budget.prototype.getTextBudgetryOrganizationFromEditPage = function() {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryOrganizationCss))),30000);
	return element(by.css(this.budgetryOrganizationCss)).getText().then(function(text){
		logger.info("budgetary Organization from Edit details page text :  "+text);
		return text;
	});
};

/**
 * Retrieve text message from environment drop-down while editing budgetary unit
 */
budget.prototype.getTextBudgetryEnvironmentFromEditPage = function() {
	browser.sleep(3000);
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryEnvironmentTextCss))),30000);
	return element(by.css(this.budgetryEnvironmentTextCss)).getAttribute("innerText").then(function(text){
		logger.info("budgetary Environment from Edit details page text :  "+text);
		return text;
	});
};

/**
 * Retrieve text message from Application drop down while editing budgetary unit
 */
budget.prototype.getTextBudgetryApplicationFromEditPage = function() {
	browser.sleep(3000);
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryApplicationTextCss))),30000);
	return element(by.css(this.budgetryApplicationTextCss)).getAttribute("innerText").then(function(text){
		logger.info("budgetary Application from Edit details page text :  "+text);
		return text;
	});
};

/**
 * Retrieve text message from team drop down while editing budgetary unit
 */
budget.prototype.getTextBudgetryTeamFromEditPage = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryTeamCss))),30000);
	return element(by.css(this.budgetryTeamCss)).getText().then(function(text){
		logger.info("budgetary Team from Edit details page text :  "+text);
		return text;
	});
};

/**
 * Retrieve text message from budget term drop down while editing budgetary unit
 */
budget.prototype.getTextBudgetryTermFromEditPage = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.budgetryTermCss))),30000);
	return element(by.css(this.budgetryTermCss)).getText().then(function(text){
		logger.info("budgetary Term from Edit details page text :  "+text);
		return text;
	});
};

/**
 * Click on budgetary status change slider while editing the budgetary unit
 */
budget.prototype.clickOnBudgetaryStatusChangeButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.budgetaryChangeStatusXpath))),30000);
	return element(by.xpath(this.budgetaryChangeStatusXpath)).click().then(function(){
		logger.info("Clicked on budgatary status change Button...");
	});
};

/**
 * Click on budgetary edit cancel button 
 */
budget.prototype.clickOnBudgetaryEditCancelButton = function(){
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.budgetaryEditCancelButtonXpath))),30000);
	return element(by.xpath(this.budgetaryEditCancelButtonXpath)).click().then(function(){
		logger.info("Clicked on budgatary Edit cancel Button...");
	});
};

/**
 * Click on budgetary edit update button
 */
budget.prototype.clickOnBudgetaryEditUpdateButton = function(){
	browser.ignoreSynchronization = true;
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.budgetaryEditSaveButtonXpath))),20000);
	return element(by.xpath(this.budgetaryEditSaveButtonXpath)).click().then(function(){
		logger.info("Clicked on budgatary Edit Update Button...");
	});
};

/**
 * Verify Success message notification is present after clicking on the update button
 */
budget.prototype.isPresentBudgetryEditUpdateSuccessMsg = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.budgetaryEditUpdateSuccessMsgCss))),30000);
	return element(by.css(this.budgetaryEditUpdateSuccessMsgCss)).isDisplayed().then(function(){
		logger.info("budgetry Edit update success message is displayed...");
	});
};

/**
 * Click on Success Notification close button after updating the budgetary unit
 */
budget.prototype.clickOnBudgetaryEditUpdateSuccessCloseButton = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.budgetaryEditUpdateSuccessCloseXpath))),120000);
	element(by.css(this.budgetaryEditUpdateSuccessMsgCss)).getText().then(function(text){
		logger.info(text)
		element(by.xpath(defaultConfig.budgetaryEditUpdateSuccessCloseXpath)).click().then(function () {
			logger.info("Clicked on budgatary Edit Update success close Button...");
		});
	})
};

//************************************ Budgetary unit details Table functions *******************/

/**
 * Select last value from budgetary pagination drop-down
 */
budget.prototype.selectbudgetaryPaginationDropDown = function(){
	var dropdown = element(by.css(this.budgetaryPaginationDrpDwnCss));
	util.waitForAngular();	
	browser.wait(EC.elementToBeClickable(dropdown), 60000).then(function(){	
		dropdown.isEnabled().then(function (enabled) {
			if(enabled){
				dropdown.click().then(function(){
					var dropDownValuesArray = element.all(by.css("#budgetaryUnitsTable option")).get(2);
					dropDownValuesArray.getText().then(function (textArray) {					
						browser.sleep(2000);
						dropDownValuesArray.click().then(function() {
							logger.info("Selected " + textArray + " from pagination dropdown");
						});
					});
				});
			}
		});                      

	});

};

//Check budgetary Unit name in the Budgetary Table
budget.prototype.checkBudgetaryNameInBudgetaryUnitTable = function(budgetaryNameText){
	var budgetPage = new budget();
	var isTextPresent = false;
	var currentPageNumber;
	var totalPageNumber;
	util.waitForAngular();
	browser.sleep(3000);
	browser.wait(EC.visibilityOf(element.all(by.css(this.tblBudgetListCss))), 30000);
	var budgetaryArray = element.all(by.css(this.tblBudgetListCss));
	budgetaryArray.getText().then(function(textArray){
		for (var i = 0; i < textArray.length; i++){
			if(textArray[i]==budgetaryNameText){
				logger.info(budgetaryNameText +" Found");
				isTextPresent = true;
				logger.info("Term : "+textArray[i+3]);
				return textArray[i+3];
			}
		}
		var paginationElement = element.all(by.css(defaultConfig.drpdownPagnCss));
		//var currentPageNumberDropdown = element(by.css("[id^=bx--page-number-input-] option[selected='true']"));
		//currentPageNumberDropdown.getText().then(function(text){
			paginationElement.getAttribute('innerText').then(function(paginationText){
				logger.info("paginationText : "+paginationText.toString());
				var paginationArray = paginationText.toString().split("\n");
				currentPageNumber = paginationArray[1];				
				totalPageNumber = paginationArray[2];
			}).then(function(){
				logger.info("Current Page Number..."+currentPageNumber);
				logger.info("Total Page Number..."+totalPageNumber);
				if(parseInt(currentPageNumber, 10) < parseInt(totalPageNumber, 10)){
					var frwrdBtn = element(by.css(defaultConfig.bdgtPageForwardBtnCss));
					util.scrollToWebElement(frwrdBtn);
					browser.wait(EC.elementToBeClickable(frwrdBtn),30000);
					frwrdBtn.click().then(function(){
						logger.info("Clicked on next button for pagination...");
					}).then(function(){
						logger.info("Function is calling again.....");
						budgetPage.checkBudgetaryNameInBudgetaryUnitTable(budgetaryNameText);					
					});
				}else{
					return;
				}
			});

		//});			
	});

};

//Check budgetary status from Budgetary Unit table 
budget.prototype.checkBudgetaryStausInBudgetaryUnitTable = function(budgetaryNameText){
	var isTextPresent = false;	
	var budgetrayStatus;
	util.waitForAngular()
	browser.wait(EC.visibilityOf(element(by.css(defaultConfig.tblBudgetListCss))), 30000);
	var budgetaryArray = element.all(by.css(defaultConfig.tblBudgetListCss));
	browser.sleep(3000);
	return budgetaryArray.getText().then(function(textArray){
		for (var i = 0; i < textArray.length; i++){
			if(textArray[i]==budgetaryNameText){
				logger.info(budgetaryNameText +" Found");
				isTextPresent = true;
				logger.info("budgetrayStatus : "+textArray[i+4]);
				budgetrayStatus = textArray[i+4];
				return budgetrayStatus;			
			}
		}
	});

	// return util.waitForAngular().then(function(){
	// 	browser.wait(EC.visibilityOf(element(by.css(defaultConfig.tblBudgetListCss))), 30000);
	// 	var budgetaryArray = element.all(by.css(defaultConfig.tblBudgetListCss));
	// 	browser.sleep(3000);
	// 	return budgetaryArray.getText().then(function(textArray){
	// 		for (var i = 0; i < textArray.length; i++){
	// 			if(textArray[i]==budgetaryNameText){
	// 				logger.info(budgetaryNameText +" Found");
	// 				isTextPresent = true;
	// 				logger.info("budgetrayStatus : "+textArray[i+4]);
	// 				budgetrayStatus = textArray[i+4];
	// 				return budgetrayStatus;			
	// 			}
	// 		}
	// 	});
	// }).then(function(){
	// 	logger.info("status is : "+budgetrayStatus);
	// 	return budgetrayStatus;
	// });	
};

/**
 * Click on Edit Icon from budgetary table and View the details of created budgetary unit 
 */
budget.prototype.clickOnEditIconAndViewDetailsForBudgetaryUnit = function(budgetaryNameText){
	var self = this;
	var budgetrayStatus;
	util.waitForAngular().then(function(){
		browser.wait(EC.visibilityOf(element(by.css("[headers^='table-header-']"))), 60000);
		browser.sleep(3000);
		var budgetaryArray = element.all(by.css("[headers^='table-header-']"));
		budgetaryArray.getText().then(function(textArray){
			for (var i = 0; i < textArray.length; i++){
				if(textArray[i]==budgetaryNameText){
					logger.info("Value ------- "+i);
					logger.info(budgetaryNameText +" Found");
					var index = i/5;
					index = parseInt(index + 1);
					logger.info("Row Index : "+index);
					// Needed to convert it from CSS to Xpath for much consistent locator
					//var editicon = element(by.xpath('//td[contains(text(), "'+budgetaryNameText+'")]/following-sibling::td[5]//button'));
					var editicon = element(by.css(defaultConfig.bdgtUnitActionBtnCss));
					util.scrollToWebElement(editicon);
					util.scrollToTop();
					browser.wait(EC.elementToBeClickable(editicon),60000);
					editicon.click().then(function(){
					//browser.actions().mouseMove(editicon).click().perform().then(function(){
						logger.info("Clicked on Action ICON for budgetary unit");
						util.waitForAngular();	
						// Needed to convert it from CSS to Xpath for much consistent locator
						browser.wait(EC.elementToBeClickable(element(by.css(self.buttonViewDetailsCss))),90000);
						element(by.css(self.buttonViewDetailsCss)).click().then(function(){
							logger.info("Clicked on View Details of budgetary unit");
						});		
					});		
				}
			}
		});
	});	
};


//*************Budgetary budgets*************************************************//

/**
 * Click on Add Budget button from Budgets section..
 */
budget.prototype.clickOnBudgetaryAddBudgetButton = function(){
	var addBudgetEle = element(by.css(this.budgetaryBudgetsAddBudgetButtonCss));
	browser.wait(EC.visibilityOf(addBudgetEle),30000).then(function(){
		browser.wait(EC.elementToBeClickable(addBudgetEle),30000).then(function(){
			logger.info("Budgatary Add Budget Button is visible...");
		});
	});	
	return element(by.css(this.budgetaryBudgetsAddBudgetButtonCss)).click().then(function(){
		logger.info("Clicked on budgatary Add Budget Button...");
	});
};

/**
 * Click on Create budget button from Budgets form.. 
 */
budget.prototype.clickOnBudgetaryCreateNewBudgetButton = function(){
	var CreateNewBudgetEle = element(by.css(this.CreateNewBudgetButtonCss));
	browser.wait(EC.elementToBeClickable(CreateNewBudgetEle),30000).then(function(){
		logger.info("Budgatary Create New Budget Button is Clicable...");
	});	
	browser.executeScript("arguments[0].scrollIntoView(true);", CreateNewBudgetEle.getWebElement());
	CreateNewBudgetEle.click().then(function(){
		logger.info("Clicked on budgatary Create New Budget Button...");
	});	
};


/**
 * Click on Back button from Budgets form  
 */
budget.prototype.clickOnBudgetaryBackBudgetButton = function(){
	util.waitForAngular();
	var backBudgetBtnEle = element(by.css(this.buttonBackBudgetCss));
	browser.wait(EC.elementToBeClickable(backBudgetBtnEle),30000).then(function(){
		logger.info("Budgatary Back Budget Button is Clickable...");
	});	
	element(by.css(this.buttonBackBudgetCss)).click().then(function(){
		logger.info("Clicked on budgatary back Budget Button...");
	});	
};

/**
 * Get text message from notification Pop-up in the Budgets form  
 */
budget.prototype.getTextNotificationMsgBudgetPage = function() {
	browser.ignoreSynchronization = true;
	browser.wait(EC.visibilityOf(element(by.css(this.NotificationMsgCss))),20000);
	return element(by.css(this.NotificationMsgCss)).getText().then(function(text){
		logger.info("Notification message text : "+text);
		return text;
	});
};

budget.prototype.getTextNotificationErrorMsgBudgetPage = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.NotificationErrorMsgCss))),90000);
	return element(by.css(this.NotificationErrorMsgCss)).getText().then(function(text){
		logger.info("Notification message text : "+text);
		return text;
	});
};

/**
 * Click on close icon from notification Pop-up in the Budgets form  
 */
budget.prototype.clickOnNotificationCloseButton = function(){
	//browser.ignoreSynchronization = true;
	var NotificationClose = element(by.xpath(this.NotificationCloseBtnXpath));
	browser.wait(EC.visibilityOf(NotificationClose),10000);
	//logger.info("Notification Budget close Button is visible");
		
	return element(by.xpath(this.NotificationCloseBtnXpath)).click().then(function(){
		logger.info("Clicked on Notification Budget close Button...");
	});	
};

/**
 * Set value for Start Period text box in the budgets form
 */
budget.prototype.setTextBudgetStartPeriod = function(budgetryStartPeriod){
	browser.wait(EC.visibilityOf(element(by.css(this.BudgetDetailsStartPeriodCss))),30000);
	element(by.css(this.BudgetDetailsStartPeriodCss)).clear();
	return element(by.css(this.BudgetDetailsStartPeriodCss)).sendKeys(budgetryStartPeriod).then(function(){
		logger.info("Budgetry start period is entered...");
	});
};

/**
 * Set value for End Period text box in the budgets form
 */
budget.prototype.setTextBudgetEndPeriod = function(budgetryEndPeriod){
	browser.wait(EC.visibilityOf(element(by.css(this.BudgetDetailsEndPeriodCss))),30000);
	element(by.css(this.BudgetDetailsEndPeriodCss)).clear();
	return element(by.css(this.BudgetDetailsEndPeriodCss)).sendKeys(budgetryEndPeriod).then(function(){
		logger.info("Budgetry end period is entered...");
	});
};

/**
 * Verify Add New Budget text is displayed in the budgets form
 */
budget.prototype.isBudgetaryAddNewBudgetTextDisplayed = function(){
	var addNewBudgetTxtEle = element(by.xpath(this.budgetaryAddNewBudgetsTxtXpath));
	return addNewBudgetTxtEle.isDisplayed().then(function(){
		logger.info("Add New Budget text is displayed.....");
	});
};

budget.prototype.clickBudgetSliderCloseButton = function(){
	var closeSliderElem = element(by.css(this.buttonBudgetSliderCloseCss));
	browser.wait(EC.elementToBeClickable(closeSliderElem),70000);	
	browser.executeScript("arguments[0].click();", closeSliderElem.getWebElement()).then(function(){
		logger.info("Closed Budget Slider");
	});		
};


/**
 * Fill order details function to fill the parameter details based on the provided value in JSON 
 */
budget.prototype.fillOrderDetails = function(jsonTemplate, modifiedParamMap) {
	var deferred = protractor.promise.defer();
	var requiredReturnMap = {}, expectedMap = {}, actualMap = {};
	var EC = protractor.ExpectedConditions;
	var jsonObject = JSON.parse(JSON.stringify(jsonTemplate));
	var elem = null;
	//browser.ignoreSynchronization = false;
	//Adding below condition for Provisioning/Edit flows
	var orderParameters,jsonObjectForParameters;
	if (modifiedParamMap["EditService"] == true){
		orderParameters = Object.keys(jsonObject["Edit Parameters"]);
		jsonObjectForParameters = jsonObject["Edit Parameters"];
	}else{
		orderParameters = Object.keys(jsonObject["Order Parameters"]);
		jsonObjectForParameters = jsonObject["Order Parameters"];
	}	

	//var orderParameters = Object.keys(jsonObject["Order Parameters"]);
	Object.keys(orderParameters).forEach(function (detailSection) {
		browser.executeScript('window.scrollTo(0,0);')
		var webElements = Object.keys(jsonObjectForParameters[orderParameters[detailSection]]);
		Object.keys(webElements).forEach(function (webElement) {
			var environment = browser.params.url.includes("cb-qa-1") ? "QA 1" :  browser.params.url.includes("cb-qa-2") ? "QA 2" : browser.params.url.includes("customer1") ? "Customer 1" : browser.params.url.includes("d2ops-test") ? "D2OPS" : "QA 4";
			var webElementObject = Object.keys(jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]]);
			var elementType = Object.values(jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]][webElementObject[0]]).join("");
			var elementID = Object.values(jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]][webElementObject[1]]).join("");
			var elementValue = Object.values(jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]][webElementObject[2]][environment]).join("");
			elem = elementID;
			if (modifiedParamMap != undefined) {
				if (Object.keys(modifiedParamMap).includes(webElements[webElement]))
					elementValue = modifiedParamMap[webElements[webElement]];
			}
			//Support xpath/css written in json file	
	        	var elementToTrigger;
			    if (webElementObject[1] == "css") {
				elementToTrigger = element(by.css(elementID));
			    }
			    if (webElementObject[1] == "xpath") {
				elementToTrigger = element(by.xpath(elementID));
			    }
			if (!elementValue == "") {
				if (elementType == "Dropdown") {		
					var dropdown = element(by.css("[id=\"" + elementID + "\"]"));
					//browser.ignoreSynchronization = false;
					browser.sleep(5000);
					util.waitForAngular();	
					browser.wait(EC.elementToBeClickable(dropdown), 60000).then(function(){
						util.waitForAngular();	
						dropdown.isEnabled().then(function (enabled) {
							if(enabled){
								browser.sleep(5000);
								dropdown.click().then(function(){
									//var dropDownValuesArray = element.all(by.xpath("//*[@id='" + elementID + "']//carbon-dropdown-option//a"));
									var dropDownValuesArray = element.all(by.xpath("//*[@id='" + elementID + "']//li"));
									dropDownValuesArray.getText().then(function (textArray) {
										var isDropDownValuePresent = false;
										for (var i = 0; i < textArray.length; i++) {
											if (textArray[i] == elementValue) {
												dropDownValuesArray.get(i).click().then(function () {
													logger.info("Selected " + elementValue + " from " + webElements[webElement] + " dropdown");
													expectedMap[webElements[webElement].trim()] = elementValue.trim();
													deferred.fulfill(expectedMap);
												}).catch(function(err){
													logger.info("Error while selecting value");
													browser.sleep(5000);
												});
												isDropDownValuePresent = true;
											}
										}
										if (!isDropDownValuePresent) {
											dropDownValuesArray.get(0).getText().then(function (text) {
												dropDownValuesArray.get(0).click().then(function () {
													logger.info("Selected " + text + " from " + webElements[webElement] + " dropdown");
													expectedMap[webElements[webElement].trim()] = text.trim();
													deferred.fulfill(expectedMap);
												});
											});
										}
									});
								});
							}
						});                      

					});                    
				}
				if (elementType == "RadioButton") {
                	// browser.sleep(5000);
                	var radioButtion = element(by.css(elementID));
                    util.waitForAngular();
                    browser.sleep(3000);
                    browser.wait(EC.elementToBeClickable(radioButtion), 300000);
                    browser.executeScript("arguments[0].click();", radioButtion.getWebElement()).then(function () {
                        logger.info("Selected " + elementValue + " radio button for " + webElements[webElement]);
                        expectedMap[webElements[webElement].trim()] = elementValue.trim();
                        deferred.fulfill(expectedMap);
                    })
                }
				if (elementType == "Textbox") {
					var textboxList;
					var textbox;
					if (elementToTrigger != undefined) {
						textbox = elementToTrigger;
				   	} else {
						textboxList = element.all(by.css("[id=\"" + elementID + "\"]"));
						textbox = textboxList.last();
				   	}
// 					var textboxList = element.all(by.css("[id=\"" + elementID + "\"]"));
// 					var textbox = textboxList.last();
					util.waitForAngular();	
				    	browser.sleep(3000);
					browser.wait(EC.elementToBeClickable(textbox), 60000);
					textbox.clear().then(function () {
						logger.info("Cleared " + webElements[webElement] + " textbox");
						var ctrlA = protractor.Key.chord(protractor.Key.CONTROL, "a");
						textbox.sendKeys(ctrlA);
					}).catch(function(err){
						browser.sleep(4000);
						textbox.clear();
						var ctrlA = protractor.Key.chord(protractor.Key.CONTROL, "a");
						textbox.sendKeys(ctrlA);
					});
					textbox.sendKeys(elementValue).then(function () {
						logger.info("Entered " + elementValue + " in " + webElements[webElement] + " textbox");
						expectedMap[webElements[webElement].trim()] = elementValue.trim();
						deferred.fulfill(expectedMap);
					})
				}
				if (elementType == "MultiselectDropdown") {
					var multiElementValue = Object.values(jsonObject["Order Parameters"][orderParameters[detailSection]][webElements[webElement]][webElementObject[2]][environment]);
					var multiElementValueArray = multiElementValue.toString().split(",");
					var checkBoxDropDown = element(by.css("[id=\"" + elementID + "\"]"));
					util.waitForAngular();	
					browser.sleep(5000);
					browser.wait(EC.elementToBeClickable(checkBoxDropDown), 60000);
					checkBoxDropDown.click().then(function () {
						logger.info("Clicked on " + webElements[webElement] + " multi-select dropdown");
					});
					var dropDownValues = element.all(by.css("[id^=dropdown-option__]"));
					browser.wait(EC.presenceOf(dropDownValues), 60000);
					dropDownValues.getText().then(function (dropDownValuesArray) {
						logger.info("Dropdown Values: " + dropDownValuesArray);
						for (var i = 0; i < multiElementValueArray.length; i++) {
							for (var j = 0; j < dropDownValuesArray.length; j++) {
								if (multiElementValueArray[i].toString().trim() == dropDownValuesArray[j].toString().trim()) {
									element.all(by.css("[id^=bx--dropdown-item-]")).get(j).click();
									logger.info("Clicked on checkbox " + multiElementValueArray[i] + " from " + webElements[webElement] + " multi-select dropdown");
									expectedMap[webElements[webElement].trim()] = multiElementValueArray.toString().trim();
									deferred.fulfill(expectedMap);
								}
							}
						}
						checkBoxDropDown.click();
					});
				}
				if(elementType == "DropdownSearch"){
					var dropdownbox = element(by.xpath("//*[@id='"+elementID + "' or @id = '" + elementID.toLowerCase() +"']/div"));
					util.waitForAngular();	
		            browser.sleep(5000);
					browser.wait(EC.presenceOf(dropdownbox), 10000).then(function(){
						dropdownbox.click().then(function(){
							browser.sleep(1000);
							util.waitForAngular();
							var dropDownValuesArray = element.all(by.xpath("//*[@id='"+elementID + "' or @id = '" + elementID.toLowerCase() + "']//ul//li"));
							dropDownValuesArray.getText().then(function(textArray){
									var isDropDownValuePresent = false;
									for (var i=0;i<textArray.length;i++){
										if (textArray[i] == elementValue){
											dropDownValuesArray.get(i).click().then(function(){
												logger.info("Selected "+elementValue+" from "+webElements[webElement]+" dropdown");
												expectedMap[webElements[webElement].trim()] = elementValue.trim();
						                    	deferred.fulfill(expectedMap);
						                    });
						                    isDropDownValuePresent =true;
						                }
						            }
						            if(!isDropDownValuePresent){
						            	dropDownValuesArray.get(0).getText().then(function(text){
						            		dropDownValuesArray.get(0).click().then(function(){
						            			logger.info("Selected "+text+" from "+webElements[webElement]+" dropdown");
						            			expectedMap[webElements[webElement].trim()] = text.trim();
						            			deferred.fulfill(expectedMap);
						            		})
						            	})
						            }
						        });
						});
					});
					
                }
				if(elementType == "Button"){
					elementValue = " ";
					var button = element(by.css("[id=\""+ elementID +"\"]"));
					util.waitForAngular();	
					// browser.sleep(5000);
					browser.wait(EC.elementToBeClickable(button), 30000).then(function(){
						button.click().then(function(){
							logger.info("Clicked on the Button "+ webElements[webElement]);
						});
					});
				}
				if(elementType == "Toggle"){
					elementValue = "";
					var button = element(by.css("[for=\""+ elementID +"\"]"));
					util.waitForAngular();	
					// browser.sleep(5000);
					browser.wait(EC.elementToBeClickable(button), 30000).then(function(){
						button.click().then(function(){
							logger.info("Clicked on the Toggle Button "+ webElements[webElement]);
						});
					});
				}
				if(elementType == "Checkbox"){
					elementValue = " ";
					var button = element(by.xpath(elementID));
					util.waitForAngular();	
					// browser.sleep(5000);
					browser.wait(EC.presenceOf(button), 90000); 
					browser.wait(EC.elementToBeClickable(button), 30000); // fix for click interception issue
					browser.actions().mouseMove(button).click().perform().then(function () {
						logger.info("Clicked on the checkbox "+ webElements[webElement])
			});
				}
				if (elementType == "Dynamic ListBox") {
					//Here for handling dynamic locator, pass dropdown id followed by xpath of values to be selected
					var locatorList = elementID.split(";");
					var dropdown = element(by.css("button[id =" + locatorList[0] +"],div[id =" + locatorList[0] +"]"));
					var dropdownValues = element.all(by.xpath(locatorList[1]));
					//Click on dropdown based on its id				
					browser.wait(EC.elementToBeClickable(dropdown), 30000);
						dropdown.click().then(function () {
							logger.info("Clicked on the Dropdown " + webElements[webElement]);
						});
						//Select dropdown values as per xpath
						browser.wait(EC.visibilityOf(dropdownValues.get(0)), 30000);
						dropdownValues.getText().then(function (textArray) {
							var isDropDownValuePresent = false;
							for (var i = 0; i < textArray.length; i++) {
								if (textArray[i] == elementValue) {
									dropdownValues.get(i).click().then(function () {
										logger.info("Selected " + elementValue + " from " + webElements[webElement] + " dropdown");
										expectedMap[webElements[webElement].trim()] = elementValue.trim();
										deferred.fulfill(expectedMap);
									}).catch(function (err) {
										logger.info("Error while selecting value");
										browser.sleep(5000);
									});
									isDropDownValuePresent = true;
								}
							}
							if (!isDropDownValuePresent) {
								dropdownValues.get(0).getText().then(function (text) {
									dropdownValues.get(0).click().then(function () {
										logger.info("Selected " + text + " from " + webElements[webElement] + " dropdown");
										expectedMap[webElements[webElement].trim()] = text.trim();
										deferred.fulfill(expectedMap);
									});
								});
							}
						});
					
				}
			}
			if(elementType == "dropdownSearchSelect"){
				var locatorList = elementID.split(";")
				var Dropdown = element(by.css("[id=\""+ locatorList[0] +"\"]"));
				console.log("dropdown..."+Dropdown)
				browser.wait(EC.elementToBeClickable(Dropdown), 30000).then(function(){
					Dropdown.click().then(function(){
						logger.info("Clicked on the Button "+ webElements[webElement]);
						var	DropdownSearchText = element(by.xpath("//*[@id=\""+ locatorList[0] +"\"]//input[@class='bx--search-input']"))
						browser.wait(EC.elementToBeClickable(DropdownSearchText), 30000)
						browser.sleep(2000);
						DropdownSearchText.sendKeys(elementValue).then(function(){
							logger.info("Entered "+ elementValue + " Search Box Dropdown");
							DropdownSearchText.sendKeys(protractor.Key.ENTER);
							util.waitForAngular();
							//var value = elementValue.replace(/[@\.]*/g,"")
							//var dropDownValue = element(by.xpath("//*[@id=\""+ elementID +"\"]//a[@id='dropdown-option__" + value + "']//input"));
							var dropDownValue = element(by.xpath("//*[@id='dropdown-option__"+ elementValue + "']//input[starts-with(@id,'"+locatorList[1]+"')]/../label"));
							console.log("dropdown..."+"//*[@id='dropdown-option__"+ elementValue + "']//input[starts-with(@id,'"+locatorList[1]+"')]/..");
							browser.wait(EC.elementToBeClickable(dropDownValue), 30000).then(function(){
								dropDownValue.click().then(function(){
									logger.info("clicked on checkBox")
									//DropdownSearchText.clear().then(function(){
									//	DropdownSearchText.sendKeys(protractor.Key.ENTER);
										Dropdown.click();
									//})
								})
							})
						})
					});
				});			
			}
			else{
				browser.sleep(5000);	
			}
		});

		util.waitForAngular();
	});

	requiredReturnMap["Actual"] = actualMap;
	requiredReturnMap["Expected"] = expectedMap;
	deferred.fulfill(requiredReturnMap);
	return deferred.promise;

}
// Find the budgetary unit, click on View Details and then find the Budget , click on View Details to get the Budget Details
// It handles both the cases having Budgetary Unit and Budget Name with same or different Name
/*budget.prototype.clickOnViewDetailsForBudgetaryUnit = function(budgetaryUnitNameText,budgetNameText){
	var curr =this;
	util.waitForAngular().then(function(){
		browser.wait(EC.visibilityOf(element(by.css(curr.GetDetailsCss))), 30000);
		var budgetaryUnitArray = element.all(by.css(curr.GetDetailsCss));
		var index;
		var budgetrayArrLen;
		budgetaryUnitArray.getText().then(function(textArray){
			budgetrayArrLen = textArray.length;
			for (var i = 0; i < textArray.length; i++){
				
				if(textArray[i]==budgetaryUnitNameText){
					logger.info("Value ------- "+i);
					logger.info( budgetaryUnitNameText +" is Available in Budgetary Unit Table");
					 index = i/5;
					index = parseInt(index + 1);
					logger.info("Row Index : "+index);
				}
				
		}
					var navigationicon = element(by.css('#carbon-deluxe-data-table-0-parent-row-'+index+'-overflow-menu-icon svg'));
					util.scrollToWebElement(navigationicon);
					util.scrollToTop();
					browser.wait(EC.elementToBeClickable(navigationicon),30000);					
					browser.actions().mouseMove(navigationicon).click().perform().then(function(){
						logger.info("Clicked on Navigation ICON");
						util.waitForAngular();	
						browser.wait(EC.elementToBeClickable(element(by.css('#carbon-deluxe-data-table-0-parent-row-'+index+'-option-1-button'))),30000);
						element(by.css('#carbon-deluxe-data-table-0-parent-row-'+index+'-option-1-button')).click().then(function(){
							logger.info("Clicked on Budgetary Unit's View Details");
						});		
					});		
				
			
		});
		curr.clickOnBudgetryBudgetsLink();
		util.waitForAngular().then(function(){
            browser.sleep(6000);                 
			browser.wait(EC.visibilityOf(element(by.css(curr.GetDetailsCss))), 30000);
			var budgetaryArray = element.all(by.css(curr.GetDetailsCss));
			budgetaryArray.getText().then(function(textArray){
				var  budgetArrayLen= textArray.length ;
				for (var i =budgetrayArrLen-1 ; i < textArray.length; i++){
					 
					if(textArray[i]==budgetNameText){
						logger.info("Value ------- "+i);
						logger.info(budgetNameText +" is Available in Budget Table");
						 index = (budgetArrayLen-budgetrayArrLen)/13;
						index = parseInt(index);
						logger.info("Row Index : "+index);
					}
	
				}
				
				var navigationicon = element(by.xpath('(//*[@id="carbon-deluxe-data-table-0-parent-row-'+index+'-overflow-menu-icon"])[2]'));
				util.scrollToWebElement(navigationicon);
				util.scrollToTop();
				browser.wait(EC.elementToBeClickable(navigationicon),30000);					
				browser.actions().mouseMove(navigationicon).click().perform().then(function(){
					logger.info("Clicked on Navigation Icon");
					util.waitForAngular();	
					browser.wait(EC.elementToBeClickable(element(by.xpath('(//*[@id="carbon-deluxe-data-table-0-parent-row-'+index+'-option-1-button"])[2]'))),30000);
					element(by.xpath('(//*[@id="carbon-deluxe-data-table-0-parent-row-'+index+'-option-1-button"])[2]')).click().then(function(){
						logger.info("Clicked on Budget's View Details");
							});		
						});		
					
				
			
					});
		});	
	});
};*/

budget.prototype.clickOnViewDetailsForBudgetaryUnit = function (budgetaryUnitNameText, budgetNameText) {
	var curr = this;	
	util.waitForAngular();
	browser.sleep(3000);
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.addNewBudgetryUnitBtnXpath))), 60000);
	var budgetaryUnitName = element.all(by.xpath(this.tblBudgetUnitXpath));		
	var indexNum;	
	budgetaryUnitName.getText().then(function (textArray) {
		indexNum = textArray.indexOf(budgetaryUnitNameText);
		expect(indexNum).not.toEqual(-1);		
		logger.info("Budgetary Unit is found : " + budgetaryUnitNameText);
		browser.executeScript("window.scrollTo(0,0)");
		//Click on View Details
		var navigationicon = element.all(by.css(defaultConfig.bdgtUnitActionBtnCss));
		util.scrollToWebElement(navigationicon.get(indexNum));
		//util.scrollToTop();
		browser.wait(EC.elementToBeClickable(navigationicon.get(indexNum)), 30000);
		navigationicon.get(indexNum).click().then(function(){
			logger.info("Clicked on Budgetary units action ICON");
			util.waitForAngular();			
		});
		
		var elemBudgetUnitViewDetailsBtn = element(by.css(defaultConfig.bdgtUnitViewDetailCss));
		browser.wait(EC.elementToBeClickable(elemBudgetUnitViewDetailsBtn), 30000);
		elemBudgetUnitViewDetailsBtn.click().then(function () {
			logger.info("Clicked on View Details of Budgetary unit - " + budgetaryUnitNameText);
		});

		curr.clickOnBudgetryBudgetsLink();
		browser.sleep(5000);
		//Click on Budgets View details
		var budgetsName = element.all(by.xpath(defaultConfig.tblBudgetsXpath));
		budgetsName.getText().then(function (textArray) {
			logger.info("Budget is available in Budgets section");
			var navigationicon = element.all(by.css(defaultConfig.bdgtActnBtnCss));
			util.scrollToWebElement(navigationicon.get(0));
			util.scrollToTop();
			browser.wait(EC.elementToBeClickable(navigationicon.get(0)), 30000);
			browser.actions().mouseMove(navigationicon.get(0)).click().perform().then(function () {
				logger.info("Clicked on Budgets Navigation ICON");
				util.waitForAngular();
				browser.wait(EC.elementToBeClickable(element(by.css(defaultConfig.bdgtViewDetlBtnCss))), 60000);
				element(by.css(defaultConfig.bdgtViewDetlBtnCss)).click().then(function () {
					logger.info("Clicked on View Details of budget " + budgetNameText);
					browser.sleep(3000);
				});
			});
			
		
		});
		
	});
};

// Budget Ammount on Budgets/Budget Details page available 
budget.prototype.getTextBudgetAmmount = function () {
	browser.wait(EC.visibilityOf(element(by.xpath(this.BudgetAmmountXpath))),5000);
	return element(by.xpath(this.BudgetAmmountXpath)).getAttribute("value").then(function (text) {
        logger.info("Budget Ammount on Budgets/Budget Details page : " + text);
        return text;
    });
};

//Available Ammount on Budgets/Budget Details page
budget.prototype.getTextAvailableAmount = function () {
	browser.wait(EC.visibilityOf(element(by.xpath(this.AvailableAmmountXpath))),5000);
	return element(by.xpath(this.AvailableAmmountXpath)).getAttribute("value").then(function (text) {
        logger.info("Available Ammount on Budgets/Budget Details page : " + text);
        return text;
    });
};

// Commited Ammount on Budgets/Budget Details page
budget.prototype.getTextCommittedAmount = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.textCommittedAmountCss))),5000);
	return element(by.css(this.textCommittedAmountCss)).getAttribute("value").then(function (text) {
        logger.info("Commited Ammount on Budget Details page : " + text);
        return text;
    });
};

//Under Approval Ammount on Budgets/Budget Details page
budget.prototype.getTextUnderAprovalAmount = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.textUnderApprovalAmountCss))),20000);
	return element(by.css(this.textUnderApprovalAmountCss)).getAttribute("value").then(function (text) {
        logger.info("Under Approval Ammount on Budget Details page: " + text);
        return text;
    });
};

budget.prototype.getTextActualCharges = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.textActualCharges))),20000);
	return element(by.css(this.textActualCharges)).getAttribute("value").then(function (text) {
        logger.info("Actual Charges on Budget Details page: " + text);
        return text;
    });
};

// Calculated Estimated Ammountfor Order
budget.prototype.calculateEstimatedAmmountforOrder = function (budgetDuration, totalCost) {
	var cost = parseFloat(("" + totalCost).replace(/[^\d\.]*/g, ''), 2).toFixed(2);
	var amount = cost * budgetDuration;
	amount = amount.toFixed(2);
	var estCost = amount.toString();
	var estCost1 = estCost.slice(0, (estCost.indexOf(".")) + 3);
        
	logger.info("Calculated estimated amount for this order: " + estCost1);
	return estCost1;
}

// Calculated expected Committed Amount after provisioning completed On Budgets/Budget Details page
budget.prototype.calculateCommittedAmountAfterProvCompletedOnBudgetPage = function (committedAmnt, estCost) {

	var committedCost1 = parseFloat(("" + committedAmnt).replace(/[^\d\.]*/g, ''), 2);
	var estCost1 = parseFloat(("" + estCost).replace(/[^\d\.]*/g, ''), 2);

	var amount = committedCost1 + estCost1
	amount = amount.toFixed(2);
	var amountToCommit = amount.toString();
	var actualCommitCost = (Number(amountToCommit)).toFixed(2);;

	logger.info("Calculated Committed Amount for this order after provisioning completed on Budget Page: " + actualCommitCost);
	return actualCommitCost;

}

// Calculated expected Avaialable Amount after provisioning completed On Budgets/Budget Details page
budget.prototype.calculateAvailableBudgetAfterProvCompletedOnBudgetPage = function (availCost, estCost) {
	var availCost1 = parseFloat(("" + availCost).replace(/[^\d\.]*/g, ''), 2);
	var estCost1 = parseFloat(("" + estCost).replace(/[^\d\.]*/g, ''), 2);
	var amount = availCost1 - estCost1
	var amountAvail = amount.toString();
	amount = amount.toFixed(2);
	var actualAvailCost = (Number(amountAvail)).toFixed(2);

	logger.info("Calculated Available Budget for this order after provisioning completed  on Budget Page: " + actualAvailCost);
	return actualAvailCost;
}

// Calculated expected Committed Amount On Budgets/Budget Details page once deletion is completed with one month cost deduction  
budget.prototype.calculateDeleteCommittedAmountOnBudgetPage = function (committedAmnt, estCost) {
	var commitCost = parseFloat(("" + committedAmnt).replace(/[^\d\.]*/g, ''), 2);
	var estCost1 = parseFloat(("" + estCost).replace(/[^\d\.]*/g, ''), 2);
	var amount = commitCost - estCost1;
	amount = amount.toFixed(2);
	var estAmount = amount.toString();
	var actualEstCost = (Number(estAmount)).toFixed(2);

	logger.info("Calculated Committed Amount after deletion is completed with one month cost deduction  on Budget Page: " + actualEstCost);
	return actualEstCost
}

// Calculated Estimated Amount On Budgets/Budget Details page once deletion is completed with one month cost deduction 
budget.prototype.calculateEstCostAfterDeleting1MonthOrderOnBudgetPage = function (estCost, oneMonthCost) {
	var oneMonthCost = parseFloat(("" + oneMonthCost).replace(/[^\d\.]*/g, ''), 2);
	var estCost1 = parseFloat(("" + estCost).replace(/[^\d\.]*/g, ''), 2);
	var amount = estCost1 - oneMonthCost;
	amount = amount.toFixed(2);
	var estAmount = amount.toString();
	var actualEstCost = (Number(estAmount)).toFixed(2);

	logger.info("Calculated Estimated Amount for the delete order  on Budget Page: " + actualEstCost);
	return actualEstCost;

}

// Calculated expected Available Amount On Budgets/Budget Details page once deletion is completed with one month cost deduction 
budget.prototype.calculateAfterDeletingAvailBudgetOnBudgetPage = function (availBudget, estCost) {
	var availBudget1 = parseFloat(("" + availBudget).replace(/[^\d\.]*/g, ''), 2);
	var estCost1 = parseFloat(("" + estCost).replace(/[^\d\.]*/g, ''), 2);
	var amount = availBudget1 + estCost1;
	amount = amount.toFixed(2);
	var estAmount = amount.toString();
	var actualAvailCost = (Number(estAmount)).toFixed(2);
	logger.info("Calculated Available Budget after deleting the order : " + actualAvailCost);
	return actualAvailCost;

}
//check if budgetary unit is available on busget list page
budget.prototype.validateBudgetaryUnitIsAvailable = function(budgetaryNameText){
	var budgetPage = new budget();
	var isTextPresent = false;
	var currentPageNumber;
	var totalPageNumber;
	var curr = this;		
	var budgetaryUnitName = element.all(by.xpath(this.tblBudgetUnitXpath));
	//browser.wait(EC.visibilityOf(element(by.css(curr.GetDetailsCss))), 30000);
	
	util.waitForAngular().then(function(){		
		//browser.wait(EC.visibilityOf(element(by.css(".table-cell-tooltip-width-reference"))), 30000);		
		budgetaryUnitName.getText().then(function (textArray) {
			for (var i = 0; i < textArray.length; i++){
				if(textArray[i]==budgetaryNameText){
					logger.info(budgetaryNameText +" is available.");
					isTextPresent = true;					
					return isTextPresent;
				}
			}
			if (isTextPresent == false){
				var paginationElement = element.all(by.css('.bx--pagination__right .bx--pagination__text'));
				paginationElement.getAttribute('innerText').then(function(paginationText){
					logger.info("paginationText : "+paginationText.toString());
					var paginationArray = paginationText.toString().split(" ");
					currentPageNumber = paginationArray[0];
					totalPageNumber = paginationArray[2];
				}).then(function(){
					logger.info("Current Page Number..."+currentPageNumber);
					logger.info("Total Page Number..."+totalPageNumber);
					if(parseInt(currentPageNumber, 10) < parseInt(totalPageNumber, 10)){
						browser.wait(EC.elementToBeClickable(element(by.css('.bx--pagination__button--forward'))),30000);
						element(by.css('.bx--pagination__button--forward')).click().then(function(){
							logger.info("Clicked on next button for pagination...");
						}).then(function(){
							logger.info("Function is calling again.....");
							if(currentPageNumber == totalPageNumber){
								return;
							}
							budgetPage.validateBudgetaryUnitIsAvailable(budgetaryNameText);
							
						});
					}else{
						return;
					}
				});
			}			
		});		
	});
}

budget.prototype.setTextBudgetName = function (budgetName) {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.BudgetaryBudgetsCreateBudgetNameCss))), 30000);
	element(by.css(this.BudgetaryBudgetsCreateBudgetNameCss)).clear();
	return element(by.css(this.BudgetaryBudgetsCreateBudgetNameCss)).sendKeys(budgetName).then(function () {
		logger.info("Budget name is entered...");
	});
};


budget.prototype.getTextBudgetName = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.BudgetaryBudgetsCreateBudgetNameCss))),30000);
	return element(by.css(this.BudgetaryBudgetsCreateBudgetNameCss)).getAttribute("value").then(function(text){
		logger.info("budget name text :  "+text);
		return text;
	});
};

budget.prototype.setTextBudgetExternalRefId = function (budgetExternalRefId) {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.budgetExternalRefIdCss))), 30000);
	element(by.css(this.budgetExternalRefIdCss)).clear();
	return element(by.css(this.budgetExternalRefIdCss)).sendKeys(budgetExternalRefId).then(function () {
		logger.info("Budget ref Id is entered...");
		//Change focus
		browser.executeScript("document.activeElement.blur();")
	});
};

budget.prototype.getTextBudgetExternalRefId = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.budgetExternalRefIdCss))),30000);
	return element(by.css(this.budgetExternalRefIdCss)).getAttribute("value").then(function(text){
		logger.info("budget External Ref Id text :  "+text);
		return text;
	});
};

budget.prototype.setTextSoftQutaMailTextbox = function (softQuotaMailText) {
	browser.wait(EC.visibilityOf(element(by.css(this.softQuotaMailTextboxCss))), 30000);
	element(by.css(this.softQuotaMailTextboxCss)).clear();
	return element(by.css(this.softQuotaMailTextboxCss)).sendKeys(softQuotaMailText).then(function () {
		logger.info("Soft Quota Threshold notification mail id is entered...");
	});
};

budget.prototype.setTextHardQutaMailTextbox = function (hardQuotaMailText) {
	browser.wait(EC.visibilityOf(element(by.css(this.hardQuotaMailTextboxCss))), 30000);
	element(by.css(this.hardQuotaMailTextboxCss)).clear();
	return element(by.css(this.hardQuotaMailTextboxCss)).sendKeys(hardQuotaMailText).then(function () {
		logger.info("hard Quota Threshold notification mail id is entered...");
	});
};

budget.prototype.getTextSoftQutaMailTextbox = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.softQuotaEditedMailTextboxCss))),30000);
	return element(by.css(this.softQuotaEditedMailTextboxCss)).getAttribute("value").then(function(text){
		logger.info("Soft Quota Threshold notification mail id  :  "+text);
		return text;
	});
};

budget.prototype.getTextHardQutaMailTextbox = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.hardQuotaEditedMailTextboxCss))),30000);
	return element(by.css(this.hardQuotaEditedMailTextboxCss)).getAttribute("value").then(function(text){
		logger.info("Hard Quota Threshold notification mail id  :  "+text);
		return text;
	});
};

budget.prototype.setTextBudgetAmount = function (budgetAmount) {
	util.waitForAngular();
	var eleList = element(by.css(this.textboxBudgetAmount));
	browser.wait(EC.visibilityOf(eleList), 30000);
	eleList.clear();
	return eleList.sendKeys(budgetAmount).then(function () {
		logger.info("Budget Amount is entered...");
	});
};

budget.prototype.setTextHardQuota = function (hardQuota) {
	browser.wait(EC.visibilityOf(element(by.css(this.hardQuotaTextboxCss))), 30000);
	element(by.css(this.hardQuotaTextboxCss)).clear();
	return element(by.css(this.hardQuotaTextboxCss)).sendKeys(hardQuota).then(function () {
		logger.info("Hard Quota Threshold value is entered...");
	});
};

budget.prototype.setTextSoftQuota = function (softQuota) {
	browser.wait(EC.visibilityOf(element(by.css(this.softQuotaTextboxCss))), 30000);
	element(by.css(this.softQuotaTextboxCss)).clear();
	return element(by.css(this.softQuotaTextboxCss)).sendKeys(softQuota).then(function () {
		logger.info("Soft Quota Threshold value is entered...");
	});
};

budget.prototype.clickOnQuotaValueType = function(quotaName, valueType){
	var radioBtn = this.thresholdRadioButton.format(quotaName, valueType);
	browser.wait(EC.visibilityOf(element(by.xpath(radioBtn))), 30000);
	element(by.xpath(radioBtn)).click().then(function(){
		logger.info("Clicked on "+valueType+" value..");
	});
};

budget.prototype.getTextSoftQuota = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.softQuotaEditTextboxCss))),30000);
	return element(by.css(this.softQuotaEditTextboxCss)).getAttribute("value").then(function(text){
		logger.info("Soft Quota Threshold  value :  "+text);
		return text;
	});
};

budget.prototype.getTextHardQuota = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.hardQuotaEditTextboxCss))),30000);
	return element(by.css(this.hardQuotaEditTextboxCss)).getAttribute("value").then(function(text){
		logger.info("Hoft Quota Threshold value  :  "+text);
		return text;
	});
};

budget.prototype.getTextBudgetryNameFromDetailPage = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.budgetaryNameDetailPageCss))),30000);
	return element(by.css(this.budgetaryNameDetailPageCss)).getText().then(function(text){
		logger.info("Budgetary Name from  details page text :  "+text);
		return text;
	});
};

budget.prototype.getTextBudgetryDescriptionFromDetailPage = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.budgetaryDescriptionCss))),30000);
	return element(by.css(this.budgetaryDescriptionCss)).getText().then(function(text){
		logger.info("Budgetary Description from  details page text :  "+text);
		return text;
	});
};

budget.prototype.getTextBudgetryRefIdFromDetailPage = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.budgetaryExternalRefId))),30000);
	return element(by.css(this.budgetaryExternalRefId)).getText().then(function(text){
		logger.info("Budgetary Ref ID from  details page text :  "+text);
		return text;
	});
};

budget.prototype.selectDropdownSearch =function(elementId,elementValue){

	var dropdownbox = element(by.xpath("//*[@id='"+elementId + "' or @id = '" + elementId.toLowerCase() +"']"));
	util.waitForAngular();	
	browser.sleep(5000);
	browser.wait(EC.presenceOf(dropdownbox), 10000).then(function(){
		dropdownbox.click().then(function(){
			browser.sleep(1000);
			util.waitForAngular();
			var dropDownValuesArray = element.all(by.xpath("//*[@id='"+elementId + "' or @id = '" + elementId.toLowerCase() + "']//ul//li"));
			dropDownValuesArray.getText().then(function(textArray){
					for (var i=0;i<textArray.length;i++){
						if (textArray[i] == elementValue){
							dropDownValuesArray.get(i).click().then(function(){
								logger.info("Selected "+elementValue+" from dropdown");
							});
						}
					}
				});
		});
	});
	
}
/** Verify 'Add New Budgetary Unit' button is not present  **/

budget.prototype.invisibilityOfAddBudgetryButton = function(){
	browser.wait(EC.invisibilityOf(element(by.xpath(this.addNewBudgetryUnitBtnXpath))),30000);
	return element(by.xpath(this.addNewBudgetryUnitBtnXpath)).isPresent().then(function(res){
		logger.info("Add new Budgetry Unit button is not present."+res);
		return res;
	});
};

budget.prototype.getViewBudgetDescriptionText = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.budgetMgmtSubHeadingCss))),30000);
	return element(by.css(this.budgetMgmtSubHeadingCss)).getText().then(function(text){
		logger.info("Budget Management Subheading is :  "+text);
		return text;
	});
};

budget.prototype.clickOnViewBudgetTab = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.budgetTileCss))),30000);
	browser.wait(EC.elementToBeClickable(element(by.css(this.budgetTileCss))),30000);
	return element(by.css(this.budgetTileCss)).click().then(function(){
		logger.info("Click On View Budget Button");
	});
};

budget.prototype.invisibilityOfBudgetEditButton = function(){
	browser.wait(EC.invisibilityOf(element.all(by.css(this.editBudgetButtonCss)).get(0)),30000);
	return element.all(by.css(this.editBudgetButtonCss)).get(0).isPresent().then(function(res){
		logger.info("Edit button is present :"+res);
		return res;
	});
};

budget.prototype.getUserName = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.userNameCss))),30000);
	return element(by.css(this.userNameCss)).getText().then(function(text){
		logger.info("User name is :  "+text);
		return text;
	});
};

budget.prototype.clickOnTableColumnHeader = function(colName, sortType, tableName) {
	var locatorsMap = new Map([["BudgetaryUnit",[this.budgetryUnitsTableXpath, this.budgetaryUnitTableColHeaderXpath]],
								["Budget", [this.budgetTableXpath, this.budgetTableColHeaderXpath]]]);
	var locatorsList = locatorsMap.get(tableName);

	browser.wait(EC.visibilityOf(element(by.xpath(locatorsList[0]))),30000);
	var colList = element.all(by.xpath(locatorsList[1]));

	return colList.getText().then(function(colNames) {
		for(var i = 0; i < colNames.length; i++){
			if(colNames[i].includes(colName)){
					if(sortType == "ascending"){
						return colList.get(i).click().then(function(){
							logger.info("Clicked on Column "+colName);
							return colList.get(i).getAttribute('class').then(function(className){
								if(!className.includes('ascending')){
									return colList.get(i).click().then(function(){
										logger.info("Clicked on Column "+colName+" to make in ascending order");
									});
								}
								else{
									logger.info("Column "+colName+" already in ascending order")
								}
							});
						});
					}
					else if(sortType == "descending"){
						return colList.get(i).click().then(function(){
							logger.info("Clicked on Column "+colName);
							return colList.get(i).getAttribute('class').then(function(className){
								if(className.includes('ascending')){
									return colList.get(i).click().then(function(){
										logger.info("Clicked on Column "+colName+" to make in descending order");
									});
								}
								else{
									logger.info("Column "+colName+" already in descending order")
								}
							});
						});
					}
			}
		}
	});
};

budget.prototype.getColumnIndex = function(colName, columnList){
	return element.all(by.xpath(columnList)).getText().then(function(colNames) {
		for(var i = 0; i < colNames.length; i++){
			if(colNames[i].includes(colName)){
				return i;
			}
		}
	});
};

budget.prototype.verifyValueAtTableCell = function(allRowsLocator, rowNum, colNum, cellVal) {
	var cellXpath = "(" + allRowsLocator + "["+rowNum+"]/td["+colNum+"]//span)[1]";
	logger.info("Column Value xpath: "+cellXpath);

	return element(by.xpath(cellXpath)).getText().then(function(actualVal){
		logger.info("ActualValue: "+actualVal+", ExpectedValue: "+cellVal);
		if(actualVal.includes(cellVal) || actualVal == ""){ // Added "" for External Ref ID column
			return true;
		}
		else{
			return false;
		}
	});

};

budget.prototype.verifySortingOfColumn = function(colName, colValue, tableName) {

	var locatorsMap = new Map([["BudgetaryUnit",[this.budgetryUnitsTableXpath, this.budgetaryUnitTableColNamesXpath, this.budgetaryUnitTableRowsXpath]],
								["Budget", [this.budgetTableXpath, this.budgetTableColNamesXpath, this.budgetTableRowsXpath]]]);
	var locatorsList = locatorsMap.get(tableName);
	var self = this;
	browser.wait(EC.visibilityOf(element(by.xpath(locatorsList[0]))),30000);
	logger.info("\nSearching "+colValue+" in "+colName+" from "+tableName+" table..");

	// Get index for given column name
	return this.getColumnIndex(colName, locatorsList[1]).then(function(index){
		var col = index+2;
		return self.verifyValueAtTableCell(locatorsList[2], 1, col, colValue).then(function(result){
			if (result == false){
				logger.info("Found on first row: "+ result+ "; Searching on second row...");
				return self.verifyValueAtTableCell(locatorsList[2], 2, col, colValue).then(function(res){
					logger.info("Found on second row: "+ res);
					return res;
				})
			}
			else{
				logger.info("Found on first row: "+ result);
				return result;
			}
		});
	});
};

budget.prototype.clickAddBudgetSetBtn = function() {
	var elem = element(by.css(this.btnAddBudgetSetCss));
	browser.wait(EC.elementToBeClickable(elem), 40000);
	return elem.click().then(function(){
		logger.info("Succesfully Clicked on Add Budget Set");
		util.waitForAngular();
	});
};

budget.prototype.setTotalBudgetAmount = function(totalAmount) {
	var elem = element(by.css(this.textboxTotalBudgetAmount));
	browser.wait(EC.elementToBeClickable(elem), 40000);
	elem.clear();
	return elem.sendKeys(totalAmount).then(function(){
		logger.info("Total Budget AMount is set to : " + totalAmount);		
	});
};

budget.prototype.validateBudgetAmountEvenlyDistributed = function(totalBudgetAmount) {
	var budgtAmount = 0;
	var quaterlyBudgtAmountList = element.all(by.css(this.textboxBudgetAmountForEachQuarterCss));
	return new Promise(function(resolve, reject) {
		quaterlyBudgtAmountList.getAttribute("title").then(function(budgetAmountList){
			for(var i = 0; i < budgetAmountList.length; i++){
				budgtAmount = parseInt(budgetAmountList[i]) + budgtAmount; 
			}
			if(budgtAmount == parseInt(totalBudgetAmount)){
				logger.info("Total Budget Amount is distributed evenly in 4 quarters.");
				resolve(true);
			}else{
				logger.info("Total Budget Amount is not distributed evenly in 4 quarters. Expected : " + totalBudgetAmount + " | Actual : " + budgtAmount);
				resolve(false);
			}
		});
	});
};

budget.prototype.updateQuaterlyBudgetAmount = function(budgetAmount){
	var quaterlyBudgtAmountList = element.all(by.css(this.textboxBudgetAmountForEachQuarterCss));	
	quaterlyBudgtAmountList.get(0).clear();
	return quaterlyBudgtAmountList.get(0).sendKeys(budgetAmount).then(function(){
		logger.info("Quaterly budget for first quarter is updated to " + budgetAmount);
	});	
};

budget.prototype.updateQuaterlyBudgetName = function(budgetName){

	return new Promise(function(resolve, reject){
		var quaterlyBudgtAmountList = element.all(by.css(defaultConfig.textboxQuatBudgetName));
		for(var i = 0; i < quaterlyBudgtAmountList.length; i++){
			quaterlyBudgtAmountList.get(i).clear();
			quaterlyBudgtAmountList.get(i).sendKeys(budgetName + "_Q" + i + 1);		
		}
		resolve(true);
	});
};

budget.prototype.validateQuaterlyBudgetsList = function(expBudgetAmnt) {
	util.waitForAngular();	
	var self=this;
	return new Promise(function(resolve, reject){
		var budgtNameElmnts = element.all(by.css(self.tblQuatBdgtNameListCss));
		var budgtAmountElmnts = element.all(by.css(self.tblQuatBdgtAmntListCss));
		budgtNameElmnts.getText().then(function(budgtNamlist){
			budgtAmountElmnts.getText().then(function(list){
				for(var i = 0; i < list.length; i++){
					if(list[i] == expBudgetAmnt){
						logger.info("Budget amount for " + budgtNamlist[i] + " is : " + list[i]);
					}else{
						logger.info("Budget amount for " + budgtNamlist[i] + " is : " + list[i] + " | Expected : " + expBudgetAmnt);
						resolve(false);
					}
				}
				resolve (true);
			});	
		});			
	});	
};

budget.prototype.checkFieldStateOnBudgetPage = function(fieldName) {
	util.waitForAngular();
	var elem = element(by.xpath("//label[text()=' " + fieldName + " ']/../div/div"));
	browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());
	return browser.executeScript("return arguments[0].isContentEditable", elem.getWebElement()).then(function (enabled) {
		logger.info("Field - " + fieldName + " isEnabled : " + enabled);
		return enabled;
	});	
};

budget.prototype.clickBudgetStatustoglBtn = function() {
	var toglBtn = element(by.css("#edit_budgetary_status_toggle + label span:nth-child(2)"));
	util.waitForAngular();	
	browser.sleep(5000);
	browser.wait(EC.elementToBeClickable(toglBtn),90000);
	browser.executeScript("arguments[0].scrollIntoView();", toglBtn.getWebElement());
	return toglBtn.click().then(function(){
		logger.info("Clicked on Budget page Inactive Status...");
	}).catch(function(){
		browser.sleep(7000);
		util.waitForLoader();
		toglBtn.click();
	});		
};

budget.prototype.navigateToBudgetDetailsPage = function(budgetName) {
	var elem = element.all(by.xpath("//a[text() = ' " + budgetName + " ']"));
	browser.wait(EC.elementToBeClickable(elem.last()), 30000);
	return elem.last().click().then(function(){
		logger.info("CLicked on budget link " + budgetName);
		util.waitForAngular();
	})
};

budget.prototype.getValueBasedOnLabelName = function (label) {
	var elemn = element.all(by.xpath("//label[text() = ' " + label + " ']/../div"));
	return elemn.last().getText().then(function (text) {
        	logger.info("Value for  : "+ label + " = " + text);
        	return text;
    	});
};


budget.prototype.deleteBudget = function(budgetaryName) {
	this.open();
	this.searchBudegtaryUnit(budgetaryName);
	/*this.selectbudgetaryPaginationDropDown();
	this.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
	this.validateBudgetaryUnitIsAvailable(budgetaryName);*/
	this.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
	this.clickOnBudgetryBudgetsLink();
	this.clickViewDetailActionIcon();
	this.clickViewDetailBtn();
	this.clickBudgetEditButton();
	this.clickBudgetInactiveStatusText();
	this.clickSaveBudgetButton();
	this.clickOnNotificationCloseButton();
	//this.clickAfterEditingBudgetaryBackButton();
	//this.clickOnBudgetryDetailsLink();
	this.navigateToBudgetDetailsPage(budgetaryName)
	this.clickOnEditBudgetaryButton();
	this.clickBudgetStatustoglBtn();
	this.clickOnBudgetrySaveBtn();
	this.clickOnNotificationCloseButton();
	//this.clickOnDeleteBtnFromBudgetaryDetailsPage();
	//this.clickOnDeleteConfirmationBtn(1);
	//this.closeBudgetSliderIfPresent();
	orderFlowUtil.closeHorizontalSliderIfPresent();
};

budget.prototype.searchBudegtaryUnit = function (BudgetaryUnitName) {
	var curr = this;
	this.waitForTableToLoad("1-10")
	browser.wait(EC.elementToBeClickable(element(by.css(this.searchIconCss))), 60000);
	element(by.css(this.searchIconCss)).click().then(function () {
		logger.info("Clicked on Budgetary Unit Search Icon...");
		var budgetSearchTextbox = element(by.css(curr.searchBoxBudgetaryUnitCss))
		browser.wait(EC.elementToBeClickable(budgetSearchTextbox), 90000);		
		budgetSearchTextbox.clear()		
		budgetSearchTextbox.sendKeys(BudgetaryUnitName).then(function () {
		}).catch(function (err) {
			curr.open()
			curr.searchBudegtaryUnit(BudgetaryUnitName)
		});
		
		budgetSearchTextbox.sendKeys(protractor.Key.ENTER);
		budgetSearchTextbox.sendKeys(protractor.Key.ENTER);
		logger.info("Searched Budgetary Unit " + BudgetaryUnitName);		
		curr.waitForTableToLoad("1-1")		
	});
};

/*budget.prototype.searchBudegtaryUnit = function (BudgetaryUnitName) {
	var curr = this;
	//Wait for loading budget list
	browser.wait(EC.visibilityOf(element(by.css(defaultConfig.tblBudgetListCss))), 60000);
	browser.wait(EC.elementToBeClickable(element(by.css(this.searchIconCss))), 60000);
	element(by.css(this.searchIconCss)).click().then(function () {
		logger.info("Clicked on Budgetary Unit Search Icon...");
		browser.wait(EC.elementToBeClickable(element(by.css(curr.searchBoxBudgetaryUnitCss))), 90000);
		browser.sleep(3000);		
		var searchBox = element(by.css(curr.searchBoxBudgetaryUnitCss));
		searchBox.clear();
		searchBox.sendKeys(BudgetaryUnitName).then(function () {
			searchBox.sendKeys(protractor.Key.ENTER);
			searchBox.sendKeys(protractor.Key.ENTER);
			logger.info("Searched Budgetary Unit " + BudgetaryUnitName);
			util.waitForAngular();
		});
	});
};*/

budget.prototype.getTextBasedOnLabelName = function(labelName){
	util.waitForAngular();
	browser.sleep(2000);
	var elem = element(by.xpath("//label[contains(text(), '" + labelName + "')]//parent::ibm-label//div[@class='bx--form__helper-text']"));
	return browser.wait(EC.visibilityOf(elem), 60000).then(function(){
		return elem.getText().then(function(text){
			logger.info("The value for "+labelName+" is : "+text)
			return text;
		});
	}).catch(function(err){
		logger.info(labelName + " is not displayed within 60s");
		return "";
	});	
};
budget.prototype.getTextBasedOnSpanName = function(labelName){
	return element(by.xpath("//span[contains(text(), '" + labelName + "')]/following-sibling::span")).getText().then(function(text){
	logger.info("The value for "+labelName+" is : "+text)
	return text;
});
};


budget.prototype.waitForTableToLoad = function (pagination_txt) {
	//Wait till first row displays
	var elmRow = element(by.xpath("//tr[1]"))
	browser.wait(EC.visibilityOf(elmRow), 60000)
	//Wait for table to load completely
	var elem = element.all(by.css("span.bx--pagination__text"))
	for (var i = 0; i < 5; i++) {
		elem.get(0).getText().then(function (text) {
			var items_displayed = text.split(" of")[0]
			if (items_displayed == pagination_txt) {
				//break
				return
			} else {
				browser.sleep(3000);
			}
		})
	}
}

module.exports = budget;
