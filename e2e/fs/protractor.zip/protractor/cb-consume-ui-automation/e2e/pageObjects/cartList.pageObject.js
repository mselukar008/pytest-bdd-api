/**********************
 * Author : Deepthi
 **********************/

"use strict";

var extend = require('extend');
var url = browser.params.url;
var EC = protractor.ExpectedConditions;
var util = require('../../helpers/util.js');
var sysuserApikey = require("../../testData/APIs/sysUserAPICreds.json");
var apiUtil = require("../../helpers/snowGooglePassCodeAPi.js");
var secretKey = browser.params.secretKey;
var logGenerator = require("../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger();

var defaultConfig = {
    pageUrl: url + '/cart/cart-list',
    //msgCartSuccessfullyAddedXpath: '//span[contains(text(),"Your service has been added to the cart.")]',
    msgCartSuccessfullyAddedXpath: '//*[contains(text(),"Successfully created bag item with name:")]',
    msgCartSuccessfullyUpdatedXpath: '//*[contains(text(),"Successfully updated cart item.")]',
    buttonTextSubmitOrder: 'Submit Order',
    buttonSubmitCss: '#submit-cart-order-confirmation-modal-carbon-button_submit',
    buttonTextContinueShopping: 'Continue Shopping',
    goToServiceCatalogCss: '#order-submitted-modal_carbon-button',
    orderSubmittedModalHeaderXpath: '//h2[contains(text(),"Order Submitted")]',
    orderSubmittedModalGoToServiceCatalogCss: '#order-submitted-modal_carbon-button',
    orderSubmittedModalOrderNumberTextCss: '#cart-order-number',
    orderSubmittedModalOrderCartNameTextXpath: '//p[contains(text(),"Cart Name")]/span',
    orderSubmittedModalOrderDateTextXpath: '//p[contains(text(),"Date")]/span',
    orderSubmittedModalTotalPriceTextXpath: '//p[contains(text()," Total")]/span',
    orderSubmittedModalSubmittedByTextXpath: '//p[contains(text()," Submitted by")]/span',
    emptyCartButtonXpath: '//*[@id="cartcomponent-empty-cart-button"]',
    menuIconXpath: '//*[@class="bx--overflow-menu"]/button',
    cartNameHeaderCss: 'h1.ibm--page-header__title',
    cartEmptyModalOkButtonXpath: '//*[@id="cart-component-cart-empty-modal_carbon-button_ok"]',
    msgCartSuccessfullyEmptiedXpath: '//span[contains(text(),"Your cart has successfully been emptied")]',
    msgCartSuccessfullyAddedAddOnXpath: '//span[contains(text(),"The add-ons have been successfully updated")]',
    deleteCartButtonXpath: '//*[@id="cartcomponent-delete-cart-button"]',
    cartDeleteModalOkButtonXpath: '//*[@id="cart-component-cart-delete-modal_carbon-button_ok"]',
    msgCartSuccessfullyDeletedXpath: '//span[contains(text(),"Your cart has successfully been deleted")]',
    cartIconCss: 'button[title="Cart"]',
    expandTheCartDetailsTabCss: '#cart-details>button',
    expandCartItemsTabCss: '#cart-items>button',
    editCartContextLinkCss: '#view-cart-updates',
    editCartContextPanelOpenedXpath: '//H3[@class="bx--slide-over-panel-title"][text()="Edit Cart Context"]',
    teamDropDownCss: 'bx--dropdown-single-parent_team:',
    expandTheBillOfMaterialLinkName: 'chevron--up',
    totalQuantityInBOMTableXpath: '//TD[@id="quantity"]/span[@class="total-quantity"]',
    updateButtonXpath: '//*[@id="cartEditUpdate_button"]',
    cartContextParamCss: '[class*="bx--no-gutter"] div div',
    cartContextValuesCss: '[class*="bx--no-gutter"] div label',
    txtTotalPriceXpath: '//td[@id="non-one-time-charge"]',
    btnExpandQuantXpath: '//tr/td/button',
    lnkBillOfMaterialXpath: '//span[contains(text(),"Bill of Materials")]',
    txtEstimatedCostXpath: '//*[@class="table-row-estimatedcost-column"]',
    // txtEstimatedCostXpath: '//label[contains(text(),"Estimated Cost")]/following-sibling::div',
    closeNotificationIconCss: '.bx--toast-notification__close-icon',
    txtboxCartNameCss: '#text-input-edit_cart_name',
    tranferCartButtonXpath: '//*[@id="cartcomponent-transfer-cart-button"]',
    searchTextBoxInputXpath: '//input[contains(@id,"text-input_")]',
    cartTransferModalButtonXpath: '//*[@id="cart-transfer-button-transfer"]',
    msgCartSuccessfullyTransferredXpath: '//span[starts-with(text(),"Your cart has successfully been transferred to")]',
    userIconCss: "[title='User']",
    logoutButtonCss: '.bottom button',
    deleteItemModalHeader: "//h2[contains(text(),'Delete Cart Item')]",
    btnOkdeleteItemModal: "#alert-modal-button-1",
    btnCanceldeleteItemModal: '#cart-item-component-cart-delete-modal_carbon-button_cancel',
    msgSuccessfullyDeletedCartItem: "//span[contains(text(),'Success')]",
    lblOfferingNameXpath: '//label[contains(text(),"Offering Name")]/following-sibling::div',
    txtOrderTotalXpath: '//*[@class="orderTotalValue"]',
    notifcnCloseBtnXpath: '//*[@class="bx--toast-notification__close-icon"]',
    cartListXpath: '//*[@class="bx--switcher__item-link"]',
    txtTransfrCartXpath: '//span[@class="body"]',
    textBoxInstancePrefixCss: '#text-input-main_params-serviceName',
    radioButtonsAddtoCartCss: '.bx--radio-button-group carbon-radio-button',
    dropdownEnvCss: '#env',
    dropdownAppCss: '#app',
    radioButtonTeamCss: '[id="#radio-button-team_TEAM1"]',
    radioButtonProviderAccountCss: '.bx--radio-button-group carbon-radio-button',
    checkboxAddToCartCss: '#checkbox-useShoppingCart',
    cartListCss: '.bx--switcher__item-link',
    textCartNotAvailableCss: '.empty-cart-error p',
    linkEmptyCartGoToCatalogCss: '.empty-cart-error a',
    btnNotificnCloseCss: '.bx--toast-notification__close-button',
    usernameIdCss: "#desktop",
    passwordClsCss: ".ibm-fullwidth",
    continueBtnCss: "#continue-button",
    loginBtnCss: "#signinbutton",
    usernameCss: "[id='username']",
    passwordCss: "[id='password']",
    ibmUserName: "[name='username']",
    ibmpassWord: "[name='password']",
    signinbuttonCss: '#btn_signin',
    googleAuthCss: '#gaOTP',
    otppswdCss: "#otppswd",
    submitBtnCss: "#btn_submit",
    privacyProceedBtnCss: "#confirm-btn",
    cartNameTextboxCss: "#text-input-main_params-cartName",
    newCartCss: "[value='newCart']",
    addToCartChkbxId: 'checkbox-useShoppingCart',
    noticeHeaderCss: ".privacy-header",
    privacyPolicyAcceptBtnCss: ".privacy-footer button:nth-child(2)",
    buttonDeleteItemXpath: "//div[contains(text(), 'Delete')]",
    cartActionIconCss: 'button.bx--overflow-menu',
    viewServiceDetailsCss: '#cart-overflow-menu-view-details',
    closeViewButton: '[class="is-active"] button.bx--slide-over-panel--close',
    viewServiceBomCss: '#cart-overflow-menu-BOM-details',
    viewServiceAddOnButtonText: 'Manage Add-ons',
    viewEditServiceCss: '#cart-overflow-menu-edit-service',
    viewDeleteServiceCss: '#cart-overflow-menu-delete',
    orderTotalCostBillofMaterialsTabCss: '#total_cost_value',
    msgCurrCartSuccessfullyDeletedXpath: '//span[contains(text(),"The cart item(s) have been deleted successfully")]',
    closeButtonOfOrderDetailsSlidderCss: '.bx--slide-over-panel--close',
    editSaveBtnCss: '#primary-btn-review-order',
    addOnSaveBtnCss: '#manage-addons-step_save-button',
    DeleteOkButtonForCartItemCss: "#alert-modal-button-1",
    IMITagInItemTableCss: ".data-table-tag",
    viewAllCartsCss: "h4.mouse-hand",
    lnkMoreCss: "a#bom-view",
    cartNameCss: "#cart-details h4",
    storeHeaderCss: '.bx--header__name',
    cartItemActnBtnCss: 'td.table-row-overflow-menu div button',
    serviceNameCartCss: 'td.table-row-id-column',
    txtCartOwnerXpath: "//*[contains(text(), 'Owner')]/../div",
    w3idUsernameCss: "#user-name-input",
    w3idPasswordCss: "#password-input",
    w3idSignBtnCss: "#login-button",
    w3idOtpTextBoxCss: "input#otp-input",
    kynTotpBtnCss: "#totp",
    kynOtpSubmitBtn: "#otp-login-button"
};

function cartList(selectorConfig) {
    if (!(this instanceof cartList)) {
        return new cartList(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

cartList.prototype.open = function () {
    browser.get(this.pageUrl);
    //browser.sleep(10000);
    browser.wait(EC.urlContains("/cart/cart-list"), 10000).then(function () {
        logger.info("Navigated to cart list page...");
    });
    util.waitForAngular();
};

cartList.prototype.clickOnStorageHeaderLink = function () {

    util.switchToDefault();
    browser.wait(EC.visibilityOf(element(by.css(this.storeHeaderCss))), 25000);
    element(by.css(this.storeHeaderCss)).click().then(function () {
        logger.info("Clicked on Storage Header link");
        util.waitForAngular();
    });
}

cartList.prototype.switchToFrame = function () {
    browser.switchTo().frame(element(by.tagName('iframe')).getWebElement());
    logger.info("Switched to iframe");
};

cartList.prototype.getServiceSuccessfullyAddedToCart = function () {
    browser.wait(EC.visibilityOf(element(by.xpath(this.msgCartSuccessfullyAddedXpath))), 15000);
    return element(by.xpath(this.msgCartSuccessfullyAddedXpath)).getText().then(function (text) {
        logger.info(text);
        var msg = text.split(':');
        return msg[0];
    });
};

cartList.prototype.isPresentSuccessfullyAddedToCart = function () {
    browser.wait(EC.visibilityOf(element(by.xpath(this.msgCartSuccessfullyAddedXpath))), 40000);
    return element(by.xpath(this.msgCartSuccessfullyAddedXpath)).isPresent().then(function (result) {
        logger.info("Success message is present");
        return result;
    });
};

cartList.prototype.isPresentSuccessfullyUpdatedCart = function () {
    browser.wait(EC.visibilityOf(element(by.xpath(this.msgCartSuccessfullyUpdatedXpath))), 40000);
    return element(by.xpath(this.msgCartSuccessfullyUpdatedXpath)).isPresent().then(function (result) {
        logger.info("Success message is present");
        return result;
    });
};

cartList.prototype.submitOrder = function (cartNo) {
    browser.wait(EC.visibilityOf(element.all(by.buttonText(this.buttonTextSubmitOrder)).get(cartNo)), 25000);
    element.all(by.buttonText(this.buttonTextSubmitOrder)).get(cartNo).click().then(function () {
        logger.info("Clicked on Submit Order");
        util.waitForAngular();
    });

    browser.wait(EC.visibilityOf(element(by.css(this.buttonSubmitCss))), 90000);
    element(by.css(this.buttonSubmitCss)).click().then(function () {
        logger.info("Clicked on Submit confirmation popup");
        util.waitForAngular();
        browser.sleep(10000);
    });
}

//Function to click on Continue Shopping Button
cartList.prototype.continueShopping = function () {
    browser.wait(EC.visibilityOf(element(by.buttonText(this.buttonTextContinueShopping))), 25000);
    return element(by.buttonText(this.buttonTextContinueShopping)).click().then(function () {
        util.waitForAngular();
        browser.sleep(10000);
    });
}


//****************FUNCTIONS IN ORDER SUBMITTED POP UP***************************
cartList.prototype.clickgoToServiceCatalogButtonOrderSubmittedModal = function () {
    util.waitForAngular();
    browser.sleep(3000);
    return element(by.css(this.orderSubmittedModalGoToServiceCatalogCss)).click().then(function () {
        logger.info("Clicked on Go to service catalog button")
    });
};

cartList.prototype.getTextOrderSubmittedHeaderOrderSubmittedModal = function () {
    browser.sleep(5000);
    browser.wait(EC.visibilityOf(element(by.xpath(this.orderSubmittedModalHeaderXpath))), 95000);
    return element(by.xpath(this.orderSubmittedModalHeaderXpath)).getText().then(function (text) {
        logger.info(text)
        return text;
    });
};

cartList.prototype.getTextOrderNumberOrderSubmittedModal = function () {
    return element(by.css(this.orderSubmittedModalOrderNumberTextCss)).getText().then(function (text) {
        logger.info("Order number : " + text);
        return text;
    });
};

cartList.prototype.getTextOrderedDateOrderSubmittedModal = function () {
    return element(by.xpath(this.orderSubmittedModalOrderDateTextXpath)).getText().then(function (text) {
        logger.info("Ordered Date : " + text);
        return text;
    });
};

cartList.prototype.getTextTotalPriceOrderSubmittedModal = function () {
    return element(by.xpath(this.orderSubmittedModalTotalPriceTextXpath)).getText().then(function (text) {
        logger.info("Total Price : " + text);
        var str1 = text.substr(4, 5);
        var str2 = text.substr(32, 5);
        var str3 = str2.replace(",", "");
        var str4 = parseFloat(str1) + parseFloat(str3);
        str4 = Math.round(str4);
        str4 = str4.toString();
        //var total = "USD"+str4.toString();
        return str4;
    });
};

cartList.prototype.getTextSubmittedByOrderSubmittedModal = function () {
    return element(by.xpath(this.orderSubmittedModalSubmittedByTextXpath)).getText().then(function (text) {
        logger.info("Submitted By : " + text);
        return text;
    });
};

cartList.prototype.clickMenuIcon = function (cartNo) {
    util.waitForAngular();
    browser.sleep(2000); //to load cart page
    browser.wait(EC.elementToBeClickable(element(by.xpath("//*[@id='cart-details-overflow-menu-" + cartNo + "']"))), 90000);
    return element(by.xpath("//*[@id='cart-details-overflow-menu-" + cartNo + "']")).click().then(function () {
        logger.info("Succesfully clicked on Menu icon");
    });
};

cartList.prototype.clickCartIcon = function () {
    browser.switchTo().defaultContent();
    var cartIcon = element(by.css(this.cartIconCss));
    util.waitForAngular();
    browser.sleep(3000);
    browser.wait(EC.elementToBeClickable(cartIcon), 60000).then(function () {
        logger.info("Waiting for cart icon to be clickable");
    }).catch(function (err) {
        logger.info("Cart icon is not clickable within 60s");
    });
    return cartIcon.click().then(function () {
        logger.info("Succesfully clicked on Cart icon");
    }).catch(function (err) {
        browser.sleep(30000);
        return cartIcon.click().then(function () {
            logger.info("Succesfully clicked on Cart icon in 2nd attempt");
        });
    });
};

cartList.prototype.emptyCart = function (cartNo) {
    element(by.css("#cart-details-empty-cart-" + cartNo + "")).click().then(function () {
        logger.info("Succesfully clicked on Empty Cart");
    });

    browser.wait(EC.visibilityOf(element(by.xpath(this.cartEmptyModalOkButtonXpath))), 30000);
    element(by.xpath(this.cartEmptyModalOkButtonXpath)).click().then(function () {
        logger.info("Succesfully clicked on ok button");
    });
    browser.sleep(3000);
    //browser.wait(EC.visibilityOf(element(by.xpath(this.msgCartSuccessfullyEmptiedXpath))), 30000);
    return element(by.xpath(this.msgCartSuccessfullyEmptiedXpath)).isPresent().then(function (result) {
        logger.info(result);
        return result;
    });
};

cartList.prototype.getTextSuccessfullyEmptiedCart = function () {
    util.waitForAngular();
    //browser.sleep(2000);
    browser.wait(EC.visibilityOf(element(by.xpath(this.msgCartSuccessfullyEmptiedXpath))), 90000);
    return element(by.xpath(this.msgCartSuccessfullyEmptiedXpath)).getText().then(function (text) {
        logger.info("Cart Emptied - " + text);
        return text;
    });
}

cartList.prototype.getTextSuccessfullyAddedAddOnFromCart = function () {
    browser.sleep(3000);
    return element(by.xpath(this.msgCartSuccessfullyAddedAddOnXpath)).getText().then(function (addOnSuccessMsg) {
        logger.info("Add on added from Cart : - " + addOnSuccessMsg);
        return addOnSuccessMsg;
    });
}
cartList.prototype.deleteCart = function (cartNo) {
    browser.wait(EC.elementToBeClickable(element(by.xpath("//*[@id='cart-details-delete-cart-" + cartNo + "']"))), 90000);
    element(by.xpath("//*[@id='cart-details-delete-cart-" + cartNo + "']")).click().then(function () {
        logger.info("clicked on Delete Cart");
    });

    browser.wait(EC.elementToBeClickable(element(by.xpath(this.cartDeleteModalOkButtonXpath))), 90000);
    return element(by.xpath(this.cartDeleteModalOkButtonXpath)).click().then(function () {
        logger.info("clicked on OK Button");
    });

    /*browser.wait(EC.visibilityOf(element(by.xpath(this.msgCartSuccessfullyDeletedXpath))), 5000);
    return element(by.xpath(this.msgCartSuccessfullyDeletedXpath)).isPresent().then(function (result) {
        logger.info("Success message is present : Your cart has successfully been deleted.");
        return result;
    });*/
};

cartList.prototype.getDeletedCartSuccessMessage = function () {
    // browser.ignoreSynchronization = true;
    //util.waitForAngular();	
    browser.sleep(2000);
    browser.wait(EC.visibilityOf(element(by.xpath(this.msgCartSuccessfullyDeletedXpath))), 90000);
    return element(by.xpath(this.msgCartSuccessfullyDeletedXpath)).getText().then(function (result) {
        logger.info(result);
        return result;
    });
};

cartList.prototype.selectCartFromList = function (cartName) {
    browser.ignoreSynchronization = true;
    util.waitForAngular();
    var elementToClick = element(by.linkText(cartName));
    browser.executeScript("arguments[0].scrollIntoView();", elementToClick.getWebElement()).then(function () {
        logger.info("Scrolling to cart item.")
    }).catch(function (err) {
        logger.info("No element found");
        browser.sleep(3000);
    });
    browser.wait(EC.elementToBeClickable(elementToClick, 30000)).then(function () {
        logger.info("Element is clickable");
    }).catch(function (err) {
        logger.info("Element is not clickable");
    });

    return elementToClick.click().then(function () {
        //    browser.ignoreSynchronization = false; 
        logger.info("Cart Selected - " + cartName);
    });
};

cartList.prototype.expandsTheCartDetailsTab = function () {
    util.waitForAngular();
    browser.wait(EC.elementToBeClickable(element(by.css(this.expandTheCartDetailsTabCss))), 60000);
    return element.all(by.css(this.expandTheCartDetailsTabCss)).first().click().then(function () {
        browser.ignoreSynchronization = false;
        logger.info("Succesfully clicked on Expand Cart Details link");
    });

};

cartList.prototype.expandsTheCartItemsTab = function () {
    util.waitForAngular();
    browser.wait(EC.elementToBeClickable(element.all(by.css(this.expandCartItemsTabCss)).first()), 60000);
    return element.all(by.css(this.expandCartItemsTabCss)).first().click().then(function () {
        browser.ignoreSynchronization = false;
        logger.info("Succesfully clicked on Expand Cart Items link");
    });

};

cartList.prototype.verifyEditCartContextSidePanelIsClosed = function () {
    util.waitForAngular();
    logger.info("Waiting for Edit cart panel to close..");
    browser.wait(EC.invisibilityOf(element(by.xpath(this.editCartContextPanelOpenedXpath))), 60000).then(function () {
        logger.info("Edit cart panel is closed");
    })
}

// Get cart name from header
cartList.prototype.getCartHeaderName = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.cartNameHeaderCss))), 10000);
    return element(by.css(this.cartNameHeaderCss)).getText().then(function (headerName) {
        logger.info("Cart header name is: " + headerName);
        return headerName;
    });
}

cartList.prototype.getCartName = function (cartName) {
    var cartNameElement = element(by.xpath("//h4//strong[contains(text(), '" + cartName + "')]"));
    //var cartNameElement =  element(by.xpath('//label[contains(text(),"Cart Name")]/following-sibling::div'));
    browser.wait(EC.visibilityOf(cartNameElement), 90000);
    return cartNameElement.getText().then(function (text) {
        logger.info("Cart Name is:  " + text);
        return text;
    });
};

cartList.prototype.clickOnEditCartContext = function (cartNo) {
    browser.wait(EC.visibilityOf(element(by.css("#cart-details-edit-cart-context-" + cartNo + ""))), 10000);
    return element(by.css("#cart-details-edit-cart-context-" + cartNo + "")).click().then(function () {
        logger.info("Clicked on " + cartNo + " menu's edit cart context button");
    });
};

cartList.prototype.clickOnEditCartContextLink = function () {
    browser.wait(EC.elementToBeClickable(element(by.css(this.editCartContextLinkCss))), 10000);
    return browser.executeScript("arguments[0].click();", element(by.css(this.editCartContextLinkCss))).then(function () {
        logger.info("Clicked on Edit Cart");
    });
};

cartList.prototype.verifyEditCartContextPanelIsOpened = function () {
    util.waitForAngular();
    var editCartContextPanelTitleElement = element(by.xpath(this.editCartContextPanelOpenedXpath));
    browser.wait(EC.visibilityOf(editCartContextPanelTitleElement), 90000);
    //browser.wait(editCartContextPanelTitleElement, 60000).then(function () {
    editCartContextPanelTitleElement.getText().then(function (text) {
        expect(text).toBe("Edit Cart Context");
    });
    //});
};

cartList.prototype.editCartDetails = function (jsonTemplate, modifiedParamMap) {
    var deferred = protractor.promise.defer();
    var requiredReturnMap = {}, expectedMap = {}, actualMap = {};
    var jsonObject = JSON.parse(JSON.stringify(jsonTemplate));
    var elem = null;
    var orderParameters, jsonObjectForParameters;
    //browser.ignoreSynchronization = false;
    orderParameters = Object.keys(jsonObject["Edit Cart Parameters"]);
    jsonObjectForParameters = jsonObject["Edit Cart Parameters"];
    Object.keys(orderParameters).forEach(function (detailSection) {
        browser.executeScript('window.scrollTo(0,0);')
        var webElements = Object.keys(jsonObjectForParameters[orderParameters[detailSection]]);
        Object.keys(webElements).forEach(function (webElement) {
            var environment = browser.params.url.includes("cb-qa-1") ? "QA 1" : browser.params.url.includes("cb-qa-2") ? "QA 2" : browser.params.url.includes("customer1") ? "Customer 1" : browser.params.url.includes("d2ops-test") ? "D2OPS" : "QA 4";
            var webElementObject = Object.keys(jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]]);
            var elementType = Object.values(jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]][webElementObject[0]]).join("");
            var elementID = Object.values(jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]][webElementObject[1]]).join("");
            var elementValue = Object.values(jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]][webElementObject[2]][environment]).join("");
            elem = elementID;
            if (modifiedParamMap != undefined) {
                if (Object.keys(modifiedParamMap).includes(webElements[webElement]))
                    elementValue = modifiedParamMap[webElements[webElement]];
            }
            if (!elementValue == "") {
                if (elementType == "Dropdown") {
                    var dropdown = element(by.css("[id=\"" + elementID + "\"]"));
                    //browser.ignoreSynchronization = false;
                    util.waitForAngular();
                    browser.sleep(3000)
                    browser.wait(EC.elementToBeClickable(dropdown), 5000).then(function () {
                        dropdown.isEnabled().then(function (enabled) {
                            if (enabled) {
                                //dropdown.click().then(function(){ //*******Added below line of code for click***//
                                browser.actions().mouseMove(dropdown).click().perform().then(function () {
                                    var dropDownValuesArray = element.all(by.xpath("//*[@id='" + elementID + "']//carbon-dropdown-option//li"));
                                    dropDownValuesArray.getText().then(function (textArray) {
                                        var isDropDownValuePresent = false;
                                        for (var i = 0; i < textArray.length; i++) {
                                            if (textArray[i] == elementValue) {
                                                dropDownValuesArray.get(i).click().then(function () {
                                                    logger.info("Selected " + elementValue + " from " + webElements[webElement] + " dropdown");
                                                    expectedMap[webElements[webElement].trim()] = elementValue.trim();
                                                    deferred.fulfill(expectedMap);
                                                });
                                                isDropDownValuePresent = true;
                                            }
                                        }
                                        if (!isDropDownValuePresent) {
                                            dropDownValuesArray.get(0).getText().then(function (text) {
                                                dropDownValuesArray.get(0).click().then(function () {
                                                    logger.info("Selected " + text + " from " + webElements[webElement] + " dropdown");
                                                    expectedMap[webElements[webElement].trim()] = text.trim();
                                                    deferred.fulfill(expectedMap);
                                                });
                                            });
                                        }
                                    });
                                });
                            }
                        });

                    });
                }
                if (elementType == "InputOptions") {
                    var inputBox = element(by.css("#" + elementID + " input[value='" + elementValue + "'] ~ .bx--tile-content"));
                    util.waitForAngular();
                    browser.wait(EC.elementToBeClickable(inputBox), 10000).then(function () {
                        inputBox.click().then(function () {
                            logger.info("Clicked on the Button " + webElements[webElement]);
                            expectedMap[webElements[webElement].trim()] = elementValue.trim();
                            deferred.fulfill(expectedMap);
                        });
                    });
                }
                if (elementType == "RadioButton") {
                    // browser.sleep(5000);
                    var radioButtion = element(by.css("[id*=\"" + elementID + "\"]"));
                    util.waitForAngular();
                    browser.sleep(3000);
                    browser.wait(EC.elementToBeClickable(radioButtion), 300000);
                    browser.executeScript("arguments[0].click();", radioButtion.getWebElement()).then(function () {
                        logger.info("Selected " + elementValue + " radio button for " + webElements[webElement]);
                        expectedMap[webElements[webElement].trim()] = elementValue.trim();
                        deferred.fulfill(expectedMap);
                    });
                }
                if (elementType == "Textbox") {
                    var textbox = element(by.css("[id^=\"" + elementID + "\"]"));
                    util.waitForAngular();
                    //    browser.sleep(5000);
                    browser.wait(EC.presenceOf(textbox), 60000);
                    textbox.clear().then(function () {
                        logger.info("Cleared " + webElements[webElement] + " textbox");
                        var ctrlA = protractor.Key.chord(protractor.Key.CONTROL, "a");
                        textbox.sendKeys(ctrlA);
                    });
                    textbox.sendKeys(elementValue).then(function () {
                        logger.info("Entered " + elementValue + " in " + webElements[webElement] + " textbox");
                        expectedMap[webElements[webElement].trim()] = elementValue.trim();
                        deferred.fulfill(expectedMap);
                    })
                    util.waitForAngular();
                }
                if (elementType == "DropdownSearch") {
                    util.waitForAngular();
                    //var dropdownbox = element(by.css("[id=\""+elementID+"\"] div"));
                    var dropdownbox = element(by.xpath("//*[@id='" + elementID + "' or @id = '" + elementID.toLowerCase() + "']/div"));
                    util.waitForAngular();
                    browser.sleep(5000);
                    browser.wait(EC.presenceOf(dropdownbox), 10000).then(function () {
                        dropdownbox.click().then(function () {
                            browser.sleep(1000);
                            util.waitForAngular();
                            //var dropDownValuesArray = element.all(by.xpath("//*[@id='" + elementID + "']//ul//li"));
                            var dropDownValuesArray = element.all(by.xpath("//*[@id='" + elementID + "' or @id = '" + elementID.toLowerCase() + "']//ul//li"));
                            dropDownValuesArray.getText().then(function (textArray) {
                                var isDropDownValuePresent = false;
                                for (var i = 0; i < textArray.length; i++) {
                                    if (textArray[i] == elementValue) {
                                        dropDownValuesArray.get(i).click().then(function () {
                                            logger.info("Selected " + elementValue + " from " + webElements[webElement] + " dropdown");
                                            expectedMap[webElements[webElement].trim()] = elementValue.trim();
                                            deferred.fulfill(expectedMap);
                                        });
                                        isDropDownValuePresent = true;
                                    }
                                }
                                if (!isDropDownValuePresent) {
                                    dropDownValuesArray.get(0).getText().then(function (text) {
                                        dropDownValuesArray.get(0).click().then(function () {
                                            logger.info("Selected " + text + " from " + webElements[webElement] + " dropdown");
                                            expectedMap[webElements[webElement].trim()] = text.trim();
                                            deferred.fulfill(expectedMap);
                                        })
                                    })
                                }
                            });
                        });
                    });

                }
            } else {
                browser.sleep(3000);
            }
        });
        util.waitForAngular();
    });
    requiredReturnMap["Expected"] = expectedMap;
    deferred.fulfill(requiredReturnMap);
    return deferred.promise;
};

cartList.prototype.clickOnUpdateCartButton = function () {
    browser.wait(element(by.xpath(this.updateButtonXpath)), 19000);
    return element(by.xpath(this.updateButtonXpath)).click().then(function () {
        logger.info("Succesfully clicked on update cart button");
        util.waitForAngular();
        browser.sleep(2000);
        browser.wait(EC.elementToBeClickable(element.all(by.css(defaultConfig.expandCartItemsTabCss)).get(0)), 120000);
    });
};

cartList.prototype.getCartContextData = function () {
    var requiredReturnMap = {}, actualMap = {};
    var deferred = protractor.promise.defer();
    var cartContextParamElements = this.cartContextParamCss;
    var cartContextValueElements = this.cartContextValuesCss;
    browser.wait(EC.visibilityOf(element(by.css(cartContextParamElements))), 90000);
    browser.wait(EC.visibilityOf(element(by.css(cartContextValueElements))), 90000);
    element.all(by.css(cartContextParamElements)).getText().then(function (keysArray) {
        element.all(by.css(cartContextValueElements)).getText().then(function (valuesArray) {
            for (var i = 0; i < keysArray.length; i++) {
                //actualMap[keysArray[i].split(":")[0].trim()] = valuesArray[i].trim();
                if (keysArray[i] != "") {
                    actualMap[keysArray[i].split(":")[0].trim()] = valuesArray[i].trim();
                }
            }
            deferred.fulfill(actualMap);
        });
    });
    requiredReturnMap["Actual"] = actualMap;
    deferred.fulfill(requiredReturnMap);
    return deferred.promise;
};

cartList.prototype.searchCartFromList = function (cartName) {
    util.waitForAngular();
    var elem = element(by.linkText(cartName));
    logger.info("Searching cart in cart List");
    browser.wait(EC.visibilityOf(elem), 10000).catch(function () {
        logger.info(cartName + " is displayed in cart list");
    }).catch(function () {
        logger.info(cartName + " is not displayed in cart list");
    });
    return elem;
};

cartList.prototype.isPresentCartInCartList = function (cartName) {
    return element.all(by.linkText(cartName)).isPresent();
};

cartList.prototype.getTextCartName = function () {
    return element.all(by.css(this.cartListCss)).getAttribute("innerText").then(function (text) {
        return text;
    });
};

cartList.prototype.closeNotificationPopUp = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.closeNotificationIconCss))), 20000);
    element(by.css(this.closeNotificationIconCss)).click().then(function () {
        logger.info("Closed Notification Pop Up Box");
        browser.sleep(5000);
    });
};

cartList.prototype.clickBillOfMaterials = function () {
    var elem = element(by.xpath(this.lnkBillOfMaterialXpath));
    browser.wait(EC.elementToBeClickable(elem), 40000);
    browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());
    return element(by.xpath(this.lnkBillOfMaterialXpath)).click().then(function () {
        logger.info("Clicked on Bill of Materials link");
        util.waitForAngular();
    });
};

cartList.prototype.clickExpandQuantity = function () {
    var elem = element(by.xpath(this.btnExpandQuantXpath));
    browser.executeScript("javascript:window.scrollBy(250, 350)");
    browser.sleep(3000);
    //return browser.wait(EC.elementToBeClickable(elem), 40000).then(function(){
    return elem.click().then(function () {
        logger.info("Clicked on Expand Arrow for Quantity icon");
        util.waitForAngular();
    }).catch(function (err) {
        browser.executeScript("document.getElementById('quantity').scrollIntoView(false)");
        browser.sleep(3000);
        browser.executeScript("arguments[0].click();", elem);
    });

};

cartList.prototype.getTotalPriceOfAllInstances = function () {
    var self = this;
    var totalPriceOfAllInstancesInBOM = 0;
    return element.all(by.xpath(this.txtTotalPriceXpath)).getText().then(function (arr) {
        for (var i = 0; i < arr.length; i++) {
            totalPriceOfAllInstancesInBOM = totalPriceOfAllInstancesInBOM + parseFloat(arr[i].replace("USD ", ""));
            logger.info("Price of instance " + i + " is : " + arr[i]);
        }
        var totalCostCalculatedinBOM = parseFloat(totalPriceOfAllInstancesInBOM).toFixed(4);
        logger.info("Total price of all instances: " + totalCostCalculatedinBOM);
        var estimatedCost = self.getEstimatedCost()
        var cost = Promise.resolve(estimatedCost);
        cost.then(function (value) {
            value.substring(0, value.indexOf("+"));
            var totalEstimatedCost = parseFloat(value.replace("USD ", "")).toFixed(4);
            logger.info("Total estimated cost shown in cart: " + totalEstimatedCost);
            if (totalEstimatedCost == totalCostCalculatedinBOM) {
                logger.info("Total estimated price and sum of price of individual instances in BOM table matches");
            }
            else {
                return false;
            }
        })
        return true;
    })
};


cartList.prototype.getEstimatedCost = function () {
    return element(by.xpath(this.txtEstimatedCostXpath)).getText().then(function (text) {
        logger.info("Total Estimated Cost in cart page : " + text);
        return text;
    });
};

cartList.prototype.getCartTestData = function (serviceDataTemplate) {
    var cartDataObj = JSON.parse(JSON.stringify(serviceDataTemplate));
    var cartName = "aut-" + cartDataObj.provider.toLowerCase() + "-" + util.getRandomString(3).toLowerCase();
    cartDataObj["Order Parameters"]["Main Parameters"]["Cart Service"] = {
        "type": "CheckBox",
        "id": "checkbox-useShoppingCart",
        "value": {
            "QA 1": "Click",
            "QA 2": "Click",
            "QA 4": "Click",
            "Customer 1": "Click"
        }
    };
    cartDataObj["Order Parameters"]["Main Parameters"]["New Shopping Cart"] = {
        "type": "InputOptions",
        "id": "cartGroup",
        "value": {
            "QA 1": "newCart",
            "QA 2": "newCart",
            "QA 3": "newCart",
            "QA 4": "newCart",
            "Customer 1": "newCart"
        }
    };
    cartDataObj["Order Parameters"]["Main Parameters"]["Cart Name"] = {
        "type": "Textbox",
        "id": "text-input-main_params-cartName",
        "value": {
            "QA 1": cartName,
            "QA 2": cartName,
            "QA 3": cartName,
            "QA 4": cartName,
            "Customer 1": cartName
        }
    };

    return cartDataObj;

};

cartList.prototype.validateEstimatedCostAllServicesInCart = function (serviceListExp) {
    var elmEstimatedCost = element.all(by.xpath(this.txtEstimatedCostXpath));
    var elmServiceName = element.all(by.xpath(this.lblOfferingNameXpath));
    var lnkBillOfMaterial = element.all(by.xpath(this.lnkBillOfMaterialXpath));
    var cartListPage = new cartList();
    let promiseArr = [];
    var finlValidn = false;

    elmServiceName.getText().then(function (serviceList) {
        return elmEstimatedCost.getText().then(function (textArray) {
            for (var i = 0; i < textArray.length; i++) {
                //Check if service is present
                if (Object.keys(serviceListExp).includes(serviceList[i])) {
                    //Validate Estimated Cost on page
                    if (textArray[i] == serviceListExp[serviceList[i]]) {
                        logger.info("Estimated Cost on shopping cart page for :" + serviceList[i] + " is - " + textArray[i]);
                        //Validate Pricing through BOM                        
                        cartListPage.clickActionIcon(i);
                        cartListPage.clickCurrentCartBOMDetails();

                        finlValidn = cartListPage.getTotalPriceOfAllInstances();
                        lnkBillOfMaterial.get(i).click();
                        browser.sleep(2000);
                        browser.executeScript("arguments[0].scrollIntoView();", lnkBillOfMaterial.get(i).getWebElement());
                    } else {
                        logger.info("Estimated Cost Mismatch on shopping cart page for :" + serviceList[i] + " | Actual - " + textArray[i] + " | Expected - " + serviceListExp[serviceList[i]]);
                    }
                    promiseArr.push(finlValidn);
                }
            }

        });
    });

    return Promise.all(promiseArr).then(function (finlValidn) {
        if (finlValidn.indexOf(false) != -1) {
            return Promise.resolve(false);
        } else {
            return Promise.resolve(true);
        }
    });

};

cartList.prototype.getOrderTotal = function () {
    var elmOrderTotal = element(by.xpath(this.txtOrderTotalXpath));
    browser.wait((EC.elementToBeClickable(elmOrderTotal)), 40000);
    return elmOrderTotal.getText().then(function (text) {
        logger.info("Order total on shopping cart page is : " + text);
        return text;
    });

};


cartList.prototype.setCartName_EditCartContext = function (cartName) {
    element(by.css(this.txtboxCartNameCss)).clear();
    return element(by.css(this.txtboxCartNameCss)).sendKeys(cartName).then(function () {
        logger.info("Cart name is entered");
    });
};
cartList.prototype.clickUserIcon = function () {
    util.waitForAngular();
    util.switchToDefault();
    var elemToClick = element.all(by.css(this.userIconCss)).last();
    browser.wait(EC.elementToBeClickable(elemToClick), 60000);
    elemToClick.click().then(function () {
        logger.info("clicked on User Icon");
    }).catch(function (err) {
        browser.sleep(5000);
        elemToClick.click().then(function () {
            logger.info("clicked on User Icon in 2nd attempt");
        });
    });
};

cartList.prototype.clickLogoutButton = function () {
    var self = this;
    util.waitForAngular();
    var logOutBtn = element(by.css(this.logoutButtonCss));
    browser.wait(EC.elementToBeClickable(logOutBtn), 10000).then(function () {
        logger.info("Waiting for logout button to be enabled");
    }).catch(function (err) {
        logger.info("Logout button not Found ..Clicking on Cart icon again");
        self.clickCartIcon();
    });

    return logOutBtn.click().then(function () {
        //Verify user is logged out succesfully
        var msg = element(by.css(".logout-main h1"));
        browser.wait(EC.visibilityOf(msg), 60000);
        msg.getText().then(function (text) {
            if (text == "You have been successfully logged out.") {
                logger.info("Logged out with current user");
                browser.sleep(6000);
            }
        });
    });
};

cartList.prototype.searchForUserID = function (userID) {
    util.waitForAngular();
    element(by.xpath(this.searchTextBoxInputXpath)).clear();
    element(by.xpath(this.searchTextBoxInputXpath)).sendKeys(userID);
    browser.wait(EC.visibilityOf(element(by.xpath("//span[contains(text(), '" + userID + "')]"))), 10000);
    util.scrollToWebElement(element(by.xpath("//span[contains(text(), '" + userID + "')]")));
    element(by.xpath("//span[contains(text(), '" + userID + "')]")).click().then(function () {
        logger.info("Searching for ID to tranfer cart");
    });
    return userID;
};
cartList.prototype.tranferCart = function (cartNo) {
    element(by.css("#cart-details-transfer-cart-" + cartNo + "")).click().then(function () {
        logger.info("clicked on tranfer Cart");
    });
};
cartList.prototype.confirmTransfer = function () {
    //var cartListPage = new cartList();
    element(by.xpath(this.cartTransferModalButtonXpath)).click().then(function () {
        logger.info("clicked on Tranfer");
    });
    element(by.xpath(this.cartTransferModalButtonXpath)).click().then(function () {
        logger.info("clicked on Transfer again");
        //expect(cartListPage.getTextSuccessMessageTransferCart()).toContain("Your cart has successfully been transferred to");	
        browser.ignoreSynchronization = true;
    });
}

cartList.prototype.getTextSuccessMessageTransferCart = function () {
    browser.ignoreSynchronization = true;
    //util.waitForAngular();
    var txtElmXpath = element.all(by.xpath(this.txtTransfrCartXpath));
    browser.wait(EC.visibilityOf(txtElmXpath.last()), 60000);
    return txtElmXpath.last().getText().then(function (text) {
        logger.info(text);
        return text;
    });

    //     browser.wait(EC.visibilityOf(element(by.xpath(this.msgCartSuccessfullyTransferredXpath))), 15000);	
    //     return element(by.xpath(this.msgCartSuccessfullyTransferredXpath)).getText().then(function (text) {
    //         logger.info(text);
    //         return text;
    //     });
}

cartList.prototype.isPresentSuccessMessageTransferCart = function () {
    return element(by.xpath(this.msgCartSuccessfullyTransferredXpath)).isPresent().then(function (result) {
        return result;
    });
}

cartList.prototype.clickNotificationCloseBtn = function () {
    browser.ignoreSynchronization = true;
    browser.wait(EC.presenceOf(element(by.css(this.closeNotificationIconCss))), 10000);
    element(by.css(this.closeNotificationIconCss)).click().then(function () {
        logger.info("Clicked on Notification close button");
    });
}

cartList.prototype.loginFromOtherUser = async function (username, password) {

    var self = this;
    self.clickUserIcon();
    return self.clickLogoutButton().then(function () {
        browser.restart();
        logger.info("Restarted browser for new login");
        //isAngularApp(false);  
        browser.waitForAngularEnabled(false);
        browser.get(browser.params.url).then(function () {
            logger.info("Launched browser and navigated to URL: " + browser.params.url);
            browser.sleep(10000);
            //isAngularApp(false);
            browser.waitForAngularEnabled(false);
            element(by.css(self.usernameIdCss)).isPresent().then(function (res) {
                if (res == false) {
                    browser.wait(EC.visibilityOf(element(by.css(self.usernameCss))), 90000).then(function () {
                        logger.info("Waited till Username text box is visible on the page");
                        element(by.css(self.usernameCss)).clear().then(function () {
                            logger.info("Cleared Username input box");
                            element(by.css(self.usernameCss)).sendKeys(username).then(function () {
                                logger.info("Entered " + username + " in Username input box");
                                browser.wait(EC.visibilityOf(element(by.css(self.continueBtnCss))), 10000).then(function () {
                                    logger.info("Waited till Continue button is visible on login page");
                                    element(by.css(self.continueBtnCss)).click().then(function () {
                                        logger.info("Clicked on Continue button");
                                        browser.sleep(3000);
                                    })
                                })
                            })
                        })
                    })
                }
            })
            element(by.css(self.passwordCss)).isPresent().then(function (value) {
                if (value) {
                    browser.wait(EC.visibilityOf(element(by.css(self.passwordCss))), 10000).then(function () {
                        logger.info("Waited till Password input box is visible on login page");
                        element(by.css(self.passwordCss)).sendKeys(password).then(function () {
                            logger.info("Entered " + password + " in password input box");
                            element(by.css(self.loginBtnCss)).click().then(function () {
                                logger.info("Clicked on Log In button");
                                browser.sleep(5000);
                            });
                        });
                    });
                }
                else {
                    browser.wait(EC.visibilityOf(element(by.css(self.ibmUserName))), 60000).then(function () {
                        logger.info("Waited till Username text box is visible on the page");
                        element(by.css(self.ibmUserName)).clear().then(function () {
                            logger.info("Cleared Username input box");
                            element(by.css(self.ibmUserName)).sendKeys(username).then(function () {
                                logger.info("Entered " + username + " in Username input box");
                                browser.wait(EC.visibilityOf(element(by.css(self.ibmpassWord))), 30000).then(function () {
                                    logger.info("Waited till Password input box is visible on login page");
                                    element(by.css(self.ibmpassWord)).sendKeys(password).then(function () {
                                        logger.info("Entered " + password + " in password input box");
                                        element(by.css(self.signinbuttonCss)).click().then(function () {
                                            logger.info("Clicked on Sign In button");
                                            browser.sleep(5000);
                                        });
                                    });
                                });
                            });
                        });
                    });
                }
            });
        });

        browser.wait(EC.visibilityOf(element(by.css(self.googleAuthCss))), 20000).then(async function () {
            logger.info("Navigated to Authorize this device page");
            element(by.css(self.googleAuthCss)).click().then(async function () {
                var passCode = await apiUtil.getGoogleAuthPassCode(secretKey);
                logger.info("Generated passcode : ", passCode);
                browser.wait(EC.visibilityOf(element(by.css(self.otppswdCss))), 60000);
                element(by.css(self.otppswdCss)).sendKeys(passCode).then(function () {
                    element(by.css(self.submitBtnCss)).click().then(function () {
                        logger.info("Clicked on submit button");
                    });
                });
            });
        }).catch(function () {
            logger.info("Authorization page is not displayed");
        });

        element(by.css(self.privacyProceedBtnCss)).isPresent().then(function (bool) {
            if (bool) {
                browser.wait(EC.visibilityOf(element(by.css(self.privacyProceedBtnCss))), 60000);
                element(by.css(self.privacyProceedBtnCss)).click().then(function () {
                    logger.info("Clicked on Proceed button on IBMid Account privacy page");
                })
            }
            else {
                logger.info("IBMid Account privacy page is not present");
            }
        });

        browser.wait(EC.visibilityOf(element(by.css(defaultConfig.noticeHeaderCss))), 60000).then(function () {
            element(by.css(defaultConfig.noticeHeaderCss)).isDisplayed().then(function (result) {
                if (result == true) {
                    logger.info("Privacy policies page displayed...");
                    element(by.css(defaultConfig.privacyPolicyAcceptBtnCss)).click().then(function () {
                        logger.info("Clicked on I accept button in the Privacy statement page...")
                    });
                }
            });
        }).catch(function (err) {
            logger.info("Privacy policy page is not displayed on re-login");
        });



        // browser.wait(EC.urlContains("/launchpad"), 60000).then(function () {
        // 	logger.info("Waited till browser url contains /launchpad");
        // });
        //});

        //});

    });

};

cartList.prototype.loginFromUserSNOW = function (username, password) {
    var self = this;
    browser.sleep(5000);
    var currenturl = util.getCurrentURL();
    currenturl.then(function (url) {
        if (url.indexOf("launchpad") === -1) {
            isAngularApp(false);
            browser.sleep(5000);
            element(by.css(self.usernameIdCss)).isPresent().then(function (res) {
                if (res == false) {
                    browser.wait(EC.visibilityOf(element(by.css(self.usernameCss))), 90000).then(function () {
                        logger.info("Waited till Username text box is visible on the page");
                        element(by.css(self.usernameCss)).clear().then(function () {
                            logger.info("Cleared Username input box");
                            element(by.css(self.usernameCss)).sendKeys(username).then(function () {
                                logger.info("Entered " + username + " in Username input box");
                                browser.wait(EC.visibilityOf(element(by.css(self.continueBtnCss))), 10000).then(function () {
                                    logger.info("Waited till Continue button is visible on login page");
                                    element(by.css(self.continueBtnCss)).click().then(function () {
                                        logger.info("Clicked on Continue button");
                                        browser.sleep(3000);
                                    })
                                })
                            })
                        })
                    }).catch(function (err) {
                        logger.info("Username field is not displayed on re-login attempt after launching url");
                    });
                }
            });

            if ((browser.params.username).toString().includes("kyndryl.com")) {
                browser.wait(EC.visibilityOf(element(by.css(self.w3idUsernameCss))), 60000).then(function () {
                    logger.info("Waited till Username text box is visible on the page");
                    element(by.css(self.w3idUsernameCss)).clear().then(function () {
                        logger.info("Cleared Username input box");
                        element(by.css(self.w3idUsernameCss)).sendKeys(browser.params.username).then(function () {
                            logger.info("Entered " + browser.params.username + " in Username input box");
                            browser.wait(EC.visibilityOf(element(by.css(self.w3idPasswordCss))), 30000).then(function () {
                                logger.info("Waited till Password input box is visible on login page");
                                element(by.css(self.w3idPasswordCss)).sendKeys(browser.params.password).then(function () {
                                    logger.info("Entered password input box");
                                    element(by.css(self.w3idSignBtnCss)).click().then(function () {
                                        logger.info("Clicked on Sign In button");
                                        browser.sleep(5000);
                                    });
                                });
                            });
                        });
                    });
                });
            }

            element(by.css(self.passwordCss)).isPresent().then(function (value) {
                if (value) {
                    browser.wait(EC.visibilityOf(element(by.css(self.passwordCss))), 10000).then(function () {
                        logger.info("Waited till Password input box is visible on login page");
                        element(by.css(self.passwordCss)).sendKeys(password).then(function () {
                            logger.info("Entered " + password + " in password input box");
                            element(by.css(self.loginBtnCss)).click().then(function () {
                                logger.info("Clicked on Log In button");
                                browser.sleep(5000);
                            });
                        });
                    });
                }
                else {
                    browser.wait(EC.visibilityOf(element(by.css(self.ibmUserName))), 60000).then(function () {
                        logger.info("Waited till Username text box is visible on the page");
                        element(by.css(self.ibmUserName)).clear().then(function () {
                            logger.info("Cleared Username input box");
                            element(by.css(self.ibmUserName)).sendKeys(username).then(function () {
                                logger.info("Entered " + username + " in Username input box");
                                browser.wait(EC.visibilityOf(element(by.css(self.ibmpassWord))), 30000).then(function () {
                                    logger.info("Waited till Password input box is visible on login page");
                                    element(by.css(self.ibmpassWord)).sendKeys(password).then(function () {
                                        logger.info("Entered " + password + " in password input box");
                                        element(by.css(self.signinbuttonCss)).click().then(function () {
                                            logger.info("Clicked on Sign In button");
                                            browser.sleep(5000);
                                        });
                                    });
                                });
                            });
                        });
                    }).catch(function(err){
                        logger.info("Password field is not displayed for the user")
                    });
                }
            });

            browser.wait(EC.visibilityOf(element(by.css(self.kynTotpBtnCss))), 30000).then(function () {
                element(by.css(self.kynTotpBtnCss)).click().then(function () {
                    logger.info("Clicked on TOTP")
                });
            }).catch(function () {
                logger.info("Otp not required for this user");
            });

            browser.wait(EC.visibilityOf(element(by.css(self.w3idOtpTextBoxCss))), 30000).then(async function () {
                logger.info("Navigated to Authorize this device page");
                var passCode = await apiUtil.getGoogleAuthPassCode(secretKey);
                logger.info("Generated passcode : ", passCode);
                browser.wait(EC.visibilityOf(element(by.css(self.w3idOtpTextBoxCss))), 60000);
                element(by.css(self.w3idOtpTextBoxCss)).sendKeys(passCode).then(function () {
                    element(by.css(self.kynOtpSubmitBtn)).click().then(function () {
                        logger.info("Clicked on submit button");
                    });
                });
            }).catch(function () {
                logger.info("Authorization page is not displayed");
            });

            browser.wait(EC.visibilityOf(element(by.css(defaultConfig.noticeHeaderCss))), 30000).then(function () {
                element(by.css(defaultConfig.noticeHeaderCss)).isPresent().then(function (result) {
                    if (result == true) {
                        logger.info("Privacy policies page displayed...");
                        element(by.css(defaultConfig.privacyPolicyAcceptBtnCss)).click().then(function () {
                            logger.info("Clicked on I accept button in the Privacy statement page...")
                        });
                    }
                });
            }).catch(function (err) {
                logger.info("Privacy policy page is not displayed on re-login");
            });

            browser.wait(EC.urlContains("/launchpad"), 60000).then(function () {
                logger.info("Waited till browser url contains /launchpad");
            }).catch(function (err) {
                logger.info("Launchpad page is not displayed on re-login attempt after launching url");
            });
        }
        else {
            logger.info("User is logged in");
        }
    })
};

cartList.prototype.clickOkInDeleteItemsInCartPopup = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.btnOkdeleteItemModal))), 5000);
    return element(by.css(this.btnOkdeleteItemModal)).click().then(function () {
        logger.info("Clicked on Ok button in delete confirmation popup");
    });
};

cartList.prototype.clickCancelInDeleteItemsInCartPopup = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.btnCanceldeleteItemModal))), 5000);
    return element(by.css(this.btnCanceldeleteItemModal)).click().then(function () {
        logger.info("Clicked on Cancel button in delete confirmation popup");
    });
};

cartList.prototype.getTextDeleteItemModalHeading = function () {
    browser.wait(EC.visibilityOf(element(by.xpath(this.deleteItemModalHeader))), 5000);
    return element(by.xpath(this.deleteItemModalHeader)).getText().then(function (text) {
        logger.info("Pop Up header :: " + text);
        return text;
    });
};

cartList.prototype.isPresentDeleteItemModal = function () {
    browser.wait(EC.visibilityOf(element(by.xpath(this.deleteItemModalHeader))), 5000);
    return element(by.xpath(this.deleteItemModalHeader)).isPresent().then(function (result) {
        logger.info("Pop Up header :: " + result);
        return result;
    });
};

cartList.prototype.deleteItemsInShoppingCart = function (cartItem) {
    //Get the index of cart item
    var cartItem = element.all(by.css(this.serviceNameCartCss));
    browser.wait(EC.visibilityOf(cartItem.get(0)), 60000);
    var index;
    cartItem.getText().then(function (textArray) {
        index = textArray.indexOf(cartItem);
        var menuIcon = element.all(by.css(defaultConfig.cartItemActnBtnCss));
        var delButton = element(by.xpath(defaultConfig.buttonDeleteItemXpath));
        browser.wait(EC.elementToBeClickable(menuIcon.get(index)), 90000);
        menuIcon.get(index).click().then(function () {
            logger.info("Clicked on menu icon for the item : " + cartItem);
            browser.sleep(2000);
        });
        browser.wait(EC.elementToBeClickable(delButton), 90000);
        delButton.click().then(function () {
            logger.info("Clicked on delete button for the item : " + cartItem);
        });
    });


};


cartList.prototype.isPresentCartItem = function (cartItem) {
    browser.wait(EC.invisibilityOf(element(by.xpath("//h6[text()='" + cartItem + "']"))), 5000);
    return element(by.xpath("//h6[text()='" + cartItem + "']")).isPresent().then(function (result) {
        logger.info("Item with " + cartItem + "is " + result);
        return result;
    });
};


cartList.prototype.getTextItemSuccessfullyDeleted = function () {
    return element(by.xpath(this.msgSuccessfullyDeletedCartItem)).getText().then(function (text) {
        return text;
    });
};

cartList.prototype.isPresentItemSuccessfullyDeleted = function () {
    browser.sleep(1000);
    return element(by.xpath(this.msgSuccessfullyDeletedCartItem)).isPresent().then(function (text) {
        return text;
    });
};

cartList.prototype.increaseQuntity = function (serviceName) {
    var browserName;
    browser.getCapabilities().then(function (cap) {
        browserName = cap.get("browserName");
    });
    var increaseQuntitybtn = element(by.xpath("//*[contains(text(),'" + serviceName + "')]/../../following-sibling::div//*[@type='number']/../div/button[@class='bx--number__control-btn up-icon']"));
    var eleToScroll = element(by.xpath("//*[contains(text(),'" + serviceName + "')]/../../following-sibling::div//*[@type='number']"));
    browser.wait(EC.elementToBeClickable(increaseQuntitybtn), 40000);
    browser.sleep(3000);
    //Scroll window to top       
    browser.executeScript("javascript:window.scroll(829,37)").then(function () {
        eleToScroll.getAttribute("id").then(function (id) {
            if (browserName == "chrome") {
                browser.executeScript("javascript:document.getElementById('" + id + "').scrollIntoView(__zone_symbol__hashchangefalse)");
            } else {
                browser.executeScript("javascript:window.scrollBy(document.getElementById('" + id + "').offsetHeight,document.getElementById('" + id + "').offsetWidth)");
            }

            increaseQuntitybtn.click().then(function () {
                logger.info("Quantity increased by 1");
                browser.sleep(2000);
                util.waitForAngular();
                //Close notification pop up
                var elemCloseBtn = element(by.css(defaultConfig.btnNotificnCloseCss));
                browser.wait(EC.elementToBeClickable(elemCloseBtn), 15000).then(function () {
                    elemCloseBtn.click();
                    util.waitForAngular();
                }).catch(function (error) {
                    logger.info("Timeout- As element not visisble");
                });
            });
        });
    });
};

cartList.prototype.validateEstimatedCostAllServicesCart = function (index) {
    browser.executeScript("window.scrollTo(0, 150);");
    var elmEstimatedCost = element.all(by.xpath(this.txtEstimatedCostXpath));
    var elmServiceName = element.all(by.xpath(this.lblOfferingNameXpath));
    var lnkBillOfMaterial = element.all(by.xpath(this.lnkBillOfMaterialXpath));
    var cartListPage = new cartList();
    let promiseArr = [];
    var finlValidn = false;
    var expOrderTotal = 0;
    var val;

    elmServiceName.getText().then(function (serviceList) {
        return elmEstimatedCost.getText().then(function (textArray) {
            for (var i = 0; i < textArray.length; i++) {
                expect(textArray[i]).not.toContain("NA");
                if (textArray[i] != "NA") {
                    val = parseFloat(textArray[i].split("+")[0].split("/")[0].replace("USD ", ""));
                    if (val != "0.00") {
                        logger.info("Estimated Cost on shopping cart page for :" + serviceList[i] + " is - " + textArray[i]);
                        //Validate Pricing through BOM                       
                        cartListPage.clickActionIcon(i + index + 1);
                        cartListPage.clickCurrentCartBOMDetails();
                        //Click on More link
                        cartListPage.clickMoreLinkBom();
                        cartListPage.clickExpandQuantity();
                        finlValidn = cartListPage.getTotalPriceOfAllInstances();
                        cartListPage.clickOnCloseButtonOfViewDetailSlidder();
                        promiseArr.push(finlValidn);
                        expOrderTotal = parseFloat(expOrderTotal) + parseFloat(val);
                    }
                } else {
                    logger.info("Estimated Cost on shopping cart page for :" + serviceList[i] + " is NA");
                    promiseArr.push(false);
                }
            }
            return cartListPage.getOrderTotalBasedOnShoppingCartNameIndex(index).then(function (actOrderTotal) {
                actOrderTotal = parseFloat(actOrderTotal.split("+")[0].split("/")[0].replace("USD ", ""));
                var n = expOrderTotal.toFixed(4);
                expect(actOrderTotal.toFixed(4)).toEqual(n);
                if (actOrderTotal.toFixed(4) == n) {
                    logger.info("Order Total is succesfully validated on shopping cart page.");
                } else {
                    logger.info("Order Total is is not matching on shopping cart page.");
                    promiseArr.push(false);
                }
            });

        });
    });

    return Promise.all(promiseArr).then(function (finlValidn) {
        if (finlValidn.indexOf(false) != -1) {
            return Promise.resolve(false);
        } else {
            return Promise.resolve(true);
        }
    });

};

cartList.prototype.reduceQuntity = function (serviceName) {
    var reduceQuntitybtn = element(by.xpath("//*[contains(text(),'" + serviceName + "')]/../../following-sibling::div//*[@type='number']/../div/button[@class='bx--number__control-btn down-icon']"));
    var eleToScroll = element(by.xpath("//*[contains(text(),'" + serviceName + "')]/../../following-sibling::div//*[@type='number']"));
    browser.wait(EC.elementToBeClickable(reduceQuntitybtn), 40000);
    browser.sleep(3000);
    //Scroll window to top       
    browser.executeScript("javascript:window.scroll(829,37)").then(function () {
        eleToScroll.getAttribute("id").then(function (id) {
            browser.executeScript("javascript:window.scrollBy(document.getElementById('" + id + "').offsetHeight,document.getElementById('" + id + "').offsetWidth)");
            reduceQuntitybtn.click().then(function () {
                logger.info("Quantity reduced by 1");
                browser.sleep(2000);
                util.waitForAngular();
            });
        });
    });

};

cartList.prototype.clickCloseOnDeleteSuccessBox = function () {
    util.waitForAngular();
    var btn = element(by.xpath(this.notifcnCloseBtnXpath));
    browser.wait(EC.visibilityOf(btn), 60000);
    return btn.click().then(function () {
        logger.info("Clicked on close button of notification");

    });
};

cartList.prototype.deleteAllCartsfromCartList = function () {

    var cartListPage = new cartList();
    let promiseArr = [];
    cartListPage.clickCartIcon();
    var carNameList = element.all(by.xpath(this.cartListXpath));
    return carNameList.getText().then(function (textArray) {
        if (textArray.length >= 10) {
            cartListPage.clickCartIcon();
            for (var i = 1; i < textArray.length - 1; i++) {
                if (textArray[i] != "") {
                    cartListPage.clickCartIcon();
                    cartListPage.selectCartFromList(textArray[i]);
                    util.switchToFrame();
                    cartListPage.clickMenuIcon();
                    cartListPage.deleteCart();
                    expect(cartListPage.getDeletedCartSuccessMessage()).toBe("Your cart has successfully been deleted.");
                    //cartListPage.clickCloseOnDeleteSuccessBox();
                    promiseArr.push(true);
                } else {
                    logger.info("Skipping cart delet process as cart lists count is less than 40.");
                }
            }

        }
    })
};

//********Main parameter page disabled objects during edit service*************//

cartList.prototype.isEnabledInstancePrefixTextbox = function () {
    util.waitForAngular();
    browser.wait(EC.visibilityOf(element(by.css(this.textBoxInstancePrefixCss))), 60000);
    return element(by.css(this.textBoxInstancePrefixCss)).getAttribute("class").then(function (result) {
        if (result.includes("disabled")) {
            logger.info("Service Instance Prefix textbox is disabled: " + result);
        }
        else {
            logger.info("Service Instance Prefix textbox is enabled: " + result);
        }
        return result;
    })
}

cartList.prototype.isEnabledAddtoCartCheckbox = function () {
    util.waitForAngular();
    browser.wait(EC.visibilityOf(element(by.css(this.checkboxAddToCartCss))), 10000);
    return element(by.css(this.checkboxAddToCartCss)).getAttribute("disabled").then(function (result) {
        if (result == "true") {
            logger.info("Add to cart checkbox is disabled: " + result);
        }
        else {
            logger.info("Add to cart checkbox is enabled: " + result);
        }
        return result;
    })
}

cartList.prototype.isDisplayedEnvDropdown = function () {
    util.waitForAngular();
    return element(by.css(this.dropdownEnvCss)).isPresent().then(function (result) {
        if (result) {
            logger.info("Environment dropdown is present: " + result);
        }
        else {
            logger.info("Environment dropdown is not present: " + result);
        }
        return result;
    })
}

cartList.prototype.isDisplayedAppDropdown = function () {
    util.waitForAngular();
    return element(by.css(this.dropdownAppCss)).isPresent().then(function (result) {
        if (result) {
            logger.info("Application dropdown is present: " + result);
        }
        else {
            logger.info("Application dropdown is not present: " + result);
        }
        return result;
    })
}

cartList.prototype.isDisplayedTeamRadioButton = function () {
    util.waitForAngular();
    return element(by.css(this.radioButtonTeamCss)).isPresent().then(function (result) {
        if (result) {
            logger.info("Team radio button is present: " + result);
        }
        else {
            logger.info("Team radio button is not present: " + result);
        }
        return result;
    })
}

cartList.prototype.isDisabledProviderAccount = function () {
    util.waitForAngular();
    browser.wait(EC.visibilityOf(element(by.css(this.radioButtonProviderAccountCss))), 90000);
    return element.all(by.css(this.radioButtonProviderAccountCss)).first().getAttribute("class").then(function (value) {
        if (value.includes("disabled")) {
            logger.info("Provider Account is disabled: " + value);
        }
        else {
            logger.info("Provider Account is enabled: " + value);
            return false;
        }
        return true;
    })
}

cartList.prototype.getTextCartNotAvailableMsg = function () {
    util.waitForAngular();
    browser.wait(EC.visibilityOf(element(by.css(this.textCartNotAvailableCss))), 90000);
    return element(by.css(this.textCartNotAvailableCss)).getText().then(function (msg) {
        logger.info("Current cart not available message: " + msg);
        return msg;
    })
};

cartList.prototype.clickEmptyCartGoToCatalogLink = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.linkEmptyCartGoToCatalogCss))), 90000);
    element(by.css(this.linkEmptyCartGoToCatalogCss)).click().then(function () {
        logger.info("Clicked on OK button of cart not available popup");
    })
};

cartList.prototype.getCartNameFromMainParamsPage = function () {

    browser.wait(EC.visibilityOf(element(by.css(this.cartNameTextboxCss))), 90000);
    return element(by.css(this.cartNameTextboxCss)).getAttribute('title').then(function (cartName) {
        logger.info("Cart name is " + cartName);
        return cartName
    })
};

cartList.prototype.isNewShoppingCartPresent = function () {
    var self = this;
    util.waitForAngular();
    var elem = element(by.css(this.textBoxInstancePrefixCss));
    browser.wait(EC.elementToBeClickable(elem), 30000).then(function () {
        logger.info("New Shopping cart button is visible");
    }).catch(function (err) {
        logger.info("New Shopping cart button not visible within 30s");
    });
    return elem.isPresent().then(function (status) {
        logger.info("New Shopping cart is present : " + status);
        if (status == true) {
            var shopping_cart = element(by.css("input[name='useShoppingCart']"))
            shopping_cart.getAttribute('id').then(function(id){
                return browser.executeScript("return document.getElementById('" + id + "').checked;").then(function (checkboxChecked) {
                    if (checkboxChecked == true) {
                        logger.info("Add to a Shopping Cart Checkbox is already Checked");
                        self.clickAddToCartCheckbox();
                    }
                });
            })
            // return browser.executeScript("arguments[0].checked", shopping_cart.getWebElement()).then(function (checkboxChecked) {
            // //return browser.executeScript("return document.getElementById('checkbox-useShoppingCart').checked;").then(function (checkboxChecked) {
            //     if (checkboxChecked == true || checkboxChecked == null) {
            //         logger.info("Add to a Shopping Cart Checkbox is already Checked");
            //         self.clickAddToCartCheckbox();
            //     }
            // });
        }
    });
};

cartList.prototype.clickAddToCartCheckbox = function () {
    util.waitForAngular();
    var elem = element(by.css("input[name='useShoppingCart']~label"));
    browser.wait(EC.elementToBeClickable(elem), 60000);
    return elem.click().then(function () {
        logger.info("Clicked on New Shopping cart checkbox");
        util.waitForAngular();
    });
};

cartList.prototype.clickActionIcon = function (cartNo) {
    browser.wait(EC.visibilityOf(element.all(by.css(this.cartActionIconCss)).get(cartNo)), 90000);
    element.all(by.css(this.cartActionIconCss)).get(cartNo).click().then(function () {
        logger.info("Clicked on the Actions icon on Review Cart Page");
    });
};

cartList.prototype.clickCurrentCartServiceDetails = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.viewServiceDetailsCss))), 90000);
    element(by.css(this.viewServiceDetailsCss)).click().then(function () {
        logger.info("Clicked on View Service Details Button in Review Cart Page");
    });
};

cartList.prototype.clickCurrentCartBOMDetails = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.viewServiceBomCss))), 90000);
    element(by.css(this.viewServiceBomCss)).click().then(function () {
        logger.info("Clicked on Bill of Materials Button in Review Cart Page");
    });
};

cartList.prototype.clickCurrentCartEditFlow = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.viewEditServiceCss))), 90000);
    return element(by.css(this.viewEditServiceCss)).click().then(function () {
        logger.info("Clicked on Edit button in Review Cart Page");
        util.waitForAngular();
    });
};

cartList.prototype.clickCurrentCartAddOnDetails = function () {
    browser.wait(EC.visibilityOf(element(by.buttonText(this.viewServiceAddOnButtonText))), 90000);
    element(by.buttonText(this.viewServiceAddOnButtonText)).click().then(function () {
        logger.info("Clicked on Add-on Button in Review Cart Page");
        util.waitForAngular();
    });
};

cartList.prototype.clickCurrentCartDeleteFlow = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.viewDeleteServiceCss))), 90000);
    element(by.css(this.viewDeleteServiceCss)).click().then(function () {
        logger.info("Clicked on Delete Button in Review Cart Page");
        util.waitForAngular();
    });
};

cartList.prototype.clickDeleteOkButtonForCartItem = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.DeleteOkButtonForCartItemCss))), 90000);
    element(by.css(this.DeleteOkButtonForCartItemCss)).click().then(function () {
        logger.info("Clicked on ok Delete Button on Cart Page");
        util.waitForAngular();
    });
};

cartList.prototype.getDeletedCurrentCartSuccessMessage = function () {
    browser.sleep(2000);
    return element(by.xpath(this.msgCurrCartSuccessfullyDeletedXpath)).getText().then(function (deleteMsg) {
        logger.info(deleteMsg);
        return deleteMsg;
    });
};

cartList.prototype.getTextBasedOnExactLabelName = function (labelName) {
    browser.executeScript('window.scrollTo(0,0);');
    browser.wait(EC.visibilityOf(element(by.xpath("//label[(text()=' " + labelName + " ')]/parent::div"))), 90000);
    return element(by.xpath(".//label[(text()=' " + labelName + " ')]/parent::div")).getText().then(function (parameterText) {
        parameterText = parameterText.split('\n')[1]
        logger.info("The value for " + labelName + " is : " + parameterText)
        return parameterText;
    });
};

cartList.prototype.clickOnEditSaveBtn = function () {
    util.waitForAngular();
    browser.wait(EC.elementToBeClickable(element(by.css(this.editSaveBtnCss))), 90000);
    return element(by.css(this.editSaveBtnCss)).click().then(function () {
        logger.info("Clicked on Save button");
    });
};

cartList.prototype.clickOnAddOnSaveBtn = function () {
    util.waitForAngular();
    browser.wait(EC.elementToBeClickable(element(by.css(this.addOnSaveBtnCss))), 90000);
    return element(by.css(this.addOnSaveBtnCss)).click().then(function () {
        logger.info("Clicked on Add on Save button");
    });
};

cartList.prototype.clickOnCloseButtonOfViewDetailSlidder = function () {
    let webElement = element.all(by.css(this.closeButtonOfOrderDetailsSlidderCss)).get(1);
    browser.wait(EC.visibilityOf(webElement), 90000);
    webElement.click().then(function () {
        logger.info("Clicked on closed button of view details slidder");
    });
};

cartList.prototype.clickOnCloseButtonOfViewDetailSlidder = function () {
    let webElement = element.all(by.css(this.closeButtonOfOrderDetailsSlidderCss)).get(1);
    browser.wait(EC.visibilityOf(webElement), 90000);
    webElement.click().then(function () {
        logger.info("Clicked on closed button of view details slidder");
    });
};

cartList.prototype.clickOnViewAllCarts = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.viewAllCartsCss))), 90000);
    return element(by.css(this.viewAllCartsCss)).click().then(function () {
        logger.info("click on view all carts tab");
    });
};

cartList.prototype.getIMITagInItemTableText = function () {
    browser.wait(EC.visibilityOf(element(by.css(this.IMITagInItemTableCss))), 90000);
    return element(by.css(this.IMITagInItemTableCss)).getText().then(function (IMItag) {
        logger.info("IMI tab on cart Item Table :" + IMItag);
        return IMItag;
    });
};

cartList.prototype.getCartDetails = function (cartName) {
    util.waitForAngular();
    browser.sleep(5000);
    var cartList = element.all(by.css(this.cartNameCss));
    browser.wait(EC.visibilityOf(cartList.get(3)), 15000);
    return cartList.getText().then(function (cartNameArray) {
        var index = cartNameArray.indexOf(cartName);
        if (index != -1) {
            return index;
        } else {
            return -1;
        }

    })
};

cartList.prototype.expandsTheCartItemsTabBasedOnIndex = function (index) {
    util.waitForAngular();
    browser.wait(EC.elementToBeClickable(element.all(by.css(this.expandCartItemsTabCss)).get(index)), 60000);
    return element.all(by.css(this.expandCartItemsTabCss)).get(index).click().then(function () {
        //browser.ignoreSynchronization = false; 
        logger.info("Succesfully clicked on Expand Cart Items link");
        util.waitForAngular();
    });

};

cartList.prototype.clickMoreLinkBom = function () {
    util.waitForAngular();
    var elem = element(by.css(this.lnkMoreCss));
    browser.wait(EC.elementToBeClickable(elem), 60000);
    browser.sleep(2000);
    return elem.click().then(function () {
        logger.info("Clicked on More link in Cart Page-->Bill of Materials section");
        //Check if BOM table is displayed        
        browser.wait(EC.elementToBeClickable(element(by.xpath(defaultConfig.btnExpandQuantXpath))), 60000).then(function () {
            logger.info("BOM table is displayed");
        }).catch(function (err) {
            elem.click();
        });
    });
};

cartList.prototype.getOrderTotalBasedOnShoppingCartNameIndex = function (index) {
    var elmOrderTotal = element.all(by.xpath(this.txtOrderTotalXpath));
    browser.wait((EC.elementToBeClickable(elmOrderTotal.get(index))), 40000);
    elmOrderTotal.get(index).click().then(function () {
        logger.info("Clicked on Fetch Total Price");
        util.waitForAngular();
    })
    return elmOrderTotal.get(index).getText().then(function (text) {
        logger.info("Order total on shopping cart page is : " + text);
        return text;
    });

};

cartList.prototype.getCartContextDataBasedOnCartName = function (cartName) {
    var requiredReturnMap = {}, actualMap = {};
    var deferred = protractor.promise.defer();
    var cartContextParamElements = element.all(by.xpath("//*[text()=' " + cartName + " ']/../../../../..//div[@class='bx--col-sm-1 cart-text-display']"));
    var cartContextValueElements = element.all(by.xpath("//*[text()=' " + cartName + " ']/../../../../..//div/label[@class='bx--label bx--col-sm-1 cart-context-display']"));

    browser.wait(EC.visibilityOf(cartContextParamElements.get(0)), 90000);
    browser.wait(EC.visibilityOf(cartContextValueElements.get(0)), 90000);
    cartContextParamElements.getText().then(function (keysArray) {
        cartContextValueElements.getText().then(function (valuesArray) {
            for (var i = 0; i < keysArray.length; i++) {
                if (keysArray[i] != "") {
                    actualMap[keysArray[i].split(":")[0].trim()] = valuesArray[i].trim();
                }
            }
            deferred.fulfill(actualMap);
        });
    });
    requiredReturnMap["Actual"] = actualMap;
    deferred.fulfill(requiredReturnMap);
    return deferred.promise;
};

cartList.prototype.getCartOwner = function (index) {
    var elmCartOwner = element.all(by.xpath(this.txtCartOwnerXpath));
    browser.wait((EC.visibilityOf(elmCartOwner.get(index))), 60000);
    return elmCartOwner.get(index).getText().then(function (text) {
        logger.info("Cart owner for cart is " + text);
        return text;
    })

};

module.exports = cartList;
