"use strict";

var extend = require('extend');
var url = browser.params.url;
var mcmpUIDataTemplate = require('../../testData/mcmp/mcmpUIData.json');
var appUrls = require('../../testData/appUrls.json');
var logGenerator = require("../../helpers/logGenerator.js"),
	CartListPage = require('../pageObjects/cartList.pageObject.js'),
	logger = logGenerator.getApplicationLogger();
var timeout = require('../../testData/timeout.json');
var EC = protractor.ExpectedConditions;
var util = require('../../helpers/util.js');
var mcmpUIDataTemplateIcam  = require('../../testData/OrderIntegration/ICAM/terraformLaunchpadMcmpUIData.json');	


var defaultConfig = {
	pageUrl:                      		url + appUrls.catalogPageUrl,
	pageHeaderTitleCss:					'#page-title',
	pageHeaderSubtitleCss:	   			'.ibm--page-header__container',
    catalogLinkTextXpath:        		'//a[contains(text(), "Catalog")]',
	bluePrintTitleCss:              	".card-service-title",
	noBlueprintFoundCss:				".bx--inline-notification__subtitle span",
	configureButtonCss:             	"[class^='storefront_carbon-button_configure bx--btn bx--btn--primary']",
	detailsButtonCss:                   "[class^='storefront_carbon-button_details']",
	lastServiceHeading:					'.header-category:last-of-type',
	catalogServiceTileCss:				'div.service-box.bx--tile-group--light',
	serviceTileProviderNameCss:			'div .card-provider-name',
	serviceTileDescCss:					'div .service-description',
	configureButtonDetailsText:         'Configure 1.0.0.0',
	configureButtonDetailsCss:         '#configure-service',
	textServiceInstancePrefixCss:       '#text-input-main_params-serviceName',
	bluePrintTitleFromToolTipId:        'service-name_tooltip-content_',
	bluePrintPriceFromToolTipId:        'service-price_tooltip-content_',
	userIconCss: 						'.bx--header__action',
	contentScrolledCss:					'main[class*="content-scrolled"]',
	//Locators for Tab Links 
	allTabLinkCss:						'#tab-link-1',
	topRatedTabLinkCss:					'#tab-link-2',
	newestTabLinkCss:					'#tab-link-3',
	bestSellersTabLinkCss:				'#tab-link-4',
	cheapestFirstTabLinkCss:		'	#tab-link-5',
	
	// Locators for Filters 
	providerCompleteListCss:			'[id^="checkbox-store-filter-menu_store-filter-menu-item_provider"] ~ label',
	firstCategoryCompleteListCss:  		'.cb--selectable-list li',
	providerCheckboxesLabelCss:     	'[id^=store-filter-menu_store-filter-menu-item_provider] label',

	// Filters by Providers				
	providerFilterNameCss:				'#Provider',
	//firstCategoryCheckBoxesLabelCss:    '[id^=checkbox-store-filter-menu_store-filter-menu-item_first-category] ~ label',
	listCategoriesCss:                  '.cb--selectable-list li',
	linkTextReset :						'RESET',
	resetLinkForProviderSection:    	'#provider_filter_reset>a',
	resetLinkForCategorySection:    	'#category_filter_reset>a',
	searchTextBoxInputXpath: 			"//input[@id='search__input-store-catalog-search-id']",
	serviceTileCss: 					'article.bx--card',
	serviceTileDetailsButtonCss: 		"[class^='storefront_carbon-button_details bx--btn bx--btn--secondary']",
	basePriceForDisplayedTemplatesCss:	'p.service-price',
    cartNameTextboxCss:					'text-input-main_params-cartName',
    cartIconCss: 						'button[title="Cart"]',
    closeNotificationIconXpath: '//*[@class="bx--toast-notification bx--toast-notification--success"]//button',
	userIconXpath: '//button[@title="User"]',
	chkboxProviderLstCss:'.provider-internal-container ul label span',
	chkboxCategoryLstCss:'.category-internal-container ul li',
	
	storeHeaderCss: '.bx--header__name',
	configErrorMsgCss: '.bx--inline-notification__subtitle span',

	/*********************** Labels filter locator *************************/
	labelsSearchBoxCss:				"#bx--search__wrapper_",
	labelsSearchInputCss:			"input[id='search__input-'][class='bx--search-input']",
	labelsFilterTextCss:			"#dropdown-option__",
	labelsFilteredTextCss:			".bx--dropdown-link",
	labelsFilterCheckBoxCss:		".bx--dropdown-link input",
	/***************** MCMP Store Catalog Page locators ***********************************/
	hamburgerCatalogCss: 'ibm-hamburger button',
	leftNavBarCss: 'ibm-sidenav',
	pinLeftNavBarCss: 'ibm-icon-pin svg',
	arrowLeftNavBarCss: 'ibm-icon-arrow-left svg',
	textLeftNavLinkCss: 'a.bx--side-nav__link span',
	textLeftNavButtonCss: '.bx--side-nav__submenu-title',
	buttonLeftNavSubMenu: '.bx--side-nav__submenu',
	linkResetProviderText: 'RESET',
	linkCatalogMainParamText: 'Catalog',
	buttonLeftSubmenuCss: '.bx--side-nav__submenu-title',
	buttonLeftSubmenuExpandXpath: '//*[@class="bx--side-nav__submenu-title"]/parent::button',
	textLeftNavAdminPortalLinkXpath: '//*[contains(text(),"Portal")]/parent::a[@role="menuitem"]',
	
	tasksMenuButtonCss: 'button[title="Tasks"] .ibm-icon',
	taskMenuButtonOpenCss : ".bx--header__action.bx--header__action--active",
	taskMenuButtonNotOpenCss : 'button[aria-label="Tasks"].bx--header__action',
	taskSubmenuOpenCss : 'button[aria-expanded="true"].bx--side-nav__submenu',
	rightNavBarCss: 'ibm-panel aside',
	rightNavBarHeaderCss: 'div.tasks-main h3',
	textRightNavLinkCss: 'div.tasks-main ibm-sidenav-menu li span',
	helpButtonCss: 'button[title="Help"] .ibm-icon',
	textHelpLinkCss: 'div.help-main ibm-switcher-list ul span',
	helpPageHeaderCss:'div.ibmdocs-product-container h2',
	helpContentHeaderCss: 'div.ibmdocs-content-container h1',
	rightNavButtonCss: 'ibm-panel .bx--side-nav__submenu',
	
	textLabelsHeaderCss: '.label-header-title',
	textLabelsDropdownCss: '.bx--search__wrapper li',
	dropdownLabelsCss: 'button.bx--search__wrapper',
	textSearchLabelCss: '[id^="search__input-"]',
	dropdownValuesLabelCss: '[id^=dropdown-option__]',
	checkboxLabelOptionsCss: '[id^=dropdown-option__] label',
	textLabelsSelectedCountCss: 'carbon-tag span span',
	iconCloseLabelsCss: '.close',
	linkLoadMoreLabelCss: '.bx--dropdown-item.bx--dropdown-item--more',
	AvailableVersionsCss:'.bx--checkbox-main-label',
	FeaturesTextCss:'.features-list ul li',
	longDescriptionCss:'#details-terms',
	OneTimeChargePriceCss:'.details-price p strong',
	allCategoriesCss:'.cb--selectable-list li:nth-child(1)',
	txtCatalogHeaderCss:'[title="Catalog"]'
}; 

function catalog(selectorConfig) {
    if (!(this instanceof catalog)) {
        return new catalog(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

// catalog.prototype.open = function()
// {			
// 	var self = this;
// 	var catlogLinkOnMainParam = element(by.cssContainingText(".bx--link", self.linkCatalogMainParamText));
// 	//element(by.linkText(self.linkCatalogMainParamText)).isPresent().then(function(val){
// 	catlogLinkOnMainParam.isPresent().then(function(val){		
// 		if(val == true) {
// 			logger.info("Catalog Link is present : " + val);
// 			catlogLinkOnMainParam.click().then(function(){
// 				logger.info("Clicked on Catalog link");
// 			});
// 		}
// 		else {
// 			util.switchToDefault();
// 			//browser.ignoreSynchronization = true;
// 			self.clickHamburgerCatalog();
// 			self.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
// 			self.checkIfleftNavStoreExpanded();
// 			self.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkCatalog);
// 			browser.sleep(5000);
// 			util.switchToFrame();			
// 			util.waitForAngular();
// 		}
// 		self.clickResetProviderLink();
// 		self.clickCloseLabelsIcon();
// 	}).catch(function(err){
// 		//Workaround for protractor.waitForAngular issue
// 		//Reload frame
// 		//browser.ignoreSynchronization = true;
// 		util.switchToDefault();
// 		browser.executeScript("document.getElementById('mcmp-iframe').contentDocument.location.reload(true);");
// 		util.waitForAngular();		
// 		browser.sleep(10000);
// 		util.switchToFrame();		
// 	});
// 	//Validate if Catalog page is displayed. If not navigate to catalog page
// 	this.getCatalogPageTitle().then(function(status){
// 		if(status == false){
// 			//Navigate to Catalog page
// 			browser.get(browser.params.url + appUrls.placeOrderMainParamtersPageUrl);
// 			util.waitForAngular();
// 		}
// 	});
// };

catalog.prototype.open = function()

{	
	var cartListPage = new CartListPage();
	var self = this;
	//Check if user is on homepage or catalog page
	try {
		self.checkIfUserIconIsDisplayed().then(function(status){
			if(status == false){
				//Handling for session timeout issue
				browser.get(browser.params.url + appUrls.launchpadUrl);
				cartListPage.loginFromUserSNOW(browser.params.username, browser.params.password);
			}	
			util.switchToDefault();
			browser.waitForAngularEnabled(false);	
			self.clickHamburgerCatalog();
			//self.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
			self.checkIfleftNavStoreExpanded();
			self.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkCatalog);
			browser.sleep(5000);
			util.switchToFrame();			
			util.waitForAngular();		
			self.clickResetProviderLink();
			self.clickCloseLabelsIcon();			
		});		
	} catch (error) {
		browser.get(browser.params.url + appUrls.catalogPageUrl);
		var currenturl = util.getCurrentURL();
    		currenturl.then(function(url) {    	
			if(url.indexOf("storeFront") === -1) {
				browser.get(browser.params.url + appUrls.launchpadUrl);
				cartListPage.loginFromUserSNOW(browser.params.username, browser.params.password);
			}
		});
	}	
	
	//Validate if Catalog page is displayed. If not navigate to catalog page
	this.getCatalogPageTitle().then(function(status){
		if(status == false){
			//Navigate to Catalog page
			browser.get(browser.params.url + appUrls.catalogPageUrl);
			util.waitForAngular();
		}
	});

};

catalog.prototype.isPresentCatalogLink = function()
{
    return element(by.xpath(this.catalogLinkTextXpath)).isPresent();
};

//*************************** Functions for Clicking Tab links **********************************

catalog.prototype.clickAllTabLink = function(){
	element(by.css(this.allTabLinkCss)).click();
};

catalog.prototype.clickTopRatedTabLink = function(){
	element(by.css(this.topRatedTabLinkCss)).click();
};

catalog.prototype.clickNewestTabLink = function(){
	element(by.css(this.newestTabLinkCss)).click();
};

catalog.prototype.clickBestSellersTabLink = function(){
	element(by.css(this.bestSellersTabLinkCss)).click();
};

catalog.prototype.clickCheapestFirstTabLink = function(){
	element(by.css(this.cheapestFirstTabLinkCss)).click();
};

//*************************** Functions for Blue Prints ******************************************


/**
 * Method to get blueprint headder name
 * This method is supposed to call once search filter is applied
 */
catalog.prototype.getBluePrintHeaderName = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.bluePrintTitleCss))), timeout.timeoutInMilis);
	return element(by.css(this.bluePrintTitleCss)).getText().then(function(text){
	   logger.info("Blueprint header name : "+text);
	   return (text.toString()).trim();
   });
};

catalog.prototype.getAllBluePrintHeaderName = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.bluePrintTitleCss))), timeout.timeoutInMilis);
	return element.all(by.css(this.bluePrintTitleCss)).getText().then(function(text){
	   logger.info("Blueprint header name : "+text);
	   return (text.toString()).trim();
   });
};


/**
 * Method to return "No Matching service found", In case service is deleted or not published
 */
catalog.prototype.getBlueprintNotAvailableMsg = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.noBlueprintFoundCss))), timeout.timeoutInMilis);
	return element(by.css(this.noBlueprintFoundCss)).getText().then(function(text){
	   logger.info("Blueprint not available Message : "+text);
	   return (text.toString()).trim();
   });
};

catalog.prototype.getIndexofBluePrint = function(blueprintName){
	var self=this;
	browser.wait(EC.elementToBeClickable(element(by.css(this.bluePrintTitleCss))), 90000).then(function(){
		logger.info("Waiting for services to display");
	}).catch(function(err){
		logger.info("Services are not displaying on catalog page");
		//Navigate to home page and re-launch catalog page
	/*	util.switchToDefault();
		var storeHeader = element(by.css(self.storeHeaderCss));
		browser.wait(EC.elementToBeClickable(storeHeader), 90000);
		storeHeader.click().then(function(){
			logger.info("Clicked on Catalog store header link")
		});
		self.open();
		//Search service instance
		self.searchForBluePrint(blueprintName); */
		
	//	util.switchToDefault();
	//	browser.executeScript("document.getElementById('mcmp-iframe').contentDocument.location.reload(true);")
// 		browser.navigate().refresh();
	//	util.switchToFrame();
	//	util.waitForAngular();
	//	browser.sleep(5000);
	//	util.waitForLoader();			
	//	self.validateIfOneServiceIsDisplayed();		
	});
	return element.all(by.css(this.bluePrintTitleCss)).getText().then(function(arr){
	   logger.info("Got all the elemets. Going to find the index of "+blueprintName);
	   for (var i=0;i<arr.length;i++){
		   logger.info("Comparing "+arr[i]+" with "+blueprintName);
           /*if (arr[i].indexOf(blueprintName)>-1){
                           return [i,arr[i]];
			}*/
		   if(arr[i] == blueprintName){
			   return i;
		   }
		}
   })
};

catalog.prototype.getAllServicesFromUI = function(){
	var current = this;
	//return element.all(by.css('article.bx--card'));
	return element.all(by.css(current.serviceTileCss))
	};
	
// function to determine Details button is displayed on a random selected catallog/service tile

catalog.prototype.isDisplayedDetailsButtonOnRandomBlueprint = function () {
	var current = this;
	return element.all(by.css(this.bluePrintTitleCss)).getText().then(function (arr) {
	    var noOfServiceTilesDisplayedInUi = arr.length;
		var index = Math.floor((Math.random() * noOfServiceTilesDisplayedInUi) + 0);
		logger.info("selecting template at index " + index);
		logger.info("selecting template title " + arr[index]);
		return element.all(by.css(current.serviceTileDetailsButtonCss)).get(index).isDisplayed();
	});

};

// function to click Details button  on a random selected catalog/service tile
catalog.prototype.clickDetailsButtonOnRandomBluePrint = function () {
	var current = this;
	return element.all(by.css(this.bluePrintTitleCss)).getText().then(function (arr) {
		var noOfServiceTilesDisplayedInUi = arr.length;
		var index = Math.floor((Math.random() * noOfServiceTilesDisplayedInUi) + 0);
		logger.info("selecting template at index " + index);
		logger.info("selecting template title " + arr[index]);
		element.all(by.css(current.serviceTileDetailsButtonCss)).get(index).click();
	});
};
	
catalog.prototype.isDisplayedConfigureButtonBasedOnName = function(blueprintName){
    var index = this.getIndexofBluePrint(blueprintName);
	var elem = element.all(by.css(this.configureButtonCss)).get(index);
	browser.sleep(8000);
	browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());
	browser.actions().mouseMove(elem).perform();
	return elem.isDisplayed().then(function(isDisplayed){
		logger.info("Is Configure button present: "+isDisplayed);
		return isDisplayed;
	});
};

catalog.prototype.isDisplayedDetailsButtonBasedOnName = function(blueprintName){
    var index = this.getIndexofBluePrint(blueprintName)
	var elem = element.all(by.css(this.serviceTileDetailsButtonCss)).get(index);
	browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());
	browser.actions().mouseMove(elem).perform();
	return elem.isDisplayed().then(function(isDisplayed){
		logger.info("Is Details button present: "+isDisplayed);
		return isDisplayed;
	});
};

catalog.prototype.getServiceTileDescription = function(blueprintName){
	var index = this.getIndexofBluePrint(blueprintName);
	var locator = element.all(by.css(this.serviceTileDescCss)).get(index);
	browser.executeScript("arguments[0].scrollIntoView();", locator);
	logger.info("Service tile description is present.");
	return locator.getText();
};

catalog.prototype.verifyServiceTileIsClickable = function(blueprintName){
	var index = this.getIndexofBluePrint(blueprintName);
	var locator = element.all(by.css(this.catalogServiceTileCss)).get(index);
	browser.executeScript("arguments[0].scrollIntoView();", locator);
	browser.wait(EC.elementToBeClickable(locator), 15000);
	return locator.isEnabled().then(function(isEnabled){
		logger.info("Is Service Tile enabled: "+isEnabled);
		return isEnabled;
	});
};

catalog.prototype.getServiceTileProviderName = function(blueprintName){
	var index = this.getIndexofBluePrint(blueprintName);
	var locator = element.all(by.css(this.serviceTileProviderNameCss)).get(index);
	browser.executeScript("arguments[0].scrollIntoView();", locator);
	logger.info("Service tile provider name is present.");
	return locator.getText();
};

catalog.prototype.clickConfigureButtonBasedOnName = function(blueprintName){
	var current = this;
	util.waitForAngular();
	browser.sleep(3000);
	return this.getIndexofBluePrint(blueprintName).then(function(index){
		var serviceToClick= element.all(by.css(current.bluePrintTitleCss)).get(index);
	browser.wait(EC.elementToBeClickable(serviceToClick), 150000);	
	browser.executeScript("arguments[0].scrollIntoView();", serviceToClick.getWebElement());
	browser.sleep(2000);
	browser.actions().mouseMove(serviceToClick).click().perform().then(function () {
		logger.info("Catalog Page - Clicked button for "+ blueprintName)
	});
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(current.configureButtonDetailsCss))), 150000);	
	return element(by.css(current.configureButtonDetailsCss)).click().then(function() {
		logger.info("Clicked configure button on Details page for " + blueprintName);
	}).catch(function(err){//Handling since click on configure for some services not working
		browser.sleep(3000);
		browser.executeScript("arguments[0].click();", serviceToClick.getWebElement());
	});
	});
 };

/*catalog.prototype.clickConfigureButtonBasedOnName = function(blueprintName){
	var current = this;
	return this.getIndexofBluePrint(blueprintName).then(function(index){
		var locator= element.all(by.css(current.configureButtonCss)).get(index);
		browser.executeScript("arguments[0].scrollIntoView();", locator.getWebElement());
		browser.sleep(2000);
		browser.actions().mouseMove(locator).click().perform().then(function () {
			logger.info("Clicked configure button for "+ blueprintName)
		});
		util.waitForAngular();
		browser.sleep(3000);
		element(by.css(current.textServiceInstancePrefixCss)).isPresent().then(function(res){	
			if(res==false){
				element(by.buttonText(current.configureButtonDetailsText)).click().then(function() {
					logger.info("Clicked configure button on Details page again for " + blueprintName);
				}).catch(function(err){//Handling since click on configure for some services not working
					browser.sleep(3000);
					browser.executeScript("arguments[0].click();", locator.getWebElement());
				});
			}
			else
				{
					logger.info("Configure button was clicked on catalog page");
				}
		})
    })
};*/

/**
 * Method to click on details button on catalog page based on service name provided
 */
catalog.prototype.clickDetailsButtonBasedOnName = function(blueprintName){
	var current = this;
	util.waitForAngular();
	browser.sleep(3000);
	return this.getIndexofBluePrint(blueprintName).then(function(index){
		var serviceToClick= element.all(by.css(current.bluePrintTitleCss)).get(index);
	browser.wait(EC.elementToBeClickable(serviceToClick), 150000);	
	browser.executeScript("arguments[0].scrollIntoView();", serviceToClick.getWebElement());
	browser.sleep(2000);
	browser.actions().mouseMove(serviceToClick).click().perform().then(function () {
		logger.info("Catalog Page - Clicked button for "+ blueprintName );
	});
	util.waitForAngular();
});
};

catalog.prototype.clickConfigureButtonInDetails = function(){
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.buttonText(this.configureButtonDetailsText))),25000);
	element(by.buttonText(this.configureButtonDetailsText)).click().then(function() {
		logger.info("Clicked configure button on Details page");
	})
};

catalog.prototype.clickBluePrintBasedOnName = function(blueprintName){
	var current = this;
	return this.getIndexofBluePrint(blueprintName).then(function(index){
	   var locator= element.all(by.css(current.bluePrintTitleCss)).get(index);
	   browser.executeScript("arguments[0].scrollIntoView();", locator.getWebElement());
		browser.sleep(2000);
		browser.actions().mouseMove(locator).click().perform().then(function () {
			logger.info("Clicked template for "+ blueprintName)
		})
   })
};

//Function to mouse click on a randomly selected  blueprint tile
catalog.prototype.clickOnRandomlySelectedBluePrint = function(){
	var current = this;
	return element.all(by.css(this.bluePrintTitleCss)).getText().then(function(arr){
		var index = Math.floor((Math.random() * (arr.length-1)));
		logger.info("selecting template at index "+index);
		element.all(by.css(current.bluePrintTitleCss)).get(index).click();
	})
};

//Function to mouse click on a randomly selected  blueprint configure button
catalog.prototype.clickConfigureBtnOnRandomlySelectedBluePrint = function(){
	var current = this;
	return element.all(by.css(this.bluePrintTitleCss)).getText().then(function(arr){
		var index = Math.floor((Math.random() * (arr.length-1)));
		logger.info("selecting template at index "+index);
		element.all(by.css(current.configureButtonCss)).get(index).click();
	})
};



//Function to use keys TAB + TAB  ENTER to operate Details button
catalog.prototype.selectDetailsButtonFromRandomBluePrintViaKeyBoard = function(){
	var current = this;
	return element.all(by.css(this.bluePrintTitleCss)).getText().then(function(arr){
		var index = Math.floor((Math.random() * (arr.length-1)));
		logger.info("selecting template at index "+index);
		element.all(by.css(current.configureButtonCss)).get(index).sendKeys(protractor.Key.TAB, protractor.Key.TAB,protractor.Key.ENTER);
	})
};

//Function to use keys TAB + TAB + TAB ENTER to operate Configure button
catalog.prototype.selectConfigureButtonFromRandomBluePrintViaKeyBoard = function(){
	var current = this;
	return element.all(by.css(this.bluePrintTitleCss)).getText().then(function(arr){
		var index = Math.floor((Math.random() * (arr.length-1)));
		logger.info("selecting template at index "+index);
		element.all(by.css(current.configureButtonCss)).get(index).sendKeys(protractor.Key.TAB, protractor.Key.TAB, protractor.Key.TAB,protractor.Key.ENTER);
	})
};

//Function to use keys TAB + ENTER to operate a service tile

catalog.prototype.selectRandomBluePrintViaKeyBoard = function(){
	var current = this;
	return element.all(by.css(this.bluePrintTitleCss)).getText().then(function(arr){
		var index = Math.floor((Math.random() * (arr.length-1)));
		logger.info("selecting template at index "+index);
		element.all(by.css(current.bluePrintTitleCss)).get(index).sendKeys(protractor.Key.TAB, protractor.Key.ENTER);
	})
};
//*************************** Functions for Filters ******************************************

//This function is used to get complete list of providers
catalog.prototype.getListofProviders = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.providerCompleteListCss))),15000);
	return element.all(by.css(this.providerCompleteListCss)).getText()

};

//This function is used to get complete list of first Category
catalog.prototype.getListofFirstCategories = function(){
	   browser.wait(EC.visibilityOf(element(by.css(this.firstCategoryCompleteListCss))),25000);
	   return element.all(by.css(this.firstCategoryCompleteListCss)).getText()
}; 


// This function is used to get the index of provider checkbox based on passed provider name
catalog.prototype.getIndexofProvider = function(providerName){
	util.waitForAngular();
	browser.sleep(5000);
	var elemProvider = element(by.css(this.providerCheckboxesLabelCss));
	browser.wait(EC.elementToBeClickable(elemProvider),90000).then(function(){
		logger.info("Getting index of provider");
	}).catch(function(err){
		logger.info(err.name);
		logger.info(err.message);
		logger.info("Unable to get index of provider");
	});
// 	browser.executeScript('arguments[0].scrollIntoView(true)', elemProvider.getWebElement()).then(function(){
// 		logger.info("Scrolling on top of Provider checkbox");
// 	}).catch(function(err){
// 		logger.info(err.name);
// 		logger.info(err.message);
// 	});	
	return element.all(by.css(this.providerCheckboxesLabelCss)).getText().then(function(arr){
		for (var i=0;i<arr.length;i++){
			if (arr[i] == providerName) {
				break;
			}
		}
	return i;		
	});
};
	
//This function is used to get click the provider CheckBox based on the passed provider name
catalog.prototype.clickProviderCheckBoxBasedOnName = function (providerName) {
	var curr = this;
	logger.info("Waiting for the Provider to be identified and Click it");
    browser.wait(EC.urlContains(appUrls.catalogPageUrl), 90000).then(function () {
        //browser.sleep(5000);
        curr.getIndexofProvider(providerName).then(function (index) {
			//store-filter-menu_store-filter-menu-item_provider_1_input
			//var id="-store-filter-menu_store-filter-menu-item_provider_" + index;
			var id="store-filter-menu_store-filter-menu-item_provider_" + index + "_input";
            var elemLocator = "input[id = '"+id+"'] ~ label";
			util.waitForAngular();
                browser.wait(EC.elementToBeClickable(element(by.css(elemLocator))), 60000).then(function () {
					//browser.sleep(3000);
					util.waitForAngular();
					element(by.css(elemLocator)).click().then(function () {
                        logger.info("Succesfully clicked on Provider : " + providerName);
						util.waitForAngular();
                    });
                });
            });
        });
};
	
//This function is used to get the index of first category checkbox based on passed category name
catalog.prototype.getIndexofFirstCategory = function(firstCategoryName){
	browser.wait(EC.visibilityOf(element(by.css(this.listCategoriesCss))),10000);
	return element.all(by.css(this.listCategoriesCss)).getText().then(function(arr){
		for (var i=0;i<arr.length;i++)
			if (arr[i] == firstCategoryName)
	               return i;
	  	})
};
	
//This function is used to get click the category CheckBox based on the passed category name
catalog.prototype.clickFirstCategoryCheckBoxBasedOnName = function (firstCategoryName) {
	var curr = this;
	logger.info("Waiting for the Category to be identified and Click it");
	browser.wait(EC.urlContains(appUrls.catalogPageUrl), 15000).then(function () {
		//browser.sleep(5000);
		util.waitForAngular();
		//Click on All Categories tab to refresh page
		//Workaround for services not found issue
		var allCateg = element(by.cssContainingText('.cb--selectable-list', 'All Categories'));
		browser.wait(EC.visibilityOf(allCateg), 60000).then(function () {
			browser.wait(EC.elementToBeClickable(allCateg), 60000).then(function () {			
				allCateg.click().then(function () {
					logger.info("Succesfully clicked on All Categories tab");
					util.waitForAngular();
				}).catch(function(err){
					logger.info("Unable to click on All Categories button");
				});
			});
		});	
		curr.getIndexofFirstCategory(firstCategoryName).then(function (index) {
			var index2 = index + 1;
			var elemLocator = ".cb--selectable-list li:nth-child(" + index2 + ")";
			browser.wait(EC.visibilityOf(element(by.css(elemLocator))), 60000).then(function () {
				browser.wait(EC.elementToBeClickable(element(by.css(elemLocator))), 60000).then(function () {
					browser.sleep(5000);
					element(by.css(elemLocator)).click().then(function () {
						logger.info("Succesfully clicked on Category : " + firstCategoryName);
						util.waitForAngular();
						browser.wait(EC.elementToBeClickable(element(by.css(curr.bluePrintTitleCss))), 90000).then(function () {
							logger.info("Waiting for services to display ");
						}).catch(function (err) {
							element(by.xpath("//span[contains(text(),' No filter result matched.')]")).isPresent().then(function (res) {
								if (res) {
									logger.info("No filter result matched... reclick on Category...")
									element(by.css(curr.allCategoriesCss)).click();
									browser.wait(EC.visibilityOf(element(by.css(elemLocator))), 60000).then(function () {
										browser.wait(EC.elementToBeClickable(element(by.css(elemLocator))), 60000).then(function () {
											browser.sleep(5000);
											element(by.css(elemLocator)).click().then(function () {
												logger.info("Succesfully clicked on Category : " + firstCategoryName);
											});
										});
									});
								}
							});
						});

					});
				});
			});
		});
	});
};

//This function clicks on reset link when the checkboxes for Blue prints and categories are checked
catalog.prototype.clickResetLinkCatalog = function(){
	browser.sleep(3000);
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.linkText(this.linkTextReset))), 25000).then(function(){
		logger.info("Clicked on Reset link");
	});
	return element(by.linkText(this.linkTextReset)).click();
};

catalog.prototype.isPresentResetLinkCatalog = function(){
	return element(by.linkText(this.linkTextReset)).isPresent();
};

//This function clicks on reset link when the checkboxes for provider checked
catalog.prototype.clickResetLinkCatalogProviderSection = function(){
	browser.sleep(15000);
	browser.wait(EC.elementToBeClickable(element(by.css(this.resetLinkForProviderSection))), 25000);
	return element(by.css(this.resetLinkForProviderSection)).click();
};

catalog.prototype.isPresentResetLinkCatalogProviderSection = function(){
	browser.sleep(5000);
	browser.wait(EC.visibilityOf(element(by.css(this.resetLinkForProviderSection))), 25000);
	return element(by.css(this.resetLinkForProviderSection)).isPresent();

};

//This function clicks on reset link when the checkboxes for categories are checked
catalog.prototype.clickResetLinkCatalogCategorySection = function(){
	browser.sleep(15000);
	browser.wait(EC.elementToBeClickable(element(by.css(this.resetLinkForCategorySection))), 25000);
	return element(by.css(this.resetLinkForCategorySection)).click();
};

catalog.prototype.isPresentResetLinkCatalogCategorySection = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.resetLinkForCategorySection))), 25000);
	return element(by.css(this.resetLinkForCategorySection)).isPresent();

};

catalog.prototype.getBasePriceOfDisplayedTemplates = function(){
	return element.all(by.css(this.basePriceForDisplayedTemplatesCss)).getText().then(function(texts){
		logger.info("Displayed base prices: "+texts);
	});
};

/**
 * Method to select the label filter based on input provided
 */
catalog.prototype.selectLabelsFilter = function(filterName){
	var self = this;
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(self.labelsSearchBoxCss))), timeout.timeoutInMilis);
	browser.executeScript('return arguments[0].scrollIntoView()', element(by.css(self.labelsSearchBoxCss)).getWebElement());
	browser.wait(EC.visibilityOf(element(by.css(self.labelsSearchInputCss))), 30000).then(function(){
		logger.info("Label filter search box is visible");
	}).catch(function(err){
		browser.executeScript('return arguments[0].scrollIntoView()', element(by.css(self.labelsSearchBoxCss)).getWebElement());
		element(by.css(self.labelsSearchBoxCss)).click();
		util.waitForAngular();
	});
	element(by.css(self.labelsSearchInputCss)).clear();
	element(by.css(self.labelsSearchInputCss)).sendKeys(filterName);
	element(by.css(self.labelsSearchInputCss)).sendKeys(protractor.Key.ENTER);
	browser.sleep(2000);
	browser.wait(EC.visibilityOf(element(by.css(self.labelsFilterTextCss + filterName))), timeout.timeoutInMilis);
	element.all(by.css(self.labelsFilteredTextCss)).getAttribute("innerText").then(function(text){
		for(var i = 0; i < text.length; i++){
			if(text[i]==filterName){
				logger.info("Filter name "+filterName+" is present");
				browser.executeScript('return arguments[0].scrollIntoView()', element.all(by.css(self.labelsFilterCheckBoxCss)).get(i));
				browser.wait(EC.elementToBeClickable(element.all(by.css(self.labelsFilterCheckBoxCss)).get(i)), timeout.timeoutInMilis);
				element.all(by.css(self.labelsFilterCheckBoxCss)).get(i).click().then(function(){
					logger.info("Clicked on filter "+filterName+" checkbox");
				});
				util.waitForAngular();
			}
		}
	});
};

//*************************** Function for Searching ******************************************
catalog.prototype.searchForBluePrint = function(blueprintName){
	browser.wait(EC.visibilityOf(element(by.xpath(this.searchTextBoxInputXpath))), timeout.timeoutInMilis);
	element(by.xpath(this.searchTextBoxInputXpath)).clear();
	element(by.xpath(this.searchTextBoxInputXpath)).sendKeys(blueprintName);
	element(by.xpath(this.searchTextBoxInputXpath)).sendKeys(protractor.Key.ENTER).then(function(){
		browser.sleep(3000);
		logger.info("Searching for "+ blueprintName + " on Catalog page." );
	});
};

// Verify Search box from the catalog page
catalog.prototype.verifyHeaderSearchBox = function(){
	browser.wait(EC.visibilityOf(element(by.xpath(this.searchTextBoxInputXpath))), 10000);
	return element(by.xpath(this.searchTextBoxInputXpath)).isPresent().then(function(res){
		logger.info("Is Searchbox present: "+res);
		return res;
	});
};

// Verify Header before scrolling services frame
catalog.prototype.verifyHeaderBeforeScrolling = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.pageHeaderSubtitleCss))), 10000);
	return element(by.css(this.pageHeaderSubtitleCss)).isDisplayed().then(function(res){
		logger.info("Is Subtitle displayed: "+res);
		return res;
	});
};

// Verify Header after scrolling services frame
catalog.prototype.verifyHeaderAfterScrolling = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.lastServiceHeading))), 10000);
	var svcHeading = element(by.css(this.lastServiceHeading));
	browser.actions().mouseMove(svcHeading).perform();
	browser.wait(EC.visibilityOf(element(by.css(this.contentScrolledCss))), 10000);
	return element(by.css(this.pageHeaderSubtitleCss)).isDisplayed().then(function(res){
		logger.info("Is Subtitle displayed: "+res);
		return res;
	});
};

//Mahendra-Adding below function to click on provider or category checkbox directly using value attribute.
/*catalog.prototype.clickProviderOrCategoryCheckbox = function (valueToCheck) {
	var elemLocator;
	if(valueToCheck == "Amazon" || valueToCheck == "Google"){
		//valueToCheck ="aws";
		//element for Provider
		elemLocator = "//label[contains(text() ," + "'" + valueToCheck + "'" + ")]";
	}else{//Element for Category
		elemLocator = "//a[contains(text() ," + "'" + valueToCheck + "'" + ")]";
	}
	util.waitForAngular();
	browser.wait(EC.urlContains("storeFront/main"), 60000).then(function () {
		//browser.sleep(3000);
		util.waitForAngular();
		// Find an element and define it
		//browser.wait(EC.visibilityOf(element(by.css(elemLocator))), 60000).then(function () {
			//var elemLocator = "input[value = '" + valueToCheck.toLowerCase() + "']~label";			
			var elementToClick = element(by.xpath(elemLocator));
			// Scroll the browser to the element's Y position
			browser.executeScript("window.scrollTo(0,"+elementToClick.getLocation().y+")").then(function(){
				// Click the element		
				browser.wait(EC.elementToBeClickable(elementToClick, 60000)).then(function () {
					return elementToClick.click().then(function () {
						logger.info("Succesfully clicked on Provider : " + valueToCheck);
						util.waitForAngular();
					}).catch(function(){
						logger.info("2nd Attempt to click : " + valueToCheck);
						return elementToClick.click().then(function () {
							logger.info("Succesfully clicked on Provider : " + valueToCheck);
							util.waitForAngular();
						});
					});
				});					
				
			});
			
		
		//});		
		
	});

};*/

catalog.prototype.clickProviderOrCategoryCheckbox = function (valueToCheck) {
	
	var prvdrList = element.all(by.css(this.chkboxProviderLstCss));
	var catgryList = element.all(by.css(this.chkboxCategoryLstCss));
	var elemLocator;
	//util.waitForAngular();
	//Adding hardcoded wait as waitForAngular is not able yo sync page completely
	//browser.sleep(5000);
	browser.wait(EC.elementToBeClickable(prvdrList.get(1)), 90000).then(function () {
		logger.info("Waiting for Provider/Category list item to be clickable");
	}).catch(function(err){
		logger.info("Provider/Category item is not clickable");
	});
	
	//Click on All Categories tab to refresh page
	//Workaround for services not found page
	//COmmenting below workaround as performance of application is stable now, no need of this extra workaround.
// 	var allCateg = element(by.css(defaultConfig.allCategoriesCss));
// 	browser.wait(EC.visibilityOf(allCateg), 60000).then(function () {
// 		browser.wait(EC.elementToBeClickable(allCateg), 60000).then(function () {			
// 			allCateg.click().then(function () {
// 				logger.info("Succesfully clicked on All Categories tab");
// 				util.waitForAngular();
// 			}).catch(function(err){
// 				logger.info("Unable to click on All Categories button");
// 			});
// 		});
// 	});
	return prvdrList.getText().then(function(provdrList){
		catgryList.getText().then(function(categoryList){
			if(provdrList.indexOf(valueToCheck) != -1){
				//elemnt for clicking on provider
				elemLocator = "//span[contains(text()," + "'" + valueToCheck + "'"  + ")]";
			}else{//elemnt for clicking on category 					
				if(categoryList.indexOf(valueToCheck) != -1){
					elemLocator = "//a[contains(text()," + "'" + valueToCheck + "'" + ")]";
				}else{
					logger.info("Unable to click on Provider/Category");
					return;
				}
			}
			var elementToClick = element(by.xpath(elemLocator));
			browser.executeScript("window.scrollTo(0,"+elementToClick.getLocation().y+")").then(function(){
				// Click the element		
				browser.wait(EC.elementToBeClickable(elementToClick, 60000)).then(function () {
					return elementToClick.click().then(function () {
						logger.info("Succesfully clicked on Provider : " + valueToCheck);
						util.waitForAngular();
					}).catch(function(){
						logger.info("2nd Attempt to click : " + valueToCheck);
						browser.sleep(5000);
						return elementToClick.click().then(function () {
							logger.info("Succesfully clicked on Provider : " + valueToCheck);
							util.waitForAngular();
						});
					});

				});					
				
			});
		});
	});	
};

catalog.prototype.clickCartIcon = function () {
    browser.switchTo().defaultContent();
   // util.waitForAngular();
    browser.wait(EC.elementToBeClickable(element(by.css(this.cartIconCss))), 160000).then(function(){
	logger.info("Waiting for cart icon to be clickable");	
    }).catch(function(err){
	logger.info("Cart icon is not clickable");	
    });
    return element(by.css(this.cartIconCss)).click().then(function () {
   	 logger.info("clicked on Cart icon");
    });;
};

catalog.prototype.searchCartFromList = function (cartName) {
	  return element(by.xpath("//*[@title='" + cartName + "']"))

};

catalog.prototype.closeNotificationPopUp = function()
{
	//browser.wait(EC.visibilityOf(element(by.xpath(this.closeNotificationIconXpath))), 5000);
    element(by.xpath(this.closeNotificationIconXpath)).click().then(function () {
    	logger.info("closed Notification Pop Up Box");  
    }); 
};

catalog.prototype.extractUserFirstName = function()
{
	var userName = browser.params.username;
	var userFirstName = userName.replace(/@.*$/,"");
	logger.info("First username extracted :: "+userFirstName)
	return userFirstName;
};

catalog.prototype.getUserID = function(userNameToVerify){	
	//Handling for username having same first name and last name separated by space
	browser.switchTo().defaultContent();
	util.waitForAngular();
	browser.sleep(4000);
		
	var userName = userNameToVerify.split(" ")[0];
	return new Promise(function(resolve, reject) {		
		var elemUserIcon = element(by.xpath(defaultConfig.userIconXpath));
		elemUserIcon.click().then(function () {
			logger.info("clicked on User Icon");
		});
		//var elem = element(by.xpath('(//*[contains(text(), "'+ userNameToVerify +'")])[1]'));
		var elem = element(by.xpath('(//*[contains(text(), "'+ userName +'")])'));
		//Commenting below condition since if element is not present , script will timeout and wont proceed further.
		//browser.wait(EC.visibilityOf(elem), 60000);
		elem.isPresent().then(function(present) {		
			logger.info(userNameToVerify + " isPresent: " + present);
			if(present == true){
				elem.getAttribute("innerText").then(function(text){		
					//logger.info("Logged in user : " + text.split("/")[0]);
					logger.info("Logged in user : " + text);
					elemUserIcon.click().then(function () {
						logger.info("clicked on User Icon");
						//resolve (text.split("/")[0] == userNameToVerify);	
						if(text.includes(userName)){
							resolve(true);
						}else{
							resolve(false);
						}			
						
					});				
				});		
			}else{
				elemUserIcon.click();
				logger.info(userNameToVerify + " isPresent: " + present);
				resolve(false);	
			}
		}).catch(function(err){
			logger.info("No element found as per UserName");
			resolve(false);
		});
		//Commenting below line as its not relevant while checking presence of element in DOM
		//browser.executeScript("arguments[0].scrollIntoView(true);", elem.getWebElement());
		
	});
};

catalog.prototype.validateConfigErrorMsg = function() {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.configErrorMsgCss))), 10000);
	return element(by.css(this.configErrorMsgCss)).getText().then(function(text){
	   logger.info("Catalog Configuration Error Message : "+text);
	   return text;
   });
};

/*****************MCMP Store Catalog Page Functions***********************************/

/*catalog.prototype.clickHamburgerCatalog = function(){
	util.waitForAngular();
 	//browser.waitForAngularEnabled(false);
 	browser.wait(EC.visibilityOf(element(by.css(this.hamburgerCatalogCss))),90000);
 	return element(by.css(this.hamburgerCatalogCss)).click().then(function(){
 		logger.info("Clicked on hamburger button");		
 	})
 };*/

catalog.prototype.clickHamburgerCatalog = function(){
	//Setting timeout for hamburger button
	//browser.driver.manage().timeouts().setScriptTimeout(60000);
	var self = this;
	util.waitForAngular();
	var elem = element(by.css(this.hamburgerCatalogCss));	
	browser.wait(EC.elementToBeClickable(element(by.css(this.hamburgerCatalogCss))),90000).then(function(){
		logger.info("Hamburger button is clickable");
	}).catch(function(err){
		logger.info("Hamburger button is not clickable");
		browser.navigate().refresh();
		browser.sleep(5000);
		util.waitForAngular();
	});
	
	browser.executeScript("arguments[0].click();", elem.getWebElement()).then(function(){
		logger.info("Clicked on hamburger button using javascript");
	}).catch(function(err){
		return element(by.css(this.hamburgerCatalogCss)).click().then(function(){
			logger.info("Clicked on hamburger button");		
		});
	});	
	//Re-Setting timeout for allScripts as defined in config
	//browser.driver.manage().timeouts().setScriptTimeout(browser.allScriptsTimeout);	
};

catalog.prototype.checkLeftNavBarOpened = function(){
	return element(by.css(this.leftNavBarCss)).getAttribute("class").then(function(res){
		if(res.includes("expanded")) {
			logger.info("Left navigation bar is opened");
		}
		else if(res.includes("pinned")) {
			logger.info("Left navigation bar is pinned and opened");
		}
		else {
			logger.info("Left navigation bar is hidden");
		}			
	    return res;
	})
};

catalog.prototype.clickPinLeftNavBar = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.pinLeftNavBarCss))),90000);
	return element(by.css(this.pinLeftNavBarCss)).click().then(function(){
		logger.info("Clicked on pin button in left navigation bar");
	})
};

catalog.prototype.clickArrowLeftNavBar = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.arrowLeftNavBarCss))),90000);
	return element(by.css(this.arrowLeftNavBarCss)).click().then(function(){
		logger.info("Clicked on arrow button in left navigation bar");
	})
};

catalog.prototype.clickLeftNavAdminPortalLink = function(){
	browser.wait(EC.visibilityOf(element(by.xpath(this.textLeftNavAdminPortalLinkXpath))),90000);
	element(by.xpath(this.textLeftNavAdminPortalLinkXpath)).click().then(function(){
		logger.info("Clicked on Admin Portal link in left navigation bar");
	})
};

catalog.prototype.clickLeftNavLinkBasedOnName = function(navLink){
	var self= this;
	browser.wait(EC.elementToBeClickable(element.all(by.css(self.textLeftNavButtonCss)).get(0)),90000).then(function(){
		logger.info("Waiting for button to load - " + navLink);
	}).catch(function(err){
		logger.info(navLink + " is not Visible; Refreshing browser");
		//Handling for EMP option not visible issue
		browser.refresh();
		util.waitForAngular();
	});	
	browser.wait(EC.elementToBeClickable(element.all(by.css(self.textLeftNavLinkCss)).get(0)),90000).then(function(){
		logger.info("Navigation links are displayed and clickable");
	}).catch(function(err){
		logger.info("Portal link is not clickable")
	});

	// var navigation_link = element(by.xpath("//li[@class='bx--side-nav__menu-item']/a[@title='" + navLink + "']/span"))
	// return navigation_link.click().then(function() {
	// 	logger.info("Clicked on " + navLink + " link on left navigation bar");
	// 	util.waitForAngular();
	// })
	
	return element.all(by.css(self.textLeftNavLinkCss)).getText().then(function(links){
		for(var i=0; i<links.length; i++) {			
			if(links[i].trim()==navLink) {
				return element.all(by.css(self.textLeftNavLinkCss)).get(i).click().then(function() {
					logger.info("Clicked on " + navLink + " link on left navigation bar");
					util.waitForAngular();
				})
			}			
		}		
	})
};

catalog.prototype.clickLeftNavButtonBasedOnName = function(navBtn){
	var self= this;
	browser.wait(EC.visibilityOf(element.all(by.css(self.textLeftNavButtonCss)).get(0)),90000).then(function(){
		logger.info("Waiting for button to load - " + navBtn);
	}).catch(function(err){
		logger.info(navBtn + " is not Visible; Refreshing browser");
		//Handling for EMP option not visible issue
		browser.refresh();
		util.waitForAngular();
	});	

	browser.wait(EC.visibilityOf(element.all(by.css(self.textLeftNavButtonCss)).first()),90000);
	return element.all(by.css(self.textLeftNavButtonCss)).getText().then(function(btns){
		for(var i=0; i<btns.length; i++) {		
			if(btns[i]==navBtn) {
				return element.all(by.css(self.textLeftNavButtonCss)).get(i).click().then(function() {
					logger.info("Clicked on " + navBtn + " button on left navigation bar");					
				})
			}			
		}		
	})
};

catalog.prototype.checkIfleftNavStoreExpanded = function(){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(self.buttonLeftSubmenuCss))),90000);
	element.all(by.css(self.buttonLeftSubmenuCss)).getText().then(function(text) {
		for(var i=0;i<text.length;i++) {
			if(text[i]==mcmpUIDataTemplate.leftNavButtonStore) {
				return element.all(by.xpath(self.buttonLeftSubmenuExpandXpath)).get(i).getAttribute("aria-expanded").then(function(res){
					//if(res=="false") {If button is not expanded, returned value is null
					if(res != "true") {
						self.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
					}
					else { 
						logger.info("Store is already expanded");
					}
				})
			}
		}
	})
};

catalog.prototype.checkIfleftNavAdminExpanded = function(){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(self.buttonLeftSubmenuCss))),90000);
	element.all(by.css(self.buttonLeftSubmenuCss)).getText().then(function(text) {
		for(var i=0;i<text.length;i++) {
			if(text[i]==mcmpUIDataTemplate.leftNavButtonAdmin) {
				return element.all(by.xpath(self.buttonLeftSubmenuExpandXpath)).get(i).getAttribute("aria-expanded").then(function(res){
					if(res != "true") {
						self.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonAdmin);
					}
					else { 
						logger.info("Admin is already expanded");
					}
				})
			}
		}
	})
};

catalog.prototype.checkIfleftNavSettingsExpanded = function(){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(self.buttonLeftSubmenuCss))),90000);
	element.all(by.css(self.buttonLeftSubmenuCss)).getText().then(function(text) {
		for(var i=0;i<text.length;i++) {
			if(text[i]==mcmpUIDataTemplate.leftNavButtonSettings) {
				return element.all(by.xpath(self.buttonLeftSubmenuExpandXpath)).get(i).getAttribute("aria-expanded").then(function(res){
					if(res == "true") {
						logger.info("Settings is already expanded");
					}
					else { 
						self.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonSettings);
					}
				})
			}
		}
	})
};

catalog.prototype.clickResetProviderLink = function(){
	var self= this;
	element(by.linkText(self.linkResetProviderText)).isPresent().then(function(res){
		if(res==true) {
			util.waitForAngular();
			browser.sleep(5000);
			browser.wait(EC.elementToBeClickable(element(by.linkText(self.linkResetProviderText))), 90000);
			element(by.linkText(self.linkResetProviderText)).click().then(function(){
				logger.info("Clicked on Reset link for provider");
				util.waitForAngular();
			})
		}
    })
};

// Click on help Button to open IBM Knowledge Center page
catalog.prototype.clickOnHelpButton = function(){
	util.waitForAngular();
	util.switchToDefault();
	browser.wait(EC.visibilityOf(element(by.css(this.helpButtonCss))),90000);
	return element(by.css(this.helpButtonCss)).click().then(function(){
		logger.info("Clicked on Help button");
	})
};

// Click on Tasks Menu Button to open right nav-bar
catalog.prototype.clickTasksMenuButton = function (rightNavButtonText) {
	util.waitForAngular();
	util.switchToDefault();
	var curr=this;
	browser.wait(EC.elementToBeClickable(element(by.css(curr.tasksMenuButtonCss))), 300000);
	element(by.css(curr.taskMenuButtonOpenCss)).isPresent().then(function (response) {
		if (response) {
			logger.info("Task Menu is already open");
			curr.clickRightNavButtonBasedOnName(rightNavButtonText);
		}
		else {
			element(by.css(curr.tasksMenuButtonCss)).click().then(function () {
				logger.info("Clicked on Tasks menu button");
			});
		}
		//curr.clickRightNavButtonBasedOnName(rightNavButtonText);
	});
};


// Check the right nav-bar is opened
catalog.prototype.isRightNavBarOpened = function(){
	var self = this;
	return browser.wait(EC.visibilityOf(element(by.css(this.rightNavBarHeaderCss))),90000).then(function() {
		return element(by.css(self.rightNavBarHeaderCss)).isPresent().then(function(result) {
			logger.info("Is navbar present: " + result);
			if (result == true){
				return result;
			}
			else{
				return result;
			}
		});
	});
};

// Check the right nav-bar is closed
catalog.prototype.isRightNavBarClosed = function(){
	var self = this;
	return browser.wait(EC.invisibilityOf(element(by.css(this.rightNavBarHeaderCss))),90000).then(function() {
		return element(by.css(self.rightNavBarHeaderCss)).isPresent().then(function(result) {
			logger.info("Is navbar present: " + result);
			if (result == false){
				return !result;
			}
			else{
				return !result;
			}
		});
	});
};

// Get Tasks header name from right nav-bar
catalog.prototype.getTasksHeaderName = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.rightNavBarHeaderCss))),10000);
	return element(by.css(this.rightNavBarHeaderCss)).getText().then(function(headerName){
		logger.info("Tasks header name is: "+headerName);
		return headerName;
	});
};


// Click on help links
catalog.prototype.clickHelpLinkBasedOnName = function(navLink){
	var self= this;
	browser.wait(EC.visibilityOf(element.all(by.css(self.textHelpLinkCss)).get(0)),90000);
	return element.all(by.css(self.textHelpLinkCss)).getText().then(function(links){
		for(var i=0; i<links.length; i++) {		
			if(links[i].trim()==navLink) {
				return element.all(by.css(self.textHelpLinkCss)).get(i).click().then(function() {
					logger.info("Clicked on " + navLink + " link on help page");
				});
			}			
		}		
	});
};

// Navigate to New tab of browser
catalog.prototype.navigateToNewTab = function(){
	var self= this;
	return browser.getWindowHandle().then(function(parentGUID){
		// click the button to open new window
	 	browser.sleep(5000);
		return browser.getAllWindowHandles().then(function(allGUID){
		console.log("Total Windows : "+allGUID.length);
			 for(let guid of allGUID){
				if(guid !=parentGUID){
				browser.switchTo().window(guid);
				 break;
		 		}
			}
			return parentGUID;
		});
	});
};

//close the current tab and Navigate to Provided Tab's GUID
catalog.prototype.closeCurrentTabNavigateToParentTab = function (parentGUID) {
	browser.close();
	browser.switchTo().window(parentGUID);
}

// Get Headers for Hep page Items
catalog.prototype.getHelpItemsPageHeader = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.helpPageHeaderCss))), 300000);
	return element(by.css(this.helpPageHeaderCss)).getText().then(function (text) {
		logger.info("Page header is: " + text);
	    return text;
	});
};
catalog.prototype.getHelpCatalogItemsPageHeader = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.helpContentHeaderCss))), 300000);
	return element(by.css(this.helpContentHeaderCss)).getText().then(function (text) {
		logger.info("Page header is: " + text);
	    return text;
	});
};

// Click on right nav-bar links
catalog.prototype.clickRightNavLinkBasedOnName = function(navLink1,navLink2){
	var self= this;
	browser.wait(EC.visibilityOf(element.all(by.css(self.textRightNavLinkCss)).get(0)),90000);
	return element.all(by.css(self.textRightNavLinkCss)).getText().then(function(links){
		for(var i=0; i<links.length; i++) {		
			if(links[i].trim()== navLink1 || links[i].trim()== navLink2 ) {
				return element.all(by.css(self.textRightNavLinkCss)).get(i).click().then(function() {
					logger.info("Clicked on " + navLink1 || navLink2 + " link on right navigation bar");
				});
			}			
		}		
	});
};

// Click on right nav-bar buttons
catalog.prototype.clickRightNavButtonBasedOnName = function (navBtn) {
	var self = this;
	var i;
	browser.wait(EC.visibilityOf(element.all(by.css(self.rightNavButtonCss)).last()), 300000);
	return element.all(by.css(self.rightNavButtonCss)).getText().then(function (btns) {
		for (i = 0; i < btns.length; i++) {
			if (btns[i] == navBtn) {
				var ele = element.all(by.css(self.rightNavButtonCss)).get(i);
				ele.getAttribute('aria-expanded').then(function (value) {
					if (value == true) {
						logger.info(navBtn + " button on right navigation bar is already Expanded");
						return;
					}
					else {
						return ele.click().then(function () {
							logger.info("Clicked on " + navBtn + " button on right navigation bar");
						});
					}
				})
			}
		}
	})
};

// Click on Close task menu icon to close right nav-bar
catalog.prototype.clickCloseTasksMenuButton = function(){
	util.waitForAngular();
	util.switchToDefault();
	browser.wait(EC.visibilityOf(element(by.css(this.tasksMenuButtonCss))),90000);
	return element(by.css(this.tasksMenuButtonCss)).click().then(function(){
		logger.info("Clicked on Close Tasks menu button");
		//task menu button takes some time to close
		browser.sleep(1000);
	})
};

/************************Functions for Labels in Catalog page***********************************************/

catalog.prototype.getTextLabelsHeader = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textLabelsHeaderCss))),90000);
	return element(by.css(this.textLabelsHeaderCss)).getText().then(function(header){
		logger.info("Labels header: " + header);
		return header;
	})
};

catalog.prototype.getTextLabelsDropdown = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textLabelsDropdownCss))),90000);
	return element(by.css(this.textLabelsDropdownCss)).getText().then(function(text){
		logger.info("Text on Labels dropdown: " + text);
		return text;
	})
};

catalog.prototype.clickLabelsDropdown = function(){
	util.waitForAngular();
	var labelElem = element(by.css(this.dropdownLabelsCss));
	browser.executeScript("arguments[0].scrollIntoView();", labelElem.getWebElement());
	browser.wait(EC.visibilityOf(labelElem),90000);
	browser.sleep(5000);
	labelElem.click().then(function(){
		logger.info("Clicked on Labels dropdown");
	})
};

catalog.prototype.searchLabelText = function(label){
	var elemSearch = element.all(by.css(this.textSearchLabelCss)).last();
	browser.wait(EC.visibilityOf(elemSearch),90000);
	return elemSearch.clear().then(function(){
		return elemSearch.sendKeys(label.toString()).then(function(){
			elemSearch.sendKeys(protractor.Key.ENTER);
			browser.sleep(5000);
			logger.info("Searching " + label + " label");
		})
	})
};

catalog.prototype.getTextLabelsDropdownOptionsCount = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.dropdownValuesLabelCss))),90000);
	return element.all(by.css(this.dropdownValuesLabelCss)).count().then(function(num){
		logger.info("Count of labels dropdown options: " + num);
		return num;
	})
};


catalog.prototype.clickLoadMoreLabelsLink = function(){
	var elem = element(by.css(this.linkLoadMoreLabelCss));
	browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());
	browser.wait(EC.visibilityOf(elem),90000);	
	elem.click().then(function() {
		logger.info("Clicked on Load More link");
	})
};

catalog.prototype.clickLoadMoreLabelsLinkIfPresent = function(){
	var self = this;
	var elem = element(by.css(self.linkLoadMoreLabelCss));
	elem.isPresent().then(function(val){
		if(val) {
			browser.wait(EC.visibilityOf(elem),90000);
			browser.executeScript("arguments[0].scrollIntoView();", elem.getWebElement());
			elem.click().then(function() {
				logger.info("Clicked on Load More link");
			})
			browser.sleep(2000);
			self.clickLoadMoreLabelsLinkIfPresent();
		}
		else {
			logger.info("Load More link is not present");
		}
		
	})		
};

catalog.prototype.selectOptionsFromLabelsDropdown = function(labels){
	var self = this;
	var n = labels.toString().search(",");
    var multiElementValueArray;   
    if(n != -1) {
		multiElementValueArray = labels.toString().split(",");
	}
    else {
		multiElementValueArray = [labels];
	}
	var dropdownValues = element.all(by.css(self.dropdownValuesLabelCss));
    dropdownValues.getText().then(function (labelsArray) {
    	for (var i = 0; i < multiElementValueArray.length; i++) {
            for (var j = 0; j < labelsArray.length; j++) {
                if (multiElementValueArray[i].toString().trim() == labelsArray[j].toString().trim()) {
                    var el = element.all(by.css(self.checkboxLabelOptionsCss)).get(j);
                    browser.executeScript("arguments[0].scrollIntoView();", el.getWebElement());
                    el.click();
                    logger.info("Clicked on checkbox " + multiElementValueArray[i] + " from Labels dropdown");
                    util.waitForAngular();
                }
            }
        }
    })	
};

catalog.prototype.clickLoadMoreUntilLabelFound = function(labels){
	var self = this;
	var multiElement = labels.toString().search(",");
    var multiElementValueArray;   
    if(multiElement != -1) {
		multiElementValueArray = labels.toString().split(",");
	}
    else {
		multiElementValueArray = [labels];
	}     
	var dropdownValuesLabel = element.all(by.css(self.dropdownValuesLabelCss));
    browser.wait(EC.presenceOf(dropdownValuesLabel), 60000);
    dropdownValuesLabel.getText().then(function (dropdownValuesArray) {
        for (var i = 0; i < multiElementValueArray.length; i++) {
        	if(dropdownValuesArray.indexOf(multiElementValueArray[i].toString().trim()) == -1) {
        		self.clickLoadMoreLabelsLink();
        		self.clickLoadMoreUntilLabelFound(labels);
        	}
        	else {
        		logger.info("Label " + multiElementValueArray[i] + " found");
        	}
        	break; 
        }
    })    
};

catalog.prototype.getTextLabelsSelectedCount = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textLabelsSelectedCountCss))),90000);
	return element(by.css(this.textLabelsSelectedCountCss)).getText().then(function(count){
		logger.info("Count of labels selected: " + count);
		return count;
	})
};

catalog.prototype.clickLabelsBasedOnName = function(options){
	this.clickLabelsDropdown();
	this.clickLoadMoreLabelsLinkIfPresent();
	this.selectOptionsFromLabelsDropdown(options);
};

catalog.prototype.clickLabelBasedOnNameSearch = function(name){
	this.clickLabelsDropdown();
	this.searchLabelText(name);
	this.selectOptionsFromLabelsDropdown(name);
	this.clickLabelsDropdown();
};

catalog.prototype.clickCloseLabelsIcon = function(){
	var self= this;
	element(by.css(self.iconCloseLabelsCss)).isPresent().then(function(res){
		if(res==true) {
			browser.sleep(5000);
			browser.wait(EC.elementToBeClickable(element(by.css(self.iconCloseLabelsCss))), 90000);
			element(by.css(self.iconCloseLabelsCss)).click().then(function(){
				logger.info("Cleared the labels");
				util.waitForAngular();
			})
		}
    })
};

catalog.prototype.checkCurrentUser = function (username) {
	var cartListPage = new CartListPage();
	var curr = this
	util.waitForAngular();
    browser.switchTo().defaultContent();
	return element.all(by.css(this.userIconCss)).isPresent().then(function (val) {
		if (val) {
			var elemUserIcon = element(by.xpath(curr.userIconXpath));
			elemUserIcon.click();
			element(by.xpath('(//*[contains(text(), "' + username + '")])[1]')).isPresent().then(function (currentUserName) {
				if (currentUserName) {
					logger.info("logged in from expected User...");
				}
				else {
					logger.info("Not logged in from supper user..");
					cartListPage.clickLogoutButton();
					cartListPage.loginFromOtherUser(browser.params.username, browser.params.password);
				}
			})
		}
		else {
			console.log("On login page..");
			cartListPage.loginFromOtherUser(browser.params.username, browser.params.password);
		}
	});
}
catalog.prototype.checkServiceIsPresent = function (blueprintName) {
	browser.wait(EC.elementToBeClickable(element(by.css(this.bluePrintTitleCss))), 90000);
	return element.all(by.css(this.bluePrintTitleCss)).getText().then(function (arr) {
		logger.info("Got all the elemets. Going to find the index of " + blueprintName);
		for (var i = 0; i < arr.length; i++) {
			logger.info("Comparing " + arr[i] + " with " + blueprintName);

			if (arr[i] == blueprintName) {
				logger.info(blueprintName + " Service is Present")
				return true;
			}
		}
	})
};

catalog.prototype.validateIfOneServiceIsDisplayed = function() {
	util.waitForAngular();
	browser.sleep(5000);
	var serviceToClick= element.all(by.css(defaultConfig.bluePrintTitleCss));		
	browser.wait(EC.elementToBeClickable(serviceToClick.get(0)), 60000);	
	return serviceToClick.getText().then(function(arr){
		logger.info("No. of items displayed matching blueprintname is " + arr.length);
		return arr.length;
	});
};

//AvailableVersions
catalog.prototype.getAvailableVersions = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.AvailableVersionsCss))), timeout.timeoutInMilis);
	return element(by.css(this.AvailableVersionsCss)).getText().then(function(AvailableVersions){
	   logger.info("Available Versions : "+AvailableVersions);
	   return (AvailableVersions.toString()).trim();
   });
};
//FeaturesText
catalog.prototype.getFeaturesText = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.FeaturesTextCss))), timeout.timeoutInMilis);
	return element(by.css(this.FeaturesTextCss)).getText().then(function(Featurestext){
	   logger.info("Features/Short Description Text : "+Featurestext);
	   return (Featurestext.toString()).trim();
   });
};
//longDescription
catalog.prototype.getlongDescription = function(){
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.longDescriptionCss))), timeout.timeoutInMilis);
	return element(by.css(this.longDescriptionCss)).getText().then(function(longDescriptiontext){
	   logger.info("Long Description Text : "+longDescriptiontext);
	   return (longDescriptiontext.toString()).trim();
   });
};


// function for fetching onetime charge for service
catalog.prototype.getOneTimeChargePrice = function () {
	logger.info("--Onetime price value is getting fetched for service--");
	browser.wait(EC.visibilityOf(element(by.css(this.OneTimeChargePriceCss))), 60000);
	return element(by.css(this.OneTimeChargePriceCss)).getText().then(function (OneTimechargePriceText) {
		logger.info("Displayed base prices: " + OneTimechargePriceText);
		return OneTimechargePriceText;
	});
};

catalog.prototype.getCatalogPageTitle = function () {
	var elmTitle = element(by.css(this.txtCatalogHeaderCss));
	return browser.wait(EC.visibilityOf(elmTitle), 60000).then(function(){
		return elmTitle.isDisplayed();
	}).catch(function(err){
		return false;
	});	
};

catalog.prototype.checkIfUserIconIsDisplayed = function(){		
	browser.switchTo().defaultContent();
	util.waitForAngular();
	//browser.sleep(4000);
	var elemUserIcon = element(by.xpath(defaultConfig.userIconXpath));
	browser.wait(EC.elementToBeClickable(elemUserIcon), 60000).then(function(){		
	}).catch(function(err){
		logger.info("User icon is not displayed after 60s on catalog/home page");
	});
	try {
		return elemUserIcon.isPresent();
	} catch (error) {
		logger.info(error.name);
		logger.info(error.message);
		return false;
	}
};
catalog.prototype.checkIfleftTerraformAutomaitonExpanded = function(){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(self.buttonLeftSubmenuCss))),90000);
	element.all(by.css(self.buttonLeftSubmenuCss)).getText().then(function(text) {
		for(var i=0;i<text.length;i++) {
			if(text[i]==mcmpUIDataTemplateIcam.leftNavTerraformAutomation) {
				return element.all(by.xpath(self.buttonLeftSubmenuExpandXpath)).get(i).getAttribute("aria-expanded").then(function(res){
					if (res == "true") {
						logger.info("Terraform Automation is already expanded");
					}
					else {
						self.clickLeftNavButtonBasedOnName(mcmpUIDataTemplateIcam.leftNavTerraformAutomation);

					}
				})
			}
		}
	})
};
catalog.prototype.checkIfleftCloudpakAdministrationExpanded = function(){
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(self.buttonLeftSubmenuCss))),90000);
	element.all(by.css(self.buttonLeftSubmenuCss)).getText().then(function(text) {
		for(var i=0;i<text.length;i++) {
			if(text[i]==mcmpUIDataTemplateIcam.leftNavCloudpakAdminstaration) {
				return element.all(by.xpath(self.buttonLeftSubmenuExpandXpath)).get(i).getAttribute("aria-expanded").then(function(res){
					if (res == "true") {
						logger.info("Cloudpak Administration is already expanded");
					}
					else {
						self.clickLeftNavButtonBasedOnName(mcmpUIDataTemplateIcam.leftNavCloudpakAdminstaration);

					}
				})
			}
		}
	})
};

module.exports = catalog;
