"use strict";

var extend = require('extend');
var async = require('async');
var url = browser.params.url;
var util = require('../../helpers/util.js');
var CatalogPage = require('../pageObjects/catalog.pageObject.js');
var mcmpUIDataTemplate = require('../../testData/mcmp/mcmpUIData.json');
var logGenerator = require("../../helpers/logGenerator.js"),
	logger = logGenerator.getApplicationLogger();
var EC = protractor.ExpectedConditions;
var path = require('path');
const extract = require('extract-zip');
var remote = require('../../node_modules/selenium-webdriver/remote/index.js');
var flag = false;
var isVM = false;
var actstatus = "";
var retFunc = false;

var defaultConfig = {

	//***********LOCATORS FOR Inventory tab ***********
	pageUrl: url + '/consume/ordered-services',
	inventoryTabXpath: '//a[contains(text(), "INVENTORY")]',

	//***********LOCATORS FOR FILTERS***********

	filtersIconXpath: '(//*[@class="bx--toolbar__menu__icon"])[1]',
	filterCheckBoxesLabelCss: '[id^=checkbox-overflow-menu-checkbox] ~ label',
	filterCheckBoxesCss: '[id^=checkbox-overflow-menu-checkbox]',
	filterProviderNamesCss: '[id^="inventory-data-table-0-tool-bar-filterByProvider"] > fieldset > carbon-overflow-menu-checkbox > li > carbon-checkbox > div > label',
	filtersNoDataTextXpath: '(//tbody/tr/td/div/h4/strong)',

	//***********LOCATORS FOR PAGINATION***********

	numberOfPagesTextCss: '.bx--pagination__text>span',
	firstitemPerPageCss: '.bx--select-option',
	seconditemPerPageCss: '#bx--pagination-0__select-option-25',
	thirditemPerPageCss: '#bx--pagination-0__select-option-50',
	paginationRightArrowXpath: '(//*[@class="bx--pagination__button bx--pagination__button--forward"])',
	paginationLeftArrowXpath: '(//*[@class="bx--pagination__button bx--pagination__button--backward"])',
	overflowmenuoptionsXpath: '(//*[@class="bx--overflow-menu-options__option"][5])',

	//*****************LOCATORS FOR SORT**************

	instanceNameColumnNameCss: '#carbon-deluxe-data-table-0-top-header-instance-name-col-1',
	statusCoulmnNameCss: '#carbon-deluxe-data-table-0-top-header-status-col-2',
	provisionedDateColumnNameCss: '#carbon-deluxe-data-table-0-top-header-provisioned-date-col-3',
	providerColumnNameCss: '#carbon-deluxe-data-table-0-top-header-provider-col-4',
	providerAccountColumnNameCss: '#carbon-deluxe-data-table-0-top-header-provider-account-col-5',
	soiSourceColumnNameCss: '#carbon-deluxe-data-table-0-top-header-soi-source-col-6',
	teamColumnNameCss: '#carbon-deluxe-data-table-0-top-header-team-col-7',
	orderedByColumnNameCss: '#carbon-deluxe-data-table-0-top-header-ordered-by-col-8',
	serviceNameColumnNameCss: '#carbon-deluxe-data-table-0-top-header-service-offering-name-col-9',
	estimatedCostColumnNameCss: '#carbon-deluxe-data-table-0-top-header-estimated-cost-col-10',
	currencyColumnNameCss: '#carbon-deluxe-data-table-0-top-header-currency-col-11',
	applicationColumnNameCss: '#carbon-deluxe-data-table-0-top-header-application-col-12',
	environmentColumnNameCss: '#carbon-deluxe-data-table-0-top-header-environment-col-13',
	viewingColumnRightArrowCss: '#carbon-deluxe-data-table-0-table-scroller__right',

	instanceNameColumnXpath: '//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][1]',
	statusColumnXpath: '//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][2]',
	provisionedDateColumnXpath: '//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][3]',
	providerColumnXpath: '//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][4]',
	providerAccountColumnXpath: '//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][5]',
	teamColumnXpath: '//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][6]',
	orderedByColumnXpath: '//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][7]',
	serviceNameColumnXpath: '//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][8]',
	estimatedCostColumnXpath: '//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][9]',
	currencyColumnXpath: '//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][10]',
	connectVMInstructionXpath: '(//*[@class="bx--modal-header__heading"])',
	addRecordsetTableActionIconCss: 'table#_subId0>tbody>tr:last-of-type>td:last-of-type',

	//***********LOCATORS FOR SEARCH***********

	searchIconCss: '#bx--tool-bar--search-icon',
	searchTextBoxCss: '#data-table-search__input',

	// Locators for Instance Table
	instanceTableActionIconCss: '.bx--table-overflow',
	instanceTableFirstDeleteButtonCss: '#carbon-deluxe-data-table-0-parent-row-1-option-3-button',
	addRecordSetText: 'Add Record Set',

	//***********LOCATORS FOR Available Version***********
	buttonTextAvailableVersion: 'Available Versions',
	changeavailableversionToUpgradeCss: 'div:nth-child(1) > carbon-radio-button > label > span.bx--checkbox-main-label',
	changeavailableversionToDowngradeCss: 'div:nth-child(2) > carbon-radio-button > label > span.bx--checkbox-main-label',

	//***********LOCATORS FOR Edit Service***********
	buttonTextEditService: 'Edit Service',
	editServiceNextButtonCss: '#next-button-mainParams',
	editServiceNextButtonAdditionalParamsCss: '#next-button-additionalParams',
	editCancelButtonCss: '#button-cancel-button-mainParams',

	editCPUDropDownCss: '#bx--dropdown-single-parent_1',
	editCPUDropDownValue2Css: '#dropdown-option_1_2',
	editServiceBillOfMaterialsCss: '#non-one-time-charge',
	editCPUInputCss: '#text-input-1',
	editMoreLinkCss: '.review-order_more-link>a',
	editCurrentBOMButtonCss: '#current_bom',
	editUpdatedBOMButtonCss: '#updated_bom',
	editstrikedCPUTextCss: '.strike',
	editupdatedTagTextCss: '.tag>span',
	editCurrentCPUTextCss: '.two-columns.m-padding>li>span>span',
	editSubmitOrderButtonCss: '#quickPurchaseSubmit-button-reviewOrder',
	editOrderNumberCss: '#order-number',
	editGoToInventoryButtonCss: '#button-order-submitted-editmodal_carbon-button',
	editInProgressStatusTextXpath: './/*[@id="carbon-deluxe-data-table-3"]/tbody/tr/td[4]/div/div[1]/div',
	InvalidEditMessageCss: '#operation-body-msg',
	invalidEditPopUpOKButtonCss:'#operation-modal-btn',
	//****LOCATORS FOR Delete Service****
	deleteserviceCss: '#carbon-deluxe-data-table-0-parent-row-1-option-3-button',
	deleteservicecheckboxCss: '.bx--checkbox-label',
	deleteserviceOkayCss: '#inventory-listing_action-modal_carbon-button_ok',
	deleteserviceCancelCss: '#inventory-listing_action-modal_carbon-button_cancel',
	//deleteOrderNumberFromPopUpTextCss:		'#invemtory-listing_carbon-notification_delete-service-order-number',
	deleteOrderNumberFromPopUpTextCss: '#inventory-listing_carbon-notification_delete-service-import-id',
	buttonTextDeleteService: 'Delete Service',
	buttonTextAddRecordSet: 'Add Record Set',
	
	//locator to support Globalization
	deleteServiceInventoryCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-option-3-button',

	//**** Locators for Delete Service Modal****

	deleteServiceModalOKButtonCss: '#inventory-listing_action-modal_carbon-button_ok',
	deleteServiceModalCancelButtonCss: '#inventory-listing_action-modal_carbon-button_cancel',
	deleteServiceModalCloseXButtonCss: '#close-btn_action-modal',
	deleteServiceModalConfirmCheckBoxCss: '#inventory-listing_action-modal_ConfirmDeleteServiceChecked_input ~ .bx--checkbox-label',
	closedDeleteServiceModalCss: '#close-icon_action-modal',
	deleteServiceModalNotificationBoxCss: '.bx--modal-container',
	deleteServiceModalNotificationBoxCloseCss: '#close-btn_action-modal',
	deleteServiceModalNotificationBoxTextCss: '.bx--modal-content>div>div',
	deleteOrderSubmittedModalOrderDateTextCss: '.bx--modal-content>div>div',
	deleteOrderSubmittedModalOrderNumberTextCss: '.bx--modal-content>div>div',
	noDataAvailablePresentTextCss: 'tr.bx--table-row.bx--table-row-empty--default',

	//***********LOCATORS FOR Inventory table***********
	inventoryTopHeaderTextCss: '#top-header-inventory_service-inventory',
	inventoryTableCheckboxListCss: '.bx--checkbox-appearance',
	clickBOMButtonCss : '[data-tab-id = "bill_of_materials"]',
	clickActionIconCss: '.bx--overflow-menu__icon',

	//***********LOCATORS FOR IMPORT BUTTON***********

	importIconCss: '#button-importFile',
	uploadFileIconXpath: '(//*[@class="bx--file-btn bx--btn bx--btn--secondary"])',

	//***********LOCATORS FOR Viewing Columns***********
	viewingColumnsRightArrowCss: '#carbon-deluxe-data-table-0-table-scroller__right',
	viewingColumnsLeftArrowCss: '#carbon-deluxe-data-table-0-table-scroller__left',

	paginationRightArrowCss: '#bx--pagination__forward-button-0',
	paginationLeftArrowCss: '#bx--pagination__back-button-0',
	noDataAvailableTextCss: '.bx--table-row-placeholder__background-fill>h4>strong',
	itemsPerPageTextCss: '.bx--pagination__text > span',
	firstrowAccordianXpath: '(//*[@class="bx--responsive-table"]/tbody/tr[1]/td[1])',
	viewingColumnScrollArrowsDisabledXpath: '(//*[@class="bx--table-scroll bx--table-scroll--disabled"])',
	menuIconXpath: '(//*[@class="bx--overflow-menu__icon"])[3]',
	closeViewButton: '[class="is-active"] button.bx--slide-over-panel--close',
	//***********LOCATORS FOR View Service***********	
	selectedSOIGlificonCss: '.bx--table-overflow',
	//viewServiceCss:								'.bx--overflow-menu-options__option',
	viewServiceButtonText: 'View Details',
	serviceNameOfSelectedSOICss: '[class^=bx--module__title]',
	soiNameOnInventoryCss: '.bx--slide-over-panel-title',
	providerServiceInstanceIdXpath: '//*[@id="left"]/p[2]',
	sliderCloseIconCss: '.bx--slide-over-panel--close > carbon-icon > svg',
	addRecordsetOverflowMenuIconXpath: '(//*[@class="bx--overflow-menu__icon"])',
	addRecordSetXpath: 'Add Record Set',
	soiNameCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe > tbody > tr > td:nth-child(3)',


	//***********LOCATORS FOR SERVICE ID ***********
	//Duplicate declaration from above lines 64 and 65.
	//searchIconCss:        				'#bx--tool-bar--search-icon',
	//searchTextBoxCss:					'.bx--search-input',
	GlificonIconXpath: '(//*[@class="bx--overflow-menu__icon"])[2]',
	//     viewserviceXpath:						'(//*[@class="bx--overflow-menu-options__btn"])[1]',
	viewserviceXpath: './/*[@id="carbon-deluxe-data-table-0-parent-row-1-option-1-button"]',
	orderhistoryCss: 'button[data-tab-id="order_history"]',
	viewServiceCloseCss: '.bx--slide-over-panel--close carbon-icon',
	refreshserviceXpath: './/*[@id="carbon-deluxe-data-table-0-parent-row-1-option-3-button"]',
	refreshserviceOkayCss: '#button-inventory-listing_action-modal_carbon-button_ok',

	editserviceCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-option-2-button',
	turnOffserviceOkayCss: '#inventory-listing_action-modal_carbon-button_ok',
	turnOnserviceOkayCss: '#inventory-listing_action-modal_carbon-button_ok',
	rebootserviceOkayCss: '#inventory-listing_action-modal_carbon-button_ok',
	refreshStatusOkayCss: '#button-inventory-listing_action-modal_carbon-button_ok',
	clickOptionsMenuXpath: '//*[@id="carbon-deluxe-data-table-0-parent-row-1-child-row-2-overflow-menu-icon"]',
	machineNameValueXpath: '//*[(@class="bx--text-input") and (@type="Machine Name")]',

	refreshStatusDialogConfirmTextXpath: './/*[@id="inventory-listing_action-modal"]/div/div/div[2]/div/div',
	soiStatusXpath: './/*[@id="carbon-deluxe-data-table-0"]/tbody/tr/td[4]/div/div[2]',
	refreshStatusOkXpath: './/*[@id="button-inventory-listing_action-modal_carbon-button_ok"]',
	viewComponentSliderCloseButtonCss: '.bx--slide-over-panel-header >carbon-icon > svg',
	socStatusFirstXpath: './/*[@id="_subId0"]/tbody/tr[1]/td[5]/div/div[2]',
	socStatusSecondXpath: './/*[@id="_subId0"]/tbody/tr[2]/td[5]/div/div[2]',

	//***********LOCATORS FOR ASSET ID ***********

	expandIconXpath: '(//*[@class="bx--table-expand__svg"])',

	//***********LOCATORS FOR MENUS OPTIONS ***********

	refreshStatusXpath: '(//*[@class="bx--overflow-menu-options__btn"])[2]',
	batchActionsMenuGlifficonXpath: '(//*[@class="bx--overflow-menu"])[1]',
	SOIcheckboxXpath: './/*[@id="carbon-deluxe-data-table-0"]/tbody/tr[1]/td[2]/carbon-checkbox/div/label/span',
	batchActionsMenuDeleteSelectedXpath: '(//*[@class="bx--overflow-menu-options__btn"])[1]',
	batchActionsMenuRefreshStatusesXpath: '(//*[@class="bx--overflow-menu-options__btn"])[2]',
	batchActionsMenuSOCTurnOnXpath: '(//*[@class="bx--overflow-menu-options__btn"])[1]',
	batchActionsMenuSOCTurnOffXpath: '(//*[@class="bx--overflow-menu-options__btn"])[1]',
	batchActionsMenuSOCRebootXpath: '(//*[@class="bx--overflow-menu-options__btn"])[1]',
	batchActionsMenuSOCRefreshXpath: '(//*[@class="bx--overflow-menu-options__btn"])[1]',
	turnOnActionMenuOptionXpath: '(//*[@class="bx--overflow-menu-options__btn"])[4]',
	turnOffActionMenuOptionXpath: '(//*[@class="bx--overflow-menu-options__btn"])[5]',
	RebootActionMenuOptionXpath: '(//*[@class="bx--overflow-menu-options__btn"])[6]',
	refreshStatusActionMenuOptionXpath: '(//*[@class="bx--overflow-menu-options__btn"])[7]',
	viewComponentActionMenuOptionXpath: '(//*[@class="bx--overflow-menu-options__btn"])[8]',
	accessComponentActionMenuOptionXpath: '(//*[@class="bx--overflow-menu-options__btn"])[9]',
	turnOnActionMenuOptionCss: '#carbon-deluxe-data-table-0-parent-row-1-child-row-1-option-1-button',
	turnOffActionMenuOptionCss: '#carbon-deluxe-data-table-0-parent-row-1-child-row-1-option-2-button',

	RebootActionMenuFirstOptionCss: '#carbon-deluxe-data-table-0-parent-row-1-child-row-1-option-6-button',
	RebootActionMenuSecondOptionCss: '#carbon-deluxe-data-table-0-parent-row-1-child-row-2-option-6-button',
	turnOffActionMenuFirstOptionCss: '#carbon-deluxe-data-table-0-parent-row-1-child-row-1-option-5-button',
	turnOffActionMenuSecondOptionCss: '#carbon-deluxe-data-table-0-parent-row-1-child-row-2-option-5-button',
	turnOnActionMenuFirstOptionCss: '#carbon-deluxe-data-table-0-parent-row-1-child-row-1-option-4-button',
	turnOnActionMenuSecondOptionCss: '#carbon-deluxe-data-table-0-parent-row-1-child-row-2-option-4-button',
	refreshStatusActionMenuOptionCss: '#carbon-deluxe-data-table-0-parent-row-1-child-row-1-option-1-button',
	viewComponentActionMenuOptionCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-1-option-3-button',
	accessComponentActionMenuOptionCss: '#carbon-deluxe-data-table-0-parent-row-1-child-row-1-option-2-button',

	expandServiceDetailsCss: '#serviceDetails',
	expandServiceConfigurationCss: "#serviceConfigurations",
	checkExpandServiceConfigurationCss: "#serviceConfigurations div[tabindex='-1']",
	expandFirstRowXpath: '(//*[@class="bx--table-expand__svg"])[1]',
	GlificonIconOfSOCXpath: '//*[@id="carbon-deluxe-data-table-0"]/tbody/tr[3]/td[8]/carbon-overflow-menu/div',
	ViewComponentCloseButtonXpath: '//carbon-slide-over-panel[2]/div/header/carbon-button/button',
	sOCFirstChildComponentXpath: '//*[@id="carbon-deluxe-data-table-0"]/tbody/tr[3]/td[2]/carbon-checkbox/div/label/span',
	sOCSecondChildComponentXpath: '//*[@id="carbon-deluxe-data-table-0"]/tbody/tr[4]/td[2]/carbon-checkbox/div/label/span',
	//powerStateOverflowMenuIconXpath:       '(//*[@class="bx--overflow-menu__icon"])[3]',
	powerStateOverflowMenuIconXpath: '//button[@class="bx--overflow-icon__wrapper"]',
	buttonTextTurnON: 'Turn ON',
	turnONInstanceOkButtonCss: '#inventory-listing_action-modal_carbon-button_ok',
	buttonTextTurnOFF: 'Turn OFF',
	turnOFFInstanceOkButtonCss: '#inventory-listing_action-modal_carbon-button_ok',
	buttonTextReboot: 'Reboot',
	rebootInstanceOkButtonCss: '#inventory-listing_action-modal_carbon-button_ok',
	buttonCustomOpnOrderOkCss: '#order-submitted-modal_carbon-button, #soi-order-submitted-modal_carbon-button',
	textCustomOpsWarningPopupCss: '#operation-body-msg',
	buttonCustomOpsWarningOKCss: '#operation-modal-btn',
	statusInstancePowerStateXpath: '(//*[@class="bx--table-column" and ../@class="bx--table-row bx--parent-row bx--table-row--sub-row bx--parent-row--even"])[3]',
	//buttonTextViewComponent: 'View Component',
	buttonXpathViewComponent: '//button[contains(text(), "View Component")]',
	buttonTurnOffCss: ".bx--overflow-menu__group carbon-overflow-menu-item:nth-child(4) button",
	buttonTurnOnCss: ".bx--overflow-menu__group carbon-overflow-menu-item:nth-child(5) button",
    buttonRebootCss: ".bx--overflow-menu__group carbon-overflow-menu-item:nth-child(6) button",
    buttonDeleteIcdVMCss: ".bx--overflow-menu-options__option button",
    buttonCancelStdOperationsCss: "#inventory-listing_action-modal_carbon-button_cancel",
    orderSubmittedModalOrderNumberTextCss: "#order-submitted-number",
	
    //***********LOCATORS FOR View Components ***********

	componentTypePropXpath: '//*[@id="left"]/p[1]',
	namePropXpath: '//*[@id="left"]/p[2]',
	statusPropXpath: '//*[@id="left"]/p[3]',
	providerNamePropXpath: '//*[@id="left"]/p[4]',
	resourceIdPropXpath: '//*[@id="left"]/p[5]',
	tagsPropXpath: '//*[@id="left"]/p[6]',
	availabilityZonePropXpath: '(.//*[@id="Template"])[1]',
	availableIpAddressCountPropXpath: '(.//*[@id="Template"])[2]',
	cidrBlockPropXpath: '(.//*[@id="Template"])[3]',
	defaultForAzPropXpath: '(.//*[@id="Template"])[4]',
	mapPublicIpOnLaunchPropXpath: '(.//*[@id="Template"])[5]',
	statePropXpath: '(.//*[@id="Template"])[6]',
	subnetIdPropXpath: '(.//*[@id="Template"])[7]',
	vpcIdPropXpath: '(.//*[@id="Template"])[8]',
	assignIpv6aAddressOnCreationPropXpath: '(.//*[@id="Template"])[1]',
	ipv6CidrBlockAssociationSetPropXpath: '(.//*[@id="Template"])[1]',
	deleteServiceInfoTooltipCss: '#inventory-listing_carbon-notification',
	deleteOrderNumberCss: '#inventory-listing_carbon-notification_delete-service-import-id',
	serviceInstanceNameXpath: './/*[@id="left"]/p[3]',
	cpuConfigXpath: './/*[@id="service_configurations_1_value"]',
	//deleteServiceInfoTooltipXpath:			'//*[@class="bx--toast-notification bx--toast-notification--success bx--toast-notification-show"]',
	deleteServiceInfoTooltipXpath: '//*[@class=" bx--toast-notification bx--toast-notification--success "]',
	//deleteOrderNumberXpath:					'//*[@class="bx--toast-notification bx--toast-notification--success bx--toast-notification-show"]//p[@id="inventory-listing_carbon-notification_delete-service-import-id"]',
	deleteOrderNumberXpath: '//*[@class="bx--toast-notification__subtitle"]/span',
	componentNameCss: '#Name',
	componentNameId: "service-details__service-name",
	fullTypeOutputParamCss: '#service-details__service-name.bx--about__title--name',
	//*****************LOCATORS FOR ORDER HISTORY COLUMNS**************
	orderIdColumnNameXpath: '(//*[@class="bx--table-header bx--table-sort"])[1]',
	operationTypeColumnNameXpath: '(//*[@class="bx--table-header bx--table-sort"])[2]',
	statusColumnNameXpath: '(//*[@class="bx--table-header bx--table-sort"])[3]',
	requestedByColumnNameXpath: '(//*[@class="bx--table-header bx--table-sort"])[4]',
	estimatedcostcurrencyColumnNameXpath: '(//*[@class="bx--table-header bx--table-sort"])[5]',
	errorFailureColumnNameXpath: '(//*[@class="bx--table-header bx--table-sort"])[6]',
	selectInputXpath: '(//*[@class="bx--select-input"])',
	estimatedCostCss: '#total_cost_value',
	estimatedCostOrderHistoryCss: 'td.table-row-estimatedCostCurrency-column',
	newOrderIdCss: 'td.table-row-id-column',
	newOperationTypeCss: 'td.table-row-orderTypeUI-column',
	//*****************LOCATORS FOR SERVICE LOGS**************
	logMessageCss: '.no-logs',
	serviceLogsCss: 'button[data-tab-id="service_logs"]',
	serviceLogTextCss:".service-display-log",
	serviceLogsTACss:'#tab-control-service',
	resourceLogsCss:"#tab-control-activity",
	//********************d2ops bvt************************************
	textTableElementsXpath: '(//tr[@class="bx--table-row bx--parent-row bx--table-row--sub-row"]/td)',
	socFirstChildGlificonXpath: '(//*[@class="bx--overflow-menu__icon"])[3]',
	socSecondChildGlificonXpath: '(//*[@class="bx--overflow-menu__icon"])[4]',
	glifIconXpath: '(//*[@class="bx--overflow-menu__icon"])',
	textServiceInstanceNameCss: "[class='bx--table-row bx--parent-row bx--table-row--sub-row'] td:nth-child(3)",
	textComponentTypeCss: "[class='bx--table-row bx--parent-row bx--table-row--sub-row'] td:nth-child(4)",
	textVMStatusCss: "[class='bx--table-row bx--parent-row bx--table-row--sub-row'] td:nth-child(5)",
	textResourceStatusRowOneXpath: '(//tr[@class="bx--table-row bx--parent-row bx--table-row--sub-row"]/td)[5]',
	textResourceStatusRowTwoXpath: '(//tr[@class="bx--table-row bx--parent-row bx--table-row--sub-row"]/td)[12]',
	textCustomOpsPriceVRACss: '.rightAside p',

	//******************User menu********************
	userIconCss: '.bx--cloud-header-list__btn.bx--toolbar__menu__icon',
	accountsMenuItemCss: '#accountsSubMenuButton',
	
	//****************Azure VM Operation Locators**********************

	azurePowerStateOverflowMenuIconXpath: '//*[@id="carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-7-overflow-menu-icon"]',
	azTurnOFFCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-7-option-7',
	azTurnONCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-7-option-6',
	azRebootCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-7-option-5',
	azTurnOFFDummyCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-1-option-6-button',
	azTurnONDummyCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-1-option-7-button',
	azRebootDummyCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-1-option-5-button',
	azVMStatus: '//*[@id="_subId0"]/tbody/tr[7]/td[5]/div/div',
	textNextButtonCss: '[id=\"next-button-mainParams\"]',
	outputParamsXpath: '//*[@class="two-columns m-padding"]//li//span',
	//TagCss: '.bx--tag.bx--tag-new.bx--tag--beta',
	TagCss: '.ml-padding:nth-child(3) div',
	linkServiceDetailsLabelsXpath: '//*[contains(text(),"abels")]/..//a',
	txtSystemTagValueFieldXpath: '//h5[contains(text(),"Ibm_mcmp_soiid") or contains(text(),"ibm_mcmp_soiid")]',
	txtSystemTagLabelXpath: '//*[contains(text(),"Ibm_mcmp_soiid")]/../p',
	azTurnOFFSNOWCss: "#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-7-option-5-button",
	azTurnONSNOWCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-7-option-4-button',
	azRebootSNOWCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-7-option-6-button',

	//***********************Alibaba VM operatios locators*********************

	alibabaPowerStateOverFlowMenuIconXpath: '//*[@id="carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-1-overflow-menu-icon"]',
	
	// *******************ICAM VM Operation Locaters **************** 

	icamTurnOFFCss: "#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-6-option-6 > li > button", 
	icamTurnONCss:  "#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-6-option-5 > li > button",
	icamShutdownXpath: '//table//span[text()=" Virtual Machine "]//ancestor::td[1]//following-sibling::td[4]//span[contains(text(),"Shutdown")]',
	icamTaintXpath: '//table//span[text()=" Virtual Machine "]//ancestor::td[1]//following-sibling::td[4]//span[contains(text(),"Taint")]',
	icamUntaintXpath: '//table//span[text()=" Virtual Machine "]//ancestor::td[1]//following-sibling::td[4]//span[contains(text(),"Untaint")]',
	icamAzureTaintCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-2-option-7',
	icamAzureUntaintCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-2-option-8',
	outputParamsXpathIcam:'//*[@class="bx--col-sm-2 output-attributes-value-container"]//h5',
	outputParamsXpathValueIcam:'//*[@class="bx--col-sm-2 output-attributes-value-container"]//div',
	clickForwardButton:'(.//*[@aria-label="next page"])[1]',
	icamAzureVmUntaintXpath:"//table//span[text()=' Virtual Machine ']//ancestor::td[1]//following-sibling::td[4]//button[contains(text(),' Untaint ')]",
	TextOfToastMessageIcam:'//*[@id="operation-body-msg"]',
	icamGCPAccessCompCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-1-option-2-button',
	icamConnectVmOkCss: '#instructions-btn',
	connectVmTextCss: '#instructions-para-txt',
	icamUDTaintCss: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-6-option-7',
	//**********Locators for Left pane filters in Inventory***********
	
	filterChevronRightCss:".bx--link.bom-toggle.filter-chevron-right",
	deletedCheckboxCss:"[for='checkbox-Deleted-checkbox-header']",
	applyFilterLabelCss:".apply-filter-label",
	clearAllFilterCss:".bx--link.right",
	serviceNameToolTipTextCss:"#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe > tbody > tr > td:nth-child(3) > div > div > span",
	appliedFilterStatusTextCss:".bx--tag.bx--data-table-filter",
	
	
	//IMI locators	
	btnRightArrowCss:'carbon-icon[name="caret--right"]',
	btnViewAddOnCss:'#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-sub-option-1-button',
	btnBillOfMaterailsCss:'[data-tab-id="bill_of_materials"]',
	lnkMoreCss:'div.bx--link',
	txtEstimtdCostCss:'div#total_cost_value',
	lnkConfigureImiXpath:'//*[contains(text(),"Configure IMI Managed Service")]',
	btnOkConfigureImiCss:'#inventory-listing_action-modal_carbon-button_ok',
	//txtUpdateCostImiXpath:'//*[contains(text(),"Updated Cost")]/../h3/p',
	txtUpdateCostImiXpath:'//*[contains(text(),"Total Monthly Cost*")]/../following-sibling::span/strong',
	btnCurntBomCss:'#current_bom',
	storeHeaderCss: '.bx--header__name',
	buttonLeftNavSubMenu: '.bx--side-nav__submenu',
	buttonLeftSubmenuCss: '.bx--side-nav__submenu-title',
	buttonLeftSubmenuExpandXpath: '//*[@class="bx--side-nav__submenu-title"]/parent::button',
	tblServiceInstanceCompCss: '#_subId0 tbody tr',
	txtDeleteRecordSet : 'Delete Record Set',
	txtAttachNetworkIntface:'Attach Network Interface',
	txtDetachNetworkIntface:'Detach Network Interface',
	viewDetailsNtwrkIntfc : '//h5[text()=" NetworkInterfaces "]/../div/a',
	viewDetailsAttchmnt : '//*[contains(text(),"test")]/../preceding-sibling::td/div/a',
	lnkKeyNameCss : 'a.bx--link',
	btnDownldFileXpath : '//button[text() = " Download File "]',
	txtNotifcnCss : ".bx--toast-notification__details",
	btnCloseNotifcnCss : ".bx--toast-notification__close-button",
	btnAcessComponentXpath: '//button[contains(text(), "Access Component")]',
	filePathCss : 'input[type="file"]',
	txtDecryptBtn : 'Decrypt Password',
	txtPwdCss: '#password',
	btnClosePwdPopUpCss :'#close-btn_decrypt-password-modal-success',
	txtComponentTypeXpath : '//*[@id="_subId0"]//td[4]//span',
	//btnBillOfMaterialsCss: '#bill_of_materials',
	btnBillOfMaterialsCss: '[data-tab-id="bill_of_materials"]',
	newOrderStatus: 'td.table-row-orderstatus-column',
	langugeCss:	'#language option',
	txtMngmntLvlCss:'#service_configurations_tag_management_level_value',
	loadingDetailsXpath: '//h3[contains(text(), "Loading...")]',

	/************************ Locators for Transfer Service in Invnetory **********************/

	searchTeamTextBoxCss: '#bx--dropdown-single-parent_transfer-service-dropdown-id',
	searchTeamTextBoxInputCss:'#text-input-transfer-service-dropdown-id',
	transferServiceButtonText:'Transfer Service',
	transferButtonText:'Transfer',
	changeOwnerButtonText:'Change Owner',
	acceptTransferButtonText:'Accept',
	denyTransferButtonText:'Deny',
	cancelTransferButtontext:'Cancel',
	resendTransferButtonText:'Resend',
	viewReasonButtonText:'View Reason',
	confirmTransferCss: '#transfer-service-modal-btn-transfer',
	transfersTabCss:'#tab-control-transfers_tab',
	pendingTransfersCss:'[data-tab-id="pending_transfers"]',
	completedTransfersCss:'[data-tab-id="completed_transfers"]',
	transferAcceptButtonCss:'#transfer-accept-button',
	notificationPopupMessageCss:'p.bx--toast-notification__subtitle > span',
	transferDenyReasonTextBoxCss:'#text-areatransfer-denial-reason',
	transferDenyButtonCss: '#transfer_deny_Okay',
	transferCancelButtonCss: '#pending-transfer-cancel-modal_btn-canceltransfer',
	selectFirstServiceCheckBoxCss: 'label[for="checkbox-carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-checkbox"]',
	confirmChangeOwnerCss: '#change_owner',
	changeOwnerTextBoxCss:'#text-input_ownerTransferControlName',
	transferorNameCss:'td.bx--table-column:nth-child(5)',
	transfereeNameCss:'td.bx--table-column:nth-child(6)',
	transferStatusCss:'td.bx--table-column:nth-child(7)',
	rightArrowCss: '#carbon-deluxe-data-table-service-transfers-completed-table-id-table-scroller__right',
	allServicesTabCss: '#tab-control-all_Services_tab',
	denyTextReasonCss:'div.bx--modal.is-visible  div.bx--modal-content>div',
	denyReasonModalOKButtonCss:'#transfer_deny_cancel',
	transferResendButtonCss:'#pending-transfer-resend-modal_btn-resendtransfer',
	fetchOrderDetailCss:'a.btn-fetch-order',
	orderSubmittedModalHeaderXpath : '//*[contains(text(),"Order Submitted")]',
	placeOrderCss:'[id*="carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-"] [tabIndex = "0"]',
	fetchOrderLnkClass:'btn-fetch-order',
	ServiceInstanceNameCss:"h3.bx--slide-over-panel-title",
	ExportLinkCss:"#export-button",
	RefreshLinkCss:"#refresh-button",
	serviceLogTextCss:".service-display-log",
	resourceLogsTACss:"#tab-control-activity",
	serviceLogsTACss:'#tab-control-service',
	buttonTextViewDetailsText:'View Details',
	orderNoCss:'#order-number',
	orderNocssnew: '#order-submitted-number',
	submittedOrderNoCss: '#order-submitted-number',
	chkBoxConfirmDeleteId : 'inventory-listing_action-modal_ConfirmDeleteServiceChecked_input',

	overFlowButtonForSpecificComponentTypeXpath: "//*[contains(text(),'{0}')]//ancestor::td[1]//following-sibling::td[contains(@class,'bx--table-overflow')]//button",
	overFlowButtonForVMStatusXpath: "//*[contains(text(),'{0}')]//ancestor::td[1]//following-sibling::td[1]//span[contains(text(),'{1}')]//ancestor::td[1]//following-sibling::td[contains(@class,'bx--table-overflow')]//button",
	turnOffActionButtonForSpecificComponentTypeXpath: "//*[contains(text(),'{0}')]//ancestor::td[1]//following-sibling::td[contains(@class,'bx--table-overflow')]//button//ancestor::td[1]//*[contains(text(),'Turn OFF')]//parent::button",
	turnOnActionButtonForSpecificComponentTypeXpath: "//*[contains(text(),'{0}')]//ancestor::td[1]//following-sibling::td[contains(@class,'bx--table-overflow')]//button//ancestor::td[1]//*[contains(text(),'Turn ON')]//parent::button",
	rebootActionButtonForSpecificComponentTypeXpath: "//*[contains(text(),'{0}')]//ancestor::td[1]//following-sibling::td[contains(@class,'bx--table-overflow')]//button//ancestor::td[1]//*[contains(text(),'Reboot')]//parent::button",
	viewCompnentButtonForSpecificComponentTypeXpath: "//*[contains(text(),'{0}')]//ancestor::td[1]//following-sibling::td[contains(@class,'bx--table-overflow')]//button//ancestor::td[1]//*[contains(text(),'View Component')]//parent::button"
}

function inventory(selectorConfig) {
	if (!(this instanceof inventory)) {
		return new inventory(selectorConfig);
	}
	extend(this, defaultConfig);

	if (selectorConfig) {
		extend(this, selectorConfig);
	}
}

inventory.prototype.open = function () {
	/*//browser.ignoreSynchronization = true;
	await util.getUrl(this.pageUrl);
	browser.wait(EC.urlContains("/consume/inventory"), 90000).then( function(){
		logger.info("Navigated to inventory page");
	});
	browser.wait(EC.visibilityOf(element(by.css(this.storeHeaderCss))),90000);
  	browser.switchTo().frame(element(by.tagName('iframe')).getWebElement());
  	//browser.ignoreSynchronization = false;
    util.waitForAngular();*/

	var catalogPage = new CatalogPage();
	//browser.ignoreSynchronization = true;
	util.switchToDefault();
	catalogPage.clickHamburgerCatalog();
	catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
	catalogPage.checkIfleftNavStoreExpanded();
	catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkInventory);
	util.switchToFrame();
    util.waitForAngular();
    browser.wait(EC.elementToBeClickable(element(by.css(this.searchTextBoxCss))), 90000).then(function () {
		logger.info("Search textbox is visible");
	}).catch(function (err) {
			browser.sleep(30000);
			logger.info("Exception occured as No Such Window");
	});
};

//************************ Functions for Filters ******************* //

inventory.prototype.clickFilterIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.filtersIconXpath))), 5000);
	return element(by.xpath(this.filtersIconXpath)).click();
};

//This function is used to get the index of filter checkbox label based on passed filter name
inventory.prototype.getIndexofFilter = function (filterName) {
	browser.wait(EC.visibilityOf(element(by.css(this.filterCheckBoxesLabelCss))), 5000);
	return element.all(by.css(this.filterCheckBoxesLabelCss)).getText().then(function (arr) {
		for (var i = 0; i < arr.length; i++)
			if (arr[i] == filterName)
				return i;
	})
};

//This function is used to get click the status or providers checkbox label under Filters based on the passed filter name
inventory.prototype.clickFilterCheckBoxLabelBasedOnName = function (filterName) {
	var current = this;
	return this.getIndexofFilter(filterName).then(function (index) {
		var elem = element.all(by.css(current.filterCheckBoxesLabelCss)).get(index);
		browser.wait(EC.elementToBeClickable(elem), 5000);
		return elem.click();
	})
};

//This function is used to check if the status or providers checkbox under Filters are checked or not based on the passed filter name
inventory.prototype.isSelectedFilterCheckBoxBasedOnName = function (filterName) {
	var current = this;
	return this.getIndexofFilter(filterName).then(function (index) {
		var elem = element.all(by.css(current.filterCheckBoxesCss)).get(index);
		browser.wait(EC.elementToBeClickable(elem), 5000);
		return elem.isSelected().then(function (selected) {
			return selected
		})
	});
}

inventory.prototype.verifyFiltersApplied = function (searchText, filterBy) {
	var isFilterApplied = false;
	flag = false;
	var elementList;

	//Check for no data availability in table
	element(by.xpath(this.filtersNoDataTextXpath)).isPresent().then(function (present) {
		if (present) {
			logger.info('Filter test : ' + searchText + '\n Inventory records is not available in table. Please manually verify once. For now passing the test \n')
			flag = true;
			return flag;
		} else logger.info('Filter test : ' + searchText + '\n Inventory records is available in table. Proceeding to verification of filters \n');
	});

	//Get 'filterBy' column in table and check to see filters are applied as selected
	if (searchText.length > 0) {
		if (filterBy == "status")
			elementList = element.all(by.xpath("(.//*[@class='bx--responsive-table']/tbody/tr[contains(@class, 'bx--table-row')]/td[contains(@class, 'bx--table-column')][2]/div/div[contains(@class, 'bx--table-cell--truncate')])"));
		else if (filterBy == "provider")
			elementList = element.all(by.xpath("(.//*[@class='bx--responsive-table']/tbody/tr[contains(@class, 'bx--table-row')]/td[contains(@class, 'bx--table-column')][4]/div/div[contains(@class, 'bx--table-cell--truncate')])"));

		var rows = elementList.map(function (eachName) {
			return eachName.getText();
		});
		//Concatenate each row contents and check if search string is present on each row. Even if search string not found in a single row, the test will fail immediately and stops checking further rows
		isFilterApplied = rows.then(function (result) {
			for (var i = 0; i < result.length; i++) {
				flag = false;
				//logger.info("result[i]");
				//For each row verify if searchText is present in that row
				for (var j = 0; j < searchText.length; j++) {
					if ((result[i]).indexOf(searchText[j]) >= 0) {
						flag = true;
						//logger.info("Found - \"" + searchText[j]+ "\" in row : " + result[i]);
						j = searchText.length;
					}
				}
				if (flag == false) {
					logger.info("None of the Filter search text matches for the Row text : " + result[i] + " - in row number : " + i);
					return flag;
				}
			}
			return flag;
		});
	} else isFilterApplied = true;

	return isFilterApplied;
};

inventory.prototype.checkFilterLabelBasedOnName = function (filterName) {
	var current = this;
	return this.getIndexofFilter(filterName).then(function (index) {
		var elem = element.all(by.css(current.filterCheckBoxesCss)).get(index);
		browser.wait(EC.elementToBeClickable(elem), 5000);
		return elem.isPresent().then(function (present) {
			return present
		})
	});
}

//This function is used to get complete list of providers in Filters
inventory.prototype.getListofFilterProviders = function () {
	return element.all(by.css(this.filterProviderNamesCss)).getText()

};


//************************ End of Functions for Filters *******************

//************************ Functions for Pagination ******************* //

inventory.prototype.countTableRecords = function () {
	var numberOfColumns = 13;
	util.waitForAngular();
	var elementList = element.all(by.xpath("(.//*[@class='bx--responsive-table']/tbody/tr[contains(@class, 'bx--table-row')]/td[contains(@class, 'bx--table-column')]/div/div[contains(@class, 'bx--table-cell--truncate')])"));
	var rows = elementList.map(function (eachName) {
		return eachName.getText();
	});
	//Count the number of rows in the table and return it
	return rows.then(function (result) {
		var count = 0;
		if (result.length == 0) return count;
		for (var i = 0; i < result.length; i = i + numberOfColumns) {
			count = count + 1;
			logger.info("The number of rows in table = " + count);
		}
		return count;
	});
};

//function used in search also
inventory.prototype.getNumberOfPagesText = function () {
	return element.all(by.css(this.numberOfPagesTextCss)).last().getText();
};
//function used in search also
inventory.prototype.clickPaginationRightArrow = function (pages) {
	for (var i = 0; i < 4; i++) element(by.xpath(this.paginationRightArrowXpath)).click();
	util.waitForAngular();
};
inventory.prototype.clickPaginationLeftArrow = function (pages) {
	for (var i = 0; i < 4; i++) element(by.xpath(this.paginationLeftArrowXpath)).click();
	util.waitForAngular();
};
inventory.prototype.clickSelectItemPerPage = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.selectInputXpath))), 5000);
	return element(by.xpath(this.selectInputXpath)).click();
};
inventory.prototype.clickFirstRecordItemPerPage = function (item) {
	browser.wait(EC.elementToBeClickable(element(by.css(this.firstitemPerPageCss))), 5000);
	return element(by.css(this.firstitemPerPageCss)).click();
};

inventory.prototype.clickSecondRecordItemPerPage = function (item) {
	browser.wait(EC.elementToBeClickable(element(by.css(this.seconditemPerPageCss))), 5000);
	return element(by.css(this.seconditemPerPageCss)).click();
};
inventory.prototype.clickThirdRecordItemPerPage = function (item) {
	browser.wait(EC.elementToBeClickable(element(by.css(this.thirditemPerPageCss))), 5000);
	return element(by.css(this.thirditemPerPageCss)).click();
};

//************************ End of Functions for Pagination *******************

//************************ Functions for Sort ******************* //

//this function is used to click on Instance name to sort that column
inventory.prototype.clickInstanceName = function () {
	//	browser.wait(EC.elementToBeClickable(element(by.css(this.instanceNameColumnNameCss))), 5000);
	browser.sleep(5000);
	util.waitForAngular();
	return element(by.css(this.instanceNameColumnNameCss)).click();
}

//this function is used to click on Status to sort that column
inventory.prototype.clickStatus = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.statusCoulmnNameCss))), 5000);
	return element(by.css(this.statusCoulmnNameCss)).click();
}

//this function is used to click on Provisioned Date to sort that column
inventory.prototype.clickProvisionedDate = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.provisionedDateColumnNameCss))), 5000);
	return element(by.css(this.provisionedDateColumnNameCss)).click();
}

//this function is used to click on Provider to sort that column
inventory.prototype.clickProvider = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.providerColumnNameCss))), 5000);
	return element(by.css(this.providerColumnNameCss)).click();
}

//this function is used to click on Provider Account to sort that column
inventory.prototype.clickProviderAccount = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.providerAccountColumnNameCss))), 5000);
	return element(by.css(this.providerAccountColumnNameCss)).click();
}

//this function is used to click on Team to sort that column
inventory.prototype.clickTeam = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.teamColumnNameCss))), 5000);
	return element(by.css(this.teamColumnNameCss)).click();
}

//this function is used to click on Ordered By to sort that column
inventory.prototype.clickOrderedBy = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.orderedByColumnNameCss))), 5000);
	return element(by.css(this.orderedByColumnNameCss)).click();
}

//this function is used to click on Service Name to sort that column
inventory.prototype.clickServiceName = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.serviceNameColumnNameCss))), 5000);
	return element(by.css(this.serviceNameColumnNameCss)).click();
}

//this function is used to click on Estimated Cost to sort that column
inventory.prototype.clickEstimatedCost = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.estimatedCostColumnNameCss))), 5000);
	return element(by.css(this.estimatedCostColumnNameCss)).click();
}

//this function is used to click on Currency to sort that column
inventory.prototype.clickCurrency = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.currencyColumnNameCss))), 5000);
	return element(by.css(this.currencyColumnNameCss)).click();
}

//this function is used to check if Instance Name column is sorted
inventory.prototype.checkIfInstanceNameColumnIsSorted = function () {
	//var elementList = element.all(by.xpath(instanceNameColumnXpath));
	var elementList = element.all(by.xpath('//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][1]'))
	elementList.map(function (eachName) {
		return eachName.getText().then(function (unSorted) {
			return unSorted;
		});
	}).then(function (unSorted) {
		unSorted = unSorted.map(function (value) {

			return value.toLowerCase();
		});
		var sorted = unSorted.slice();
		sorted = sorted.sort();
		console.log("sorted");
		console.log(sorted)
		console.log("unsorted");
		console.log(unSorted)
		expect(sorted).toEqual(unSorted);
	});
}

//this function is used to check if Status column is sorted
inventory.prototype.checkIfStatusColumnIsSorted = function () {
	//var elementList = element.all(by.xpath(statusColumnXpath));
	var elementList = element.all(by.xpath('//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][2]'))
	elementList.map(function (eachName) {
		return eachName.getText().then(function (unSorted) {
			return unSorted;
		});
	}).then(function (unSorted) {
		var sorted = unSorted.slice();
		sorted = sorted.sort();
		expect(sorted).toEqual(unSorted);
	});
}

//this function is used to check if Provisioned Date column is sorted
inventory.prototype.checkIfProvisionedDateColumnIsSorted = function () {
	//var elementList = element.all(by.xpath(provisionedDateColumnXpath));
	var elementList = element.all(by.xpath('//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][3]'))
	elementList.map(function (eachName) {
		return eachName.getText().then(function (unSorted) {
			return unSorted;
		});
	}).then(function (unSorted) {
		var sorted = unSorted.slice();
		sorted = sorted.sort();
		expect(sorted).toEqual(unSorted);
	});
}

//this function is used to check if Provider column is sorted
inventory.prototype.checkIfProviderColumnIsSorted = function () {
	//var elementList = element.all(by.xpath(providerColumnXpath));
	var elementList = element.all(by.xpath('//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][4]'))
	elementList.map(function (eachName) {
		return eachName.getText().then(function (unSorted) {
			return unSorted;
		});
	}).then(function (unSorted) {
		var sorted = unSorted.slice();
		sorted = sorted.sort();
		expect(sorted).toEqual(unSorted);
	});
}

//this function is used to check if Provider Account column is sorted
inventory.prototype.checkIfProviderAccountColumnIsSorted = function () {
	//var elementList = element.all(by.xpath(providerAccountColumnXpath));
	var elementList = element.all(by.xpath('//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][5]'))
	elementList.map(function (eachName) {
		return eachName.getText().then(function (unSorted) {
			return unSorted;
		});
	}).then(function (unSorted) {
		var sorted = unSorted.slice();
		sorted = sorted.sort();
		expect(sorted).toEqual(unSorted);
	});
}

//this function is used to check if Team column is sorted
inventory.prototype.checkIfTeamColumnIsSorted = function () {
	//var elementList = element.all(by.xpath(teamColumnXpath));
	var elementList = element.all(by.xpath('//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][6]'))
	elementList.map(function (eachName) {
		return eachName.getText().then(function (unSorted) {
			return unSorted;
		});
	}).then(function (unSorted) {
		var sorted = unSorted.slice();
		sorted = sorted.sort();
		expect(sorted).toEqual(unSorted);
	});
}

//this function is used to check if Ordered By column is sorted
inventory.prototype.checkIfOrderedByColumnIsSorted = function () {
	//var elementList = element.all(by.xpath(orderedByColumnXpath));
	var elementList = element.all(by.xpath('//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][7]'))
	elementList.map(function (eachName) {
		return eachName.getText().then(function (unSorted) {
			return unSorted;
		});
	}).then(function (unSorted) {
		var sorted = unSorted.slice();
		sorted = sorted.sort();
		expect(sorted).toEqual(unSorted);
	});
}

//this function is used to check if Service Name column is sorted
inventory.prototype.checkIfServiceNameColumnIsSorted = function () {
	//var elementList = element.all(by.xpath(serviceNameColumnXpath));
	var elementList = element.all(by.xpath('//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][8]'))
	elementList.map(function (eachName) {
		return eachName.getText().then(function (unSorted) {
			return unSorted;
		});
	}).then(function (unSorted) {
		var sorted = unSorted.slice();
		sorted = sorted.sort();
		expect(sorted).toEqual(unSorted);
	});
}

//this function is used to check if Estimated Cost column is sorted
inventory.prototype.checkIfEstimatedCostColumnIsSorted = function () {
	//var elementList = element.all(by.xpath(estimatedCostColumnXpath));
	var elementList = element.all(by.xpath('//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][9]'))
	elementList.map(function (eachName) {
		return eachName.getText().then(function (unSorted) {
			return unSorted;
		});
	}).then(function (unSorted) {
		var sorted = unSorted.slice();
		sorted = sorted.sort();
		expect(sorted).toEqual(unSorted);
	});
}

// Click BOM tab in inventory's view Service.
inventory.prototype.clickBOMButton = function() {
	browser.wait(EC.elementToBeClickable(element(by.css(this.clickBOMButtonCss))), 90000);
	return element(by.css(this.clickBOMButtonCss)).click().then(function(){
		logger.info("Clicked on Bill Of Materials of Inventory Page");
	});
}

//this function is used to check if Currency column is sorted
inventory.prototype.checkIfCurrencyColumnIsSorted = function () {
	//var elementList = element.all(by.xpath(currencyColumnXpath));
	var elementList = element.all(by.xpath('//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][10]'))
	elementList.map(function (eachName) {
		return eachName.getText().then(function (unSorted) {
			return unSorted;
		});
	}).then(function (unSorted) {
		var sorted = unSorted.slice();
		sorted = sorted.sort();
		expect(sorted).toEqual(unSorted);
	});
}

inventory.prototype.clickViewingColumnRightArrow = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.viewingColumnRightArrowCss))), 5000);
	return element(by.css(this.viewingColumnRightArrowCss)).click();
}

//************************ End of Functions for Sort *******************

//************************ Functions for Search ******************* //

inventory.prototype.searchInTable = function (seachText) {
	element(by.css(this.searchTextBoxCss)).clear();
	element(by.css(this.searchTextBoxCss)).sendKeys(seachText);
	browser.actions().sendKeys(protractor.Key.ENTER).perform();
	//browser.sleep(5000);
};

inventory.prototype.verifySearchOnCurrentPage = function (searchText) {
	logger.info("Searching for text :" + searchText);
	var numberOfColumns = 13;
	var ro = [];
	util.waitForAngular();
	var elementList = element.all(by.xpath("(.//*[@class='bx--responsive-table']/tbody/tr[contains(@class, 'bx--table-row')]/td[contains(@class, 'bx--table-column')]/div/div[contains(@class, 'bx--table-cell--truncate')])"));
	var rows = elementList.map(function (eachName) {
		return eachName.getText();
	});

	//Concatenate each row contents and check if search string is present on each row of the initial columns displayed
	//Even if search string not found in a single row, the test will fail immediately and stops checking further rows
	var strFound = rows.then(function (result) {
		var row = "";
		var found = false;
		//logger.info(result);
		//console.log("result : " + result)
		for (var i = 0; i < result.length; i = i + numberOfColumns) {
			for (var j = i; j < i + numberOfColumns; j++) {
				row = row + result[j]
			}
			//logger.info(row);
			//console.log("row : " + row)
			//For each row verify if searchText is present in that row
			if ((row.toLowerCase()).indexOf(searchText.toLowerCase()) >= 0) {
				found = true;
				logger.info("Found - \"" + searchText + "\" in row : " + row);
			}
			else {
				found = false;
				logger.info(searchText + " not Found in row : " + row);
				return found;
			}
			row = "";
		}
		return found;
	});

	//Click right arrow and display remaining columns
	for (var c = numberOfColumns; c > numberOfColumns - 5; c--) {
		element.all(by.css(this.clickviewingColumnsRightArrow()));
	}

	//Search text in remaining columns
	var rows1 = elementList.map(function (eachName) {
		return eachName.getText();
	});

	//Click left arrow and display initial columns
	for (var c = numberOfColumns; c > numberOfColumns - 5; c--) {
		element.all(by.css(this.clickviewingColumnsLeftArrow()));
	}

	//Concatenate each row contents and check if search string is present on each row
	//Even if search string not found in a single row, the test will fail immediately and stops checking further rows
	var strFound1 = rows1.then(function (result) {
		var row = "";
		var found = false;
		for (var i = 0; i < result.length; i = i + numberOfColumns) {
			for (var j = i; j < i + numberOfColumns; j++) {
				row = row + result[j]
			}
			//logger.info(row);
			//For each row verify if searchText is present in that row
			if ((row.toLowerCase()).indexOf(searchText.toLowerCase()) >= 0) {
				found = true;
				logger.info("Found - \"" + searchText + "\" in row : " + row);
			}
			else {
				found = false;
				logger.info(searchText + " not Found in row : " + row);
				return found;
			}
			row = "";
		}
		return found;
	});

	return protractor.promise.all([strFound, strFound1]).then(function (values) {
		return (values[0] || values[1]);
	});
};

inventory.prototype.clickPaginationLeftArrow_gotoFirst = function (pages) {
	for (var i = 0; i < pages; i++) element(by.css(this.paginationLeftArrowCss)).click();
	util.waitForAngular();
};

inventory.prototype.clickviewingColumnsLeftArrow_gotoFirst = function () {
	for (var i = 0; i < 5; i++) element(by.css(this.viewingColumnsLeftArrowCss)).click();
	util.waitForAngular();
};

//************************ End of Functions for Search *******************

//************************ Functions for Edit Service ******************* //

inventory.prototype.getTextForInvalidEditModal = function () {
    util.waitForAngular();
    browser.wait(EC.visibilityOf(element(by.css(this.InvalidEditMessageCss))), 150000);
    return element(by.css(this.InvalidEditMessageCss)).getText().then(function (nonEditPopUptext) {
        logger.info(nonEditPopUptext)
        return nonEditPopUptext;
    });
};

inventory.prototype.clickOnInvalidEditOkModal = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.invalidEditPopUpOKButtonCss))), 150000);
	element(by.css(this.invalidEditPopUpOKButtonCss)).click().then(function(){
		logger.info("Clicked on OK Button for Non editable OKModal")
	})
};

inventory.prototype.isEnabledEditServiceMenuOption = function () {
	return element(by.css(this.editserviceCss)).isEnabled();
};

inventory.prototype.clickEditServiceIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.editserviceCss))), 150000);
	return element(by.css(this.editserviceCss)).click().then(function(){
		util.waitForAngular();
	});
};

inventory.prototype.clickEditServiceNextButton = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.editServiceNextButtonCss))), 5000);
	return element(by.css(this.editServiceNextButtonCss)).click();
};

inventory.prototype.clickEditServiceNextAdditionalParamsButton = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.editServiceNextButtonAdditionalParamsCss))), 5000);
	return element(by.css(this.editServiceNextButtonAdditionalParamsCss)).click();
};

inventory.prototype.clickEditMoreLink = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.editMoreLinkCss))), 5000);
	return element(by.css(this.editMoreLinkCss)).click();
};

inventory.prototype.clickEditCancelButton = function () {
	return element(by.xpath(this.editCancelButtonCss)).click();
	util.waitForAngular();
}

inventory.prototype.setCPUDropDown = function () {
	element(by.css(this.editCPUDropDownCss)).click();
	element(by.css(this.editCPUDropDownValue2Css)).click();
	util.waitForAngular();
}

inventory.prototype.getUpdatedBOM = function () {
	return element.all(by.css(this.editServiceBillOfMaterialsCss)).get(0).getText();
}

inventory.prototype.getCurrentBOM = function () {
	return element.all(by.css(this.editServiceBillOfMaterialsCss)).get(1).getText();
}

inventory.prototype.getEditCurrentCPUText = function () {
	return element.all(by.css(this.editCurrentCPUTextCss)).get(2).getText();
}

inventory.prototype.getEditStrikedCPUText = function () {
	return element(by.css(this.editstrikedCPUTextCss)).getText();
}

inventory.prototype.getEditUpdatedTagText = function () {
	return element(by.css(this.editupdatedTagTextCss)).getText();
}

inventory.prototype.getEditOrderNumberText = function () {
	return element(by.css(this.editOrderNumberCss)).getText();
}

inventory.prototype.clickCurrentBOMButton = function () {
	return element(by.css(this.editCurrentBOMButtonCss)).click();
	util.waitForAngular();
}

inventory.prototype.clickUpdatedBOMButton = function () {
	return element(by.css(this.editUpdatedBOMButtonCss)).click();
	util.waitForAngular();
}

inventory.prototype.clickEditSubmitOrderButton = function () {
	return element(by.css(this.editSubmitOrderButtonCss)).click();
	util.waitForAngular();
}

inventory.prototype.clickEditGoToInventoryButton = function () {
	return element(by.css(this.editGoToInventoryButtonCss)).click();
	util.waitForAngular();
}

//this function is used to get Status of SOI
inventory.prototype.getStatusOfSOI = function () {
	var elementList = element.all(by.xpath('//*[@class="bx--responsive-table"]/tbody/tr[contains(@class, "bx--table-row")]/td[contains(@class, "bx--table-column")][2]'))
	var status_SOI = elementList.map(function (eachName) {
		return eachName.getText().then(function (unSorted) {
			return unSorted;
		});
	}).then(function (unSorted) {
		console.log(unSorted[0])
		return unSorted[0]
	});
	return status_SOI
}

//************************ End of Functions for Edit Service *******************

//************************ Functions for Delete Service ******************* //

inventory.prototype.isEnabledDeleteServiceMenuOption = function () {
	return element(by.css(this.deleteserviceCss)).isEnabled();
};

inventory.prototype.clickDeleteServiceIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.deleteserviceCss))), 5000);
	return element(by.css(this.deleteserviceCss)).click();
};
inventory.prototype.clickDeleteServicecheckboxIcon = function () {
	return element.all(by.css(this.deleteservicecheckboxCss)).first().click();
};

inventory.prototype.clickDeleteServiceOkaybutton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.deleteserviceOkayCss))), 5000);
	return element(by.css(this.deleteserviceOkayCss)).click();
};

inventory.prototype.getDeleteOrderNumberFromPopUpText = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.deleteOrderNumberFromPopUpTextCss))), 10000);
	return element(by.css(this.deleteOrderNumberFromPopUpTextCss)).getText().split(":")[1].trim();
}

//************************ End of Functions for Delete Service *******************

inventory.prototype.searchOrderByServiceName = function (serviceName) {
	var curr = this;
	var servicename = serviceName;
	browser.wait(EC.elementToBeClickable(element(by.css(curr.searchTextBoxCss))), 10000).then(function () {
		var searchInputBox = element(by.css(curr.searchTextBoxCss));
		util.waitForAngular();
		return searchInputBox.clear().then( function() {
			searchInputBox.sendKeys(servicename);
			searchInputBox.sendKeys(protractor.Key.ENTER);
			logger.info("Searching service "+serviceName+" on Inventory page..");
			util.waitForAngular();
			browser.sleep(7000);
			//wait till service instance is displayed	
			browser.wait(EC.elementToBeClickable(element(by.css(curr.instanceTableActionIconCss))), 90000).then(function(){
				logger.info("Waiting for service instance to be displayed in Inventory")
			}).catch(function(){
				logger.info("Service instance not displayed in Inventory. searching again.....");
				curr.open();
				util.waitForAngular();
				browser.wait(EC.elementToBeClickable(element(by.css(curr.searchTextBoxCss))), 50000).then(function () {
				searchInputBox.clear().then( function() {
					searchInputBox.sendKeys(servicename);
					searchInputBox.sendKeys(protractor.Key.ENTER);
					searchInputBox.sendKeys(protractor.Key.ENTER);
					logger.info("Searching service "+serviceName+" on Inventory page..");
					util.waitForAngular();
					browser.sleep(8000);
					//wait till service instance is displayed	
					return browser.wait(EC.elementToBeClickable(element(by.css(curr.instanceTableActionIconCss))), 90000).then(function(){
						logger.info("Waiting for service instance to be displayed in Inventory again")
					}).catch(function(){
						logger.info("Service instance not displayed in Inventory even for the second time .");
						util.waitForAngular();
						browser.sleep(3000);
						
					});
				})
			});
			});
		})
	});

};

//****************** Functions for Instance Table ************

inventory.prototype.clickDeleteFirstInstance = function () {
	var curr = this;
	browser.wait(EC.elementToBeClickable(element.all(by.css(curr.instanceTableActionIconCss)).first()), 90000);
	return element.all(by.css(curr.instanceTableActionIconCss)).first().click().then(function () {
		logger.info("Clicked on the Actions icon from the first row on Inventory page");
		browser.wait(EC.elementToBeClickable(element(by.buttonText(curr.buttonTextDeleteService))), 90000);
		return element(by.buttonText(curr.buttonTextDeleteService)).click().then(function () {
			logger.info("Clicked on Delete Service button");
			util.waitForAngular();
		});
	});
};

/*Function to support Globalisation
 * 
 */
inventory.prototype.clickDeleteFirstInstanceInInventory = function () {
	var curr = this;
	browser.wait(EC.elementToBeClickable(element.all(by.css(curr.instanceTableActionIconCss)).first()), 90000);
	return element.all(by.css(curr.instanceTableActionIconCss)).first().click().then(function () {
		logger.info("Clicked on the Actions icon from the first row on Inventory page");
		browser.wait(EC.elementToBeClickable(element(by.css(curr.deleteServiceInventoryCss))), 40000);
		return element(by.css(curr.deleteServiceInventoryCss)).click().then(function () {
			logger.info("Clicked on Delete Service button");
		});
		util.waitForAngular();
	});
};

//****************** Functions for Delete Service Modal ************

// This function is used to click 'Ok' in the Delete Service Modal
inventory.prototype.clickOKDeleteServiceModal = function () {
	var curr = this;
	browser.wait(EC.elementToBeClickable(element(by.css(curr.deleteServiceModalOKButtonCss))), 10000).then(function () {
		element(by.css(curr.deleteServiceModalOKButtonCss)).click().then(function () {
			logger.info("Clicked on OK button on Delete Service modal dialog");
		});
	});
	//util.waitForAngular();
	browser.sleep(2500);
};

//This function is used to click 'Cancel' in the Delete Service Modal
inventory.prototype.clickCancelDeleteServiceModal = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.deleteServiceModalCancelButtonCss))), 5000);
	element(by.css(this.deleteServiceModalCancelButtonCss)).click();
	util.waitForAngular();
};

//This function is used to click 'Close X' in the Delete Service Modal
inventory.prototype.clickCloseXDeleteServiceModal = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.deleteServiceModalCloseXButtonCss))), 5000);
	element(by.css(this.deleteServiceModalCloseXButtonCss)).click();
	util.waitForAngular();
};

//This function is used to click checkbox to confirm Delete Service in the Delete Service Modal
inventory.prototype.clickConfirmCheckBoxDeleteServiceModal = function () {
	var self = this;
	browser.wait(EC.elementToBeClickable(element(by.css(this.deleteServiceModalConfirmCheckBoxCss))), 200000);
	element(by.css(this.deleteServiceModalConfirmCheckBoxCss)).click().then(function () {
		logger.info("Checked Confirm checkbox on Delete Service modal dialog");
		util.waitForAngular();
	}).catch(function (err) {
		logger.info(err.Name);
		logger.info(err.Message);		
	});

	return element(by.css(this.deleteServiceModalConfirmCheckBoxCss)).isPresent().then(function (value) {
		if (value) {
			//Make sure that checkbox is checked
			return browser.executeScript("return document.getElementById('" + defaultConfig.chkBoxConfirmDeleteId + "').checked;").then(function (checkboxChecked) {
				if (checkboxChecked == false) {
					return element(by.css(defaultConfig.deleteServiceModalConfirmCheckBoxCss)).click().then(function () {
						logger.info("Clicked Delete checkbox in 2nd attempt");
						util.waitForAngular();
					});
				}
			});
		}else {
			return element(by.css(defaultConfig.closedDeleteServiceModalCss)).isPresent().then(function (res) {
				if (res) {
					return element(by.css(defaultConfig.closedDeleteServiceModalCss)).click().then(function () {
						logger.info("closed delete service flow as Delete service check box was not present trying again. ");
						self.clickDeleteFirstInstance();
						return element(by.css(defaultConfig.deleteServiceModalConfirmCheckBoxCss)).click().then(function () {
							logger.info("Checked Delete checkbox in 2nd attempt");
							util.waitForAngular();
						});
					});
				}
			});
		}
	});
};

inventory.prototype.getTopHeaderText = function () {
	return element(by.css(this.inventoryTopHeaderTextCss)).getText();
}

inventory.prototype.clickInventoryTab = function () {
	return element(by.xpath(this.inventoryTabXpath)).click();
}

//************************ Import button******************* //
inventory.prototype.clickImportIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.importIconCss))), 5000);
	return element(by.css(this.importIconCss)).click();
};

inventory.prototype.clickUploadFileIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.uploadFileIconXpath))), 5000);
	return element(by.xpath(this.uploadFileIconXpath)).click();
};

//************************ Functions for Clicking Search button******************* //
inventory.prototype.clickSearchIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.searchIconCss))), 5000);
	return element(by.css(this.searchIconCss)).click();
};


inventory.prototype.clickviewingColumnsRightArrow = function () {
	element(by.css(this.viewingColumnsRightArrowCss)).click();
	util.waitForAngular();
};

inventory.prototype.clickviewingColumnsLeftArrow = function () {
	element(by.css(this.viewingColumnsLeftArrowCss)).click();
	util.waitForAngular();
};

inventory.prototype.clickviewingColumnsRightArrow_gotoLast = function () {
	for (var i = 0; i < 5; i++) element(by.css(this.viewingColumnsRightArrowCss)).click();
	util.waitForAngular();
};


inventory.prototype.clickPaginationRightArrow_gotoLast = function (pages) {
	for (var i = 0; i < pages; i++) element(by.css(this.paginationRightArrowCss)).click();
	util.waitForAngular();
};



inventory.prototype.isPresentNoDataAvailableText = function () {
	return element(by.css(this.noDataAvailableTextCss)).isPresent();
};

inventory.prototype.clickitemsPerPageText = function () {
	return element.all(by.css(this.itemsPerPageTextCss)).first().click();
};


/************************start of order history page***********************************************/
inventory.prototype.clickOrderId = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.orderIdColumnNameXpath))), 5000);
	return element(by.xpath(this.selectInputXpath)).click();
}
inventory.prototype.clickOperationType = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.operationTypeColumnNameXpath))), 5000);
	return element(by.xpath(this.selectInputXpath)).click();
}
inventory.prototype.clickStatusColumn = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.statusColumnNameXpath))), 5000);
	return element(by.xpath(this.selectInputXpath)).click();
}
inventory.prototype.clickRequestedBy = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.requestedByColumnNameXpath))), 5000);
	return element(by.xpath(this.selectInputXpath)).click();
}
inventory.prototype.clickEstimatedCostCurrency = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.estimatedcostcurrencyColumnNameXpath))), 5000);
	return element(by.xpath(this.selectInputXpath)).click();
}
inventory.prototype.clickErrorFailure = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.errorFailureColumnNameXpath))), 5000);
	return element(by.xpath(this.selectInputXpath)).click();
};


/************************end of order history page***********************************************/

//************************ Functions for View Properties******************* //
inventory.prototype.clickSelectedSOIGlificon = function () {
	return element(by.css(this.selectedSOIGlificonCss)).click();
};

// Click on service details
inventory.prototype.clickOnServiceDetails = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.expandServiceDetailsCss))), 60000);
	 element(by.css(this.expandServiceDetailsCss)).click().then(function(){
   		logger.info("Expanded the Service Details row");
   	})
};

// Click on service configuaration
inventory.prototype.clickOnServiceConfiguration = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.expandServiceConfigurationCss))), 60000);
	element(by.css(this.checkExpandServiceConfigurationCss)).isPresent().then(function(bool){
		if(bool)
		{
			element(by.css(this.expandServiceConfigurationCss)).click().then(function(){
				logger.info("Expanded the Service Configuration row");
			})
		}
		else
		{
			logger.info("Service Configuration row is already Expanded");
		}
	})
};

inventory.prototype.clickViewService = function () {
	//return element.all(by.css(this.viewServiceCss)).first().click();
	var curr = this;
	return element(by.buttonText(this.viewServiceButtonText)).click().then(function () {
		logger.info("Clicked on View Service Button in Inventory Page");
		util.waitForAngular();
		browser.wait(EC.invisibilityOf(element(by.xpath(curr.loadingDetailsXpath))),100000);
		//curr.clickOnServiceDetails();
		//curr.clickOnServiceConfiguration();
	});
};

inventory.prototype.isServiceNameOfSelectedSOIAvailable = function () {
	return element.all(by.css(this.serviceNameOfSelectedSOICss)).isPresent();
};

inventory.prototype.isProviderServiceInstanceIdSOIAvailable = function () {
	return element(by.xpath(this.providerServiceInstanceIdXpath)).isPresent();
};


//************************ Functions for Individual Service ID Search and performing other actions ******************* //

inventory.prototype.clickSearchIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.searchIconCss))), 5000);
	return element(by.css(this.searchIconCss)).click();
};

inventory.prototype.searchInTable = function (seachText) {
	element(by.css(this.searchTextBoxCss)).clear();
	element(by.css(this.searchTextBoxCss)).sendKeys(seachText);
	browser.actions().sendKeys(protractor.Key.ENTER).perform();
};

inventory.prototype.clickGlificonIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.GlificonIconXpath))), 5000);
	return element(by.xpath(this.GlificonIconXpath)).click();
};
inventory.prototype.clickViewServiceIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.viewserviceXpath))), 5000);
	return element(by.xpath(this.viewserviceXpath)).click();
};

inventory.prototype.clickOrderHistorTab = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.orderhistoryCss))), 5000);
	return element(by.css(this.orderhistoryCss)).click();
};

inventory.prototype.checkServiceLogsPresent = function(){
	browser.wait(EC.presenceOf(element.all(by.css(this.logMessageCss)).get(0)), 5000);
	return element(by.css(this.logMessageCss)).isPresent();
};

inventory.prototype.getTextEstimatedCostOnOrderHistory = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.estimatedCostOrderHistoryCss))), 10000);
    return element(by.css(this.estimatedCostOrderHistoryCss)).getText().then(function(text){
        logger.info("Estimated price on Order History page : "+text)
        return text;
    });
};

inventory.prototype.getTextEstimatedCostAfterEditOnOrderHistory = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.estimatedCostOrderHistoryCss))), 10000);
	var ele = element.all(by.css(this.estimatedCostOrderHistoryCss)).get(1);
    return ele.getText().then(function(text){
        logger.info("Estimated price after edit on Order History page : "+text)
        return text;
    });
};

inventory.prototype.getTextOrderIdAfterEditOnOrderHistory = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.newOrderIdCss))), 10000);
	var ele = element.all(by.css(this.newOrderIdCss)).get(1);
    return ele.getText().then(function(text){
        logger.info("Order ID on Order History page : "+text)
        return text;
    });
};

inventory.prototype.getTextOrderIdOnOrderHistory = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.newOrderIdCss))), 10000);
    return element(by.css(this.newOrderIdCss)).getText().then(function(text){
        logger.info("Order ID on Order History page : "+text)
        return text;
    });
};

inventory.prototype.getTextNewOperationType = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.newOperationTypeCss))), 10000);
    return element(by.css(this.newOperationTypeCss)).getText().then(function(text){
        logger.info("Operation Type on Order History page : "+text)
        return text;
    });
};

inventory.prototype.getTextEditOperationType = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.newOperationTypeCss))), 10000);
	var ele = element.all(by.css(this.newOperationTypeCss)).get(1);
    return ele.getText().then(function(text){
        logger.info("Operation Type on Order History page : "+text)
        return text;
    });
};
inventory.prototype.getTextSOIName = function () {
	browser.sleep(10000);
	browser.wait(EC.visibilityOf(element.all(by.css(this.soiNameOnInventoryCss)).get(0)), 30000);
	return element.all(by.css(this.soiNameOnInventoryCss)).get(0).getText().then(function(text) {
		logger.info("Service Instance Name is: "+text);
		return text;
	});
}

inventory.prototype.clickOnServiceLogsTab = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.serviceLogsCss))), 60000);
	return element(by.css(this.serviceLogsCss)).click().then(function() {
		logger.info("Clicked On Service Logs Tab of Inventory View Service")
	});
}
inventory.prototype.clickViewServiceClosebutton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.viewServiceCloseCss))), 5000);
	return element(by.css(this.viewServiceCloseCss)).click().then(function(){
		logger.info("Clicked On Close View Service button on Inventory page.")
	});
};
inventory.prototype.clickGlificonIcon1 = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.GlificonIconXpath))), 5000);
	return element(by.xpath(this.GlificonIconXpath)).click();
};

inventory.prototype.clickRefreshServiceIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.refreshserviceXpath))), 5000);
	return element(by.xpath(this.refreshserviceXpath)).click();
};
inventory.prototype.clickRefreshServiceOakybutton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.refreshserviceOkayCss))), 5000);
	return element(by.css(this.refreshserviceOkayCss)).click();
};
/*---------------------------------------------------------------------*/
inventory.prototype.isInstanceNamePresent = function () {
	return element(by.css(this.instanceNameColumnNameCss)).click().then(function () {
		logger.info("Instance Name clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
};

inventory.prototype.isStatusPresent = function () {
	return element(by.css(this.statusCoulmnNameCss)).click().then(function () {
		logger.info("Status clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
};

inventory.prototype.isProvisionedDatePresent = function () {
	return element(by.css(this.provisionedDateColumnNameCss)).click().then(function () {
		logger.info("Provisioned Date clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
};

inventory.prototype.isProviderPresent = function () {
	return element(by.css(this.providerColumnNameCss)).click().then(function () {
		logger.info("Provider clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
};

inventory.prototype.isProviderAccountPresent = function () {
	return element(by.css(this.providerAccountColumnNameCss)).click().then(function () {
		logger.info("Provider Account clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
};

inventory.prototype.isTeamPresent = function () {
	return element(by.css(this.teamColumnNameCss)).click().then(function () {
		logger.info("Team clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
};

inventory.prototype.isOrderedByPresent = function () {
	return element(by.css(this.orderedByColumnNameCss)).click().then(function () {
		logger.info("Ordered By clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
}

inventory.prototype.isServiceNamePresent = function () {
	return element(by.css(this.serviceNameColumnNameCss)).click().then(function () {
		logger.info("Service Name clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
}

inventory.prototype.isEstimatedCostPresent = function () {
	return element(by.css(this.estimatedCostColumnNameCss)).click().then(function () {
		logger.info("Estimated Cost clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
}

inventory.prototype.isCurrencyPresent = function () {
	return element(by.css(this.currencyColumnNameCss)).click().then(function () {
		logger.info("Currency clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
}

inventory.prototype.expandFirstRow = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.firstrowAccordianXpath))), 5000);
	return element(by.xpath(this.firstrowAccordianXpath)).click();

}

inventory.prototype.isViewingColumnDisabled = function () {
	browser.wait(EC.presenceOf(element(by.xpath(this.viewingColumnScrollArrowsDisabledXpath))), 5000);
	return element(by.xpath(this.viewingColumnScrollArrowsDisabledXpath)).isPresent();

}

/*-----------------------------------------------------------------------------------*/
inventory.prototype.isOrderIdPresent = function () {
	return element(by.xpath(this.orderIdColumnNameXpath)).click().then(function () {
		console.log("Order Name clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
};
inventory.prototype.isOperationTypePresent = function () {
	return element(by.xpath(this.operationTypeColumnNameXpath)).click().then(function () {
		console.log("Operation Type clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
};

inventory.prototype.isStatusPresent = function () {
	return element(by.xpath(this.statusColumnNameXpath)).click().then(function () {
		console.log("Status Column clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
};

inventory.prototype.isRequestedByPresent = function () {
	return element(by.xpath(this.requestedByColumnNameXpath)).click().then(function () {
		console.log("Requested By clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
};

inventory.prototype.isEstimatedCostCurrencyPresent = function () {
	return element(by.xpath(this.estimatedcostcurrencyColumnNameXpath)).click().then(function () {
		console.log("Estimated Cost Currency clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
};

inventory.prototype.isErrorFailurePresent = function () {
	return element(by.xpath(this.errorFailureColumnNameXpath)).click().then(function () {
		console.log("Is Error Failure clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
}

inventory.prototype.isHeadingNamePresent = function () {
	return element(by.xpath(this.connectVMInstructionXpath)).click().then(function () {
		console.log("Instance Name clicked successfully");
		return true;
	}, function (err) {
		var errName = err.toString();
		if (errName.indexOf("ElementNotVisibleError") != -1) {
			return false;
		}
		else
			throw err;
	});
};
/*-----------------------------------------------------------------------------------*/


//************************ Functions for Individual Asset ID Search and performing other actions ******************* //

inventory.prototype.clickExpansionIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.expansionIconXpath))), 5000);
	return element(by.xpath(this.expandIconXpath)).click();
};


/*-----------------------------------------------------------------------------------*/

//************************ Functions for role management and view component properties ******************* //

inventory.prototype.isEnabledViewServiceMenuOption = function () {
	return element(by.xpath(this.viewserviceXpath)).isEnabled();
};

inventory.prototype.isEnabledRefreshStatusMenuOption = function () {
	return element(by.xpath(this.refreshStatusXpath)).isEnabled();
};

//Batch SOC operation menu item methods

inventory.prototype.isEnabledbatchActionsMenuSOCTurnOn = function () {
	return element(by.xpath(this.batchActionsMenuSOCTurnOnXpath)).isEnabled();
};

inventory.prototype.isEnabledbatchActionsMenuSOCTurnOff = function () {
	return element(by.xpath(this.batchActionsMenuSOCTurnOffXpath)).isEnabled();
};

inventory.prototype.isEnabledbatchActionsMenuSOCReboot = function () {
	return element(by.xpath(this.batchActionsMenuSOCRebootXpath)).isEnabled();
};

inventory.prototype.isEnabledbatchActionsMenuSOCRefresh = function () {
	return element(by.xpath(this.batchActionsMenuSOCRefreshXpath)).isEnabled();
};

inventory.prototype.expandFirstRow = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.firstrowAccordianXpath))), 5000);
	return element(by.xpath(this.firstrowAccordianXpath)).click();

}

inventory.prototype.clickOverflowMenuIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.menuIconXpath))), 5000);
	return element(by.xpath(this.menuIconXpath)).click();

}

inventory.prototype.clickoverflowmenuoptions = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.overflowmenuoptionsXpath))), 3000);
	return element(by.xpath(this.overflowmenuoptionsXpath)).click();
};

inventory.prototype.isViewingColumnDisabled = function () {
	browser.wait(EC.presenceOf(element(by.xpath(this.viewingColumnScrollArrowsDisabledXpath))), 5000);
	return element(by.xpath(this.viewingColumnScrollArrowsDisabledXpath)).isPresent();

}

inventory.prototype.viewSOIComponents = function (orderObject,SOIComponents) {
	var self = this;
	self.clickExpandFirstRow().then(function () {
		browser.executeScript('window.scrollTo(0,0);');
		var i = 1;
		async.forEachSeries(SOIComponents, function (component, callback) {
			self.clickOverMenuIcon(i).then(function () {
				self.clickOnViewComponent(i).then(function () {
					expect(self.getComponentName(SOIComponents)).toBe(true);
					self.closeViewComponent();
					browser.sleep(10000);
					i++;
					return callback();
				});
			})
		}, function (error) {
			if (error) {
				logger.info('Unable to Get SOI component')
			}
		})
	})
}

inventory.prototype.clickExpandFirstRow = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.expandFirstRowXpath))), 60000);
	return element(by.xpath(this.expandFirstRowXpath)).click().then(function(){
   		logger.info("Expanded the first row");
		util.waitForAngular();
   	})
};

inventory.prototype.clickBatchActionsMenuGlifficon = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.batchActionsMenuGlifficonXpath))), 5000);
	return element(by.xpath(this.batchActionsMenuGlifficonXpath)).click();
};

inventory.prototype.clickGlificonIconOfSOC = function () {
	browser.ignoreSynchronization = true;
	element(by.xpath(this.GlificonIconOfSOCXpath)).click();
	//   	browser.ignoreSynchronization = false;
};

inventory.prototype.clickSOIcheckbox = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.SOIcheckboxXpath))), 5000);
	return element(by.xpath(this.SOIcheckboxXpath)).click();
};

inventory.prototype.clicksOCFirstChildComponent = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.sOCFirstChildComponentXpath))), 5000);
	return element(by.xpath(this.sOCFirstChildComponentXpath)).click();
};

inventory.prototype.clicksOCSecondChildComponent = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.sOCSecondChildComponentXpath))), 5000);
	return element(by.xpath(this.sOCSecondChildComponentXpath)).click();
};

inventory.prototype.isEnabledTurnOnActionMenuOption = function () {
	return element(by.css(this.turnOnActionMenuOptionCss)).isEnabled();
};

inventory.prototype.isEnabledTurnOffActionMenuOption = function () {
	return element(by.css(this.turnOffActionMenuOptionCss)).isEnabled();
};

inventory.prototype.isEnabledRebootActionMenuOption = function () {
	return element(by.css(this.RebootActionMenuOptionCss)).isEnabled();
};

inventory.prototype.isEnabledRefreshStatusActionMenuOption = function () {
	return element(by.css(this.refreshStatusActionMenuOptionCss)).isEnabled();
};

inventory.prototype.isEnabledViewComponentActionMenuOption = function () {
	return element(by.css(this.viewComponentActionMenuOptionCss)).isEnabled();
};

inventory.prototype.clickViewComponentActionMenuOption = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.viewComponentActionMenuOptionCss))), 5000);
	return element(by.css(this.viewComponentActionMenuOptionCss)).click();
};

inventory.prototype.clickViewComponentCloseButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.ViewComponentCloseButtonXpath))), 5000);
	return element(by.xpath(this.ViewComponentCloseButtonXpath)).click();
};

inventory.prototype.clickViewComponentCloseButtonAWS = function () {
	var closeButton = "//carbon-slide-over-panel[2]/div/header/span/carbon-icon"
	browser.wait(EC.elementToBeClickable(element(by.xpath(closeButton))), 5000);
	console.log("clicked on view componenet close button");
	return element(by.xpath(closeButton)).click();
};

inventory.prototype.isEnabledAccessComponentActionMenuOption = function () {
	return element(by.css(this.accessComponentActionMenuOptionCss)).isEnabled();
};

inventory.prototype.isEnabledbatchActionsMenuDeleteSelected = function () {
	return element(by.xpath(this.batchActionsMenuDeleteSelectedXpath)).isEnabled();
};

inventory.prototype.isEnabledbatchActionsMenuRefreshStatuses = function () {
	return element(by.xpath(this.batchActionsMenuRefreshStatusesXpath)).isEnabled();
};

//View component properties methods
inventory.prototype.getcomponentTypeProp = function () {
	return element.all(by.xpath(this.componentTypePropXpath)).getText().then(function (text) {
		return text
	});
};

inventory.prototype.getnameProp = function () {
	return element.all(by.xpath(this.namePropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getstatusProp = function () {
	return element.all(by.xpath(this.statusPropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getproviderNameProp = function () {
	return element.all(by.xpath(this.providerNamePropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getresourceIdProp = function () {
	return element.all(by.xpath(this.resourceIdPropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.gettagsProp = function () {
	return element.all(by.xpath(this.tagsPropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getavailabilityZoneProp = function () {
	return element.all(by.xpath(this.availabilityZonePropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getavailableIpAddressCountProp = function () {
	return element.all(by.xpath(this.availableIpAddressCountPropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getcidrBlockProp = function () {
	return element.all(by.xpath(this.cidrBlockPropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getdefaultForAzProp = function () {
	return element.all(by.xpath(this.defaultForAzPropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getmapPublicIpOnLaunchProp = function () {
	return element.all(by.xpath(this.mapPublicIpOnLaunchPropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getstateProp = function () {
	return element.all(by.xpath(this.statePropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getsubnetIdProp = function () {
	return element.all(by.xpath(this.subnetIdPropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getvpcIdProp = function () {
	return element.all(by.xpath(this.vpcIdPropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getassignIpv6aAddressOnCreationProp = function () {
	return element.all(by.xpath(this.assignIpv6aAddressOnCreationPropXpath)).getText().then(function (text) {
		return text
	});
};
inventory.prototype.getipv6CidrBlockAssociationSetProp = function () {
	return element.all(by.xpath(this.ipv6CidrBlockAssociationSetPropXpath)).getText().then(function (text) {
		return text
	});
};

inventory.prototype.getViewComponentPropertyAWS = function (labelName) {//    browser.ignoreSynchronization = true;
	browser.waitForAngular();
	var label = "//h5[contains(text(),'" + labelName + "')]/following-sibling::p"
	browser.wait(EC.visibilityOf(element(by.xpath(label))), 3000);
	return element(by.xpath(label)).getText().then(function (text) {
		logger.info("The value for " + labelName + " is : " + text)
		return text;
	});

}

//****************FUNCTIONS IN DELETE ORDER SUBMITTED POP UP***************************

inventory.prototype.getTextdeleteOrderSubmittedHeaderModal = function () {
	return element(by.xpath(this.deleteOrderSubmittedHeaderModalXpath)).getText().then(function (text) {
		logger.info(text)
		return text;
	});
};

inventory.prototype.getTextdeleteServiceModalNotificationMessage = function () {
	return element(by.css(this.deleteServiceModalNotificationBoxTextCss)).getText().then(function (text) {
		logger.info("Message : " + text);
		return text;
	});
};

inventory.prototype.getTextOrderNumberDeleteOrderSubmittedModal = function () {
	return element(by.css(this.deleteOrderSubmittedModalOrderNumberTextCss)).getText().then(function (text) {
		logger.info("Order number : " + text);
		return text;
	});
};

inventory.prototype.getTextOrderedDateDeleteOrderSubmittedModal = function () {
	return element(by.css(this.deleteOrderSubmittedModalOrderDateTextCss)).getText().then(function (text) {
		logger.info("Ordered Date : " + text);
		return text;
	});
};

inventory.prototype.clickdeleteServiceModalNotificationBoxClose = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.deleteServiceModalNotificationBoxCloseCss))), 5000);
	element(by.css(this.deleteServiceModalNotificationBoxCloseCss)).click();
	util.waitForAngular();
};

inventory.prototype.isPresentdeleteServiceModalNotification = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.deleteServiceModalNotificationBoxCss))), 5000);
	element(by.css(this.deleteServiceModalNotificationBoxCss)).isPresent();
	util.waitForAngular();
	return element(by.css(this.deleteServiceModalNotificationBoxCss)).isPresent();
};

inventory.prototype.clickdeleteServiceConfirmDialogCancelButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.deleteserviceCancelCss))), 5000);
	element(by.css(this.deleteserviceCancelCss)).click();
	util.waitForAngular();
};


//****************FUNCTIONS IN DELETE ORDER SUBMITTED POP UP END************************


//**************** START : FUNCTIONS FOR D2OP (TURN ON, TURN OFF, REBOOT) OF INSTANCES***********


inventory.prototype.clickOverflowActionButtonForPowerStates = function () {
	//browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.sleep(3000);
	var elem = element.all(by.xpath(this.powerStateOverflowMenuIconXpath));	
	browser.wait(EC.elementToBeClickable(elem.last()), 60000);
	return elem.last().click().then(function()
		{
			logger.info("clicked last Over Flow Menu Icon");
		}
	);
};

inventory.prototype.clickOverflowActionButtonFisrtComponent = function () {
	browser.ignoreSynchronization = true;
	util.waitForAngular();
	var elem = element.all(by.xpath(this.powerStateOverflowMenuIconXpath));	
	browser.wait(EC.elementToBeClickable(elem.get(2)), 90000);
	return elem.get(2).click().then(function(){
		logger.info("CLicked on Action button.")
	});
};
//*********Functions for ICAM Day2 operations  */
inventory.prototype.clickOverflowActionButtonForPowerStatesoperationIcam = function()
{   
	var self = this;
	browser.ignoreSynchronization = true;
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.powerStateOverflowMenuIconXpath))), 60000);
	
	var componentType = element.all(by.css(this.textComponentTypeCss));
	return componentType.getText().then(function(textArray){
		   if(textArray.includes("Virtual Machine")) {
		  	  var stringID = textArray.indexOf("Virtual Machine");
		  	  var vmID = stringID + 2;
		  	  element(by.xpath(self.glifIconXpath + "[" + vmID + "]")).click().then(function(){
						logger.info("Clicked on Action icon of Virtual Machine for Power states");
		  	  });
		   }
		   else {
					logger.info("Error: No Virtual machine found");
				}
	})
	
	 browser.ignoreSynchronization = false;
};

inventory.prototype.clickActionButtonForIcamAzureInstance = function()
{   
	var self = this;
	browser.ignoreSynchronization = true;
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.powerStateOverflowMenuIconXpath))), 60000);
	
	var componentType = element.all(by.css(this.textComponentTypeCss));
	return componentType.getText().then(function(textArray){
		logger.info("TestarrayContain:"+textArray);

		   if(textArray.includes("Virtual Machine")) {
		  	  var stringID = textArray.indexOf("Virtual Machine");  
		  	  var vmID = stringID + 3;
		  	  element(by.xpath(self.glifIconXpath + "[" + vmID + "]")).click().then(function(){
						logger.info("Clicked on Action icon of Virtual Machine for Power states");
		  	  });
		   }
		   else {
					logger.info("Error: No Virtual machine found");
				}
	})
	
	 browser.ignoreSynchronization = false;
};

inventory.prototype.clickTurnONButtonOfInstanceNegativeIcam = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.icamTurnONCss))), 60000);
	element(by.css(this.icamTurnONCss)).click().then(function() {
		logger.info("Clicked on start of Virtual Machine");
		})

	
};

inventory.prototype.clickTurnOFFButtonOfInstanceIcam = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.icamTurnOFFCss))), 90000);
	element(by.css(this.icamTurnOFFCss)).click().then(function() {
		logger.info("Clicked on stop of Virtual Machine");
		})

};

inventory.prototype.icamClickShutdownButtonOfInstance = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.icamShutdownXpath))), 60000);
	element(by.xpath(this.icamShutdownXpath)).click().then(function() {
		logger.info("Clicked on shutdown of Virtual Machine");
		})

};

inventory.prototype.clickTaintONButtonOfInstanceIcam = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.icamTaintXpath))), 60000);
	element(by.xpath(this.icamTaintXpath)).click().then(function() {
		logger.info("Clicked on taint of Virtual Machine");
		})
};
inventory.prototype.clickUntaintONButtonOfInstanceIcam = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.icamUntaintXpath))), 60000);
	element(by.xpath(this.icamUntaintXpath)).click().then(function() {
		logger.info("Clicked on untaint of Virtual Machine");
		})
};

inventory.prototype.icamClickTaintButtonOfIcamUpgrade_DowngradeInstance = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.icamUDTaintCss))), 60000);
	element(by.css(this.icamUDTaintCss)).click().then(function() {
		logger.info("Clicked on taint of virtual machine of Upgrade-downgrade service.");
		})

};

inventory.prototype.icamClickTaintButtonOfIcamAzureInstance = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.icamAzureTaintCss))), 60000);
	element(by.css(this.icamAzureTaintCss)).click().then(function() {
		logger.info("Clicked on taint of  virtual machine ");
		})

};


inventory.prototype.icamClickUntaintButtonOfIcamAzureInstance = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.icamAzureUntaintCss))), 60000);
	element(by.css(this.icamAzureUntaintCss)).click().then(function() {
		logger.info("Clicked on Untaint of virtual machine");
		})

};

//*************** Functions for VRA Day2 Operations (Turn Off, Turn On, Reboot) **************************

inventory.prototype.clickOverflowActionButtonVRA = function(componentType, status)
{   
	var self = this;
	// browser.ignoreSynchronization = true;
	var overFlowButtonForComponentType = this.overFlowButtonForSpecificComponentTypeXpath.format(componentType);
	util.waitForAngular();
	return browser.wait(EC.elementToBeClickable(element.all(by.xpath(overFlowButtonForComponentType)).first()), 60000).then(function(){
		if(status == 'Off'){
			var overFlowButtonWithAction = self.overFlowButtonForVMStatusXpath.format(componentType,status);
			return element.all(by.xpath(overFlowButtonWithAction)).first().click().then(function(){
				logger.info("Clicked on Action icon of Virtual Machine for Turn Off Power state..");
			}).catch(function(){
				logger.info("Error: No Virtual machine found");
			});
		}
		else{
			return element.all(by.xpath(overFlowButtonForComponentType)).first().click().then(function(){
				logger.info("Clicked on Action icon of Virtual Machine for Power states..");
			}).catch(function(){
				logger.info("Error: No Virtual machine found");
			});
		}
	});
	
	// var componentType = element.all(by.css(this.textComponentTypeCss));
	// return componentType.getText().then(function(textArray){
	// 	   if(textArray.includes("Infrastructure.Virtual")) {
	// 	  	  var stringID = textArray.indexOf("Infrastructure.Virtual");
	// 	  	  var vmID = stringID + 3;
	// 	  	  element(by.xpath(self.glifIconXpath + "[" + vmID + "]")).click().then(function(){
	// 					logger.info("Clicked on Action icon of Virtual Machine for Power states");
	// 	  	  });
	// 	   }
	// 	   else {
	// 				logger.info("Error: No Virtual machine found");
	// 			}
	// })
	
	//  browser.ignoreSynchronization = false;
};

inventory.prototype.clickViewComponentButtonOfInstanceVRA = function (componentType) {
	util.waitForAngular();
	browser.sleep(6000)
	var viewComponentButtonForComponentType = this.viewCompnentButtonForSpecificComponentTypeXpath.format(componentType);
	// var componentType = element.all(by.css(this.textComponentTypeCss));
	// return componentType.getText().then(function(textArray){
	// 	   if(textArray.includes("Infrastructure.Virtual")) {
	// 	  	  var stringID = textArray.indexOf("Infrastructure.Virtual");
	// 	  	  var buttonID = stringID + 1;
	// 	  	  browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-3-button"))),90000);
	// 	  	  return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-3-button")).click().then(function(){
	// 					logger.info("Clicked on View Component button");
	// 	  	  });	  	  
	// 	    }
	// 	   else {
	// 				logger.info("Error: No Virtual machine found");
	// 			}
	// 	});   
	browser.wait(EC.elementToBeClickable(element(by.xpath(viewComponentButtonForComponentType))), 60000); 
	return element(by.xpath(viewComponentButtonForComponentType)).click().then(function(){
		logger.info("Clicked on View Component button");
	}).catch(function(){
		logger.info("No View Component button found");
	});
};

inventory.prototype.clickViewComponentButtonOfInstanceOFFVRA = function () {
	util.waitForAngular(); 
	var componentType = element.all(by.css(this.textComponentTypeCss));
	var status = element.all(by.css(this.textVMStatusCss));
	return componentType.getText().then(function(textArray){
		return status.getText().then(function(statusArray){
			for(var i=0; i<textArray.length; i++) {
				if(textArray[i]=="Infrastructure.Virtual" && statusArray[i]=="Off") {
		  	  		var buttonID = i + 1;
		  	  		browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-3-button"))),90000);
		  	  		return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-3-button")).click().then(function(){
		  	  			logger.info("Clicked on View Component button for powered off VM");
		  	  		});
				   }
				else {
					logger.info("Error: Status is not in OFF state");
				}
				}
		 });	  
	});   
};

inventory.prototype.clickTurnOFFButtonOfInstanceVRA = function (componentType) {
	util.waitForAngular();
	var turnOffActionButtonForComponentType = this.turnOffActionButtonForSpecificComponentTypeXpath.format(componentType);
	// var componentType = element.all(by.css(this.textComponentTypeCss));
	// return componentType.getText().then(function(textArray){
	// 	   if(textArray.includes("Infrastructure.Virtual")) {
	// 	  	  var stringID = textArray.indexOf("Infrastructure.Virtual");
	// 	  	  var buttonID = stringID + 1;
	// 	  	  browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-6"))),90000);
	// 	  	  return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-6")).click().then(function(){
	// 					logger.info("Clicked on Turn OFF button");
	// 	  	  });	  	  
	// 	    }
	// 	   else {
	// 				logger.info("Error: No Virtual machine found");
	// 			}
	// 	});  
	browser.wait(EC.elementToBeClickable(element(by.xpath(turnOffActionButtonForComponentType))), 60000); 
	return element(by.xpath(turnOffActionButtonForComponentType)).click().then(function(){
		logger.info("Clicked on Turn OFF button");
	}).catch(function(){
		logger.info("No Turn OFF button found");
	});
};

inventory.prototype.clickTurnONButtonOfInstanceVRA = function (componentType) {
	util.waitForAngular(); 
	var turnOnActionButtonForComponentType = this.turnOnActionButtonForSpecificComponentTypeXpath.format(componentType);
	// var componentType = element.all(by.css(this.textComponentTypeCss));
	// var status = element.all(by.css(this.textVMStatusCss));
	// return componentType.getText().then(function(textArray){
	// 	return status.getText().then(function(statusArray){
	// 		for(var i=0; i<textArray.length; i++) {
	// 			if(textArray[i]=="Infrastructure.Virtual" && statusArray[i]=="Off") {
	// 	  	  		var buttonID = i + 1;
	// 	  	  		browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-5"))),90000);
	// 	  	  		return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-5")).click().then(function(){
	// 	  	  			logger.info("Clicked on Turn ON button");
	// 	  	  		});
	// 			   }
	// 			else {
	// 				logger.info("Error: Status is not in OFF state");
	// 			}
	// 			}
	// 	 });	  
	// }); 
	browser.wait(EC.elementToBeClickable(element(by.xpath(turnOnActionButtonForComponentType))), 60000); 
	return element(by.xpath(turnOnActionButtonForComponentType)).click().then(function(){
		logger.info("Clicked on Turn ON button");
	}).catch(function(){
		logger.info("No Turn ON button found");
	});
};

inventory.prototype.clickRebootButtonOfInstanceVRA = function (componentType) {
	util.waitForAngular();
	var rebootActionButtonForComponentType = this.rebootActionButtonForSpecificComponentTypeXpath.format(componentType);
	// var componentType = element.all(by.css(this.textComponentTypeCss));
	// return componentType.getText().then(function(textArray){
	// 	   if(textArray.includes("Infrastructure.Virtual")) {
	// 	  	  var stringID = textArray.indexOf("Infrastructure.Virtual");
	// 	  	  var buttonID = stringID + 1;
	// 			browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-7"))),90000);
	// 	  	  return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-7")).click().then(function(){
	// 					logger.info("Clicked on Reboot button");
	// 	  	  });	  	  
	// 	    }
	// 	   else
	// 	  	 {
	// 	  	 		logger.info("Error: No Virtual machine found");
	// 	  	 }
	// 	});
	browser.wait(EC.elementToBeClickable(element(by.xpath(rebootActionButtonForComponentType))), 60000); 
	return element(by.xpath(rebootActionButtonForComponentType)).click().then(function(){
		logger.info("Clicked on Reboot button");
	}).catch(function(){
		logger.info("No Reboot button found");
	}); 
};

inventory.prototype.clickOverflowActionButtonON3TierVRA = function()
{   
	var self = this;
	browser.ignoreSynchronization = true;
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.powerStateOverflowMenuIconXpath))), 90000);
	
	var componentType = element.all(by.css(this.textComponentTypeCss));
	var status = element.all(by.css(this.textVMStatusCss));
	return componentType.getText().then(function(textArray){
		return status.getText().then(function(statusArray){
			for(var i=0; i<textArray.length; i++) {
				if(textArray[i]=="Infrastructure.Virtual" && statusArray[i]=="Off") {
		  	  var vmID = i + 3;
		  	  element(by.xpath(self.glifIconXpath + "[" + vmID + "]")).click().then(function(){
						logger.info("Clicked on Action icon of Virtual Machine for Power states");
		  	  });
		    }
				else {
					logger.info("Error: No Virtual machine found");
				}
			}
		})
	})	
	 browser.ignoreSynchronization = false;
};

//Negative scenario- Turn on the VM which is in ON state
inventory.prototype.clickTurnONButtonOfInstanceNegativeVRA = function () {
	util.waitForAngular();
	var componentType = element.all(by.css(this.textComponentTypeCss));
	return componentType.getText().then(function(textArray){
		   if(textArray.includes("Infrastructure.Virtual")) {
		  	  var stringID = textArray.indexOf("Infrastructure.Virtual");
		  	  var buttonID = stringID + 1;
				browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-6"))),90000);
  	  		return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-6")).click().then(function(){
  	  			logger.info("Clicked on Turn ON button");
  	  		})  	  
		    }
		   else {
					logger.info("Error: No Virtual machine found");
				}
		});   
};

inventory.prototype.waitForInstanceStateStatusChangeVRA = function(orderObject, expectedChangedStatus, repeatCount) {
	var self = this;
	if (repeatCount == undefined) {
        	repeatCount = 900;  //900 counts will take less than a minute
    	}
	util.waitForAngular();
	if (repeatCount > 0) {	
			var componentType = element.all(by.css(this.textComponentTypeCss));
			return componentType.getText().then(function(textArray){
				   if(textArray.includes("Infrastructure.Virtual")) {
				  	  var stringID = textArray.indexOf("Infrastructure.Virtual");
				  	  var statusID = stringID + 5 + (6*stringID);
				  	  element(by.xpath(self.textTableElementsXpath + "[" + statusID + "]" )).getText().then(function(text) {
				  	  	logger.info("Current Status:" + text);
								if (text == expectedChangedStatus) {
									logger.info("Instance Status is changed to: " + text);
									repeatCount = 0;
									return text;
								} 
								else {
									util.waitForAngular();
									logger.info("Status Check - " + repeatCount + " : Waiting for instance status to be " + expectedChangedStatus + ", current status: " + text);
									repeatCount = repeatCount - 1;
									self.waitForInstanceStateStatusChangeVRA(orderObject, expectedChangedStatus, repeatCount);
								}
				  	  })
				   }
			 })
	  }				
};							
		
inventory.prototype.getInstancePowerStateStatusVRA=function(orderObject) {
	util.waitForAngular();
	var self = this;
	var status = element.all(by.css(this.textVMStatusCss));
	browser.wait(EC.visibilityOf(status.last()), 90000);
	return status.getText().then(function(statusArray) {
		logger.info("Status of VM is: " + statusArray);
		return statusArray;
	})					 
};

inventory.prototype.getServiceInstanceNameTextVRA=function() {
	util.waitForAngular();
	var instanceName = element.all(by.css(this.textServiceInstanceNameCss));
	browser.wait(EC.visibilityOf(instanceName.last()), 90000);
	return instanceName.getText().then(function(nameArray){
		for(var i=0; i<nameArray.length; i++) {
		   if(Boolean(nameArray[i].startsWith("dal") || nameArray[i].startsWith("vm") || nameArray[i].startsWith("Cent"))) {
			   logger.info("Service Instance Name is: " + nameArray[i]);
			   return nameArray[i];
		   }
		   else {
			   logger.info("Error: No Virtual machine found");
		   }
		}
	})
};


inventory.prototype.getCountOfVirtualMachines=function() {
	util.waitForAngular();
	var resources = element.all(by.css(this.textServiceInstanceNameCss));
	browser.wait(EC.visibilityOf(resources.last()), 90000);
	return resources.getText().then(function(nameArray){
		var count = 0;
		for(var i=0; i<nameArray.length; i++) {
		   if(Boolean(nameArray[i].startsWith("dal") || nameArray[i].startsWith("vm") || nameArray[i].startsWith("AutoVM"))) {
			   count++;
		   }
		}
		logger.info("Number of virtual machines provisioned: " + count);
		return count;
	})
};
	
inventory.prototype.clickOnActionIcon = function () { 	
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element.all(by.css(this.clickActionIconCss)).last()), 120000);
	return element.all(by.css(this.clickActionIconCss)).last().click().then(function () {
		logger.info('Clicked on Action icon');
		browser.ignoreSynchronization = false;
		util.waitForAngular();
	});
};

inventory.prototype.getTextFullTypeOutputParamValue = function () { 	
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element.all(by.css(this.fullTypeOutputParamCss)).get(1)), 120000);
	return element.all(by.css(this.fullTypeOutputParamCss)).get(1).getText().then(function (fullTypeText) {
		logger.info("Full type output param value: " +fullTypeText);
		return fullTypeText;
	});
};

//*********************** End of functions for VRA Day2 operations **************************************


//**********************Inventory View Component functions***********************************************
inventory.prototype.getViewComponentVMdetailsBasedOnLabelText = function (labelName) {
	var prop = element(by.xpath("//h5[contains(text(), '" + labelName + "')]/following-sibling::p"));
	browser.wait(EC.visibilityOf(prop), 20000);
	return prop.getText().then(function (text) {
		logger.info(labelName + " value in View Component is: " + text);
		return text;
	});
};

inventory.prototype.getViewComponentVMdetailsBasedOnLabelName = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.componentNameCss))), 30000);
	return element(by.css(this.componentNameCss)).getText().then(function (text) {
		logger.info("Name in view Component is:" + text);
		return text;
	});
};

inventory.prototype.getViewComponentTempOPPropBasedOnLabelText = function (labelName) {
	//var prop = element(by.xpath("//h5[contains(text(),'" + labelName + "')]/parent::div//div/span"));
	var prop = element(by.xpath("//h5[contains(text(),'" + labelName + "')]/../span"));
	browser.wait(EC.visibilityOf(prop), 20000);
	return prop.getText().then(function (text) {
		logger.info(labelName + " value in View Component Template Output Properties is: " + text);
		return text;
	});
};

inventory.prototype.getViewComponentTempOPPropLinkBasedOnLabelText = function (labelName) {
	var prop = element(by.xpath("//h5[contains(text(),'" + labelName + "')]/parent::div//div/a"));
	browser.wait(EC.visibilityOf(prop), 20000);
	return prop.getText().then(function (text) {
		logger.info(labelName + " link in View Component Template Output Properties is: " + text);
		return text;
	});
};

//********************End of Inventory View Component functions*********************************************
inventory.prototype.clickTurnONButtonOfInstance = function () { 	//browser.ignoreSynchronization = true;
	//browser.waitForAngular();
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.buttonTextTurnON))), 120000);
	return element(by.buttonText(this.buttonTextTurnON)).click().then(function () {
		logger.info('Clicked on Turn ON button');
		util.waitForAngular();
	});
};

inventory.prototype.clickTurnONButtonOfInstanceSNOW = function () { 	//browser.ignoreSynchronization = true;
	util.waitForAngular(); 
	var componentType = element.all(by.css(this.textComponentTypeCss));
	var status = element.all(by.css(this.textVMStatusCss));
	return componentType.getText().then(function(textArray){
		return status.getText().then(function(statusArray){
			for(var i=0; i<textArray.length; i++) {
				if(textArray[i]=="Infrastructure.Virtual" && statusArray[i]=="Off") {
		  	  		var buttonID = i + 1;
		  	  		browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-6"))),30000);
		  	  		return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-6")).click().then(function(){
		  	  			logger.info("Clicked on Turn ON button");
		  	  		});
				   }
				else {
					logger.info("Error: Status is not in OFF state");
				}
				}
		 });	  
	});
};

inventory.prototype.clickTurnONButtonOfInstanceICDS = function () { 	//browser.ignoreSynchronization = true;
	util.waitForAngular(); 
	var componentType = element.all(by.css(this.textComponentTypeCss));
	var status = element.all(by.css(this.textVMStatusCss));
	return componentType.getText().then(function(textArray){
		return status.getText().then(function(statusArray){
			for(var i=0; i<textArray.length; i++) {
				if(textArray[i]=="Infrastructure.Virtual" && statusArray[i]=="Off") {
		  	  		var buttonID = i + 1;
		  	  		browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-4-button"))),30000);
		  	  		return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-4-button")).click().then(function(){
		  	  			logger.info("Clicked on Turn ON button");
		  	  		});
				   }
				else {
					logger.info("Error: Status is not in OFF state");
				}
				}
		 });	  
	});
};

inventory.prototype.clickOkForInstanceTurnONPermission = function () {
	//util.waitForAngular();
	//this.placeD2opsOrder();
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.turnONInstanceOkButtonCss))), 140000);
	element(by.css(this.turnONInstanceOkButtonCss)).click().then(function () {
		logger.info('Clicked on Ok button for Turn ON');
	});
	util.waitForAngular();
	this.fetchD2opsOrderDetails();
};

inventory.prototype.clickTurnOFFButtonOfInstance = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.buttonTextTurnOFF))), 120000);
	return element(by.buttonText(this.buttonTextTurnOFF)).click().then(function () {
		logger.info('Clicked on Turn OFF button');
		util.waitForAngular();
	});
};

inventory.prototype.clickTurnOFFButtonOfInstanceSNOW = function () {
	util.waitForAngular();
	var componentType = element.all(by.css(this.textComponentTypeCss));
	return componentType.getText().then(function(textArray){
		   if(textArray.includes("Infrastructure.Virtual")) {
		  	  var stringID = textArray.indexOf("Infrastructure.Virtual");
		  	  var buttonID = stringID + 1;
		  	  browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-5"))),30000);
		  	  return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-5")).click().then(function(){
						logger.info("Clicked on Turn OFF button");
		  	  });	  	  
		    }
		   else {
					logger.info("Error: No Virtual machine found");
				}
		});   
};

inventory.prototype.clickTurnOFFButtonOfInstanceICDS = function () {
	util.waitForAngular();
	var componentType = element.all(by.css(this.textComponentTypeCss));
	return componentType.getText().then(function(textArray){
		   if(textArray.includes("Infrastructure.Virtual")) {
		  	  var stringID = textArray.indexOf("Infrastructure.Virtual");
		  	  var buttonID = stringID + 1;
		  	  browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-5-button"))),30000);
		  	  return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-5-button")).click().then(function(){
						logger.info("Clicked on Turn OFF button");
		  	  });	  	  
		    }
		   else {
					logger.info("Error: No Virtual machine found");
				}
		});   
};

inventory.prototype.clickOkForInstanceTurnOFFPermission = function () {
	//this.placeD2opsOrder();
	//browser.ignoreSynchronization = true;

	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.turnOFFInstanceOkButtonCss))), 140000);
	element(by.css(this.turnOFFInstanceOkButtonCss)).click().then(function () {
		logger.info('Clicked on Ok button for Turn OFF');
	});
	util.waitForAngular();
	this.fetchD2opsOrderDetails();
};

inventory.prototype.clickRebootButtonOfInstance = function () {
	// browser.ignoreSynchronization = true;
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.buttonTextReboot))), 120000);
	return element(by.buttonText(this.buttonTextReboot)).click().then(function () {
		logger.info('Clicked on Reboot button');
		util.waitForAngular();
	});
};

inventory.prototype.clickRebootButtonOfInstanceSNOW = function () {
	util.waitForAngular();
	var componentType = element.all(by.css(this.textComponentTypeCss));
	return componentType.getText().then(function(textArray){
		   if(textArray.includes("Infrastructure.Virtual")) {
		  	  var stringID = textArray.indexOf("Infrastructure.Virtual");
		  	  var buttonID = stringID + 1;
		  	  browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-4"))),30000);
		  	  return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-4")).click().then(function(){
						logger.info("Clicked on Reboot button");
		  	  });	  	  
		    }
		   else
		  	 {
		  	 		logger.info("Error: No Virtual machine found");
		  	 }
		});  
};

inventory.prototype.clickRebootButtonOfInstanceICDS = function () {
	util.waitForAngular();
	var componentType = element.all(by.css(this.textComponentTypeCss));
	return componentType.getText().then(function(textArray){
		   if(textArray.includes("Infrastructure.Virtual")) {
		  	  var stringID = textArray.indexOf("Infrastructure.Virtual");
		  	  var buttonID = stringID + 1;
		  	  browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-6-button"))),30000);
		  	  return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-6-button")).click().then(function(){
						logger.info("Clicked on Reboot button");
		  	  });	  	  
		    }
		   else
		  	 {
		  	 		logger.info("Error: No Virtual machine found");
		  	 }
		});  
};

inventory.prototype.clickOkForInstanceRebootPermission = function () {
	 browser.ignoreSynchronization = true;
	// browser.waitForAngular();
	//this.placeD2opsOrder();
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.rebootInstanceOkButtonCss))), 140000);
	element(by.css(this.rebootInstanceOkButtonCss)).click().then(function () {
		logger.info('Clicked on Ok button for Reboot');
	});
	util.waitForAngular();
	this.fetchD2opsOrderDetails();
};

inventory.prototype.clickOkForCustomOpnOrderButton = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.buttonCustomOpnOrderOkCss))), 90000);
	return element(by.css(this.buttonCustomOpnOrderOkCss)).click().then(function () {
		logger.info('Clicked on Ok button for Custom Operations order');
		util.waitForAngular();
	});
};

inventory.prototype.getCustomOpsWarningPopupText = function () {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.textCustomOpsWarningPopupCss))), 100000);
	return element(by.css(this.textCustomOpsWarningPopupCss)).getText().then(function (message) {
		logger.info('Warning message for Custom Operation negative scenario: ' + message);
		return message;
	});
};

inventory.prototype.clickCustomOpsWarningOKButton = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.buttonCustomOpsWarningOKCss))), 90000);
	return element(by.css(this.buttonCustomOpsWarningOKCss)).click().then(function () {
		logger.info('Clicked on Ok button for Custom Operations Warning popup');
		util.waitForAngular();
	});
};

inventory.prototype.clickStdOpertionsCancelButton = function () { 	
	//browser.waitForAngular();
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.buttonCancelStdOperationsCss))), 120000);
	return element(by.css(this.buttonCancelStdOperationsCss)).click().then(function () {
		logger.info('Clicked on cancel button');
	});
};

inventory.prototype.getTextOrderNumberOrderSubmittedModal = function()
{
	browser.wait(EC.visibilityOf(element(by.css(this.orderSubmittedModalOrderNumberTextCss))),90000);
    return element(by.css(this.orderSubmittedModalOrderNumberTextCss)).getText().then(function(text){
        logger.info("Order number : "+text);
        return text;
    });
};

//********************Functions for ICD Custom operations*************************************************
inventory.prototype.clickDeleteVMforInstanceICD = function()
{ 	
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element.all(by.css(this.buttonDeleteIcdVMCss)).last()), 120000);
   	return element.all(by.css(this.buttonDeleteIcdVMCss)).last().click().then(function(){
		logger.info('Clicked on Delete button for ICD instance');
	});
};

//*******************End of Functions for ICD Custom operations*******************************************

//********************Functions for VRA Custom operations*************************************************
inventory.prototype.clickAddDiskforInstanceVRA = function () {
	util.waitForAngular();
	var componentType = element.all(by.css(this.textComponentTypeCss));
	return componentType.getText().then(function(textArray){
		   if(textArray.includes("Infrastructure.Virtual")) {
		  	  var stringID = textArray.indexOf("Infrastructure.Virtual");
		  	  var buttonID = stringID + 1;
		  	  browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-4"))),30000);
		  	  return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-4")).click().then(function(){
						logger.info("Clicked on Add Disk button for VRA instance");
		  	  });	  	  
		    }
		});   
};
inventory.prototype.clickAddStorageforInstanceVRA = function () {
	util.waitForAngular();
	var componentType = element.all(by.css(this.textComponentTypeCss));
	return componentType.getText().then(function(textArray){
		   if(textArray.includes("Infrastructure.Virtual")) {
		  	  var stringID = textArray.indexOf("Infrastructure.Virtual");
		  	  var buttonID = stringID + 1;
		  	  browser.wait(EC.elementToBeClickable(element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-5"))),30000);
		  	  return element(by.css("#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-" + buttonID + "-option-5")).click().then(function(){
						logger.info("Clicked on Add storage button for VRA instance");
		  	  });	  	  
		    }
		});   
};

inventory.prototype.getCustomOpsPriceTextVRA = function () {
	browser.wait(EC.visibilityOf(element(by.css(this.textCustomOpsPriceVRACss))), 10000);
	return element(by.css(this.textCustomOpsPriceVRACss)).getText().then(function (textCustomOpsPriceVRA) {
		logger.info("Updated Cost after adding disk: " + textCustomOpsPriceVRA);
		return textCustomOpsPriceVRA;
	});
};

//
inventory.prototype.clickForwardButtonIcam = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.clickForwardButton))), 60000);
	element(by.xpath(this.clickForwardButton)).click().then(function () {
		logger.info("Clicked on forward of Virtual Machine");
	})
};

inventory.prototype.clickActionButtonForIcamAzureVM = function () {
	var self = this;
	browser.ignoreSynchronization = true;
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.powerStateOverflowMenuIconXpath))), 60000);
	var componentType = element.all(by.css(this.textComponentTypeCss));
	return componentType.getText().then(function (textArray) {
		logger.info("TestarrayContain:" + textArray);
		if (textArray.includes("Virtual Machine")) {
			var stringID = textArray.indexOf("Virtual Machine");
			var vmID = stringID + 3;
			element(by.xpath(self.glifIconXpath + "[" + vmID + "]")).click().then(function () {
				logger.info("Clicked on Action icon of Virtual Machine for Power states");
			});
		}
		else {
			logger.info("Error: No Virtual machine found");
		}
	})

	browser.ignoreSynchronization = false;
};
inventory.prototype.icamClickUntaintButtonOfIcamAzureVM = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.icamAzureVmUntaintXpath))), 60000);
	element(by.xpath(this.icamAzureVmUntaintXpath)).click().then(function () {
		logger.info("Clicked on taint of azure virtual machine");
	})
};
inventory.prototype.getTextOfToastMessageIcam = function () {
	browser.wait(EC.visibilityOf(element(by.xpath(this.TextOfToastMessageIcam))), 10000);
	return element(by.xpath(this.TextOfToastMessageIcam)).getText().then(function (text) {
		logger.info("Toast message text:" + text);
		return text;
	});
};


//*******************End of Functions for VRA Custom operations*******************************************


inventory.prototype.getComponentTags = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	var eleCompTag = element(by.xpath('//tr[@class="bx--table-row bx--parent-row bx--table-row--sub-row"]/td[6]'));
	browser.wait(EC.visibilityOf(eleCompTag), 40000);
	return eleCompTag.getText().then(function (text) {
		logger.info('Service Components are ' + text);
		logger.info('Dummy adapter : ' + text.split(",")[0] + "}");
		return text.split(",")[0] + "}";
	});
};

inventory.prototype.waitForInstancStateStatusChange = function (orderObject, expectedChangedStatus, repeatCount) {
	let self = this;
	browser.ignoreSynchronization = true;
	if (repeatCount == undefined) {
		repeatCount = 12;
	}
	browser.waitForAngular();
	browser.sleep(10000);
	this.clickExpandFirstRow();
	browser.sleep(3000);

	if (repeatCount > 0) {
		return this.clickExpandFirstRow().then(function () {
			browser.ignoreSynchronization = true;
			browser.waitForAngular();
			browser.wait(EC.elementToBeClickable(element(by.xpath('(//*[@class="bx--overflow-menu__icon"])[3]'))), 120000).then(function () {
				//browser.wait(EC.visibilityOf(element(by.xpath('(//*[@class="bx--table-column" and ../@class="bx--table-row bx--parent-row bx--table-row--sub-row bx--parent-row--even"])[3]'))), 30000).then(function(){
				//element(by.xpath('(//*[@class="bx--table-column" and ../@class="bx--table-row bx--parent-row bx--table-row--sub-row bx--parent-row--even"])[3]')).getText().then(function(text){
				//var statusElemXpath = element(by.xpath('//tr[@class="bx--table-row bx--parent-row bx--table-row--sub-row"]/td[5]'));							
				var statusElemXpath = element(by.xpath('(//tr[@class="bx--table-row bx--parent-row bx--table-row--sub-row"]/td)[5]'));
				browser.wait(EC.visibilityOf(statusElemXpath), 60000).then(function () {
					statusElemXpath.getText().then(function (text) {
						logger.info("Current Status:" + text);
						if (text == expectedChangedStatus) {
							logger.info("Instance Status is changed to: " + text);
							repeatCount = 0;
							return text;
						} else {
							browser.waitForAngular();
							browser.sleep(5000);
							logger.info("Status Check - " + repeatCount + " : Waiting for instance status to be " + expectedChangedStatus + ", current status: " + text);
							repeatCount = repeatCount - 1;
							self.waitForInstancStateStatusChange(orderObject, expectedChangedStatus, repeatCount);
						}
					});
				});
			});
		});

	}

};



inventory.prototype.getInstancePowerStateStatus = function (orderObject) {
	this.searchOrderByServiceName(orderObject.servicename);
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	var statusElemXpath = element(by.xpath('(//tr[@class="bx--table-row bx--parent-row bx--table-row--sub-row"]/td)[5]'));
	this.clickExpandFirstRow().then(function () {
		browser.ignoreSynchronization = true;
		browser.waitForAngular();
		browser.wait(EC.elementToBeClickable(element(by.xpath('(//*[@class="bx--overflow-menu__icon"])[1]'))), 60000).then(function () {
			browser.wait(EC.visibilityOf(statusElemXpath), 60000);
		});
	});
	//return element(by.xpath('(//*[@class="bx--table-column" and ../@class="bx--table-row bx--parent-row bx--table-row--sub-row bx--parent-row--even"])[3]')).getText();
	return statusElemXpath.getText();
};

inventory.prototype.clickViewComponentofAWSInstance = function () {
	//browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.sleep(4000);
	var elem = element.all(by.xpath(this.buttonXpathViewComponent));
	browser.wait(EC.elementToBeClickable(elem.get(0)), 60000).then(function(){
		logger.info("Waiting for View Component to be clickable.")
	}).catch(function(err){
		logger.info("View Component not clickable.");
	});
	return elem.last().isDisplayed().then(function(status){
		if(status == true){
			return elem.last().click().then(function () {
				logger.info('Clicked on View Component button');
			});
		}else{
			return elem.get(0).click().then(function () {
				logger.info('Clicked on View Component button');
			});
		}
	});
};

//**************** STOP : FUNCTIONS FOR D2OP (TURN ON, TURN OFF, REBOOT) OF INSTANCES***********

//***************************************AZURE VM state Function starts**********************************
//Function for Azure VM State Check
inventory.prototype.waitForAzInstancStateStatusChange = function (orderObject, expectedChangedStatus) {
	let self = this;
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.sleep(10000);
	browser.executeScript('window.scrollTo(0,0);');
	this.clickExpandFirstRow();
	browser.sleep(3000);
	this.clickExpandFirstRow().then(function () {
		browser.ignoreSynchronization = true;
		browser.waitForAngular();
		browser.wait(EC.elementToBeClickable(element(by.xpath(self.azurePowerStateOverflowMenuIconXpath))), 60000).then(function () {
			browser.wait(EC.visibilityOf(element(by.xpath(self.azVMStatus))), 30000).then(function () {
				element(by.xpath(self.azVMStatus)).getText().then(function (text) {
					logger.info("Current Status:" + text);
					if (text == expectedChangedStatus) {
						logger.info("Instance Status is changed to: " + text);
						return text;
					} else {
						browser.waitForAngular();
						browser.sleep(5000);
						self.waitForAzInstancStateStatusChange(orderObject, expectedChangedStatus);
						logger.info("Waiting for instance status to be " + expectedChangedStatus + ", current status: " + text);
					}
				});
			});
		});
	});
	return element(by.xpath(self.azVMStatus)).getText();
};

//Function for clicking on Azure VM's available operations
inventory.prototype.clickOverflowActionButtonForPowerStatesAz = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.sleep(5000);
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.azurePowerStateOverflowMenuIconXpath))), 70000);
	return element(by.xpath(this.azurePowerStateOverflowMenuIconXpath)).click();
};

//Function for Turn Off Azure VM
inventory.prototype.azClickTurnOFFButtonOfInstance = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.azTurnOFFCss))), 30000);
	return element(by.css(this.azTurnOFFCss)).click().then(function () {
		logger.info('Clicked on Turn OFF button');
	});
};

//Function for Turn Off Azure VM - SNOW
inventory.prototype.azClickTurnOFFButtonOfInstanceSNOW = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.azTurnOFFSNOWCss))), 30000);
	return element(by.css(this.azTurnOFFSNOWCss)).click().then(function () {
		logger.info('Clicked on Turn OFF button');
	});
};

//Function for Turn On Azure VM
inventory.prototype.azClickTurnONButtonOfInstance = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.azTurnONCss))), 30000);
	return element(by.css(this.azTurnONCss)).click().then(function () {
		logger.info('Clicked on Turn ON button');
	});
};

//Function for Turn On Azure VM - SNOW
inventory.prototype.azClickTurnONButtonOfInstanceSNOW = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.azTurnONSNOWCss))), 30000);
	return element(by.css(this.azTurnONSNOWCss)).click().then(function () {
		logger.info('Clicked on Turn ON button');
	});
};

//Function for Reboot Azure VM
inventory.prototype.azClickRebootButtonOfInstance = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.azRebootCss))), 30000);
	return element(by.css(this.azRebootCss)).click().then(function () {
		logger.info('Clicked on Reboot button');
	});
};

//Function for Reboot Azure VM - SNOW
inventory.prototype.azClickRebootButtonOfInstanceSNOW = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.azRebootSNOWCss))), 30000);
	return element(by.css(this.azRebootSNOWCss)).click().then(function () {
		logger.info('Clicked on Reboot button');
	});
};

//Function for Turn Off Azure VM dummy
inventory.prototype.azClickTurnOFFButtonDummyOfInstance = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.azTurnOFFDummyCss))), 60000);
	return element(by.css(this.azTurnOFFDummyCss)).click().then(function () {
		logger.info('Clicked on Turn OFF button');
	});
};

//Function for Turn On Azure VM dummy
inventory.prototype.azClickTurnONButtonDummyOfInstance = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.azTurnONDummyCss))), 60000);
	return element(by.css(this.azTurnONDummyCss)).click().then(function () {
		logger.info('Clicked on Turn ON button');
	});
};

//Function for Reboot Azure VM Dummy
inventory.prototype.azClickRebootButtonDummyOfInstance = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.azRebootDummyCss))), 60000);
	return element(by.css(this.azRebootDummyCss)).click().then(function () {
		logger.info('Clicked on Reboot button');
	});
};
//***************************************AZURE VM state Function Ends**********************************

//*********************************Alibaba VM standard operations function start*************************

//Function for clicking on Alibaba VM's available operations
inventory.prototype.clickOverflowActionButtonForPowerStatesAli = function () {
	browser.waitForAngular();
	browser.sleep(5000);
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.alibabaPowerStateOverFlowMenuIconXpath))), 70000);
	return element(by.xpath(this.alibabaPowerStateOverFlowMenuIconXpath)).click().then(function () {
		logger.info('Clicked on action icon of virtual machine')
	});

};

//****************************Alibaba VM standard operations function end******************************


//This function is used to call import API and return response of it
inventory.prototype.callImportAPI = function () {
	return "response"
}

inventory.prototype.isExistsFirstChildComponent = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.sOCFirstChildComponentXpath))), 5000);
	element(by.xpath(this.sOCFirstChildComponentXpath)).isPresent().then(function (present) {
		return present
	});
};

inventory.prototype.iscomponentTypePropAvailable = function () {
	element(by.xpath(this.componentTypePropXpath)).isPresent().then(function (present) {
		return present
	});
};

inventory.prototype.clickTurnOffActionMenuOption = function () {
	element(by.css(this.turnOffActionMenuOptionCss)).click();
	util.waitForAngular();
};

inventory.prototype.clickTurnOffOakybutton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.turnOffserviceOkayCss))), 5000);
	return element(by.css(this.turnOffserviceOkayCss)).click();
};

inventory.prototype.clickTurnOnActionMenuOption = function () {
	element(by.css(this.turnOnActionMenuOptionCss)).click();
	util.waitForAngular();
};

inventory.prototype.clickTurnOnOakybutton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.turnOnserviceOkayCss))), 5000);
	return element(by.css(this.turnOnserviceOkayCss)).click();
};

inventory.prototype.clickRebootActionMenuOption = function () {
	element(by.css(this.RebootActionMenuOptionCss)).click();
	util.waitForAngular();
};

inventory.prototype.clickRebootOakybutton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.rebootserviceOkayCss))), 5000);
	return element(by.css(this.rebootserviceOkayCss)).click();
};

inventory.prototype.clickAccessComponentActionMenuOption = function () {
	element(by.xpath(this.accessComponentActionMenuOptionXpath)).click();
	util.waitForAngular();
};

inventory.prototype.clickRefreshStatusActionMenuOption = function () {
	element(by.xpath(this.refreshStatusActionMenuOptionXpath)).click();
	util.waitForAngular();
};

inventory.prototype.clickRefreshStatusOakybutton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.refreshStatusOkayCss))), 5000);
	return element(by.css(this.refreshStatusOkayCss)).click();
};

inventory.prototype.clickRefreshStatusOKbutton = function () {
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.refreshStatusOkXpath))), 5000);
	return element(by.xpath(this.refreshStatusOkXpath)).click();
};

inventory.prototype.getDeleteOrderNumber = function () {
	
	return browser.wait(EC.visibilityOf(element(by.xpath(this.deleteServiceInfoTooltipXpath))), 70000).then(function () {
		logger.info("Waited till Delete Service Info tool tip appears");
		return element(by.xpath(defaultConfig.deleteOrderNumberXpath)).getText().then(function (text) {
			logger.info("Delete Service Message - " + text);
			var deleteOrderNumber = text.toString().split(":")[1];
			logger.info("Delete Order Number:" + deleteOrderNumber.trim());
			return deleteOrderNumber.trim();
		});
	}).catch(function(err){
		logger.info("Order Id is not captured on Inventory page");
		return "";
	});
};

/*inventory.prototype.getDeleteOrderNumber = function () {
	//util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.deleteServiceInfoTooltipXpath))), 150000).then(function () {
		logger.info("Waited till Delete Service Info tool tip appears");
	});
	
	browser.wait(EC.visibilityOf(element(by.xpath(this.deleteOrderNumberXpath))), 150000)
	return element(by.xpath(this.deleteOrderNumberXpath)).getText().then(function (text) {
		logger.info("Delete Service Message - " + text);
		var deleteOrderNumber = text.toString().split(":")[1];
		logger.info("Delete Order Number:" + deleteOrderNumber.trim());
		return deleteOrderNumber.trim();
	});
};*/

inventory.prototype.selectOptionsMenu = function (index) {
	var optionsIndexXpath = "//*[@id='carbon-deluxe-data-table-0-parent-row-1-child-row-" + index + "-overflow-menu-icon']"
	console.log("indexXapth = " + optionsIndexXpath)
	browser.wait(EC.elementToBeClickable(element(by.xpath(optionsIndexXpath))), 5000);
	return element(by.xpath(optionsIndexXpath)).click();
}
inventory.prototype.clickViewComponent = function (index) {
	var viewComponentIndexCss = "#carbon-deluxe-data-table-0-parent-row-1-child-row-" + index + "-option-5-button"
	browser.wait(EC.elementToBeClickable(element(by.css(this.viewComponentIndexCss))), 5000);
	return element(by.css(this.viewComponentIndexCss)).click();
}
inventory.prototype.getMachineName = function (machineNameFromAPI) {
	return element(by.xpath(this.machineNameXpath)).getAttribute("value").then(function (value) {
		console.log("MachineNameFromUI: " + value);
		expect(value).toEqual(machineNameFromAPI);
	});
}
inventory.prototype.getserviceInstanceName = function () {
	return element(by.xpath(this.serviceInstanceNameXpath)).getText().then(function (arr) {
		var serviceName = ""
		for (var i = 0; i < arr.length; i++) {
			serviceName = serviceName + arr[i]
		}
		return serviceName;
	})

}

inventory.prototype.getCPUConfigValue = function () {
	return element(by.xpath(this.cpuConfigXpath)).getText().then(function (arr) {
		var cpuConfig = ""
		for (var i = 0; i < arr.length; i++) {
			cpuConfig = cpuConfig + arr[i]
		}
		return cpuConfig;
	})

}

inventory.prototype.clickSliderCloseIcon = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.sliderCloseIconCss))), 5000);
	return element(by.css(this.sliderCloseIconCss)).click();

}

inventory.prototype.clickViewComponentSliderCloseButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.viewComponentSliderCloseButtonXpath))), 5000);
	return element(by.css(this.viewComponentSliderCloseButtonXpath)).click();

}

inventory.prototype.clicksocFirstChildGlificon = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.socFirstChildGlificonXpath))), 5000);
	return element(by.xpath(this.socFirstChildGlificonXpath)).click();
}

inventory.prototype.clicksocSecondChildGlificon = function () {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.socSecondChildGlificonXpath))), 5000);
	return element(by.xpath(this.socSecondChildGlificonXpath)).click();
}

inventory.prototype.verifySOC = function () {
	var compType = element(by.css(this.textComponentTypeCss)).getAttribute('innerText').then(function (arr) {
		var componentType = ""
		for (var i = 0; i < arr.length; i++) {
			componentType = componentType + arr[i]
		}
		if ((componentType.toString()).indexOf("Infrastructure.Network.Network.Existing") >= 0) {
			console.log("Component Type : " + componentType)

		} else if ((componentType.toString()).indexOf("Infrastructure.Virtual") >= 0) {
			console.log("Component Type : " + componentType)
		}
		return componentType;
	})


}



inventory.prototype.getRefreshStatusDialogConfirmText = function () {
	return element(by.xpath(this.refreshStatusDialogConfirmTextXpath)).getText().then(function (arr) {
		var confirmText = ""
		for (var i = 0; i < arr.length; i++) {
			confirmText = confirmText + arr[i]
		}
		return confirmText;
	})
}

inventory.prototype.getsoiStatus = function () {
	return element(by.xpath(this.soiStatusXpath)).getText().then(function (arr) {
		var status = ""
		console.log("array length")
		console.log(arr.length)
		for (var i = 0; i < arr.length; i++) {
			status = status + arr[i]
		}
		return status;
	})
}

inventory.prototype.findisVM = function () {

	this.clicksocFirstChildGlificon();
	util.waitForAngular();
	this.clickViewComponentActionMenuOption();
	var compType = element(by.css(this.textComponentTypeCss)).getAttribute('innerText').then(function (arr) {
		var componentType = ""
		for (var i = 0; i < arr.length; i++) {
			componentType = componentType + arr[i]
		}
		if ((componentType.toString()).indexOf("Infrastructure.Network.Network.Existing") >= 0) {
			console.log("Component Type : " + componentType)
			console.log("Selecting VM component next to perform operations")
			isVM = false
		} else if ((componentType.toString()).indexOf("Infrastructure.Virtual") >= 0) {
			console.log("Component Type : " + componentType)
			isVM = true
		}
		console.log("inner loop isvm")
		console.log(isVM)
		return isVM;
	})

	return protractor.promise.all([compType]).then(function (values) {
		console.log("isvm")
		console.log(isVM)
		return isVM
	});
}

inventory.prototype.testRebootFirst = function () {
	console.log("calling second second")
	browser.sleep(3000);
	element.all(by.css(this.viewComponentSliderCloseButtonCss)).get(1).click();
	browser.sleep(3000);
	logger.info("Clicked on slider close button");

	//Verify reboot
	element(by.xpath(this.socFirstChildGlificonXpath)).click()
	browser.sleep(3000);
	logger.info("Clicked on first child Glificon button");
	element(by.css(this.RebootActionMenuFirstOptionCss)).click()
	browser.sleep(3000);
	logger.info("Clicked on Reboot action button");
	element(by.css(this.rebootserviceOkayCss)).click()
	logger.info("Clicked on Reboot OK button in Confirmation dialog");
	this.verifyActionStatusRebootFirst(60)

}
inventory.prototype.testRebootSecond = function () {
	console.log("calling second second")
	browser.sleep(3000);
	element.all(by.css(this.viewComponentSliderCloseButtonCss)).get(1).click();
	browser.sleep(3000);
	logger.info("Clicked on slider close button");

	//Verify reboot
	element(by.xpath(this.socSecondChildGlificonXpath)).click()
	browser.sleep(3000);
	logger.info("Clicked on second child Glificon button");
	element(by.css(this.RebootActionMenuSecondOptionCss)).click()
	browser.sleep(3000);
	logger.info("Clicked on Reboot action button");
	element(by.css(this.rebootserviceOkayCss)).click()
	logger.info("Clicked on Reboot OK button in Confirmation dialog");
	this.verifyActionStatusRebootSecond(60)

}

inventory.prototype.testTurnOffFirst = function () {
	console.log("calling second second")
	browser.sleep(8000);

	//Verify turn off
	element(by.xpath(this.socFirstChildGlificonXpath)).click()
	browser.sleep(3000);
	logger.info("Clicked on first child Glificon button");
	element(by.css(this.turnOffActionMenuFirstOptionCss)).click()
	browser.sleep(3000);
	logger.info("Clicked on Turn Off action button");
	element(by.css(this.turnOffserviceOkayCss)).click()
	logger.info("Clicked on Turn Off OK button in Confirmation dialog");
	this.verifyActionStatusTurnOffFirst(60)

}

inventory.prototype.testTurnOffSecond = function () {
	console.log("calling second second")
	browser.sleep(8000);

	//Verify turn off
	element(by.xpath(this.socSecondChildGlificonXpath)).click()
	browser.sleep(3000);
	logger.info("Clicked on second child Glificon button");
	element(by.css(this.turnOffActionMenuSecondOptionCss)).click()
	browser.sleep(3000);
	logger.info("Clicked on Turn Off action button");
	element(by.css(this.turnOffserviceOkayCss)).click()
	logger.info("Clicked on Turn Off OK button in Confirmation dialog");
	this.verifyActionStatusTurnOffSecond(60)

}

inventory.prototype.testTurnOnFirst = function () {
	console.log("calling second second")
	browser.sleep(20000);

	//Verify turn on
	element(by.xpath(this.socFirstChildGlificonXpath)).click()
	browser.sleep(3000);
	logger.info("Clicked on first child Glificon button");
	element(by.css(this.turnOnActionMenuFirstOptionCss)).click()
	browser.sleep(3000);
	logger.info("Clicked on Turn On action button");
	element(by.css(this.turnOnserviceOkayCss)).click()
	logger.info("Clicked on Turn On OK button in Confirmation dialog");
	this.verifyActionStatusTurnOnFirst(60)

}

inventory.prototype.testTurnOnSecond = function () {
	console.log("calling second second")
	browser.sleep(25000);

	//Verify turn on
	element(by.xpath(this.socSecondChildGlificonXpath)).click()
	browser.sleep(3000);
	logger.info("Clicked on second child Glificon button");
	element(by.css(this.turnOnActionMenuSecondOptionCss)).click(),
		browser.sleep(3000);
	logger.info("Clicked on Turn On action button");
	element(by.css(this.turnOnserviceOkayCss)).click()
	logger.info("Clicked on Turn On OK button in Confirmation dialog");
	this.verifyActionStatusTurnOnSecond(60)

}

inventory.prototype.getsocStatusFirst = function () {
	return element(by.xpath(this.socStatusFirstXpath)).getText().then(function (text) {
		actstatus = text;
		return text
	})
}

inventory.prototype.getsocStatusSecond = function () {
	return element(by.xpath(this.socStatusSecondXpath)).getText().then(function (text) {
		actstatus = text;
		return text
	})
}

inventory.prototype.verifyActionStatusRebootFirst = function (repeatCount) {
	var brk = 0
	repeatCount = repeatCount - 1;

	if (repeatCount > 0 && (brk == 0)) {
		this.getsocStatusFirst().then(function (values) {
			if (values.toString().indexOf("Rebooting") >= 0) {
				//				console.log("Rebooting.... Breaking the loop")
				brk = 1
			} else {
				browser.sleep(3000);
				console.log(repeatCount)
				brk = 0
			}
		})

		if (brk == 0) {
			this.verifyActionStatusRebootFirst(repeatCount);
		} else {
			return;
		}
	} else {
		console.log("repeat count incorrect")
	}
}

inventory.prototype.verifyActionStatusRebootSecond = function (repeatCount) {
	var brk = 0
	repeatCount = repeatCount - 1;

	if (repeatCount > 0 && (brk == 0)) {
		this.getsocStatusSecond().then(function (values) {

			if (values.toString().indexOf("Rebooting") >= 0) {
				//				console.log("Rebooting.... Breaking the loop")
				brk = 1
			} else {
				browser.sleep(3000);
				console.log(repeatCount)
				brk = 0
			}
		})

		if (brk == 0) {
			this.verifyActionStatusRebootSecond(repeatCount);
		} else {
			return;
		}
	} else {
		console.log("repeat count incorrect")
	}
}

inventory.prototype.verifyActionStatusTurnOffFirst = function (repeatCount) {
	var brk = 0
	repeatCount = repeatCount - 1;

	if (repeatCount > 0 && (brk == 0)) {
		this.getsocStatusFirst().then(function (values) {

			if (values.toString().indexOf("TurningOff") >= 0) {
				//				console.log("Turning Off.... Breaking the loop")
				brk = 1
			} else {
				browser.sleep(3000);
				console.log(repeatCount)
				brk = 0
			}
		})

		if (brk == 0) {
			this.verifyActionStatusTurnOffFirst(repeatCount);
		} else {
			return;
		}
	} else {
		console.log("repeat count incorrect")
	}

}

inventory.prototype.verifyActionStatusTurnOffSecond = function (repeatCount) {
	var brk = 0
	repeatCount = repeatCount - 1;

	if (repeatCount > 0 && (brk == 0)) {
		this.getsocStatusSecond().then(function (values) {

			if (values.toString().indexOf("TurningOff") >= 0) {
				//				console.log("Turning Off.... Breaking the loop")
				brk = 1
			} else {
				browser.sleep(3000);
				console.log(repeatCount)
				brk = 0
			}
		})

		if (brk == 0) {
			this.verifyActionStatusTurnOffSecond(repeatCount);
		} else {
			return;
		}
	} else {
		console.log("repeat count incorrect")
	}
}

inventory.prototype.verifyActionStatusTurnOnFirst = function (repeatCount) {
	var brk = 0
	repeatCount = repeatCount - 1;

	if (repeatCount > 0 && (brk == 0)) {
		this.getsocStatusFirst().then(function (values) {

			if (values.toString().indexOf("TurningOn") >= 0) {
				//				console.log("Turning On.... Breaking the loop")
				brk = 1
			} else {
				browser.sleep(3000);
				console.log(repeatCount)
				brk = 0
			}
		})

		if (brk == 0) {
			this.verifyActionStatusTurnOnFirst(repeatCount);
		} else {
			return;
		}
	} else {
		console.log("repeat count incorrect")
	}

}

inventory.prototype.verifyActionStatusTurnOnSecond = function (repeatCount) {
	var brk = 0
	repeatCount = repeatCount - 1;

	if (repeatCount > 0 && (brk == 0)) {
		this.getsocStatusSecond().then(function (values) {
			if (values.toString().indexOf("TurningOn") >= 0) {
				//				console.log("Turning On.... Breaking the loop")
				brk = 1
			} else {
				browser.sleep(3000);
				console.log(repeatCount)
				brk = 0
			}
		})

		if (brk == 0) {
			this.verifyActionStatusTurnOnSecond(repeatCount);
		} else {
			return;
		}
	} else {
		console.log("repeat count incorrect")
	}

}

//Additional Details Section

inventory.prototype.getTextBasedOnLabelName = function (labelName) {
	var latelTextElement = element.all(by.xpath("//span[contains(text(), '" + labelName + "')]/following-sibling::span"));
	browser.executeScript('window.scrollTo(0,0);');
	//browser.sleep(10000);
	browser.wait(EC.visibilityOf(latelTextElement.last()), 90000);
	return latelTextElement.last().getText().then(function (text) {
		logger.info("The value for " + labelName + " is : " + text)
		return text;
	});
};

// Fetch Service Offering Instance Name from View Service of Inventory Page using text and index
inventory.prototype.getTextServiceInstanceNameAndIndex = function (labelName, index) {
	var latelTextElement = element.all(by.xpath("//span[contains(text(), '" + labelName + "')]/following-sibling::span"));
	browser.executeScript('window.scrollTo(0,0);');
	browser.wait(EC.visibilityOf(latelTextElement.get(index)), 90000);
	return latelTextElement.getText().then(function(textArray){
        logger.info("The value for "+labelName+" is : " + textArray[index])
        return textArray[index];
    });
};

// Fetch Service Offering Instance Name from View Service of Inventory Page
inventory.prototype.getTextServiceInstanceName = function (SerivceLabelName) {
	var InstanceName = element(by.xpath("//h5[contains(text(), '" + SerivceLabelName + "')]/following-sibling::p"));
	browser.wait(EC.visibilityOf(InstanceName), 60000);
	return InstanceName.getText().then(function (text) {
		logger.info("The value for " + SerivceLabelName + " is : " + text)
		return text;

	});
};

//Fetch Service Offering Instance name from Inventory Page
inventory.prototype.getTextInventorySOIName = function () {
	var ServiceInstanceName = element(by.css(this.soiNameCss));
	browser.wait(EC.visibilityOf(ServiceInstanceName), 60000);
	return ServiceInstanceName.getText().then(function (text) {
		logger.info("The value for Service Offering Instance name is : " + text)
		return text;
	});
};

//****************** Accounts functions ************

inventory.prototype.clickUserIcon = function () {
	return element(by.css(this.userIconCss)).click();
	util.waitForAngular();
};

inventory.prototype.clickAccountsMenuItem = function () {
	return element(by.css(this.accountsMenuItemCss)).click();
	util.waitForAngular();
};

inventory.prototype.clickEditInstance = function () {
	var curr = this;
	return element.all(by.css(this.instanceTableActionIconCss)).first().click().then(function () {
		logger.info("Clicked on the Actions icon from the first row on Inventory page");
		browser.wait(EC.elementToBeClickable(element(by.buttonText(curr.buttonTextEditService))), 120000);
		return element(by.buttonText(curr.buttonTextEditService)).click().then(function () {
			logger.info("Clicked on Edit Service button");
			util.waitForAngular();
			browser.wait(EC.elementToBeClickable(element(by.css(curr.editServiceNextButtonCss))), 120000);

		});

	});
};
inventory.prototype.clickNonEditableInstance = function () {
	var curr = this;
	return element.all(by.css(this.instanceTableActionIconCss)).first().click().then(function () {
		logger.info("Clicked on the Actions icon from the first row on Inventory page");
		browser.wait(EC.elementToBeClickable(element(by.buttonText(curr.buttonTextEditService))), 120000);
		return element(by.buttonText(curr.buttonTextEditService)).click().then(function () {
			logger.info("Clicked on Edit Service button");
			util.waitForAngular();
		});

	});
};

inventory.prototype.clickAvailableVersionIcon = function () {
	var curr = this;
	browser.wait(EC.elementToBeClickable(element(by.buttonText(curr.buttonTextAvailableVersion))), 120000);
	return element(by.buttonText(curr.buttonTextAvailableVersion)).click().then(function () {
		logger.info("Clicked on Available version button now to Upgrade the service..");
		util.waitForAngular();
	});
};

inventory.prototype.clickforchangeversionfromV1ToV2forICAM = function () {
	var curr = this;
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(curr.changeavailableversionToUpgradeCss))), 120000);
	return element(by.css(curr.changeavailableversionToUpgradeCss)).click().then(function () {
		logger.info("Clicked on version number 2 successfully to Upgrade the Service..");
		util.waitForAngular();
	});
};

inventory.prototype.clickforchangeversionfromV2ToV1forICAM = function () {
	var curr = this;
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(curr.changeavailableversionToDowngradeCss))), 120000);
	return element(by.css(curr.changeavailableversionToDowngradeCss)).click().then(function () {
		logger.info("Clicked on version number 1 successfully to Downgrade the Service..");
		util.waitForAngular();
	});
};


inventory.prototype.clickOverflowActionButtonForAddRecordSet = function () {
	browser.ignoreSynchronization = true;
	util.waitForAngular();
	var elemToClick = element.all(by.css(this.addRecordsetTableActionIconCss));
	browser.wait(EC.elementToBeClickable(elemToClick), 30000);

	return elemToClick.click().then(function () {
		logger.info("Succesfully clicked on Action button for Recordset option");
		util.waitForAngular();
	});
};

inventory.prototype.clickAddRecordSet = function () {
	var self = this;
	var elemToClick = element.all(by.buttonText(this.addRecordSetText));
	browser.wait(EC.elementToBeClickable(elemToClick.last()), 30000);
	return elemToClick.last().click().then(function () {
		logger.info('Clicked on Add Recordset button');
		util.waitForAngular();
		self.placeD2opsOrder();
	});
};

inventory.prototype.fillDnsRecordSetDetails = function () {

	browser.wait(EC.elementToBeClickable(element(by.css('input#text-input-dnsName'), 50000)));
	element(by.css('#text-input-dnsName')).sendKeys("auto-qa-test").then(function () {
		logger.info('DNS Name is succesfully entered');
	});

	element(by.css('#text-input-ttl')).sendKeys("2").then(function () {
		logger.info('TTL is succesfully entered');
	});

	element(by.css('#text-input-ipv4_address')).sendKeys("192.168.22.10").then(function () {
		logger.info('IPv4 Address is succesfully entered');
	});
	//Click on Next button
	element(by.buttonText('Next')).click().then(function () {
		logger.info("Succesfully filled details for DNS Recordset")
		util.waitForAngular();
	});

};
inventory.prototype.clickNextButton = function () {
	browser.sleep(3000);
	browser.wait(EC.elementToBeClickable(element(by.css(this.textNextButtonCss))), 50000);
	element(by.css(this.textNextButtonCss)).click().then(function () {
		logger.info("Clicked on Main Parameters Next button");
	});
};
inventory.prototype.clickOverMenuIcon = function (i) {
	//browser.ignoreSynchronization = true;
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css('#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-' + i +'-overflow-menu-icon'))), 100000);
	return element(by.css('#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-' + i +'-overflow-menu-icon')).click().then(function () {
		logger.info("clicked on Menu Icon");
		util.waitForAngular();
	})

};
inventory.prototype.getComponentName = function (componentName) {
	browser.wait(EC.visibilityOf(element(by.css(this.componentNameCss))), 10000);
	return element(by.css(this.componentNameCss)).getText().then(function (text) {
		for (var i = 0; i < componentName.length; i++) {
			if (componentName[i] == text) {
				logger.info("SOI Component name : " + text);
				return true;
			}
		}
	})

};


inventory.prototype.verifyComponentName = function(componentName){

    return new Promise((resolve, reject)=>{

		browser.wait(EC.visibilityOf(element(by.id(this.componentNameCss))), 10000);
			return element.all(by.css(this.componentNameCss)).getText().then(function (text) {
				for (var i = 0; i < componentName.length; i++) {
					if (componentName[i] == text) {
						logger.info("SOI Component name : " + text);
						return resolve(true);
					}
				}
			})

    });


}


inventory.prototype.closeViewComponent = function () {
	let ele = element(by.cssContainingText(this.closeViewButton, 'Close'));
	browser.wait(EC.elementToBeClickable(ele), 30000);
	return ele.click().then(function () {
		logger.info('Close View Components window');
	})

};

inventory.prototype.clickOnViewComponent = function (index) {
	//browser.ignoreSynchronization = true;
	//browser.waitForAngular();
	browser.sleep(5000);
	browser.wait(EC.visibilityOf(element(by.css('#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-' + index + '-option-3-button'))), 60000);
	browser.wait(EC.elementToBeClickable(element(by.css('#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-' + index + '-option-3-button'))), 60000);
	return element(by.css('#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-' + index + '-option-3-button')).click().then(
		function () {
			logger.info('Clicked on View Component button');
			util.waitForAngular();
		}
	)
};

inventory.prototype.verifyOutputParams = function (inputServiceConfiguration, orderObject) {
	var inventoryPage = new inventory();
	var field,fieldValue;
	browser.waitForAngular();

	this.open();
	this.searchOrderByServiceName(orderObject.servicename);
	
	element.all(by.css(this.instanceTableActionIconCss)).first().click().then(function () {
		logger.info("Clicked on the Actions icon from the first row on Inventory page");
	});
	
	this.clickViewService();	
		
	var ele = element.all(by.xpath(this.outputParamsXpath));
	return ele.getText().then(function(arryList){
		for(var i = 0; i <= arryList.length -1; i += 2){
			field = arryList[i];
			fieldValue = arryList[i + 1];			
			if((fieldValue != "" && field != "") && (fieldValue != "undefined" && fieldValue != undefined)){
				if(fieldValue.includes(",")){
					var fielValues = fieldValue.split(",");
					if(fielValues[1] == ""){
						fieldValue = fieldValue + arryList[i + 2];
						i=i+1;
					}	
				}				
				if(inputServiceConfiguration["Actual"][field] = fieldValue){
					logger.info("Output param - " + field + " = " + fieldValue);
				}else{
					logger.info("Output param - Actual --> " + field + " = " + fieldValue + " | Expected --> " + field + " = " + inputServiceConfiguration["Actual"][field]);
					return false;
				}
			}	
		}
		return inventoryPage.closeViewComponent().then(function(){
			return true;	
		});
	
	});	
};


inventory.prototype.clickLabelsViewDetailsLink = function (i) {
	browser.ignoreSynchronization = true;
	browser.waitForAngular();
	var elemToClick = element(by.xpath(this.linkServiceDetailsLabelsXpath));
	browser.wait(EC.elementToBeClickable(elemToClick), 100000);
	return browser.executeScript("arguments[0].click();", elemToClick);
	//Commenting below non-working code
	/*return elemToClick.click().then(function () {
		logger.info("clicked on Labels-->View Details");
		util.waitForAngular();
	})*/
};

inventory.prototype.validateSystemTagValueIsDisplayed = function () {	
	var elemTag = element(by.xpath(this.txtSystemTagValueFieldXpath));
	browser.wait(EC.visibilityOf(elemTag), 100000);
	return elemTag.isDisplayed().then(function (status) {
		if(status == true){
			logger.info("System tag for VM is displayed under labels link.");
			return true;
		}else{
			return false;
		}		
	});
};

inventory.prototype.getSystemTagLabel = function () {	
	var elemTagValue = element(by.xpath(this.txtSystemTagValueFieldXpath));
	browser.wait(EC.visibilityOf(elemTagValue), 100000);
	return elemTagValue.getText().then(function (text) {
		logger.info("System Tag for compute engine is : " + text);
		return text;
	});
};


inventory.prototype.getInstancePowerStateStatusAzure = function (orderObject) {
	util.waitForAngular();
	var self = this;
	var status = element.all(by.css(this.textVMStatusCss));
	browser.wait(EC.visibilityOf(status.last()), 90000);
	return status.getText().then(function(statusArray) {
		logger.info("Status of VM is: " + statusArray);
		return statusArray;
	})

};
inventory.prototype.getTagsOnInventory = function () {
	util.waitForAngular();
	//Sync completely with page.
	browser.sleep(3000);
	var elemTagValue = element.all(by.css(this.TagCss));
	//browser.wait(EC.visibilityOf(elemTagValue), 9000);
	return elemTagValue.getText().then(function (text) {
		text = text.toString();
		logger.info("System Tag  is : " + text);
		return text;
	})
};


 //Function for clicking on ICAM VM's available operations
 inventory.prototype.clickOverflowActionButtonForPowerStatesIcam = function () {
	var self = this;
	browser.ignoreSynchronization = true;
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.powerStateOverflowMenuIconXpath))), 60000);
	
	var componentType = element.all(by.css(this.textComponentTypeCss));
	return componentType.getText().then(function(textArray){
		   if(textArray.includes("Virtual Machine")) {
		  	  var stringID = textArray.indexOf("Virtual Machine");
		  	  var vmID = stringID + 3;
		  	  element(by.xpath(self.glifIconXpath + "[" + vmID + "]")).click().then(function(){
						logger.info("Clicked on Action icon of Virtual Machine for Power states");
		  	  });
		   }
		   else {
					logger.info("Error: No Virtual machine found");
				}
	})
	
	
};

inventory.prototype.clickViewAddOnDetails = function (orderObject) {
	this.open();
	this.searchOrderByServiceName(orderObject.servicename);
	return element.all(by.css(this.instanceTableActionIconCss)).first().click().then(function () {
		logger.info("Clicked on the Actions icon from the first row on Inventory page");
		var elemTagValue = element.all(by.css(defaultConfig.btnRightArrowCss));
		elemTagValue.get(1).click().then(function () {
			logger.info("Clicked on Action icon for view Add On");
			var elemViewAddOn = element.all(by.css(defaultConfig.btnViewAddOnCss));
			browser.wait(EC.elementToBeClickable(elemViewAddOn.get(1)), 30000);
			return elemViewAddOn.get(1).click().then(function () {
				logger.info("Clicked on view Add On button");	
				util.waitForAngular();
			});		
		});	
	});
};

inventory.prototype.clickBillOfMaterialsTabOrderDetails = function(){
	var elemBom = element(by.css(this.btnBillOfMaterailsCss));
	browser.wait(EC.elementToBeClickable(elemBom),90000);
	return elemBom.click().then(function(){
		logger.info("Clicked on Bill of Materials tab");
	});
};

inventory.prototype.clickMoreLinkinBom = function(){
	var elemMore = element(by.css(this.lnkMoreCss));
	browser.wait(EC.elementToBeClickable(elemMore),20000);
	return elemMore.click().then(function(){
		logger.info("Clicked on Bill of Materials tab");
	});
};

inventory.prototype.getTextEstimatedCost = function(){
	var elemCost = element(by.css(this.txtEstimtdCostCss));	
	return elemCost.getText().then(function(text){
		logger.info("Estimated Cost for Add On in Inventory page is " + text);
		return text;
	});
};

inventory.prototype.getImiTags = function(orderObject){
	var indexOfElem = 0;
	var self = this;
	this.open();
	this.searchOrderByServiceName(orderObject.servicename);
	this.clickExpandFirstRow();
	if(orderObject.componentType == undefined){
		this.clickOverflowActionButtonForPowerStates();
	}else{
		this.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function(index){
			indexOfElem = index;
		});
	}	
	this.clickViewComponentofAWSInstance().then(function(){
		logger.info("Clicked on view componenet");
	}).catch( function(err){
		self.clickViewComponentBasedOnIndex(indexOfElem - 1);
	});
	//Get all the tags
	return  this.getTagsOnInventory();					
};

inventory.prototype.getTextBasedOnLabelNameandIndex = function(labelName, index){
    browser.ignoreSynchronization = true;
    util.waitForAngular();	
    browser.sleep(3000);
    browser.wait(EC.visibilityOf(element.all(by.xpath("//h5[contains(text(),'" + labelName + "')]/following-sibling::p")).get(index)),80000);
    var elemList = element.all(by.xpath("//h5[contains(text(),'" + labelName + "')]/following-sibling::p"));
    //browser.wait(EC.visibilityOf(elemList), 60000);
    return elemList.getText().then(function(textArray){
        logger.info("The value for "+labelName+" is : " + textArray[index])
        return textArray[index];
    });
};

inventory.prototype.clickConfigureImiService = function(){
	var self = this;
	util.waitForAngular();
	browser.sleep(2000);
	var elem = element.all(by.xpath(this.lnkConfigureImiXpath));
	browser.wait(EC.elementToBeClickable(elem.last()), 60000);
	return elem.last().click().then(function(textArray){
		logger.info("Clicked on Configure IMI Managed Service button");
		util.waitForAngular();
		self.placeD2opsOrder();
	});
};

inventory.prototype.clickConfigureImiServicefirst = function(){
	var self = this;
	var elem = element.all(by.xpath(this.lnkConfigureImiXpath));
	browser.wait(EC.elementToBeClickable(elem.first()), 60000);
	return elem.first().click().then(function(textArray){
		logger.info("Clicked on Configure IMI Managed Service button");
		util.waitForAngular();
		self.placeD2opsOrder();
	});
};
inventory.prototype.clickConfigureImiServicelast = function(){
	var self = this;
	var elem = element.all(by.xpath(this.lnkConfigureImiXpath));	
	browser.wait(EC.elementToBeClickable(elem.last()), 60000);
	return elem.last().click().then(function(textArray){
        logger.info("Clicked on Configure IMI Managed Service button");
        util.waitForAngular();
	self.placeD2opsOrder();	
    });
};

inventory.prototype.clikFirstSOCMenu = function () {
    browser.ignoreSynchronization = true;
    browser.waitForAngular();
    var elem = element.all(by.xpath(this.powerStateOverflowMenuIconXpath));
    browser.wait(EC.elementToBeClickable(elem.first()), 60000);
    return elem.first().click();
};
inventory.prototype.clickOkButnInConfigrImiPopUp = function(){
	var self=this;
	var elem = element(by.css(this.btnOkConfigureImiCss));
	browser.wait(EC.elementToBeClickable(elem), 60000);
    return elem.click().then(function(textArray){
        logger.info("Clicked on Ok button in Custom Operation COnfirmation Dialog box");
        util.waitForAngular();
	//self.fetchD2opsOrderDetails();
    });
};


inventory.prototype.getTextUpdatedCostConfigureImiManagedService = function(){
    var elemCost = element.all(by.xpath(this.txtUpdateCostImiXpath));
    return elemCost.getText().then(function(text){
        logger.info("The value for Updated cost is  : " + text)
        return text;
    });
};

inventory.prototype.clickCurrentBOMButton = function(){
	var elem = element(by.css(this.btnCurntBomCss));
	browser.wait(EC.elementToBeClickable(elem), 60000);
    return elem.click().then(function(textArray){
        logger.info("Clicked on Current BOM  button");
        util.waitForAngular();
    });
};

inventory.prototype.closeViewDetailsTab = function () {
	let ele = element(by.css(this.closeViewButton));
	browser.wait(EC.elementToBeClickable(ele), 20000);
	return ele.click().then(function () {
		logger.info('Close View Details tab');
	})

};
inventory.prototype.clickOnInstanceTableActionIcon = function() {
	browser.wait(EC.elementToBeClickable(element(by.css(this.instanceTableActionIconCss))), 90000);
	element.all(by.css(this.instanceTableActionIconCss)).first().click().then(function(){
		logger.info("clicked on Instance Table Action icon on Inventory")
	})
}

inventory.prototype.isTurnONButtonPresent = function () {
	browser.wait(EC.invisibilityOf(element(by.buttonText(this.buttonTextTurnON))), 90000);
	element(by.buttonText(this.buttonTextTurnON)).isPresent().then(function (isPresent) {
		if (isPresent) {
			logger.info("Turn ON button is Present");
			return true
		}
		else {
			logger.info("Turn ON button is not Present")
			return false
		}
	})
}
inventory.prototype.isRebootButtonPresent = function () {
	browser.wait(EC.invisibilityOf(element(by.buttonText(this.buttonTextReboot))), 90000);
	element(by.buttonText(this.buttonTextReboot)).isPresent().then(function (isPresent) {
		if (isPresent) {
			logger.info("Reboot button is Present");
			return true
		}
		else {
			logger.info("Reboot button is not Present");
			return false
		}
	})
}
inventory.prototype.isTurnOFFButtonPresent = function () {
	browser.sleep(10000)
	browser.wait(EC.visibilityOf(element(by.buttonText(this.buttonTextTurnOFF))), 90000);
	return element(by.buttonText(this.buttonTextTurnOFF)).isPresent().then(function (isPresent) {
		if (isPresent) {
			logger.info("Turn OFF button is Present");
			return true
		}
		else {
			logger.info("Turn OFF button is not Present");
			return false
		}
	})
}

inventory.prototype.clickOverflowACtionBtnBasedOnComponent = function (component) {	 
	var self = this;
	browser.ignoreSynchronization = true;
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.xpath(this.powerStateOverflowMenuIconXpath))), 60000);
	
	var componentType = element.all(by.css(this.textComponentTypeCss));
	return componentType.getText().then(function(textArray){
		   if(textArray.includes(component)) {
		  	  var stringID = textArray.indexOf(component);
		  	  //var vmID = stringID + 3;
			   var vmID = stringID + 2;
		  	  return element(by.xpath(self.glifIconXpath + "[" + vmID + "]")).click().then(function(){
				logger.info("Clicked on Action icon of " + component);
				return vmID - 2;
		  	  });
		   }
		   else {
					logger.info("Error: No Virtual machine found");
				}
	})
	
	 browser.ignoreSynchronization = false;

};

inventory.prototype.clickViewComponentBasedOnIndex = function (index) {
	browser.waitForAngular();
	var elem = element.all(by.xpath(this.buttonXpathViewComponent));	
	return elem.get(index).click().then(function () {
		logger.info('Clicked on View Component button');
	});	
};

inventory.prototype.clickConfigureImiServiceBasedOnIndex = function(index){
	var elem = element.all(by.xpath(this.lnkConfigureImiXpath));	
	browser.wait(EC.elementToBeClickable(elem.get(index)), 60000);
	return elem.get(index).click().then(function(textArray){
        logger.info("Clicked on Configure IMI Managed Service button");
        util.waitForAngular();
	});
};
inventory.prototype.verifyOutputParamsLablesIcam = function (orderObject) {
	var self = this;
		browser.waitForAngular();
		this.open()
		this.searchOrderByServiceName(orderObject.servicename)

		element.all(by.css(this.instanceTableActionIconCss)).first().click().then(function () {
			logger.info("Clicked on the Actions icon from the first row on Inventory page");
		});
		
		this.clickViewService();
		browser.wait(EC.visibilityOf(element(by.xpath(this.outputParamsXpathIcam))),30000);
		var ele = element.all(by.xpath(this.outputParamsXpathIcam));
		return ele.getText().then(function(arryList){
			logger.info("**Output parameters Lables - " + arryList);
			return self.closeViewComponent().then(function(){
				return arryList;	
			});
		});	
	};
	inventory.prototype.verifyOutputParamsValueIcam = function (orderObject) {
		var self = this;
		browser.waitForAngular();
		this.open()
		this.searchOrderByServiceName(orderObject.servicename)
		
		element.all(by.css(this.instanceTableActionIconCss)).first().click().then(function () {
			logger.info("Clicked on the Actions icon from the first row on Inventory page");
		});

		this.clickViewService();
		browser.wait(EC.visibilityOf(element(by.xpath(this.outputParamsXpathValueIcam))),30000);
		var ele = element.all(by.xpath(this.outputParamsXpathValueIcam));
		return ele.getText().then(function(arryList){
			logger.info("Output parameters  " + arryList);
			return self.closeViewComponent().then(function(){
				return arryList;	
			});
		});		
};



inventory.prototype.clickDeleteRecordSet = function () {
	var self = this;
	var elemToClick = element.all(by.buttonText(this.txtDeleteRecordSet));
	browser.wait(EC.elementToBeClickable(elemToClick.last()), 30000);
	return elemToClick.last().click().then(function () {
		logger.info('Clicked on Delete Recordset button');
		util.waitForAngular();	
		self.placeD2opsOrder();	
	});
};

inventory.prototype.clickAtachNetworkInterfaceBtn = function () { 	
	
	//util.waitForAngular();
	var self = this;
	var elem = element(by.buttonText(this.txtAttachNetworkIntface));
	browser.wait(EC.elementToBeClickable(elem), 120000);
	return elem.click().then(function () {
		logger.info('Clicked on Attach Network Interface button');
		util.waitForAngular();
		self.placeD2opsOrder();	
	});
};

inventory.prototype.clickDetachNetworkInterfaceBtn = function () { 	
	//util.waitForAngular();
	var self = this;
	var elem = element(by.buttonText(this.txtDetachNetworkIntface));
	browser.wait(EC.elementToBeClickable(elem), 120000);
	return elem.click().then(function () {
		logger.info('Clicked on Detach Network Interface button');
		util.waitForAngular();
		self.placeD2opsOrder();	
	});
};

inventory.prototype.getAtachmntId = function () {
	var self = this;
	util.waitForAngular();
	self.clickViewComponentofAWSInstance();
	util.waitForAngular();
	//click on View details for EC2 network Interface
	var elemViewDetailsNtwrkIntfc = element(by.xpath(self.viewDetailsNtwrkIntfc));	
	browser.executeScript("arguments[0].scrollIntoView();", elemViewDetailsNtwrkIntfc.getWebElement());
	browser.wait(EC.elementToBeClickable(elemViewDetailsNtwrkIntfc), 15000);
	browser.sleep(2000);
	elemViewDetailsNtwrkIntfc.click().then(function(){
		logger.info("Succesfully clicked on View Details for Network Inteface");
	});	
	var elemViewDetailsAttchmnt = element(by.xpath(self.viewDetailsAttchmnt));
	browser.wait(EC.elementToBeClickable(elemViewDetailsAttchmnt), 15000);
	elemViewDetailsAttchmnt.click().then(function(){
		logger.info("Succesfully clicked on View Details for Attachment Id");	
	});
	return self.getTextBasedOnLabelNameandIndex("AttachmentId", 0).then(function(text){
		return text;
	});	
};

inventory.prototype.downLoadKeyPair = function(keyName) {
	
	element(by.buttonText(this.viewServiceButtonText)).click().then(function () {
		logger.info("Clicked on View Service Button in Inventory Page");
		util.waitForAngular();		
	});
	var elemKeyPairLink = element(by.cssContainingText(".bx--link", keyName));
	browser.wait(EC.elementToBeClickable(elemKeyPairLink), 60000);
	elemKeyPairLink.click().then(function(){
		logger.info("Clicked on Key Pair link from Inventory");
		util.waitForAngular();		
	});

	var elemDownlodBtn = element(by.xpath(defaultConfig.btnDownldFileXpath));
	browser.wait(EC.elementToBeClickable(elemDownlodBtn), 60000);
	return elemDownlodBtn.click().then(function(){
		logger.info("Clicked on Download button for key pair");		
	});
};

inventory.prototype.getNotificationMsg = function() {
	browser.ignoreSynchronization = true;	
	util.switchToDefault();
	util.switchToFrame();
	var elem = element.all(by.css(this.txtNotifcnCss));
	browser.wait(EC.visibilityOf(elem.get(1)), 15000);
	return elem.get(1).getText().then(function(text){
		logger.info("Notification Message - " + text);
		browser.sleep(2000);
		element(by.css(defaultConfig.btnCloseNotifcnCss)).click().then(function(){
			logger.info("Clicked on Close Notification button.");			
		});
		return text;		
	});
};

inventory.prototype.clickAccessComponent = function () {	
	browser.waitForAngular();
	var elem = element.all(by.xpath(this.btnAcessComponentXpath));
	return elem.last().isDisplayed().then(function (status) {
		if (status == true) {
			return elem.last().click().then(function () {
				logger.info('Clicked on Access Component button');
			});
		} else {
			return elem.get(0).click().then(function () {
				logger.info('Clicked on Access Component button');
			});
		}
	});
};

inventory.prototype.uploadFile = async function (fileName) {		
	var zipFile = fileName + ".zip";
	var pemFile = fileName + ".pem";
	// set file detector
	browser.setFileDetector(new remote.FileDetector());
	var fileToUpload = '../../downloads/' + pemFile;
	var fileToExtract = '../../downloads/' + zipFile;
	var absolutePath = path.resolve(__dirname, fileToUpload);
	var extarctFileAbsPath = path.resolve(__dirname, fileToExtract);
	
	//Extract zip file
	try {
		await extract(extarctFileAbsPath, { dir: process.cwd() + "/downloads" });
		logger.info('Extraction complete');
	} catch (err) {
		// handle any errors
		logger.info('Unable to Exract file')
	}

	var fileElem = element.all(by.css(this.filePathCss)).get(1);
	// Unhide file input
	browser.executeScript("arguments[0].style.visibility = 'visible'; arguments[0].style.height = '1px'; arguments[0].style.width = '1px';  arguments[0].style.opacity = 1", fileElem.getWebElement());
	fileElem.sendKeys(absolutePath);
	// wait to sync
	browser.driver.sleep(1000);
};

inventory.prototype.clickDecryptBtn = function() {
	var elem = element(by.buttonText(this.txtDecryptBtn));
	browser.wait(EC.elementToBeClickable(elem), 15000);
	return elem.click().then(function(){
		logger.info("Clicked on Decrypt button");
		util.waitForAngular();
	});
}

inventory.prototype.getPaswrdVm = function() {
	var elem = element(by.css(this.txtPwdCss));
	browser.wait(EC.visibilityOf(elem), 20000);
	return elem.getText().then(function(text){
		logger.info("VM password is decrepted-" + text);
		//Close popup
		element(by.css(defaultConfig.btnClosePwdPopUpCss)).click();
		return text;
	});	
}

inventory.prototype.getServiceTags = function(actTagList){
	var counter = 0;
	var systemTag;
	var sytemTagKeyValue;
	var systemTagKey;
	var systemTagValue;
	var systemTagMap = {};
	while(counter < actTagList.length) {
		systemTag = actTagList[counter];
		sytemTagKeyValue = systemTag.split(":");
		systemTagKey = sytemTagKeyValue[0];
		systemTagValue = sytemTagKeyValue[1];
		systemTagMap[systemTagKey] = systemTagValue;
		counter = counter + 1;
	}
	return systemTagMap;
};

inventory.prototype.getComponentNameOnInventoryPage = function() {
	var elem = element(by.xpath(this.txtComponentTypeXpath));
	return elem.getText().then(function(text){
		logger.info("Component type on onventory page is " + text);
		return text;
	});
}
inventory.prototype.clickViewAccessComponentIcam = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.icamGCPAccessCompCss))), 60000);
	element(by.css(this.icamGCPAccessCompCss)).click().then(function () {
		logger.info("Clicked on Access Component  of Virtual Machine");
		util.waitForAngular();
	})
}

inventory.prototype.readAccessComponentIcam = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.connectVmTextCss))), 60000);
	element(by.css(this.connectVmTextCss)).getText().then(function (text) {
		logger.info(" VM connect instructions are visible :" + text);
		return text;
	});

}

inventory.prototype.viewAccessComponentOkIcam = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.icamConnectVmOkCss))), 60000);
	element(by.css(this.icamConnectVmOkCss)).click().then(function () {
		logger.info("Clicked on OK access component for  Virtual Machine");
	})
}

inventory.prototype.getTextBasedOnExactLabelName = function (labelName) {
	browser.executeScript('window.scrollTo(0,0);');
	return element(by.xpath("//span[(text()=' " + labelName +  " ')]/following-sibling::span")).getText().then(function (text) {
		logger.info("The value for " + labelName + " is : " + text)
		return text;
	});
};

inventory.prototype.getEc2ServerHeading = function () {
	var latelTextElement = element(by.xpath("//h1"));	
	browser.wait(EC.visibilityOf(latelTextElement), 10000);
	return latelTextElement.getText().then(function (webserverHeading) {
		logger.info("EC2 server is launched - " + webserverHeading);
		return webserverHeading;
	});
};

inventory.prototype.clickBomTab = function () {	
	browser.waitForAngular();
	var elem = element(by.css(this.btnBillOfMaterialsCss));	
	browser.wait(EC.elementToBeClickable(elem), 10000);
	return elem.click().then(function(){
		logger.info("Clicked on Bill of Materials tab");
	});
};

inventory.prototype.getBOMTableEstimatedPrice = function () {
	var latelTextElement = element(by.css(this.estimatedCostCss));	
	//browser.wait(EC.visibilityOf(latelTextElement), 10000);
	return latelTextElement.getText().then(function (estimatedPrice) {
		logger.info("Estimated Cost on BOM in Inventory - " + estimatedPrice);
		return estimatedPrice;
	});
};

inventory.prototype.getWebSiteUrl = function (labelName) {
	var latelTextElement = element(by.xpath("//*[contains(text(), '" + labelName + "')]/following-sibling::div//span"));
	browser.executeScript('window.scrollTo(0,0);');
	browser.wait(EC.visibilityOf(latelTextElement), 10000);
	return latelTextElement.getText().then(function (webUrl) {
		logger.info("The value for " + labelName + " is : " + webUrl)
		return webUrl;
	});
};

inventory.prototype.getTextOrderStatus = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.newOrderStatus))), 10000);
    return element(by.css(this.newOrderStatus)).getText().then(function(orderStatus){
        logger.info("Order Status on Order History page : "+orderStatus)
        return orderStatus;
    });
};
inventory.prototype.getLanguageCount = function(){
	util.waitForAngular();
	var langugElem = element.all(by.css(this.langugeCss));
	browser.wait(EC.visibilityOf(langugElem.get(5)), 10000);
	return langugElem.count().then(function(totalElem){
		logger.info("Total languages displayed on Wordpress site is : " + totalElem)
		if(totalElem < 5){
			return false;
		}else{
			return true;
		}       
	});
};

inventory.prototype.getTextImiMangmntLevl = function(){
	var elem = element.all(by.css(this.txtMngmntLvlCss)).last();
	browser.wait(EC.visibilityOf(elem), 50000);
    return elem.getText().then(function(text){
        logger.info("Management Level -  : " + text)
        return text;
    });
};

inventory.prototype.noDataAvailableIsPresent = function (orderObject) {
	this.open();
    this.searchOrderByServiceName(orderObject.servicename);
	return element(by.css(this.noDataAvailablePresentTextCss)).isPresent(); 
};

//Function to select right cheevron to expand filter

inventory.prototype.clickRightChevronToExpandFilter = function () {
	browser.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.filterChevronRightCss))), 15000);
	element(by.css(this.filterChevronRightCss)).click().then(function(){
		logger.info("Clicked on right chevron to expand filter")
	});
	util.waitForAngular();
};

//Function to click on deleted checkbox from right filter

inventory.prototype.clickDeletedCheckboxFromFilter = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.deletedCheckboxCss))), 15000);
	element(by.css(this.deletedCheckboxCss)).click().then(function(){
		logger.info("Clicked on deleted checkbox")
	});
};
	
//Function to click on apply filter
inventory.prototype.clickOnApplyFilter = function () {
		browser.wait(EC.elementToBeClickable(element(by.css(this.applyFilterLabelCss))), 15000);
		element(by.css(this.applyFilterLabelCss)).click().then(function(){
			logger.info("Clicked on apply filter label");
		});
		util.waitForAngular();
};
	
inventory.prototype.clickClearAllFilter = function () {
		browser.wait(EC.elementToBeClickable(element(by.css(this.clearAllFilterCss))), 5000);
		element(by.css(this.clearAllFilterCss)).click().then(function(){
			logger.info("Clicked on clear all ");
		});
		util.waitForAngular();
};	

inventory.prototype.getServiceNameAfterApplyingFilter = function(){
		browser.wait(EC.visibilityOf(element(by.css(this.serviceNameToolTipTextCss))), 20000);
	    return element(by.css(this.serviceNameToolTipTextCss)).getText().then(function(serviceNameAfterApplyingFilter){
	        logger.info("Service name after applying filter: "+serviceNameAfterApplyingFilter);
	        return serviceNameAfterApplyingFilter;
	    });
};

inventory.prototype.getTextStatusAfterApplyingFilter = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.appliedFilterStatusTextCss))), 10000);
    return element(by.css(this.appliedFilterStatusTextCss)).getText().then(function(appliedFilterStatus){
        logger.info("Status after applying filter: "+appliedFilterStatus);
        return appliedFilterStatus;
    });
};

inventory.prototype.searchForTransferTeam = function (teamName) {
	var curr = this;
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(curr.searchTeamTextBoxCss))), 150000);
	element(by.css(curr.searchTeamTextBoxCss)).click().then(function () {
		element(by.css(curr.searchTeamTextBoxInputCss)).clear();
		element(by.css(curr.searchTeamTextBoxInputCss)).sendKeys(teamName);
		browser.wait(EC.visibilityOf(element(by.xpath("//button[contains(text(), '" + teamName + "')]"))), 150000);
		util.scrollToWebElement(element(by.xpath("//button[contains(text(), '" + teamName + "')]")));
		element(by.xpath("//button[contains(text(), '" + teamName + "')]")).click().then(function () {
			logger.info("Selected searched team...");
		});
	});
};

inventory.prototype.clickTransferService = function () {
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.transferServiceButtonText))), 5000);
	return element(by.buttonText(this.transferServiceButtonText)).click().then(function () {
		logger.info("Clicked on Transfer Service Button on Order Services Page");
		util.waitForAngular();
	});
};
inventory.prototype.clickTransferButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.transferButtonText))), 5000);
	return element(by.buttonText(this.transferButtonText)).click().then(function () {
		logger.info("Clicked on Transfer Service Button on Order Services Page");
		util.waitForAngular();
	});
};

inventory.prototype.clickAcceptTransferService = function () {
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.acceptTransferButtonText))), 5000);
	return element(by.buttonText(this.acceptTransferButtonText)).click().then(function () {
		logger.info("Clicked on Accept Transfer Service Button on Pending Transfers Page");
		util.waitForAngular();
	});
};

inventory.prototype.clickConfirmAcceptTransferService = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.transferAcceptButtonCss))), 5000);
	return element(by.css(this.transferAcceptButtonCss)).click().then(function () {
		logger.info("Clicked on Accept Transfer Service Button on Pending Transfers Page");
		util.waitForAngular();
	});
}

inventory.prototype.clickCancelTransferService = function () {
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.cancelTransferButtontext))), 5000);
	return element(by.buttonText(this.cancelTransferButtontext)).click().then(function () {
		logger.info("Clicked on Cancel Transfer Service Button on Pending Transfers Page");
		util.waitForAngular();
	});
};

inventory.prototype.clickDenyTransferService = function () {
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.denyTransferButtonText))), 5000);
	return element(by.buttonText(this.denyTransferButtonText)).click().then(function () {
		logger.info("Clicked on Deny Transfer Service Button on Pending Transfers Page");
		util.waitForAngular();
	});
};

inventory.prototype.clickViewReasonDeniedTransferService = function () {
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.viewReasonButtonText))), 5000);
	return element(by.buttonText(this.viewReasonButtonText)).click().then(function () {
		logger.info("Clicked on View Reason of Rejected Transfer  Service on Completed Transfers Page");
	});
};

inventory.prototype.clickOkButtonofDeniedModalTransferService = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.denyReasonModalOKButtonCss))), 5000);
	return element(by.css(this.denyReasonModalOKButtonCss)).click().then(function () {
		logger.info("Clicked on OK  of Rejected Transfer  Service on Completed Transfers Page");
		util.waitForAngular();
	});
};

inventory.prototype.getReasonTextofDeniedTransferService = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.denyTextReasonCss))), 5000);
	return element(by.css(this.denyTextReasonCss)).getText().then(function (text) {
		logger.info("Rejected Reason Text of Transfer  Service on Completed Transfers Page is : " + text);
		return text;
	});
};

inventory.prototype.clickChangeOwner = function (elementNo) {
	browser.wait(EC.elementToBeClickable(element.all(by.buttonText(this.changeOwnerButtonText)).get(elementNo)), 5000);
	return element.all(by.buttonText(this.changeOwnerButtonText)).get(elementNo).click().then(function () {
		logger.info("Clicked on Change Owner of Service on All orders Page");
		util.waitForAngular();
	});
};

inventory.prototype.confirmTransferService = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.confirmTransferCss))), 15000);
	return element(by.css(this.confirmTransferCss)).click().then(function () {
		logger.info("Clicked on Confirm Transfer Button on Order Services Page");
	});
};
inventory.prototype.clickOnAllServicesTab = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.allServicesTabCss))), 5000);
	return element(by.css(this.allServicesTabCss)).click().then(function () {
		logger.info("Clicked on All Services tab on Order Services Page");
		util.waitForAngular();
	});
};

inventory.prototype.clickOnTransfersTab = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.transfersTabCss))), 5000);
	return element(by.css(this.transfersTabCss)).click().then(function () {
		logger.info("Clicked on Transfers tab on Order Services Page");
		util.waitForAngular();
	});
};

inventory.prototype.clickOnPendingTransfersTab = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.pendingTransfersCss))), 5000);
	return element(by.css(this.pendingTransfersCss)).click().then(function () {
		logger.info("Clicked on Pending Transfers tab on Order Services Page");
		util.waitForAngular();
	});
};

inventory.prototype.clickOnCompletedTransfersTab = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.completedTransfersCss))), 5000);
	return element(by.css(this.completedTransfersCss)).click().then(function () {
		logger.info("Clicked on Completed Transfers tab on Order Services Page");
		util.waitForAngular();
	});
};

inventory.prototype.getSuccessNotificationPopupMsg = function()
{
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.notificationPopupMessageCss))),190000);
	return element(by.css(this.notificationPopupMessageCss)).getText().then(function(msg){
		logger.info("Notification Message is :"+ msg);
		return msg;
	});
}

inventory.prototype.ConfirmDenyTranferService = function (denyReason) {
	browser.wait(EC.visibilityOf(element(by.css(this.transferDenyReasonTextBoxCss))),20000);
	element(by.css(this.transferDenyReasonTextBoxCss)).clear();
	element(by.css(this.transferDenyReasonTextBoxCss)).sendKeys(denyReason);
	element(by.css(this.transferDenyButtonCss)).click().then(function(){
		logger.info("Denied Transfer Service....");
	});
};

inventory.prototype.ConfirmCancelTransferService = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.transferCancelButtonCss))), 5000);
	return element(by.css(this.transferCancelButtonCss)).click().then(function () {
		logger.info("Clicked on Confirm Cancel Transfers Order Services Page..");
		util.waitForAngular();
	});
};
inventory.prototype.ConfirmResendTransferService = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.transferResendButtonCss))), 5000);
	return element(by.css(this.transferResendButtonCss)).click().then(function () {
		logger.info("Clicked on Confirm Resend Transfers on Completed Transfers Page..");
		util.waitForAngular();
	});
};

inventory.prototype.clickOnResendButton = function () {
	browser.wait(EC.elementToBeClickable(element(by.buttonText(this.resendTransferButtonText))), 5000);
	return element(by.buttonText(this.resendTransferButtonText)).click().then(function () {
		logger.info("Clicked on Resend Transfers on Completed Transfers Page..");
		util.waitForAngular();
	});
};

inventory.prototype.SelectCheckboxForFirstService = function () {
	browser.sleep(4000);
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.selectFirstServiceCheckBoxCss))), 10000);
	return element(by.css(this.selectFirstServiceCheckBoxCss)).click().then(function () {
		logger.info("Clicked on checkbox for first service under All Services Table..");
		util.waitForAngular();
	});
};

inventory.prototype.searchandSelectChangeOwner = function(ownerName){
    util.waitForAngular();
	element(by.css(this.changeOwnerTextBoxCss)).clear();
    element(by.css(this.changeOwnerTextBoxCss)).sendKeys(ownerName);
    browser.wait(EC.visibilityOf(element(by.xpath("//span[contains(text(), '" + ownerName + "')]"))),10000);
    util.scrollToWebElement(element(by.xpath("//span[contains(text(), '" + ownerName + "')]")));
    element(by.xpath("//span[contains(text(), '" + ownerName + "')]")).click().then(function () {
        logger.info("Selected searched  Owner...");
});
};

inventory.prototype.ConfirmChangeOwner = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.confirmChangeOwnerCss))), 10000);
	return element(by.css(this.confirmChangeOwnerCss)).click().then(function () {
		logger.info("Clicked on checkbox for first service under All Services Table..");
	});
};

inventory.prototype.getTextOfTransferorTeam = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.transferorNameCss))), 10000);
    return element(by.css(this.transferorNameCss)).getText().then(function(Status){
        logger.info("Status after applying filter: "+Status);
        return Status;
    });
};


inventory.prototype.getTextOfTransfereeTeam = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.transfereeNameCss))), 10000);
    return element(by.css(this.transfereeNameCss)).getText().then(function(Status){
        logger.info("Status after applying filter: "+Status);
        return Status;
    });
};
inventory.prototype.getTextOfTransferStatus = function(){
	var self = this;
	self.scrollArrowToRight();
	browser.wait(EC.visibilityOf(element(by.css(this.transferStatusCss))), 10000);
    return element(by.css(this.transferStatusCss)).getText().then(function(Status){
        logger.info("Status after applying filter: "+Status);
        return Status;
    });
};

inventory.prototype.scrollArrowToRight = function(){
	browser.wait(EC.elementToBeClickable(element(by.css(this.rightArrowCss))), 40000);
		element(by.css(this.rightArrowCss)).click().then(function () {
		logger.info("Clicked on right scroller arrow");
	});
};

inventory.prototype.placeD2opsOrder = function(){
	var elem = element(by.css(this.placeOrderCss));
	browser.wait(EC.elementToBeClickable(elem), 60000);
    return elem.click().then(function(){
		logger.info("Clicked on Place Order button for D2ops operation in Inventory");
		util.waitForAngular();         
    });
};

/*inventory.prototype.fetchD2opsOrderDetails = function(){
	util.waitForAngular();
	var elem = element(by.css(this.fetchOrderDetailCss));
	return elem.isDisplayed().then(function(lnkPresent){
		if(lnkPresent){
			browser.sleep(3000);
			browser.wait(EC.elementToBeClickable(elem), 120000);
			return elem.click().then(function(){
				logger.info("Clicked on fetch order details"); 
				browser.sleep(2000);
				//Check if order details displayed.
				elem.isDisplayed().then(function(status){
					if(status){
						//Again click on link using JS
// 						return browser.executeScript("arguments[0].click();", elem.getWebElement()).then(function(){
// 							logger.info("Clicked on fetch order details using JS");					
// 						});
						
						return browser.executeScript("document.getElementsByClassName('" + defaultConfig.fetchOrderLnkClass + "')[0].click();").then(function(){
							logger.info("Clicked on fetch order details using JS");					
						});
					}
				}).catch(function(err){
					logger.info(err.name);
					logger.info(err.message);
				});;        
			});
		}
	}).catch(function(err){
		logger.info(err.name);
		logger.info(err.message);
	});
};*/

inventory.prototype.fetchD2opsOrderDetails = function(repeatCount){
    //util.waitForAngular();
   //Commenting waitForAngular function as its bloacking test flow even if spinner is not present.
   //Adding static wait to sync with the page
    browser.sleep(3000);	
    let self = this;
    if(repeatCount == undefined){
        repeatCount = 10;
        }
        repeatCount = repeatCount-1;
        if(repeatCount>0) {
            var elem = element(by.css(this.fetchOrderDetailCss));
            return elem.isPresent().then(function(lnkPresent){
                //util.waitForAngular();
		logger.info(" Is the link 'Please click here for order updates' present: ",lnkPresent);
		if(lnkPresent){
			browser.wait(EC.elementToBeClickable(elem), 120000);
			elem.click().then(function(){
				logger.info("Clicked on fetch order details"); 
				browser.sleep(3000);						 
			});
		}

		return element(by.css(self.orderNocssnew)).isPresent().then(function(state){
		return element(by.css(self.submittedOrderNoCss)).isPresent().then(function(state){
			logger.info(" Is the Order Submitted pop up displayed: ",state);
			if(state)
			{       
				logger.info(" D2 Ops Order Submitted Details displayed,Order Submitted!,breaking the loop");
				repeatCount = 0;
				return;
			}
			else {
					//util.waitForAngular();
					self.fetchD2opsOrderDetails(repeatCount);
					logger.info(" D2 Ops Order Submitted Details not displayed,Waiting for Order Submitted Details to be displayed, => continuing the loop ");
			}
		});		
            });
			});    
};
};

//checkExportLinkIsPresent
inventory.prototype.checkExportLinkIsPresent = function(){
	browser.wait(EC.presenceOf(element(by.css(this.ExportLinkCss))), 60000);
	return element(by.css(this.ExportLinkCss)).isPresent().then(function(status){
		logger.info("Export link is visible.."+status);
		return status;
	})
};
//check refresh link present
inventory.prototype.checkRefreshLinkCss = function(){
	browser.wait(EC.presenceOf(element(by.css(this.RefreshLinkCss))), 60000);
	return element(by.css(this.RefreshLinkCss)).isPresent().then(function(status){
	 logger.info("Refresh link is visible.."+status);
	 return status;
	})
};
//check instance name present
inventory.prototype.ServiceInstanceNameTextPresent = function(){
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.presenceOf(element.all(by.css(this.ServiceInstanceNameCss)).get(0)), 60000);
	return element(by.css(this.ServiceInstanceNameCss)).getText().then(function(InstanceNameText){
        logger.info("logs initial text: "+InstanceNameText);
        return InstanceNameText;
    });
};

//click ob view details link for order on inventory
inventory.prototype.clickViewDetailsLink = function () {
	var curr = this;
	browser.wait(EC.presenceOf(element(by.css(this.instanceTableActionIconCss))), 5000);
	return element.all(by.css(this.instanceTableActionIconCss)).first().click().then(function () {
		logger.info("Clicked on the Actions icon from the first row on Inventory page");
		browser.wait(EC.elementToBeClickable(element(by.buttonText(curr.buttonTextViewDetailsText))), 40000);
		return element(by.buttonText(curr.buttonTextViewDetailsText)).click().then(function () {
			logger.info("Clicked on viewdetails Service button");
		});
	});
};
//checkServiceLogsTab
inventory.prototype.checkServiceLogsTab = function () {
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.presenceOf(element(by.css(this.serviceLogsCss))), 60000);
	return element(by.css(this.serviceLogsCss)).isPresent().then(function (status) {
		logger.info("Service log Tab is present.."+status);
		return status;
	})
};
//checkResourceLogsTab
inventory.prototype.checkResourceLogsTab = function () {
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.presenceOf(element(by.css(this.resourceLogsCss))), 60000);
	return element(by.css(this.resourceLogsCss)).isPresent().then(function (status) {
		logger.info("Resource log Tab is present.."+status);
		return status;
	})
};
//checkserviceLogTextPresent
inventory.prototype.checkserviceLogTextPresent = function(){
	util.waitForCircleStrokeToDisappear();
	browser.wait(EC.presenceOf(element.all(by.css(this.serviceLogTextCss)).get(0)), 60000);
	return element(by.css(this.serviceLogTextCss)).getText().then(function(ServicelogText){
        logger.info("Service log text: "+ServicelogText);
        return ServicelogText;
    });
};


module.exports = inventory;
