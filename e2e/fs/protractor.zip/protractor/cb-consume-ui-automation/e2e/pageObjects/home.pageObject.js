"use strict";

var extend = require('extend');
var url = browser.params.url;
var username = browser.params.username;
var CatalogPage = require('../pageObjects/catalog.pageObject.js');
var CartListPage = require('../pageObjects/cartList.pageObject.js');
var mcmpUIDataTemplate = require('../../testData/mcmp/mcmpUIData.json');
var logGenerator = require("../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger();
var util = require('../../helpers/util.js');
var appUrls = require('../../testData/appUrls.json');
var EC = protractor.ExpectedConditions;

var defaultConfig = {
    pageUrl: url + '/launchpad',
    ordersLinkTextXpath: '//a[contains(text(), "Orders")][@id="ordersLinkId"]',
    approveOrdersTextXpath: '//a[@id="approverOrdersLinkId"][contains(text(), "Approve Orders")]',
    accountsLinkTextXpath: '//a[contains(text(), "ACCOUNTS")]',
    cataLogLinkTextXpath: '//a[contains(text(), "Catalog")]',
    servicesLinkTextXpath: '//a[contains(text(), "SERVICES")]',
    inventoryLinkTextXpath: '//a[contains(text(), "Inventory")]',
    configureLinkTextXpath: '(//*[@id="storefront_carbon-button_configure"]/button)',
    cancelLinkTextXpath: '//button[text()[contains(., "Cancel")]]',
    brokerageLinkTextXpath: '//h1[contains(text(), "IBM Cloud Brokerage")]',
    storeHeaderTitleXpath: "//h1[contains(text(),'IBM Cloud Brokerage')]",
    storeLandingPageTitleXpath: "//div[contains(text(),'Store')]",
    logOutLinkXpath: '//a[contains(text(),"Logout")]',
    sysadminVerifyId: 'checkbox-verifyCheckboxId',
    
    /***************** MCMP Store launchpad Page locators ***********************************/
    textHeaderUserCss: '.header.mcmp-header h1',
	textPageHeaderCss: 'h1.ibm--page-header__title',
	textSysPageHeaderCss: 'h1.ibm--page-header__title',
    linkShowAllTasks: 'Show all tasks',
    linkShowLessTasks: 'Show less tasks',
    tilesMcmpCss: '.tile-icon.tile-icon--no-icons',
    textCommonTasksCss: 'ibm-tile h3',
    textCommonTasksTileNameCss: 'ibm-tile p',
    iconAdminConsoleCss: 'ibm-icon-user-admin20 svg',
    buttonAdminConsoleCss: 'button[ibmbutton]',
    linkStore: 'Enterprise Marketplace',
    textKnowledgeCenterHeaderCss: '.ibm-alternate-background.kc-content-header h1',
    linkPrivacyPolicy: 'Privacy Policy',
    textPrivacyHeaderCss: '#ibm-pagetitle-h1',
    textBuildIDCss: '.bx--grid.footer p',
	pageHeaderCss: '.mcmp-header',
	colorInputCss: 'input[formcontrolname="brandColor"]',
	themeDropdownText: 'button.bx--list-box__field',
	selectThemeId: 'dropdown-1',
	themeLinkCss: 'a.bx--tabs__nav-link[title="Theme"]',
	saveThemeBtnCss: '#tab-theme-content > div.bx--button-group.form-buttons > button.bx--btn.bx--btn--primary',
	restoreDefaultLinkCss: '.form-buttons a',
	saveSuccessMsgCss: 'p.bx--toast-notification__subtitle span',
	showMoreLinkCss:'a.mcmp-link',
	mcmpHeaderTabCss: 'section:nth-child(2) div.tile-title',
	/*********MCMP TA New Tab Locators for SAML Sign In page ********************/
	terraformSignInPageHeaderCss: 'h3',
	terraformAuthenticationTypeCss: '.bx--form',
	cloudPakSignInTypeSamlXpath: '//*[@id="Enterprise SAML"]/a',
	cloudPakSignIntypeDefaultXpath: '//*[@id="Default authentication"]/a'
};

function home(selectorConfig) {
    if (!(this instanceof home)) {
        return new home(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

home.prototype.open = function()
{
	var catalogPage = new CatalogPage();
	var cartListPage = new CartListPage();
	// catalogPage.checkIfUserIconIsDisplayed().then(function(status){
	// 	if(status == false){
	// 	//Handling for session timeout issue
	// 		browser.get(browser.params.url + appUrls.launchpadUrl);
	// 		cartListPage.loginFromUserSNOW(browser.params.username, browser.params.password);
	// 	}	
	// });
	
	//Check if user is on homepage or catalog page
	try {
		catalogPage.checkIfUserIconIsDisplayed().then(function(status){
			if(status == false){
				//Handling for session timeout issue
				browser.get(browser.params.url + appUrls.launchpadUrl);
				cartListPage.loginFromUserSNOW(browser.params.username, browser.params.password);
			}	
			util.switchToDefault();
			browser.waitForAngularEnabled(false);					
		});		
	} catch (error) {
		browser.get(browser.params.url + appUrls.catalogPageUrl);
		var currenturl = util.getCurrentURL();
    		currenturl.then(function(url) {    	
			if(url.indexOf("storeFront") === -1) {
				browser.get(browser.params.url + appUrls.launchpadUrl);
				cartListPage.loginFromUserSNOW(browser.params.username, browser.params.password);
			}
		});
	}

	util.switchToDefault();
	//browser.ignoreSynchronization = true;
	catalogPage.clickHamburgerCatalog();
	catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkPortal);
	util.waitForAngular();
};

home.prototype.checkSysadminVerifyId = function () {
    return element(by.id(this.sysadminVerifyId)).click().then(function(){
        logger.info("Checked Verify-System-Admin checkbox.")
    })
}

home.prototype.clickconfigureLink = function () {
    return element.all(by.xpath(this.configureLinkTextXpath)).get(1).click();
};

home.prototype.clickLogoutLink = function () {
    element(by.xpath(this.logOutLinkXpath)).click().then(function () {
        logger.info("clicked logout link");
    });
};

home.prototype.clickordersLink = function () {
	browser.wait(EC.visibilityOf(element(by.xpath(this.ordersLinkTextXpath))),30000);
    return element(by.xpath(this.ordersLinkTextXpath)).click().then(function () {
        logger.info("clicked orders link");
    });
};

home.prototype.clickOnApproveOrdersLink = function () {
	browser.wait(EC.visibilityOf(element(by.xpath(this.ordersLinkTextXpath))),30000);
	element(by.xpath(this.ordersLinkTextXpath)).click();
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.approveOrdersTextXpath))),30000);
	browser.actions().mouseMove(element(by.xpath(this.approveOrdersTextXpath))).click().perform().then(function () {
		logger.info("clicked on approve orders link");
	});
};


home.prototype.clickAccountsLink = function () {
    return element(by.xpath(this.accountsLinkTextXpath)).click().then(function () {
        logger.info("clicked accounts link");
    });
};

home.prototype.clickInventoryLink = function () {
    return element(by.xpath(this.inventoryLinkTextXpath)).click().then(function () {
        logger.info("clicked Inventory link");
    });
};

home.prototype.catalogMenuItem = function () {
    return element(by.xpath(this.cataLogLinkTextXpath)).getText().then(function (text) {
        logger.info(text);
        return (text);
    });
}
home.prototype.storeHeaderGetTitle = function () {
    browser.sleep(5000);
    return element(by.xpath(this.storeHeaderTitleXpath)).getText().then(function (text) {
        logger.info(text);
        return (text);
    });
}
home.prototype.storeLandingPageTitle = function () {
    browser.sleep(5000);
    return element(by.xpath(this.storeLandingPageTitleXpath)).getText().then(function (text) {
        logger.info(text);
        return (text);
    });
}
home.prototype.clickCatalogLink = function () {
	browser.sleep(10000);
    return element(by.xpath(this.cataLogLinkTextXpath)).click().then(function () {
        logger.info("clicked catalog link");
    });
};

home.prototype.clickservicesLink = function () {
    return element(by.xpath(this.servicesLinkTextXpath)).click();
};

home.prototype.clickNextLink = function () {
    return element(by.xpath(this.NextLinkTextXpath)).click().then(function () {

        logger.info("clicked Next link");
    });
};

home.prototype.clickCancelLink = function () {
    return element(by.xpath(this.cancelLinkTextXpath)).click();
};

home.prototype.clickcloudbrokerageLink = function () {
    return element(by.xpath(this.brokerageLinkTextXpath)).click();
};


/*****************MCMP Store Launchpad Page Functions***********************************/

home.prototype.getTextHeaderUser = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textHeaderUserCss))),90000);
	return element(by.css(this.textHeaderUserCss)).getText().then(function(user){
		logger.info("Logged in user is: " + user);
		return user;
	})
};

home.prototype.getTextPageHeader = function () {
	//util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.css(this.textPageHeaderCss))), 120000);
	return element(by.css(this.textPageHeaderCss)).getText().then(function (text) {
		logger.info("Page header is: " + text);
	    return text;
	});
};

home.prototype.getTextSysPageHeader = function () {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.textSysPageHeaderCss))), 60000);
	return element(by.css(this.textSysPageHeaderCss)).getText().then(function (text) {
		logger.info("Page header is: " + text);
	    return text;
	});
};

home.prototype.getPageHeaderColor = function() {
	browser.wait(EC.visibilityOf(element(by.css(this.pageHeaderCss))), 60000);
	return element(by.css(this.pageHeaderCss)).getCssValue('background-color').then(function(color) {
		logger.info("Page header is: " + color);
	    return color;
	});
};

home.prototype.isPresentThemeSaveSuccessMsg = function(){
	browser.ignoreSynchronization = true;
	browser.wait(EC.visibilityOf(element(by.css(this.saveSuccessMsgCss))), 90000);
	return element(by.css(this.saveSuccessMsgCss)).getText().then(function(text){
		logger.info("Save theme success message text : "+text);
		browser.ignoreSynchronization = false;
		return text;
	});
};

home.prototype.clickOnThemeLink = function () {
	browser.wait(EC.elementToBeClickable(element(by.css(this.themeLinkCss))), 30000);
	element(by.css(this.themeLinkCss)).click().then(function () {
		logger.info("Clicked on Theme link.")
	});
}

home.prototype.changePageHeaderColor = function (color) {
	browser.wait(EC.elementToBeClickable(element(by.css(this.themeDropdownText))), 30000);
	element(by.css(this.themeDropdownText)).click().then(function () {
		logger.info("Clicked On Theme Dropdown");
		var colorOption = element(by.xpath('//li[@title="' + color + '"]'));
		colorOption.click().then(function () {
			logger.info("Selected new theme: " + color);
		})
	})
};

home.prototype.clickSaveThemeBtn = function() {
	var self = this;
	browser.wait(EC.visibilityOf(element(by.css(this.saveThemeBtnCss))), 60000);
	element(by.css(self.saveThemeBtnCss)).click().then(function(){
		logger.info("Clicked on save button, Saved theme.");
		browser.sleep(5000); //Added static wait as it takes time to change the colour
	});
};

home.prototype.clickRestoreDefaultThemeSettings = function(color) {
	var self = this;
	var restoreLink = element(by.css(this.restoreDefaultLinkCss));
	browser.wait(EC.visibilityOf(restoreLink), 60000);
	restoreLink.isEnabled().then(function(res){
		if(res){
			browser.actions().doubleClick(restoreLink).perform().then(function(){
				logger.info("Clicked on Reset Default link.");
				browser.sleep(3000);
			});
		}
	});
};

home.prototype.switchToFrame = function () {
	browser.switchTo().frame(element(by.tagName('iframe')).getWebElement());
	logger.info("Switched to iframe");
};

home.prototype.clickShowAllTasksLink = function () {
	browser.wait(EC.visibilityOf(element(by.linkText(this.linkShowAllTasks))), 60000);
	element(by.linkText(this.linkShowAllTasks)).click().then(function() {
		logger.info("Clicked on Show All Tasks link");
	});
};

home.prototype.clickShowLessTasksLink = function () {
	browser.wait(EC.visibilityOf(element(by.linkText(this.linkShowLessTasks))), 60000);
	element(by.linkText(this.linkShowLessTasks)).click().then(function() {
		logger.info("Clicked on Show Less Tasks link");
	});
};

home.prototype.getCountMcmpTiles = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.tilesMcmpCss))),90000);
	return element.all(by.css(this.tilesMcmpCss)).count().then(function(num){
		logger.info("MCMP tiles shown on launchpad: " + num);
		return num;
	})
};

home.prototype.clickCommonTasksTileBasedOnName = function(taskLink){
	var self= this;
	browser.wait(EC.visibilityOf(element(by.css(self.textCommonTasksCss))),90000);
	 return element.all(by.css(self.textCommonTasksCss)).getText().then(function(links){
		for(var i=0; i<links.length; i++) {			
			if(links[i]==taskLink) {
				return element.all(by.css(self.textCommonTasksCss)).get(i).click().then(function() {
					browser.sleep(2000);
					logger.info("Clicked on " + taskLink + " link in Common tasks");
				})
			}			
		}		
	})
};

home.prototype.getTextCommonTasksTileBasedOnName = function(tileName){
	var self= this;
	browser.wait(EC.visibilityOf(element(by.css(self.textCommonTasksCss))),90000);
	 return element.all(by.css(self.textCommonTasksCss)).getText().then(function(names){
		for(var i=0; i<names.length; i++) {			
			if(names[i]==tileName) {
				return element.all(by.css(self.textCommonTasksTileNameCss)).get(i).getText().then(function(text) {
					logger.info(tileName + " tile sub name is: " + text);
					return text;
				})
			}			
		}		
	})
};

home.prototype.isPresentAdminConsoleUserIcon = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.iconAdminConsoleCss))),90000);
	return element(by.css(this.iconAdminConsoleCss)).isPresent().then(function(res){
		logger.info("User icon on Admin console: " + res);
		return res;
	})
};

home.prototype.clickAdminConsoleButton = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.buttonAdminConsoleCss))),90000);
	element(by.css(this.buttonAdminConsoleCss)).click().then(function(){
		logger.info("Clicked on Admin Console button");
	})
};

home.prototype.clickStoreLink = function(){
	browser.wait(EC.visibilityOf(element(by.linkText(this.linkStore))),90000);
	element(by.linkText(this.linkStore)).click().then(function(){
		browser.sleep(2000);
		logger.info("Clicked on Store link");
	})
};

home.prototype.getTextKnowledgeCenterHeader = function(){
	var self = this;
	return browser.getAllWindowHandles().then(function(handles) {
	    return browser.switchTo().window(handles[1]).then(function() {
	    	logger.info("Switched to new window");
	    	browser.ignoreSynchronization = true;
	    	browser.wait(EC.visibilityOf(element(by.css(self.textKnowledgeCenterHeaderCss))),90000);
	    	return element(by.css(self.textKnowledgeCenterHeaderCss)).getText().then(function(text){
	    		logger.info("Knowledge Center header is: " + text);
	    		browser.close().then(function(){
	    			browser.switchTo().window(handles[0]).then(function(){
	    				logger.info("Switched back to parent window");
	    			})
	    		})
	    		browser.ignoreSynchronization = false;
	    		return text;
	    	})
	    })
	})
};

home.prototype.clickPrivacyPolicyLink = function(){
	browser.wait(EC.visibilityOf(element(by.linkText(this.linkPrivacyPolicy))),90000);
	element(by.linkText(this.linkPrivacyPolicy)).click().then(function(){
		logger.info("Clicked on Privacy Policy link");
	})
};

home.prototype.getTextPrivacyPolicyHeader = function(){
	var self = this;
	return browser.getAllWindowHandles().then(function(handles) {
	    return browser.switchTo().window(handles[1]).then(function() {
	    	logger.info("Switched to new window");
	    	browser.ignoreSynchronization = true;
	    	browser.wait(EC.visibilityOf(element(by.css(self.textPrivacyHeaderCss))),90000);
	    	return element(by.css(self.textPrivacyHeaderCss)).getText().then(function(text){
	    		logger.info("Privacy Policy header is: " + text);
	    		browser.close().then(function(){
	    			browser.switchTo().window(handles[0]).then(function(){
	    				logger.info("Switched back to parent window");
	    			})
	    		})
	    		browser.ignoreSynchronization = false;
	    		return text;
	    	})
	    })
	})
};

home.prototype.getTextBuildID = function(){
	browser.wait(EC.visibilityOf(element(by.css(this.textBuildIDCss))),90000);
	return element.all(by.css(this.textBuildIDCss)).last().getText().then(function(text){
		logger.info("Build ID is: " + text);
		return text;
	})
};

home.prototype.clickOnShowMoreLink = function()
{
	browser.wait(EC.elementToBeClickable(element(by.css(this.showMoreLinkCss))),90000);
	return element(by.css(this.showMoreLinkCss)).click().then(function(){
		logger.info("clicked on show more Link : ");
	})
}

home.prototype.getMcmpHeadersTabText = function () {
	browser.wait(EC.visibilityOf(element.all(by.css(this.mcmpHeaderTabCss)).get(0)), 90000);
	return element.all(by.css(this.mcmpHeaderTabCss)).getText().then(function (McmpHearderList) {
		logger.info("Mcmp Headers Tabs are : " + McmpHearderList);
		return McmpHearderList;
	})
}

home.prototype.clickLaunchpadLink = function (linknameText) {
	var self = this;
	var cloudPakBlueLink = element(by.xpath("//ibm-tile/ul[@class='tile-body']//a[.='" + linknameText + "']"));
	browser.wait(EC.elementToBeClickable(cloudPakBlueLink), 10000);
	cloudPakBlueLink.click().then(function(){
		browser.sleep(2000);
		logger.info("Clicked on blue link" + linknameText + "link");
		util.waitForAngular();
	});

};

home.prototype.verifyCloudPakHeaderlIsVisible = function () {
	util.waitForAngular();
	browser.wait(EC.visibilityOf(element(by.css(this.terraformAuthenticationTypeCss))), 60000);
	browser.wait(EC.visibilityOf(element(by.css(this.terraformSignInPageHeaderCss))), 60000);
	return element(by.css(this.terraformSignInPageHeaderCss)).getText().then(function (cloudPakHeaderText) {
		logger.info("CloudPak Page header is: " + cloudPakHeaderText);
		return cloudPakHeaderText;
	});
};

home.prototype.verifyAuthenticationSamlIsVisible = function () {
	util.waitForAngular();
	browser.wait(EC.elementToBeClickable(element(by.xpath(this.cloudPakSignInTypeSamlXpath))), 60000);
	return element(by.xpath(this.cloudPakSignInTypeSamlXpath)).getText().then(function (AuthenticationTypeText) {
		logger.info("Authentication Type is visible : " + AuthenticationTypeText);
		return AuthenticationTypeText;
	});
};

home.prototype.VerifyAuthenticationDefaultIsVisible = function () {
	util.waitForAngular();

	browser.wait(EC.elementToBeClickable(element(by.xpath(this.cloudPakSignIntypeDefaultXpath))), 60000);
	return element(by.xpath(this.cloudPakSignIntypeDefaultXpath)).getText().then(function (AuthenticationTypeText) {
		logger.info("Authentication Type is visible : " + AuthenticationTypeText);
		return AuthenticationTypeText;
	});
};

module.exports = home;