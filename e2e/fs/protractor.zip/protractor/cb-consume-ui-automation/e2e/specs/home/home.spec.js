"use strict";

var  HomePage = require('../../pageObjects/home.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    util = require('../../../helpers/util.js');

describe('Consume Home Page Tests', function() {
    var homePage;
    var dashBoard;

    beforeAll(function() {
        homePage = new HomePage();
        dashBoard = new DashBoard();
        browser.driver.manage().window().maximize();
        ensureConsumeHome();
        //ensureConsumeHomeWithRoles('admin');
    });

    afterAll(function() {

    });

    beforeEach(function() {
       
    });

	it('should land on DashBoard', function() { 
        expect(util.getCurrentURL()).toMatch('dashboard');
        dashBoard.clickLetsGetStarted();
        expect(util.getCurrentURL()).toMatch('storeFront/main');
    });

    it('CON - 3174 - should verify Store as title on dashboard Page', function () {
        browser.sleep(5000);
        expect(dashBoard.dashboardPageTitle()).toMatch('Store').then(function () {
            console.log('Verified dasboard title  as Store ')
        });
    });

    it('CON - 3174 - should verify text content  on dashboard Page', function () {
        browser.sleep(5000);
        expect(dashBoard.dashboardPageIntroText()).toMatch('IBM Cloud Brokerage Store is one of several components of the IBM Cloud Brokerage suite. It is a purpose-built application that enables a self-service ability to browse, search, order, and fulfill services. It is powered by a comprehensive, curated ITaaS catalog, across Cloud and Traditional IT providers.').then(function () {
            console.log('Verified dasboard intro text ');
        });
    });

    it('CON - 3071 - check if privacy policy link is opening the modal', function() {
        dashBoard.clickPrivacyPolicy();
        browser.sleep(1000);
        expect(element(by.css('.bx--modal.is-visible')).isPresent()).toBe(true);
    });

    it('CON - 3071 - check if privacy policy modal is closing on OK button click', function() {
        dashBoard.clickOkInPrivacyPolicy();
        browser.sleep(1000);
        expect(element(by.css('.bx--modal.is-visible')).isPresent()).toBe(false);
    });

	xit('should verify Services Link', function() { 
		homePage.clickservicesLink();
        expect(util.getCurrentURL()).toMatch('fulfillment');
    });
  
    it('should verify Catalog Link',function(){
		homePage.clickCatalogLink();
		expect(util.getCurrentURL()).toMatch('main');
	});
	it('should verify IBM Cloud Brokerage Link', function() {
		console.log("entering function call");
		homePage.clickcloudbrokerageLink();
		expect(util.getCurrentURL()).toMatch('dashboard');

    });													   
});
