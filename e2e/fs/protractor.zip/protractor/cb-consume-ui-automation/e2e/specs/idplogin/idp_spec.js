

var idpPage = require('../../pageObjects/idp.pageObject'),
    util = require('../../../helpers/util.js');

describe('IDP Sigin Test', function(){
    var idp_page;

    beforeAll(function(){
        idp_page = new idpPage();
    });

    it('Use IDP to sign in to consume', function(){

        browser.ignoreSynchronization = true;
        browser.get(idp_page.url);
        browser.sleep(1000);
        idp_page.clickhomepageSignin();
        browser.sleep(1000);
        idp_page.enterUsername('ashetye@fieldengg.local');
        idp_page.enterPassowrd('Qwerty12!');
        idp_page.clickSigninSubmit();
        browser.sleep(1000);
        idp_page.clickFinalSigninButton();
        browser.sleep(2000);
        browser.ignoreSynchronization = false;
        expect(util.getCurrentURL()).toMatch('dashboard$');
    });
});