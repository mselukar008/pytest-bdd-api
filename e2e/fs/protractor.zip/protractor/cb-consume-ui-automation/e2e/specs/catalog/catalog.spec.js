"use strict";

var  HomePage = require('../../pageObjects/home.pageObject.js'),
	 CatalogcatalogDetailsPage = require('../../pageObjects/catalogdetails.pageObject.js'),
    CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
    util = require('../../../helpers/util.js'),
    VNTemplate = require('../../../testData/OrderIntegration/Azure/VN.json');

describe('Consume Catalog Page Tests', function() {
    var homePage;
    var catalogPage;
	var catalogDetailsPage;
    beforeAll(function() {
        homePage = new HomePage();
		    catalogPage = new CatalogPage();
		    catalogDetailsPage = new CatalogcatalogDetailsPage();						   
        browser.driver.manage().window().maximize();
        ensureConsumeHomeWithRoles("admin");
        catalogPage.open();
    });

    afterAll(function() {

    });

    beforeEach(function() {
       catalogPage.open();
       browser.sleep(2000);
    });

	xit('should verify Store Page Header Title-TC C158557', function() { 
        var headerTitle = homePage.storeHeaderGetTitle();
        browser.sleep(5000);
        expect(headerTitle).toBe('IBM Cloud Brokerage');
        console.log('IBM Cloud Brokerage title verified');
    });
   
    xit('should verify Store landing page title-TC C158559', function() { 
        var storeLandingTitle = homePage.storeLandingPageTitle();
        expect(storeLandingTitle).toBe('Search, Select and Configure');
        console.log('Store landing page title Search, Select and Configure verified');
    });

    xit('should verify Catalog menu item-TC C158621', function() { 
		var storeMenuHasCatalog = homePage.catalogMenuItem();
		expect(storeMenuHasCatalog).toBe('CATALOG');
		console.log('Verified Catalog Menu Item Exists');
	});
	
    xit('should verify service tile has active configure button item-TC C158565 , cliking on the button takes to configuration page TC C158569 ', function(){
        browser.sleep("1000")   
        expect(catalogPage.isDisplayedConfigureButtonBasedOnName('CentOS')).toBe(true).then(function(data){
        console.log('Verified Configure Button is Displayed ')
        });
        catalogPage.clickConfigureButtonBasedOnName("CentOS");
        browser.sleep("1000")
        expect(util.getCurrentURL()).toMatch('main-parameters').then(function(){
        console.log('Verified Configure button navigates to Service Configuration main parameters page');
        });
   });
	xit('should verify  clicking on the service tile takes to service details page  TC- C158890 ', function(){
        browser.sleep("1000") 
        catalogPage.clickBluePrintBasedOnName('CentOS') ;
        expect(util.getCurrentURL()).toMatch('service-details').then(function(){
        console.log('Verified Service details page opened successfully');
        });

        });
	xit('Verify Navigating to Catalog Page is working', function() { 
		homePage.clickCatalogLink();
        expect(util.getCurrentURL()).toMatch('storeFront');
    });
	
	xit('verify selecting VRA provider check box', function() {
		console.log("selecting vra provider");
		catalogPage.selectvraProviderCheckbox();
	});
    
    xit('verify Reset Link In provider section: TC:C160320', function() {
        browser.sleep(4000);
	    catalogPage.clickProviderCheckBoxBasedOnName('vra').then(function(){
        console.log("clicked provider VRA");
        });
        expect(catalogPage.isPresentResetLinkCatalogProviderSection()).toBe(true);
        browser.sleep(1000);
        catalogPage.clickResetLinkCatalogProviderSection().then(function(){
        console.log("clicked reset link in provider section");
        });
        browser.sleep(3000);
        expect(catalogPage.isPresentResetLinkCatalogProviderSection()).toBe(false);
    });
    xit('verify Reset Link In category section: TC:C161512', function() {
        browser.sleep(4000);
	    catalogPage.clickFirstCategoryCheckBoxBasedOnName('Compute').then(function(){
        console.log("clicked category compute");
        });
        expect(catalogPage.isPresentResetLinkCatalogCategorySection()).toBe(true);
        browser.sleep(1000);
        catalogPage.clickResetLinkCatalogCategorySection().then(function(){
            console.log("clicked reset link in category section");
        });
        browser.sleep(1000);

        expect(catalogPage.isPresentResetLinkCatalog()).toBe(false);
	});
	xit('Verify Feature Text by clicking on Lamp stack',function() {
		 catalogPage.clickLampStack();
		 browser.sleep("1000")
		 expect(util.getCurrentURL()).toMatch('service-details')
		 expect(catalogDetailsPage.checkFeatureText()).toEqual("Install LAMP Stack");
     });
     it('verify provider filters are displaying on catalog page',function(){
        catalogPage.getListofProviders().then(function(arr){
            for (var i in arr){
                if(i==0){
                    expect(arr[i]).toMatch("amazon");
                }
                else if(i==1){
                    expect(arr[i]).toMatch("azure");
                }
                else if(i==2){
                    expect(arr[i]).toMatch("icd");
                }
                else{
                    expect(arr[i]).toMatch("vra");
                }  
            };              
        });

     });
     it('verify category filters are displaying on catalog page',function(){
        catalog.getListofFirstCategories().then(function(arr1){
            for (var i in arr1){
                if(i==0){
                    expect(arr1[i]).toMatch("Compute");
                }
                else if(i==1){
                    expect(arr1[i]).toMatch("Storage");
                }
                else if(i==2){
                    expect(arr1[i]).toMatch("Network");
                }
                else if(i==3){
                    expect(arr1[i]).toMatch("Databases");
                }
                else if(i==4){
                    expect(arr1[i]).toMatch("Backup & Disaster Recovery");
                }
                else if(i==5){
                    expect(arr1[i]).toMatch("Security & Identity");
                }
                else if(i==6){
                    expect(arr1[i]).toMatch("Applications");
                }
                else{
                    expect(arr1[i]).toMatch("Temp Default Category");
                }  
            };              
        });       
     })

     it('verify if scrolling on catlog to end showing all Services ',function(){
        catalogPage.clickProviderCheckBoxBasedOnName(VNTemplate.provider);
        util.scrollToBottom();
        util.scrollToTop();
        expect(catalogPage.checkServiceIsPresent(VNTemplate.bluePrintName)).toBe(true);
     });
});