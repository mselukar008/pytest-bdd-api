"use strict";

var  HomePage = require('../../pageObjects/home.pageObject.js'),
	 CatalogcatalogDetailsPage = require('../../pageObjects/catalogdetails.pageObject.js'),
    CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
	util = require('../../../helpers/util.js');

describe('Consume Catalog Page Tests', function(){
    var homePage;
    var catalogPage;
	var catalogDetailsPage;
    beforeAll(function() {
        homePage = new HomePage();
		    catalogPage = new CatalogPage();
		    catalogDetailsPage = new CatalogcatalogDetailsPage();						   
        browser.driver.manage().window().maximize();
        ensureConsumeHomeWithRoles("admin");
        catalogPage.open();
    });

    afterAll(function() {

    });

     beforeEach(function() {
       catalogPage.open();
       browser.sleep("1000");
       catalogPage.clickBluePrintBasedOnName('CentOS');
    });

     it('Verify From Service Details page, clicking on Catalog from bread crumb navigation menu should open service list page-TC C158591', function() { 
        browser.sleep("1000") 
        expect(util.getCurrentURL()).toMatch('service-details');
        browser.sleep("1000");
        catalogDetailsPage.clickCatalogFromBreadCrumbNav();
        expect(util.getCurrentURL()).toMatch('storeFront').then(function(){
        console.log('Verified clicking on Catalog from bread crumb navigation menu  opened catalog list page successfully');
    });
    });

    it('Verify From Service Details page, configure button appears (TC C158579)and clicking it opens service configuration page (TC C158589)', function(){ 
        browser.sleep("1000")   
        expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true).then(function(){
        console.log('Verified Configure Button is Displayed on service details page')
        catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
        browser.sleep("1000")
        expect(util.getCurrentURL()).toMatch('main-parameters').then(function(){
        //browser.sleep("1000")
        console.log('Verified clicking on Configure button from Service Details page opens configuration main parameters page successfully');
    });
    });
    });
    it('Verify From Service Details page, cancel button appears and clicking it returns to service list page (TC C160502)', function(){ 
        browser.sleep("1000");  
        expect(catalogDetailsPage.isDisplayedCancelButtonCatalogDetailsPage()).toBe(true).then(function(){
        console.log('Verified Cancel Button is Displayed on service details page')
        catalogDetailsPage.clickCancelButtonCatalogDetailsPage();
        browser.sleep("1000")
        expect(util.getCurrentURL()).toMatch('storeFront').then(function(){
        browser.sleep("1000")
        console.log('Verified clicking on Cancel button from Service Details page returns to catalog list page successfully');
    });
    });
});
});