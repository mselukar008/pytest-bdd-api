/*
Spec_Name: 101containerRegistry.spec.js 
Description: This spec will cover E2E testing of Container Registry service onboarded to comsume with cbs-servicify CLI using Native Template. 
*/

"use strict";


var Orders = require('../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../testData/appUrls.json'),
        util = require('../../../helpers/util.js'),
        jsonUtil = require('../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../helpers/orderFlowUtil.js'),
        EC = protractor.ExpectedConditions,

        containerRegistryTemplate = require('../../../testData/azureServicificationTestData/101containerRegistry.json');


describe('Azure: Test cases for 101-container-registry Native template Service', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Compute' };
        var servicename = "Nativecontregis" + util.getRandomString(5);
        var rgName;
        var contRegisName = "Nativeregis" + util.getRandomString(5)

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                rgName = "autotc_azure_nativecontregisRG" + util.getRandomString(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Acr Name": contRegisName };
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        });

        //E2E Storage Account order Submit, Approve, Delete Service with New Resource Group.
        it('Azure: TC-C219590 Verify that for Container Registry Native Template on creating new/delete order order is getting completed', function () {

                        var orderObject = JSON.parse(JSON.stringify(containerRegistryTemplate));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};

                        orderFlowUtil.fillOrderDetails(containerRegistryTemplate, modifiedParamMap);

                        placeOrderPage.submitOrder();

                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');

                        //Delete Order Flow
                        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                        orderFlowUtil.approveDeletedOrder(returnObj);
                        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');

        });
});
