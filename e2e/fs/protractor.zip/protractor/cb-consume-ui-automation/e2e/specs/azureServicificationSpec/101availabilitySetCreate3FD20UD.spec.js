/*
Spec_Name: 101availabilitySetCreate3FD20UD.spec.js 
Description: This spec will cover E2E testing of Availability Set service onboarded to comsume with cbs-servicify CLI using Native Template.
*/

"use strict";


var Orders = require('../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../testData/appUrls.json'),
        util = require('../../../helpers/util.js'),
        jsonUtil = require('../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../helpers/orderFlowUtil.js'),
        EC = protractor.ExpectedConditions,

        ASTemplate = require('../../../testData/azureServicificationTestData/101availabilitySetCreate3FD20UD.json');


describe('Azure: Test cases for 101-availability-set-create-3FDs-20UDs Natvie template Service', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Compute' };
        var servicename = "NativeAvsrv" + util.getRandomString(5);
        var rgName;

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                rgName = "gslautotc_azure_nativeasRG" + util.getRandomString(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName };
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        });

        //E2E Availability Set order Submit, Approve, Delete Service with New Resource Group.
        it('Azure: Verify that for Availability Set Native Template on creating new/delete order order is getting completed', function () {

                        var orderObject = JSON.parse(JSON.stringify(ASTemplate));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};

                        orderFlowUtil.fillOrderDetails(ASTemplate, modifiedParamMap);

                        placeOrderPage.submitOrder();

                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');

                        //Delete Order Flow
                        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                        orderFlowUtil.approveDeletedOrder(returnObj);
                        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');

        });
});
