// This test file is for testing filters on inventory page

"use strict";

var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    util = require('../../../helpers/util.js'),
    inventoryData = require('../../../testData/inventory/inventory.json');


describe('Test View Properties in Inventory page', function() {
    var orders, homePage, dashBoard, inventoryPage; 

    beforeAll(function() {
        homePage = new HomePage(); 
        dashBoard = new DashBoard();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
        inventoryPage.open();
    });

    afterAll(function() {

    });

    beforeEach(function() {
    	
    });
	
    /* Verify view properties dialog displayed */
	it('Verify viewProperties', function() {	
		util.waitForAngular();
        inventoryPage.searchInTable(inventoryData.Search_InstanceName);
        inventoryPage.clickSelectedSOIGlificon();
        inventoryPage.clickViewService();
		expect(inventoryPage.isServiceNameOfSelectedSOIAvailable()).toBe(true, " Service name is present");
		expect(inventoryPage.isProviderServiceInstanceIdSOIAvailable()).toBe(true, "Provider Service Instance Id is present")
	});
	
});
