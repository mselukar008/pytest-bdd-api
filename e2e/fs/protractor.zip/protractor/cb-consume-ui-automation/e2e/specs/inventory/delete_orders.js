// This test file is for placing service orders for day2ops test runs

"use strict";
const fs = require('fs');
var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    AccountsPage = require('../../pageObjects/account.pageObject.js'),
    singleVMCentOSTemplate	= require('../../../testData/inventory/singleVMCentOs.json'),
    util = require('../../../helpers/util.js'),
    PlaceOrderPage = require('../../pageObjects/placeOrder.pageObject.js'),
    orderFlowUtil = require('../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../testData/appUrls.json'),
    Orders = require('../../pageObjects/orders.pageObject.js'),
    inventoryData = require('../../../testData/inventory/inventory.json');

describe('Delete VRA order', function() {
    var orders, homePage, dashBoard, inventoryPage, accountsPage, catalogPage, placeOrderPage; 
   
    beforeAll(function() {
        homePage = new HomePage(); 
        dashBoard = new DashBoard();
        inventoryPage = new InventoryPage();
        accountsPage = new AccountsPage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        orders = new Orders();
        browser.driver.manage().window().maximize();
        inventoryPage.open();
    });

    afterAll(function() {

    });

    beforeEach(function() {
    });
    
    it('Delete VRA order (Standard Operations), Approve Delete Order and verify SOI status', function() {
    	var serviceName = inventoryData.Search_InstanceName;
    	var deleteOrderNumber = "";
    	var orderObject = {};
    	//Search for the service instance
		inventoryPage.clickSearchIcon();
		inventoryPage.searchInTable(inventoryData.Search_InstanceName);
		expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_InstanceName)).toBe(true,"Search text found");
    	
		//Select Delete Service
		inventoryPage.clickGlificonIcon();
		util.waitForAngular();
		expect(inventoryPage.isEnabledDeleteServiceMenuOption()).toBe(true,"Delete Service menu option is Enabled");
		util.waitForAngular();
		inventoryPage.clickDeleteServiceIcon();
		util.waitForAngular();
		inventoryPage.clickDeleteServicecheckboxIcon();
		util.waitForAngular();
		inventoryPage.clickDeleteServiceOkaybutton();
		inventoryPage.getDeleteOrderNumberFromPopUpText();
		inventoryPage.getDeleteOrderNumberFromPopUpText().then(function(orderNo){  
            deleteOrderNumber = orderNo.substring(orderNo.indexOf(":")+2);
            console.log("deleteOrderNumber : " + deleteOrderNumber)
            
            //Verify "Delete in Progress" status of SOI
			inventoryPage.clickFilterIcon();
			util.waitForAngular();
			inventoryPage.clickFilterCheckBoxLabelBasedOnName("Delete in progress");
			inventoryPage.clickSearchIcon();
			inventoryPage.searchInTable(inventoryData.Search_InstanceName);
			expect(inventoryPage.getStatusOfSOI()).toBe('Delete in progress', " SOI status is Edit in progress");
			inventoryPage.clickFilterIcon();
			util.waitForAngular();
			inventoryPage.clickFilterCheckBoxLabelBasedOnName("Delete in progress");
			
			orderObject.orderNumber = deleteOrderNumber;
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject,'Provisioning in Progress');
//			orders.closeServiceDetailsSlider();
			orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed',30);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
				if (status == 'Completed') {
					console.log("Delete Order got Completed")
				}
			})
			
			//Search for valid Instance Name 
			inventoryPage.open();
			inventoryPage.clickFilterIcon();
			util.waitForAngular();
			inventoryPage.clickFilterCheckBoxLabelBasedOnName("Deleted");
			inventoryPage.clickSearchIcon();
			inventoryPage.searchInTable(inventoryData.Search_InstanceName);
			expect(inventoryPage.getStatusOfSOI()).toBe('Deleted', " SOI status is Deleted");
			inventoryPage.clickFilterIcon();
			util.waitForAngular();
			inventoryPage.clickFilterCheckBoxLabelBasedOnName("Deleted");
        });
    });
   
});
