// This test file is for testing filters on inventory page

"use strict";

	var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
	HomePage = require('../../pageObjects/home.pageObject.js'),
	DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
	util = require('../../helpers/util.js'),
	inventoryData = require('../../testdata/inventory/inventory.json'),
	CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
	OrdersPage = require('../../pageObjects/orders.pageObject.js'),
	DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
	orderFlowUtil = require('../../helpers/orderFlowUtil.js'),
	vraBluePrints = require('../../testdata/vRAIntegration/vRABluePrints.json');


describe('Access Component', function() {
	 var orders, homePage, dashBoard, inventoryPage, catalogPage, ordersPage;

	 beforeAll(function() {
	        homePage = new HomePage();
	        dashBoard = new DashBoard();
	        catalogPage = new CatalogPage();
	        ordersPage = new OrdersPage();
			browser.driver.manage().window().setSize(1280, 1024);
			ensureConsumeHome();
	        inventoryPage = new InventoryPage();
	    });

	    afterAll(function() {
	    });

	    beforeEach(function() {
	    });
	    
	    /*code to create vRA order */
		   it('Should Verify Create SingleVMCentOS service order and successful provisioning is working fine with default values - TC C160154', function() {
		    	console.log("You are going to place order")
		    	var i = 0;
		    	catalogPage.open();
		        var centOSObject = JSON.parse(JSON.stringify(vraBluePrints.CentOS65));
		        var returnObj = orderFlowUtil.createOrder(centOSObject);
		        orderFlowUtil.approveOrder(returnObj);
		        if(orderFlowUtil.verifyOrderStatus(returnObj) == 'Completed') console.log("true");
		        //expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe('Provisioning in Progress');
		        orderFlowUtil.waitForOrderCompletion(returnObj,30);
		        console.log("Provisioning Completed");
		    });
	    
		    
		    /* Search for valid Provisioned Date */
			it('Search for valid Provisioned Date', function() {	
				//Get number of pages and do search in each page
				inventoryPage.open();
				util.waitForAngular();
				inventoryPage.searchInTable(inventoryData.Search_ByOrderNo);
				expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_ByOrderNo)).toBe(false,"Search text found");
				inventoryPage.clickExpansionIcon();
				browser.sleep(3000);
				isAngularApp(false);
				inventoryPage.clickOverflowMenuIcon();
				inventoryPage.clickoverflowmenuoptions();
				expect(inventoryPage.isHeadingNamePresent()).toBe(false, "Connect VM");
				//isAngularApp(false);
			});
			

});
