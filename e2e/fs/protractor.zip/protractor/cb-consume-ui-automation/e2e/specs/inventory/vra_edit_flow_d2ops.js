// This test file is for testing filters on inventory page

"use strict";

var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
	Orders = require('../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../pageObjects/placeOrder.pageObject.js'),
    util = require('../../../helpers/util.js'),
    inventoryData = require('../../../testData/inventory/inventory.json'),
    orderFlowUtil = require('../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../testData/appUrls.json'),
    tier3TraditionalTemplate = require('../../../testData/OrderIntegration/VRA/3tierTraditionalWorkload.json'),
    singleVMCentOSTemplate	= require('../../../testData/OrderIntegration/VRA/singleVMCentOs.json'),
    vraBluePrints = require('../../../testData/vRAIntegration/vRABluePrints.json');

describe('Test e2e edit flow d2ops functionality', function() {
    var orders, homePage, dashBoard, inventoryPage, catalogPage, placeOrderPage; 
    var modifiedParamMap = {};
    var messageStrings = {providerName:'VRA'};


    beforeAll(function() {
        orders = new Orders();
        homePage = new HomePage(); 
        dashBoard = new DashBoard();
        catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    afterAll(function() {
    	
    });

    beforeEach(function() {
    	
    });
    beforeAll(function(){
    	
    });
    
    /* End to End Day2 operations flow */
	it('Search for valid Instance Name', function() {	
		
		//Search for valid Instance Name 
		inventoryPage.open();
		inventoryPage.clickSearchIcon();
		inventoryPage.searchInTable(inventoryData.Search_InstanceName);
		expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_InstanceName)).toBe(true,"Search text found");
	});
	
	it('Do Edit Service on SOI and Submit Order', function() {	

		inventoryPage.clickGlificonIcon();
		util.waitForAngular();
		expect(inventoryPage.isEnabledEditServiceMenuOption()).toBe(true,"View Service menu option is Enabled");
		util.waitForAngular();
		inventoryPage.clickEditServiceIcon();
		util.waitForAngular();
		inventoryPage.clickEditServiceNextButton();
		inventoryPage.setCPUDropDown();
		inventoryPage.clickEditServiceNextAdditionalParamsButton();
		browser.sleep(5000);
//		Verify updated Config
		expect(inventoryPage.getEditStrikedCPUText()).toBe("1","Previous CPU config value striked out")
		expect(inventoryPage.getEditUpdatedTagText()).toBe("Updated", "Updated tag found in Edit Config")
		expect(inventoryPage.getEditCurrentCPUText()).toBe("2", "Updated tag found in Edit Config")
//		Verify updated BOM
		inventoryPage.clickEditMoreLink();
		expect(inventoryPage.getUpdatedBOM()).toBe("USD240.00", "BOM updated in submit order page")
		inventoryPage.clickCurrentBOMButton();
		expect(inventoryPage.getCurrentBOM()).toBe("USD120.00", "Current BOM in submit order page")
		inventoryPage.clickUpdatedBOMButton();
		inventoryPage.clickEditSubmitOrderButton();
		util.waitForAngular();
		
	});
	
	it('Get Edit Order Number, Approve and wait for the Edit order to be Completed', function() {	
		
		var orderObject = {};
		var orderNumber = "";

		inventoryPage.getEditOrderNumberText().then(function(orderNo){        
            console.log("Order Number : " + orderNo);
            orderNumber = orderNo;
        });
		inventoryPage.clickEditGoToInventoryButton();
		
		//Verify "Edit in Progress" status of SOI
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Edit in progress");
		inventoryPage.clickSearchIcon();
		inventoryPage.searchInTable(inventoryData.Search_InstanceName);
		expect(inventoryPage.getStatusOfSOI()).toBe('Edit in progress', " SOI status is Edit in progress");
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Edit in progress");
		
		orderObject.orderNumber = orderNumber;
		orderFlowUtil.approveOrder(orderObject);
		orderFlowUtil.waitForOrderStatusChange(orderObject,'Provisioning in Progress');
//		orders.closeServiceDetailsSlider();
		orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed',30);
		expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
		orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
			if (status == 'Completed') {
				console.log("Edit Order got Completed")
			}
		})
	});
	
	it('Check for SOI View properties changes after Edit Completed', function() {	
		
		//Search for valid Instance Name 
		inventoryPage.open();
		inventoryPage.clickSearchIcon();
		inventoryPage.searchInTable(inventoryData.Search_InstanceName);
		expect(inventoryPage.getStatusOfSOI()).toBe('Active', " SOI status is Active");
		
		//Go to View properties and check CPU is updated value
		inventoryPage.clickGlificonIcon();
		util.waitForAngular();
		expect(inventoryPage.isEnabledViewServiceMenuOption()).toBe(true,"View Service menu option is Enabled");
		util.waitForAngular();
		inventoryPage.clickViewServiceIcon();
		expect(inventoryPage.getCPUConfigValue()).toBe("2", "CPU config updated as expected")
		inventoryPage.clickSliderCloseIcon();
	});
});
