"use strict";

var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
HomePage = require('../../pageObjects/home.pageObject.js'),
DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
util = require('../../../helpers/util.js');

var osType = util.getOSType();

describe('Test Sort functionality in Inventory page', function() {
var homePage, dashBoard, inventoryPage; 

	
	 beforeAll(function() {
	        homePage = new HomePage(); 
	        dashBoard = new DashBoard();
	        inventoryPage = new InventoryPage();
	        browser.driver.manage().window().maximize();
	        //ensureConsumeHome();
	        inventoryPage.open();
	 });

    afterAll(function() {

    });

    beforeEach(function() {
    	
    });
	
	/* Checking the column sort on Instance Name Column */	
	it('Verify Instance Name column is sorted', function() {
		
		inventoryPage.clickInstanceName();
		inventoryPage.checkIfInstanceNameColumnIsSorted();			
		
	});
	
	/* Checking the column sort on Status Column */	
	it('Verify Status Column is sorted', function() {
		
		inventoryPage.clickStatus();
		inventoryPage.checkIfStatusColumnIsSorted();
		
	});
	
	/* Checking the column sort on Provisioned Date Column */	
	it('Verify Provisioned Date column is sorted', function() {
		
		inventoryPage.clickProvisionedDate();
		inventoryPage.checkIfProvisionedDateColumnIsSorted();
		
	});
	
	/* Checking the column sort on Provider Column */	
	it('Verify Provider column is sorted', function() {
		
		inventoryPage.clickProvider();
		inventoryPage.checkIfProviderColumnIsSorted();
		 
	});
	
	/* Checking the column sort on Provider Account and Teams column */	
	it('Verify Provider Account and Teams column are sorted', function() {
		   
		osType.then((text) => {
            console.log("OS is: " + text);
            return text;
       }).then(function(text){
    	   if (!(text.indexOf("Windows") >= 0)) {
    		   inventoryPage.clickViewingColumnRightArrow();
    		   inventoryPage.clickViewingColumnRightArrow();
    	   }
    	   inventoryPage.clickProviderAccount();
    	   inventoryPage.checkIfProviderAccountColumnIsSorted();
    			
    	   inventoryPage.clickTeam();
    	   inventoryPage.checkIfTeamColumnIsSorted();
       })
		
	});
	
	/* Checking the column sort on Ordered By Column */	
	it('Verify Ordered By column is sorted ', function() {
		
    	inventoryPage.clickViewingColumnRightArrow();
		inventoryPage.clickViewingColumnRightArrow();
		
		inventoryPage.clickOrderedBy();
		inventoryPage.checkIfOrderedByColumnIsSorted();
		
	});
	
	/* Checking the column sort on Service Name Column */	
	it('Verify Service Name column is sorted', function() {
		
		inventoryPage.clickServiceName();
		inventoryPage.checkIfServiceNameColumnIsSorted();	
		
	});
	
	/* Checking the column sort on Estimated Cost Column */	
	it('Verify Estimated Cost column is sorted', function() {
		
		inventoryPage.clickViewingColumnRightArrow();
		inventoryPage.clickViewingColumnRightArrow();
		
	});
	
	/* Checking the column sort on Currency Column */	
	it('Verify Currency column is sorted', function() {
		
		inventoryPage.clickCurrency();
		inventoryPage.checkIfCurrencyColumnIsSorted();	
		
	});
});
