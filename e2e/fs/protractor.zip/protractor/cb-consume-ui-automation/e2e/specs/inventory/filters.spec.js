// This test file is for testing filters on inventory page

"use strict";

var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    AccountsPage = require('../../pageObjects/account.pageObject.js'),
    util = require('../../../helpers/util.js');
    //orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    //inventoryData = require('../../../testData/inventory/inventory.json');

describe('Test Filters functionality in Inventory page', function() {
    var orders, homePage, dashBoard, inventoryPage, accountsPage, catalogPage; 
    var  filterByStatus = "status";
    var filterByProvider = "provider";


    beforeAll(function() {
        homePage = new HomePage(); 
        dashBoard = new DashBoard();
        inventoryPage = new InventoryPage();
        accountsPage = new AccountsPage();
        catalogPage = new CatalogPage();
        browser.driver.manage().window().maximize();
//        ensureConsumeHome();
        catalogPage.open();
    });

    afterAll(function() {

    });

    beforeEach(function() {
    	
    });
    
    /* Verify filter provider names sync with catalog page */
	it('Verify filter provider names sync with catalog page', function() {	
		var catalogProviderList = [];
		browser.sleep(3000);
		util.waitForAngular();
		catalogPage.getListofProviders().then(function(arr){
            for (var i in arr){
            	catalogProviderList.push(arr[i]);
            };           
            console.log("Catalog provider list : " + catalogProviderList);
        });
		inventoryPage.open();
		browser.sleep(3000);
		inventoryPage.clickFilterIcon();
		inventoryPage.getListofFilterProviders().then(function(arr){
            for (var i in arr){
            	console.log("Filter provider name :" + arr[i] + " is same as " + "Catalog provider name :" + catalogProviderList[i])
                expect(arr[i]).toEqual(catalogProviderList[i]); 
            };   
		});
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
	
    /* Verify default filter option "Active" selected */
	it('Verify default filter option "Active" selected', function() {	
		var searchText1 = ["Active"];
		var searchText2 = [];
		browser.sleep(3000);
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Active")).toBe(true,"Active checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Deleted")).toBe(false,"Deleted checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Delete in progress")).toBe(false,"Delete In Progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Edit in progress")).toBe(false,"Edit In Progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("VRA")).toBe(false,"Vra checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Amazon")).toBe(false,"Amazon checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Azure")).toBe(false,"Azure checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("IBM Cloud")).toBe(false,"Softlayer checkbox is not enabled");
		//Get the table data and check that all Status rows shows "Active"
		expect(inventoryPage.verifyFiltersApplied(searchText1,filterByStatus)).toBe(true, "Active Filter is Applied by default");
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
	
	/* Verify filter option "Deleted" selected */
	it('Verify filter option "Deleted" selected', function() {	
		var searchText1 = ["Deleted"];
		var searchText2 = [];
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Active");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Deleted");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Active")).toBe(false,"Active checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Deleted")).toBe(true,"Deleted checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Delete in progress")).toBe(false,"Delete In Progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Edit in progress")).toBe(false,"Edit In Progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("VRA")).toBe(false,"Vra checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Amazon")).toBe(false,"Amazon checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Azure")).toBe(false,"Azure checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("IBM Cloud")).toBe(false,"Softlayer checkbox is not enabled");
		//Get the table data and check that all Status rows shows "Active"
		expect(inventoryPage.verifyFiltersApplied(searchText1,filterByStatus)).toBe(true, "Deleted Filter is Applied by default");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Deleted");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Active");
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
	
	/* Verify filter option "Delete in progress" selected */
	it('Verify filter option "Delete in progress" selected', function() {	
		var searchText1 = ["Delete in progress"];
		var searchText2 = [];
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Active");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Delete in progress");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Active")).toBe(false,"Active checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Deleted")).toBe(false,"Deleted checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Delete in progress")).toBe(true,"Delete in progress checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Edit in progress")).toBe(false,"Delete in progress checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("VRA")).toBe(false,"Vra checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Amazon")).toBe(false,"Amazon checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Azure")).toBe(false,"Azure checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("IBM Cloud")).toBe(false,"Softlayer checkbox is not enabled");
		//Get the table data and check that all Status rows shows "Active"
		expect(inventoryPage.verifyFiltersApplied(searchText1,filterByStatus)).toBe(true, "Delete In Progress Filter is Applied by default");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Delete in progress");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Active");
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
	
	/* Verify filter option "Edit in progress" selected */
	it('Verify filter option "Edit in progress" selected', function() {	
		var searchText1 = ["Edit in progress"];
		var searchText2 = [];
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Active");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Edit in progress");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Active")).toBe(false,"Active checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Deleted")).toBe(false,"Deleted checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Delete in progress")).toBe(false,"Delete in progress checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Edit in progress")).toBe(true,"Delete in progress checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("VRA")).toBe(false,"VRA checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Amazon")).toBe(false,"Amazon checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Azure")).toBe(false,"Azure checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("IBM Cloud")).toBe(false,"IBM Cloud checkbox is not enabled");
		//Get the table data and check that all Status rows shows "Active"
		expect(inventoryPage.verifyFiltersApplied(searchText1,filterByStatus)).toBe(true, "Edit In Progress Filter is Applied by default");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Edit in progress");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Active");
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
		
	/* Verify filter option "Active" and "Deleted" selected */
	it('Verify filter option "Active" and "Deleted" selected', function() {
		var searchText1 = ["Active", "Deleted"];
		var searchText2 = [];
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Deleted");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Active")).toBe(true,"Active checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Deleted")).toBe(true,"Deleted checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Delete in progress")).toBe(false,"Delete in progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Edit in progress")).toBe(false,"Delete in progress checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("VRA")).toBe(false,"VRA checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Amazon")).toBe(false,"Amazon checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Azure")).toBe(false,"Azure checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("IBM Cloud")).toBe(false,"IBM Cloud checkbox is not enabled");
		//Get the table data and check that all Status rows shows "Active"
		expect(inventoryPage.verifyFiltersApplied(searchText1,filterByStatus)).toBe(true, "Active and Deleted Filters are Applied by default");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Deleted");
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
	
	/* Verify filter option "Active" and "VRA", "Azure" */
	it('Verify filter option "Active" and "VRA", "Azure"', function() {
		var searchText1 = ["Active"];
		var searchText2 = ["VRA", "azure"];
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("VRA");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Azure");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Active")).toBe(true,"Active checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Deleted")).toBe(false,"Deleted checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Delete in progress")).toBe(false,"Delete in progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Edit in progress")).toBe(false,"Delete in progress checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("VRA")).toBe(true,"VRA checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Amazon")).toBe(false,"Amazon checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Azure")).toBe(true,"Azure checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("IBM Cloud")).toBe(false,"IBM Cloud checkbox is not enabled");
		//Get the table data and check for filters selected
		expect(inventoryPage.verifyFiltersApplied(searchText1, filterByStatus)).toBe(true, "Active Filter is Applied as expected");
		expect(inventoryPage.verifyFiltersApplied(searchText2, filterByProvider)).toBe(true, " VRA and Azure Filters are Applied as expected")
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("VRA");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Azure");
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
	
	/* Verify filter option "Active", "Deleted" and "VRA", "Azure" */
	it('Verify filter option "Active", "Deleted" and "VRA", "Azure"', function() {
		var searchText1 = ["Active","Deleted"];
		var searchText2 = ["VRA", "azure"];
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Deleted");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("VRA");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Azure");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Active")).toBe(true,"Active checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Deleted")).toBe(true,"Deleted checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Delete in progress")).toBe(false,"Delete in progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Edit in progress")).toBe(false,"Delete in progress checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("VRA")).toBe(true,"VRA checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Amazon")).toBe(false,"Amazon checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Azure")).toBe(true,"Azure checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("IBM Cloud")).toBe(false,"IBM Cloud checkbox is not enabled");
		//Get the table data and check for filters selected
		expect(inventoryPage.verifyFiltersApplied(searchText1, filterByStatus)).toBe(true, "Active and Deleted Filters are Applied as expected");
		expect(inventoryPage.verifyFiltersApplied(searchText2, filterByProvider)).toBe(true, " VRA and Azure Filters are Applied as expected")
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Deleted");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("VRA");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Azure");
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
	
	/* Verify filter option "Deleted" and "Amazon", "IBM Cloud" */
	it('Verify filter option "Deleted" and "Amazon", "IBM Cloud"', function() {
		var searchText1 = ["Deleted"];
		var searchText2 = ["amazon", "IBM Cloud"];
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Active");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Deleted");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Amazon");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("IBM Cloud");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Active")).toBe(false,"Active checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Deleted")).toBe(true,"Deleted checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Delete in progress")).toBe(false,"Delete in progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Edit in progress")).toBe(false,"Edit in progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("VRA")).toBe(false,"VRA checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Amazon")).toBe(true,"Amazon checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Azure")).toBe(false,"Azure checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("IBM Cloud")).toBe(true,"IBM Cloud checkbox is enabled");
		//Get the table data and check for filters selected
		expect(inventoryPage.verifyFiltersApplied(searchText1, filterByStatus)).toBe(true, "Deleted Filter is Applied as expected");
		expect(inventoryPage.verifyFiltersApplied(searchText2, filterByProvider)).toBe(true, " Amazon and IBM Cloud Filters are Applied as expected")
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Active");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Deleted");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Amazon");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("IBM Cloud");
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
	
	/* Verify filter option "vRA" */
	it('Verify filter option "VRA"', function() {
		var searchText1 = [];
		var searchText2 = ["VRA"];
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Active");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("VRA");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Active")).toBe(false,"Active checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Deleted")).toBe(false,"Deleted checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Delete in progress")).toBe(false,"Delete in progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Edit in progress")).toBe(false,"Edit In Progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("VRA")).toBe(true,"VRA checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Amazon")).toBe(false,"Amazon checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Azure")).toBe(false,"Azure checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("IBM Cloud")).toBe(false,"IBM Cloud checkbox is not enabled");
		//Get the table data and check for filters selected
		expect(inventoryPage.verifyFiltersApplied(searchText2, filterByProvider)).toBe(true, " VRA Filter is Applied as expected")
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Active");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("VRA");
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
	
	/* Verify filter option "vRA" and "Azure" */
	it('Verify filter option "VRA" and "Azure', function() {
		var searchText1 = [];
		var searchText2 = ["VRA","azure"];
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Active");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("VRA");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Azure");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Active")).toBe(false,"Active checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Deleted")).toBe(false,"Deleted checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Delete in progress")).toBe(false,"Delete in progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Edit in progress")).toBe(false,"Edit in progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("VRA")).toBe(true,"VRA checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Amazon")).toBe(false,"Amazon checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Azure")).toBe(true,"Azure checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("IBM Cloud")).toBe(false,"IBM Cloud checkbox is not enabled");
		//Get the table data and check for filters selected
		expect(inventoryPage.verifyFiltersApplied(searchText2, filterByProvider)).toBe(true, " VRA and Azure Filters are Applied as expected")
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Active");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("VRA");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Azure");
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
	
	/* Verify filter option all selected */
	it('Verify filter option all selected', function() {
		var searchText1 = ["Active","Deleted"];
		var searchText2 = ["VRA","azure","amazon","IBM Cloud"];
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Deleted");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("VRA");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Azure");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Amazon");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("IBM Cloud");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Active")).toBe(true,"Active checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Deleted")).toBe(true,"Deleted checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Delete in progress")).toBe(false,"Delete in progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Edit in progress")).toBe(false,"Edit in progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("VRA")).toBe(true,"VRA checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Amazon")).toBe(true,"Amazon checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Azure")).toBe(true,"Azure checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("IBM Cloud")).toBe(true,"IBM Cloud checkbox is enabled");
		//Get the table data and check for filters selected
		expect(inventoryPage.verifyFiltersApplied(searchText1, filterByStatus)).toBe(true, "Active and Deleted Filters are Applied as expected");
		expect(inventoryPage.verifyFiltersApplied(searchText2, filterByProvider)).toBe(true, " VRA, Azure, Amazon and IBM Cloud Filters are Applied as expected")
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Deleted");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("VRA");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Azure");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("Amazon");
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("IBM Cloud");
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
	
	/* Verify filter option "Active" and "Softlayer" */
	it('Verify filter option "Active" and "Softlayer"', function() {
		var searchText1 = ["Active"];
		var searchText2 = ["IBM Cloud"];
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("IBM Cloud");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Active")).toBe(true,"Active checkbox is enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Deleted")).toBe(false,"Deleted checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Delete in progress")).toBe(false,"Delete in progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Edit in progress")).toBe(false,"Edit in progress checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("VRA")).toBe(false,"VRA checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Amazon")).toBe(false,"Amazon checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("Azure")).toBe(false,"Azure checkbox is not enabled");
		expect(inventoryPage.isSelectedFilterCheckBoxBasedOnName("IBM Cloud")).toBe(true,"IBM Cloud checkbox is enabled");
		//Get the table data and check for filters selected
		expect(inventoryPage.verifyFiltersApplied(searchText1, filterByStatus)).toBe(true, "Active Filter is Applied as expected");
		expect(inventoryPage.verifyFiltersApplied(searchText2, filterByProvider)).toBe(true, " IBM Cloud Filter is Applied as expected")
		util.waitForAngular();
		inventoryPage.clickFilterCheckBoxLabelBasedOnName("IBM Cloud");
		util.waitForAngular();
		inventoryPage.clickFilterIcon();
	});
	
	it('Verify dynamic filter', function(){
		
		inventoryPage.clickUserIcon();
		inventoryPage.clickAccountsMenuItem();
		accountsPage.checkIfAccountExists("AWS").then(function(value) {
			if (value == true){
				inventoryPage.clickInventoryTab();
				inventoryPage.clickFilterIcon();
				expect(inventoryPage.checkFilterLabelBasedOnName("Amazon")).toBe(true, "Amazon filter not present")
			}
		})
		inventoryPage.clickUserIcon();
		inventoryPage.clickAccountsMenuItem();
		accountsPage.checkIfAccountExists("IBM Cloud").then(function(value) {
			if (value == true){
				inventoryPage.clickInventoryTab();
				inventoryPage.clickFilterIcon();
				expect(inventoryPage.checkFilterLabelBasedOnName("IBM Cloud")).toBe(true, "IBM Cloud filter not present")
			}
		})
		inventoryPage.clickUserIcon();
		inventoryPage.clickAccountsMenuItem();
		accountsPage.checkIfAccountExists("VRA").then(function(value) {
			if (value == true){
				inventoryPage.clickInventoryTab();
				inventoryPage.clickFilterIcon();
				expect(inventoryPage.checkFilterLabelBasedOnName("VRA")).toBe(true, "VRA filter not present")
			}
		})
		inventoryPage.clickUserIcon();
		inventoryPage.clickAccountsMenuItem();
		accountsPage.checkIfAccountExists("AZURE").then(function(value) {
			if (value == true){
				inventoryPage.clickInventoryTab();
				inventoryPage.clickFilterIcon();
				expect(inventoryPage.checkFilterLabelBasedOnName("Azure")).toBe(true, "Azure filter not present")
			}
		})
		inventoryPage.clickUserIcon();
		inventoryPage.clickAccountsMenuItem();		
		accountsPage.checkIfAccountExists("ICD").then(function(value) {
			if (value == true){
				inventoryPage.clickInventoryTab();
				inventoryPage.clickFilterIcon();
				expect(inventoryPage.checkFilterLabelBasedOnName("Icd")).toBe(true, "ICD filter not present")
			}
		})
		inventoryPage.clickUserIcon();
		inventoryPage.clickAccountsMenuItem();
		accountsPage.checkIfAccountExists("MANAGEDSERVICE").then(function(value) {
			if (value == true){
				inventoryPage.clickInventoryTab();
				inventoryPage.clickFilterIcon();
				expect(inventoryPage.checkFilterLabelBasedOnName("Managedservice")).toBe(true, "ManagedService filter not present")
			}
		})
			
	})
});