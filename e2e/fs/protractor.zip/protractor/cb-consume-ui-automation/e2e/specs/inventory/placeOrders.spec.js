// This test file is for placing service orders for day2ops test runs

"use strict";
const fs = require('fs');
var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    AccountsPage = require('../../pageObjects/account.pageObject.js'),
    singleVMCentOSTemplate	= require('../../../testData/inventory/singleVMCentOs.json'),
    util = require('../../../helpers/util.js'),
    PlaceOrderPage = require('../../pageObjects/placeOrder.pageObject.js'),
    orderFlowUtil = require('../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../testData/appUrls.json'),
    Orders = require('../../pageObjects/orders.pageObject.js'),
    inventoryData = require('../../../testData/inventory/inventory.json');

describe('Place VRA order for upcoming tests', function() {
    var orders, homePage, dashBoard, inventoryPage, accountsPage, catalogPage, placeOrderPage; 
    var serviceName, modifiedParamMap;
    var messageStrings = {
    		providerName:'VRA',
    		orderSubmittedConfirmationMessage: 'Order Submitted !'
    		};


    beforeAll(function() {
        homePage = new HomePage(); 
        dashBoard = new DashBoard();
        inventoryPage = new InventoryPage();
        accountsPage = new AccountsPage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        orders = new Orders();
        browser.driver.manage().window().maximize();
        catalogPage.open();
    });

    afterAll(function() {

    });

    beforeEach(function() {
    	catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    	serviceName = "TestAutomation"+util.getRandomString(5);
		modifiedParamMap = {"Service Instance Name":serviceName};

    });
    
    it('Should Verify Create SingleVMCentOS service order and successful provisioning is working fine with default values', function() {
    	
    	var orderObject = {};
    	var centOsObj = JSON.parse(JSON.stringify(singleVMCentOSTemplate));
    	console.log(singleVMCentOSTemplate.bluePrintName)
    	catalogPage.clickConfigureButtonBasedOnName(singleVMCentOSTemplate.bluePrintName);
    	orderObject.servicename = serviceName;
    	orderFlowUtil.fillOrderDetails(singleVMCentOSTemplate, modifiedParamMap);
    	placeOrderPage.submitOrder();
    	orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
    	placeOrderPage.getTextOrderNumberOrderSubmittedModal().then(function(orderNumber){
    		console.log("Order Number : " + orderNumber);
    		console.log("Service Name : " + serviceName)
    		var data = fs.readFileSync('./testData/inventory/inventory.json', 'utf-8');
        	var toModify = JSON.parse(data);
        	toModify.orderNumber = orderNumber
        	toModify.Search_InstanceName = serviceName
        	fs.writeFileSync('./testData/inventory/inventory.json', JSON.stringify(toModify, null, 2), 'utf-8');
    	});
    	orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
    	placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
		orderFlowUtil.approveOrder(orderObject);
//		orders.closeServiceDetailsSlider();
		expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Provisioning in Progress');
		orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed',30);
		expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
		orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
			if (status == 'Completed') {
				console.log("Order got Completed")
			}
		})
    });
	
   
});
