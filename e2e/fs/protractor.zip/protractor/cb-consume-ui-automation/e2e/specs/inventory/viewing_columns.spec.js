"use strict";

var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
HomePage = require('../../pageObjects/home.pageObject.js'),
DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
util = require('../../../helpers/util.js');

var osType = util.getOSType();

describe('Test View Columns functionality in Inventory page', function() {
	var homePage, dashBoard, inventoryPage; 

		
		 beforeAll(function() {
		        homePage = new HomePage(); 
		        dashBoard = new DashBoard();
		        inventoryPage = new InventoryPage();
		        browser.driver.manage().window().maximize();
//		        ensureConsumeHome();
		        inventoryPage.open();
		 });

	    afterAll(function() {

	    });

	    beforeEach(function() {
	    	
	    });

	    it('Viewing Columns are sorted Functionality', function() {
	    	
	    	expect(inventoryPage.isInstanceNamePresent()).toBe(true);
			console.log("Instance Name is Present in Day2Ops Inventory UI page");
			expect(inventoryPage.isStatusPresent()).toBe(true);
			console.log("Status is Present in Day2Ops Inventory UI page");
			expect(inventoryPage.isProvisionedDatePresent()).toBe(true);
			console.log("Provisioned Date is Present in Day2Ops Inventory UI page");
			expect(inventoryPage.isProviderPresent()).toBe(true);
			console.log("Provider is Present in Day2Ops Inventory UI page");
			expect(inventoryPage.isProviderAccountPresent()).toBe(true);
			console.log("Provider Account is Present in Day2Ops Inventory UI page");
		//	expect(inventoryPage.isTeamPresent()).toBe(true);
		//	console.log("Team is Present in Day2Ops Inventory UI page");
	     
		/*	osType.then((text) => {
	            console.log("OS is: " + text);
	            return text;
	       }).then(function(text){
	    	   if (!(text.indexOf("Windows") >= 0)) {   
	    			expect(inventoryPage.isTeamPresent()).toBe(true);
	    			console.log("Team is Present in Day2Ops Inventory UI page");
	    		   }
	    	   else {
	    	*/		expect(inventoryPage.isTeamPresent()).toBe(true);
	    			console.log("Team is Present in Day2Ops Inventory UI page");
	    //	   }
	    //   })
			
			
			expect(inventoryPage.isOrderedByPresent()).toBe(false);
			expect(inventoryPage.isServiceNamePresent()).toBe(false);
			expect(inventoryPage.isEstimatedCostPresent()).toBe(false);
			expect(inventoryPage.isCurrencyPresent()).toBe(false);
			
		});
	    
	  //Verify if Column dots indicate which columns are viewed and also verify "Instance Name" column is always locked
		it('Column dots indicate which columns are viewed and "Instance Name" column is always locked', function() {
				
			inventoryPage.clickViewingColumnRightArrow();
			inventoryPage.clickViewingColumnRightArrow();
			inventoryPage.clickViewingColumnRightArrow();
			expect(inventoryPage.isInstanceNamePresent()).toBe(true, "Instance Name - Column displayed");
			
	    });
	    
		it('Arrows can be used to view additional columns and columns shifted on spot over', function() {
			
			inventoryPage.open();
				
			//Click right arrow to show last column
			inventoryPage.clickViewingColumnRightArrow();
			inventoryPage.clickViewingColumnRightArrow();
			inventoryPage.clickViewingColumnRightArrow();
			
			expect(inventoryPage.isInstanceNamePresent()).toBe(true, "Instance Name - Column displayed");
			expect(inventoryPage.isStatusPresent()).toBe(false, "Status - Column displayed");
		    expect(inventoryPage.isProvisionedDatePresent()).toBe(false, "Provisioned date column not displayed as expected");
		    expect(inventoryPage.isProviderPresent()).toBe(false, "Provider - Column displayed");
			expect(inventoryPage.isProviderAccountPresent()).toBe(true, "Provider Account - Column displayed");
			expect(inventoryPage.isTeamPresent()).toBe(true, "Team - Column displayed");
			expect(inventoryPage.isOrderedByPresent()).toBe(true, "Ordered By - Column displayed");
			expect(inventoryPage.isServiceNamePresent()).toBe(true, "Service Name - Column displayed");
			expect(inventoryPage.isEstimatedCostPresent()).toBe(true, "Estimated Cost - Column displayed");
			expect(inventoryPage.isCurrencyPresent()).toBe(false, "Currency - Column displayed");
		    
		//    expect(inventoryPage.isViewingColumn_Right_Arrow_Enabled()).toBe(false);
		//	expect(inventoryPage.isViewingColumn_Left_Arrow_Enabled()).toBe(true);
			
			//Click left arrow twice
			inventoryPage.clickviewingColumnsLeftArrow();
			inventoryPage.clickviewingColumnsLeftArrow();
			
			expect(inventoryPage.isInstanceNamePresent()).toBe(true, "Instance Name - Column displayed");
			expect(inventoryPage.isStatusPresent()).toBe(false, "Status - Column displayed");
		    expect(inventoryPage.isProvisionedDatePresent()).toBe(true, "Provisioned date column not displayed as expected");
		    expect(inventoryPage.isProviderPresent()).toBe(true, "Provider - Column displayed");
			expect(inventoryPage.isProviderAccountPresent()).toBe(true, "Provider Account - Column displayed");
			expect(inventoryPage.isTeamPresent()).toBe(true, "Team - Column displayed");
			expect(inventoryPage.isOrderedByPresent()).toBe(true, "Ordered By - Column displayed");
			expect(inventoryPage.isEstimatedCostPresent()).toBe(false, "Estimated Cost - Column displayed");
			expect(inventoryPage.isCurrencyPresent()).toBe(false, "Currency - Column displayed");

			
		 //   expect(inventoryPage.isViewingColumn_Right_Arrow_Enabled()).toBe(true);
		//	expect(inventoryPage.isViewingColumn_Left_Arrow_Enabled()).toBe(false);	
		});
		
it('Resize window and Check columns hidden', function() {
			
			inventoryPage.open();
			var width = 600;
			var height = 800
			console.log("Resolution tested :::::: 600 X 800");
			
			//isAngularApp(false);
			browserResize(width, height);
			browser.sleep(1000);
		    //isAngularApp(true);
		    
		    expect(inventoryPage.isInstanceNamePresent()).toBe(true, "Instance Name - Column displayed");
			expect(inventoryPage.isStatusPresent()).toBe(true, "Status - Column displayed");
		    expect(inventoryPage.isProvisionedDatePresent()).toBe(true, "Provisioned date column not displayed as expected");
		    expect(inventoryPage.isProviderPresent()).toBe(false, "Provider - Column displayed");
			expect(inventoryPage.isProviderAccountPresent()).toBe(false, "Provider Account - Column displayed");
			expect(inventoryPage.isTeamPresent()).toBe(false, "Team - Column displayed");
			
			//isAngularApp(false);
			var width = 1000;
			var height = 1200
			browserResize(width, height);
		    browser.sleep(1000);
		    //isAngularApp(true);
			
			expect(inventoryPage.isInstanceNamePresent()).toBe(true, "Instance Name - Column displayed");
			expect(inventoryPage.isStatusPresent()).toBe(true, "Status - Column displayed");
		    expect(inventoryPage.isProvisionedDatePresent()).toBe(true, "Provisioned date column not displayed as expected");
		    expect(inventoryPage.isProviderPresent()).toBe(true, "Provider - Column displayed");
			expect(inventoryPage.isProviderAccountPresent()).toBe(false, "Provider Account - Column displayed");
			expect(inventoryPage.isTeamPresent()).toBe(false, "Team - Column displayed");
		
	    });
		
		xit('Global column navigator will be locked when the VM section is expanded', function() {
			 
			inventoryPage.open();
			inventoryPage.expandFirstRow();
			browser.sleep(5000);
			expect(inventoryPage.isViewingColumnDisabled()).toBe(true);
		  
		});
});