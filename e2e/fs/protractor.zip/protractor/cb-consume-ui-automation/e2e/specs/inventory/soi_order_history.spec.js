// This test file is for testing filters on inventory page

"use strict";

	var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    AccountsPage = require('../../pageObjects/account.pageObject.js'),
    util = require('../../../helpers/util.js');
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    inventoryData = require('../../../testData/inventory/inventory.json'); 
	CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
	vraBluePrints = require('../../../testdata/vRAIntegration/vRABluePrints.json');



describe('SOI Order History', function() {
	 var orders, homePage, dashBoard, inventoryPage, catalogPage, ordersPage;

	 beforeAll(function() {
	        homePage = new HomePage();
	        dashBoard = new DashBoard();
	        catalogPage = new CatalogPage();
	        ordersPage = new OrdersPage();
			browser.driver.manage().window().setSize(1280, 1024);
			ensureConsumeHome();
	        inventoryPage = new InventoryPage();
	    });

	    afterAll(function() {
	    });

	    beforeEach(function() {
	    });
	    
	    	/*code to create vRA order */
		    it('Should Verify Create SingleVMCentOS service order and successful provisioning is working fine with default values - TC C160154', function() {
		    	console.log("You are going to place order")
		    	var i = 0;
		    	catalogPage.open();
		        var centOSObject = JSON.parse(JSON.stringify(vraBluePrints.CentOS65));
		        var returnObj = orderFlowUtil.createOrder(centOSObject);
		        orderFlowUtil.approveOrder(returnObj);
		        if(orderFlowUtil.verifyOrderStatus(returnObj) == 'Completed') console.log("true");
		        //expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe('Provisioning in Progress');
		        orderFlowUtil.waitForOrderCompletion(returnObj,30);
		        console.log("Provisioning Completed");
		    });
		    /* Verify View Services of Service ID's */
		    it('Searching Indiviual ServiceID ', function() {
		    	inventoryPage.open();
				browser.sleep(3000);
				util.waitForAngular();
				inventoryPage.clickSearchIcon();
				inventoryPage.clickGlificonIcon();
				inventoryPage.clickViewServiceIcon();
				inventoryPage.clickOrderHistorTab();
				browser.sleep(3000);
				expect(inventoryPage.isOrderIdPresent()).toBe(true, "Order Id - Column displayed");
				//expect(inventoryPage.isSubmittedDatePresent()).toBe(false, "Submitted Date - Column displayed");
			    expect(inventoryPage.isOperationTypePresent()).toBe(true, "Operation Type- Column displayed");
			    expect(inventoryPage.isStatusPresent()).toBe(true, "Status - Column displayed");
				expect(inventoryPage.isRequestedByPresent()).toBe(true, "Requested By - Column displayed");
				expect(inventoryPage.isEstimatedCostCurrencyPresent()).toBe(true, "Estimated Cost Currency - Column displayed");
				expect(inventoryPage.isErrorFailurePresent()).toBe(true, "ErrorFailure - Column displayed");
		    });
});
