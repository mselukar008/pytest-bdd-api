// This test file is for testing filters on inventory page

"use strict";

var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    util = require('../../../helpers/util.js'),
    inventoryData = require('../../../testData/inventory/inventory.json');

describe('Test Search functionality in Inventory page', function() {
    var orders, homePage, dashBoard, inventoryPage; 
    var  filterByStatus = "status";
    var filterByProvider = "provider";


    beforeAll(function() {
        homePage = new HomePage(); 
        dashBoard = new DashBoard();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
        inventoryPage.open();
    });

    afterAll(function() {
    	
    });

    beforeEach(function() {
    	inventoryPage.clickSearchIcon();
    });
    beforeAll(function(){
    	
    });
    
    /* Search for valid Instance Name */
	it('Search for valid Instance Name', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Search_InstanceName);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_InstanceName)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Search for valid Service Status */
	it('Search for valid Service Status', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Search_ServiceStatus);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_ServiceStatus)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Search for valid Provisioned Date */
	it('Search for valid Provisioned Date', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Search_ProvisionedDate);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_ProvisionedDate)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Search for valid Provider name */
	it('Search for valid Provider name', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Search_ProviderName);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_ProviderName)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Search for valid Provider Account */
	it('Search for valid Provider Account', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Search_ProviderAccount);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_ProviderAccount)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Search for valid Team Name */
	it('Search for valid Team Name', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Search_Team);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_Team)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Search for valid Ordered By */
	it('Search for valid Ordered By', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Search_OrderedBy);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_OrderedBy)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Search for valid Service Name */
	it('Search for valid Service Name', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Search_ServiceName);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_ServiceName)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Search for valid Estimated Cost */
	it('Search for valid Estimated Cost', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Search_EstimatedCost);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_EstimatedCost)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Search for valid Currency */
	it('Search for valid Currency', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Search_Currency);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_Currency)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Search for invalid string */
	it('Search for invalid string', function() {	
		//Get number of pages and do search in each page
		inventoryPage.searchInTable("~!#@$#^%*&^*");
		expect(inventoryPage.isPresentNoDataAvailableText()).toBe(true,"No Data available text found");
		expect(inventoryPage.countTableRecords()).toBe(0);
		inventoryPage.clickitemsPerPageText();
	});
	
	
	/* Search for Non Existing string */
	it('Search for Non Existing string', function() {	
		//Get number of pages and do search in each page
		//inventoryPage.clickSearchIcon();
		inventoryPage.searchInTable("Instanceeeeeeeee");
		expect(inventoryPage.isPresentNoDataAvailableText()).toBe(true,"No Data available text found");
		expect(inventoryPage.countTableRecords()).toBe(0);
		inventoryPage.clickitemsPerPageText();
	});
	
	/* Search for Non Existing long string */
	it('Search for Non Existing long string', function() {	
		//Get number of pages and do search in each page
		//inventoryPage.clickSearchIcon();
		inventoryPage.searchInTable("Instanceeeeeeeee of vRA to Search for instance");
		expect(inventoryPage.isPresentNoDataAvailableText()).toBe(true,"No Data available text found");
		expect(inventoryPage.countTableRecords()).toBe(0);
		inventoryPage.clickitemsPerPageText();
	});
	
	/* Partial Text Search for valid Instance Name */
	it('Partial Text Search for valid Instance Name', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Partialsearch_InstanceName);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Partialsearch_InstanceName)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Partial Text Search for valid Service Status */
	it('Partial Text Search for valid Service Status', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Partialsearch_ServiceStatus);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Partialsearch_ServiceStatus)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Partial Text Search for valid Provisioned Date */
	it('Partial Text Search for valid Provisioned Date', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Partialsearch_ProvisionedDate);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Partialsearch_ProvisionedDate)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Partial Text Search for valid Provider Name */
	it('Partial Text Search for valid Provider Name', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Partialsearch_ProviderName);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Partialsearch_ProviderName)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Partial Text Search for valid Provider Account */
	it('Partial Text Search for valid Provider Account', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Partialsearch_ProviderAccount);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Partialsearch_ProviderAccount)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Partial Text Search for valid Team */
	it('Partial Text Search for valid Team', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Partialsearch_Team);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Partialsearch_Team)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Partial Text Search for valid Ordered By */
	it('Partial Text Search for valid Ordered By', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Partialsearch_OrderedBy);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Partialsearch_OrderedBy)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Partial Text Search for valid Service Name */
	it('Partial Text Search for valid Service Name', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Partialsearch_ServiceName);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Partialsearch_ServiceName)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Partial Text Search for valid Estimated Cost */
	it('Partial Text Search for valid Estimated Cost', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Partialsearch_EstimatedCost);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Partialsearch_EstimatedCost)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	/* Partial Text Search for valid Currency */
	it('Partial Text Search for valid Currency', function() {	
		//Get number of pages and do search in each page
		inventoryPage.getNumberOfPagesText().then(function (result) {
		if(result>2){result = 1}
		for(var page = 1;page<=result; page++){
			if(page>1)inventoryPage.clickPaginationRightArrow();
			util.waitForAngular();
			if(page ==1) inventoryPage.searchInTable(inventoryData.Partialsearch_Currency);
			expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Partialsearch_Currency)).toBe(true,"Search text found");
			inventoryPage.clickviewingColumnsLeftArrow_gotoFirst();
		}
		inventoryPage.clickPaginationLeftArrow_gotoFirst(result);
				
		});
	});
	
	
});