// This test file is for testing filters on inventory page

"use strict";

var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    util = require('../../../helpers/util.js'),
    inventoryData = require('../../../testData/inventory/inventory.json');

describe('Test Search functionality in Inventory page', function() {
    var orders, homePage, dashBoard, inventoryPage; 
    var  filterByStatus = "status";
    var filterByProvider = "provider";
    var Search_InstanceName = "brownfield"


    beforeAll(function() {
        homePage = new HomePage(); 
        dashBoard = new DashBoard();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
        ensureConsumeHome();
        //ensureConsumeHomeWithRoles("d2ops_buyer");
    });

    afterAll(function() {
    	
    });

    beforeEach(function() {
    	inventoryPage.clickSearchIcon();
    });
    beforeAll(function(){
    	
    });
    
    /* Call Import API and search for the brownfield SOI in Inventory page */
	it('Call Import API and search for the brownfield SOI in Inventory page', function() {	
		//Call import API
		inventoryPage.callImportAPI().then(function(result){
			Search_InstanceName = result["SID"];
		})
		//Search for the brownfield SOI from Inventory page
		inventoryPage.open();
		util.waitForAngular();
		inventoryPage.searchInTable(inventoryData.Search_InstanceName);
		expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_InstanceName)).toBe(true,"Search text found");				
	});
    
    /* View properties of brownfield SOI */
	it('View properties of brownfield SOI', function() {	
		inventoryPage.clickSelectedSOIGlificon();
		expect(inventoryPage.isEnabledViewServiceMenuOption()).toBe(true,"View Service menu option is Enabled");
		expect(inventoryPage.isEnabledRefreshStatusMenuOption()).toBe(true,"Refresh Status menu option is Enabled");
		expect(inventoryPage.isEnabledDeleteServiceMenuOption()).toBe(true,"Delete Service menu option is Enabled");
        inventoryPage.clickViewService();
		expect(inventoryPage.isServiceNameOfSelectedSOIAvailable()).toBe(true, " Service name is present");
		expect(inventoryPage.isProviderServiceInstanceIdSOIAvailable()).toBe(true, "Provider Service Instance Id is present")
		nventoryPage.clickViewServiceClosebutton();
	});
	
	/* Brownfield SOI Refresh status operation*/
	it('Brownfield SOI Refresh status operation', function() {
		inventoryPage.clickSelectedSOIGlificon();
		expect(inventoryPage.isEnabledRefreshStatusMenuOption()).toBe(true,"Refresh Status menu option is Enabled");
		inventoryPage.clickRefreshServiceIcon();
		inventoryPage.clickRefreshServiceOakybutton();
		expect(inventoryPage.getstatusProp()).toBe("Refreshing...", "Refresh status working for brownfield SOI");
	});
	
	/* Check expand of brownfield SOI */
	it('Check expand of brownfield SOI', function() {	
		inventoryPage.clickExpandFirstRow();
		browser.wait(3000);
		expect(inventoryPage.isExistsFirstChildComponent()).toBe(true,"Brownfield SOI can be expanded")
	});
	
	/* View component properties of brownfield SOI */
	it('View component properties of brownfield SOI', function() {
		browser.sleep(3000);
		inventoryPage.clickGlificonIconOfSOC();
		expect(inventoryPage.isEnabledViewComponentActionMenuOption()).toBe(true,"Delete Service menu option is Enabled");
		inventoryPage.clickViewComponentActionMenuOption();
		browser.sleep(2000);
		//Verify view component properties here
		expect(inventoryPage.iscomponentTypePropAvailable()).toContain(true,"SOC properties available");
		inventoryPage.clickViewComponentCloseButton();
		
	});
	
	/* Perform Turn Off on brownfield SOC */
	it('Perform Turn Off on brownfield SOC', function() {
		browser.sleep(3000);
		inventoryPage.clickGlificonIconOfSOC();
		inventoryPage.clickTurnOffActionMenuOption();
		inventoryPage.clickTurnOffOakybutton();
		browser.sleep(5000);
		expect(inventoryPage.getstatusProp()).toBe("Turning Off", "Turn Off working for brownfield SOI");inventoryPage.clickViewComponentCloseButton();
		browser.sleep(5000);
		expect(inventoryPage.getstatusProp()).toBe("Off", "Turn Off working for brownfield SOI");inventoryPage.clickViewComponentCloseButton();		
	});
	
	/* Perform Turn On on brownfield SOC */
	it('Perform Turn On on brownfield SOC', function() {
		browser.sleep(3000);
		inventoryPage.clickGlificonIconOfSOC();
		inventoryPage.clickTurnOnActionMenuOption();
		inventoryPage.clickTurnOnOakybutton();
		browser.sleep(5000);
		expect(inventoryPage.getstatusProp()).toBe("Turning On", "Turn On working for brownfield SOI");inventoryPage.clickViewComponentCloseButton();
		browser.sleep(5000);
		expect(inventoryPage.getstatusProp()).toBe("On", "Turn On working for brownfield SOI");inventoryPage.clickViewComponentCloseButton();		
	});
	
	/* Perform Turn On on brownfield SOC */
	it('Perform Reboot on brownfield SOC', function() {
		browser.sleep(3000);
		inventoryPage.clickGlificonIconOfSOC();
		inventoryPage.clickRebootActionMenuOption();
		inventoryPage.clickRebootOakybutton();
		browser.sleep(5000);
		expect(inventoryPage.getstatusProp()).toBe("Rebooting", "Reboot working for brownfield SOI");inventoryPage.clickViewComponentCloseButton();
		browser.sleep(5000);
		expect(inventoryPage.getstatusProp()).toBe("On", "Reboot working for brownfield SOI");inventoryPage.clickViewComponentCloseButton();
		inventoryPage.clickExpandFirstRow();		
	});
	
	/* Perform Access Component action on brownfield SOC */
	it('Perform Access Component action on brownfield SOC', function() {
		browser.sleep(3000);
		inventoryPage.clickGlificonIconOfSOC();
		inventoryPage.clickAccessComponentActionMenuOption();
		browser.sleep(5000);
		var title = browser.getTitle();
		 title.then(function(pagetitle){
		    expect(pagetitle).toContain("access","Access Component is working")
		})		
	});
	
	/* Perform Refresh Status action on brownfield SOC */
	it('Perform Refresh Status action on brownfield SOC', function() {
		browser.sleep(3000);
		inventoryPage.clickGlificonIconOfSOC();
		inventoryPage.clickRefreshStatusActionMenuOption();
		inventoryPage.clickRefreshStatusOakybutton();
		expect(inventoryPage.getstatusProp()).toBe("Refreshing...", "Refresh status working for brownfield SOC");
		inventoryPage.clickExpandFirstRow();		
	});
	
	/* Verify bulk operations on brownfield SOC */
	it('Verify bulk operations on brownfield SOC', function() {
		browser.sleep(3000);
		inventoryPage.clickExpandFirstRow();
		inventoryPage.clicksOCFirstChildComponent();
		inventoryPage.clickBatchActionsMenuGlifficon();
		expect(inventoryPage.isEnabledbatchActionsMenuSOCTurnOn()).toBe(true,"Turn On Selected menu option is Enabled");
		expect(inventoryPage.isEnabledbatchActionsMenuSOCTurnOff()).toBe(true,"Turn Off Selected menu option is Enabled");
		expect(inventoryPage.isEnabledbatchActionsMenuSOCReboot()).toBe(true,"Reboot Selected menu option is Enabled");
		expect(inventoryPage.isEnabledbatchActionsMenuSOCRefresh()).toBe(true,"Refresh Statuses menu option is Enabled");
		inventoryPage.clicksOCFirstChildComponent();
		inventoryPage.clickExpandFirstRow();
	});
	
	/* Verify bulk operations on brownfield SOI */
	it('Verify bulk operations on brownfield SOI', function() {
		inventoryPage.clickSOIcheckbox();
		inventoryPage.clickBatchActionsMenuGlifficon();
		expect(inventoryPage.isEnabledbatchActionsMenuDeleteSelected()).toBe(true,"Delete Selected batch action menu option is Enabled");
		expect(inventoryPage.isEnabledbatchActionsMenuRefreshStatuses()).toBe(true,"Refresh Statuses batch action menu option is Enabled");
		inventoryPage.clickSOIcheckbox();
	});
	
	/* Brownfield SOI Delete operation*/
	it('Brownfield SOI Delete operation', function() {
		inventoryPage.clickSelectedSOIGlificon();
		inventoryPage.clickDeleteServiceIcon();
		inventoryPage.clickDeleteServicecheckboxIcon();
		inventoryPage.clickDeleteServiceOakybutton();
		util.waitForAngular();
		inventoryPage.searchInTable(inventoryData.Search_InstanceName);
		expect(inventoryPage.getstatusProp()).toBe("Delete In Progress", "Delete working for brownfield SOI");
	});
	
});