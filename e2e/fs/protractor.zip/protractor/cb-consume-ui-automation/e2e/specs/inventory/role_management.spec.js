// This test file is for testing filters on inventory page

"use strict";

var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    util = require('../../../helpers/util.js'),
    orderFlowUtil = require('../../../helpers/orderFlowUtil.js'),
    inventoryData = require('../../../testData/inventory/inventory.json');

describe('Test Search functionality in Inventory page', function() {
    var orders, homePage, dashBoard, inventoryPage; 
    
    var fs = require('fs');
    
    var awsBluePrints;
    if(browser.params.url.includes('cb-qa-d2ops'))
    	awsBluePrints	= require('../../../testData/inventory/aWSBluePrint.json');
    var VPCEC2Oject = JSON.parse(JSON.stringify(awsBluePrints.VPCSingleInstanceForEC2));
    var returnObj;

    beforeAll(function() {
        homePage = new HomePage(); 
        dashBoard = new DashBoard();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
//        ensureConsumeHome();
        //ensureConsumeHomeWithRoles("d2ops_buyer");
    });

    afterAll(function() {
    	
    });

    beforeEach(function() {
    	
    });
    beforeAll(function(){
    	
    });
        
    it('Verify AWS IAAS Provision Network VPC is working fine from consume App - TC C167628', function() { 
		returnObj = orderFlowUtil.createOrder(VPCEC2Oject);
		orderFlowUtil.approveOrder(returnObj);
		expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe('Provisioning in Progress');
		orderFlowUtil.waitForOrderCompletion(returnObj,30);
    });
    
    /* Verify VIEW permission on Inventory page */
	it('Verify VIEW permission on Inventory page', function() {	
		inventoryPage.open();
		inventoryPage.clickSearchIcon();
		inventoryPage.searchInTable(inventoryData.Search_InstanceName);
		expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_InstanceName)).toBe(true,"Search text found");
	});
	
	/* Verify CRUD permission on Inventory page */
	it('Verify CRUD permission on Inventory page',function(){
		
		//Verify individual operations
		inventoryPage.clickGlificonIcon();
		browser.sleep(3000);
		util.waitForAngular();
		expect(inventoryPage.isEnabledViewServiceMenuOption()).toBe(true,"View Service menu option is Enabled");
		expect(inventoryPage.isEnabledRefreshStatusMenuOption()).toBe(true,"Refresh Status menu option is Enabled");
		expect(inventoryPage.isEnabledDeleteServiceMenuOption()).toBe(true,"Delete Service menu option is Enabled");
		util.waitForAngular();
		inventoryPage.clickViewServiceIcon();
		//Verify view service properties here
		
		inventoryPage.clickViewServiceClosebutton();
		
		//Verify bulk operations
		inventoryPage.clickSOIcheckbox();
		inventoryPage.clickBatchActionsMenuGlifficon();
		expect(inventoryPage.isEnabledbatchActionsMenuDeleteSelected()).toBe(false,"Delete Selected batch action menu option is Disabled");
		expect(inventoryPage.isEnabledbatchActionsMenuRefreshStatuses()).toBe(true,"Refresh Statuses batch action menu option is Enabled");
		inventoryPage.clickSOIcheckbox();
	});
	
	/* Verify OPERATIONS permission on Inventory page */
	it('Verify OPERATIONS permission on Inventory page',function(){
		inventoryPage.clickExpandFirstRow();
		browser.sleep(3000);
		inventoryPage.clickGlificonIconOfSOC();
		expect(inventoryPage.isEnabledTurnOnActionMenuOption()).toBe(false,"View Service menu option is Enabled");
		expect(inventoryPage.isEnabledTurnOffActionMenuOption()).toBe(false,"Refresh Status menu option is Enabled");
		expect(inventoryPage.isEnabledRebootActionMenuOption()).toBe(false,"Delete Service menu option is Enabled");
		expect(inventoryPage.isEnabledRefreshStatusActionMenuOption()).toBe(false,"Delete Service menu option is Enabled");
		expect(inventoryPage.isEnabledViewComponentActionMenuOption()).toBe(true,"Delete Service menu option is Enabled");
		expect(inventoryPage.isEnabledAccessComponentActionMenuOption()).toBe(false,"Delete Service menu option is Enabled");
		inventoryPage.clickViewComponentActionMenuOption();
		browser.sleep(2000);
		//Verify view component properties here
		expect(inventoryPage.getcomponentTypeProp()).toContain("AWS::EC2::Subnet","Verification for Component Type property");
		expect(inventoryPage.getnameProp()).not.toBe("","Verification for Name property");
		expect(inventoryPage.getstatusProp()).toContain("CREATE_COMPLETE","Verification for Status property");
		expect(inventoryPage.getproviderNameProp()).toContain(VPCEC2Oject.provider,"Verification for Provider Name property");
		expect(inventoryPage.getresourceIdProp()).not.toBe("","Verification for Resource Id property");
		expect(inventoryPage.gettagsProp()).toContain("aws:","Verification for Tags property");
		expect(inventoryPage.getavailabilityZoneProp()).toContain(VPCEC2Oject.dropdownLabels[0].value,"Verification for Availability Zone property");
		expect(inventoryPage.getavailableIpAddressCountProp()).toBeGreaterThan(0,"Verification for Available IP Address Count property");
		expect(inventoryPage.getcidrBlockProp()).toBe(VPCEC2Oject.textinputdetails[2].value,"Verification for CIDR Block property");
		expect(inventoryPage.getdefaultForAzProp()).toBe(false,"Verification for Default For AZ property");
		expect(inventoryPage.getmapPublicIpOnLaunchProp()).toBe(false,"Verification for Map Public IP On Launch property");
		expect(inventoryPage.getstateProp()).toBe("available","Verification for State property");
		expect(inventoryPage.getsubnetIdProp()).toContain("subnet","Verification for Subnet Id property");
		expect(inventoryPage.getvpcIdProp()).toContain("vpc","Verification for VPC Id property");
		expect(inventoryPage.getassignIpv6aAddressOnCreationProp()).toBe(false,"Verification for Assign Ipv6 Address On Creation property");
		expect(inventoryPage.getipv6CidrBlockAssociationSetProp()).not.toBe("[]","Verification for Cidr Block Association Set property");
		browser.sleep(2000);
		
		//VPCEC2Oject
		//toBeNonEmptyObject
		
		inventoryPage.clickViewComponentCloseButton();

		//Verify bulk operations
		inventoryPage.clicksOCFirstChildComponent();
		inventoryPage.clicksOCSecondChildComponent();
		inventoryPage.clickBatchActionsMenuGlifficon();
		expect(inventoryPage.isEnabledbatchActionsMenuSOCTurnOn()).toBe(false,"Turn On Selected menu option is not Enabled");
		expect(inventoryPage.isEnabledbatchActionsMenuSOCTurnOff()).toBe(false,"Turn Off Selected menu option is not Enabled");
		expect(inventoryPage.isEnabledbatchActionsMenuSOCReboot()).toBe(false,"Reboot Selected menu option is not Enabled");
		expect(inventoryPage.isEnabledbatchActionsMenuSOCRefresh()).toBe(false,"Refresh Statuses menu option is not Enabled");
		inventoryPage.clicksOCFirstChildComponent();
		inventoryPage.clicksOCSecondChildComponent();
		
	});
	
	it('Delete AWS order', function() { 
		orderFlowUtil.deleteService(returnObj);
		expect(orderFlowUtil.verifyOrderTypeDeletedOrder()).toBe('Delete');
		orderFlowUtil.approveDeletedOrder();
		expect(orderFlowUtil.verifyOrderStatusDeletedOrder()).toBe('Provisioning in Progress');	
    });

	
	
});