// This test file is for testing filters on inventory page

"use strict";

var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    util = require('../../../helpers/util.js'),
	CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
	OrdersPage = require('../../pageObjects/orders.pageObject.js'),
	DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
	util = require('../../../helpers/util.js'),
	//inventoryData = require('../../../testData/inventory/inventory.json'),
	orderFlowUtil = require('../../../helpers/orderFlowUtil.js'),
	vraBluePrints = require('../../../testData/vRAIntegration/vRABluePrints.json');	

describe('Individual Asset Actions Test', function() {
	 var orders, homePage, dashBoard, inventoryPage, catalogPage, ordersPage; 


	 beforeAll(function() {
	        homePage = new HomePage(); 
	        dashBoard = new DashBoard();
	        catalogPage = new CatalogPage();
	        ordersPage = new OrdersPage();
	        browser.driver.manage().window().maximize();
//	        ensureConsumeHome();
	        inventoryPage = new InventoryPage();
	    });

	    afterAll(function() {

	    });

	    beforeEach(function() {
	    	
	    });
	    
	    /*code to create vRA order */
	    it('Should Verify Create SingleVMCentOS service order and successful provisioning is working fine with default values - TC C160154', function() {
	    	console.log("You are going to place order")
	    	var i = 0;
	    	catalogPage.open();
	        var centOSObject = JSON.parse(JSON.stringify(vraBluePrints.SingleVMCentOS));
	        var returnObj = orderFlowUtil.createOrder(centOSObject);
	        orderFlowUtil.approveOrder(returnObj);
	        if(orderFlowUtil.verifyOrderStatus(returnObj) == 'Completed') console.log("true");
	        //expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe('Provisioning in Progress');
	        orderFlowUtil.waitForOrderCompletion(returnObj,30);
	    });
	
    /* Verify View Assets of Service ID's */
    it('Searching Indiviual ServiceID ', function() {
    	inventoryPage.open();
		browser.wait(3000);
		util.waitForAngular();
		inventoryPage.clickSearchIcon();
		expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_InstanceName)).toBe(true,"Search text found");
		inventoryPage.clickExpansionIcon();
		browser.wait(3000);
    });

});