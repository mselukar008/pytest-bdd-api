// This test file is for testing filters on inventory page

"use strict";

var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
	Orders = require('../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../pageObjects/placeOrder.pageObject.js'),
    util = require('../../../helpers/util.js'),
    inventoryData = require('../../../testData/inventory/inventory.json'),
    orderFlowUtil = require('../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../testData/appUrls.json'),
    tier3TraditionalTemplate = require('../../../testData/OrderIntegration/VRA/3tierTraditionalWorkload.json'),
    singleVMCentOSTemplate	= require('../../../testData/OrderIntegration/VRA/singleVMCentOs.json'),
    vraBluePrints = require('../../../testData/vRAIntegration/vRABluePrints.json');

describe('Test e2d d2ops functionality', function() {
    var orders, homePage, dashBoard, inventoryPage, catalogPage, placeOrderPage;


    beforeAll(function() {
        orders = new Orders();
        homePage = new HomePage(); 
        dashBoard = new DashBoard();
        catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    afterAll(function() {
    	
    });

    beforeEach(function() {
    	
    });
    beforeAll(function(){
    	
    });
    
    /* End to End Day2 operations flow */
	it('Search for valid Instance Name', function() {	
		
		//Search for valid Instance Name
		inventoryPage.open();
		inventoryPage.clickSearchIcon();
		inventoryPage.searchInTable(inventoryData.Search_InstanceName);
		expect(inventoryPage.verifySearchOnCurrentPage(inventoryData.Search_InstanceName)).toBe(true,"Search text found");
	});
	
	it('SOI View Service properties slider', function() {	

		//Click on Glifficon and select View Service on SOI
		inventoryPage.clickGlificonIcon();
		util.waitForAngular();
		expect(inventoryPage.isEnabledViewServiceMenuOption()).toBe(true,"View Service menu option is Enabled");
		expect(inventoryPage.isEnabledRefreshStatusMenuOption()).toBe(true,"Refresh Status menu option is Enabled");
		expect(inventoryPage.isEnabledDeleteServiceMenuOption()).toBe(true,"Delete Service menu option is Enabled");
		util.waitForAngular();
		inventoryPage.clickViewServiceIcon();
		expect(inventoryPage.getserviceInstanceName()).toContain(inventoryData.Search_InstanceName, "Service name is present")
		inventoryPage.clickSliderCloseIcon();
		browser.sleep(3000);
		
	});
	
//	it('SOI Refresh Status', function() {	
//
//		//Click on Glifficon and select Refresh Status on SOI
//		inventoryPage.clickGlificonIcon();
//		util.waitForAngular();
//		inventoryPage.clickRefreshServiceIcon();
//		expect(inventoryPage.getRefreshStatusDialogConfirmText()).toContain("Do you really want to perform this action?", "Service name is present")
//		inventoryPage.clickRefreshStatusOakybutton();
////		expect(inventoryPage.getsoiStatus()).toContain("Refreshing", "Service name is present")
//		browser.sleep(3000);
//		expect(inventoryPage.getsoiStatus()).toContain("Active", "Service name is present")
//	});
	
	it('Expand SOI, Verify Component properties slider, perform all operations on VM', function() {	
		//Expand Instance
		inventoryPage.clickExpandFirstRow().then(function () {
		browser.sleep(3000);
		
			//Click Glifficon of first child and check which is VM
			inventoryPage.findisVM().then(function(isVM){
			if (isVM){
				inventoryPage.testRebootFirst();
				browser.sleep(20000);
				expect(inventoryPage.getsocStatusFirst()).toBe("On", "VM is in ON state after Reboot")				
				inventoryPage.testTurnOffFirst();
				browser.sleep(20000);
				expect(inventoryPage.getsocStatusFirst()).toBe("Off", "VM is in OFF state after Turning Off")	
				inventoryPage.testTurnOnFirst();
				browser.sleep(30000);
				expect(inventoryPage.getsocStatusFirst()).toBe("On", "VM is in ON state after Turning On")	
			}
			else{
				inventoryPage.testRebootSecond();
				browser.sleep(10000);
				expect(inventoryPage.getsocStatusSecond()).toBe("On", "VM is in ON state after Reboot")
				inventoryPage.testTurnOffSecond();
				browser.sleep(10000);
				expect(inventoryPage.getsocStatusSecond()).toBe("Off", "VM is in OFF state after Turning Off")
				inventoryPage.testTurnOnSecond();
				browser.sleep(30000);
				expect(inventoryPage.getsocStatusSecond()).toBe("On", "VM is in ON state after Turning On")
			}
				
			})
	
		});
		
	});
	
});