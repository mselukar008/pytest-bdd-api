// This test file is for testing filters on inventory page

"use strict";

var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    util = require('../../../helpers/util.js'),
	CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
	OrdersPage = require('../../pageObjects/orders.pageObject.js'),
	DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
	util = require('../../../helpers/util.js'),
	inventoryData = require('../../../testData/inventory/inventory.json'),
	orderFlowUtil = require('../../../helpers/orderFlowUtil.js'),
	vraBluePrints = require('../../../testData/vRAIntegration/vRABluePrints.json');	

describe('Individual Service Actions Test', function() {
	 var orders, homePage, dashBoard, inventoryPage, catalogPage, ordersPage; 
	 var orderNumber, SID;


	 beforeAll(function() {
	        homePage = new HomePage(); 
	        dashBoard = new DashBoard();
	        catalogPage = new CatalogPage();
	        ordersPage = new OrdersPage();
	        browser.driver.manage().window().maximize();
//	        ensureConsumeHome();
	        inventoryPage = new InventoryPage();
	    });

	    afterAll(function() {

	    });

	    beforeEach(function() {
	    	
	    });
	    
	    /*code to create vRA order */
	    it('Should Verify Create SingleVMCentOS service order and successful provisioning is working fine with default values - TC C160154', function() {
	    	console.log("You are going to place order")
	    	var i = 0;
	    	catalogPage.open();
	        var centOSObject = JSON.parse(JSON.stringify(vraBluePrints.SingleVMCentOS));
	        var returnObj = orderFlowUtil.createOrder(centOSObject);
	        orderNumber = orderObject.orderNumber;
	        SID = orderObject.SID;
	        orderFlowUtil.approveOrder(returnObj);
	        if(orderFlowUtil.verifyOrderStatus(returnObj) == 'Completed') console.log("true");
	        //expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe('Provisioning in Progress');
	        orderFlowUtil.waitForOrderCompletion(returnObj,30);
	        
	    });
	
    /* Verify View Services of Service ID's */
    it('Searching Indiviual ServiceID ', function() {
    	inventoryPage.open();
		browser.sleep(3000);
		util.waitForAngular();
		inventoryPage.clickSearchIcon();
		//inventoryPage.searchInTable();
		inventoryPage.clickGlificonIcon();
		inventoryPage.clickViewServiceIcon();
		inventoryPage.clickViewServiceClosebutton();
    });
        
    /* Verify Refresh Services of Service ID's */
    it('Refresh Indiviual ServiceID ', function() {
    	inventoryPage.open();
		browser.sleep(3000);
		util.waitForAngular();
		inventoryPage.clickSearchIcon();
		inventoryPage.clickGlificonIcon();
		inventoryPage.clickRefreshServiceIcon();
		inventoryPage.clickRefreshServiceOakybutton();
    });		
    
    /* Verify Delete Services of Service ID's */
    it('Delete Indiviual ServiceID ', function() {
    	var currentDateTime = new Date();
		var year = currentDateTime.getUTCFullYear();
    	inventoryPage.open();
		browser.sleep(3000);
		util.waitForAngular();
		inventoryPage.clickSearchIcon();
		inventoryPage.clickGlificonIcon();
		inventoryPage.clickDeleteServiceIcon();
		inventoryPage.clickDeleteServicecheckboxIcon();
		inventoryPage.clickdeleteServiceConfirmDialogCancelButton();
		//Cancel delete order confirmation dialog and check delete order notification  not displayed
		browser.sleep(3000);
		expect(inventoryPage.isPresentdeleteServiceModalNotification()).toBe(false,"Delete order notification closed")
		inventoryPage.clickGlificonIcon();
		inventoryPage.clickDeleteServiceIcon();
		inventoryPage.clickDeleteServicecheckboxIcon();
		inventoryPage.clickDeleteServiceOakybutton();
		//Ok delete order confirmation dialog and check delete order notification is displayed
		browser.sleep(3000);
		//Check for order notification popup 
		expect(inventoryPage.isPresentdeleteServiceModalNotification()).toBe(true,"Delete order pop up notification shown");
		//Check the order notification message. Check for orderid, time and message
		expect(inventoryPage.getTextdeleteOrderSubmittedHeaderModal()).toContain("Order Submitted !","Header for delete order notification displayed");
		expect(inventoryPage.getTextdeleteServiceModalNotificationMessage()).toContain("Successfully updated SOI status to Delete In Progress for SOI: " + SID,"Notification has order number displayed");
		expect(inventoryPage.getTextOrderNumberDeleteOrderSubmittedModal()).not.toBeNull();
		expect(inventoryPage.getTextOrderNumberDeleteOrderSubmittedModal()).toContain(orderNumber,"Notification has Order Number displayed");
		expect(inventoryPage.getTextOrderedDateDeleteOrderSubmittedModal()).toContain(year,"Notification has Ordered Date displayed");
		
		//Close the popup
		inventoryPage.clickdeleteServiceModalNotificationBoxClose();
		expect(inventoryPage.isPresentdeleteServiceModalNotification()).toBe(false,"Delete order notification closed")
		browser.sleep(3000);
    });		
    
    /*  Verify BOM for Delete Service action */
    xit('Delete Indiviual ServiceID ', function() {
    	inventoryPage.open();
		browser.sleep(3000);
		util.waitForAngular();
		//inventoryPage.clickSearchIcon();
		inventoryPage.clickGlificonIcon();
		inventoryPage.clickDeleteServiceIcon();
		inventoryPage.clickDeleteServicecheckboxIcon();
		inventoryPage.clickDeleteServiceOakybutton();
		browser.sleep(3000);	
		ordersPage.open();
		expect(ordersPage.getTextFirstAmountOrdersTable()).not.toBe("$0.00", "Value is less than or equal to zero")
		ordersPage.clickFirstViewDetailsOrdersTable();
		ordersPage.clickBillOfMaterialsTabOrderDetails();
		expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).not.toBe("$0.00", "Value is less than or equal to zero")	
		
   });
	
    it('Verify primaryInfo values from API call and UI', function(){
    	console.log("You are going to place order")
        catalogPage.open();
    	var centOSObject = JSON.parse(JSON.stringify(vraBluePrints.CentOS65));
    	var returnObj = orderFlowUtil.createOrder(centOSObject);
    	orderFlowUtil.approveOrder(returnObj);
    	if(orderFlowUtil.verifyOrderStatus(returnObj) == 'Completed') console.log("true");
    	orderFlowUtil.waitForOrderCompletion(returnObj,30);
    	
    	var data = fs.readFileSync('./testData/inventory/inventory.json', 'utf-8');
    	var toModify = JSON.parse(data);
    	    
    	console.log("Service Name: " + toModify.Search_InstanceName)
    	var serviceName = toModify.Search_InstanceName;
    	   
    	inventoryPage.open();
    	inventoryPage.clickFilterIcon();
    	inventoryPage.clickFilterCheckBoxLabelBasedOnName("VRA");
    	inventoryPage.clickExpansionIcon();
    	browser.sleep(3000);
    	isAngularApp(false);
    	var index;
    	var machineNameFromAPI;
    	
    	serviceListingAPI.getServiceListingAPIResponse(serviceName).then((serviceListingAPIResponse) => {
    		var resbody = JSON.parse(serviceListingAPIResponse)
    		console.log('\n' + 'SID: ' + resbody["docs"][0]["SID"])
    	    return resbody["docs"][0]["SID"];
        }).then(function(serviceInstanceID){
            serviceDetailsAPI.getServiceDetailsAPIResponse(serviceInstanceID).then(async function(serviceDetailsAPIResponse) {
            	var jsonResponse = JSON.parse(serviceDetailsAPIResponse)
                for (var i=0 ; i< 2; i++){                 
                	if (jsonResponse["resources"][i]["resourceType"] == "Virtual Machine"){
                		index = i+1;
                		for (var j=0 ; j<2 ; j++ ){
                			if(jsonResponse["resources"][i]["primaryInfo"][j]["name"] == "Machine Name"){
                				console.log(jsonResponse["resources"][i]["primaryInfo"][j]["value"])
                				machineNameFromAPI = jsonResponse["resources"][i]["primaryInfo"][j]["value"];
                			}
    	                }
                	}
                }
            	await
            	inventoryPage.selectOptionsMenu(index);
            	inventoryPage.clickViewComponent(index);
            	console.log("machineNameFromAPI = " + machineNameFromAPI)
            	inventoryPage.getMachineName(machineNameFromAPI);
            })
    	})
    	       
    });        


});