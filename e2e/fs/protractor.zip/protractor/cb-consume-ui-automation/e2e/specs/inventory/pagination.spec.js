// This test file is for testing filters on inventory page

"use strict";

var InventoryPage = require('../../pageObjects/inventory.pageObject.js'),
    HomePage = require('../../pageObjects/home.pageObject.js'),
    DashBoard = require('../../pageObjects/dashBoard.pageObject.js'),
    util = require('../../../helpers/util.js');
    //orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    //inventoryData = require('../../../testData/inventory/inventory.json');

describe('Pagination Functionality', function() {
    var orders, homePage, dashBoard, inventoryPage;
    


    beforeAll(function() {
        homePage = new HomePage(); 
        dashBoard = new DashBoard();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
//        ensureConsumeHome();
        inventoryPage.open();
    });

    afterAll(function() {

    });

    beforeEach(function() {
    	
    });
	
    /* Selecting items per value equal to "10" */
    it('Pagination verification for item per page as 10 ', function() {
		browser.sleep(3000);
		util.waitForAngular();
		inventoryPage.countTableRecords();
		inventoryPage.getNumberOfPagesText().then(function (result) {
		inventoryPage.clickPaginationRightArrow(result);
		inventoryPage.clickPaginationLeftArrow(result);
		});
		expect(inventoryPage.countTableRecords()).toBe(10, "Record count is 10");
		
    });
    
    /* Selecting items per value equal to "25" */
    it('Pagination verification for item per page as 25 ', function() {
		
		/* Selecting items per value equal to "25" */
		browser.sleep(3000);
		util.waitForAngular();
		inventoryPage.clickSelectItemPerPage();
		inventoryPage.clickSecondRecordItemPerPage();
		inventoryPage.getNumberOfPagesText().then(function (result) {
		inventoryPage.clickPaginationRightArrow(result);
		inventoryPage.clickPaginationLeftArrow(result);
		});
		expect(inventoryPage.countTableRecords()).toBe(25, "Record count is 25");
		
    });
    
    /* Selecting items per value equal to "50" */
    it('Pagination verification for item per page as 50 ', function() {
		
		/* Selecting items per value equal to "50" */
		browser.sleep(3000);
		util.waitForAngular();
		inventoryPage.clickThirdRecordItemPerPage();
		inventoryPage.getNumberOfPagesText().then(function (result) {
		inventoryPage.clickPaginationRightArrow(result);
		inventoryPage.clickPaginationLeftArrow(result);
		});
		expect(inventoryPage.countTableRecords()).toBe(50, "Record count is 50");
    });
	
});