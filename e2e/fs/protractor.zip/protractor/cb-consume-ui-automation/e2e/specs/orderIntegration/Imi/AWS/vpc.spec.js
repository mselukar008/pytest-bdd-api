"use strict";
var Orders = require('../../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../../helpers/util.js'),
    jsonUtil = require('../../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../../testData/appUrls.json'),
    imiUtil = require('../../../../../helpers/imiApiUtil.js'),
    imiConfigTemplate = require('../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    imiManageServiceTemplate = require('../../../../../testData/OrderIntegration/Imi/manageService.json'),
    vpcInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSVPCInstance.json');

describe('IMI - VPC', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, VPCINSObject, vpcName, publicSubnet, inventoryPage, msgToVerify;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = vpcInstanceTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        instanceName: vpcInstanceTemplate.instanceName,
        componentType: vpcInstanceTemplate.componentType,
        serviceId: vpcInstanceTemplate.serviceId,
        imiOrderSubmitted: "Configure IMI Managed Service"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
    });

    it('IMI:AWS VPC - Verify E2E flow for VPC with IMI Add On', function () {

        var serviceDetailsMap = {};
        serviceName = "aws-auto-imi-VPC-" + util.getRandomString(5);
        var addOnName = "VPC-adOn-" + util.getRandomString(5);
        vpcName = "testvpcauto" + util.getRandomString(5);
        publicSubnet = "publicSubnet" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "VPC Name": vpcName, "Public Subnet Name": publicSubnet, "Add-On Name": addOnName };

        VPCINSObject = JSON.parse(JSON.stringify(vpcInstanceTemplate));
        orderObject.servicename = serviceName;
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(vpcInstanceTemplate.provider);
        catalogPage.clickProviderOrCategoryCheckbox(vpcInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(vpcInstanceTemplate.bluePrintName);

        //Update VPC template with IMI template
        delete vpcInstanceTemplate["Order Parameters"]["Configure Add-ons"];
        vpcInstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
        vpcInstanceTemplate["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
        vpcInstanceTemplate["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
        vpcInstanceTemplate["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(vpcInstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            //Restore template with default data	
            vpcInstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiManageServiceTemplate["Configure Add-ons"];
            delete vpcInstanceTemplate["Order Parameters"]["IMI Main Parameters"];
            delete vpcInstanceTemplate["Order Parameters"]["Configure manage service"];
            delete vpcInstanceTemplate["Order Parameters"]["Review IMI Config"];
            serviceDetailsMap = requiredReturnMap;
            util.waitForAngular();
            //Validate IMI configuration on Review Order page
            expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(placeOrderPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(placeOrderPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Provider Account", 1)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Provider Account IMI"));

            //Validate Review Order page with all Service Configuration
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(vpcInstanceTemplate.TotalCostWithAddOn);

            expect(requiredReturnMap["Actual"]["VPC Configuration"]).toEqual(requiredReturnMap["Expected"]["VPC Configuration"]);
            expect(requiredReturnMap["Actual"]["IPv4 CIDR Block"]).toEqual(requiredReturnMap["Expected"]["IPv4 CIDR Block"]);
            expect(requiredReturnMap["Actual"]["IPv6 CIDR Block"]).toEqual(requiredReturnMap["Expected"]["IPv6 CIDR Block"]);
            expect(requiredReturnMap["Actual"]["VPC Name"]).toEqual(vpcName);
            expect(requiredReturnMap["Actual"]["Public Subnet's IPv4 CIDR"]).toEqual(requiredReturnMap["Expected"]["Public Subnet's IPv4 CIDR"]);
            expect(requiredReturnMap["Actual"]["Availability Zone For Public Subnet"]).toEqual(requiredReturnMap["Expected"]["Availability Zone For Public Subnet"]);
            expect(requiredReturnMap["Actual"]["Public Subnet Name"]).toEqual(publicSubnet);
            expect(requiredReturnMap["Actual"]["Enable DNS Hostnames"]).toEqual(requiredReturnMap["Expected"]["Enable DNS Hostnames"]);
            expect(requiredReturnMap["Actual"]["Hardware Tenancy"]).toEqual(requiredReturnMap["Expected"]["Hardware Tenancy"]);
            expect(requiredReturnMap["Actual"]["Key"]).toEqual(requiredReturnMap["Expected"]["Key"]);
            expect(requiredReturnMap["Actual"]["Value"]).toEqual(requiredReturnMap["Expected"]["Value"]);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate Add on on orders page
            expect(ordersPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
            expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            util.waitForAngular();
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(VPCINSObject, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("VPC Configuration")).toEqual(jsonUtil.getValue(VPCINSObject, "VPC Configuration"));
            expect(ordersPage.getTextBasedOnLabelName("IPv4 CIDR Block")).toEqual(jsonUtil.getValue(VPCINSObject, "IPv4 CIDR Block"));
            expect(ordersPage.getTextBasedOnLabelName("IPv6 CIDR Block")).toEqual(jsonUtil.getValue(VPCINSObject, "IPv6 CIDR Block"));
            expect(ordersPage.getTextBasedOnLabelName("VPC Name")).toEqual(vpcName);
            expect(ordersPage.getTextBasedOnLabelName("Availability Zone For Public Subnet")).toEqual(jsonUtil.getValue(VPCINSObject, "Availability Zone For Public Subnet"));
            expect(ordersPage.getTextBasedOnLabelName("Public Subnet Name")).toEqual(publicSubnet);
            expect(ordersPage.getTextBasedOnLabelName("Enable DNS Hostnames")).toEqual(jsonUtil.getValue(VPCINSObject, "Enable DNS Hostnames"));
            expect(ordersPage.getTextBasedOnLabelName("Hardware Tenancy")).toEqual(jsonUtil.getValue(VPCINSObject, "Hardware Tenancy"));
            expect(ordersPage.getTextBasedOnLabelName("Key")).toEqual(jsonUtil.getValue(VPCINSObject, "Key"));
            expect(ordersPage.getTextBasedOnLabelName("Value")).toEqual(jsonUtil.getValue(VPCINSObject, "Value"));

            //Validate Add On details
            ordersPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 2)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate estimated cost
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(vpcInstanceTemplate.TotalCostWithAddOn);
            //Validate BOM table on order details
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "VPC - Charge for per GB data processed by NatGateways": vpcInstanceTemplate.TotalCost, "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost };
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(vpcInstanceTemplate.EstimatedPriceWithAddOn);
            }

            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            //Validate Add-On tag
            expect(ordersHistoryPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate Add On Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickExpandArrowForServiceAddOn();
            ordersHistoryPage.getAddOnDetails().then(function (addOnDetails) {
                expect(addOnDetails[1]).toContain(addOnName);
                expect(addOnDetails[3]).toContain(imiConfigTemplate.TotalCost);
                expect(addOnDetails[4]).toContain("Completed");
            })
            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(VPCINSObject, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC Configuration")).toEqual(jsonUtil.getValue(VPCINSObject, "VPC Configuration"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("IPv4 CIDR Block")).toEqual(jsonUtil.getValue(VPCINSObject, "IPv4 CIDR Block"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("IPv6 CIDR Block")).toEqual(jsonUtil.getValue(VPCINSObject, "IPv6 CIDR Block"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC Name")).toEqual(vpcName);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Availability Zone For Public Subnet")).toEqual(jsonUtil.getValue(VPCINSObject, "Availability Zone For Public Subnet"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Public Subnet Name")).toEqual(publicSubnet);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Enable DNS Hostnames")).toEqual(jsonUtil.getValue(VPCINSObject, "Enable DNS Hostnames"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Hardware Tenancy")).toEqual(jsonUtil.getValue(VPCINSObject, "Hardware Tenancy"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Key")).toEqual(jsonUtil.getValue(VPCINSObject, "Key"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Value")).toEqual(jsonUtil.getValue(VPCINSObject, "Value"));

            //Validate Add-On Details
            ordersHistoryPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 2)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 4)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(vpcInstanceTemplate.TotalCostWithAddOn);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();

            priceMap = { "VPC - Charge for per GB data processed by NatGateways": vpcInstanceTemplate.TotalCost, "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost };

            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(vpcInstanceTemplate.TotalCostWithAddOn);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Verify Output parameter in Inventory
            expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            inventoryPage.clickViewAddOnDetails(orderObject);
            //Verify Add On details in Inventory
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Provider Name", 3)).toBe("IMI");
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Instance Status", 2)).toBe("Active");
            expect(inventoryPage.getTextImiMangmntLevl()).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            //expect(inventoryPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(inventoryPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //verify bom for Add On
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(imiConfigTemplate.TotalCost);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost };
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Validate IMI tags
             if (isDummyAdapterDisabled == "false") {
                orderObject.componentType = "Network";
             }    
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                var tagList = tags.split(",");
                if (isDummyAdapterDisabled == "true") {
                    expect(tagList[4]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[5]).toContain(imiConfigTemplate.ServiceTierName);
                } else {
                    expect(tagList[2]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[0]).toContain(imiConfigTemplate.ServiceTierName);
                }
                orderFlowUtil.closeHorizontalSliderIfPresent();
            });

        });
    });
    if (isDummyAdapterDisabled == "true") {
        it('IMI-AWS-VPC- Configure IMI Manage service having AddOn', function () {

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function (index) {
                    inventoryPage.clickConfigureImiServiceBasedOnIndex(index - 1);
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });

            });

            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost    
                expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost };
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                ordersPage.open();
                //expect(util.getCurrentURL()).toMatch('orders');
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost };
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);

                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);

                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();

                //Validate Updated BOM on Inventory(AddOn+Manage Service)
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickOnInstanceTableActionIcon();
                inventoryPage.clickViewService();
                inventoryPage.clickBillOfMaterialsTabOrderDetails();
                //verify estimated cost for Add On
                expect(inventoryPage.getTextEstimatedCost()).toEqual(vpcInstanceTemplate.TotalCostWithAddOn);
                inventoryPage.clickMoreLinkinBom();
                //Validate BOM table for Add on
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                inventoryPage.clickViewServiceClosebutton();

            });
        });
    }
    it('IMI-AWS-VPC- Delete service having addon from Inventory', function () {
        //Delete Service flow
        orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
        //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
        orderFlowUtil.approveDeletedOrder(orderObject);
        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
    });

    if (isDummyAdapterDisabled == "true") {
        it('IMI-AWS-VPC- Configure Manage service from Inventory', function () {
            var serviceDetailsMap = {};
            serviceName = "aws-auto-VPC-" + util.getRandomString(5);
            var aliasVPC = "aliasVPC" + util.getRandomString(5);
            aliasVPC = aliasVPC.toLowerCase();
            modifiedParamMap = { "Service Instance Name": serviceName, "Alias": aliasVPC };
            VPCINSObject = JSON.parse(JSON.stringify(vpcInstanceTemplate));
            orderObject.servicename = serviceName;
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(vpcInstanceTemplate.provider);
            catalogPage.clickProviderOrCategoryCheckbox(vpcInstanceTemplate.Category);
            catalogPage.clickConfigureButtonBasedOnName(vpcInstanceTemplate.bluePrintName);
            //Fill Order Details
            orderFlowUtil.fillOrderDetails(vpcInstanceTemplate, modifiedParamMap);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(vpcInstanceTemplate.EstimatedPrice);

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function (index) {
                    inventoryPage.clickConfigureImiServiceBasedOnIndex(index - 1);
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });

            });

            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost    
                expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost };
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                //Navigate to Inventory and check same order id is generated after performing
                //same operation as the order is not approved, CON-34929
                //======================================================================
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                        inventoryPage.clickConfigureImiService();
                        inventoryPage.getCustomOpsWarningPopupText().then(function(text){
                            expect(text.split("Order Number:")[1]).toContain(orderObject.orderNumber);
                            inventoryPage.clickCustomOpsWarningOKButton(); 
                        });                                               
                    });
                });

                ordersPage.open();
                //expect(util.getCurrentURL()).toMatch('orders');
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost };
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);

                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);

                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();

                //Delete Service flow
                orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            });
        });
    }
});
