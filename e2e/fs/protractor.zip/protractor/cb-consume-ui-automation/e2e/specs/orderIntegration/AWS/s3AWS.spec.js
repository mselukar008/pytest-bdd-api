
"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
	async = require('async'),
	HomePage = require('../../../pageObjects/home.pageObject.js'),
	CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	Inventory = require('../../../pageObjects/inventory.pageObject.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	jsonUtil = require('../../../../helpers/jsonUtil.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	appUrls = require('../../../../testData/appUrls.json'),
	logGenerator = require("../../../../helpers/logGenerator.js"),
	logger = logGenerator.getApplicationLogger(),
	testEnvironment = browser.params.url.includes("cb-qa-2") ? "QA 2" : browser.params.url.includes("customer1") ? "Customer 1" : "QA 4",

	s3InstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSS3Instance.json');

describe('AWS - S3', function () {
	var inventoryPage, ordersPage, homePage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, bucketName, logBucketName, S3INSObject, bucketPolicyEditor;
	var modifiedParamMap = {};
	var messageStrings = {
		providerName: 'Amazon',
		category: 'Storage',
		catalogPageTitle: 'Search, Select and Configure',
		inputServiceNameWarning: "Parameter Warning:",
		orderSubmittedConfirmationMessage: 'Order Submitted !',
		isDummyTagValue: 'Yes',
		systemTagText: "ibm_mcmp_soiid",
		editOrderErrorMessage: 'No configuration has changed on the Service Instance to perform the edit action'
	};

	beforeAll(function () {
		ordersPage = new Orders();
		homePage = new HomePage();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new Inventory();
		ordersHistoryPage = new OrderHistoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		S3INSObject = JSON.parse(JSON.stringify(s3InstanceTemplate));
		serviceName = "auto-aws-s3-" + util.getRandomString(5);
		bucketName = "buckettestaut" + util.getRandomString(5);
		bucketName = bucketName.toLowerCase();
		bucketPolicyEditor = JSON.stringify({ "Version": "2012-10-17", "Statement": [{ "Sid": "PublicRead", "Effect": "Allow", "Principal": "*", "Action": ["s3:GetObject"], "Resource": ["arn:aws:s3:::" + bucketName + "/*"] }] });
		logBucketName = "logbuckettestaut" + util.getRandomString(5);
		logBucketName = logBucketName.toLowerCase();
		modifiedParamMap = { "Service Instance Name": serviceName, "Bucket Name": bucketName, "Log Bucket Name": logBucketName, "Bucket Policy Editor": bucketPolicyEditor };
	});

	it('AWS S3 - Verify Service details on review/approve/Order Order history page and provisioning is working fine.', async function () {
		var orderObject = {};
		var serviceDetailsMap = {};
		var totalCostBOM, totalCostUpdated;
		orderObject.servicename = serviceName;
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
		catalogPage.clickConfigureButtonBasedOnName(s3InstanceTemplate.bluePrintName);

		orderFlowUtil.fillOrderDetails(s3InstanceTemplate, modifiedParamMap).then(async function (requiredReturnMap) {
			serviceDetailsMap = requiredReturnMap;
			expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
			if (browser.params.defaultCurrency == "USD") {
				expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(s3InstanceTemplate.TotalCost);
				//BOM Validation as per components of service.
				expect(placeOrderPage.validateBOMOnReviewOrderPage(s3InstanceTemplate.Pricing)).toBe(true);
			}
			expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
			//expect(requiredReturnMap["Actual"]["Service Instance Name"]).toEqual(serviceName);
			expect(requiredReturnMap["Actual"]["Bucket Name"]).toEqual(bucketName);
			expect(requiredReturnMap["Actual"]["Versioning"]).toEqual(requiredReturnMap["Expected"]["Versioning"]);
			expect(requiredReturnMap["Actual"]["Server Access Logging"]).toEqual(requiredReturnMap["Expected"]["Server Access Logging"]);
			expect(requiredReturnMap["Actual"]["Default Encryption"]).toEqual(requiredReturnMap["Expected"]["Default Encryption"]);
			expect(requiredReturnMap["Actual"]["Access Control"]).toEqual(requiredReturnMap["Expected"]["Access Control"]);
			expect(requiredReturnMap["Actual"]["Transfer Acceleration"]).toEqual(requiredReturnMap["Expected"]["Transfer Acceleration"]);

			expect(requiredReturnMap["Actual"]["Enter a rule name"]).toEqual(requiredReturnMap["Expected"]["Enter a rule name"]);
			expect(requiredReturnMap["Actual"]["Add tags to Rule"]).toEqual(requiredReturnMap["Expected"]["Add tags to Rule"]);
			expect(requiredReturnMap["Actual"]["Add filter tag key name to limit scope to tags"]).toEqual(requiredReturnMap["Expected"]["Add filter tag key name to limit scope to tags"]);
			expect(requiredReturnMap["Actual"]["Add filter tag key value to limit scope to tags"]).toEqual(requiredReturnMap["Expected"]["Add filter tag key value to limit scope to tags"]);
			expect(requiredReturnMap["Actual"]["Static Website Hosting"]).toEqual(requiredReturnMap["Expected"]["Static Website Hosting"]);
			expect(requiredReturnMap["Actual"]["Target Bucket Or Domain"]).toEqual(requiredReturnMap["Expected"]["Target Bucket Or Domain"]);
		});
		placeOrderPage.submitOrder();
		expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
		orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(s3InstanceTemplate.bluePrintName, "New");
		placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

		//Service details on Order History page
		ordersHistoryPage.open();
		ordersHistoryPage.searchOrderById(orderObject.orderNumber);
		ordersHistoryPage.clickServiceDetailsLink();
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(S3INSObject, "AWS Region"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Bucket Name")).toEqual(bucketName);
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Access Control")).toEqual(jsonUtil.getValue(S3INSObject, "Access Control"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Server Access Logging")).toEqual(jsonUtil.getValue(S3INSObject, "Server Access Logging"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Versioning")).toEqual(jsonUtil.getValue(S3INSObject, "Versioning"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Transfer Acceleration")).toEqual(jsonUtil.getValue(S3INSObject, "Transfer Acceleration"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Default Encryption")).toEqual(jsonUtil.getValue(S3INSObject, "Default Encryption"));

		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Bucket Policy Editor")).toEqual(bucketPolicyEditor);
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Enter a rule name")).toEqual(jsonUtil.getValue(S3INSObject, "Enter a rule name"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Add tags to rule")).toEqual(jsonUtil.getValue(S3INSObject, "Add Tags to Rule"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Add filter tag key name to limit scope to tags")).toEqual(jsonUtil.getValue(S3INSObject, "Add filter tag key name to limit scope to tags"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Add filter tag key value to limit scope to tags")).toEqual(jsonUtil.getValue(S3INSObject, "Add filter tag key value to limit scope to tags"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Static Website Hosting")).toEqual(jsonUtil.getValue(S3INSObject, "Static Website Hosting"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Target Bucket Or Domain")).toEqual(jsonUtil.getValue(S3INSObject, "Target Bucket Or Domain"));
		if (browser.params.defaultCurrency == "USD") {
			ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
			expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(s3InstanceTemplate.TotalCost);
			//BOM check On order history page
			totalCostBOM = await placeOrderPage.getBOMTablePrice();
			expect(s3InstanceTemplate.TotalCost).toContain(totalCostBOM);

			ordersHistoryPage.closeServiceDetailsSlider();
			ordersHistoryPage.clickBillOfMaterials();
			expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(s3InstanceTemplate.TotalCost);
			totalCostBOM = await placeOrderPage.getBOMTablePrice();
			expect(s3InstanceTemplate.TotalCost).toContain(totalCostBOM);
			ordersHistoryPage.closeServiceDetailsSlider();
		}

		//Order details on approve order page
		ordersPage.open();
		expect(util.getCurrentURL()).toMatch('orders');
		ordersPage.searchOrderById(orderObject.orderNumber);
		expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
		ordersPage.clickFirstViewDetailsOrdersTable();
		//orderFlowUtil.waitForOrderStatusChange(orderObject, 'Approval In Progress');
		expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
		expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
		expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
		expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
		//util.waitForAngular();
		expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(S3INSObject, "AWS Region"));
		expect(ordersPage.getTextBasedOnLabelName("Bucket Name")).toEqual(bucketName);
		expect(ordersPage.getTextBasedOnLabelName("Access Control")).toEqual(jsonUtil.getValue(S3INSObject, "Access Control"));
		expect(ordersPage.getTextBasedOnLabelName("Server Access Logging")).toEqual(jsonUtil.getValue(S3INSObject, "Server Access Logging"));
		expect(ordersPage.getTextBasedOnLabelName("Versioning")).toEqual(jsonUtil.getValue(S3INSObject, "Versioning"));
		expect(ordersPage.getTextBasedOnLabelName("Transfer Acceleration")).toEqual(jsonUtil.getValue(S3INSObject, "Transfer Acceleration"));
		expect(ordersPage.getTextBasedOnLabelName("Default Encryption")).toEqual(jsonUtil.getValue(S3INSObject, "Default Encryption"));

		expect(ordersPage.getTextBasedOnLabelName("Bucket Policy Editor")).toEqual(bucketPolicyEditor);
		expect(ordersPage.getTextBasedOnLabelName("Enter a rule name")).toEqual(jsonUtil.getValue(S3INSObject, "Enter a rule name"));
		expect(ordersPage.getTextBasedOnLabelName("Add tags to rule")).toEqual(jsonUtil.getValue(S3INSObject, "Add Tags to Rule"));
		expect(ordersPage.getTextBasedOnLabelName("Add filter tag key name to limit scope to tags")).toEqual(jsonUtil.getValue(S3INSObject, "Add filter tag key name to limit scope to tags"));
		expect(ordersPage.getTextBasedOnLabelName("Add filter tag key value to limit scope to tags")).toEqual(jsonUtil.getValue(S3INSObject, "Add filter tag key value to limit scope to tags"));
		expect(ordersPage.getTextBasedOnLabelName("Static Website Hosting")).toEqual(jsonUtil.getValue(S3INSObject, "Static Website Hosting"));
		expect(ordersPage.getTextBasedOnLabelName("Target Bucket Or Domain")).toEqual(jsonUtil.getValue(S3INSObject, "Target Bucket Or Domain"));
		if (browser.params.defaultCurrency == "USD") {
			ordersPage.clickBillOfMaterialsTabOrderDetails();
			expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(s3InstanceTemplate.TotalCost);
			//BOM check On approve Order Details
			totalCostBOM = await placeOrderPage.getBOMTablePrice();
			expect(s3InstanceTemplate.TotalCost).toContain(totalCostBOM);
			ordersPage.closeServiceDetailsSlider();
		}

		if (isProvisioningRequired == "true") {
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
			orderFlowUtil.verifyOrderStatus(orderObject).then(async function (status) {
				if (status == 'Completed') {
					if (browser.params.defaultCurrency == "USD") {
						//Validate Estimated price on approve order page
						expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(s3InstanceTemplate.EstimatedPrice);
						//Validate pricing on order history page
						ordersHistoryPage.open();
						ordersHistoryPage.searchOrderById(orderObject.orderNumber);
						expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(s3InstanceTemplate.EstimatedPrice);

						inventoryPage.open();
						inventoryPage.searchOrderByServiceName(orderObject.servicename);
						element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
						inventoryPage.clickViewService();
						// Checking cost of BOM (Inventory Page Page)		
						inventoryPage.clickBOMButton();
						totalCostBOM = await placeOrderPage.getBOMTablePrice();
						expect(s3InstanceTemplate.TotalCost).toContain(totalCostBOM);
						inventoryPage.closeViewComponent();
					}
					//Verify Output parameter
					expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
					//Negative flow for edit service
					var modifiedParamMap = { "EditService": true };
					var modifiedParamMapEdit = { "EditService": true, "Versioning": "", "Transfer Acceleration": "", "Default Encryption": "", "Access Control": "", "Tags": "", "Key": "", "Value": "" };
					orderFlowUtil.editService(orderObject);
					orderFlowUtil.fillOrderDetails(s3InstanceTemplate, modifiedParamMapEdit).then(function () {
						logger.info("Edit parameter details are filled.");
						//browser.sleep(5000);
					});

					placeOrderPage.submitOrder();

					//Validate Error message
					expect(placeOrderPage.getTextEditOrderErrorMsg()).toBe(messageStrings.editOrderErrorMessage);
					placeOrderPage.clickOnNotificationCloseButton();
					placeOrderPage.clickPreviousButton();
					placeOrderPage.clickPreviousButton();
					placeOrderPage.clickPreviousButton();
					placeOrderPage.clickPreviousButton();
					//Functional flow for edit service
					//Delete objects
					delete s3InstanceTemplate["Edit Parameters"]["Main Parameters"];
					delete s3InstanceTemplate["Edit Parameters"]["Configure Region"];
					delete s3InstanceTemplate["Edit Parameters"]["Name"];
					orderFlowUtil.fillOrderDetails(s3InstanceTemplate, modifiedParamMap).then(function (reviewOrderExpActParamsMap) {
						logger.info("Edit parameter details are filled.");
						//browser.sleep(5000);
						//Validate Review order page parameters
						expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
					});
					placeOrderPage.submitOrder();
					orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(s3InstanceTemplate.bluePrintName, "Edit");
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
					placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
					orderFlowUtil.approveOrder(orderObject);
					orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
					orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
						if (status == 'Completed') {
							//Verify updated details are reflected on order details page.						
							ordersPage.clickFirstViewDetailsOrdersTable();
							expect(ordersPage.getTextBasedOnLabelName("Versioning")).toEqual(jsonUtil.getValueEditParameter(S3INSObject, "Versioning"));
							expect(ordersPage.getTextBasedOnLabelName("Transfer Acceleration")).toEqual(jsonUtil.getValueEditParameter(S3INSObject, "Transfer Acceleration"));
							expect(ordersPage.getTextBasedOnLabelName("Default Encryption")).toEqual(jsonUtil.getValueEditParameter(S3INSObject, "Default Encryption"));
							expect(ordersPage.getTextBasedOnLabelName("Access Control")).toEqual(jsonUtil.getValueEditParameter(S3INSObject, "Access Control"));
							expect(ordersPage.getTextBasedOnLabelName("Key")).toEqual(jsonUtil.getValueEditParameter(S3INSObject, "Key"));
							expect(ordersPage.getTextBasedOnLabelName("Value")).toEqual(jsonUtil.getValueEditParameter(S3INSObject, "Value"));
							if (browser.params.defaultCurrency == "USD") {
								ordersPage.clickBillOfMaterialsTabOrderDetails();
								// Checking cost of BOM on Updated BOM tab (Orders Page)
								totalCostUpdated = placeOrderPage.getTextUpdatedBOMTablePrice(2);
								expect(s3InstanceTemplate.TotalCostAfterEdit).toContain(totalCostUpdated);

								// Checking cost of BOM on Current BOM tab(Orders Page)
								totalCostBOM = placeOrderPage.getTextCurrentBOMTablePrice(0);
								expect(s3InstanceTemplate.TotalCost).toContain(totalCostBOM);

								ordersHistoryPage.open();
								ordersHistoryPage.searchOrderById(orderObject.orderNumber);
								ordersHistoryPage.clickServiceDetailsLink();
								ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();

								// Checking cost of BOM on Updated BOM tab(order History Page)
								totalCostUpdated = placeOrderPage.getTextUpdatedBOMTablePrice(2);
								expect(s3InstanceTemplate.TotalCostAfterEdit).toContain(totalCostUpdated);

								// Checking cost of BOM on Current BOM tab(order History Page)
								totalCostBOM = placeOrderPage.getTextCurrentBOMTablePrice(0);
								expect(s3InstanceTemplate.TotalCost).toContain(totalCostBOM);

								inventoryPage.open();
								inventoryPage.searchOrderByServiceName(orderObject.servicename);
								element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
								inventoryPage.clickViewService();
								// Checking cost of BOM (Inventory Page Page)				
								inventoryPage.clickBOMButton();
								totalCostUpdated = placeOrderPage.getBOMTablePrice();
								expect(s3InstanceTemplate.TotalCostAfterEdit).toContain(totalCostUpdated);
								inventoryPage.clickViewServiceClosebutton();
							}

							//Validate service Tags
							inventoryPage.open();
							inventoryPage.getImiTags(orderObject).then(function (tags) {
								var tagList = tags.split(",");
								var tagMap = inventoryPage.getServiceTags(tagList);
								var mcmpTag = false;
								if (isDummyAdapterDisabled == "false") {
									//verifying flags for dummy adapter
									expect(tagMap["IsUsingDummy"]).toEqual(messageStrings.isDummyTagValue);
									expect(tagMap["Name"]).toEqual(s3InstanceTemplate.bluePrintName);
									expect(tagMap["PhysicalId"]).toContain(serviceName);
									expect(Object.keys(tagMap).includes("Test")).toBe(true);
									expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
								} else {
									//verifying a system tag
									expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
									//verifying some of the service tags
									expect(tagList.includes(tagList.find(tag => tag.includes("stackId:arn:aws:cloudformation")))).toBe(true);
									expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:logical-id")))).toBe(true);
									expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-id")))).toBe(true);
									expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-name")))).toBe(true);
									expect(tagMap["orderNumber"].toUpperCase()).toEqual(orderObject.orderNumber);
									expect(tagMap["serviceInstanceName"].toLowerCase()).toContain(serviceName.toLowerCase());
								}
								orderFlowUtil.closeHorizontalSliderIfPresent();
							});

							//Delete Service flow
							orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, s3InstanceTemplate.bluePrintName);
							//expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
							orderFlowUtil.approveDeletedOrder(orderObject);
							orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
							expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
						}
					});
				}
			});
		}
	});
})
