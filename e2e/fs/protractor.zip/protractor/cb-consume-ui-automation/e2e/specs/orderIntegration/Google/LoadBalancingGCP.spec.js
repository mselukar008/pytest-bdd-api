"use strict";

var Orders = require('../../../pageObjects/orders.pageObject.js'),
    async = require('async'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    testEnvironment = browser.params.url.includes("cb-qa-2") ? "QA 2" : browser.params.url.includes("customer1") ? "Customer 1" : "QA 4",
    logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    gcpLoadBalancingTemplate = require('../../../../testData/OrderIntegration/Google/gcpLoadBalancing.json');

describe('GCP - UDP Cloud Load Balancing', function () {
    var ordersPage, homePage, catalogPage, placeOrderPage, orderHistoryPage, inventoryPage, serviceName, totalCostBOM;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: 'Google',
        category: 'Network',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
    };

    beforeAll(function () {
        ordersPage = new Orders();
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        orderHistoryPage = new OrderHistoryPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        catalogPage.open();
        //expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        serviceName = "auto-udp-load-balancing-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName };
    });

    it('TC-C183213 : Google Load Balancing : Verify fields on Main Parameters page are working fine while provisioning a Google Load Balancing', function () {
        catalogPage.clickProviderOrCategoryCheckbox('Network');
        catalogPage.clickConfigureButtonBasedOnName(gcpLoadBalancingTemplate.bluePrintName);
        expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
        placeOrderPage.setServiceNameText(serviceName);
        placeOrderPage.selectProviderAccount(gcpLoadBalancingTemplate.providerAccount);
        expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
    });

    it('TC-C183214 : Google Load Balancing : Verify Service Details are listed in Review Order page', async function () {
        var loadBalObj = JSON.parse(JSON.stringify(gcpLoadBalancingTemplate));
        catalogPage.clickProviderOrCategoryCheckbox('Network');
        catalogPage.clickConfigureButtonBasedOnName(gcpLoadBalancingTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetails(gcpLoadBalancingTemplate, modifiedParamMap).then(async function (requiredReturnMap) {
            //expect(requiredReturnMap["Actual"]["Service Instance Name"]).toEqual(requiredReturnMap["Expected"]["Service Instance Name"]);
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(requiredReturnMap["Actual"]["Region"]).toEqual(requiredReturnMap["Expected"]["Region"]);
            expect(requiredReturnMap["Actual"]["Type"]).toEqual(requiredReturnMap["Expected"]["Type"]);
            expect(requiredReturnMap["Actual"]["Load Balancing Traffic"]).toEqual(requiredReturnMap["Expected"]["Load Balancing Traffic"]);
            //expect(requiredReturnMap["Actual"]["Name"]).toEqual(requiredReturnMap["Expected"]["Name"]);
            expect(requiredReturnMap["Actual"]["Backends"]).toEqual(requiredReturnMap["Expected"]["Backends"]);
            expect(requiredReturnMap["Actual"]["Health Check"]).toEqual(requiredReturnMap["Expected"]["Health Check"]);
            expect(requiredReturnMap["Actual"]["Protocol"]).toEqual(requiredReturnMap["Expected"]["Protocol"]);
            expect(requiredReturnMap["Actual"]["IP"]).toEqual(requiredReturnMap["Expected"]["IP"]);
            expect(requiredReturnMap["Actual"]["Port"]).toEqual(requiredReturnMap["Expected"]["Port"]);
            if (browser.params.defaultCurrency == "USD") {
                //Validate estimated cost
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(gcpLoadBalancingTemplate.TotalCost);
                //BOM Validation as per components of service.
                expect(placeOrderPage.validateBOMOnReviewOrderPage(gcpLoadBalancingTemplate.Pricing)).toBe(true);
            }
        });
    });

    fit('TC-C183215 : Google Load Balancing : Verify Order Details once order is submitted from catalog page ', async function () {

        var orderObject = {};
        var orderAmount;
        global.serviceName = serviceName;
        var loadBalObj = JSON.parse(JSON.stringify(gcpLoadBalancingTemplate));
        catalogPage.clickProviderOrCategoryCheckbox('Network');
        catalogPage.clickConfigureButtonBasedOnName(gcpLoadBalancingTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetails(gcpLoadBalancingTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        expect(util.getCurrentURL()).toMatch('orders');
        ordersPage.searchOrderById(orderObject.orderNumber);
        expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
        ordersPage.getTextFirstAmountOrdersTable().then(function (text) {
            orderAmount = text;
        });
        ordersPage.clickFirstViewDetailsOrdersTable();
        expect(ordersPage.getTextBasedOnLabelName("Service Instance Prefix")).toEqual(serviceName);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
        expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
        expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
        util.waitForAngular();
        expect(ordersPage.getTextBasedOnLabelName("Region")).toContain(jsonUtil.getValue(loadBalObj, "Region"));
        expect(ordersPage.getTextBasedOnLabelName("Load Balancing Traffic")).toEqual(jsonUtil.getValue(loadBalObj, "Load Balancing Traffic"));
        expect(ordersPage.getTextBasedOnLabelName("Backends")).toEqual(jsonUtil.getValue(loadBalObj, "Backends"));
        expect(ordersPage.getTextBasedOnLabelName("Health Check")).toEqual(jsonUtil.getValue(loadBalObj, "Health Check"));

        orderFlowUtil.verifyOrderServiceDetails(loadBalObj).then(function (status) {
            expect(status).toEqual(true);
        });
        if (browser.params.defaultCurrency == "USD") {
            ordersPage.clickBillOfMaterialsTabOrderDetails().then(async function () {
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(gcpLoadBalancingTemplate.TotalCost);
                //BOM check On View Order Details
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                totalCostBOM = await placeOrderPage.getBOMTablePrice();
                expect(gcpLoadBalancingTemplate.TotalCost).toContain(totalCostBOM);
            });
        }
        ordersPage.clickServiceDetailSliderCloseButton();
    });

    if (isProvisioningRequired == "true") {
        it('TC-C183216 : Google Load Balancing : E2E: Verify Google Load Balancing Order Provisioning is working fine from consume Application', async function () {
            var orderObject = {};
            global.serviceName = serviceName;
            var loadBalObj = JSON.parse(JSON.stringify(gcpLoadBalancingTemplate));
            catalogPage.clickProviderOrCategoryCheckbox('Network');
            catalogPage.clickConfigureButtonBasedOnName(gcpLoadBalancingTemplate.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetails(gcpLoadBalancingTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpLoadBalancingTemplate.bluePrintName, "New");
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            orderFlowUtil.verifyOrderStatus(orderObject).then(async function (status) {
                if (status == 'Completed') {
                    //BOM check On order History Page(View Details)
                    if(browser.params.defaultCurrency == "USD") {                        
                        orderHistoryPage.open();
                        orderHistoryPage.searchOrderById(orderObject.orderNumber);
                        orderHistoryPage.clickServiceDetailsLink();
                        orderHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                        totalCostBOM = await placeOrderPage.getBOMTablePrice();
                        expect(gcpLoadBalancingTemplate.TotalCost).toContain(totalCostBOM);
                        orderHistoryPage.closeServiceDetailsSlider();
                        //BOM check On Inventory(View Details)
                        inventoryPage.open();
                        inventoryPage.searchOrderByServiceName(orderObject.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //BOM check On Inventory View Order Details
                        inventoryPage.clickBOMButton();
                        totalCostBOM = await placeOrderPage.getBOMTablePrice();
                        expect(gcpLoadBalancingTemplate.TotalCost).toContain(totalCostBOM);
                        inventoryPage.closeViewComponent();
                    }
                    //orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                    orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, gcpLoadBalancingTemplate.bluePrintName);
                    expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                    orderFlowUtil.approveDeletedOrder(orderObject);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
                }
            });
        });
    }
});
