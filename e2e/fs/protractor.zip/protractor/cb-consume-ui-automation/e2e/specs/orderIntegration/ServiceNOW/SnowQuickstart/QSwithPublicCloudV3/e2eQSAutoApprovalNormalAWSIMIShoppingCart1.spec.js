"use strict";
var CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
    OrderHistoryPage = require('../../../../../pageObjects/ordersHistory.pageObject.js'),
    CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
    util = require('../../../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
    jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
    appUrls = require('../../../../../../testData/appUrls.json'),
    snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
    SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
    url = browser.params.url,
    awsEC2template = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSEC2SnowShoppingCartWithIMI.json'),
    awsSQStemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSSQSSnowShoppingCartWithIMI.json'),
    imiConfigTemplate = require('../../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
    policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
    addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
    snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');

describe("AWS IMI - Shopping Cart 1: E2E cases for Auto Technical/Financial/Legal approval with Normal change", function(){
    var catalogPage, placeOrderPage, policyPage, snowPage, provOrder, orderHistoryPage, cartListPage;
    var modifiedParamMapEC2 = {};
    var modifiedParamMapSQS = {};
    var modifiedParamMapPolicy = {};
    var modifiedParamMapAddRule = {};
    var orderObject = {};
    var consumeLaunchpadUrl = url + '/launchpad';
    var serviceName1 = "SNOWQSAutoAwsImiEc2" + util.getRandomString(5);
    var serviceName2 = "SNOWQSAutoAwsImiSQS" + util.getRandomString(5);
    var policyName = "SNOWQSautoAWSPolicy" + util.getRandomString(5);
    var policyRuleName = "SNOWQSautoAWSPolicyRule" + util.getRandomString(5);
    var groupName = "autoSecGrp" + util.getRandomString(5);
    var cartName = "autoCartSnowIMI" + util.getRandomString(5);
    var queueName = "autoQueue" + util.getRandomString(5);
    var awsEC2Obj = JSON.parse(JSON.stringify(awsEC2template));
    var awsSQSObj = JSON.parse(JSON.stringify(awsSQStemplate));

    //Update template with IMI template for EC2
	delete awsEC2Obj["Order Parameters"]["Configure Add-ons"];
	awsEC2Obj["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
	awsEC2Obj["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
	awsEC2Obj["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
	awsEC2Obj["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];
	awsEC2Obj["TotalCost"] = imiConfigTemplate["TotalCost"];

    //Update template with IMI template for SQS
	delete awsSQSObj["Order Parameters"]["Configure Add-ons"];
	awsSQSObj["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
	awsSQSObj["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
	awsSQSObj["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
	awsSQSObj["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];
	awsSQSObj["TotalCost"] = imiConfigTemplate["TotalCost"];

    beforeAll(function () {
        snowPage = new SNOWPage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        orderHistoryPage = new OrderHistoryPage();
        policyPage = new PolicyPage();
        cartListPage = new CartListPage();
        browser.driver.manage().window().maximize();
        modifiedParamMapPolicy = { "policy Name": policyName, "Values": "Auto-TEAM1 (my_org)" };
        modifiedParamMapAddRule = {
            "Add Rule Name": policyRuleName, "Order Type": ["New", "Edited", "Deleted", "ServiceAction"], "Provider": ["Amazon", "IMI"], "Total Monthly Cost": "", "Monthly Cost": "", "Budget Is": ""
        };
        modifiedParamMapEC2 = { "Service Instance Name": serviceName1, "Cart Name": cartName, "Cart Service":"Click", "New Shopping Cart": "newCart", "Team": "Auto-TEAM1", "Environment": "QA", "Application": "", "Provider Account": "AWS-SNOW / AWS-SNOW", "Group Name": groupName };
        modifiedParamMapSQS = { "Service Instance Name": serviceName2, "Team": "", "Environment": "", "Application": "", "Queue Name": queueName }
    });
    
    it('Set Change Request type to Normal in SNOW', function () {
		expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});

    it('Create Approval Policy for AWS with Auto Technical, Financial, Legal approval and Normal change', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});

    it("AWS IMI - Shopping Cart 1: Verify Provision functionality with Auto Technical/Financial/Legal approval and Normal change", function(){
        // Add configured EC2 with IMI into Cart
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(awsEC2Obj.provider);
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(awsEC2Obj.Category);
        catalogPage.clickConfigureButtonBasedOnName(awsEC2Obj.bluePrintName);
        orderObject.servicename = serviceName1;
        orderFlowUtil.fillOrderDetails(awsEC2Obj, modifiedParamMapEC2);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        
        // Add configured SQS with IMI into Cart
        catalogPage.open();
        catalogPage.clickResetProviderLink();
        catalogPage.clickProviderCheckBoxBasedOnName(awsSQSObj.provider);
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(awsSQSObj.Category);
        catalogPage.clickConfigureButtonBasedOnName(awsSQSObj.bluePrintName);
        orderObject.servicename = serviceName2;
        orderFlowUtil.fillOrderDetails(awsSQSObj, modifiedParamMapSQS);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);

        // Submit Order
		cartListPage.submitOrder(0);
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.cartName = placeOrderPage.getTextCartNameOrderSubmittedModal();
        provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toContain(awsEC2template.orderSubmittedConfirmationMessage);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderObject = {"orderNumber":provOrder};

        // Validation in Marketplace after auto approval
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);

        // Validations on SNOW Request page after auto approval
        snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
        snowPage.waitUntilApprovalIsApprovedQS();
        expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
        expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
        expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
        expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
        expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
        expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
        expect(snowPage.getTextShortDescription()).toBe(cartName);
        expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
        expect(snowPage.getOrderNumberText()).toBe(provOrder);
        expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
        expect(snowPage.getCountOfRITMlinks()).toBe(parseInt("2"));
    });

    it("AWS IMI - Shopping Cart 1: Verify the First RITM for Provision functionality with Normal change", function(){
        snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
        snowPage.clickFirstRequestedItemLink();
        expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
        expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
        expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
        expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
        expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
        expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
        
        snowPage.getTextReqItemVariableServiceName().then(function(sName){
            if(sName.includes(serviceName1)) {
                expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2Obj.bluePrintName);
                expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
                expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
                // Broker Config values table validations - EC2
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2Obj, "Resource Name"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2Obj, "Instance Family"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2Obj, "Instance Type"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2Obj, "Search By"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2Obj, "Availability Zone"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2Obj, "VPC Creation Mode"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("Subnet")).toEqual("subnet-a68b538d");
                expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("VPC")).toEqual("vpc-8eadd1eb");
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2Obj, "Shutdown Behavior"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2Obj, "Enable Termination Protection"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2Obj, "T2/T3 Unlimited"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("group Name")).toEqual(groupName);
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2Obj, "User Data"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2Obj, "Key Pair"));

                // Validate BOM values
                expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAwsSrvcItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
                expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAwsSrvcItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalCIt2SmallAws);

                // Validate Addon BOM Values

            }
            else{
                expect(sName).toContain(serviceName2);
                expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsSQSObj.bluePrintName);
                expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowreqItemvariableSerOfferDescAWSSQS);
                expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryMessaging);
                // Broker Config values table validations - SQS
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toContain(jsonUtil.getValue(awsSQSObj, "AWS Region"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("type Of Queue")).toEqual(jsonUtil.getValue(awsSQSObj, "Type Of Queue"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("Queue Name")).toEqual(queueName);
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("default Visibility Timeout")).toEqual(jsonUtil.getValue(awsSQSObj, "Default Visibility Timeout"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("delivery Delay")).toEqual(jsonUtil.getValue(awsSQSObj, "Delivery Delay"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("receive Message Wait Time")).toEqual(jsonUtil.getValue(awsSQSObj, "Receive Message Wait Time"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("use Redrive Policy")).toEqual(jsonUtil.getValue(awsSQSObj, "Use Redrive Policy"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use SSE")).toEqual(jsonUtil.getValue(awsSQSObj, "Use SSE"));

                // Validate BOM values

                // Validate Addon BOM Values
            }

            // Addon Services Values table validations
            expect(snowPage.getTextReqItemAddOnValuesBasedOnName(imiConfigTemplate.managementLevelKey)).toEqual(snowInstanceTemplate.snowAzureAddOnManagementLevelValue);
            expect(snowPage.getTextReqItemAddOnValuesBasedOnName(imiConfigTemplate.managementLevelSummaryKey)).toEqual(snowInstanceTemplate.snowAzureAddOnManagementLevelSummaryValue);
            expect(snowPage.getTextReqItemAddOnValuesBasedOnName(imiConfigTemplate.planLevelKey)).toEqual(snowInstanceTemplate.snowAzureAddOnPlanLevelValue);
            expect(snowPage.getTextReqItemAddOnValuesBasedOnName(imiConfigTemplate.planLevelSummaryKey)).toContain(snowInstanceTemplate.snowAzureAddOnPlanLevelSummaryValue);

            //Validations on SNOW Configuration Item- Service Instance CIs page
            snowPage.switchToDefaultContent();
            snowPage.switchToParentFrame();
            snowPage.openConfItemServiceInstanceCIs();
            expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
            expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
            expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
            snowPage.clickUpdateButton();
            
            //Validation on Catalog Task page
            snowPage.clickCatalogTaskLink();
            expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
            snowPage.clickBackButton();
            
            //Normal change
            snowPage.openRelatedChangeRequest();
            expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
            snowPage.enterChangeReqValues();
            snowPage.enterPlanningValues();
            snowPage.enterScheduleValues();
            snowPage.clickCalculateRiskLink();
            snowPage.clickAssessButton();
            
            //Approvals in SNOW
            snowPage.clickRequestApprovalInChangeRequestPage();
            snowPage.approveChangeRequestForEachState();
            snowPage.approveRequestQS();
            snowPage.approveRequestQS();
            expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);			
                    
            //Order Completion in SNOW
            snowPage.rightClickOnCMDBCIFormHeader();
            var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
            sysidofChangeRequest.then(function(sysidofChangeRequestValue){
                var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
                setChangeRequesttoImplementState.then(function(statuscode){
                    expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
                });
            });
            snowPage.checkIfProvisioningTaskClosed();
            snowPage.closeNotifySerDeskTask();
            snowPage.closeImplementTask();
            snowPage.clickCloseChangeRequestButton();
            snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);

            //Validation in Marketplace
            browser.get(consumeLaunchpadUrl);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
            orderHistoryPage.searchOrder(orderObject.orderNumber);
            if(sName.includes(serviceName1)) {
                orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
                expect(orderHistoryPage.getStatusBasedOnServiceNameWithAddOn(serviceName1)).toBe(awsEC2template.completedState);
            }
            else {
                orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
                expect(orderHistoryPage.getStatusBasedOnServiceNameWithAddOn(serviceName2)).toBe(awsEC2template.completedState);
            }
        });

        //Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
        snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
        snowPage.clickFirstRequestedItemLink();
        expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
        snowPage.openConfItemServiceInstanceCIs();
        expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
        expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
        snowPage.clickUpdateButton();	
        
        //Validation on Catalog Task page after completion
        snowPage.clickCatalogTaskLink();
        expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
        snowPage.clickBackButton();
    });

    it("AWS IMI - Shopping Cart 1: Verify the Second RITM for Provision functionality with Normal change", function(){
        snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
        snowPage.clickSecondRequestedItemLink();
        expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
        expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
        expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
        expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
        expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
        expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
        
        snowPage.getTextReqItemVariableServiceName().then(function(sName){
            if(sName.includes(serviceName1)) {
                expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2Obj.bluePrintName);
                expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
                expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
                // Broker Config values table validations - EC2
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2Obj, "Resource Name"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2Obj, "Instance Family"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2Obj, "Instance Type"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2Obj, "Search By"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2Obj, "Availability Zone"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2Obj, "VPC Creation Mode"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("Subnet")).toEqual("subnet-a68b538d");
                expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("VPC")).toEqual("vpc-8eadd1eb");
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2Obj, "Shutdown Behavior"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2Obj, "Enable Termination Protection"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2Obj, "T2/T3 Unlimited"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("group Name")).toEqual(groupName);
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2Obj, "User Data"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2Obj, "Key Pair"));

                // Validate BOM values
                expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAwsSrvcItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
                expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAwsSrvcItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalCIt2SmallAws);

                // Validate Addon BOM Values

            }
            else{
                expect(sName).toContain(serviceName2);
                expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsSQSObj.bluePrintName);
                expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowreqItemvariableSerOfferDescAWSSQS);
                expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryMessaging);
                // Broker Config values table validations - SQS
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toContain(jsonUtil.getValue(awsSQSObj, "AWS Region"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("type Of Queue")).toEqual(jsonUtil.getValue(awsSQSObj, "Type Of Queue"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("Queue Name")).toEqual(queueName);
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("default Visibility Timeout")).toEqual(jsonUtil.getValue(awsSQSObj, "Default Visibility Timeout"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("delivery Delay")).toEqual(jsonUtil.getValue(awsSQSObj, "Delivery Delay"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("receive Message Wait Time")).toEqual(jsonUtil.getValue(awsSQSObj, "Receive Message Wait Time"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("use Redrive Policy")).toEqual(jsonUtil.getValue(awsSQSObj, "Use Redrive Policy"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use SSE")).toEqual(jsonUtil.getValue(awsSQSObj, "Use SSE"));

                // Validate BOM values

                // Validate Addon BOM Values
            }

            // Addon Services Values table validations
            expect(snowPage.getTextReqItemAddOnValuesBasedOnName(imiConfigTemplate.managementLevelKey)).toEqual(snowInstanceTemplate.snowAzureAddOnManagementLevelValue);
            expect(snowPage.getTextReqItemAddOnValuesBasedOnName(imiConfigTemplate.managementLevelSummaryKey)).toEqual(snowInstanceTemplate.snowAzureAddOnManagementLevelSummaryValue);
            expect(snowPage.getTextReqItemAddOnValuesBasedOnName(imiConfigTemplate.planLevelKey)).toEqual(snowInstanceTemplate.snowAzureAddOnPlanLevelValue);
            expect(snowPage.getTextReqItemAddOnValuesBasedOnName(imiConfigTemplate.planLevelSummaryKey)).toContain(snowInstanceTemplate.snowAzureAddOnPlanLevelSummaryValue);

            //Validations on SNOW Configuration Item- Service Instance CIs page
            snowPage.switchToDefaultContent();
            snowPage.switchToParentFrame();
            snowPage.openConfItemServiceInstanceCIs();
            expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
            expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
            expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
            snowPage.clickUpdateButton();
            
            //Validation on Catalog Task page
            snowPage.clickCatalogTaskLink();
            expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
            snowPage.clickBackButton();
            
            //Normal change
            snowPage.openRelatedChangeRequest();
            expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
            snowPage.enterChangeReqValues();
            snowPage.enterPlanningValues();
            snowPage.enterScheduleValues();
            snowPage.clickCalculateRiskLink();
            snowPage.clickAssessButton();
            
            //Approvals in SNOW
            snowPage.clickRequestApprovalInChangeRequestPage();
            snowPage.approveChangeRequestForEachState();
            snowPage.approveRequestQS();
            snowPage.approveRequestQS();
            expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);			
                    
            //Order Completion in SNOW
            snowPage.rightClickOnCMDBCIFormHeader();
            var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
            sysidofChangeRequest.then(function(sysidofChangeRequestValue){
                var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
                setChangeRequesttoImplementState.then(function(statuscode){
                    expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
                });
            });
            snowPage.checkIfProvisioningTaskClosed();
            snowPage.closeNotifySerDeskTask();
            snowPage.closeImplementTask();
            snowPage.clickCloseChangeRequestButton();
            snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);

            //Validation in Marketplace
            browser.get(consumeLaunchpadUrl);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
            orderHistoryPage.searchOrder(orderObject.orderNumber);
            if(sName.includes(serviceName1)) {
                orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
                expect(orderHistoryPage.getStatusBasedOnServiceNameWithAddOn(serviceName1)).toBe(awsEC2template.completedState);
            }
            else {
                orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
                expect(orderHistoryPage.getStatusBasedOnServiceNameWithAddOn(serviceName2)).toBe(awsEC2template.completedState);
            }
        });

        //Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
        snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
        snowPage.clickFirstRequestedItemLink();
        expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
        snowPage.openConfItemServiceInstanceCIs();
        expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
        expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
        snowPage.clickUpdateButton();	
        
        //Validation on Catalog Task page after completion
        snowPage.clickCatalogTaskLink();
        expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
        snowPage.clickBackButton();
    });

    afterAll(function () {
        //Delete Approval Policy
        browser.get(consumeLaunchpadUrl);
        cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
        policyPage.open();
        util.waitForAngular();
        policyPage.searchPolicyInPolicyTextbox(policyName);
        policyPage.clickPolicyDetailIcon();
        policyPage.clickPolicyViewDetailButton();
        policyPage.clickRadioButtonRetiredOption();
        policyPage.clickUpdatePolicyBtn();
        expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg + " " + policyName + " successfully");
        var policyStatusInPolicy = policyPage.getTextPolicyStatusInPolicyTable(policyName);
        expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
        policyPage.searchPolicyInPolicyTextbox(policyName);
        policyPage.clickPolicyDetailIcon();
        policyPage.clickButtonDeletePolicyText();
        policyPage.clickDeleteConfirmationPopUpPolicyBtn();
        util.waitForAngular();
        policyPage.searchPolicyInPolicyTextbox(policyName);
        expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

        browser.get(consumeLaunchpadUrl);
        cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
    });
});