"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../helpers/logGenerator.js"),
    appUrls = require('../../../../testData/appUrls.json'),
    shoppingCartTemplate = require('../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
    imiConfigTemplate = require('../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    ec2InstanceTemplate = require('../../../../testData/OrderIntegration/AWS/ec2InstanceWithApache.json');

describe('AWS - EC2 With Apache', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, EC2INSObject, inventoryPage, msgToVerify;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = ec2InstanceTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Compute',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-ec2Apache-" + util.getRandomString(5);
    });

    beforeEach(function () {
        modifiedParamMap = { "Service Instance Name": serviceName };
    });

    it('AWS-EC2 With Apache - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        catalogPage.open();
        EC2INSObject = JSON.parse(JSON.stringify(ec2InstanceTemplate));
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(ec2InstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(ec2InstanceTemplate.TotalCost);
            }
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Instance Type"]).toEqual(requiredReturnMap["Expected"]["Instance Type"]);
            expect(requiredReturnMap["Actual"]["Web Server Port"]).toEqual(requiredReturnMap["Expected"]["Web Server Port"]);
            expect(requiredReturnMap["Actual"]["VPC"]).toEqual(requiredReturnMap["Expected"]["VPC"]);
            expect(requiredReturnMap["Actual"]["Key Pair"]).toEqual(requiredReturnMap["Expected"]["Key Pair"]);
            expect(requiredReturnMap["Actual"]["SSH Location"]).toEqual(requiredReturnMap["Expected"]["SSH Location"]);
            expect(requiredReturnMap["Actual"]["Key"]).toEqual(requiredReturnMap["Expected"]["Key"]);
            expect(requiredReturnMap["Actual"]["Value"]).toEqual(requiredReturnMap["Expected"]["Value"]);

            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(ec2InstanceTemplate.EstimatedPrice);
                //Validate pricing on order history page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                if (browser.params.defaultCurrency == "USD") {
                    expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(ec2InstanceTemplate.EstimatedPrice);
                }
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();

            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Web Server Port")).toEqual(jsonUtil.getValue(EC2INSObject, "Web Server Port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Key Pair")).toEqual(jsonUtil.getValue(EC2INSObject, "Key Pair"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("SSH Location")).toEqual(jsonUtil.getValue(EC2INSObject, "SSH Location"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(EC2INSObject, "VPC"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Key")).toEqual(jsonUtil.getValue(EC2INSObject, "Key"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Value")).toEqual(jsonUtil.getValue(EC2INSObject, "Value"));
            if (browser.params.defaultCurrency == "USD") {
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(ec2InstanceTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(ec2InstanceTemplate.TotalCost);
            }
            ordersHistoryPage.closeServiceDetailsSlider();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("Web Server Port")).toEqual(jsonUtil.getValue(EC2INSObject, "Web Server Port"));
            expect(ordersPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            expect(ordersPage.getTextBasedOnLabelName("Key Pair")).toEqual(jsonUtil.getValue(EC2INSObject, "Key Pair"));
            expect(ordersPage.getTextBasedOnLabelName("SSH Location")).toEqual(jsonUtil.getValue(EC2INSObject, "SSH Location"));
            expect(ordersPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(EC2INSObject, "VPC"));
            expect(ordersPage.getTextBasedOnExactLabelName("Key")).toEqual(jsonUtil.getValue(EC2INSObject, "Key"));
            expect(ordersPage.getTextBasedOnLabelName("Value")).toEqual(jsonUtil.getValue(EC2INSObject, "Value"));
            if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(ec2InstanceTemplate.TotalCost);
            }
            ordersPage.clickServiceDetailSliderCloseButton();
        });
    });

    it('AWS-EC2 With Apache-Verify Website URL and Delete Service', function () {
        if (isDummyAdapterDisabled == "true") {
            //Validate Service Details on Inventory Page            
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();
            expect(inventoryPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "AWS Region"));
            expect(inventoryPage.getTextBasedOnLabelName("Web Server Port")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "Web Server Port"));
            expect(inventoryPage.getTextBasedOnLabelName("instance Type")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "Instance Type"));
            expect(inventoryPage.getTextBasedOnLabelName("SSH Location")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "SSH Location"));
            expect(inventoryPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "VPC"));
            expect(inventoryPage.getTextBasedOnLabelName("Key")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "Key"));
            expect(inventoryPage.getTextBasedOnLabelName("Value")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "Value"));
            expect(inventoryPage.getTextBasedOnLabelName("Key Pair")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "Key Pair"));

            inventoryPage.getWebSiteUrl("WebsiteURL").then(function (webUrl) {
                //open url in new tab and check if website is displaying
                browser.executeScript("window.open()");
                return browser.getAllWindowHandles().then(function (handles) {
                    const newWindowHandle = handles[1];
                    browser.switchTo().window(newWindowHandle);
                    browser.get(webUrl).then(function () {
                        util.waitForAngular();
                        expect(inventoryPage.getEc2ServerHeading()).toEqual(ec2InstanceTemplate.ec2ServerMsg);
                        browser.close();
                        util.switchToParentWindow();
                        //util.switchToChildWindow();
                        util.switchToFrame();
                    });
                });
            });
            if (browser.params.defaultCurrency == "USD") {
                // Validate BOM (Inventory Page)
                inventoryPage.clickBomTab();
                expect(inventoryPage.getBOMTableEstimatedPrice()).toEqual(ec2InstanceTemplate.TotalCost);
                //Validate order history tab
                inventoryPage.clickOrderHistorTab();
                //expect(inventoryPage.getTextOrderIdOnOrderHistory()).toEqual(orderObject.orderNumber);
                expect(inventoryPage.getTextNewOperationType()).toEqual(ec2InstanceTemplate.newOrderType);
                expect(inventoryPage.getTextOrderStatus()).toEqual(messageStrings.completedState)
                expect(inventoryPage.getTextEstimatedCostOnOrderHistory()).toEqual(ec2InstanceTemplate.TotalCost);
                inventoryPage.closeViewComponent();
            }
        }

        //Delete Service flow                    
        orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, ec2InstanceTemplate.bluePrintName);
        orderFlowUtil.approveDeletedOrder(orderObject);
        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
    });

});
