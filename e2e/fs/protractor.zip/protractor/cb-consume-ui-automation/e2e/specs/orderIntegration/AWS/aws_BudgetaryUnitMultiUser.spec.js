"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),
	budgetaryFlow = require('../../../../helpers/budgetaryFlow.js'),
	budgetDeleteApi = require('../../../../helpers/budgetDeleteApiUtil.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	superUserUsername = browser.params.username,
	superUserPassword = browser.params.password,
	budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
	budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryAddNewBudgetDetails.json'),
	userCredentialsTemplate = require('../../../../testData/credentials.json'),
	kmsInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSKMSInstance.json');

describe('AWS - Multi user budget Functionlaities', function () {
	var ordersPage, catalogPage, placeOrderPage, cartListPage, orderHistoryPage, serviceName, cartName, userCredntialsObject, budgetName, alias,
		budgetryPage, budgetaryName, budgetaryNewBudgetName, budgetaryUnitCode;
	var modifiedParamMap = {};
	var modifiedParamMapBudget = {};
	var modifiedNewBudgetParamMap = {};
	var messageStrings = {
		providerName: 'Amazon',
		catalogPageTitle: 'Search, Select and Configure',
		inputServiceNameWarning: "Parameter Warning:",
		orderSubmittedConfirmationMessage: 'Order Submitted',
		budgetaryUnitDeleteSuccessMsg:budgetaryUnitDetailsTemplate.budgetaryUnitDeleteSuccessMsg
	};

	beforeAll(function () {
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		orderHistoryPage = new OrderHistoryPage();
		browser.driver.manage().window().maximize();
		userCredntialsObject = JSON.parse(JSON.stringify(userCredentialsTemplate));
		budgetryPage = new BudgetaryPage();
		budgetaryName = "awsAutMultiUser" + util.getRandomString(8);
		budgetaryNewBudgetName = "newAwsAutMultiuser" + util.getRandomString(8);
		budgetaryUnitCode = "AwsCodeMultiUser" + util.getRandomString(8);
		serviceName = "budgetAws-multiUser-" + util.getRandomString(5);
		alias = "kms-" + util.getRandomString(5)
		modifiedParamMap = { "Service Instance Name": serviceName, "Team" : "budgetTEAM1", "Environment": "awsEnv", "Application": "awsApp", "Provider Account": "", "Alias": alias };
		modifiedParamMapBudget = { "budgetary Name": budgetaryName, "budgetary unit code": budgetaryUnitCode, "Choose Entity": "Organization", "Entity Value": "budgetORG", "Environment": "awsEnv", "Application": "awsApp" };
	});
	
	//Pre-Requisite
	/*1.Make sure to have budget is already created.
	2.Context text for Environment and application must be available.
	3.Context must be mapped to TEAM.*/

	// beforeEach(function () {
	// 	catalogPage.open();
	// });
	

	it('Add new budgetry Unit for E2E budget Flow ', function () {
		//Make sure to create budget using super user cbadmn		    
// 		catalogPage.getUserID(userCredentialsTemplate.superUserName).then(function (status) {
// 			if (status != true) {
// 				cartListPage.clickUserIcon();
// 				cartListPage.clickLogoutButton();
// 				cartListPage.loginFromOtherUser(userCredentialsTemplate.superUserID, userCredentialsTemplate.superUserPassword);
// 				catalogPage.open();
// 				expect(catalogPage.getUserID(userCredentialsTemplate.superUserName)).toBe(true);
// 			}
// 		});
		orderFlowUtil.closeHorizontalSliderIfPresent();
		budgetryPage.open();    		
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMapBudget);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		var startPeriod = budgetaryFlow.incrementMonth(0);
		modifiedNewBudgetParamMap = { "Name": budgetaryNewBudgetName, "Start Period": startPeriod, "Notify When Soft Quota reached": "budgetTEAM1", "Notify When Hard Quota reached": "budgetTEAM1" };
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		budgetryPage.clickOnNotificationCloseButton();
		//budgetryPage.clickOnBudgetaryBackBudgetButton();		
		budgetryPage.clickBudgetSliderCloseButton();
	});

	it('AWS : Multi User Budget Validation for AWS KMS Service', async function () {
		
		var availBudgetProvCompleted, afterProvCommittedAmnt, beforePovisioningAvailBudget;
		var orderObject = {};
		var kmsInsObject = JSON.parse(JSON.stringify(kmsInstanceTemplate));

		// Logout from the super user
		//cartListPage.clickUserIcon();
		//cartListPage.clickLogoutButton();
		//login with the buyer role user and place order
		orderFlowUtil.closeHorizontalSliderIfPresent();	
		catalogPage.open();
		await cartListPage.loginFromOtherUser(userCredntialsObject.buyerUserID, userCredntialsObject.buyerUserPassword);
		catalogPage.open();
		expect(catalogPage.getUserID(userCredntialsObject.buyerUserName)).toBe(true);		
		util.switchToFrame();
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(kmsInstanceTemplate.Category);
		orderObject.servicename = serviceName;
		catalogPage.clickConfigureButtonBasedOnName(kmsInstanceTemplate.bluePrintName);

		orderFlowUtil.fillOrderDetails(kmsInstanceTemplate, modifiedParamMap).then(async function (ttt) {
			//Submit order
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();

			//Get details on pop up after submit
			var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			var orderprice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			placeOrderPage.getTextSubmittedByOrderSubmittedModal().then(function (ordersubmittedBy) {
				expect(ordersubmittedBy.split(" ")[0]).toEqual((userCredntialsObject.buyerUserName).split(" ")[0]);
			});

			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

			// Logout from the buyer role user			
			//cartListPage.clickUserIcon();
			//cartListPage.clickLogoutButton();

			await cartListPage.loginFromOtherUser(userCredntialsObject.technicalApprovalUserID, userCredntialsObject.technicalApprovalUserPass);
			expect(catalogPage.getUserID(userCredntialsObject.technicalApprovalUser)).toBe(true);
			orderFlowUtil.approveOrderTechnically(orderObject);//.then(function(){
			//to check budget is not present as the user have only technical approval role
			await expect(ordersPage.checkInvisibilityOfBudgetDetails()).toBe(false, "For technically approval role user Budget details is not present on the Approve order page.")
			//})

			//log out from the technically approval role user
			//browser.ignoreSynchronization = false;
			catalogPage.open();
			//cartListPage.clickUserIcon();
			//cartListPage.clickLogoutButton();
			//login from the financially approval role user
			await cartListPage.loginFromOtherUser(userCredntialsObject.financialApprovalUserID, userCredntialsObject.financialApprovalUserPass);
			expect(catalogPage.getUserID(userCredntialsObject.financialApprovalUser)).toBe(true);
			ordersPage.open();
			ordersPage.searchOrderById(orderObject.orderNumber);
			browser.sleep(10000);
			//select Budgetary Unit
			ordersPage.selectBudgetaryUnit(budgetaryName);
			util.waitForAngular();

			//Budget verification 
			expect(ordersPage.getTextBudgetAmmount()).toEqual(kmsInstanceTemplate.BudgetAmount);
			var beforePovisioningCommittedAmount = await ordersPage.getTextBudgetaryCommittedAmmount();
			var calculatedEstAmount = ordersPage.calculateBudgetaryEstimatedAmmountforOrder(kmsInstanceTemplate.budgetDuration, kmsInstanceTemplate.TotalCost);
			beforePovisioningAvailBudget = await ordersPage.getTextAvailableBudget();
			var costOtherOrdersAwaitingApprovalBeforeProvision = await ordersPage.getTextOtherOrdersAwaitingApproval();
			expect(ordersPage.getTextBudgetarySpendAmmount()).toEqual("USD 0.00");
			expect(ordersPage.getTextBudgetaryEstimatedAmmountforOrder()).toContain(calculatedEstAmount);
			orderFlowUtil.approveOrderFinancially(orderObject);

			orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed').then(function () {

				/********** Order provisioning completed **********/
				//order status completed 
				availBudgetProvCompleted = ordersPage.calculateAvailableBudgetAfterProvCompleted(beforePovisioningAvailBudget, calculatedEstAmount);
				expect(ordersPage.getTextAvailableBudget()).toContain(availBudgetProvCompleted);


				var actualOrdersAwaitingApprovalAmout = ordersPage.calculateAfterProvOtherOrderAwaitingApprovalAmount(costOtherOrdersAwaitingApprovalBeforeProvision, calculatedEstAmount);
				expect(ordersPage.getTextOtherOrdersAwaitingApproval()).toEqual(actualOrdersAwaitingApprovalAmout);

				afterProvCommittedAmnt = ordersPage.calculateCommittedAmountAfterProvCompleted(beforePovisioningCommittedAmount, calculatedEstAmount);
				expect(ordersPage.getTextBudgetaryCommittedAmmount()).toContain(afterProvCommittedAmnt);

				expect(ordersPage.getTextBudgetarySpendAmmount()).toEqual("USD 0.00");
			});
			//browser.ignoreSynchronization = false;
			//Open Approve order page
			ordersPage.open();
			//Logout from the financial approval user roles
			//cartListPage.clickUserIcon();
			//cartListPage.clickLogoutButton();

			//Login from the buyer role user 
			await cartListPage.loginFromOtherUser(userCredntialsObject.buyerUserID, userCredntialsObject.buyerUserPassword);
			expect(catalogPage.getUserID(userCredntialsObject.buyerUserName)).toBe(true);
			//Place the deleteorder from the buyer role
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			// expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
			catalogPage.open();
			//Logout from the buyer role user
			//cartListPage.clickUserIcon();
			//cartListPage.clickLogoutButton();
			//Login from the technically approval role user
			await cartListPage.loginFromOtherUser(userCredntialsObject.technicalApprovalUserID, userCredntialsObject.technicalApprovalUserPass);
			expect(catalogPage.getUserID(userCredntialsObject.technicalApprovalUser)).toBe(true);
			orderFlowUtil.approveDeletedOrderTechnically(orderObject);
			//Logout from the technically approval role user
			catalogPage.open();
			//cartListPage.clickUserIcon();
			//cartListPage.clickLogoutButton();
			//Login from the financially approval role user
			await cartListPage.loginFromOtherUser(userCredntialsObject.financialApprovalUserID, userCredntialsObject.financialApprovalUserPass);
			expect(catalogPage.getUserID(userCredntialsObject.financialApprovalUser)).toBe(true);
			// catalogPage.open();
			orderFlowUtil.approveDeletedOrderFinancially(orderObject);

			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed').then(function () {

				/********** Delete order status completed **********/
				var estCostAfterDeleting1MonthOrder = ordersPage.calculateEstCostAfterDeleting1MonthOrder(calculatedEstAmount, kmsInstanceTemplate.TotalCost);
				expect(estCostAfterDeleting1MonthOrder).toContain(ordersPage.getTextBudgetaryEstimatedAmmountforOrder());

				var deletedCommittedAmnt = ordersPage.calculateDeleteCommittedAmount(afterProvCommittedAmnt, estCostAfterDeleting1MonthOrder);
				expect(deletedCommittedAmnt).toContain(ordersPage.getTextBudgetaryCommittedAmmount());

				var deletedAvailableBudget = ordersPage.calculateAfterDeletingAvailBudget(availBudgetProvCompleted, estCostAfterDeleting1MonthOrder);
				expect(deletedAvailableBudget).toContain(ordersPage.getTextAvailableBudget());

			});
			//Logout from the financially approval role user
			//cartListPage.clickUserIcon();
			//cartListPage.clickLogoutButton();
			//Login with super user
			await cartListPage.loginFromOtherUser(superUserUsername, superUserPassword);
			expect(catalogPage.getUserID(userCredntialsObject.superUserName)).toBe(true);
		});

	});

	afterAll(async function () {	
		orderFlowUtil.closeHorizontalSliderIfPresent();
		//catalogPage.open();			
		catalogPage.getUserID(userCredentialsTemplate.superUserName).then(async function (status) {
			if (status != true) {
				//cartListPage.clickUserIcon();
				//cartListPage.clickLogoutButton();
				await cartListPage.loginFromOtherUser(userCredentialsTemplate.superUserID, userCredentialsTemplate.superUserPassword);
				catalogPage.open();
				expect(catalogPage.getUserID(userCredentialsTemplate.superUserName)).toBe(true);
			}		
		});
		budgetryPage.deleteBudget(budgetaryName);
		//expect(budgetryPage.getNotificationMsg()).toContain(messageStrings.budgetaryUnitDeleteSuccessMsg);
	});

});
