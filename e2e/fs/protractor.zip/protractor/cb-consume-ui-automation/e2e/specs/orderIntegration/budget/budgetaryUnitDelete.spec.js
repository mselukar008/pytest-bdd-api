/*************************************************
	AUTHOR: Pushpraj Singh
 **************************************************/

"use strict";

var BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),
budgetDeleteApi = require('../../../../helpers/budgetDeleteApiUtil.js'),
util = require('../../../../helpers/util.js'),
CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
budgetaryFlow = require('../../../../helpers/budgetaryFlow.js'),
jsonUtil = require('../../../../helpers/jsonUtil.js'),
appUrls = require('../../../../testData/appUrls.json'),
credentialsTemplate = require('../../../../testData/credentials.json'),
budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
budgetaryUnitDeleteTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDelete.json'),
budgetaryUnitEditDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitEditDetails.json'),
budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryAddNewBudgetDetails.json'),
budgetaryBudgetEditDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryBudgetEditDetails.json'),
subnetTemplate = require('../../../../testData/OrderIntegration/Softlayer/budgetSubnet.json');

describe('budgetary Test cases - ', function() {
	var catalogPage, placeOrderPage, ordersPage, budgetaryName, budgetaryNameNew, budgetaryEditName, budgetaryUnitCode, budgetaryUnitCodeNew, budgetaryDetailName, budgetRefId, budgetaryRefId,
	budgetaryBudgetName, budgetaryNewBudgetName, userName, budgetryPage, serviceName;
	var messageStrings = {
			providerName: budgetaryUnitDetailsTemplate.provider,
			budgetDesc: budgetaryUnitDetailsTemplate.budgetDesc,
			budgetRefId: budgetaryUnitDetailsTemplate.budgetRefId,
			budgetEntity: budgetaryUnitDetailsTemplate.budgetEntity,
			budgetEnv: budgetaryUnitDetailsTemplate.budgetEnv,
			budgetApp: budgetaryUnitDetailsTemplate.budgetApp,
			budgetTerm: budgetaryUnitDetailsTemplate.budgetTerm,
			budgetActive: budgetaryUnitDetailsTemplate.budgetActive,
			budgetSuccessMsg: budgetaryUnitDetailsTemplate.budgetSuccessMsg,
			budgetDeleteSuccessMsg : budgetaryUnitDeleteTemplate.budgetDeleteSuccessMsg,
			oneBudgetDeleteSuccessMsg : budgetaryUnitDeleteTemplate.oneBudgetDeleteSuccessMsg,
			twoBudgetDeleteSuccessMsg : budgetaryUnitDeleteTemplate.twoBudgetDeleteSuccessMsg,
			noDataAvailableMsg : budgetaryUnitDeleteTemplate.noDataAvailableMsg,
			budgetaryUnitDeleteSuccessMsg : budgetaryUnitDeleteTemplate.budgetaryUnitDeleteSuccessMsg,
			budgetaryUnitsDeleteSuccessMsg : budgetaryUnitDeleteTemplate.budgetaryUnitsDeleteSuccessMsg,
			budgetDeleteWarningMsg : budgetaryUnitDeleteTemplate.budgetDeleteWarningMsg,
			twoBudgetsDeactivateSuccessMsg : budgetaryUnitDeleteTemplate.twoBudgetsDeactivateSuccessMsg
	};

	beforeAll(function() {		
		budgetryPage = new BudgetaryPage();
		browser.driver.manage().window().maximize();
		budgetaryName = "autoBudgetUnit"+util.getRandomString(8);
		budgetaryNameNew = "autoBudgetUnit"+util.getRandomString(8);
		budgetaryDetailName = "autoBudgetEdit"+util.getRandomString(8);
		budgetaryBudgetName = "autoBudget"+util.getRandomString(8);
		budgetaryNewBudgetName = "autoBudget"+util.getRandomString(8);
		budgetaryEditName = "autoBudgetUnitEdit"+util.getRandomString(8);
		budgetaryUnitCode = "autoBudgetUnitCode"+util.getRandomString(8);
		budgetaryUnitCodeNew = "autoBudgetUnitCode"+util.getRandomString(8);
		budgetRefId = "autoRefId"+util.getRandomString(8);
		budgetaryRefId = "autoRefId"+util.getRandomString(8);
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		ordersPage = new OrdersPage();
	});

	beforeEach(function() {
		budgetryPage.closeBudgetSliderIfPresent();
		budgetryPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.budgetaryUrl);
	});

	it('Add new budgetary Unit', function () {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
		util.waitForAngular();	
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.isPresentAddNewBudgetryUnitPanel();
		budgetryPage.isPresentAddNewBudgetryUnitText();
		var modifiedParamMap = {"budgetary Name":budgetaryName, "budgetary unit code":budgetaryUnitCode};
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMap);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickBudgetSliderCloseButton();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		expect(status).toEqual(messageStrings.budgetActive);				
	});

	it('Add Budget for newly created budgetary unit', function() {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryAddNewBudgetDetailsTemplate));
		util.waitForAngular();	
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);	
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(0); //Zero (0) for current month
		var modifiedNewBudgetParamMap = {"Name":budgetaryNewBudgetName, "Start Period":startPeriod, "Notify When Soft Quota reached" : "", "Notify When Hard Quota reached" : ""};
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetryPage.clickOnBudgetaryBackBudgetButton();
		expect(budgetryPage.getBudgetName()).toEqual(budgetaryNewBudgetName);
	});

	
	it('Delete budget for newly created budgetary unit once inactivated', function() {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryAddNewBudgetDetailsTemplate));
		util.waitForAngular();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);	
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickViewDetailActionIcon();
    	budgetryPage.clickViewDetailBtn();
    	budgetryPage.clickBudgetEditButton();
    	budgetryPage.clickBudgetInactiveStatusText();
    	budgetryPage.clickSaveBudgetButton();
    	budgetryPage.clickOnNotificationCloseButton();
    	budgetryPage.clickOnDeleteBtnFromBudgetDetailsPage();
    	budgetryPage.clickOnDeleteConfirmationBtn(0); // index
    	expect(budgetryPage.getBudgetDeletedMsg()).toContain(messageStrings.budgetDeleteSuccessMsg);
    	expect(budgetryPage.getBudgetTableMessage()).toEqual(messageStrings.noDataAvailableMsg);
	});
	
	
	it('Delete budget after adding it to newly created budgetary unit by selecting checkbox', function() {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryAddNewBudgetDetailsTemplate));
		util.waitForAngular();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);	
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(0); //Zero (0) for current month
		var modifiedNewBudgetParamMap = {"Name":budgetaryNewBudgetName, "Start Period":startPeriod, "Notify When Soft Quota reached" : "", "Notify When Hard Quota reached" : ""};
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetryPage.clickOnBudgetaryBackBudgetButton();
		expect(budgetryPage.getBudgetName()).toEqual(budgetaryNewBudgetName);
		budgetryPage.clickViewDetailActionIcon();
    	budgetryPage.clickViewDetailBtn();
		budgetryPage.clickBudgetEditButton();
    	budgetryPage.clickBudgetInactiveStatusText();
    	budgetryPage.clickSaveBudgetButton();
    	budgetryPage.clickOnNotificationCloseButton();
    	budgetryPage.clickAfterEditingBudgetaryBackButton();
    	budgetryPage.selectCheckBoxBasedOnName(budgetaryNewBudgetName);
    	budgetryPage.clickonDeleteBtnForSelectedItem();
    	budgetryPage.clickOnDeleteConfirmationBtn(1);
    	expect(budgetryPage.getBudgetDeletedMsg()).toContain(messageStrings.oneBudgetDeleteSuccessMsg);
    	expect(budgetryPage.getBudgetTableMessage()).toEqual(messageStrings.noDataAvailableMsg);
	});

	it('Delete budget after adding it to newly created budgetary unit by selecting multiple checkbox', function() {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryAddNewBudgetDetailsTemplate));
		util.waitForAngular();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);	
		
		//Add budget 1
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(0); //Zero (0) for current month
		var modifiedNewBudgetParamMapNew = {"Name":budgetaryNewBudgetName, "Start Period":startPeriod, "Notify When Soft Quota reached" : "", "Notify When Hard Quota reached" : ""};
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMapNew);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetryPage.clickOnBudgetaryBackBudgetButton();
		expect(budgetryPage.getBudgetName()).toEqual(budgetaryNewBudgetName);
		budgetryPage.clickViewDetailActionIcon();
    	budgetryPage.clickViewDetailBtn();
		budgetryPage.clickBudgetEditButton();
    	budgetryPage.clickBudgetInactiveStatusText();
    	budgetryPage.clickSaveBudgetButton();
    	budgetryPage.clickOnNotificationCloseButton();
    	budgetryPage.clickAfterEditingBudgetaryBackButton();
    	
    	//Add Budget 2
    	budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(3); //Zero (0) for current month
		var modifiedNewBudgetParamMap = {"Name":budgetaryBudgetName, "Start Period":startPeriod, "Notify When Soft Quota reached" : "", "Notify When Hard Quota reached" : ""};
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetryPage.clickOnBudgetaryBackBudgetButton();
    	
    	budgetryPage.selectCheckBoxBasedOnName(budgetaryNewBudgetName);
    	budgetryPage.selectCheckBoxBasedOnName(budgetaryBudgetName);
    	budgetryPage.clickonDeleteBtnForSelectedItem();
    	budgetryPage.clickOnDeleteConfirmationBtn(1);
    	expect(budgetryPage.getBudgetDeletedMsg()).toContain(messageStrings.twoBudgetDeleteSuccessMsg);
    	expect(budgetryPage.getBudgetTableMessage()).toEqual(messageStrings.noDataAvailableMsg);
	});
	
	it('Delete budgetary unit from budgetary unit details page', function () {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
		util.waitForAngular();	
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
		budgetryPage.clickOnDeleteBtnFromBudgetaryDetailsPage();
		budgetryPage.clickOnDeleteConfirmationButton();
		expect(budgetryPage.getNotificationMsg()).toContain(messageStrings.budgetaryUnitDeleteSuccessMsg);
		budgetryPage.open();
		var isPresent = budgetaryFlow.checkBudgetaryUnitInBudgetaryUnitTable(budgetaryName);
		expect(isPresent).toBe(false);				
	});
	
	it('Delete budgetary Unit by selecting checkbox', function () {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
		util.waitForAngular();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.isPresentAddNewBudgetryUnitPanel();
		budgetryPage.isPresentAddNewBudgetryUnitText();
		var modifiedParamMap = {"budgetary Name":budgetaryName, "budgetary unit code":budgetaryUnitCode};
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMap);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickBudgetSliderCloseButton();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.selectCheckBoxBasedOnName(budgetaryName);
		budgetryPage.clickonDeleteBtnForSelectedItem();
    	budgetryPage.clickOnDeleteConfirmationBtn(3);
    	expect(budgetryPage.getNotificationMsg()).toContain(messageStrings.budgetaryUnitDeleteSuccessMsg);
    	budgetryPage.open();
		var isPresent = budgetaryFlow.checkBudgetaryUnitInBudgetaryUnitTable(budgetaryName);
		expect(isPresent).toBe(false);	
	});
	
	it('Delete budgetary Unit by selecting multiple checkbox', function () {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
		//Budgetary unit 1
		util.waitForAngular();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.isPresentAddNewBudgetryUnitPanel();
		budgetryPage.isPresentAddNewBudgetryUnitText();
		var modifiedParamMap = {"budgetary Name":budgetaryName, "budgetary unit code":budgetaryUnitCode};
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMap);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickBudgetSliderCloseButton();
				
		//Budgetary unit 2
		util.waitForAngular();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.isPresentAddNewBudgetryUnitPanel();
		budgetryPage.isPresentAddNewBudgetryUnitText();
		var modifiedParamMapNew = {"budgetary Name":budgetaryNameNew, "budgetary unit code":budgetaryUnitCodeNew};
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMapNew);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickBudgetSliderCloseButton();
		
		budgetryPage.open();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.selectCheckBoxBasedOnName(budgetaryName);
		
		budgetryPage.open();
		budgetryPage.isPresentBudgetryUnitsTable();		
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryNameNew);
		var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryNameNew);
		expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.selectCheckBoxBasedOnName(budgetaryNameNew);
		
		budgetryPage.clickonDeleteBtnForSelectedItem();
    	budgetryPage.clickOnDeleteConfirmationBtn(3);
    	expect(budgetryPage.getNotificationMsg()).toContain(messageStrings.budgetaryUnitsDeleteSuccessMsg);
    	budgetryPage.open();
		var isPresent = budgetaryFlow.checkBudgetaryUnitInBudgetaryUnitTable(budgetaryName);
		expect(isPresent).toBe(false);	
		
		budgetryPage.open();
		var isPresent = budgetaryFlow.checkBudgetaryUnitInBudgetaryUnitTable(budgetaryNameNew);
		expect(isPresent).toBe(false);	
	});
	
	it('Delete budgetary Unit by selecting multiple checkboxes with active and inactive combination', function () {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
		//Budgetary unit 1
		util.waitForAngular();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.isPresentAddNewBudgetryUnitPanel();
		budgetryPage.isPresentAddNewBudgetryUnitText();
		var modifiedParamMap = {"budgetary Name":budgetaryName, "budgetary unit code":budgetaryUnitCode};
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMap);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickBudgetSliderCloseButton();
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
		budgetryPage.isPresentBudgetryDetailsUnitPanel();
		util.waitForAngular();
		budgetryPage.clickOnEditBudgetaryButton();
		budgetryPage.clickOnBudgetaryStatusChangeButton();
		budgetryPage.isPresentBudgetryEditUpdateSuccessMsg();
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetryPage.clickBudgetSliderCloseButton();
				
		//Budgetary unit 2
		util.waitForAngular();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.isPresentAddNewBudgetryUnitPanel();
		budgetryPage.isPresentAddNewBudgetryUnitText();
		var modifiedParamMapNew = {"budgetary Name":budgetaryNameNew, "budgetary unit code":budgetaryUnitCodeNew};
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMapNew);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickBudgetSliderCloseButton();
		
		budgetryPage.open();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.selectCheckBoxBasedOnName(budgetaryName);
		
		budgetryPage.open();
		budgetryPage.isPresentBudgetryUnitsTable();		
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryNameNew);
		var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryNameNew);
		expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.selectCheckBoxBasedOnName(budgetaryNameNew);
		
		budgetryPage.clickonDeleteBtnForSelectedItem();
    	budgetryPage.clickOnDeleteConfirmationBtn(3);
    	expect(budgetryPage.getNotificationMsg()).toContain(messageStrings.budgetaryUnitsDeleteSuccessMsg);
    	budgetryPage.open();
		var isPresent = budgetaryFlow.checkBudgetaryUnitInBudgetaryUnitTable(budgetaryName);
		expect(isPresent).toBe(false);	
		
		budgetryPage.open();
		var isPresent = budgetaryFlow.checkBudgetaryUnitInBudgetaryUnitTable(budgetaryNameNew);
		expect(isPresent).toBe(false);	
	});
	
	it('Delete budget by selecting multiple checkboxes with transaction and w/o transaction combination', function() {
		util.waitForAngular();	
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.isPresentAddNewBudgetryUnitPanel();
		budgetryPage.isPresentAddNewBudgetryUnitText();
		var modifiedParamMap = {"budgetary Name":budgetaryName, "budgetary unit code":budgetaryUnitCode, "Environment": "slEnv", "Application": "slApp"};
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMap);
		budgetryPage.clickOnBudgetrySaveBtn();

		//Add budget 1
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(0);
		var modifiedNewBudgetParamMapNew = {"Name":budgetaryNewBudgetName, "Start Period":startPeriod };
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMapNew);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetryPage.clickOnBudgetaryBackBudgetButton();
    	
    	//Add Budget 2
    	budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(5);
		var modifiedNewBudgetParamMap = {"Name":budgetaryBudgetName, "Start Period":startPeriod };
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetryPage.clickBudgetSliderCloseButton();

		// Add budgetaryBudgetName in transaction
		var orderObject = {};
		serviceName = "GSLSLTestAutomation" + util.getRandomString(5);
		modifiedParamMap = { "Service Instance Name": serviceName, "UpdateMainParamObject": false };
		var slPsJsonObject = JSON.parse(JSON.stringify(subnetTemplate));
		catalogPage.open();
		catalogPage.clickProviderCheckBoxBasedOnName(slPsJsonObject.providerName);
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(slPsJsonObject.Category);
		catalogPage.searchForBluePrint(slPsJsonObject.bluePrintName);
		catalogPage.clickConfigureButtonBasedOnName(slPsJsonObject.bluePrintName);
		orderObject.servicename = serviceName;
		orderFlowUtil.fillOrderDetails(slPsJsonObject, modifiedParamMap);

		placeOrderPage.submitOrder();
		orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
		orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();

		expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
		placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

		ordersPage.open();
		ordersPage.searchOrderById(orderObject.orderNumber);

		util.waitForAngular();

		expect(ordersPage.getTextBudgetAmmount()).toEqual(slPsJsonObject.BudgetAmount);

		budgetryPage.open();
		util.waitForAngular();

		// Try to batch Delete
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
		budgetryPage.clickOnBudgetryBudgetsLink();
		// Number of rows before batch Delete action
		expect(budgetryPage.getNoOfRowsBudget()).toBe(2);
    	budgetryPage.selectCheckBoxBasedOnName(budgetaryNewBudgetName);
    	budgetryPage.selectCheckBoxBasedOnName(budgetaryBudgetName);
		budgetryPage.clickonDeleteBtnForSelectedItem();
		budgetryPage.clickOnDeleteConfirmationBtn(1);
		expect(budgetryPage.getTextDeleteBudgetWarningMsg()).toContain(messageStrings.budgetDeleteWarningMsg);
		// Number of rows after batch Delete action
		expect(budgetryPage.getNoOfRowsBudget()).toBe(1);

		// Deactivate the other budget
		budgetryPage.clickViewDetailActionIcon();
    	budgetryPage.clickViewDetailBtn();
		budgetryPage.clickBudgetEditButton();
    	budgetryPage.clickBudgetInactiveStatusText();
    	budgetryPage.clickSaveBudgetButton();
		budgetryPage.clickOnNotificationCloseButton();
		budgetryPage.clickBudgetSliderCloseButton();
		// Reject the submitted order
		orderFlowUtil.denyOrder(orderObject);
	});

	it('Batch Deactivate budgets --> Batch Delete budgets', function() {
		util.waitForAngular();	
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.isPresentAddNewBudgetryUnitPanel();
		budgetryPage.isPresentAddNewBudgetryUnitText();
		var modifiedParamMap = {"budgetary Name":budgetaryName, "budgetary unit code":budgetaryUnitCode, "Environment": "slEnv", "Application": "slApp"};
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMap);
		budgetryPage.clickOnBudgetrySaveBtn();

		//Add budget 1
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(0);
		var modifiedNewBudgetParamMapNew = {"Name":budgetaryNewBudgetName, "Start Period":startPeriod };
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMapNew);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetryPage.clickOnBudgetaryBackBudgetButton();
    	
    	//Add Budget 2
    	budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(5);
		var modifiedNewBudgetParamMap = {"Name":budgetaryBudgetName, "Start Period":startPeriod };
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetryPage.clickOnBudgetaryBackBudgetButton();

		// Batch Deactivate budgets
    	budgetryPage.selectCheckBoxBasedOnName(budgetaryNewBudgetName);
		budgetryPage.selectCheckBoxBasedOnName(budgetaryBudgetName);
		budgetryPage.clickonDeactivateBtnForSelectedItem();
		budgetryPage.clickOnDeactivateConfirmationBtn();
		expect(budgetryPage.getTextDeactivatingBudgetSuccessMsg()).toContain(messageStrings.twoBudgetsDeactivateSuccessMsg);
		expect(budgetryPage.isBudgetActive(budgetaryNewBudgetName)).toBe(false);
		expect(budgetryPage.isBudgetActive(budgetaryBudgetName)).toBe(false);

		// Batch Delete budgets
		budgetryPage.selectCheckBoxBasedOnName(budgetaryNewBudgetName);
		budgetryPage.selectCheckBoxBasedOnName(budgetaryBudgetName);
		budgetryPage.clickonDeleteBtnForSelectedItem();
		budgetryPage.clickOnDeleteConfirmationBtn(1);
		expect(budgetryPage.getBudgetDeletedMsg()).toContain(messageStrings.twoBudgetDeleteSuccessMsg);
		expect(budgetryPage.getBudgetTableMessage()).toEqual(messageStrings.noDataAvailableMsg);
		budgetryPage.clickBudgetSliderCloseButton();
	});

	it('Batch Deactivate budgets with transaction and w/o transaction combination --> Batch Delete budgets', function() {
		util.waitForAngular();	
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.isPresentAddNewBudgetryUnitPanel();
		budgetryPage.isPresentAddNewBudgetryUnitText();
		var modifiedParamMap = {"budgetary Name":budgetaryName, "budgetary unit code":budgetaryUnitCode, "Environment": "slEnv", "Application": "slApp"};
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMap);
		budgetryPage.clickOnBudgetrySaveBtn();

		//Add budget 1
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(0);
		var modifiedNewBudgetParamMapNew = {"Name":budgetaryNewBudgetName, "Start Period":startPeriod };
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMapNew);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetryPage.clickOnBudgetaryBackBudgetButton();
    	
    	//Add Budget 2
    	budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(5);
		var modifiedNewBudgetParamMap = {"Name":budgetaryBudgetName, "Start Period":startPeriod };
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetryPage.clickBudgetSliderCloseButton();

		// Add budgetaryBudgetName in transaction
		var orderObject = {};
		serviceName = "GSLSLTestAutomation" + util.getRandomString(5);
		modifiedParamMap = { "Service Instance Name": serviceName, "UpdateMainParamObject": false };
		var slPsJsonObject = JSON.parse(JSON.stringify(subnetTemplate));
		catalogPage.open();
		catalogPage.clickProviderCheckBoxBasedOnName(slPsJsonObject.providerName);
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(slPsJsonObject.Category);
		catalogPage.searchForBluePrint(slPsJsonObject.bluePrintName);
		catalogPage.clickConfigureButtonBasedOnName(slPsJsonObject.bluePrintName);
		orderObject.servicename = serviceName;
		orderFlowUtil.fillOrderDetails(slPsJsonObject, modifiedParamMap);

		placeOrderPage.submitOrder();
		orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
		orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();

		expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
		placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

		ordersPage.open();
		ordersPage.searchOrderById(orderObject.orderNumber);

		util.waitForAngular();

		expect(ordersPage.getTextBudgetAmmount()).toEqual(slPsJsonObject.BudgetAmount);

		budgetryPage.open();
		util.waitForAngular();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
		budgetryPage.clickOnBudgetryBudgetsLink();

		// Batch Deactivate budgets
    	budgetryPage.selectCheckBoxBasedOnName(budgetaryNewBudgetName);
		budgetryPage.selectCheckBoxBasedOnName(budgetaryBudgetName);
		budgetryPage.clickonDeactivateBtnForSelectedItem();
		budgetryPage.clickOnDeactivateConfirmationBtn();
		expect(budgetryPage.getTextDeactivatingBudgetSuccessMsg()).toContain(messageStrings.twoBudgetsDeactivateSuccessMsg);
		expect(budgetryPage.isBudgetActive(budgetaryNewBudgetName)).toBe(false);
		expect(budgetryPage.isBudgetActive(budgetaryBudgetName)).toBe(false);

		// Number of rows before batch Delete action
		expect(budgetryPage.getNoOfRowsBudget()).toBe(2);
		// Batch Delete budgets
		budgetryPage.selectCheckBoxBasedOnName(budgetaryNewBudgetName);
		budgetryPage.selectCheckBoxBasedOnName(budgetaryBudgetName);
		budgetryPage.clickonDeleteBtnForSelectedItem();
		budgetryPage.clickOnDeleteConfirmationBtn(1);
		expect(budgetryPage.getTextDeleteBudgetWarningMsg()).toContain(messageStrings.budgetDeleteWarningMsg);
		// Number of rows after batch Delete action
		expect(budgetryPage.getNoOfRowsBudget()).toBe(1);
		budgetryPage.clickBudgetSliderCloseButton();
		// Reject the submitted order
		orderFlowUtil.denyOrder(orderObject);
	});

	afterAll(async function () {
		budgetryPage.closeBudgetSliderIfPresent();		
	});

});
