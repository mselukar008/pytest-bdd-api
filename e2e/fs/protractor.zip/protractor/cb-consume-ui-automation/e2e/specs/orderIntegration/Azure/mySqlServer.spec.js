//Author: Atiksha Batra
"use strict";
var logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    async = require('async'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    MysqlserverTemplate = require('../../../../testData/OrderIntegration/Azure/mySqlServer.json');

describe('Azure - Azure Database for MySQL servers Service ', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, servicename, SOIComponents, mySqlComponent1;
    var modifiedParamMap = {};
    var servicename = "AutoMysqlsrv" + util.getRandomString(5);
    var newResourceGroupName = "gslautotc_azureMysql-RG101" + util.getRandomString(4);
    var serverName = "autoserver" + util.getRandomString(4);
    serverName = serverName.toLowerCase();
    var messageStrings = { providerName: 'Azure', category: 'Databases', templateName: 'Azure Database for MySQL servers' };
    modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Server Name": serverName };
    
    beforeAll(function () {
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    afterAll(function () {
        // Delete Azure Database for MySQL servers 
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    it('Azure: Verify that for Azure Database for MySQL servers Service required parameters on Service Details Page are present.', function () {
        var mySqlServerObject = JSON.parse(JSON.stringify(MysqlserverTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(mySqlServerObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(mySqlServerObject.bluePrintName);
        if (browser.params.defaultCurrency == "USD") {
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(mySqlServerObject.BasePrice);
        }
    });

    it('Azure: Verify Review order and View Order Details for Azure Database for MySQL servers Service', function () {
        var orderObject = {};
        orderObject.servicename = servicename;
        var mySqlServerObject = JSON.parse(JSON.stringify(MysqlserverTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(mySqlServerObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(mySqlServerObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(MysqlserverTemplate, modifiedParamMap);
        //Verify input values on Review Order page    
        expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(mySqlServerObject, "New Resource Group Required"));
        expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
        expect(placeOrderPage.getTextBasedOnLabelName("Location:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Server Name:")).toEqual(serverName);
        expect(placeOrderPage.getTextBasedOnLabelName("Data Source:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Data Source"));
        expect(placeOrderPage.getTextBasedOnLabelName("Server Location:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Server Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Version:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Version"));
        expect(placeOrderPage.getTextBasedOnLabelName("Compute + storage:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Compute + storage"));
        expect(placeOrderPage.getTextBasedOnLabelName("VCore:")).toEqual(jsonUtil.getValue(mySqlServerObject, "VCore"));
        expect(placeOrderPage.getTextBasedOnLabelName("Storage In GB:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Storage In GB"));
        expect(placeOrderPage.getTextBasedOnLabelName("Storage-auto-growth:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Storage-auto-growth"));
        expect(placeOrderPage.getTextBasedOnLabelName("Backup Retention Period:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Backup Retention Period"));
        expect(placeOrderPage.getTextBasedOnLabelName("Backup Redundancy Options:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Backup Redundancy Options"));
        expect(placeOrderPage.getTextBasedOnLabelName("Admin Username:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Admin Username"));
        expect(placeOrderPage.getTextBasedOnLabelName("Allow Azure Service Access:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Allow Azure Service Access"));
        expect(placeOrderPage.getTextBasedOnLabelName("Ssl Enforcement:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Ssl Enforcement"));
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(orderObject.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(orderObject.servicename);//Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe('Azure');//Checking Provider
        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(mySqlServerObject, "New Resource Group Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(mySqlServerObject, "Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(newResourceGroupName);
        expect(ordersPage.getTextBasedOnExactLabelName("Server Name")).toEqual(serverName);
        expect(ordersPage.getTextBasedOnExactLabelName("Data Source")).toEqual(jsonUtil.getValue(mySqlServerObject, "Data Source"));
        expect(ordersPage.getTextBasedOnExactLabelName("Server Location")).toEqual(jsonUtil.getValue(mySqlServerObject, "Server Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("Version")).toEqual(jsonUtil.getValue(mySqlServerObject, "Version"));
        expect(ordersPage.getTextBasedOnExactLabelName("Compute + storage")).toEqual(jsonUtil.getValue(mySqlServerObject, "Compute + storage"));
        expect(ordersPage.getTextBasedOnExactLabelName("VCore")).toEqual(jsonUtil.getValue(mySqlServerObject, "VCore"));
        expect(ordersPage.getTextBasedOnExactLabelName("Storage In GB")).toEqual(jsonUtil.getValue(mySqlServerObject, "Storage In GB"));
        expect(ordersPage.getTextBasedOnExactLabelName("Storage-auto-growth")).toEqual(jsonUtil.getValue(mySqlServerObject, "Storage-auto-growth"));
        expect(ordersPage.getTextBasedOnExactLabelName("Backup Retention Period")).toEqual(jsonUtil.getValue(mySqlServerObject, "Backup Retention Period"));
        expect(ordersPage.getTextBasedOnExactLabelName("Backup Redundancy Options")).toEqual(jsonUtil.getValue(mySqlServerObject, "Backup Redundancy Options"));
        expect(ordersPage.getTextBasedOnExactLabelName("Admin Username")).toEqual(jsonUtil.getValue(mySqlServerObject, "Admin Username"));
        expect(ordersPage.getTextBasedOnExactLabelName("Allow Azure Service Access")).toEqual(jsonUtil.getValue(mySqlServerObject, "Allow Azure Service Access"));
        expect(ordersPage.getTextBasedOnExactLabelName("Ssl Enforcement")).toEqual(jsonUtil.getValue(mySqlServerObject, "Ssl Enforcement"));
        //Checking Bill Of Material
        if (browser.params.defaultCurrency == "USD") {
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(ordersPage.getEstimatedCost()).toBe(mySqlServerObject.TotalCost);
        }
        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
    });

    if (isProvisioningRequired == "true") {
        if (isDummyAdapterDisabled == "false") {
            it('Azure: Verify provisioning of Azure Database for MySQL servers Service using Consume UI', function () {
                var orderObject = {};
                orderObject.servicename = servicename;
                var mySqlServerObject = JSON.parse(JSON.stringify(MysqlserverTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(mySqlServerObject.Category);
                catalogPage.clickConfigureButtonBasedOnName(mySqlServerObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(MysqlserverTemplate, modifiedParamMap);
                placeOrderPage.submitOrder();
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                inventoryPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                inventoryPage.clickViewService();
                //Checking Inventory Page Service Configuration
                expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                expect(inventoryPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(mySqlServerObject, "New Resource Group Required"));
                expect(inventoryPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
                expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Location"));
                expect(inventoryPage.getTextBasedOnLabelName("Server Name:")).toEqual(serverName);
                expect(inventoryPage.getTextBasedOnLabelName("Data Source:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Data Source"));
                expect(inventoryPage.getTextBasedOnLabelName("Server Location:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Server Location"));
                expect(inventoryPage.getTextBasedOnLabelName("Version:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Version"));
                expect(inventoryPage.getTextBasedOnLabelName("Compute + storage:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Compute + storage"));
                expect(inventoryPage.getTextBasedOnLabelName("Storage In GB:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Storage In GB"));
                expect(inventoryPage.getTextBasedOnLabelName("Storage-auto-growth:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Storage-auto-growth"));
                expect(inventoryPage.getTextBasedOnLabelName("Backup Retention Period:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Backup Retention Period"));
                expect(inventoryPage.getTextBasedOnLabelName("Backup Redundancy Options:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Backup Redundancy Options"));
                expect(inventoryPage.getTextBasedOnLabelName("Admin Username:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Admin Username"));
                expect(inventoryPage.getTextBasedOnLabelName("Allow Azure Service Access:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Allow Azure Service Access"));
                expect(inventoryPage.getTextBasedOnLabelName("Ssl Enforcement:")).toEqual(jsonUtil.getValue(mySqlServerObject, "Ssl Enforcement"));
                inventoryPage.closeViewDetailsTab();
                inventoryPage.clickNonEditableInstance();
                expect(inventoryPage.getTextForInvalidEditModal()).toEqual(MysqlserverTemplate.nonEditableText);
                inventoryPage.clickOnInvalidEditOkModal();
            });
        }
    }
});
