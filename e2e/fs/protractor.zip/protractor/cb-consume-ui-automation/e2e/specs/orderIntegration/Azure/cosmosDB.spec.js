/*
Spec_Name: cosmosDB.spec.js 
Description: This spec will cover E2E testing of Cosmos DB service order submit, approve, edit and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../../testData/appUrls.json'),
        util = require('../../../../helpers/util.js'),
        jsonUtil = require('../../../../helpers/jsonUtil.js'),
        OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        CDBTemplate = require('../../../../testData/OrderIntegration/Azure/CosmosDB.json');

describe('Azure - Cosmos DB Address', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, orderHistoryPage, catalogDetailsPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Database' };
        var modifiedParamMaped = {};
        var servicename = "AutoCDBsrv" + util.getRandomString(5);
        var rgName = "gslautotc_azureCDB-RG101" + util.getRandomString(5);
        var acName = "autoacname" + util.getRandomNumber(5);
        var SOIComponents, vnName;
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Account Name": acName };

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                orderHistoryPage = new OrderHistoryPage();
                catalogDetailsPage = new CatalogDetailsPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
                rgName = "gslautotc_azureCDB-RG101" + util.getRandomString(5);
                acName = "autoacname" + util.getRandomNumber(5);
                vnName = "autovnname" + util.getRandomNumber(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Account Name": acName, "Virtual Network Name": vnName };
                SOIComponents = [acName, vnName]
        });

        afterAll(function () {
                //Delete  CosmosDB.
                var returnObj = {};
                returnObj.servicename = servicename;
                returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                orderFlowUtil.approveDeletedOrder(returnObj);
                orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        });
        //E2E ExpressRoute Cosmos DB Address order Submit, Approve, Delete Service with New Resource Group.
        if (isProvisioningRequired == "true") {
                it('Azure: TC-T386570 Verify for Cosmos DB service, if create SQL with new Resource Group is working fine.', function () {
                        var orderObject = JSON.parse(JSON.stringify(CDBTemplate));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};
                        var returnObj1 = {};
                        orderFlowUtil.fillOrderDetails(CDBTemplate, modifiedParamMap);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Checking Inventory Page Service Configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnExactLabelName("New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Account Name:")).toContain(acName);
                        expect(inventoryPage.getTextBasedOnExactLabelName("Cosmos DB Location:")).toEqual(jsonUtil.getValue(orderObject, "Cosmos DB Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" API:")).toEqual(jsonUtil.getValue(orderObject, "API"));
                        expect(inventoryPage.getTextBasedOnLabelName("Capacity Mode:")).toEqual(jsonUtil.getValue(orderObject, "Capacity Mode"));
                        expect(inventoryPage.getTextBasedOnLabelName("Apply Free Tier Discount:")).toEqual(jsonUtil.getValue(orderObject, "Apply Free Tier Discount"));
                        expect(inventoryPage.getTextBasedOnExactLabelName("Paired Region Location:")).toEqual(jsonUtil.getValue(orderObject, "Paired Region Location"));
                        expect(inventoryPage.getTextBasedOnLabelName("Geo-Redundany:")).toEqual(jsonUtil.getValue(orderObject, "Geo-Redundany"));
                        expect(inventoryPage.getTextBasedOnLabelName("Multi-region Writes:")).toEqual(jsonUtil.getValue(orderObject, "Multi-region Writes"));
                        expect(inventoryPage.getTextBasedOnLabelName("Availability Zone:")).toEqual(jsonUtil.getValue(orderObject, "Availability Zone"));
                        expect(inventoryPage.getTextBasedOnLabelName("Connectivity Method:")).toEqual(jsonUtil.getValue(orderObject, "Connectivity Method"));
                        expect(inventoryPage.getTextBasedOnLabelName("Allow access from Azure Portal:")).toEqual(jsonUtil.getValue(orderObject, "Allow access from Azure Portal"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Configure Virtual Network:")).toEqual(jsonUtil.getValue(orderObject, "Configure Virtual Network"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Virtual Network Name:")).toEqual(vnName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Address Space:")).toEqual(jsonUtil.getValue(orderObject, "Address Space"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Subnet Name:")).toEqual(jsonUtil.getValue(orderObject, "Subnet Name"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Subnet Address Range:")).toEqual(jsonUtil.getValue(orderObject, "Subnet Address Range"));
                        expect(inventoryPage.getTextBasedOnLabelName("Backup policy:")).toEqual(jsonUtil.getValue(orderObject, "Backup policy"));
                        expect(inventoryPage.getTextBasedOnLabelName("Backup Interval Unit:")).toEqual(jsonUtil.getValue(orderObject, "Backup Interval Unit"));
                        expect(inventoryPage.getTextBasedOnLabelName("Backup Interval:")).toEqual(jsonUtil.getValue(orderObject, "Backup Interval"));
                        expect(inventoryPage.getTextBasedOnLabelName("Backup Retention Unit:")).toEqual(jsonUtil.getValue(orderObject, "Backup Retention Unit"));
                        expect(inventoryPage.getTextBasedOnLabelName("Backup Retention:")).toEqual(jsonUtil.getValue(orderObject, "Backup Retention"));
                        expect(inventoryPage.getTextBasedOnLabelName("Backup Up Storage:")).toEqual(jsonUtil.getValue(orderObject, "Backup Up Storage"));
                        expect(inventoryPage.getTextBasedOnLabelName("Data Encryption:")).toEqual(jsonUtil.getValue(orderObject, "Data Encryption"));
                        inventoryPage.closeViewDetailsTab();
                        //Checking SOI Components
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.clickExpandFirstRow().then(function () {
                                        browser.executeScript('window.scrollTo(0,0);');
                                        var i = 1;
                                        async.forEachSeries(SOIComponents, function (component, callback) {
                                                inventoryPage.clickOverMenuIcon(i).then(function () {
                                                        util.waitForAngular();
                                                        inventoryPage.clickOnViewComponent(i).then(function () {
                                                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                                                inventoryPage.closeViewComponent();
                                                                browser.sleep(10000);
                                                                i++;
                                                                return callback();
                                                        });
                                                })
                                        }, function (error) {
                                                if (error) {
                                                        logger.info('Unable to Get SOI component')
                                                }
                                        })
                                })
                        }
                        // edit order flow
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickEditServiceIcon();
                        modifiedParamMaped = { "Service Instance Name": servicename, "EditService": true };
                        orderFlowUtil.fillOrderDetails(CDBTemplate, modifiedParamMaped);
                        placeOrderPage.submitOrder();
                        returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj1.servicename = servicename;
                        //Open Order page and Approve Order 
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj1);
                        orderFlowUtil.waitForOrderStatusChange(returnObj1, "Completed", 50);
                });
        }

        //Checking parameters on Main Parameters page
        it('Azure: TC-T386558 verify that for Cosmos DB Address Service all parameters on Main Parameters Page are present.', function () {
                var orderObject = JSON.parse(JSON.stringify(CDBTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
                if (browser.params.defaultCurrency == "USD") {
                expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
                }
        });

        //Checking values of all parameters on Review Order Page and View Order Details
        it('Azure: TC-T386560 verify that for Cosmos DB Address Service all values on Review Order Details and View Order Details page matches with input.', function () {
                var returnObj = {};
                returnObj.servicename = servicename;
                var orderObject = JSON.parse(JSON.stringify(CDBTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.searchForBluePrint(orderObject.bluePrintName);
                catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(CDBTemplate, modifiedParamMap);
                //Checking Service Details in ReviewOrder
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
                if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
                }
                //Checking Additional Details in ReviewOrder
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Account Name:")).toEqual(acName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Cosmos DB Location:")).toEqual(jsonUtil.getValue(orderObject, "Cosmos DB Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" API:")).toEqual(jsonUtil.getValue(orderObject, "API"));
                expect(placeOrderPage.getTextBasedOnLabelName("Capacity Mode:")).toEqual(jsonUtil.getValue(orderObject, "Capacity Mode"));
                expect(placeOrderPage.getTextBasedOnLabelName("Apply Free Tier Discount:")).toEqual(jsonUtil.getValue(orderObject, "Apply Free Tier Discount"));
                expect(placeOrderPage.getTextBasedOnLabelName("Paired Region Location:")).toEqual(jsonUtil.getValue(orderObject, "Paired Region Location"));
                expect(placeOrderPage.getTextBasedOnLabelName("Geo-Redundany:")).toEqual(jsonUtil.getValue(orderObject, "Geo-Redundany"));
                expect(placeOrderPage.getTextBasedOnLabelName("Multi-region Writes:")).toEqual(jsonUtil.getValue(orderObject, "Multi-region Writes"));
                expect(placeOrderPage.getTextBasedOnLabelName("Availability Zone:")).toEqual(jsonUtil.getValue(orderObject, "Availability Zone"));
                expect(placeOrderPage.getTextBasedOnLabelName("Connectivity Method:")).toEqual(jsonUtil.getValue(orderObject, "Connectivity Method"));
                expect(placeOrderPage.getTextBasedOnLabelName("Allow access from Azure Portal:")).toEqual(jsonUtil.getValue(orderObject, "Allow access from Azure Portal"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Configure Virtual Network:")).toEqual(jsonUtil.getValue(orderObject, "Configure Virtual Network"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Virtual Network Name:")).toEqual(vnName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Address Space:")).toEqual(jsonUtil.getValue(orderObject, "Address Space"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Subnet Name:")).toEqual(jsonUtil.getValue(orderObject, "Subnet Name"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Subnet Address Range:")).toEqual(jsonUtil.getValue(orderObject, "Subnet Address Range"));
                expect(placeOrderPage.getTextBasedOnLabelName("Backup policy:")).toEqual(jsonUtil.getValue(orderObject, "Backup policy"));
                expect(placeOrderPage.getTextBasedOnLabelName("Backup Interval Unit:")).toEqual(jsonUtil.getValue(orderObject, "Backup Interval Unit"));
                expect(placeOrderPage.getTextBasedOnLabelName("Backup Interval:")).toEqual(jsonUtil.getValue(orderObject, "Backup Interval"));
                expect(placeOrderPage.getTextBasedOnLabelName("Backup Retention Unit:")).toEqual(jsonUtil.getValue(orderObject, "Backup Retention Unit"));
                expect(placeOrderPage.getTextBasedOnLabelName("Backup Retention:")).toEqual(jsonUtil.getValue(orderObject, "Backup Retention"));
                expect(placeOrderPage.getTextBasedOnLabelName("Backup Up Storage:")).toEqual(jsonUtil.getValue(orderObject, "Backup Up Storage"));
                expect(placeOrderPage.getTextBasedOnLabelName("Data Encryption:")).toEqual(jsonUtil.getValue(orderObject, "Data Encryption"));
                placeOrderPage.submitOrder();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                ordersPage.open();
                ordersPage.searchOrderById(returnObj.orderNumber);
                ordersPage.clickFirstViewDetailsOrdersTable();
                //Checking Order Details in View order details
                expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(orderObject.servicename);//Checking Service Name
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
                //Checking Service Configuration Parameters
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
                expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Account Name")).toEqual(acName);
                expect(ordersPage.getTextBasedOnExactLabelName("Cosmos DB Location")).toEqual(jsonUtil.getValue(orderObject, "Cosmos DB Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("API")).toEqual(jsonUtil.getValue(orderObject, "API"));
                expect(ordersPage.getTextBasedOnExactLabelName("Capacity Mode")).toEqual(jsonUtil.getValue(orderObject, "Capacity Mode"));
                expect(ordersPage.getTextBasedOnExactLabelName("Apply Free Tier Discount")).toEqual(jsonUtil.getValue(orderObject, "Apply Free Tier Discount"));
                expect(ordersPage.getTextBasedOnExactLabelName("Paired Region Location")).toEqual(jsonUtil.getValue(orderObject, "Paired Region Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Geo-Redundany")).toEqual(jsonUtil.getValue(orderObject, "Geo-Redundany"));
                expect(ordersPage.getTextBasedOnExactLabelName("Multi-region Writes")).toEqual(jsonUtil.getValue(orderObject, "Multi-region Writes"));
                expect(ordersPage.getTextBasedOnExactLabelName("Availability Zone")).toEqual(jsonUtil.getValue(orderObject, "Availability Zone"));
                expect(ordersPage.getTextBasedOnExactLabelName("Connectivity Method")).toEqual(jsonUtil.getValue(orderObject, "Connectivity Method"));
                expect(ordersPage.getTextBasedOnExactLabelName("Allow access from Azure Portal")).toEqual(jsonUtil.getValue(orderObject, "Allow access from Azure Portal"));
                expect(ordersPage.getTextBasedOnExactLabelName("Configure Virtual Network")).toEqual(jsonUtil.getValue(orderObject, "Configure Virtual Network"));
                expect(ordersPage.getTextBasedOnExactLabelName("Virtual Network")).toEqual(jsonUtil.getValue(orderObject, "Virtual Network"));
                expect(ordersPage.getTextBasedOnExactLabelName("Virtual Network Name")).toEqual(vnName);
                expect(ordersPage.getTextBasedOnExactLabelName("Address Space")).toEqual(jsonUtil.getValue(orderObject, "Address Space"));
                expect(ordersPage.getTextBasedOnExactLabelName("Subnet Name")).toEqual(jsonUtil.getValue(orderObject, "Subnet Name"));
                expect(ordersPage.getTextBasedOnExactLabelName("Subnet Address Range")).toEqual(jsonUtil.getValue(orderObject, "Subnet Address Range"));
                expect(ordersPage.getTextBasedOnExactLabelName("Backup policy")).toEqual(jsonUtil.getValue(orderObject, "Backup policy"));
                expect(ordersPage.getTextBasedOnExactLabelName("Backup Interval Unit")).toEqual(jsonUtil.getValue(orderObject, "Backup Interval Unit"));
                expect(ordersPage.getTextBasedOnExactLabelName("Backup Interval")).toEqual(jsonUtil.getValue(orderObject, "Backup Interval"));
                expect(ordersPage.getTextBasedOnExactLabelName("Backup Retention Unit")).toEqual(jsonUtil.getValue(orderObject, "Backup Retention Unit"));
                expect(ordersPage.getTextBasedOnExactLabelName("Backup Retention")).toEqual(jsonUtil.getValue(orderObject, "Backup Retention"));
                expect(ordersPage.getTextBasedOnExactLabelName("Backup Up Storage")).toEqual(jsonUtil.getValue(orderObject, "Backup Up Storage"));
                expect(ordersPage.getTextBasedOnExactLabelName("Data Encryption")).toEqual(jsonUtil.getValue(orderObject, "Data Encryption"));
                //Checking Bill Of Material
                if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
                orderHistoryPage.open();
                orderHistoryPage.searchOrderById(returnObj.orderNumber);
                expect(orderHistoryPage.getTextEstimatedCostOrderHistory()).toBe(orderObject.EstimatedCost);
                }
        });
});
