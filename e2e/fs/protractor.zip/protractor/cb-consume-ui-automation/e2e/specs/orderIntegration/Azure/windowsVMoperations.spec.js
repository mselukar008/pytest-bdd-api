/*
Spec_Name: windowsVMoperations.spec.js 
Description: This spec will cover Operations Off, On and Reboot on Azure Windows Virtual Machine
Author: Atiksha Batra 
*/

"use strict";


var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    async = require('async'),
    EC = protractor.ExpectedConditions,
    operationGroupTemplate = require('../../../../testData/OrderIntegration/policy/operationGroup.json'),
    OperationsPolicy = require('../../../pageObjects/operationsPolicy.pageObject.js'),
    PolicyPage = require('../../../pageObjects/policy.pageObject.js'),
    WVMTemplate = require('../../../../testData/OrderIntegration/Azure/windowsVMoperations.json'),
    operationPolicyTemplate = require('../../../../testData/OrderIntegration/policy/operationPolicy.json'),
    CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
    credentialJson = require('../../../../testData/credentials.json'),
    testEnvironment = browser.params.url;

describe('Azure - Windows Virtual Machine Operations', function () {
    var diskName;
    var ordersPage, catalogPage, inventoryPage, placeOrderPage;
    var messageStrings = {
        providerName: 'Azure', category: 'Compute', catalogPageTitle: 'Search, Select and Configure',
        orderSubmittedConfirmationMessage: WVMTemplate.orderSubmittedConfirmationMessage,
        provInProgressState: WVMTemplate.provInProgressState,
        completedState: WVMTemplate.completedState,
        powerStateOff: WVMTemplate.powerStateOff,
        powerStateOn: WVMTemplate.powerStateOn,
        orderTypeAction: WVMTemplate.orderTypeAction,
        turnOnNegativeWarning: WVMTemplate.turnOnNegativeWarning,
        turnOffNegativeWarning: WVMTemplate.turnOffNegativeWarning,
        rebootNegativeWarning: WVMTemplate.rebootNegativeWarning,
        turnOn: WVMTemplate.turnOn,
        turnOff: WVMTemplate.turnOff,
        reboot: WVMTemplate.reboot
    };
    var modifiedParamMap = {};
    var modifiedParamMapedit = {};
    var newResourceGroupName, newVmName, newNetworkName, newSubnetName, newNetworkInterfaceName, newnetworkSecurityGroupName, newPublicIpName, newAvailabilitySetName, computeComponent;
    var servicename = "WMService" + util.getRandomString(5);
    newResourceGroupName = "gslautotc_azure_winvmRG" + util.getRandomString(4);
    var SOIComponents;
    var returnObj = {};
    returnObj.servicename = servicename;
    var operationGroupName, approvalPolicyPage, operationPolicyPage, operationPolicyName, cartListPage;
    var modifiedParamMapOperationGroup = {};
    var modifiedParamMapOperationPolicy = {};
    operationGroupName = "automationGroupPolicy" + util.getRandomString(5);
    operationPolicyName = "autoOperationPolicy" + util.getRandomString(5);
    modifiedParamMapOperationGroup = { "Name": operationGroupName, "Operation": [" Turn OFF (Azure) "] };
    modifiedParamMapOperationPolicy = { "policy Name": operationPolicyName, "Team": ["TeamOperatorUser (my_org)"], "Operation Group": [operationGroupName] };
    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
        operationPolicyPage = new OperationsPolicy();
        approvalPolicyPage = new PolicyPage();
        cartListPage = new CartListPage();
    });

    beforeEach(function () {
        newResourceGroupName = "gslautotc_azure_winvmRG" + util.getRandomString(4);
        newVmName = "auto-VM" + util.getRandomString(4);
        newNetworkName = "auto-VN101" + util.getRandomString(4);
        newSubnetName = "auto-SN101" + util.getRandomString(4);
        newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
        newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
        newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
        newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
        diskName = "autodisk" + util.getRandomString(4);
        diskName = diskName.toLocaleLowerCase();
        computeComponent = "shutdown-computevm-" + newVmName;
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Disk Name": diskName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName };
        SOIComponents = [newNetworkName, newNetworkInterfaceName, newnetworkSecurityGroupName, newPublicIpName, computeComponent, diskName, newVmName];
    });

    afterAll(async function () {
        // cartListPage.clickUserIcon();
        // cartListPage.clickLogoutButton();
       await  cartListPage.loginFromOtherUser(credentialJson.superUserID, credentialJson.superUserPassword);
        //Deleting the operation policy
        operationPolicyPage.open();
        // operationPolicyPage.clickOperationPolicyTab();
        operationPolicyPage.searchOperationGroup(operationPolicyName);
        approvalPolicyPage.clickPolicyDetailIcon();
        approvalPolicyPage.clickPolicyViewDetailButton();
        util.waitForAngular();
        operationPolicyPage.clickOperationPolicyRetiredOption();
        operationPolicyPage.clickOnUpdateButtonOfOperationGroup();

        approvalPolicyPage.searchPolicyInPolicyTextbox(operationPolicyName);
        approvalPolicyPage.clickPolicyDetailIcon();
        approvalPolicyPage.clickButtonDeletePolicyText();
        operationPolicyPage.clickDeleteConfirmationPopUpApprovalPolicyBtn();

        //Delete the operation group
        operationPolicyPage.openOperationGroup();
        operationPolicyPage.searchOperationGroup(operationGroupName);
        util.waitForAngular();
        operationPolicyPage.clickOnTheActionOverflowMenuIconOfOperationPolicyGroup();
        operationPolicyPage.deleteOperationGroup();

        //Delete Windows VM

        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Provisioning in Progress');
    });


    if (isProvisioningRequired == "true") {
        it('Azure: TC-T374437-Sanity Verify if VM created with new RG,OS Publisher-Server,OS-DC,VM Size-BasicA0, new VN and Subnet, new NSG , new Public IP,AV-No,Boot-Enabled, new DSA', function () {
            var returnObj = {};
            returnObj.servicename = servicename;
            var newWindowsVMObject = JSON.parse(JSON.stringify(WVMTemplate));
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(newWindowsVMObject.Category);
            catalogPage.searchForBluePrint(newWindowsVMObject.bluePrintName);
            catalogPage.clickConfigureButtonBasedOnName(newWindowsVMObject.bluePrintName);
            var returnObj1 = {};
            orderFlowUtil.fillOrderDetails(WVMTemplate, modifiedParamMap);

            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState, 100);

            //Checking SOI Components
            if (isDummyAdapterDisabled == "true") {
                inventoryPage.clickExpandFirstRow().then(function () {
                    browser.executeScript('window.scrollTo(0,0);');
                    var i = 1;
                    async.forEachSeries(SOIComponents, function (component, callback) {
                        browser.executeScript('window.scrollTo(0,0);');
                        util.waitForAngular();
                        inventoryPage.clickOverMenuIcon(i).then(function () {
                            inventoryPage.clickOnViewComponent(i).then(function () {
                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                expect(inventoryPage.getTagsOnInventory()).toContain(newWindowsVMObject.mcmpTag);
                                expect(inventoryPage.getTagsOnInventory()).toContain(newWindowsVMObject.bluePrintName);
                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                //expect(inventoryPage.getTagsOnInventory()).toContain(newResourceGroupName);
                                inventoryPage.closeViewComponent();
                                browser.sleep(10000);
                                i++;
                                return callback();

                            });
                        })
                    }, function (error) {
                        if (error) {
                            logger.info('Unable to Get SOI component')
                        }
                    })
                })

                // edit flow actual adapter
                element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                inventoryPage.clickEditServiceIcon();

                inventoryPage.clickNextButton();

                modifiedParamMapedit = { "Service Instance Name": servicename, "Network Security Group Name": newnetworkSecurityGroupName, "EditService": true };


                orderFlowUtil.fillOrderDetails(WVMTemplate, modifiedParamMapedit);
                placeOrderPage.submitOrder();

                returnObj1.servicename = servicename;
                returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                //Open Order page and Approve Order 
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);

                placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(returnObj1);
                orderFlowUtil.waitForOrderStatusChange(returnObj1, messageStrings.completedState, 50);
            }
        });


        it('Azure: TC-C182590-Sanity Verify for Windows VM that on SOI VM is able to stop a running VM successfully', function () {
            var returnObj = {};
            returnObj.servicename = servicename;
            catalogPage.open();
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {
                    browser.executeScript('window.scrollTo(0,0);');
                    util.waitForAngular();
                    inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.azClickTurnOFFButtonOfInstance().then(function () {
                            inventoryPage.clickOkForInstanceTurnOFFPermission();
                            util.waitForAngular();
                        });
                    });
                }
                else {
                    if(testEnvironment.includes('release'))
                    {
    
                       inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.azClickTurnONButtonDummyOfInstance().then(function () {
                            inventoryPage.clickOkForInstanceTurnOFFPermission();
                            util.waitForAngular();
                        });
                    });
                }
                else
                {
                    inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.azClickTurnOFFButtonDummyOfInstance().then(function () {
                            inventoryPage.clickOkForInstanceTurnOFFPermission();
                            util.waitForAngular();
                        })
                    })
                }
                   
                }
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderTypeCustomOps(returnObj)).toBe(messageStrings.orderTypeAction);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.turnOff);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.getInstancePowerStateStatusAzure(returnObj).then(function(status){
                        if(status !== "Off"){
                            browser.refresh(); //refreshing browser to check updated vm status
                            util.waitForAngular();
                            inventoryPage.open();
                            inventoryPage.searchOrderByServiceName(returnObj.servicename);
                            inventoryPage.clickExpandFirstRow();
                        }
                        if (isDummyAdapterDisabled == "true") {
                            expect(inventoryPage.getInstancePowerStateStatusAzure(returnObj)).toContain(messageStrings.powerStateOff);
                        }
                        else {
                            expect(inventoryPage.getInstancePowerStateStatusAzure(returnObj)).toContain(WVMTemplate.powerStateOffDummy);
                        }
                    });
                });
            });
        });
        it('Azure: Verify for Virtual machine, when VM is turned OFF,', function () {
            var returnObj = {};
            returnObj.servicename = servicename;
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {
                    browser.executeScript('window.scrollTo(0,0);');
                    util.waitForAngular();
                    inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.azClickTurnOFFButtonOfInstance().then(function () {
                            //inventoryPage.placeD2opsOrder();
                            expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOffNegativeWarning);
                            inventoryPage.clickCustomOpsWarningOKButton()
                        });
                    });
                }
                else {
                    if(testEnvironment.includes('release'))
                    {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                            util.waitForAngular();
                            browser.executeScript('window.scrollTo(0,0);');
                            inventoryPage.azClickTurnONButtonDummyOfInstance().then(function () {
                                //inventoryPage.placeD2opsOrder();
                                expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(WVMTemplate.turnOffNegativeWarningDummy);
                                inventoryPage.clickCustomOpsWarningOKButton()
                            });
                        });
                    }
                    else
                    {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                            browser.executeScript('window.scrollTo(0,0);');
                            inventoryPage.azClickTurnOFFButtonDummyOfInstance().then(function () {
                                //inventoryPage.placeD2opsOrder();
                                expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(WVMTemplate.turnOffNegativeWarningDummy);
                                inventoryPage.clickCustomOpsWarningOKButton()
                            });
                        });
                    }
                    
                }
            })
        });
        it('Azure:  Negative Scenario ---- Reboot the instance when the VM state is OFF', function () {

            var returnObj = {};
            returnObj.servicename = servicename;
         inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {
                    browser.executeScript('window.scrollTo(0,0);');
                    util.waitForAngular();
                    inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
                        inventoryPage.azClickRebootButtonOfInstance().then(function () {
                            //inventoryPage.placeD2opsOrder();
                            expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.rebootNegativeWarning);
                            inventoryPage.clickCustomOpsWarningOKButton();
                        });
                    });
                }
                else {
                    browser.executeScript('window.scrollTo(0,0);');
                    inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                        inventoryPage.azClickRebootButtonDummyOfInstance().then(function () {
                            //inventoryPage.placeD2opsOrder();
                            expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(WVMTemplate.rebootNegativeWarningDummy);
                            inventoryPage.clickCustomOpsWarningOKButton();
                        });
                    });
                }
            });
        });


        it('Azure: TC-C204051-Sanity Verify for Windows VM that on SOI VM is able to start a stopped VM successfully', function () {
           
            var returnObj = {};
            returnObj.servicename = servicename;
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {
                    browser.executeScript('window.scrollTo(0,0);');
                    util.waitForAngular();
                    inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
                        inventoryPage.azClickTurnONButtonOfInstance().then(function () {
                            inventoryPage.clickOkForInstanceTurnONPermission();
                            util.waitForAngular();
                        });
                    });
                }
                else {
                    if(testEnvironment.includes('release'))
                    {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                            inventoryPage.azClickTurnOFFButtonDummyOfInstance().then(function () {
                                inventoryPage.clickOkForInstanceTurnONPermission();
                                util.waitForAngular();
                            });
                        });
                    }
                    else
                    {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                            inventoryPage.azClickTurnONButtonDummyOfInstance().then(function () {
                                inventoryPage.clickOkForInstanceTurnONPermission();
                                util.waitForAngular();
                            });
                        });

                    }
                   

                }
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderTypeCustomOps(returnObj)).toBe(messageStrings.orderTypeAction);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.turnOn);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    //expect(inventoryPage.getInstancePowerStateStatusAzure(returnObj)).toContain(messageStrings.powerStateOn);
                    inventoryPage.getInstancePowerStateStatusAzure(returnObj).then(function(status){
                        console.log("CustomOpsStatus:" + status);
                        if(status !== "On"){
                            browser.refresh(); //refreshing browser to check updated vm status
                            util.waitForAngular();
                            inventoryPage.open();
                            inventoryPage.searchOrderByServiceName(returnObj.servicename);
                            inventoryPage.clickExpandFirstRow();
                        }
                        expect(inventoryPage.getInstancePowerStateStatusAzure(returnObj)).toContain(messageStrings.powerStateOn);
                    });
                });
            });
        });

        it('Azure: Turn ON the instance when the VM state is ON', function () {
            var returnObj = {};
            returnObj.servicename = servicename;
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {
                    browser.executeScript('window.scrollTo(0,0);');
                    util.waitForAngular();
                    inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
                        inventoryPage.azClickTurnONButtonOfInstance().then(function () {
                            //inventoryPage.placeD2opsOrder();
                            expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOnNegativeWarning);
                            inventoryPage.clickCustomOpsWarningOKButton();
                        });
                    });
                }
                else {
                    if(testEnvironment.includes('release'))
                    {
                        browser.executeScript('window.scrollTo(0,0);');
                        util.waitForAngular();
                        inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                            inventoryPage.azClickTurnOFFButtonDummyOfInstance().then(function () {
                                //inventoryPage.placeD2opsOrder();
                                expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOnNegativeWarning);
                                inventoryPage.clickCustomOpsWarningOKButton();
    
                            });
                        });
                    }
                    else
                    {
                        browser.executeScript('window.scrollTo(0,0);');
                    inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                        inventoryPage.azClickTurnONButtonDummyOfInstance().then(function () {
                            //inventoryPage.placeD2opsOrder();
                            expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOnNegativeWarning);
                            inventoryPage.clickCustomOpsWarningOKButton();

                        });
                    });

                    }
                    
                }
            })
        })
        it('Azure: TC-C204052-Sanity Verify for Windows VM that on SOI VM is able to reboot a VM successfully', function () {
            var returnObj = {};
            returnObj.servicename = servicename;
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {
                    browser.executeScript('window.scrollTo(0,0);');
                    util.waitForAngular();
                    inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
                        inventoryPage.azClickRebootButtonOfInstance().then(function () {
                            inventoryPage.clickOkForInstanceTurnONPermission();
                            util.waitForAngular();
                        });
                    });
                }
                else {
                    browser.executeScript('window.scrollTo(0,0);');
                    inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                        inventoryPage.azClickRebootButtonDummyOfInstance().then(function () {
                            inventoryPage.clickOkForInstanceTurnONPermission();
                            util.waitForAngular();
                        });
                    });
                }
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderTypeCustomOps(returnObj)).toBe(messageStrings.orderTypeAction);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.reboot);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    expect(inventoryPage.getInstancePowerStateStatusAzure(returnObj)).toContain(messageStrings.powerStateOn);
                });
            });
        });

    }

    it("Create the operation Group", function () {

        operationPolicyPage.open();
        operationPolicyPage.openOperationGroup();

        //Create a operation group
        operationPolicyPage.clickNewOperationGroupButton();
        approvalPolicyPage.fillPolicyDetails(operationGroupTemplate, modifiedParamMapOperationGroup);
        operationPolicyPage.clickOnAddOperationGroupButton();

    })

    it("Create the operation policy",async function () {
        operationPolicyPage.closeOperationGroupSliderIfPresent();
        operationPolicyPage.open();
        operationPolicyPage.clickOperationPolicyTab();
        operationPolicyPage.clickAddOperationPolicyButton();
        approvalPolicyPage.fillPolicyDetails(operationPolicyTemplate, modifiedParamMapOperationPolicy);
        approvalPolicyPage.clickCreatePolicyButton();
        // cartListPage.clickUserIcon();
        // cartListPage.clickLogoutButton();
        await cartListPage.loginFromOtherUser(credentialJson.operatorID, credentialJson.operatorUserPass);
    })

    it("e2e flow of Stardard operation with operation Policy applied", function () {

        var returnObj = {};
        returnObj.servicename = servicename;
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(returnObj.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            if (isDummyAdapterDisabled == "true") {
                inventoryPage.clickOverflowActionButtonForPowerStatesAz();
            }
            else {
                inventoryPage.clickOverflowActionButtonFisrtComponent();
            }
        }).then(async function () {
            expect(inventoryPage.isTurnOFFButtonPresent()).toBe(true);
            expect(inventoryPage.isTurnONButtonPresent()).toBeFalsy();
            expect(inventoryPage.isRebootButtonPresent()).toBeFalsy();
            inventoryPage.clickTurnOFFButtonOfInstance();
            inventoryPage.clickOkForInstanceTurnOFFPermission();
            util.waitForAngular();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            await cartListPage.loginFromOtherUser(credentialJson.superUserID, credentialJson.superUserPassword);
            orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(returnObj)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.turnOff);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.getInstancePowerStateStatusAzure(returnObj).then(function(status){
                    if(status !== "Off"){
                        browser.refresh(); //refreshing browser to check updated vm status
                        util.waitForAngular();
                        inventoryPage.open();
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        inventoryPage.clickExpandFirstRow();
                    }
                    if (isDummyAdapterDisabled == "true") {
                        expect(inventoryPage.getInstancePowerStateStatusAzure(returnObj)).toContain(messageStrings.powerStateOff);
                    }
                    else {
                        expect(inventoryPage.getInstancePowerStateStatusAzure(returnObj)).toContain(WVMTemplate.powerStateOffDummy);
                    }
                });
            });
            
        })

    })
});