/*************************************************
Spec_Name: virtualPrivateCloud.spec.js
Description: This spec will cover E2E testing of Virtual Private Cloud service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".     
**************************************************/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    vpcTemplate = require('../../../../testData/OrderIntegration/Alibaba/VirtualPrivateCloud.json')

describe('Alibaba: Test cases for Virtual Private Cloud', function () {
    var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage, homePage;
    var modifiedParamMap = {};
    var modifiedParamMapedit = {};
    var messageStrings = {
        providerName: 'Alibaba Cloud',
        category: 'Network'
    };
    var servicename = "Gsl-Auto-VPC" + util.getRandomString(5);

    beforeAll(function () {
        homePage = new HomePage();
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        modifiedParamMap = {
            "Service Instance Name": servicename,
        };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });
    
    afterAll(function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    if (isProvisioningRequired == "true") {
        it('Aalibaba: TC-1 VPC -Verify Inventory / output parameters Details', function () {
            var modifiedParamMapEditForNegativeScenario = {
                "EditService": true,
                "UpdateMainParamObject": false
            };
            var returnObj = {};
            var returnObjForEdit = {};
            var editServiceObj = JSON.parse(JSON.stringify(vpcTemplate.negativeScenarioForEditService));
            var orderObject = JSON.parse(JSON.stringify(vpcTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            orderFlowUtil.fillOrderDetails(vpcTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, orderObject.OrderStatus);

            //checking order on Inventory Page 
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();

            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
            expect(inventoryPage.getTextBasedOnLabelName(" VPC Name:")).toEqual(jsonUtil.getValue(orderObject, "VPC Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" CIDR Block Option:")).toEqual(jsonUtil.getValue(orderObject, "CIDR Block Option"));
            expect(inventoryPage.getTextBasedOnLabelName(" Existing CIDR Block VPC:")).toEqual(jsonUtil.getValue(orderObject, "Existing CIDR Block VPC"));
            expect(inventoryPage.getTextBasedOnLabelName(" VPC Description:")).toEqual(jsonUtil.getValue(orderObject, "VPC Description"));
            expect(inventoryPage.getTextBasedOnLabelName(" Vswitch Name:")).toEqual(jsonUtil.getValue(orderObject, "Vswitch Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Zone Id:")).toEqual(jsonUtil.getValue(orderObject, "Zone Id"));
            expect(inventoryPage.getTextBasedOnLabelName(" CIDR Block Vswitch:")).toEqual(jsonUtil.getValue(orderObject, "CIDR Block Vswitch"));
            expect(inventoryPage.getTextBasedOnLabelName(" Vswitch Description:")).toEqual(jsonUtil.getValue(orderObject, "Vswitch Description"));
            inventoryPage.closeViewDetailsTab();

            //Edit order flow
            modifiedParamMapedit = {
                "EditService": true,
                "UpdateMainParamObject": false
            };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickEditServiceIcon();
            inventoryPage.clickNextButton();
            orderFlowUtil.fillOrderDetails(editServiceObj, modifiedParamMapEditForNegativeScenario);
            placeOrderPage.EditsubmitOrder();
            placeOrderPage.clickOnNotificationCloseButton();
            placeOrderPage.clickPreviousButton();
            placeOrderPage.clickPreviousButton();
            placeOrderPage.clickPreviousButton();
            placeOrderPage.clickPreviousButton();
            orderFlowUtil.fillOrderDetails(vpcTemplate, modifiedParamMapedit);
            placeOrderPage.submitOrder();
            returnObjForEdit.servicename = servicename;
            returnObjForEdit.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObjForEdit.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
            expect(orderFlowUtil.verifyOrderType(returnObjForEdit)).toBe('EditSOI');
            orderFlowUtil.approveOrder(returnObjForEdit);
            orderFlowUtil.waitForOrderStatusChange(returnObjForEdit, 'Completed', 50);
        });
    }

    it('Aalibaba: TC-2 verify that for Virtual Private Cloud Service all parameters on catlog Details page / main parameters are present.', function () {
        var orderObject = JSON.parse(JSON.stringify(vpcTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);

        expect(catalogDetailsPage.getServiceName()).toBe(orderObject.bluePrintName)
        expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true);
        expect(catalogDetailsPage.isPresentLinkToProviderSite()).toBe(true);
        expect(catalogDetailsPage.isPresentFeaturesLabel()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsLabel()).toBe(true);
        expect(catalogDetailsPage.getTextFeaturesLabel()).toBe(orderObject.FeaturesLabel);
        expect(catalogDetailsPage.getTextDetailsLabel()).toBe(orderObject.DetailsLabel);
        expect(catalogDetailsPage.isPresentFeaturesInfo()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsInfo()).toBe(true);
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);

        catalogDetailsPage.clickCatalogFromBreadCrumbNav();
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
        homePage.open();
    });

    it('Aalibaba: TC-3 verify that for Virtual Private Cloud Service all parameters on Review Order page matches with input.', function () {
        var orderObject = JSON.parse(JSON.stringify(vpcTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderObject.servicename = servicename;
        orderFlowUtil.fillOrderDetails(vpcTemplate, modifiedParamMap);

        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(orderObject.servicename);
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);

        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(placeOrderPage.getTextBasedOnLabelName(" VPC Name:")).toEqual(jsonUtil.getValue(orderObject, "VPC Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" CIDR Block Option:")).toEqual(jsonUtil.getValue(orderObject, "CIDR Block Option"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Existing CIDR Block VPC:")).toEqual(jsonUtil.getValue(orderObject, "Existing CIDR Block VPC"));
        expect(placeOrderPage.getTextBasedOnLabelName(" VPC Description:")).toEqual(jsonUtil.getValue(orderObject, "VPC Description"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Vswitch Name:")).toEqual(jsonUtil.getValue(orderObject, "Vswitch Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Zone Id:")).toEqual(jsonUtil.getValue(orderObject, "Zone Id"));
        expect(placeOrderPage.getTextBasedOnLabelName(" CIDR Block Vswitch:")).toEqual(jsonUtil.getValue(orderObject, "CIDR Block Vswitch"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Vswitch Description:")).toEqual(jsonUtil.getValue(orderObject, "Vswitch Description"));
        homePage.open();
    });

    it('Aalibaba: TC-4 verify that for Virtual Private Cloud Service all values on View Order Details page matches with input.', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(vpcTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(vpcTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();

        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);

        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("Region")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(ordersPage.getTextBasedOnExactLabelName("VPC Name")).toEqual(jsonUtil.getValue(orderObject, "VPC Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("CIDR Block Option")).toEqual(jsonUtil.getValue(orderObject, "CIDR Block Option"));
        expect(ordersPage.getTextBasedOnExactLabelName("Existing CIDR Block VPC")).toEqual(jsonUtil.getValue(orderObject, "Existing CIDR Block VPC"));
        expect(ordersPage.getTextBasedOnExactLabelName("VPC Description")).toEqual(jsonUtil.getValue(orderObject, "VPC Description"));
        expect(ordersPage.getTextBasedOnExactLabelName("Vswitch Name")).toEqual(jsonUtil.getValue(orderObject, "Vswitch Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Zone Id")).toEqual(jsonUtil.getValue(orderObject, "Zone Id"));
        expect(ordersPage.getTextBasedOnExactLabelName("CIDR Block Vswitch")).toEqual(jsonUtil.getValue(orderObject, "CIDR Block Vswitch"));
        expect(ordersPage.getTextBasedOnExactLabelName("Vswitch Description")).toEqual(jsonUtil.getValue(orderObject, "Vswitch Description"));

        //Checking Bill Of Material
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(placeOrderPage.getTotalCost()).toBe(orderObject.TotalCost);

        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
        orderFlowUtil.denyOrder(returnObj);
    });
});