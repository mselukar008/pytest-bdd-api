/*
Spec_Name: managedDisk.spec.js 
Description: This spec will cover E2E testing of Managed Disks service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../../testData/appUrls.json'),
        util = require('../../../../helpers/util.js'),
        jsonUtil = require('../../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        MDTemplate = require('../../../../testData/OrderIntegration/Azure/ManagedDisk.json');

describe('Azure - Managed Disk', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Storage' };
        var modifiedParamMap = {};
        var modifiedParamMapedit = {};
        var servicename = "AutoMDsrv" + util.getRandomString(5);
        var rgName = "gslautotc_azureMDRG101" + util.getRandomString(5);
        var diskName = "autodisk" + util.getRandomString(5);
        var SOIComponents;
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Managed Disk Name": diskName };

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                catalogDetailsPage = new CatalogDetailsPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
                rgName = "gslautotc_azureMDRG101" + util.getRandomString(5);
                diskName = "autodisk" + util.getRandomString(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Managed Disk Name": diskName };
                SOIComponents = [diskName]
        });

        afterAll(function () {
                // Delete Managed Disk
                var returnObj = {};
                returnObj.servicename = servicename;
                returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                orderFlowUtil.approveDeletedOrder(returnObj);
                orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        });

        //E2E ExpressRoute Managed Disk order Submit, Approve, Delete Service with New Resource Group.
        if (isProvisioningRequired == "true") {
                it('Azure: TC-T366912-Sanity Verify that for Managed Disk None(empty disk), Create new Disk with New Resource Group, Standard Account Type is successful.', function () {
                        var orderObject = JSON.parse(JSON.stringify(MDTemplate));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};
                        var returnObj1 = {};
                        orderFlowUtil.fillOrderDetails(MDTemplate, modifiedParamMap);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Checking Inventory Page Service Configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                        expect(inventoryPage.getTextBasedOnExactLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnExactLabelName("New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(inventoryPage.getTextBasedOnExactLabelName("Managed Disk Name:")).toEqual(diskName);
                        expect(inventoryPage.getTextBasedOnExactLabelName("Managed Disk Location:")).toEqual(jsonUtil.getValue(orderObject, "Managed Disk Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Account Type:")).toEqual(jsonUtil.getValue(orderObject, "Account Type"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Source Type:")).toEqual(jsonUtil.getValue(orderObject, "Source Type"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Provide Custom Disk Size:")).toEqual(jsonUtil.getValue(orderObject, "Provide Custom Disk Size"));
                        expect(inventoryPage.getTextBasedOnLabelName("Disk Size List In GB:")).toEqual(jsonUtil.getValue(orderObject, "Disk Size List In GB"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Availability Zone:")).toEqual(jsonUtil.getValue(orderObject, "Availability Zone"));
                        inventoryPage.closeViewDetailsTab();
                        //Checking SOI Components
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.clickExpandFirstRow().then(function () {
                                        browser.executeScript('window.scrollTo(0,0);');
                                        var i = 1;
                                        async.forEachSeries(SOIComponents, function (component, callback) {
                                                inventoryPage.clickOverMenuIcon(i).then(function () {
                                                        inventoryPage.clickOnViewComponent(i).then(function () {
                                                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.mcmpTag);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.bluePrintName);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(rgName);
                                                                inventoryPage.closeViewComponent();
                                                                browser.sleep(10000);
                                                                i++;
                                                                return callback();
                                                        });
                                                })
                                        }, function (error) {
                                                if (error) {
                                                        logger.info('Unable to Get SOI component')
                                                }
                                        })
                                })
                        }
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                        inventoryPage.clickEditServiceIcon();
                        browser.sleep(10000);
                        modifiedParamMapedit = { "Service Instance Name": servicename, "EditService": true };
                        orderFlowUtil.fillOrderDetails(MDTemplate, modifiedParamMapedit);
                        placeOrderPage.submitOrder();
                        returnObj1.servicename = servicename;
                        returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        //Open Order page and Approve Order 
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj1);
                        orderFlowUtil.waitForOrderStatusChange(returnObj1, "Completed", 50);
                });
        }

        //Checking parameters on Main Parameters page
        it('Azure: TC-T366901 verify that for Managed Disk Service all parameters on Main Parameters Page are present.', function () {
                var orderObject = JSON.parse(JSON.stringify(MDTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
                if (browser.params.defaultCurrency == "USD") {
                expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
                }
        });

        //Checking values all parameters on Review Order Page and View Order Details
        it('Azure: TC-T366903 verify that for Managed Disk Service all values on Review Order Page and View Order Details page matches with input.', function () {
                var returnObj = {};
                returnObj.servicename = servicename;
                var orderObject = JSON.parse(JSON.stringify(MDTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(MDTemplate, modifiedParamMap);
                //Checking Service Details in ReviewOrder
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
                if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
                }
                //Checking Additional Details in ReviewOrder
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Managed Disk Name:")).toEqual(diskName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Managed Disk Location:")).toEqual(jsonUtil.getValue(orderObject, "Managed Disk Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Account Type:")).toEqual(jsonUtil.getValue(orderObject, "Account Type"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Source Type:")).toEqual(jsonUtil.getValue(orderObject, "Source Type"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Provide Custom Disk Size:")).toEqual(jsonUtil.getValue(orderObject, "Provide Custom Disk Size"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Availability Zone:")).toEqual(jsonUtil.getValue(orderObject, "Availability Zone"));
                placeOrderPage.submitOrder();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                ordersPage.open();
                ordersPage.searchOrderById(returnObj.orderNumber);
                ordersPage.clickFirstViewDetailsOrdersTable();
                //Checking Order Details in View order details
                expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
                //Checking Service Configuration Parameters
                expect(ordersPage.getTextBasedOnLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
                expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(ordersPage.getTextBasedOnLabelName("Managed Disk Name")).toEqual(diskName);
                expect(ordersPage.getTextBasedOnLabelName("Managed Disk Location")).toEqual(jsonUtil.getValue(orderObject, "Managed Disk Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Account Type")).toEqual(jsonUtil.getValue(orderObject, "Account Type"));
                expect(ordersPage.getTextBasedOnExactLabelName("Source Type")).toEqual(jsonUtil.getValue(orderObject, "Source Type"));
                expect(ordersPage.getTextBasedOnExactLabelName("Provide Custom Disk Size")).toEqual(jsonUtil.getValue(orderObject, "Provide Custom Disk Size"));
                expect(ordersPage.getTextBasedOnExactLabelName("Disk Size List In GB")).toEqual(jsonUtil.getValue(orderObject, "Disk Size List In GB"));
                expect(ordersPage.getTextBasedOnExactLabelName("Availability Zone")).toEqual(jsonUtil.getValue(orderObject, "Availability Zone"));
                //Checking Bill Of Material
                if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
                }
                ordersPage.clickServiceDetailSliderCloseButton();
        });
});
