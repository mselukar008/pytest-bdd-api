"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	OrderHistoryPage = require('../../../../../pageObjects/ordersHistory.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	awsEC2template = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSEC2InstanceSnowV3SpecstoSkipIMI.json'),
	awsS3Temp = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSS3Snow.json'),
	shoppingCartTemplate   = require('../../../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json');
	
describe('QS: E2E cases for Homo cart with three AWS services and Auto approval with Normal change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, provOrder, cartListPage, orderHistoryPage, policyPage;
	var modifiedParamMapAWS1 = {};
	var modifiedParamMapAWS2 = {};
	var modifiedParamMapAWS3 = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var orderObject = {};
	var serviceName1 = "SNOWQSauto"+util.getRandomString(5);
	var serviceName2 = "SNOWQSauto"+util.getRandomString(5);
	var serviceName3 = "SNOWQSauto"+util.getRandomString(5);
	var policyName = "SNOWQSautoAWSPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWQSautoAWSPolicyRule"+util.getRandomString(5);
	var cartName = "SNOWQSautoCart" + util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var bucketName1 = "buckettestaut" + util.getRandomString(5);
	bucketName1 = bucketName1.toLowerCase();
	var bucketName2 = "buckettestaut" + util.getRandomString(5);
	bucketName2 = bucketName2.toLowerCase();
	var consumeLaunchpadUrl = url + '/launchpad';
	var awsEC2obj = JSON.parse(JSON.stringify(awsEC2template));
	var awsS3obj = JSON.parse(JSON.stringify(awsS3Temp));

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		orderHistoryPage = new OrderHistoryPage();
		policyPage = new PolicyPage();
		browser.driver.manage().window().maximize();
		
		//Delete policy if exists
		policyPage.open();
		util.waitForAngular();
		policyPage.deletePoliciesIfExist();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New"],"Provider":["Amazon"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":""};
		modifiedParamMapAWS1 = {"Service Instance Name":serviceName1, "Cart Name":cartName, "Cart Service":"checkbox-useShoppingCart", "New Shopping Cart":"newCart", "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "Provider Account":"AWS-SNOW / AWS-SNOW"};
		modifiedParamMapAWS2 = {"Service Instance Name":serviceName2, "Team":"", "Environment":"", "Application":"","Bucket Name":bucketName1};
		modifiedParamMapAWS3 = {"Service Instance Name":serviceName3, "Team":"", "Environment":"", "Application":"","Bucket Name":bucketName2}

	});
	
	afterAll(function() {
		browser.get(consumeLaunchpadUrl);
		policyPage.open();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		policyPage.clickRadioButtonRetiredOption();
		policyPage.clickUpdatePolicyBtn();
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickButtonDeletePolicyText();
		policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);

   
	});
	
	it('Set Change Request type to Normal in SNOW', function () {
		expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Auto Approval Policy for AWS provider', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('Place an order for Homo cart with three AWS services and Auto approval with Normal change', function () {
			
			//Add first AWS service to cart
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(awsEC2template.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(awsEC2template.Category);
			catalogPage.clickConfigureButtonBasedOnName(awsEC2template.bluePrintName);
			orderObject.servicename = serviceName1;
			orderFlowUtil.fillOrderDetails(awsEC2template, modifiedParamMapAWS1);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
	        
	        //Add second AWS service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(awsS3Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(awsS3Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(awsS3Temp.bluePrintName);
			orderObject.servicename = serviceName2;
			orderFlowUtil.fillOrderDetails(awsS3Temp, modifiedParamMapAWS2);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
	        
	        //Add third AWS service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(awsS3Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(awsS3Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(awsS3Temp.bluePrintName);
			orderObject.servicename = serviceName3;
			orderFlowUtil.fillOrderDetails(awsS3Temp, modifiedParamMapAWS3);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
			
			//Submit Order
			cartListPage.submitOrder(0);
	    	orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
	    	orderObject.submittedBy = cartListPage.getTextSubmittedByOrderSubmittedModal
	        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(shoppingCartTemplate.orderSubmittedConfirmationMessage);
	    	provOrder = cartListPage.getTextOrderNumberOrderSubmittedModal();
	        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
	        orderObject = {"orderNumber":provOrder};	
		
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
			expect(snowPage.getTextShortDescription()).toBe(cartName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
			expect(snowPage.getCountOfRITMlinks()).toBe(parseInt("3"));
		});
		
		it('Verify the First RITM for Provision functionality with Normal change', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
			var service = snowPage.getTextReqItemVariableServiceName();
			service.then(function(serviceName) {
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);					
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2obj, "Resource Name"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("Subnet")).toEqual("subnet-a68b538d");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("VPC")).toEqual("vpc-8eadd1eb");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2obj, "Shutdown Behavior"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2obj, "T2/T3 Unlimited"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2obj, "User Data"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));

					// Validate BOM values from Broker config values
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(serviceName, snowInstanceTemplate.snowAWSSrvcItemValueEC2)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(serviceName, snowInstanceTemplate.snowAWSSrvcItemValueEC2)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWS);
				}
				else {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsS3Temp.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowreqItemvariableSerOfferDescAWS3);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySt);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("versioning")).toEqual(jsonUtil.getValue(awsS3obj, "Versioning"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("server Access Logging")).toEqual(jsonUtil.getValue(awsS3obj, "Server Access Logging"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("static Website Hosting")).toEqual("Disable website hosting");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("default Encryption")).toEqual(jsonUtil.getValue(awsS3obj,"Default Encryption"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Transfer Acceleration")).toEqual(jsonUtil.getValue(awsS3obj, "Transfer Acceleration"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("access Control")).toEqual(jsonUtil.getValue(awsS3obj, "Access Control"));		

					// Validate BOM values from Broker config values
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(serviceName, snowInstanceTemplate.snowAWSSrvcItemValueS3)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(serviceName, snowInstanceTemplate.snowAWSSrvcItemValueS3)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWSS3);
				}
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Normal change
				snowPage.openRelatedChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
				snowPage.enterChangeReqValues();
				snowPage.enterPlanningValues();
				snowPage.enterScheduleValues();
				snowPage.clickCalculateRiskLink();
				snowPage.clickAssessButton();
				
				//Approvals in SNOW
				snowPage.clickRequestApprovalInChangeRequestPage();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveRequestQS();
				snowPage.approveRequestQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				snowPage.rightClickOnCMDBCIFormHeader();
				var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
				sysidofChangeRequest.then(function(sysidofChangeRequestValue){
				var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
				setChangeRequesttoImplementState.then(function(statuscode){
				expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
				});
			});
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.closeNotifySerDeskTask();
				snowPage.closeImplementTask();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(awsEC2template.completedState);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(awsEC2template.completedState);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(awsEC2template.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickBackButton();
	    });
	
		it('Verify the Second RITM for Provision functionality with Normal change', function () {
		
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
			var service = snowPage.getTextReqItemVariableServiceName();
			service.then(function(serviceName) {
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);					
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2obj, "Resource Name"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("Subnet")).toEqual("subnet-a68b538d");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("VPC")).toEqual("vpc-8eadd1eb");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2obj, "Shutdown Behavior"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2obj, "T2/T3 Unlimited"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2obj, "User Data"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));		

					// Validate BOM values from Broker config values
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(serviceName, snowInstanceTemplate.snowAWSSrvcItemValueEC2)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(serviceName, snowInstanceTemplate.snowAWSSrvcItemValueEC2)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWS);
				}
				else {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsS3Temp.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowreqItemvariableSerOfferDescAWS3);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySt);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("versioning")).toEqual(jsonUtil.getValue(awsS3obj, "Versioning"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("server Access Logging")).toEqual(jsonUtil.getValue(awsS3obj, "Server Access Logging"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("static Website Hosting")).toEqual("Disable website hosting");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("default Encryption")).toEqual(jsonUtil.getValue(awsS3obj,"Default Encryption"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Transfer Acceleration")).toEqual(jsonUtil.getValue(awsS3obj, "Transfer Acceleration"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("access Control")).toEqual(jsonUtil.getValue(awsS3obj, "Access Control"));		

					// Validate BOM values from Broker config values
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(serviceName, snowInstanceTemplate.snowAWSSrvcItemValueS3)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(serviceName, snowInstanceTemplate.snowAWSSrvcItemValueS3)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWSS3);
				}
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Normal change
				snowPage.openRelatedChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
				snowPage.enterChangeReqValues();
				snowPage.enterPlanningValues();
				snowPage.enterScheduleValues();
				snowPage.clickCalculateRiskLink();
				snowPage.clickAssessButton();
				
				//Approvals in SNOW
				snowPage.clickRequestApprovalInChangeRequestPage();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveRequestQS();
				snowPage.approveRequestQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				snowPage.rightClickOnCMDBCIFormHeader();
				var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
				sysidofChangeRequest.then(function(sysidofChangeRequestValue){
				var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
				setChangeRequesttoImplementState.then(function(statuscode){
				expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
				});
			});
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.closeNotifySerDeskTask();
				snowPage.closeImplementTask();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(awsEC2template.completedState);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(awsEC2template.completedState);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(awsEC2template.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickBackButton();
	    });
		
		it('Verify the Third RITM for Provision functionality with Normal change', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickThirdRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
			var service = snowPage.getTextReqItemVariableServiceName();
			service.then(function(serviceName) {
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);					
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2obj, "Resource Name"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("Subnet")).toEqual("subnet-a68b538d");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("VPC")).toEqual("vpc-8eadd1eb");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2obj, "Shutdown Behavior"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2obj, "T2/T3 Unlimited"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2obj, "User Data"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));	

					// Validate BOM values from Broker config values
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(serviceName, snowInstanceTemplate.snowAWSSrvcItemValueEC2)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(serviceName, snowInstanceTemplate.snowAWSSrvcItemValueEC2)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWS);
				}
				else {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsS3Temp.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowreqItemvariableSerOfferDescAWS3);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySt);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("versioning")).toEqual(jsonUtil.getValue(awsS3obj, "Versioning"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("server Access Logging")).toEqual(jsonUtil.getValue(awsS3obj, "Server Access Logging"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("static Website Hosting")).toEqual("Disable website hosting");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("default Encryption")).toEqual(jsonUtil.getValue(awsS3obj,"Default Encryption"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Transfer Acceleration")).toEqual(jsonUtil.getValue(awsS3obj, "Transfer Acceleration"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("access Control")).toEqual(jsonUtil.getValue(awsS3obj, "Access Control"));	
							
					// Validate BOM values from Broker config values
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(serviceName, snowInstanceTemplate.snowAWSSrvcItemValueS3)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(serviceName, snowInstanceTemplate.snowAWSSrvcItemValueS3)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWSS3);
				}
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Normal change
				snowPage.openRelatedChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
				snowPage.enterChangeReqValues();
				snowPage.enterPlanningValues();
				snowPage.enterScheduleValues();
				snowPage.clickCalculateRiskLink();
				snowPage.clickAssessButton();
				
				//Approvals in SNOW
				snowPage.clickRequestApprovalInChangeRequestPage();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveRequestQS();
				snowPage.approveRequestQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				snowPage.rightClickOnCMDBCIFormHeader();
				var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
				sysidofChangeRequest.then(function(sysidofChangeRequestValue){
				var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
				setChangeRequesttoImplementState.then(function(statuscode){
				expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
				});
			});
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.closeNotifySerDeskTask();
				snowPage.closeImplementTask();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(awsEC2template.completedState);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(awsEC2template.completedState);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(awsEC2template.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickThirdRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickBackButton();
			
			//Validations on SNOW Request page after Completion of all RITM's
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
	    });
	 }
	

});
	
	
	
	