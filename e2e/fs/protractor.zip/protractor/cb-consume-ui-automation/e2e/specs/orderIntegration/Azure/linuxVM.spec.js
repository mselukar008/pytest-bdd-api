/*
Spec_Name: linuxVM.spec.js 
Description: This spec will cover E2E testing of Linux VM service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    LVMTemplate = require('../../../../testData/OrderIntegration/Azure/newLinuxVM.json'),
    HostTemplate = require('../../../../testData/OrderIntegration/Azure/host.json');
    
describe('Azure - Linux Virtual Machine ', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, servicename, vmName1, SOIComponents;
    var diskName;
    var hostOrderObject = {};
    var modifiedParamMap = {};
    var modifiedParamMapedit = {};
    var modifiedParamMapHostService = {};
    var newResourceGroupName = "gslautotc_azureLVM-RG101" + util.getRandomString(4);
    var newVmName = "auto-VM101" + util.getRandomString(4);
    var newNetworkName = "auto-VN101" + util.getRandomString(4);
    var newSubnetName = "auto-SN101" + util.getRandomString(4);
    var newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
    var newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
    var newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
    var newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
    var hostName = "autoHost" + util.getRandomString(5);
    var hostGroupName = "hostGroupName" + util.getRandomString(5);
    var messageStrings = { providerName: 'Azure', category: 'Compute', templateName: 'Linux Virtual Machine' };
    var servicename = "AutoLVMsrv" + util.getRandomString(5);
    var servicenameHost = "GSLSLTestAutomationHost" + util.getRandomString(5);
    var newLinuxVMObject = JSON.parse(JSON.stringify(LVMTemplate.Scenario1));

    beforeAll(function () {
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();

    });

    afterAll(function () {
        if (isDummyAdapterDisabled == "false") {
            // Delete Linux VM
            var returnObj = {};
            returnObj.servicename = servicename;
            returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
            orderFlowUtil.approveDeletedOrder(returnObj);
            orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        }
        // if (isDummyAdapterDisabled == "true") {
        //      //deletion for host service
        //    var returnObjHost = {};
        //     returnObjHost.servicename = servicenameHost;
        //     returnObjHost.deleteOrderNumber = orderFlowUtil.deleteService(returnObjHost);
        //     orderFlowUtil.approveDeletedOrder(returnObjHost);
        //     orderFlowUtil.waitForDeleteOrderStatusChange(returnObjHost, 'Completed');
        //     expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObjHost)).toBe('Completed');
        // }
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        newResourceGroupName = "gslautotc_azureLVM-RG101" + util.getRandomString(4);
        newVmName = "auto-VM101" + util.getRandomString(4);
        newNetworkName = "auto-VN101" + util.getRandomString(4);
        newSubnetName = "auto-SN101" + util.getRandomString(4);
        newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
        newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
        newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
        newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
        diskName = "autodisk" + util.getRandomString(4);
        diskName = diskName.toLocaleLowerCase();
        SOIComponents = [newVmName, newNetworkName, newPublicIpName, newnetworkSecurityGroupName, newNetworkInterfaceName, newAvailabilitySetName, diskName]
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Disk Name": diskName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName, "UpdateMainParamObject": false };
    });

    it('Azure: TC-T388691 Verify that for Linux Virtual Machine Service all parameters on Main Parameters Page are present.', function () {
        var orderObject = JSON.parse(JSON.stringify(LVMTemplate.Scenario1));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.searchForBluePrint(orderObject.bluePrintName);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        if(browser.params.defaultCurrency == "USD"){
            expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
        }
    });

    it('Azure: TC-T388821 Verify Review order and View Order Details for Linux Virtual Machine Service', function () {
        var orderObject = {};
        orderObject.servicename = servicename;
        newLinuxVMObject = JSON.parse(JSON.stringify(LVMTemplate.Scenario1));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(newLinuxVMObject.Category);
        catalogPage.searchForBluePrint(newLinuxVMObject.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(newLinuxVMObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(LVMTemplate.Scenario1, modifiedParamMap).then(function (requiredReturnMap) {
            //Verify input values on Review Order page            
            expect(requiredReturnMap["Actual"]["New Resource Group Required"]).toEqual(requiredReturnMap["Expected"]["New Resource Group Required"]);
            expect(requiredReturnMap["Actual"]["New Resource Group"]).toEqual(requiredReturnMap["Expected"]["New Resource Group"]);
            expect(requiredReturnMap["Actual"]["Location"]).toEqual(requiredReturnMap["Expected"]["Location"]);
            expect(requiredReturnMap["Actual"]["Virtual Machine Name"]).toEqual(requiredReturnMap["Expected"]["Virtual Machine Name"]);
            expect(requiredReturnMap["Actual"]["Virtual Machine Location"]).toEqual(requiredReturnMap["Expected"]["Virtual Machine Location"]);
            expect(requiredReturnMap["Actual"]["Proximity Placement Group"]).toEqual(requiredReturnMap["Expected"]["Proximity Placement Group"]);
            expect(requiredReturnMap["Actual"]["Username"]).toEqual(requiredReturnMap["Expected"]["Username"]);
            expect(requiredReturnMap["Actual"]["Availability Options"]).toEqual(requiredReturnMap["Expected"]["Availability Options"]);
            expect(requiredReturnMap["Actual"]["Operating System Image"]).toEqual(requiredReturnMap["Expected"]["Operating System Image"]);
            expect(requiredReturnMap["Actual"]["Vm Generation"]).toEqual(requiredReturnMap["Expected"]["Vm Generation"]);
            expect(requiredReturnMap["Actual"]["Use Managed Disk"]).toEqual(requiredReturnMap["Expected"]["Use Managed Disk"]);
            expect(requiredReturnMap["Actual"]["Use Ephemeral OS Disk"]).toEqual(requiredReturnMap["Expected"]["Use Ephemeral OS Disk"]);
            expect(requiredReturnMap["Actual"]["OS Disk Type"]).toEqual(requiredReturnMap["Expected"]["OS Disk Type"]);
            expect(requiredReturnMap["Actual"]["Data Disk"]).toEqual(requiredReturnMap["Expected"]["Data Disk"]);
            expect(requiredReturnMap["Actual"]["Logical Unit Number (LUN)"]).toEqual(requiredReturnMap["Expected"]["Logical Unit Number (LUN)"]);
            expect(requiredReturnMap["Actual"]["Disk Name"]).toEqual(requiredReturnMap["Expected"]["Disk Name"]);
            expect(requiredReturnMap["Actual"]["Storage Type : Ultra Disk:"]).toEqual(requiredReturnMap["Expected"]["Storage Type : Ultra Disk:"]);
            expect(requiredReturnMap["Actual"]["Source Type"]).toEqual(requiredReturnMap["Expected"]["Source Type"]);
            expect(requiredReturnMap["Actual"]["Storage Type"]).toEqual(requiredReturnMap["Expected"]["Storage Type"]);
            expect(requiredReturnMap["Actual"]["Provide Custom Disk Size"]).toEqual(requiredReturnMap["Expected"]["Provide Custom Disk Size"]);
            expect(requiredReturnMap["Actual"]["Host Caching"]).toEqual(requiredReturnMap["Expected"]["Host Caching"]);
            expect(requiredReturnMap["Actual"]["Virtual Network Required"]).toEqual(requiredReturnMap["Expected"]["Virtual Network Required"]);
            expect(requiredReturnMap["Actual"]["Virtual Network Name"]).toEqual(requiredReturnMap["Expected"]["Virtual Network Name"]);
            expect(requiredReturnMap["Actual"]["Address Prefix"]).toEqual(requiredReturnMap["Expected"]["Address Prefix"]);
            expect(requiredReturnMap["Actual"]["Subnet Name"]).toEqual(requiredReturnMap["Expected"]["Subnet Name"]);
            expect(requiredReturnMap["Actual"]["Subnet Prefix"]).toEqual(requiredReturnMap["Expected"]["Subnet Prefix"]);
            expect(requiredReturnMap["Actual"]["Network Interface Name"]).toEqual(requiredReturnMap["Expected"]["Network Interface Name"]);
            expect(requiredReturnMap["Actual"]["Network Security Group Name"]).toEqual(requiredReturnMap["Expected"]["Network Security Group Name"]);
            expect(requiredReturnMap["Actual"]["Public IP Address Name"]).toEqual(requiredReturnMap["Expected"]["Public IP Address Name"]);
            expect(requiredReturnMap["Actual"]["Use Load Balancing"]).toEqual(requiredReturnMap["Expected"]["Use Load Balancing"]);
            expect(requiredReturnMap["Actual"]["OS Guest Diagnostics"]).toEqual(requiredReturnMap["Expected"]["OS Guest Daignostics"]);
            expect(requiredReturnMap["Actual"]["System Assigned Managed Identity"]).toEqual(requiredReturnMap["Expected"]["System Assigned Managed Identity"]);
            expect(requiredReturnMap["Actual"]["Boot Diagnostics"]).toEqual(requiredReturnMap["Expected"]["Boot Diagnostics"]);
            expect(requiredReturnMap["Actual"]["Enable Auto Shutdown"]).toEqual(requiredReturnMap["Expected"]["Enable Auto Shutdown"]);
            if (browser.params.defaultCurrency == "USD") {
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(newLinuxVMObject.TotalCost);
            }
            expect(requiredReturnMap["Actual"]["Public IP Address Required"]).toEqual(requiredReturnMap["Expected"]["Public IP Address Required"]);
            expect(requiredReturnMap["Actual"]["Public Ip Address Sku"]).toEqual(requiredReturnMap["Expected"]["Public Ip Address Sku"]);
            expect(requiredReturnMap["Actual"]["Public IP Address Type"]).toEqual(requiredReturnMap["Expected"]["Public IP Address Type"]);
            expect(requiredReturnMap["Actual"]["NIC Network Security Group"]).toEqual(requiredReturnMap["Expected"]["NIC Network Security Group"]);
            expect(requiredReturnMap["Actual"]["Public Inbound Ports"]).toEqual(requiredReturnMap["Expected"]["Public Inbound Ports"]);
            expect(requiredReturnMap["Actual"]["Support For Premium Disks"]).toEqual(requiredReturnMap["Expected"]["Support For Premium Disks"]);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            ordersPage.open();
            ordersPage.searchOrderById(orderObject.orderNumber);
            ordersPage.clickFirstViewDetailsOrdersTable();
            //Checking Order Details in View order details
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(orderObject.servicename);//Checking Service Name
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe('Azure');//Checking Provider
            //Checking Service Configuration Parameters
            ordersPage.clickServiceConfigurationsTabOrderDetails();
            expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(newLinuxVMObject, "New Resource Group Required"));
            expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Location"));
            expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(newResourceGroupName);
            expect(ordersPage.getTextBasedOnExactLabelName("Virtual Machine Name")).toEqual(newVmName);
            expect(ordersPage.getTextBasedOnExactLabelName("Virtual Machine Location")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Virtual Machine Location"));
            expect(ordersPage.getTextBasedOnExactLabelName("Username")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Username"));
            expect(ordersPage.getTextBasedOnExactLabelName("Proximity Placement Group")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Proximity Placement Group"));
            expect(ordersPage.getTextBasedOnExactLabelName("Availability Options")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Availability Options"));
            expect(ordersPage.getTextBasedOnExactLabelName("Operating System Image")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Operating System Image"));
            expect(ordersPage.getTextBasedOnExactLabelName("Vm Generation")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Vm Generation"));
            expect(ordersPage.getTextBasedOnExactLabelName("Virtual Machine Size")).toEqual(jsonUtil.getValue(newLinuxVMObject, " Virtual Machine Size"));
            expect(ordersPage.getTextBasedOnExactLabelName("Use Managed Disk")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Use Managed Disk"));
            expect(ordersPage.getTextBasedOnExactLabelName("Use Ephemeral OS Disk")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Use Ephemeral OS Disk"));
            expect(ordersPage.getTextBasedOnExactLabelName("OS Disk Type")).toEqual(jsonUtil.getValue(newLinuxVMObject, "OS Disk Type"));
            expect(ordersPage.getTextBasedOnExactLabelName("Data Disk")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Data Disk"));
            expect(ordersPage.getTextBasedOnExactLabelName("Logical Unit Number (LUN)")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Logical Unit Number (LUN)"));
            expect(ordersPage.getTextBasedOnExactLabelName("Disk Name")).toEqual(diskName);
            expect(ordersPage.getTextBasedOnExactLabelName("Storage Type : Ultra Disk")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Storage Type : Ultra Disk"));
            expect(ordersPage.getTextBasedOnExactLabelName("Storage Type")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Storage Type"));
            expect(ordersPage.getTextBasedOnExactLabelName("Source Type")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Source Type"))
            expect(ordersPage.getTextBasedOnExactLabelName("Provide Custom Disk Size")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Provide Custom Disk Size"));
            expect(ordersPage.getTextBasedOnExactLabelName("Disk Size List In GB")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Disk Size List In GB"));
            expect(ordersPage.getTextBasedOnExactLabelName("Host Caching")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Host Caching"));
            expect(ordersPage.getTextBasedOnExactLabelName("New Virtual Network Required")).toEqual(jsonUtil.getValue(newLinuxVMObject, "New Virtual Network Required"));
            expect(ordersPage.getTextBasedOnExactLabelName("Virtual Network Name")).toEqual(newNetworkName);
            expect(ordersPage.getTextBasedOnExactLabelName("Address Prefix")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Address Prefix"));
            expect(ordersPage.getTextBasedOnExactLabelName("Subnet Name")).toEqual(newSubnetName);
            expect(ordersPage.getTextBasedOnExactLabelName("Subnet Prefix")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Subnet Prefix"));
            expect(ordersPage.getTextBasedOnExactLabelName("Network Interface Name")).toEqual(newNetworkInterfaceName);
            expect(ordersPage.getTextBasedOnExactLabelName("Public IP Address Required")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Public IP Address Required"));
            expect(ordersPage.getTextBasedOnExactLabelName("NIC Network Security Group")).toEqual(jsonUtil.getValue(newLinuxVMObject, "NIC Network Security Group"));
            expect(ordersPage.getTextBasedOnExactLabelName("Public Inbound Ports")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Public Inbound Ports"));
            expect(ordersPage.getTextBasedOnExactLabelName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
            expect(ordersPage.getTextBasedOnExactLabelName("Public IP Address Name")).toEqual(newPublicIpName);
            expect(ordersPage.getTextBasedOnExactLabelName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Public Ip Address Sku"));
            expect(ordersPage.getTextBasedOnExactLabelName("Public IP Address Type")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Public IP Address Type"));
            expect(ordersPage.getTextBasedOnExactLabelName("Use Load Balancing")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Use Load Balancing"));
            expect(ordersPage.getTextBasedOnExactLabelName("Boot Diagnostics")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Boot Diagnostics"));
            expect(ordersPage.getTextBasedOnExactLabelName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(newLinuxVMObject, "System Assigned Managed Identity"));
            expect(ordersPage.getTextBasedOnExactLabelName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(newLinuxVMObject, "OS Guest Daignostics"));
            expect(ordersPage.getTextBasedOnExactLabelName("Support For Premium Disks")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Support For Premium Disks"));
            expect(ordersPage.getTextBasedOnExactLabelName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Enable Auto Shutdown"));
            //Checking Bill Of Material
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            if (browser.params.defaultCurrency == "USD") {
                expect(ordersPage.getEstimatedCost()).toBe(newLinuxVMObject.TotalCost);
            }
            //Deny Order
            ordersPage.clickServiceDetailSliderCloseButton();
            orderFlowUtil.denyOrder(orderObject);
        });
    });

    if (isProvisioningRequired == "true") {
        if (isDummyAdapterDisabled == "false") {
            it('Azure: TC-T395763 Verify provisioning of Linux Virtual Machine using Consume UI for Scenario 1', function () {
                var newLinuxVMObject = JSON.parse(JSON.stringify(LVMTemplate.Scenario1));
                var orderObject = {};
                var returnObj1 = {};
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(newLinuxVMObject.Category);
                catalogPage.searchForBluePrint(newLinuxVMObject.bluePrintName);
                catalogPage.clickConfigureButtonBasedOnName(newLinuxVMObject.bluePrintName);
                orderObject.servicename = servicename;
                orderFlowUtil.fillOrderDetails(LVMTemplate.Scenario1, modifiedParamMap);
                placeOrderPage.submitOrder();
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, "Completed", 50);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                inventoryPage.clickViewService();
                //Checking Inventory Page Service Configuration
                expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "New Resource Group Required"));
                expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(newResourceGroupName);
                expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Location"));
                expect(inventoryPage.getTextBasedOnLabelName(" Virtual Machine Name:")).toEqual(newVmName);
                expect(inventoryPage.getTextBasedOnExactLabelName("Virtual Machine Location:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Virtual Machine Location"));
                expect(inventoryPage.getTextBasedOnLabelName(" Authentication Type:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Authentication Type"));
                expect(inventoryPage.getTextBasedOnLabelName(" Proximity Placement Group:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Proximity Placement Group"));
                expect(inventoryPage.getTextBasedOnLabelName(" Availability Options:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Availability Options"));
                expect(inventoryPage.getTextBasedOnLabelName(" Operating System Image:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Operating System Image"));
                expect(inventoryPage.getTextBasedOnLabelName(" Vm Generation:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Vm Generation"));
                expect(inventoryPage.getTextBasedOnLabelName(" Username:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Username"));
                expect(inventoryPage.getTextBasedOnLabelName(" Virtual Machine Size:")).toEqual(jsonUtil.getValue(newLinuxVMObject, " Virtual Machine Size"));
                expect(inventoryPage.getTextBasedOnLabelName(" Use Managed Disk:")).toEqual(jsonUtil.getValue(newLinuxVMObject, " Use Managed Disk"));
                expect(inventoryPage.getTextBasedOnLabelName(" Use Ephemeral OS Disk:")).toEqual(jsonUtil.getValue(newLinuxVMObject, " Use Ephemeral OS Disk"));
                expect(inventoryPage.getTextBasedOnLabelName(" OS Disk Type:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "OS Disk Type"));
                expect(inventoryPage.getTextBasedOnLabelName(" Data Disk:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Data Disk"));
                expect(inventoryPage.getTextBasedOnLabelName(" Logical Unit Number (LUN):")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Logical Unit Number (LUN)"));
                expect(inventoryPage.getTextBasedOnLabelName(" Disk Name:")).toEqual(diskName);
                expect(inventoryPage.getTextBasedOnLabelName(" Storage Type : Ultra Disk:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Storage Type : Ultra Disk"));
                expect(inventoryPage.getTextBasedOnLabelName(" Storage Type:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Storage Type"));
                expect(inventoryPage.getTextBasedOnLabelName(" Source Type:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Source Type"));
                expect(inventoryPage.getTextBasedOnLabelName(" Provide Custom Disk Size:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Provide Custom Disk Size"));
                expect(inventoryPage.getTextBasedOnLabelName(" Disk Size List In GB:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Disk Size List In GB"));
                expect(inventoryPage.getTextBasedOnLabelName(" Host Caching:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Host Caching"));
                expect(inventoryPage.getTextBasedOnLabelName(" New Virtual Network Required:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "New Virtual Network Required"));
                expect(inventoryPage.getTextBasedOnLabelName(" Virtual Network Name:")).toEqual(newNetworkName);
                expect(inventoryPage.getTextBasedOnLabelName(" Address Prefix:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Address Prefix"));
                expect(inventoryPage.getTextBasedOnLabelName(" Subnet Name:")).toEqual(newSubnetName);
                expect(inventoryPage.getTextBasedOnLabelName(" Subnet Prefix:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Subnet Prefix"));
                expect(inventoryPage.getTextBasedOnLabelName(" Network Interface Name:")).toEqual(newNetworkInterfaceName);
                expect(inventoryPage.getTextBasedOnLabelName(" Public IP Address Required:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Public IP Address Required"));
                expect(inventoryPage.getTextBasedOnLabelName(" NIC Network Security Group:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "NIC Network Security Group"));
                expect(inventoryPage.getTextBasedOnLabelName(" Public Inbound Ports:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Public Inbound Ports"));
                expect(inventoryPage.getTextBasedOnLabelName(" Network Security Group Name:")).toEqual(newnetworkSecurityGroupName);
                expect(inventoryPage.getTextBasedOnLabelName(" Public IP Address Name:")).toEqual(newPublicIpName);
                expect(inventoryPage.getTextBasedOnLabelName(" Public Ip Address Sku:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Public Ip Address Sku"));
                expect(inventoryPage.getTextBasedOnLabelName(" Public IP Address Type:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Public IP Address Type"));
                expect(inventoryPage.getTextBasedOnLabelName(" Use Load Balancing:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Use Load Balancing"));
                expect(inventoryPage.getTextBasedOnLabelName(" Boot Diagnostics:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Boot Diagnostics"));
                expect(inventoryPage.getTextBasedOnLabelName(" System Assigned Managed Identity:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "System Assigned Managed Identity"));
                expect(inventoryPage.getTextBasedOnLabelName(" OS Guest Diagnostics:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "OS Guest Daignostics"));
                expect(inventoryPage.getTextBasedOnLabelName(" Support For Premium Disks:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Support For Premium Disks"));
                expect(inventoryPage.getTextBasedOnLabelName(" Enable Auto Shutdown:")).toEqual(jsonUtil.getValue(newLinuxVMObject, "Enable Auto Shutdown"));
                inventoryPage.closeViewDetailsTab();
                // // Edit is not supported anymore with Dummy Apdater Commenting below code (INT-7673)
                // inventoryPage.open();
                // inventoryPage.searchOrderByServiceName(orderObject.servicename);
                // element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                // inventoryPage.clickEditServiceIcon();
                // inventoryPage.clickNextButton();
                // modifiedParamMapedit = { "Service Instance Name": servicename, "Network Security Group Name": newnetworkSecurityGroupName, "EditService": true };
                // orderFlowUtil.fillOrderDetails(LVMTemplate.Scenario1, modifiedParamMapedit);
                // placeOrderPage.submitOrder();
                // returnObj1.servicename = servicename;
                // returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                // returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                // //Get details on pop up after submit
                // var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                // var orderprice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                // var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                // var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                // //Open Order page and Approve Order 
                // expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                // placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                // orderFlowUtil.approveOrder(returnObj1);
                // orderFlowUtil.waitForOrderStatusChange(returnObj1, "Completed", 50);
            });
        }
    }

    // Automated VM Scenario with Host but as Host costing is 3000$ plus so commenting the code
    // if (isProvisioningRequired == "true") {
    //     if (isDummyAdapterDisabled == "true") {
    //         it('Azure: Linux Virtual Machine - Create prerequisite Host Service for Linux Virtual Machine ', function () {

    //             catalogPage.searchForBluePrint(HostTemplate.bluePrintName);
    //             catalogPage.clickConfigureButtonBasedOnName(HostTemplate.bluePrintName);
    //             modifiedParamMapHostService = {"Service Instance Name": servicenameHost, "New Resource Group": newResourceGroupName, "Host Name": hostName, "Host Group Name": hostGroupName, "Dedicate Host VM Family Size": "ESv3-Type2 ( 76 vCPUs )", "Host Group Availability Zone": "2" };
    //             hostOrderObject.servicename = servicenameHost;
    //             orderFlowUtil.fillOrderDetails(HostTemplate, modifiedParamMapHostService);
    //             placeOrderPage.submitOrder();
    //             hostOrderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
    //             hostOrderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
    //             expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
    //             placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
    //             orderFlowUtil.approveOrder(hostOrderObject);
    //             orderFlowUtil.waitForOrderStatusChange(hostOrderObject, "Completed", 80);        
    //         });

    //         it('Azure: Verify provisioning of Linux Virtual Machine using Consume UI for Scenario 2', function () {
    //             var newLinuxVMObject1 = JSON.parse(JSON.stringify(LVMTemplate.Scenario2));
    //             var orderObject = {};
    //             var servicename = "GSLSLTestAutomation" + util.getRandomString(5);
    //             catalogPage.clickFirstCategoryCheckBoxBasedOnName(newLinuxVMObject1.Category);
    //             catalogPage.clickConfigureButtonBasedOnName(newLinuxVMObject1.bluePrintName);
    //             modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Disk Name": diskName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName,"Host": hostName, "Host Group": hostGroupName,"UpdateMainParamObject": false };
    //             orderObject.servicename = servicename;
    //             //logger.info("***********************: " + "Host Name"  + hostOrderObject.hostName + "Host Group Name" + hostOrderObject.hostGroupName);
    //             orderFlowUtil.fillOrderDetails(LVMTemplate.Scenario2, modifiedParamMap);
    //             placeOrderPage.submitOrder();
    //             orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
    //             orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
    //             expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
    //             placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
    //             orderFlowUtil.approveOrder(orderObject);
    //             orderFlowUtil.waitForOrderStatusChange(orderObject, "Completed", 50);

    //             //deletion for Linux Host VM
    //             var returnObj = {};
    //             returnObj.servicename = servicename;
    //             returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
    //             orderFlowUtil.approveDeletedOrder(returnObj);
    //             orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
    //             expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    //         });
    //     }
    // }
});