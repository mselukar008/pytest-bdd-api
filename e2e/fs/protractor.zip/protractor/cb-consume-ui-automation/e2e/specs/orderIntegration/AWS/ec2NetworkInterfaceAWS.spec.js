"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    networkInterfaceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSEC2NetworkInterface.json'),
    ec2InstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSEC2Instance.json'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled;

if (isDummyAdapterDisabled == 'true') {
    describe('AWS - Network Interface', function () {
        var ordersPage, homePage, catalogPage, placeOrderPage, inventoryPage, serviceName, serviceNameEc2, resourceName;
        var modifiedParamMap = {};
        var modifiedParamMap1 = {};
        var messageStrings = {
            providerName: 'Amazon',
            category: 'Network',
            catalogPageTitle: 'Search, Select and Configure',
            inputServiceNameWarning: "Parameter Warning:",
            orderSubmittedConfirmationMessage: 'Order Submitted !',
            isDummyTagValue: 'Yes',
            systemTagText: "ibm_mcmp_soiid"
        };
        var orderObjectEc2 = {};
        var orderObject = {};
        orderObject.componentType = ec2InstanceTemplate.componentType;

        beforeAll(function () {
            ordersPage = new Orders();
            homePage = new HomePage();
            catalogPage = new CatalogPage();
            placeOrderPage = new PlaceOrderPage();
            inventoryPage = new InventoryPage();
            browser.driver.manage().window().maximize();
            var groupName = "att-group-" + util.getRandomString(5);
            serviceNameEc2 = "auto-aws-ec2-" + util.getRandomString(5);
            modifiedParamMap1 = { "Service Instance Name": serviceNameEc2, "Select VPC": "vpc-8eadd1eb", "My Subnet IDs": "subnet-a68b538d", "Security Group Ids": "sg-4e88232a", "Group Name": groupName };
        });

        beforeEach(function () {
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
            serviceName = "auto-aws-ec2networkintrfc-1-" + util.getRandomString(5);
            modifiedParamMap = { "Service Instance Name": serviceName, "Instance Id": "test" };
        });

        it('TC-C182408 : AWS Network Interface - Verify fields on Main Parameters page is working fine', function () {
            var AWSEC2Object = JSON.parse(JSON.stringify(ec2InstanceTemplate));
            catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(networkInterfaceTemplate.bluePrintName);
            expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
            placeOrderPage.setServiceNameText(serviceName);
            placeOrderPage.selectProviderAccount(AWSEC2Object["Order Parameters"]["Main Parameters"]["Provider Account"]["value"]["QA 1"]);
            expect(placeOrderPage.isNextButtonEnabled()).toBe(true);

        });

        it('TC-C182409 : AWS Network Interface - Verify Summary details and Additional Details are listed in review Order page', function () {
            var NetworkInterfaceObject = JSON.parse(JSON.stringify(networkInterfaceTemplate));
            catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(networkInterfaceTemplate.bluePrintName);
            modifiedParamMap['Instance Id'] = resourceName;
            orderFlowUtil.fillOrderDetails(networkInterfaceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
                //expect(requiredReturnMap["Actual"]["Service Instance Name"]).toEqual(requiredReturnMap["Expected"]["Service Instance Name"]);
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
                //expect(placeOrderPage.getTextCategoryName_ReviewOrder()).toBe(messageStrings.category);
                //expect(placeOrderPage.getTextProviderName_ReviewOrder()).toBe(messageStrings.providerName);
                if (browser.params.defaultCurrency == "USD") {
                    expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(networkInterfaceTemplate.TotalCost);
                }
                expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
                expect(requiredReturnMap["Actual"]["Description"]).toEqual(requiredReturnMap["Expected"]["Description"]);
                expect(requiredReturnMap["Actual"]["VPC"]).toEqual(requiredReturnMap["Expected"]["VPC"]);
                expect(requiredReturnMap["Actual"]["Availability Zone"]).toEqual(requiredReturnMap["Expected"]["Availability Zone"]);
                expect(requiredReturnMap["Actual"]["Subnet"]).toEqual(requiredReturnMap["Expected"]["Subnet"]);
                expect(requiredReturnMap["Actual"]["Auto Assign"]).toEqual(requiredReturnMap["Expected"]["Auto Assign"]);
                expect(requiredReturnMap["Actual"]["Security Groups"]).toEqual(requiredReturnMap["Expected"]["Security Groups"]);
                expect(requiredReturnMap["Actual"]["Source Dest Check"]).toEqual(requiredReturnMap["Expected"]["Source Dest Check"]);
                expect(requiredReturnMap["Actual"]["Tag Key"]).toEqual(requiredReturnMap["Expected"]["Tag Key"]);
                expect(requiredReturnMap["Actual"]["Tag Value"]).toEqual(requiredReturnMap["Expected"]["Tag Value"]);                
            });
        });

        it('TC-C182410 : AWS Network Interface - Verify Order is listed in Orders details page once it is submitted from catalog page', function () {
            var orderObject = {};
            var NetworkInterfaceObject = JSON.parse(JSON.stringify(networkInterfaceTemplate));
            catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(networkInterfaceTemplate.bluePrintName);
            modifiedParamMap['Instance Id'] = resourceName + " | EC2Instance";
            orderFlowUtil.fillOrderDetails(networkInterfaceTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
            expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            //util.waitForAngular();
            expect(ordersPage.getTextBasedOnLabelName("Service Instance Prefix")).toEqual(serviceName);
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(NetworkInterfaceObject, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("Description")).toEqual(jsonUtil.getValue(NetworkInterfaceObject, "Description"));
            expect(ordersPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(NetworkInterfaceObject, "VPC"));
            expect(ordersPage.getTextBasedOnLabelName("Availability Zone")).toEqual(jsonUtil.getValue(NetworkInterfaceObject, "Availability Zone"));
            expect(ordersPage.getTextBasedOnLabelName("Subnet")).toEqual(jsonUtil.getValue(NetworkInterfaceObject, "Subnet"));
            expect(ordersPage.getTextBasedOnLabelName("Auto Assign")).toEqual(jsonUtil.getValue(NetworkInterfaceObject, "Auto Assign"));
            expect(ordersPage.getTextBasedOnLabelName("Security Groups")).toEqual(jsonUtil.getValue(NetworkInterfaceObject, "Security Groups"));
            expect(ordersPage.getTextBasedOnLabelName("Source Dest Check")).toEqual(jsonUtil.getValue(NetworkInterfaceObject, "Source Dest Check"));
            expect(ordersPage.getTextBasedOnLabelName("Tag Key")).toEqual(jsonUtil.getValue(NetworkInterfaceObject, "Tag Key"));
            expect(ordersPage.getTextBasedOnLabelName("Tag Value")).toEqual(jsonUtil.getValue(NetworkInterfaceObject, "Tag Value"));
            if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(element(by.xpath('//*[@id="total_cost_value"]')).getText()).toBe(networkInterfaceTemplate.TotalCost);
            }
        });

        if (isProvisioningRequired == "true") {

            it('TC-C182411 : AWS Network Interface - E2E : Verify instance Order Provision and Deletion is working fine from consume App', function () {

                var serviceDetailsMap = {};
                var NetworkInterfaceObject = JSON.parse(JSON.stringify(networkInterfaceTemplate));
                catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
                catalogPage.clickConfigureButtonBasedOnName(networkInterfaceTemplate.bluePrintName);
                orderObject.servicename = serviceName;
                modifiedParamMap['Instance Id'] = resourceName;
                orderFlowUtil.fillOrderDetails(networkInterfaceTemplate, modifiedParamMap).then(function (serviceDetailsMapActual) {
                    serviceDetailsMap = serviceDetailsMapActual;
                });

                placeOrderPage.submitOrder();
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(networkInterfaceTemplate.bluePrintName, "New");
                orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');

                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                        inventoryPage.clickViewComponentofAWSInstance().then(function () {
                            var resourceID = inventoryPage.getViewComponentPropertyAWS("Resource Id");
                            resourceID.then(function (text) {
                                resourceName = text;
                                orderFlowUtil.closeHorizontalSliderIfPresent();
                            });
                        });
                    });
                });

            });

            it('TC-C172382 : AWS Network Interface - Verify AWS EC2 instance creation as part of pre-requisite data.', function () {
                var AWSEC2Object = JSON.parse(JSON.stringify(ec2InstanceTemplate));
                catalogPage.clickProviderOrCategoryCheckbox('Compute');
                catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);
                orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap1).then(function (requiredReturnMap) {
                    placeOrderPage.submitOrder();
                    orderObjectEc2.servicename = serviceNameEc2;
                    orderObjectEc2.orderNumber = placeOrderPage.getAndSaveOrderId(networkInterfaceTemplate.bluePrintName, "New-EC2");
                    //orderObjectEc2.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                    orderObjectEc2.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                    expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                    placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                    orderFlowUtil.approveOrder(orderObjectEc2);
                    orderFlowUtil.waitForOrderStatusChange(orderObjectEc2, 'Completed');
                    expect(orderFlowUtil.verifyOrderStatus(orderObjectEc2)).toBe('Completed');
                });
            });

            it('AWS EC2 - Attach Network Interface', function () {
                orderObjectEc2.servicename = serviceNameEc2;
                var NetworkInterfaceObject = JSON.parse(JSON.stringify(networkInterfaceTemplate));
                resourceName = resourceName + " (description)"
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObjectEc2.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                        inventoryPage.clickAtachNetworkInterfaceBtn().then(function () {
                            inventoryPage.clickOkButnInConfigrImiPopUp();
                        });
                    });
                });

                var modifiedParamMapInterface = { "CustomOperation": true, "Attach Network Interface": resourceName, "Detach Network Interface": "" };
                orderFlowUtil.fillOrderDetails(networkInterfaceTemplate, modifiedParamMapInterface);
                //Validate Review order page
                inventoryPage.getTextBasedOnLabelName("AWS Region").then(function (regn) {
                    expect(jsonUtil.getValue(NetworkInterfaceObject, "AWS Region")).toContain(regn);
                });
                inventoryPage.getTextBasedOnLabelName("Vpc Id").then(function (vpc) {
                    expect(jsonUtil.getValue(NetworkInterfaceObject, "VPC")).toContain(vpc);
                });
                inventoryPage.getTextBasedOnLabelName("Subnet Id").then(function (id) {
                    expect(jsonUtil.getValue(NetworkInterfaceObject, "Subnet")).toContain(id);
                });
                expect(inventoryPage.getTextBasedOnLabelName("Network Interface")).toEqual(resourceName);
                placeOrderPage.submitOrder();
                inventoryPage.fetchD2opsOrderDetails();
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(networkInterfaceTemplate.bluePrintName, "AttachNetworkInterface");
                //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Request Initiated!');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');

            });

            it('AWS EC2 - Detach Network Interface', function () {

                orderObjectEc2.servicename = serviceNameEc2;
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObjectEc2.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                        inventoryPage.getAtachmntId().then(function (text) {
                            orderFlowUtil.closeHorizontalSliderIfPresent();
                            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType);
                            inventoryPage.clickDetachNetworkInterfaceBtn();
                            inventoryPage.clickOkButnInConfigrImiPopUp();
                            var modifiedParamMapInterface = { "CustomOperation": true, "Detach Network Interface": text + " | " + resourceName, "Attach Network Interface": "" };
                            orderFlowUtil.fillOrderDetails(networkInterfaceTemplate, modifiedParamMapInterface);
                            expect(inventoryPage.getTextBasedOnLabelName("Network Interface")).toContain(text);
                        });
                    });
                });
                placeOrderPage.submitOrder();
                inventoryPage.fetchD2opsOrderDetails();
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(networkInterfaceTemplate.bluePrintName, "DetachNetworkInterface");
                //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Request Initiated!');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                catalogPage.open();
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');

                //Delete EC2 instance
                //orderObjectEc2.deleteOrderNumber = orderFlowUtil.deleteService(orderObjectEc2);
                orderFlowUtil.deleteService(orderObjectEc2).then(async function (orderNo) {
                    orderObjectEc2.deleteOrderNumber = orderNo;
                    await util.saveOrderId(networkInterfaceTemplate.bluePrintName, "Delete-EC2", orderNo);
                    orderFlowUtil.approveDeletedOrder(orderObjectEc2);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObjectEc2, 'Completed');
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObjectEc2)).toBe('Completed');
                });

                //Delete EC2 Network Interface
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, networkInterfaceTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            });
        }

    });
}
