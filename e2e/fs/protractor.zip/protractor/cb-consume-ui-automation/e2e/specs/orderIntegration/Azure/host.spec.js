/*
Spec_Name: host.spec.js 
Description: This spec will cover E2E testing of Host Service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra 
*/
"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    async = require('async'),
    logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    HTTemplate = require('../../../../testData/OrderIntegration/Azure/host.json');

describe('Azure - Host Service', function () {
    var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage;
    var rgName, hostName, hostGroupName, SOIComponents;
    var modifiedParamMap = {};
    var messageStrings = { providerName: 'Azure', category: 'Compute' };
    var servicename = "AutoHostsrv" + util.getRandomString(5);
    rgName = "gslautotc_azure_hostRG" + util.getRandomString(5);
    hostName = "autoHost" + util.getRandomString(5);
    hostGroupName = "autoHostGroup" + util.getRandomString(5);
    var modifiedParamMapedit = {};

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        catalogDetailsPage = new CatalogDetailsPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        rgName = "gslautotc_azure_hostRG" + util.getRandomString(5);
        hostName = "autoHost" + util.getRandomString(5);
        hostGroupName = "autoHostGroup" + util.getRandomString(5);
        SOIComponents = [hostName, hostGroupName]
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Host Name": hostName, "Host Group Name": hostGroupName };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    afterAll(function () {
        // Delete Host Service
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    //E2E Dedicated Host order Submit, Approve, Delete Service with New Resource Group.
    if (isProvisioningRequired == "true") {
        it('Azure: TC Verify that for Host Service,if service is created with new resource group with valid name and location,create valid Host Name and Host Location', function () {
            var orderObject = JSON.parse(JSON.stringify(HTTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            var returnObj = {};
            var returnObj1 = {};
            orderFlowUtil.fillOrderDetails(HTTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
            //checking order on Inventory Page 
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
            inventoryPage.clickViewService();
            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
            expect(inventoryPage.getTextBasedOnExactLabelName("New Resource Group:")).toEqual(rgName);
            expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
            expect(inventoryPage.getTextBasedOnLabelName(" Host Name:")).toEqual(hostName);
            expect(inventoryPage.getTextBasedOnLabelName(" Host Location:")).toEqual(jsonUtil.getValue(orderObject, "Host Location"));
            inventoryPage.closeViewDetailsTab();
            //Checking SOI Components
            if (isDummyAdapterDisabled == "true") {
                inventoryPage.clickExpandFirstRow().then(function () {
                    browser.executeScript('window.scrollTo(0,0);');
                    var i = 1;
                    async.forEachSeries(SOIComponents, function (component, callback) {
                        util.waitForAngular();
                        inventoryPage.clickOverMenuIcon(i).then(function () {
                            browser.executeScript('window.scrollTo(0,0);');
                            inventoryPage.clickOnViewComponent(i).then(function () {
                                //expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.mcmpTag);
                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.bluePrintName);
                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                inventoryPage.closeViewComponent();
                                browser.sleep(10000);
                                i++;
                                return callback();
                            });
                        })
                    }), function (error) {
                        if (error) {
                            logger.info('Unable to Get SOI component')
                        }
                    }
                })
            }
            //Edit order flow
            util.waitForAngular();
            element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
            inventoryPage.clickEditServiceIcon();
            inventoryPage.clickNextButton();
            modifiedParamMapedit = { "Service Instance Name": servicename, "EditService": true };
            orderFlowUtil.fillOrderDetails(HTTemplate, modifiedParamMapedit);
            placeOrderPage.submitOrder();
            returnObj1.servicename = servicename;
            returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            //Open Order page and Approve Order 
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj1);
            orderFlowUtil.waitForOrderStatusChange(returnObj1, 'Completed', 50);
        })
    }

    //Checking parameters on Main Parameters page
    it('Azure: TC verify that for Host Service all parameters on Main Parameters Page are present.', function () {
        var orderObject = JSON.parse(JSON.stringify(HTTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        if (browser.params.defaultCurrency == "USD") {
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
        }
    });

    //Checking values all parameters on Review Order Page and View Order Details
    it('Azure: TC verify that for Host Service all values on Review Order Page and View Order Details page matches with input.', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(HTTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(HTTemplate, modifiedParamMap);
        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
        if (browser.params.defaultCurrency == "USD") {
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
        }
        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
        expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Host Name:")).toEqual(hostName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Host Location:")).toEqual(jsonUtil.getValue(orderObject, "Host Location"));
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
        expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("Host Name")).toEqual(hostName);
        expect(ordersPage.getTextBasedOnExactLabelName("Host Location")).toEqual(jsonUtil.getValue(orderObject, "Host Location"));
        //Checking Bill Of Material
        if (browser.params.defaultCurrency == "USD") {
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(ordersPage.getEstimatedCost()()).toBe(orderObject.TotalCost);
        }
        ordersPage.clickServiceDetailSliderCloseButton();
    });
});