/*************************************************
Spec_Name: autoScaling.spec.js
Description: This spec will cover E2E testing of AutoScaling order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".  
**************************************************/

"use strict";
var async = require('async'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    autoScalingTemplate = require('../../../../testData/OrderIntegration/Alibaba/AutoScaling.json')

describe('Alibaba: Test cases for AutoScaling', function () {
    var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage, homePage;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: 'Alibaba Cloud',
        category: 'Compute'
    };
    var servicename = "Gsl-Automation-AutoScaling" + util.getRandomString(5);

    beforeAll(function () {
        homePage = new HomePage();
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        modifiedParamMap = {
            "Service Instance Name": servicename,
        };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    afterAll(function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    if (isProvisioningRequired == "true") {
        it('Aalibaba: TC-1 AutoScaling -Verify Inventory / output parameters Details', function () {
            var orderObject = JSON.parse(JSON.stringify(autoScalingTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            var returnObj = {};
            orderFlowUtil.fillOrderDetails(autoScalingTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, orderObject.OrderStatus);

            //checking order on Inventory Page 
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();

            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
            expect(inventoryPage.getTextBasedOnLabelName(" Source Type:")).toEqual(jsonUtil.getValue(orderObject, "Source Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" Scaling Group Name:")).toEqual(jsonUtil.getValue(orderObject, "Scaling Group Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Maximum Instances:")).toEqual(jsonUtil.getValue(orderObject, "Maximum Instances"));
            expect(inventoryPage.getTextBasedOnLabelName(" Minimum Instances:")).toEqual(jsonUtil.getValue(orderObject, "Minimum Instances"));
            expect(inventoryPage.getTextBasedOnLabelName(" Default Cooldown Time:")).toEqual(jsonUtil.getValue(orderObject, "Default Cooldown Time"));
            expect(inventoryPage.getTextBasedOnLabelName(" Enable Deletion Protection For Scaling Group:")).toEqual(jsonUtil.getValue(orderObject, "Enable Deletion Protection For Scaling Group"));
            expect(inventoryPage.getTextBasedOnLabelName(" Multi Zone Scaling Policy:")).toEqual(jsonUtil.getValue(orderObject, "Multi Zone Scaling Policy"));
            expect(inventoryPage.getTextBasedOnLabelName(" Create New Virtual Private Cloud:")).toEqual(jsonUtil.getValue(orderObject, "Create New Virtual Private Cloud"));
            expect(inventoryPage.getTextBasedOnLabelName(" Zone:")).toEqual(jsonUtil.getValue(orderObject, "Zone"));
            expect(inventoryPage.getTextBasedOnLabelName(" VPC Name:")).toEqual(jsonUtil.getValue(orderObject, "VPC Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Cidr Block VPC:")).toEqual(jsonUtil.getValue(orderObject, "Cidr Block VPC"));
            expect(inventoryPage.getTextBasedOnLabelName(" Vswitch Name:")).toEqual(jsonUtil.getValue(orderObject, "Vswitch Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Cidr Block Vswitch:")).toEqual(jsonUtil.getValue(orderObject, "Cidr Block Vswitch"));
            expect(inventoryPage.getTextBasedOnLabelName(" Multi Zone Scaling Policy:")).toEqual(jsonUtil.getValue(orderObject, "Multi Zone Scaling Policy"));
            expect(inventoryPage.getTextBasedOnLabelName(" Create New Scaling Configuration:")).toEqual(jsonUtil.getValue(orderObject, "Create New Scaling Configuration"));
            expect(inventoryPage.getTextBasedOnLabelName(" Scaling Configuration Name:")).toEqual(jsonUtil.getValue(orderObject, "Scaling Configuration Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Operating System Type:")).toEqual(jsonUtil.getValue(orderObject, "Operating System Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" Image:")).toEqual(jsonUtil.getValue(orderObject, "Image"));
            expect(inventoryPage.getTextBasedOnLabelName(" Instance Type:")).toEqual(jsonUtil.getValue(orderObject, "Instance Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" System Disk Category:")).toEqual(jsonUtil.getValue(orderObject, "System Disk Category"));
            expect(inventoryPage.getTextBasedOnLabelName(" System Disk Size:")).toEqual(jsonUtil.getValue(orderObject, "System Disk Size"));
            expect(inventoryPage.getTextBasedOnLabelName(" Assign Public IP:")).toEqual(jsonUtil.getValue(orderObject, "Assign Public IP"));
            expect(inventoryPage.getTextBasedOnLabelName(" Create New Security Group:")).toEqual(jsonUtil.getValue(orderObject, "Create New Security Group"));
            expect(inventoryPage.getTextBasedOnLabelName(" Security Grp Name:")).toEqual(jsonUtil.getValue(orderObject, "Security Grp Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Log Credential:")).toEqual(jsonUtil.getValue(orderObject, "Log Credential"));
            expect(inventoryPage.getTextBasedOnLabelName(" Instance Name:")).toEqual(jsonUtil.getValue(orderObject, "Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Create New Scaling Rule:")).toEqual(jsonUtil.getValue(orderObject, "Create New Scaling Rule"));
            inventoryPage.closeViewDetailsTab();
        });
    }

    it('Aalibaba: TC-2 verify that for AutoScaling all parameters on Main Parameters Page are present.', function () {
        var orderObject = JSON.parse(JSON.stringify(autoScalingTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);

        expect(catalogDetailsPage.getServiceName()).toBe(orderObject.bluePrintName)
        expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true);
        expect(catalogDetailsPage.isPresentLinkToProviderSite()).toBe(true);
        expect(catalogDetailsPage.isPresentFeaturesLabel()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsLabel()).toBe(true);
        expect(catalogDetailsPage.getTextFeaturesLabel()).toBe(orderObject.FeaturesLabel);
        expect(catalogDetailsPage.getTextDetailsLabel()).toBe(orderObject.DetailsLabel);
        expect(catalogDetailsPage.isPresentFeaturesInfo()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsInfo()).toBe(true);

        catalogDetailsPage.clickCatalogFromBreadCrumbNav();
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
        homePage.open();
    });

    it('Aalibaba: TC-3 verify that for AutoScaling all parameters on Review Order page matches with input.', function () {
        var orderObject = JSON.parse(JSON.stringify(autoScalingTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderObject.servicename = servicename;
        orderFlowUtil.fillOrderDetails(autoScalingTemplate, modifiedParamMap);

        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(orderObject.servicename);
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);

        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Source Type:")).toEqual(jsonUtil.getValue(orderObject, "Source Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Scaling Group Name:")).toEqual(jsonUtil.getValue(orderObject, "Scaling Group Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Maximum Instances:")).toEqual(jsonUtil.getValue(orderObject, "Maximum Instances"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Minimum Instances:")).toEqual(jsonUtil.getValue(orderObject, "Minimum Instances"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Default Cooldown Time:")).toEqual(jsonUtil.getValue(orderObject, "Default Cooldown Time"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Enable Deletion Protection For Scaling Group:")).toEqual(jsonUtil.getValue(orderObject, "Enable Deletion Protection For Scaling Group"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Multi Zone Scaling Policy:")).toEqual(jsonUtil.getValue(orderObject, "Multi Zone Scaling Policy"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Create New Virtual Private Cloud:")).toEqual(jsonUtil.getValue(orderObject, "Create New Virtual Private Cloud"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Zone:")).toEqual(jsonUtil.getValue(orderObject, "Zone"));
        expect(placeOrderPage.getTextBasedOnLabelName(" VPC Name:")).toEqual(jsonUtil.getValue(orderObject, "VPC Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Cidr Block VPC:")).toEqual(jsonUtil.getValue(orderObject, "Cidr Block VPC"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Vswitch Name:")).toEqual(jsonUtil.getValue(orderObject, "Vswitch Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Cidr Block Vswitch:")).toEqual(jsonUtil.getValue(orderObject, "Cidr Block Vswitch"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Multi Zone Scaling Policy:")).toEqual(jsonUtil.getValue(orderObject, "Multi Zone Scaling Policy"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Create New Scaling Configuration:")).toEqual(jsonUtil.getValue(orderObject, "Create New Scaling Configuration"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Scaling Configuration Name:")).toEqual(jsonUtil.getValue(orderObject, "Scaling Configuration Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Operating System Type:")).toEqual(jsonUtil.getValue(orderObject, "Operating System Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Image:")).toEqual(jsonUtil.getValue(orderObject, "Image"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Instance Type:")).toEqual(jsonUtil.getValue(orderObject, "Instance Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" System Disk Category:")).toEqual(jsonUtil.getValue(orderObject, "System Disk Category"));
        expect(placeOrderPage.getTextBasedOnLabelName(" System Disk Size:")).toEqual(jsonUtil.getValue(orderObject, "System Disk Size"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Assign Public IP:")).toEqual(jsonUtil.getValue(orderObject, "Assign Public IP"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Create New Security Group:")).toEqual(jsonUtil.getValue(orderObject, "Create New Security Group"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Security Grp Name:")).toEqual(jsonUtil.getValue(orderObject, "Security Grp Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Log Credential:")).toEqual(jsonUtil.getValue(orderObject, "Log Credential"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Instance Name:")).toEqual(jsonUtil.getValue(orderObject, "Instance Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Create New Scaling Rule:")).toEqual(jsonUtil.getValue(orderObject, "Create New Scaling Rule"));
        homePage.open();
    });

    it('Aalibaba: TC-4 verify that for AutoScaling all values on View Order Details page matches with input.', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(autoScalingTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(autoScalingTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();

        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename); //Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider); //Checking Provider

        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("Region")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(ordersPage.getTextBasedOnExactLabelName("Source Type")).toEqual(jsonUtil.getValue(orderObject, "Source Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Scaling Group Name")).toEqual(jsonUtil.getValue(orderObject, "Scaling Group Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Maximum Instances")).toEqual(jsonUtil.getValue(orderObject, "Maximum Instances"));
        expect(ordersPage.getTextBasedOnExactLabelName("Minimum Instances")).toEqual(jsonUtil.getValue(orderObject, "Minimum Instances"));
        expect(ordersPage.getTextBasedOnExactLabelName("Default Cooldown Time")).toEqual(jsonUtil.getValue(orderObject, "Default Cooldown Time"));
        expect(ordersPage.getTextBasedOnExactLabelName("Enable Deletion Protection For Scaling Group")).toEqual(jsonUtil.getValue(orderObject, "Enable Deletion Protection For Scaling Group"));
        expect(ordersPage.getTextBasedOnExactLabelName("Multi Zone Scaling Policy")).toEqual(jsonUtil.getValue(orderObject, "Multi Zone Scaling Policy"));
        expect(ordersPage.getTextBasedOnExactLabelName("Create New Virtual Private Cloud")).toEqual(jsonUtil.getValue(orderObject, "Create New Virtual Private Cloud"));
        expect(ordersPage.getTextBasedOnExactLabelName("Zone")).toEqual(jsonUtil.getValue(orderObject, "Zone"));
        expect(ordersPage.getTextBasedOnExactLabelName("VPC Name")).toEqual(jsonUtil.getValue(orderObject, "VPC Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Cidr Block VPC")).toEqual(jsonUtil.getValue(orderObject, "Cidr Block VPC"));
        expect(ordersPage.getTextBasedOnExactLabelName("Vswitch Name")).toEqual(jsonUtil.getValue(orderObject, "Vswitch Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Cidr Block Vswitch")).toEqual(jsonUtil.getValue(orderObject, "Cidr Block Vswitch"));
        expect(ordersPage.getTextBasedOnExactLabelName("Multi Zone Scaling Policy")).toEqual(jsonUtil.getValue(orderObject, "Multi Zone Scaling Policy"));
        expect(ordersPage.getTextBasedOnExactLabelName("Create New Scaling Configuration")).toEqual(jsonUtil.getValue(orderObject, "Create New Scaling Configuration"));
        expect(ordersPage.getTextBasedOnExactLabelName("Scaling Configuration Name")).toEqual(jsonUtil.getValue(orderObject, "Scaling Configuration Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Operating System Type")).toEqual(jsonUtil.getValue(orderObject, "Operating System Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Image")).toEqual(jsonUtil.getValue(orderObject, "Image"));
        expect(ordersPage.getTextBasedOnExactLabelName("Instance Type")).toEqual(jsonUtil.getValue(orderObject, "Instance Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("System Disk Category")).toEqual(jsonUtil.getValue(orderObject, "System Disk Category"));
        expect(ordersPage.getTextBasedOnExactLabelName("System Disk Size")).toEqual(jsonUtil.getValue(orderObject, "System Disk Size"));
        expect(ordersPage.getTextBasedOnExactLabelName("Assign Public IP")).toEqual(jsonUtil.getValue(orderObject, "Assign Public IP"));
        expect(ordersPage.getTextBasedOnExactLabelName("Create New Security Group")).toEqual(jsonUtil.getValue(orderObject, "Create New Security Group"));
        expect(ordersPage.getTextBasedOnExactLabelName("Security Grp Name")).toEqual(jsonUtil.getValue(orderObject, "Security Grp Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Log Credential")).toEqual(jsonUtil.getValue(orderObject, "Log Credential"));
        expect(ordersPage.getTextBasedOnExactLabelName("Instance Name")).toEqual(jsonUtil.getValue(orderObject, "Instance Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Create New Scaling Rule")).toEqual(jsonUtil.getValue(orderObject, "Create New Scaling Rule"));

        //Checking Bill Of Material
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(placeOrderPage.getTotalCost()).toBe(orderObject.TotalCost);

        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
        orderFlowUtil.denyOrder(returnObj);
    });
});