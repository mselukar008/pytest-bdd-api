//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.
"use strict";

const { browser } = require('protractor');

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	Orders = require('../../../pageObjects/orders.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	vmInAwsTemplate = require('../../../../testData/OrderIntegration/ICAM/VirtualMachineInAWS.json'),
	externalContextTemplate = require('../../../../testData/OrderIntegration/ICAM/ExternalContextwithAWS.json'),
	CatalogDiscoveryPage   = require('../../../pageObjects/catalogDiscovery.pageObject.js');
	

describe('TA - E2E Virtual machine in AWS service', function () {

	var catalogPage, placeOrderPage, ordersPage,orderHistoryPage,SubnetName,vpc, serviceName, virtualMachineName, awsSshKeyName,inventoryPage,catalogDiscoveryObj;
	var modifiedParamMap = {};
	var modifiedParamMap2 = {};
	var externalContextModifiedParamMap = {};
	var serviceNameProv = vmInAwsTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
	var ServiceNameExternalContextProv = externalContextTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
	var messageStrings = {
		providerName				     : vmInAwsTemplate.providerName,
		category					   	 : vmInAwsTemplate.category,
		estimatedPrice				   	 : vmInAwsTemplate.estimatedPrice,
		providerAccount				   	 : vmInAwsTemplate.providerAccount,
		completedState				   	 : vmInAwsTemplate.completedState,
		approvalState				   	 : vmInAwsTemplate.approvalState,
		orderTypeDel				   	 : vmInAwsTemplate.orderTypeDel,
		urlOrders					   	 : vmInAwsTemplate.urlOrders,
		estimatedCost				   	 : vmInAwsTemplate.estimatedCost,
		cancelOrderSuccessMsg            : vmInAwsTemplate.cancelOrderSuccessMsg,
		cancelledStatus                  : vmInAwsTemplate.cancelledStatus,
		provisiongstatus                 : vmInAwsTemplate.provisiongstatus,
		Cancelingstatus			 : vmInAwsTemplate.Cancelingstatus,
		orderSubmittedConfirmationMessage: vmInAwsTemplate.orderSubmittedConfirmationMessage,
		orderFailedStatus                : vmInAwsTemplate.failedState,
		deletedStatus                    : vmInAwsTemplate.deletedStatus,
		AvailableVersions		 :vmInAwsTemplate.AvailableVersions,
		featureText			 :vmInAwsTemplate.featureText,
		longDescription			 :vmInAwsTemplate.longDescription,
		failedLogsText: vmInAwsTemplate.failedLogsText,
		servicelogText: vmInAwsTemplate.servicelogText,
		resourcelogText: vmInAwsTemplate.resourcelogText,
		SuccessLogMsg :vmInAwsTemplate.SuccessLogMsg,
		sshValue:vmInAwsTemplate.sshValue,
		sshKeyName:vmInAwsTemplate.sshKeyName,
		RegxErrorMsg:vmInAwsTemplate.RegxErrorMsg,
		DenyStatus:vmInAwsTemplate.DenyStatus,
		MessageForStartOnStart			  : vmInAwsTemplate.MessageForStartOnStart,
        MessageForStopOnStop			  : vmInAwsTemplate.MessageForStopOnStop,
		SuccessLogMsg :vmInAwsTemplate.SuccessLogMsg

	};
	
	beforeAll(function () {
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		orderHistoryPage = new OrderHistoryPage();
		inventoryPage = new InventoryPage();
		catalogDiscoveryObj = new CatalogDiscoveryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		serviceName = vmInAwsTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
		SubnetName= vmInAwsTemplate.subnetnamePrefix + "-" + util.getRandomString(5);
		vpc= vmInAwsTemplate.vpcPrefix + "-" + util.getRandomString(5);
		virtualMachineName = vmInAwsTemplate.virtualMachineNamePrefix + "-" + util.getRandomString(5);
		awsSshKeyName = vmInAwsTemplate.awsSshKeyNamePrefix + "-" + util.getRandomString(5);
		modifiedParamMap = { "Service Instance Name": serviceName, "Public SSH Key Name": awsSshKeyName };
		modifiedParamMap2 = { "Service Instance Name": serviceNameProv, "Public SSH Key Name": awsSshKeyName };
		externalContextModifiedParamMap = { "Service Instance Name": ServiceNameExternalContextProv, "Public SSH Key Name": awsSshKeyName };
	});

	it('TA -  Virtual machine in AWS ---- Verify fields on Main Parameters page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);	
		catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
		expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
		placeOrderPage.setServiceNameTextICAM(vmInAwsTemplate.serviceNamePrefix + "-" + util.getRandomString(4));
		 placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
		expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
		//expect(placeOrderPage.getTextEstimatedPrice()).toBe(vmInAwsTemplate.EstimatedPrice);
	});

	it('TA - Virtual machine in AWS ---- Verify Summary details and Additional Details are listed in review Order page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
		//	expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPrice);
			expect(requiredReturnMap["Actual"]["Instance Plan"]).toEqual(requiredReturnMap["Expected"]["Instance Plan"]);
			expect(requiredReturnMap["Actual"]["AWS Region Name"]).toEqual(requiredReturnMap["Expected"]["AWS Region Name"]);
			expect(requiredReturnMap["Actual"]["Cloud Connection Name"]).toEqual(requiredReturnMap["Expected"]["Cloud Connection Name"]);
			expect(requiredReturnMap["Actual"]["VPC Name tag"]).toEqual(requiredReturnMap["Expected"]["VPC Name tag"]);
			expect(requiredReturnMap["Actual"]["Subnet Name"]).toEqual(requiredReturnMap["Expected"]["Subnet Name"]);
			expect(requiredReturnMap["Actual"]["Public SSH Key Name"]).toEqual(requiredReturnMap["Expected"]["Public SSH Key Name"]);
			expect(requiredReturnMap["Actual"]["Public SSH Key"]).toBeDefined();
		});
	});

	it('TA - Virtual machine in AWS ---- Verify Order is listed in Orders details page once it is submitted from catalog page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			placeOrderPage.submitOrder();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			var orderId = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			ordersPage.open();
			expect(util.getCurrentURL()).toMatch(messageStrings.urlOrders);
			ordersPage.searchOrderById(orderId);
			expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderId);
			ordersPage.clickFirstViewDetailsOrdersTable();
			expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual(messageStrings.approvalState);
			expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
			expect(ordersPage.isDisplayedDenyButtonOrderDetails()).toEqual(true);
			ordersPage.clickServiceConfigurationsTabOrderDetails();
			expect(ordersPage.getTextBasedOnLabelName("Instance Plan")).toEqual((requiredReturnMap["Expected"]["Instance Plan"]));
			expect(ordersPage.getTextBasedOnLabelName("AWS Region Name")).toEqual((requiredReturnMap["Expected"]["AWS Region Name"]));
			expect(ordersPage.getTextBasedOnLabelName("Cloud Connection Name")).toEqual((requiredReturnMap["Expected"]["Cloud Connection Name"]));
			expect(ordersPage.getTextBasedOnLabelName("VPC Name tag")).toEqual((requiredReturnMap["Expected"]["VPC Name tag"]));
			expect(ordersPage.getTextBasedOnLabelName("Subnet Name")).toEqual((requiredReturnMap["Expected"]["Subnet Name"]));
			expect(ordersPage.getSshKeyBasedOnLabelName("Public SSH Key Name")).toEqual((requiredReturnMap["Expected"]["Public SSH Key Name"]));
			expect(ordersPage.getSshKeyBasedOnLabelName("Public SSH Key")).toEqual((requiredReturnMap["Expected"]["Public SSH Key"]));

			ordersPage.clickBillOfMaterialsTabOrderDetails();
		//	expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);

		});
	});

	it('TA -  Virtual machine in AWS -- Verify service details short and Long Desc', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
            catalogPage.searchForBluePrint(vmInAwsTemplate.bluePrintName);
			catalogPage.clickDetailsButtonBasedOnName(vmInAwsTemplate.bluePrintName);
			expect(catalogPage.getAvailableVersions()).toEqual(messageStrings.AvailableVersions);
			expect(catalogPage.getFeaturesText()).toEqual(messageStrings.featureText);
			expect(catalogPage.getlongDescription()).toEqual(messageStrings.longDescription);
			
	});

	it('TA - Check External context with AWS service ---- Verify Summary details and Additional Details are listed in review Order page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(externalContextTemplate.category);
		catalogPage.clickConfigureButtonBasedOnName(externalContextTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetailsICAM(externalContextTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
			expect(requiredReturnMap["Actual"]["Customer"]).toEqual(requiredReturnMap["Expected"]["Customer"]);
			expect(requiredReturnMap["Actual"]["Instance Plan"]).toEqual(requiredReturnMap["Expected"]["Instance Plan"]);
			expect(requiredReturnMap["Actual"]["AWS Region Name"]).toEqual(requiredReturnMap["Expected"]["AWS Region Name"]);
			expect(requiredReturnMap["Actual"]["Cloud Connection Name"]).toEqual(requiredReturnMap["Expected"]["Cloud Connection Name"]);
			expect(requiredReturnMap["Actual"]["VPC Name tag"]).toEqual(requiredReturnMap["Expected"]["VPC Name tag"]);
			expect(requiredReturnMap["Actual"]["Subnet Name"]).toEqual(requiredReturnMap["Expected"]["Subnet Name"]);
			expect(requiredReturnMap["Actual"]["Public SSH Key Name"]).toEqual(requiredReturnMap["Expected"]["Public SSH Key Name"]);
			expect(requiredReturnMap["Actual"]["Public SSH Key"]).toBeDefined();
		});
	});

	it('TA - Check External context with AWS service ---- Verify Order is listed in Orders details page once it is submitted from catalog page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(externalContextTemplate.category);
		catalogPage.clickConfigureButtonBasedOnName(externalContextTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetailsICAM(externalContextTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			placeOrderPage.submitOrder();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(externalContextTemplate.orderSubmittedConfirmationMessage);
			var orderId = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			ordersPage.open();
			expect(util.getCurrentURL()).toMatch(externalContextTemplate.urlOrders);
			ordersPage.searchOrderById(orderId);
			expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderId);
			ordersPage.clickFirstViewDetailsOrdersTable();
			expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual(externalContextTemplate.approvalState);
			expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
			expect(ordersPage.isDisplayedDenyButtonOrderDetails()).toEqual(true);
			ordersPage.clickServiceConfigurationsTabOrderDetails();
			expect(ordersPage.getTextOrderExternalcontext()).toEqual(externalContextTemplate.CustomerAsExternalcontext);
			expect(ordersPage.getTextBasedOnLabelName("Instance Plan")).toEqual((requiredReturnMap["Expected"]["Instance Plan"]));
			expect(ordersPage.getTextBasedOnLabelName("AWS Region Name")).toEqual((requiredReturnMap["Expected"]["AWS Region Name"]));
			expect(ordersPage.getTextBasedOnLabelName("Cloud Connection Name")).toEqual((requiredReturnMap["Expected"]["Cloud Connection Name"]));
			expect(ordersPage.getTextBasedOnLabelName("VPC Name tag")).toEqual((requiredReturnMap["Expected"]["VPC Name tag"]));
			expect(ordersPage.getTextBasedOnLabelName("Subnet Name")).toEqual((requiredReturnMap["Expected"]["Subnet Name"]));
			expect(ordersPage.getSshKeyBasedOnLabelName("Public SSH Key Name")).toEqual((requiredReturnMap["Expected"]["Public SSH Key Name"]));
			expect(ordersPage.getSshKeyBasedOnLabelName("Public SSH Key")).toEqual((requiredReturnMap["Expected"]["Public SSH Key"]));

			ordersPage.clickBillOfMaterialsTabOrderDetails();

		});
	});

	if (isProvisioningRequired == "true") {
		it('TA - Check External context with AWS service --- Verify Provision services', function () {
			var orderObject = {} 
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(externalContextTemplate.category);
			catalogPage.clickConfigureButtonBasedOnName(externalContextTemplate.bluePrintName);
			orderObject.servicename = ServiceNameExternalContextProv;
			orderFlowUtil.fillOrderDetailsICAM(externalContextTemplate, externalContextModifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(externalContextTemplate.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, externalContextTemplate.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(externalContextTemplate.completedState);

		});

		it('TA  : Check External context with AWS service ---- Verify Delete services-----', function () {
			var orderObject = {};
			orderObject.servicename = ServiceNameExternalContextProv;
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(externalContextTemplate.orderTypeDel);
			orderFlowUtil.approveDeletedOrder(orderObject);
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, externalContextTemplate.completedState);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(externalContextTemplate.completedState)
		});

		it('TA - Virtual machine in AWS --- Verify Cancel Order by just placing order and cancelling it from order history.', function() {
			var orderObject = {};
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			placeOrderPage.getTextOrderNumberOrderSubmittedModal().then(function (orderNumber){
				orderObject.orderNumber=orderNumber;
			var orderNum = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderHistoryPage.searchOrderClickCancelOrder(orderObject.orderNumber)
			orderHistoryPage.clickOnOrderTableActionsCancelYesButton();
			messageStrings.cancelOrderSuccessMsg  = messageStrings.cancelOrderSuccessMsg+" "+orderNumber;
			expect(orderHistoryPage.getTextCancelOrderSuccessFulMsg()).toContain(messageStrings.cancelOrderSuccessMsg);
			orderHistoryPage.clickCancelOrderOkButton();
			inventoryPage.open(); //random click
			orderFlowUtil.waitForOrderStatusChangeInOrderHistory(orderObject,messageStrings.cancelledStatus)
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.cancelledStatus);
		
			});	});

		it('TA - Virtual machine in AWS --- Verify cancel flow for Failed order.', function () {
			var orderObject = {} 
			var modifiedParamMap = { "Service Instance Name":serviceName,
			"Subnet Name": SubnetName,"VPC Name tag": vpc};
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
		//	orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.orderFailedStatus);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.orderFailedStatus);
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == messageStrings.orderFailedStatus) {                    
                    orderHistoryPage.open();
                    orderHistoryPage.searchOrderById(orderObject.orderNumber);
					util.waitForCircleStrokeToDisappear();
                    orderHistoryPage.clickOnOrderTableDetailsExpandArrow();
                    orderHistoryPage.clickOrdersTableActionIcon();
                    orderHistoryPage.clickOnOrderTableActionsCancelOptionXpath();
                    orderHistoryPage.clickOfJustPlaceOrderYesButton();
					orderHistoryPage.clickCancelOrderOkButton();
					inventoryPage.open(); //random click

					orderFlowUtil.waitForOrderStatusChangeInOrderHistory(orderObject,messageStrings.cancelledStatus)
					expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.cancelledStatus);
					
                }
            })
		});

		it('TA - Virtual machine in AWS --- Verify Retry flow for Failed order and check service and resource log present or not..', function () {
			var orderObject = {}
			var modifiedParamMap = {
				"Service Instance Name": serviceName,
				"Subnet Name": SubnetName, "VPC Name tag": vpc
			};
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
		    //orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.orderFailedStatus);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.orderFailedStatus);
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
			    if (status == messageStrings.orderFailedStatus) {                    
			orderHistoryPage.open();
			orderHistoryPage.searchOrderById(orderObject.orderNumber);
			util.waitForAngular();
			orderHistoryPage.clickOnOrderTableDetailsExpandArrow();
			orderHistoryPage.clickOrdersTableActionIcon();
			orderHistoryPage.clickOnOrderTableActionsRetryOption();
			orderHistoryPage.clickOnOrderTableActionsRetryYesButton();
			orderHistoryPage.clickOnOrderTableActionsRetryModelOkButton();
			// orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provisiongstatus).then(function () {
			// expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.provisiongstatus);
			// });				
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.orderFailedStatus).then(function () {
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.orderFailedStatus);
			expect(orderHistoryPage.getOrderFailureReason(orderObject.orderNumber)).toContain(messageStrings.failedLogsText);
			orderHistoryPage.ClickOnViewFailureLink();
			orderHistoryPage.ClickOnViewLogsLink();
			expect(orderHistoryPage.checkServiceLogsTab()).toBe(true);
			expect(orderHistoryPage.checkResourceLogsTab()).toBe(true);
			orderHistoryPage.checkserviceLogTextPresent();
			var servicelogText=orderHistoryPage.checkserviceLogTextPresent();
			expect(servicelogText).toContain(messageStrings.servicelogText);
			orderHistoryPage.clickonResourceLog();
			var resourcelogText=orderHistoryPage.checkResourceLogTextPresent();
			expect(resourcelogText).toContain(messageStrings.resourcelogText);
			});
		}
	})
});
		
		it('TA - Virtual machine in AWS --- Verify deny order,order is rejected by user..', function () {
			var orderObject = {}
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
			orderObject.servicename = serviceNameProv;
			orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap2);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.denyOrder(orderObject);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.DenyStatus);	
});

		it('TA - Virtual machine in AWS --- Verify Provision services', function () {
			var orderObject = {} 
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
			orderObject.servicename = serviceNameProv;
			orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap2);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			//orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);

		});


		it('TA  : Virtual machine in AWS ---- Verify Service logs from invenory-----', function () {
			var orderObject = {};
			orderObject.servicename = serviceNameProv;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			util.waitForAngular();
			inventoryPage.clickViewDetailsLink();
			inventoryPage.clickOnServiceLogsTab();
			expect(inventoryPage.checkServiceLogsTab()).toBe(true);
			expect(inventoryPage.checkResourceLogsTab()).toBe(true);
			expect(inventoryPage.checkserviceLogTextPresent()).toContain(messageStrings.SuccessLogMsg);
			expect(inventoryPage.checkRefreshLinkCss()).toBe(true);
			expect(inventoryPage.checkExportLinkIsPresent()).toBe(true);
			expect(inventoryPage.ServiceInstanceNameTextPresent()).toContain(orderObject.servicename);
		});

		it('TA - Virtual machine in AWS ---- Verify is instance present or not ', function () {
			var orderObject = {};
			orderObject.servicename = serviceNameProv;
			catalogDiscoveryObj.open();
			catalogDiscoveryObj.clickOnPublishSectionLink();
			catalogDiscoveryObj.searchServiceOrProviderName(vmInAwsTemplate.bluePrintName);
			catalogDiscoveryObj.clickOnThreeDotMenuIcon(vmInAwsTemplate.bluePrintName);
			catalogDiscoveryObj.clickOnviewInstanceLink();
			catalogDiscoveryObj.searchForServiceInstanceName(orderObject.servicename);
			util.waitForCircleStrokeToDisappear();
			expect(catalogDiscoveryObj.isServiceInstancePresent(orderObject.servicename)).toContain(orderObject.servicename);
		});

		//Validation message verify for start on start VM
		it('TA: AWS Virtual Machine- Verify for Start Virtual machine, when VM is turned ON, Validation should come up', function () {
			var orderObject = {};
			orderObject.servicename = serviceNameProv;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
					inventoryPage.clickTurnONButtonOfInstanceNegativeIcam()
					inventoryPage.placeD2opsOrder();
					expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.MessageForStartOnStart);
					util.waitForAngular();
				});
			})
		});

		//Stop operation
		it('TA: AWS Virtual Machine  - Verify for Stop Virtual machine, when VM is turned OFF, status should get changed from ON to OFF', function () {
			var orderObject = {};
			orderObject.servicename = serviceNameProv;

			inventoryPage.open();

			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
					inventoryPage.clickTurnOFFButtonOfInstanceIcam();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnOFFPermission();
					util.waitForAngular();

				});
			}).then(function () {
				var orderObject = JSON.parse(JSON.stringify(vmInAwsTemplate));
				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();
				orderFlowUtil.approveOrder(orderObject);
				orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);

			});
		});

		//Validation message verify for stop on stop VM
		it('TA: AWS Virtual Machine- Verify for Stop Virtual machine, when VM is turned OFF already, Validation should come up', function () {
			var orderObject = {};
			orderObject.servicename = serviceNameProv;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
					inventoryPage.clickTurnOFFButtonOfInstanceIcam()
					inventoryPage.placeD2opsOrder();
					expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.MessageForStopOnStop);
					util.waitForAngular();

				});
			})
		});

		it('TA: AWS Virtual Machine  - Verify for Start Virtual machine, when VM is turned ON, status should get changed from OFF to ON', function () {
			var orderObject = {};
			orderObject.servicename = serviceNameProv;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
					inventoryPage.clickTurnONButtonOfInstanceNegativeIcam();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnOFFPermission();

					util.waitForAngular();

				});
			}).then(function () {
				var orderObject = JSON.parse(JSON.stringify(vmInAwsTemplate));

				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();
				orderFlowUtil.approveOrder(orderObject);
				orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);

			});

		});

		//taint operation
		it('TA: AWS Virtual Machine - Verify for Start Virtual machine, taint operation is working fine or not', function () {
			var orderObject = {};
			orderObject.servicename = serviceNameProv;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
					inventoryPage.clickTaintONButtonOfInstanceIcam();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnOFFPermission();
					util.waitForAngular();
				});
			}).then(function () {
				var orderObject = JSON.parse(JSON.stringify(vmInAwsTemplate));

				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();
				orderFlowUtil.approveOrder(orderObject);
				orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);

			});

		});

		//untaint operation
		it('TA: AWS Virtual Machine  - Verify for Start Virtual machine, untaint operation is working fine or not', function () {
			var orderObject = {};
			orderObject.servicename = serviceNameProv;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
					inventoryPage.clickUntaintONButtonOfInstanceIcam();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnOFFPermission();
					util.waitForAngular();
				});
			}).then(function () {
				var orderObject = JSON.parse(JSON.stringify(vmInAwsTemplate));

				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();
				orderFlowUtil.approveOrder(orderObject);
				orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);

			});

		});

		//Shutdown operation
		it('TA: AWS Virtual Machine  - Verify for Shutdown Virtual machine, when VM is turned ON, status should get changed from ON to OFF', function () {
			var orderObject = {};
			orderObject.servicename = serviceNameProv;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
					inventoryPage.icamClickShutdownButtonOfInstance();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnOFFPermission();
					util.waitForAngular();
				});

			}).then(function () {
				var orderObject = JSON.parse(JSON.stringify(vmInAwsTemplate));

				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();
				orderFlowUtil.approveOrder(orderObject);
				orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
			});

		});

		it('TA  : ICAM-ON Virtual machine in AWS ---- Verify Delete services-----', function () {
			var orderObject = {};
			orderObject.servicename = serviceNameProv;
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
			orderFlowUtil.approveDeletedOrder(orderObject);
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState)
		});

		it('ICAM : ICAM-ON Virtual machine in AWS - Deleted filter validation in inventory',function() {
			var orderObject = {};
			orderObject.servicename = serviceNameProv;
			inventoryPage.open();
			inventoryPage.clickRightChevronToExpandFilter();
			inventoryPage.clickClearAllFilter();
			//inventoryPage.clickRightChevronToExpandFilter();
			inventoryPage.clickDeletedCheckboxFromFilter();
			inventoryPage.clickOnApplyFilter();
		    inventoryPage.searchOrderByServiceName(orderObject.servicename);
		    var statusAfterApplyingFilter=inventoryPage.getTextStatusAfterApplyingFilter();
		    expect(statusAfterApplyingFilter).toEqual(messageStrings.deletedStatus);
		    var serviceNameAfterApplyingFilter=inventoryPage.getServiceNameAfterApplyingFilter();
		    expect(serviceNameAfterApplyingFilter).toContain(orderObject.servicename);
	});
	
	it('ICAM : ICAM-ON Regex AWS ---- Verify that for Regex AWS Virtual Machine dynamic validation is working or not', function () {

		var modifiedParamMap3 = {
		"dynamicValidation":true,"Service Instance Name": serviceName,"Subnet Name": SubnetName, "VPC Name tag": vpc,"Public SSH Key":"sshkeyvalue"}
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
		placeOrderPage.setServiceNameTextICAM("TA-automation-Regex-" + util.getRandomString(4));
		placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
		placeOrderPage.clickNextButton();
		orderFlowUtil.fillOrderDetails(vmInAwsTemplate,modifiedParamMap3);
		placeOrderPage.setsshkeyValueText(messageStrings.sshValue);
		placeOrderPage.setsshKeyNamecssText(messageStrings.sshKeyName);
		expect(placeOrderPage.getTextsshKeyError()).toContain(messageStrings.RegxErrorMsg);
	});
  }
});
