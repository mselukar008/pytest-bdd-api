"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../testData/appUrls.json'),
    vmInstanceTemplate = require('../../../../testData/OrderIntegration/IM/vm.json');

describe('IM - VM', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, vmInsObj, vmName, inventoryPage, msgToVerify;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = vmInstanceTemplate.componentType;
    var messageStrings = {
        providerName: vmInstanceTemplate.provider,
        category: vmInstanceTemplate.Category,
        orderSubmittedConfirmationMessage: vmInstanceTemplate.orderSubmittedConfirmationMessage,
        provInProgressState: vmInstanceTemplate.provInProgressState,
        completedState: vmInstanceTemplate.completedState,
        powerStateOff: vmInstanceTemplate.powerStateOff,
        powerStateOn: vmInstanceTemplate.powerStateOn,
        orderTypeAction: vmInstanceTemplate.orderTypeAction,        
        serviceOfferingTurnOff: "Turn OFF",
        serviceOfferingTurnOn: "Turn ON",
        serviceOfferingReboot: "Reboot",
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "cp4mcm-vm-" + util.getRandomString(5);
        vmName = "autovm-" + util.getRandomString(5);
    });
    
    it('VM Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        modifiedParamMap = { "Service Instance Name": serviceName, "VM Name": vmName,  "UpdateMainParamObject": false };
        catalogPage.open();
        vmInsObj = JSON.parse(JSON.stringify(vmInstanceTemplate));
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(vmInstanceTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(vmInstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            //As pricing is dummy for CF dependent on pricing json, no need to validate it. Commenting below line
            //expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(vmInstanceTemplate.TotalCost); 
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["CPU"]).toEqual(requiredReturnMap["Expected"]["CPU"]);
            expect(requiredReturnMap["Actual"]["RAM"]).toEqual(requiredReturnMap["Expected"]["RAM"]);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(vmInstanceTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, vmInstanceTemplate.completedState);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vmInstanceTemplate.completedState);
                 //As pricing is dummy for CF dependent on pricing json, no need to validate it. Commenting below line
                //Validate Estimated price on approve order page
                //expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(vmInstanceTemplate.EstimatedPrice);
                //Validate pricing on order history page
               // ordersHistoryPage.open();
               // ordersHistoryPage.searchOrderById(orderObject.orderNumber);
               // expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(vmInstanceTemplate.EstimatedPrice);
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();

            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("CPU")).toEqual(jsonUtil.getValue(vmInsObj, "CPU"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("RAM")).toEqual(jsonUtil.getValue(vmInsObj, "RAM"));

//             ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
//             expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(vmInstanceTemplate.TotalCost);
//             ordersHistoryPage.closeServiceDetailsSlider();
//             ordersHistoryPage.clickBillOfMaterials();
//             expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(vmInstanceTemplate.TotalCost);
             ordersHistoryPage.closeServiceDetailsSlider();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("RAM")).toEqual(jsonUtil.getValue(vmInsObj, "RAM"));
            expect(ordersPage.getTextBasedOnLabelName("CPU")).toEqual(jsonUtil.getValue(vmInsObj, "CPU"));

//          ordersPage.clickBillOfMaterialsTabOrderDetails();
//          expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(vmInstanceTemplate.TotalCost);
            ordersPage.clickServiceDetailSliderCloseButton();
        });
    });

    it('VM Verify View Component-Template Output Parameters for the powered ON instance', function () {
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickViewComponentofAWSInstance().then(function () {
                    //View Component VM details
                    expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(vmInstanceTemplate.componentType);
                    expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelName("Name")).toEqual(vmInstanceTemplate.bluePrintName);
                    expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Status")).toEqual(messageStrings.powerStateOn);
                    expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);
                    inventoryPage.closeViewComponent();
                    inventoryPage.clickExpandFirstRow();
                });
            });
        });
    });   

    it('VM Verify instance Turn OFF functionality', function () {               
        orderObject.servicename = serviceName;        
        var status = messageStrings.powerStateOff;
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            browser.executeScript('window.scrollTo(0,0);');
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                    inventoryPage.clickOkForInstanceTurnOFFPermission();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(vmInstanceTemplate.bluePrintName, "TurnOff");
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingTurnOff);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe(status);
            });
        });
    });      

    it('VM Verify instance Turn ON functionality', function () {
        orderObject.servicename = serviceName;        
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            browser.executeScript('window.scrollTo(0,0);');
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickTurnONButtonOfInstance().then(function () {
                    inventoryPage.clickOkForInstanceTurnONPermission();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(vmInstanceTemplate.bluePrintName, "TurnOn");
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingTurnOn);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
            });
        });
    });

    it('VM Verify instance Reboot functionality', function () {
        orderObject.servicename = serviceName;        
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            browser.executeScript('window.scrollTo(0,0);');
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickRebootButtonOfInstance().then(function () {
                    inventoryPage.clickOkForInstanceRebootPermission();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(vmInstanceTemplate.bluePrintName, "Reboot");
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingReboot);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
                browser.sleep(1000);
                inventoryPage.clickExpandFirstRow();
            });
        });

    });

    it('VM Validate system tags, Edit and Delete Service', function () {
        //Edit service flow
        var modifiedParamMap = { "EditService": true };
        orderFlowUtil.editService(orderObject);
        orderFlowUtil.fillOrderDetails(vmInstanceTemplate, modifiedParamMap).then(function (reviewOrderExpActParamsMap) {
            logger.info("Edit parameter details are filled.");
           // expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(vmInstanceTemplate.TotalCostPostEdit);
           // browser.sleep(5000);
            //Validate Review order page parameters
            expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
        });
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(vmInstanceTemplate.bluePrintName, "Edit");
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, vmInstanceTemplate.completedState);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == vmInstanceTemplate.completedState) {
                //Verify updated details are reflected on order details page.						
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelName("CPU")).toEqual(jsonUtil.getValueEditParameter(vmInstanceTemplate, "CPU"));
//                 ordersPage.clickBillOfMaterialsTabOrderDetails();
//                 expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(vmInstanceTemplate.TotalCostPostEdit);
                ordersPage.clickServiceDetailSliderCloseButton();
                //Delete Service flow                    
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, vmInstanceTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, vmInstanceTemplate.completedState);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(vmInstanceTemplate.completedState);
            }
        });
    });
});
