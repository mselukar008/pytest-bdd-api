//Author: Atiksha Batra
"use strict";
var logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    async = require('async'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    HyperScaleserverTemplate = require('../../../../testData/OrderIntegration/Azure/hyperScaleServer.json');

describe('Azure - Azure Hyperscale (Citus) server group Service ', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, servicename, SOIComponents;
    var modifiedParamMap = {};
    var servicename = "AutoHyperScalesrv" + util.getRandomString(5);
    var newResourceGroupName = "gslautotc_azureHyperScale-RG101" + util.getRandomString(4);
    var serverGroupName = "autoservergrp" + util.getRandomString(4);
    serverGroupName = serverGroupName.toLowerCase();
    var messageStrings = { providerName: 'Azure', category: 'Databases', templateName: 'Hyperscale (Citus) server group' };
    var hyperScaleComponent1 = serverGroupName + "-c";
    var hyperScaleComponent2 = serverGroupName + "-w0"
    var hyperScaleComponent3 = serverGroupName + "-w1"
    SOIComponents = [serverGroupName, serverGroupName, serverGroupName, serverGroupName]
    modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Server Group Name": serverGroupName };
    

    beforeAll(function () {
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    afterAll(function () {
        // Delete Azure Database for MySQL servers 
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    it('Azure: Verify that for Azure Hyperscale (Citus) server group required parameters on Service Details Page are present.', function () {
        var hyperScaleServerObject = JSON.parse(JSON.stringify(HyperScaleserverTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(hyperScaleServerObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(hyperScaleServerObject.bluePrintName);
        if (browser.params.defaultCurrency == "USD") {
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(hyperScaleServerObject.BasePrice);
        }
    });

    it('Azure: Verify Review order and View Order Details for Azure Hyperscale (Citus) server group', function () {
        var orderObject = {};
        orderObject.servicename = servicename;
        var hyperScaleServerObject = JSON.parse(JSON.stringify(HyperScaleserverTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(hyperScaleServerObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(hyperScaleServerObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(HyperScaleserverTemplate, modifiedParamMap);
        //Verify input values on Review Order page    
        expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "New Resource Group Required"));
        expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
        expect(placeOrderPage.getTextBasedOnLabelName("Location:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Server Group Name:")).toEqual(serverGroupName);
        expect(placeOrderPage.getTextBasedOnLabelName("Server Location:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Server Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Worker Node Count:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Worker Node Count"));
        expect(placeOrderPage.getTextBasedOnLabelName("Worker vCore:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Worker vCore"));
        expect(placeOrderPage.getTextBasedOnLabelName("Worker Storage:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Worker Storage"));
        expect(placeOrderPage.getTextBasedOnLabelName("Coordinator vCore:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Coordinator vCore"));
        expect(placeOrderPage.getTextBasedOnLabelName("Coordinator Storage:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Coordinator Storage"));
        expect(placeOrderPage.getTextBasedOnLabelName("Enable High Availability:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Enable High Availability"));
        expect(placeOrderPage.getTextBasedOnLabelName("Connectivity Method:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Connectivity Method"));
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(orderObject.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(orderObject.servicename);//Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe('Azure');//Checking Provider
        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "New Resource Group Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(newResourceGroupName);
        expect(ordersPage.getTextBasedOnExactLabelName("Server Group Name")).toEqual(serverGroupName);
        expect(ordersPage.getTextBasedOnExactLabelName("Server Location")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Server Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("Worker Node Count")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Worker Node Count"));
        expect(ordersPage.getTextBasedOnExactLabelName("Worker vCore")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Worker vCore"));
        expect(ordersPage.getTextBasedOnExactLabelName("Worker Storage")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Worker Storage"));
        expect(ordersPage.getTextBasedOnExactLabelName("Coordinator vCore")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Coordinator vCore"));
        expect(ordersPage.getTextBasedOnExactLabelName("Coordinator Storage")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Coordinator Storage"));
        expect(ordersPage.getTextBasedOnExactLabelName("Enable High Availability")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Enable High Availability"));
        expect(ordersPage.getTextBasedOnExactLabelName("Connectivity Method")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Connectivity Method"));
        //Checking Bill Of Material
        if (browser.params.defaultCurrency == "USD") {
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(ordersPage.getEstimatedCost()).toBe(hyperScaleServerObject.TotalCost);
        }
        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
    });

    if (isProvisioningRequired == "true") {
        if (isDummyAdapterDisabled == "false") {
            it('Azure: Verify provisioning of Azure Hyperscale (Citus) server group using Consume UI', function () {
                var orderObject = {};
                orderObject.servicename = servicename;
                var hyperScaleServerObject = JSON.parse(JSON.stringify(HyperScaleserverTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(hyperScaleServerObject.Category);
                catalogPage.clickConfigureButtonBasedOnName(hyperScaleServerObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(HyperScaleserverTemplate, modifiedParamMap);
                placeOrderPage.submitOrder();
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                inventoryPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                inventoryPage.clickViewService();
                //Checking Inventory Page Service Configuration
                expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                expect(inventoryPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "New Resource Group Required"));
                expect(inventoryPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
                expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Location"));
                expect(inventoryPage.getTextBasedOnLabelName("Server Group Name:")).toEqual(serverGroupName);
                expect(inventoryPage.getTextBasedOnLabelName("Server Location:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Server Location"));
                expect(inventoryPage.getTextBasedOnLabelName("Worker Node Count:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Worker Node Count"));
                expect(inventoryPage.getTextBasedOnLabelName("Coordinator vCore:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Coordinator vCore"));
                expect(inventoryPage.getTextBasedOnLabelName("Coordinator Storage:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Coordinator Storage"));
                expect(inventoryPage.getTextBasedOnLabelName("Enable High Availability:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Enable High Availability"));
                expect(inventoryPage.getTextBasedOnLabelName("Connectivity Method:")).toEqual(jsonUtil.getValue(hyperScaleServerObject, "Connectivity Method"));
                inventoryPage.closeViewDetailsTab();
                //check Non-Editable service Message
                inventoryPage.clickNonEditableInstance();
                expect(inventoryPage.getTextForInvalidEditModal()).toEqual(HyperScaleserverTemplate.nonEditableText);
                inventoryPage.clickOnInvalidEditOkModal();
            });
        }
    }
});
