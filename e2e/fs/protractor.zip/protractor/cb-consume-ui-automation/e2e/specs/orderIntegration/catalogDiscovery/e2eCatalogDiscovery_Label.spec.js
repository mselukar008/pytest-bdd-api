/********************
  Author : Pushpraj
 ********************/

"use strict";
var CatalogDiscoveryPage   = require('../../../pageObjects/catalogDiscovery.pageObject.js'),
	CatalogPage   		   = require('../../../pageObjects/catalog.pageObject.js'),
	CatalogDetailsPage     = require('../../../pageObjects/catalogdetails.pageObject.js'),
	util                   = require('../../../../helpers/util.js'),
	appUrls 			   = require('../../../../testData/appUrls.json'),
	logGenerator 	       = require("../../../../helpers/logGenerator.js"),
	logger 			       = logGenerator.getApplicationLogger(),
	catalogDiscoveryApi    = require('../../../../helpers/APIs/catalogDiscoveryServicesAPI.js'),
	catalogDiscoveryData   = require('../../../../testData/OrderIntegration/catalogDiscovery/catalogDiscovery_testData.json'),
	centos70_json_payload  = require('../../../../testData/OrderIntegration/catalogDiscovery/centos70_vRA75Payload.json');



describe('Add labels in Draft WIP & Published service state - ', function() {
	var catalogDiscoveryObj;	
	var catalogPageObj;
	var catalogDetailsObj;
	var catalogDiscvrydata;
	var centos70_payLoad;

	beforeAll(function() {
		catalogPageObj = new CatalogPage();
		catalogDetailsObj = new CatalogDetailsPage();
		catalogDiscoveryObj = new CatalogDiscoveryPage();
		browser.driver.manage().window().maximize();
		catalogDiscvrydata = JSON.parse(JSON.stringify(catalogDiscoveryData));
		centos70_payLoad = JSON.parse(JSON.stringify(centos70_json_payload));
	});

	beforeEach(function() {
		browser.waitForAngularEnabled();
		catalogDiscoveryObj.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogAdminUrl);
	});


	it('start catalog discovery for VRA from catalog Admin page', function(){
		catalogDiscoveryObj.clickOnStartCatalogDiscoveryBtn();
		catalogDiscoveryObj.clickOnProviderToStartDiscovery(catalogDiscvrydata.serviceCategoryProvider);
		catalogDiscoveryObj.selectVraAccountFromDrpDwn(catalogDiscvrydata.serviceAccount);
		catalogDiscoveryObj.clickOnOKBtnFromDiscoveryPopup();
		expect(catalogDiscoveryObj.getDiscoveryStartedPopupMsg()).toEqual(catalogDiscvrydata.discoveryStartedPopMsg);
		catalogDiscoveryObj.discoveryStartedPopup();
		catalogDiscoveryObj.open();
		expect(catalogDiscoveryObj.getDiscoveryStatus()).toMatch(catalogDiscvrydata.discoveryStatusInProgress);
	});

	it('verify VRA Catalog discovery status', function(){
		catalogDiscoveryObj.waitToCompletDiscoveryStatus();
		logger.info("Current date "+catalogDiscoveryObj.currenDate());
		expect(catalogDiscoveryObj.getDiscoveryStatus()).toMatch(catalogDiscoveryObj.currenDate());
		catalogDiscoveryObj.clickOnVraHistoryLink();
		expect(catalogDiscoveryObj.getHistoryPageTitleText()).toMatch(catalogDiscvrydata.historyPageTitle);
		expect(catalogDiscoveryObj.getHeaderTextFromHistorySec()).toMatch(catalogDiscoveryObj.currenDate());
		expect(catalogDiscoveryObj.getStatusFromHistorySec()).toEqual(catalogDiscvrydata.discoveryStatusCompleted);
		expect(catalogDiscoveryObj.getAccountNameFromHistroySec()).toEqual(catalogDiscvrydata.serviceAccount);
	});

	it('Add the label and pricing json in draft state of service', async function(){
		catalogDiscoveryObj.getheaderTitleText().then(async function(){
			await catalogDiscoveryApi.putServiceCallForDraftToWIP(centos70_payLoad).then(function(obj){
				expect(200).toEqual(obj["statusCode"]);
				expect("OK").toEqual(obj["status"]);
				expect(catalogDiscvrydata.serviceId + "_WIP").toEqual(obj["id"]);
			});
		});
		catalogDiscoveryObj.clickOnDraftSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getServiceNameFromDraftSearchSection()).toEqual(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getEditedServiceStatus(catalogDiscvrydata.serviceName)).toEqual(catalogDiscvrydata.serviceStatusWIP);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnViewDetailsLink()
		expect(catalogDiscoveryObj.getLabelsNameFromViewDetails()).toContain(catalogDiscvrydata.labelsDraft);
		catalogPageObj.open();
		catalogPageObj.selectLabelsFilter(catalogDiscvrydata.labelsDraft);
		catalogPageObj.isDisplayedDetailsButtonBasedOnName(catalogDiscvrydata.serviceName);
		catalogPageObj.clickDetailsButtonBasedOnName(catalogDiscvrydata.serviceName);
		expect(catalogDetailsObj.getServiceName()).toEqual(catalogDiscvrydata.serviceName);
		expect(catalogDetailsObj.getLabelsName()).toEqual(catalogDiscvrydata.labelsDraft);
	});

	it('Add lable in WIP state of service', function(){
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getServiceNameFromDraftSearchSection()).toEqual(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnViewDetailsLink();
		catalogDiscoveryObj.clickOnEditButton();
		catalogDiscoveryObj.removeAllLabelFromEditServiceConf();
		catalogDiscoveryObj.addLabelInEditServiceConf(catalogDiscvrydata.labelsWIP);
		catalogDiscoveryObj.clickOnSaveBtn();
		catalogDiscoveryObj.open();
		catalogDiscoveryObj.clickOnDraftSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getEditedServiceStatus(catalogDiscvrydata.serviceName)).toEqual(catalogDiscvrydata.serviceStatusWIP);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnViewDetailsLink();
		expect(catalogDiscoveryObj.getLabelsNameFromViewDetails()).toContain(catalogDiscvrydata.labelsWIP);
		catalogPageObj.open();
		catalogPageObj.selectLabelsFilter(catalogDiscvrydata.labelsWIP);
		catalogPageObj.isDisplayedDetailsButtonBasedOnName(catalogDiscvrydata.serviceName);
		catalogPageObj.clickDetailsButtonBasedOnName(catalogDiscvrydata.serviceName);
		expect(catalogDetailsObj.getServiceName()).toEqual(catalogDiscvrydata.serviceName);
		expect(catalogDetailsObj.getLabelsName()).toEqual(catalogDiscvrydata.labelsWIP);
	});

	it('Publish drafted service and validate the service in Published section', function(){
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnPublishService();
		catalogDiscoveryObj.getAlertNotificationTitle();
		catalogDiscoveryObj.getAlertNotificationSubTitle();
		catalogDiscoveryObj.getAlertNotificationCaption();
		expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(catalogDiscvrydata.publishSuccessfull);
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);		
		expect(catalogDiscoveryObj.getPublishedSerivceDate()).toMatch(catalogDiscoveryObj.currenDate());
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceName);
	});


	it('Add lable in published state of service', function(){
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnViewDetailsLink();
		catalogDiscoveryObj.clickOnEditButton();
		catalogDiscoveryObj.removeAllLabelFromEditServiceConf();
		catalogDiscoveryObj.addLabelInEditServiceConf(catalogDiscvrydata.labelsPublished);
		catalogDiscoveryObj.clickOnSaveBtn();
		catalogDiscoveryObj.open();
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnViewDetailsLink()
		expect(catalogDiscoveryObj.getLabelsNameFromViewDetails()).toContain(catalogDiscvrydata.labelsPublished);

		catalogPageObj.open();
		catalogPageObj.selectLabelsFilter(catalogDiscvrydata.labelsPublished);
		catalogPageObj.isDisplayedDetailsButtonBasedOnName(catalogDiscvrydata.serviceName);
		catalogPageObj.clickDetailsButtonBasedOnName(catalogDiscvrydata.serviceName);
		expect(catalogDetailsObj.getServiceName()).toEqual(catalogDiscvrydata.serviceName);
		expect(catalogDetailsObj.getLabelsName()).toEqual(catalogDiscvrydata.labelsPublished);
	});

	it('Add multiple lables in published state of service', function(){
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnViewDetailsLink();
		catalogDiscoveryObj.clickOnEditButton();
		catalogDiscoveryObj.removeAllLabelFromEditServiceConf();
		catalogDiscoveryObj.addLabelInEditServiceConf(catalogDiscvrydata.labelsPublished);
		catalogDiscoveryObj.addLabelInEditServiceConf(catalogDiscvrydata.labelsWIP);
		catalogDiscoveryObj.addLabelInEditServiceConf(catalogDiscvrydata.labelsDraft);
		catalogDiscoveryObj.clickOnSaveBtn();
		catalogDiscoveryObj.open();
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnViewDetailsLink()
		expect(catalogDiscoveryObj.getLabelsNameFromViewDetails()).toContain(catalogDiscvrydata.labelsPublished);

		catalogPageObj.open();
		catalogPageObj.selectLabelsFilter(catalogDiscvrydata.labelsPublished);
		catalogPageObj.selectLabelsFilter(catalogDiscvrydata.labelsWIP);
		catalogPageObj.selectLabelsFilter(catalogDiscvrydata.labelsDraft);
		catalogPageObj.isDisplayedDetailsButtonBasedOnName(catalogDiscvrydata.serviceName);
		catalogPageObj.clickDetailsButtonBasedOnName(catalogDiscvrydata.serviceName);
		expect(catalogDetailsObj.getServiceName()).toEqual(catalogDiscvrydata.serviceName);
		expect(catalogDetailsObj.getLabelsName()).toContain(catalogDiscvrydata.labelsPublished);
		expect(catalogDetailsObj.getLabelsName()).toContain(catalogDiscvrydata.labelsWIP);
		expect(catalogDetailsObj.getLabelsName()).toContain(catalogDiscvrydata.labelsDraft);
	});

	it('retire the Published service and verify it in Retired section', function(){
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);	
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnRetireServiceOption();
		catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
		catalogDiscoveryObj.getAlertNotificationTitle();
		catalogDiscoveryObj.getAlertNotificationSubTitle();
		catalogDiscoveryObj.getAlertNotificationCaption();
		catalogDiscoveryObj.clickOnRetiredSectionLink();
		expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(catalogDiscvrydata.retireSuccessfull);
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceName);
	});

	it('delete the retired service from Retired section and verify from API', async function(){
		catalogDiscoveryObj.clickOnRetiredSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);	
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnDeleteServiceOption();
		catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
		catalogDiscoveryObj.getAlertNotificationTitle();
		catalogDiscoveryObj.getAlertNotificationSubTitle();
		catalogDiscoveryObj.getAlertNotificationCaption();
		expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(catalogDiscvrydata.successMsg);
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);		
		expect(catalogDiscoveryObj.getNoDataAvailableTextPublishedSection()).toEqual(catalogDiscvrydata.noDataAvailabe);
		catalogDiscoveryObj.getheaderTitleText().then(async function(){
			let msg = await catalogDiscoveryApi.deletePublishedService(catalogDiscvrydata.serviceId);
			expect(msg).toEqual(catalogDiscvrydata.rows_affected);
		});
	});

});
