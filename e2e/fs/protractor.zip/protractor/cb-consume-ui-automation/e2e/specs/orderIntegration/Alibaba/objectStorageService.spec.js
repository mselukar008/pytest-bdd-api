/*************************************************
DESCRIPTION: The test script verifies the OSS Service functionality    
AUTHOR: Leena Chouhan
**************************************************/
"use strict";
var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    ossTemplate = require('../../../../testData/OrderIntegration/Alibaba/ObjectStorageService.json')

describe('Tests for Alibaba : oss Service in detail', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, homePage;
    var modifiedParamMap = {};
    var servicename = "Gsl-Auto-OSS" + util.getRandomString(5);
    var messageStrings = {
        providerName: 'Alibaba Cloud',
        category: 'Storage'
    };

    beforeAll(function () {
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        modifiedParamMap = {
            "Service Instance Name": servicename,
        };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    afterAll(function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    if (isProvisioningRequired == "true") {
        it('Aalibaba:TC-1 OSS -Verify Inventory / output parameters Details', function () {
            var orderObject = JSON.parse(JSON.stringify(ossTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            var returnObj = {};
            orderFlowUtil.fillOrderDetails(ossTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, orderObject.OrderStatus);

            //checking order on Inventory Page 
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();

            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
            expect(inventoryPage.getTextBasedOnLabelName(" Bucket Name:")).toEqual(jsonUtil.getValue(orderObject, "Bucket Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Storage Class:")).toEqual(jsonUtil.getValue(orderObject, "Storage Class"));
            expect(inventoryPage.getTextBasedOnLabelName(" Access Control List:")).toEqual(jsonUtil.getValue(orderObject, "Access Control List"));
            expect(inventoryPage.getTextBasedOnLabelName(" Encryption Method:")).toEqual(jsonUtil.getValue(orderObject, "Encryption Method"));
            inventoryPage.closeViewDetailsTab();
        });
    }

    it('Aalibaba:TC-2 OSS- Verify Alibaba OSS Main Page parameters', function () {
        var orderObject = JSON.parse(JSON.stringify(ossTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);

        expect(catalogDetailsPage.getServiceName()).toBe(orderObject.bluePrintName)
        expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true);
        expect(catalogDetailsPage.isPresentLinkToProviderSite()).toBe(true);
        expect(catalogDetailsPage.isPresentFeaturesLabel()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsLabel()).toBe(true);
        expect(catalogDetailsPage.getTextFeaturesLabel()).toBe(orderObject.FeaturesLabel);
        expect(catalogDetailsPage.getTextDetailsLabel()).toBe(orderObject.DetailsLabel);
        expect(catalogDetailsPage.isPresentFeaturesInfo()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsInfo()).toBe(true);
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);

        catalogDetailsPage.clickCatalogFromBreadCrumbNav();
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
        homePage.open();
    });

    it('Aalibaba:TC-3 OSS - Verify Alibaba OSS review Parameters on review order', function () {
        var orderObject = JSON.parse(JSON.stringify(ossTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderObject.servicename = servicename;
        orderFlowUtil.fillOrderDetails(ossTemplate, modifiedParamMap);

        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(orderObject.servicename);
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
        expect(placeOrderPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Bucket Name:")).toEqual(jsonUtil.getValue(orderObject, "Bucket Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Storage Class:")).toEqual(jsonUtil.getValue(orderObject, "Storage Class"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Access Control List:")).toEqual(jsonUtil.getValue(orderObject, "Access Control List"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Encryption Method:")).toEqual(jsonUtil.getValue(orderObject, "Encryption Method"));
        homePage.open();
    });

    it('Aalibaba:TC-4 OSS - Verify View Order Details', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(ossTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(ossTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder)
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();

        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);

        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnLabelName("Region")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(ordersPage.getTextBasedOnLabelName("Bucket Name")).toEqual(jsonUtil.getValue(orderObject, "Bucket Name"));
        expect(ordersPage.getTextBasedOnLabelName("Storage Class")).toEqual(jsonUtil.getValue(orderObject, "Storage Class"));
        expect(ordersPage.getTextBasedOnLabelName("Access Control List")).toEqual(jsonUtil.getValue(orderObject, "Access Control List"));
        expect(ordersPage.getTextBasedOnLabelName("Encryption Method")).toEqual(jsonUtil.getValue(orderObject, "Encryption Method"));

        //cheking bill of material
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(placeOrderPage.getTotalCost()).toBe(orderObject.TotalCost);

        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
        orderFlowUtil.denyOrder(returnObj);
    });
});