
"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	Inventory = require('../../../pageObjects/inventory.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	jsonUtil = require('../../../../helpers/jsonUtil.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	appUrls = require('../../../../testData/appUrls.json'),
	keyPairTemplate = require('../../../../testData/OrderIntegration/AWS/keyPair.json');

describe('AWS - Key-Pair', function () {
	var inventoryPage, ordersPage, catalogPage, placeOrderPage, serviceName, keyName, KeyPairINSObject;
	var modifiedParamMap = {};
	var orderObject = {};
	var messageStrings = {
		orderSubmittedConfirmationMessage: 'Order Submitted !',
		fileDownloadMsg: 'The file downloaded successfully.'
	};

	beforeAll(function () {
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new Inventory();
		KeyPairINSObject = JSON.parse(JSON.stringify(keyPairTemplate));
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderCheckBoxBasedOnName(keyPairTemplate.provider);
		serviceName = "auto-aws-keyPair-" + util.getRandomString(5);
		keyName = "attkey-" + util.getRandomString(5);
		modifiedParamMap = { "Service Instance Name": serviceName, "Key Name": keyName };
	});

	it('AWS Key-Pair - Verify fields on Main Parameters page is working fine', function () {
		catalogPage.clickProviderOrCategoryCheckbox(keyPairTemplate.Category);
		catalogPage.clickConfigureButtonBasedOnName(keyPairTemplate.bluePrintName);
		expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
		placeOrderPage.setServiceNameText(serviceName);
		placeOrderPage.selectProviderAccount(KeyPairINSObject["Order Parameters"]["Main Parameters"]["Provider Account"]["value"]["QA 1"]);
		expect(placeOrderPage.isNextButtonEnabled()).toBe(true);

	});

	fit('AWS Key-Pair - Verify Summary details and Additional Details are listed in review Order page', function () {
		catalogPage.clickProviderOrCategoryCheckbox(keyPairTemplate.Category);
		catalogPage.clickConfigureButtonBasedOnName(keyPairTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetails(keyPairTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
			if (browser.params.defaultCurrency == "USD") {
				expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(keyPairTemplate.TotalCost);
			}
			expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
			expect(requiredReturnMap["Actual"]["Key Name"]).toEqual(keyName);
		});
	});


	it('AWS Key-Pair - Verify Order is listed in Orders details page once it is submitted from catalog page', function () {
		var orderObject = {};
		catalogPage.clickProviderOrCategoryCheckbox(keyPairTemplate.Category);
		catalogPage.clickConfigureButtonBasedOnName(keyPairTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetails(keyPairTemplate, modifiedParamMap);
		placeOrderPage.submitOrder();
		expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
		orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
		placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
		ordersPage.open();
		expect(util.getCurrentURL()).toMatch('orders');
		ordersPage.searchOrderById(orderObject.orderNumber);
		expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
		ordersPage.clickFirstViewDetailsOrdersTable();
		expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
		expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(keyPairTemplate.provider);
		expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
		expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
		//util.waitForAngular();
		expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(KeyPairINSObject, "AWS Region"));
		expect(ordersPage.getTextBasedOnLabelName("Key Name")).toEqual(keyName);
		if (browser.params.defaultCurrency == "USD") {
			ordersPage.clickBillOfMaterialsTabOrderDetails();
			expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(keyPairTemplate.TotalCost);
		}
	});

	if (isProvisioningRequired == "true") {
		it('AWS Key-Pair - E2E : Verify instance Order Provision and Deletion is working fine from consume App', function () {

			var serviceDetailsMap = {};
			catalogPage.clickProviderOrCategoryCheckbox(keyPairTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(keyPairTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(keyPairTemplate, modifiedParamMap).then(function (serviceDetailsMapActual) {
				serviceDetailsMap = serviceDetailsMapActual;
			});

			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(keyPairTemplate.bluePrintName, "New");
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
			//Verify Output parameter			
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
				if (status == 'Completed') {
					//Verify Output parameter
					expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
					if (isDummyAdapterDisabled == "true") {
						inventoryPage.clickOnInstanceTableActionIcon();
						inventoryPage.downLoadKeyPair(keyName);
						expect(inventoryPage.getNotificationMsg()).toContain(messageStrings.fileDownloadMsg);
						orderFlowUtil.closeHorizontalSliderIfPresent();
					}
					orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, keyPairTemplate.bluePrintName);
					orderFlowUtil.approveDeletedOrder(orderObject);
					orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
					expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');

				}
			});
		});
	}
})
