
"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),	
	CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),	
	util = require('../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	customTemplate = require('../../../../testData/OrderIntegration/AWS/pricingCustomTemplate.json');

describe('AWS - Pricing Validation of Custom Templates', function () {
	var ordersPage, catalogPage, placeOrderPage,  serviceName;
	var modifiedParamMap = {};
	var messageStrings = {
		providerName: 'Amazon',
		category: 'default',
		catalogPageTitle: 'Search, Select and Configure',
		inputServiceNameWarning: "Parameter Warning:",
		orderSubmittedConfirmationMessage: 'Order Submitted !'		
	};

	beforeAll(function () {
		ordersPage = new Orders();		
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();		
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		//customInstObj = JSON.parse(JSON.stringify(customTemplate));
		serviceName = "pricingvalidation-customTemp-" + util.getRandomString(3);		
		modifiedParamMap = { "Service Instance Name": serviceName };
	});

	it('AWS - Verify Pricing of custom template on review Order page/Approve Order Page', function () {
		var orderObject = {};
		orderObject.servicename = serviceName;
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(customTemplate.bluePrintName);
        		
		orderFlowUtil.fillOrderDetails(customTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);			
			//Validate Pricing of all components on Review order page			
			placeOrderPage.validatePricingCustomTemplate();	
		});

		placeOrderPage.submitOrder();
		expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
		orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
		placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
		ordersPage.open();
		expect(util.getCurrentURL()).toMatch('orders');
		ordersPage.searchOrderById(orderObject.orderNumber);
		expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
		ordersPage.clickFirstViewDetailsOrdersTable();		
		util.waitForAngular();		
		ordersPage.clickBillOfMaterialsTabOrderDetails();
		ordersPage.clickMoreLinkBom();		
		//Validate Pricing of all Service Components
		ordersPage.validatePricingCustomTemplate();		
	});
	
});
