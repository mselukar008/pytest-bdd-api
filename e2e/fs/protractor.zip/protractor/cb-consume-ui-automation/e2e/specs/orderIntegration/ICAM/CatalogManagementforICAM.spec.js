/**********************
 * Spec_Name: CatalogManagementforICAM.spec.js
 * Author : Sarika Bothe
 * Description : This file covers flow for start catalog discovery,cancel discovery,check duplicate service group names,completed discovery status,edit image icon for service. etc '
 **********************/
"use strict";
const { browser } = require('protractor');
var CatalogDiscoveryPage = require('../../../pageObjects/catalogDiscovery.pageObject.js'),
    ServiceVersiondetail = require('../../../../testData/OrderIntegration/ICAM/ServiceGroupAndVersion.json'),
    util = require('../../../../helpers/util.js')
describe('TA - E2E Test cases for Catalog Discovery - ', function () {
    var catalogDiscoveryObj;

    beforeAll(function () {
        catalogDiscoveryObj = new CatalogDiscoveryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        browser.waitForAngularEnabled(false);
        catalogDiscoveryObj.open();
    });

    //catalog admin edits service on the same page service for group field no duplicate group names should be allowed to save.
    it('TA - Verifing catalog admin edits service on the same page service for group field no duplicate group names should be allowed to save.', function () {
        catalogDiscoveryObj.clickOnGroupToggleBtn();
        catalogDiscoveryObj.clickOnServiceGroupDropdown();
        catalogDiscoveryObj.enterGroupName(ServiceVersiondetail.ServiceGroupName);
        util.waitForAngular();
        expect(catalogDiscoveryObj.getVersionText()).toEqual(ServiceVersiondetail.ServiceVersion);
        expect(catalogDiscoveryObj.getServiceGroupNameText()).toEqual(ServiceVersiondetail.ServiceGroupName);
        catalogDiscoveryObj.clickOnThreeDotMenuIcon(ServiceVersiondetail.serviceNameICAM);
        catalogDiscoveryObj.clickOnViewDetailsLink();
        catalogDiscoveryObj.clickOnEditButton();
        catalogDiscoveryObj.EnterInvalidGroupName(ServiceVersiondetail.InvalidServiceName);
        catalogDiscoveryObj.clickOnSaveBtn();
        expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(ServiceVersiondetail.SameGroupError);
    });

    //verify configuration parameter is visible on catalog admin page
    it('TA - Verifing parameters on catalog admin page for service.', function () {
        catalogDiscoveryObj.searchServiceOrProviderName(ServiceVersiondetail.serviceNameICAM);
        catalogDiscoveryObj.clickOnThreeDotMenuIcon(ServiceVersiondetail.serviceNameICAM);
        catalogDiscoveryObj.clickOnViewDetailsLink();
        catalogDiscoveryObj.clickOnEditButton();
        catalogDiscoveryObj.clickOnConfigurationParameterTA();
        catalogDiscoveryObj.clickOnexpandAllLink();
        catalogDiscoveryObj.getServiceConfigurationstext().then(function (arryList) {
            expect(arryList[0]).toContain(ServiceVersiondetail.InstancePlan);
            expect(arryList[1]).toContain(ServiceVersiondetail.AzureConnection);
            expect(arryList[2]).toContain(ServiceVersiondetail.AWSconnection);
            expect(arryList[3]).toContain(ServiceVersiondetail.AdminUserPassword);
            expect(arryList[4]).toContain(ServiceVersiondetail.AWSRegionName);
            expect(arryList[5]).toContain(ServiceVersiondetail.VirtualPrivateCloud);
            expect(arryList[6]).toContain(ServiceVersiondetail.SubnetName);
            expect(arryList[7]).toContain(ServiceVersiondetail.PublicSSHKeyName);
        })

    });

    //start catalog discovery for Icam from catalog Admin page selet account and wait till discovery get complete
    it('TA - verifying start catalog discovery for Icam from catalog Admin page', function () {
        catalogDiscoveryObj.clickOnStartCatalogDiscoveryBtn();
        catalogDiscoveryObj.clickOkImportService();
        catalogDiscoveryObj.clickOnProviderToStartDiscovery(ServiceVersiondetail.serviceCategoryProviderICAM);
        expect(catalogDiscoveryObj.getMultipleAccountsDetectedText()).toMatch(ServiceVersiondetail.Multipleaccountsdetected);
        catalogDiscoveryObj.selectIcamAccountFromDrpDwn(ServiceVersiondetail.ProviderAccount);
        catalogDiscoveryObj.clickOnOKBtnFromDiscoveryPopup();
        expect(catalogDiscoveryObj.getDiscoveryStartedText()).toMatch(ServiceVersiondetail.TADiscoveryStartedText);
        catalogDiscoveryObj.clickOnokButtonIbmDiscoverryStarted();
        catalogDiscoveryObj.open();
        catalogDiscoveryObj.clickOnProvidersToggleBtn();
        catalogDiscoveryObj.searchProviderByName(ServiceVersiondetail.serviceCategoryProviderICAM);
        expect(catalogDiscoveryObj.getDiscoveryStatus()).toMatch(ServiceVersiondetail.DiscoveryStatus);
    });

    //when discovery get complete ,check status in history tab
    it('TA - verify Icam Catalog discovery status from catalog discovery history', function () {
        catalogDiscoveryObj.waitToCompletDiscoveryStatusTA();
        catalogDiscoveryObj.clickOnICAMHistoryLink();
        expect(catalogDiscoveryObj.getcatalogDiscoveryStatusText()).toMatch("Completed");

    });

    //save the service in WIP state and publish the service
    it('TA - Verify is service getting publish succesfully', function () {
        catalogDiscoveryObj.clickOnDraftSectionLink();
        catalogDiscoveryObj.searchServiceOrProviderName(ServiceVersiondetail.ServiceName);
        catalogDiscoveryObj.clickOnThreeDotMenuIcon(ServiceVersiondetail.ServiceName);
        catalogDiscoveryObj.clickOnViewDetailsLink();
        catalogDiscoveryObj.clickOnEditButton();
        catalogDiscoveryObj.clickOnSaveBtn();
        catalogDiscoveryObj.open();
        catalogDiscoveryObj.searchServiceOrProviderName(ServiceVersiondetail.ServiceName);
        catalogDiscoveryObj.clickOnThreeDotMenuIcon(ServiceVersiondetail.ServiceName);
        catalogDiscoveryObj.clickOnPublishService();
        expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(ServiceVersiondetail.PublishMsg);
        catalogDiscoveryObj.clickOnPublishSectionLink();
        catalogDiscoveryObj.searchServiceOrProviderName(ServiceVersiondetail.ServiceName);
        expect(catalogDiscoveryObj.getServiceNameFromRetiredSearchSectionICAM()).toEqual(ServiceVersiondetail.ServiceName);

    });
    //retired service from publish section and again unretired same service
    it('TA - Verify is service getting retired and unretired successfully  ', function () {
        catalogDiscoveryObj.clickOnPublishSectionLink();
        catalogDiscoveryObj.searchServiceOrProviderName(ServiceVersiondetail.ServiceName);
        catalogDiscoveryObj.clickOnThreeDotMenuIcon(ServiceVersiondetail.ServiceName);
        catalogDiscoveryObj.clickOnRetireServiceOption();
        catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
        expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(ServiceVersiondetail.RetiredMsg);
        catalogDiscoveryObj.clickOnRetiredSectionLink();
        catalogDiscoveryObj.searchServiceOrProviderName(ServiceVersiondetail.ServiceName);
        expect(catalogDiscoveryObj.getServiceNameFromRetiredSearchSectionICAM()).toEqual(ServiceVersiondetail.ServiceName);
        catalogDiscoveryObj.clickOnThreeDotMenuIcon(ServiceVersiondetail.ServiceName);
        catalogDiscoveryObj.clickOnUnretireServiceOption();
        catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
        expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(ServiceVersiondetail.UnretiredMsg);
        catalogDiscoveryObj.clickOnPublishSectionLink();
        catalogDiscoveryObj.searchServiceOrProviderName(ServiceVersiondetail.ServiceName);
        expect(catalogDiscoveryObj.getServiceNameFromRetiredSearchSectionICAM()).toEqual(ServiceVersiondetail.ServiceName);
    });

    //delete service from retired section
    it('TA - Verify is service getting deleted successfully ', function () {
        catalogDiscoveryObj.clickOnPublishSectionLink();
        catalogDiscoveryObj.searchServiceOrProviderName(ServiceVersiondetail.ServiceName);
        catalogDiscoveryObj.clickOnThreeDotMenuIcon(ServiceVersiondetail.ServiceName);
        catalogDiscoveryObj.clickOnRetireServiceOption();
        catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
        expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(ServiceVersiondetail.RetiredMsg);
        catalogDiscoveryObj.clickOnRetiredSectionLink();
        catalogDiscoveryObj.searchServiceOrProviderName(ServiceVersiondetail.ServiceName);
        expect(catalogDiscoveryObj.getServiceNameFromRetiredSearchSectionICAM()).toEqual(ServiceVersiondetail.ServiceName);
        catalogDiscoveryObj.clickOnThreeDotMenuIcon(ServiceVersiondetail.ServiceName);
        catalogDiscoveryObj.ClickOnDeleteService();
        catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
        expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual("Success");
    });
    //start catalog discovery and verifying cancel discovery is working propery or not
    it('Cancel catalog discovery for Icam from catalog Admin page', function () {
        catalogDiscoveryObj.clickOnStartCatalogDiscoveryBtn();
        catalogDiscoveryObj.clickOkImportService();
        catalogDiscoveryObj.clickOnProviderToStartDiscovery(ServiceVersiondetail.serviceCategoryProviderICAM);
        catalogDiscoveryObj.selectIcamAccountFromDrpDwn(ServiceVersiondetail.ProviderAccount);
        catalogDiscoveryObj.clickOnOKBtnFromDiscoveryPopup();
        catalogDiscoveryObj.clickOnokButtonIbmDiscoverryStarted();
        catalogDiscoveryObj.open();
        catalogDiscoveryObj.clickOnProvidersToggleBtn();
        catalogDiscoveryObj.searchProviderByName(ServiceVersiondetail.serviceCategoryProviderICAM);
        catalogDiscoveryObj.clickOncancelDiscovery();
        catalogDiscoveryObj.clickOncancelDiscoveryOk();
        expect(catalogDiscoveryObj.getAlertNotificationTitle()).toContain(ServiceVersiondetail.SuccessNotifiacation);
        catalogDiscoveryObj.clickOnICAMHistoryLink();
        expect(catalogDiscoveryObj.getcatalogDiscoveryStatusText()).toContain("Canceled");

    });


});