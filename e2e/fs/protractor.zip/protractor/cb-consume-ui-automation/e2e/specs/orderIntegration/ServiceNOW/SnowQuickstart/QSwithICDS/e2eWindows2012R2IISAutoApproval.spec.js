"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	icdsWinR2IIS = require('../../../../../../testData/OrderIntegration/ServiceNOW/ICDSWin2012R2IIS.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('ICDS E2E cases for Auto Approval', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, sampleOrder1, provOrder, instName, inventoryPage;
	var modifiedParamMap = {};
	var serviceName = "SNOWauto"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var icdsWinR2IISObj = JSON.parse(JSON.stringify(icdsWinR2IIS));

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"TestSnowTeam", "Environment":"QA", "Application":""};
	});
	
	afterAll(function() {
		browser.get(consumeLaunchpadUrl);
	});
	
	it('Enable Auto approval in SNOW QS', function () {
		snowPage.loginToSnowQSICDSPortal();
		snowPage.enableAutoApprovalQS(snowInstanceTemplate.snowReqGrpApprovalProperty);
	});
	
	if(isProvisioningRequired == "true") {	
		it('ICDS: Windows Server 2012 R2 With IIS ---- Verify Provision functionality for Auto approval', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsWinR2IIS.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsWinR2IIS.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsWinR2IIS.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(icdsWinR2IIS, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsWinR2IIS.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2IIS.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2IIS.provInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsWinR2IIS.bluePrintName);
			
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSReqItemWinIIS);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemWinIIS);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Customer")).toBe(jsonUtil.getValue(icdsWinR2IISObj, "Customer"));
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Service Collection")).toBe(jsonUtil.getValue(icdsWinR2IISObj, "Servicecollection"));
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsWinR2IISObj, "Environment"));
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Active Directory Domain")).toBe(snowInstanceTemplate.snowQSReqItemVarADDomain);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Number of CPU Cores")).toBe(jsonUtil.getValue(icdsWinR2IISObj, "CPUs"));
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Memory Size (GB)")).toBe(jsonUtil.getValue(icdsWinR2IISObj, "Memory (MB)"));
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Disk 0 (System) Size (GB)")).toBe(snowInstanceTemplate.snowQSReqItemVarDisk0Size);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Disk 0 (System) Name")).toBe(snowInstanceTemplate.snowQSReqItemVarDisk0Name);

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.clickImplementButtonQS();
			snowPage.clickBackButton();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);				
			snowPage.checkIfAllSevenChangeTasksClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2IIS.completedState);
			
			//Validation on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
		 });
		
		it('ICDS: Windows Server 2012 R2 With IIS ---- Verify Turn Off functionality for Auto approval', function () {
			
			//Place order for Turn OFF in Marketplace 
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA().then(function () {
	                inventoryPage.clickTurnOFFButtonOfInstanceICDS().then(function () {
	                    inventoryPage.clickOkForInstanceTurnOFFPermission();
	                });
	            });
	        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsWinR2IIS.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2IIS.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2IIS.provInProgressState);

            //Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsWinR2IIS.serviceOfferingTurnOff);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSReqItemDay2Ops);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDay2Ops);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsWinR2IISObj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.clickImplementButtonQS();
			snowPage.clickBackButton();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.checkIfAllTwoChangeTasksClosed();	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2IIS.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickReqItemVarTabQS();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
	       });
		});
		
		it('ICDS: Windows Server 2012 R2 With IIS ---- Verify Turn On functionality for Auto approval', function () {
			
			//Place order for Turn ON in Marketplace 
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA().then(function () {
	                inventoryPage.clickTurnONButtonOfInstanceICDS().then(function () {
	                    inventoryPage.clickOkForInstanceTurnONPermission();
	                });
	            });
	        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsWinR2IIS.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2IIS.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2IIS.provInProgressState);

            //Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsWinR2IIS.serviceOfferingTurnOn);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSReqItemDay2Ops);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDay2Ops);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsWinR2IISObj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.clickImplementButtonQS();
			snowPage.clickBackButton();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.checkIfAllTwoChangeTasksClosed();	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2IIS.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickReqItemVarTabQS();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
	       });
		});
		
		it('ICDS: Windows Server 2012 R2 With IIS ---- Verify Reboot functionality for Auto approval', function () {
			
			//Place order for Reboot in Marketplace 
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA().then(function () {
	                inventoryPage.clickRebootButtonOfInstanceICDS().then(function () {
	                    inventoryPage.clickOkForInstanceRebootPermission();
	                });
	            });
	        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsWinR2IIS.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2IIS.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2IIS.provInProgressState);

            //Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsWinR2IIS.serviceOfferingReboot);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSReqItemDay2Ops);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDay2Ops);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsWinR2IISObj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.clickImplementButtonQS();
			snowPage.clickBackButton();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.checkIfAllTwoChangeTasksClosed();	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2IIS.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickReqItemVarTabQS();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
	       });
		});
		
		it('ICDS: Windows Server 2012 R2 With IIS ---- Verify Delete functionality for Auto approval', function () {
			
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			provOrder = inventoryPage.getDeleteOrderNumber();
			ordersPage.open();
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject,icdsWinR2IIS.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2IIS.provInProgressState);
		
			//Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsWinR2IIS.bluePrintName);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSReqItemWinDel);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemWinDel);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsWinR2IISObj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.clickImplementButtonQS();
			snowPage.clickBackButton();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.checkIfAllElevenChangeTasksClosed();	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(icdsWinR2IIS.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);			
		 });		
	 }
});
	
	
	
	