"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    Inventory = require('../../../pageObjects/inventory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    glacierInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSGlacierInstance.json');

describe('AWS - Glacier', function () {
    var ordersPage, catalogPage, inventoryPage, placeOrderPage, serviceName, vaultName, topicName, GlacierINSObject;
    var modifiedParamMap = {};
    var orderObject = {};
    var serviceDetailsMap = {};
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Storage',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        systemTagText: "ibm_mcmp_soiid"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new Inventory();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        GlacierINSObject = JSON.parse(JSON.stringify(glacierInstanceTemplate));
        serviceName = "auto-aws-glacier-" + util.getRandomString(5);
        vaultName = "TestVault" + util.getRandomString(5);
        topicName = "topicnamesns" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Vault Name": vaultName, "Topic Name": topicName };
    });

    it('TC-C182487 : AWS Glacier - Verify fields on Main Parameters page is working fine', function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(glacierInstanceTemplate.bluePrintName);
        expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
        //expect(placeOrderPage.getTextBluePrintName()).toContain(glacierInstanceTemplate.descriptiveText);
        placeOrderPage.setServiceNameText(serviceName);
        placeOrderPage.selectProviderAccount(GlacierINSObject["Order Parameters"]["Main Parameters"]["Provider Account"]["value"]["QA 1"]);
        expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
        //expect(placeOrderPage.getTextEstimatedPrice()).toBe(glacierInstanceTemplate.BasePrice);
    });

    fit('TC-C182488 : AWS Glacier - Verify Summary details and Additional Details are listed in review Order page', function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(glacierInstanceTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetails(glacierInstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            //expect(requiredReturnMap["Actual"]["Service Instance Name"]).toEqual(requiredReturnMap["Expected"]["Service Instance Name"]);
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            //expect(placeOrderPage.getTextCategoryName_ReviewOrder()).toBe(messageStrings.category);
            //expect(placeOrderPage.getTextProviderName_ReviewOrder()).toBe(messageStrings.providerName);
            if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(glacierInstanceTemplate.TotalCost);
                //BOM Validation as per components of service.
                expect(placeOrderPage.validateBOMOnReviewOrderPage(glacierInstanceTemplate.Pricing)).toBe(true);
            }
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Vault Name"]).toEqual(requiredReturnMap["Expected"]["Vault Name"]);
            expect(requiredReturnMap["Actual"]["Event Notifications"]).toEqual(requiredReturnMap["Expected"]["Event Notifications"]);
            expect(requiredReturnMap["Actual"]["Topic Name"]).toEqual(requiredReturnMap["Expected"]["Topic Name"]);
            expect(requiredReturnMap["Actual"]["Display Name"]).toEqual(requiredReturnMap["Expected"]["Display Name"]);
            expect(requiredReturnMap["Actual"]["Job Types To Trigger Notifications"]).toEqual(requiredReturnMap["Expected"]["Job Types To Trigger Notifications"]);
            expect(requiredReturnMap["Actual"]["Key"]).toEqual(requiredReturnMap["Expected"]["Key"]);
            expect(requiredReturnMap["Actual"]["Value"]).toEqual(requiredReturnMap["Expected"]["Value"]);
        });
    });

    it('TC-C182489 : AWS Glacier - Verify Order is listed in Orders details page once it is submitted from catalog page', function () {
        var orderObject = {};
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(glacierInstanceTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetails(glacierInstanceTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        expect(util.getCurrentURL()).toMatch('orders');
        ordersPage.searchOrderById(orderObject.orderNumber);
        expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
        var orderAmount = ordersPage.getTextFirstAmountOrdersTable();
        ordersPage.clickFirstViewDetailsOrdersTable();
        //orderFlowUtil.waitForOrderStatusChange(orderObject, 'Approval In Progress');
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
        expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
        expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
        //util.waitForAngular();
        expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(GlacierINSObject, "AWS Region"));
        expect(ordersPage.getTextBasedOnLabelName("Vault Name")).toEqual(vaultName);
        expect(ordersPage.getTextBasedOnLabelName("Event Notifications")).toEqual(jsonUtil.getValue(GlacierINSObject, "Event Notifications"));
        expect(ordersPage.getTextBasedOnLabelName("Topic Name")).toEqual(topicName);
        expect(ordersPage.getTextBasedOnLabelName("Display Name")).toEqual(jsonUtil.getValue(GlacierINSObject, "Display Name"));
        expect(ordersPage.getTextBasedOnLabelName("Job Types To Trigger Notifications")).toEqual(jsonUtil.getValue(GlacierINSObject, "Job Types To Trigger Notifications"));
        expect(ordersPage.getTextBasedOnLabelName("Key")).toEqual(jsonUtil.getValue(GlacierINSObject, "Key"));
        expect(ordersPage.getTextBasedOnLabelName("Value")).toEqual(jsonUtil.getValue(GlacierINSObject, "Value"));
        if (browser.params.defaultCurrency == "USD") {
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(glacierInstanceTemplate.TotalCost);
        }
    });

    if (isProvisioningRequired == "true") {
        it('TC-C182490 : AWS Glacier - E2E : Verify instance Order Provision is working fine from consume App', function () {
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
            catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(glacierInstanceTemplate.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetails(glacierInstanceTemplate, modifiedParamMap).then(function (serviceDetailsMapActual) {
                serviceDetailsMap = serviceDetailsMapActual;
            });

            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(glacierInstanceTemplate.bluePrintName, "New");
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');

        });

        if (isDummyAdapterDisabled == 'true') {
            it('TC-C182490 : AWS Glacier : Before edit-Verify System tags are displayed for Service', function () {
                //Validate System tags
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    browser.executeScript('window.scrollTo(0,0);');
                    inventoryPage.clickOverflowActionButtonFisrtComponent();//.then(function () {
                    inventoryPage.clickViewComponentofAWSInstance().then(function () {
                        //Verify system tags      
                        expect(inventoryPage.getTagsOnInventory()).toContain(messageStrings.systemTagText);
                    });
                });
            });
        }

        it('TC-C182490 : AWS Glacier : Verify Output params and Edit service instance', function () {
            //Verify Output parameter            
            expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            //Edit Service
            var modifiedParamMap = { "EditService": true };
            orderFlowUtil.editService(orderObject);
            orderFlowUtil.fillOrderDetails(glacierInstanceTemplate, modifiedParamMap).then(function (reviewOrderExpActParamsMap) {
                logger.info("Edit parameter details are filled.");
                //browser.sleep(5000);
                //Validate Review order page parameters
                expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
            });
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(glacierInstanceTemplate.bluePrintName, "Edit");
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == 'Completed') {
                    //Verify updated details are reflected on order details page.						
                    ordersPage.clickFirstViewDetailsOrdersTable();
                    expect(ordersPage.getTextBasedOnLabelName("Event Notifications")).toEqual(jsonUtil.getValueEditParameter(GlacierINSObject, "Event Notifications"));
                    expect(ordersPage.getTextBasedOnLabelName("Key")).toEqual(jsonUtil.getValueEditParameter(GlacierINSObject, "Key"));
                    expect(ordersPage.getTextBasedOnLabelName("Value")).toEqual(jsonUtil.getValueEditParameter(GlacierINSObject, "Value"));
                }
                //After edit-Verify System tags are displayed for Service
                if (isDummyAdapterDisabled == 'true') {
                    inventoryPage.open();
                    inventoryPage.searchOrderByServiceName(orderObject.servicename);
                    inventoryPage.clickExpandFirstRow().then(function () {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.clickOverflowActionButtonFisrtComponent();//.then(function () {
                        inventoryPage.clickViewComponentofAWSInstance().then(function () {
                            //Verify system tags      
                            expect(inventoryPage.getTagsOnInventory()).toContain(messageStrings.systemTagText);
                            inventoryPage.closeViewComponent();
                            inventoryPage.clickExpandFirstRow();
                        });
                    });
                }
                //Delete Service flow
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, glacierInstanceTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            });
        });
    }
});
