"use strict";

const apiUtil = require('../../../../helpers/APIs/apiUtil.js');

var Orders = require('../../../pageObjects/orders.pageObject.js'),
	HomePage = require('../../../pageObjects/home.pageObject.js'),
	CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),
	CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	logGenerator = require("../../../../helpers/logGenerator.js"),
	Logger = logGenerator.getApplicationLogger(),
	InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
	BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),
	budgetaryFlow = require('../../../../helpers/budgetaryFlow.js'),
	budgetDeleteApi = require('../../../../helpers/budgetDeleteApiUtil.js'),
    userCredentialsTemplate = require('../../../../testData/credentials.json'),
	persistentDiskTemplate = require('../../../../testData/OrderIntegration/Google/persistentdisk.json'),
	budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
	budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryAddNewBudgetDetails.json');


describe('GCP - Budget Validation-Single User', function () {
	var ordersPage, homePage, catalogPage, placeOrderPage, cartListPage, orderHistoryPage, serviceName, cartName, budgetryPage, budgetaryName, budgetaryNewBudgetName, budgetaryUnitCode;
	var modifiedParamMap = {};
	var modifiedParamMapBudget = {};
	var modifiedNewBudgetParamMap = {};
	var messageStrings = {
		catalogPageTitle: persistentDiskTemplate.catalogPageTitle,
		inputServiceNameWarning: persistentDiskTemplate.inputServiceNameWarning,
		orderSubmittedConfirmationMessage: persistentDiskTemplate.orderSubmittedConfirmationMessage,
		providerName: persistentDiskTemplate.provider,
		completedState: persistentDiskTemplate.completedState,
		budgetDeletedApiSucessMsg: "Success",
		budgetaryUnitDeletedApiSucessMsg: "Success",
		budgetaryUnitDeleteSuccessMsg:budgetaryUnitDetailsTemplate.budgetaryUnitDeleteSuccessMsg
	};

	beforeAll(function () {
		ordersPage = new Orders();
		homePage = new HomePage();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		orderHistoryPage = new OrderHistoryPage();
		budgetryPage = new BudgetaryPage();		
		budgetaryName = "gcpAut" + util.getRandomString(8);
		budgetaryNewBudgetName = "newgcpAut" + util.getRandomString(8);
		budgetaryUnitCode = "gcpCode" + util.getRandomString(8);
		serviceName = "budgetGcp" + util.getRandomString(5);
		modifiedParamMap = { "Service Instance Name": serviceName, "Team": "budgetTEAM2", "Environment": "gcpEnv", "Application": "gcpApp", "Provider Account": "" };
		modifiedParamMapBudget = { "budgetary Name": budgetaryName, "budgetary unit code": budgetaryUnitCode, "Choose Entity": "Organization", "Entity Value": "budgetORG", "Environment": "gcpEnv", "Application": "gcpApp" };

	});

// 	beforeEach(function () {
// 		orderFlowUtil.closeHorizontalSliderIfPresent();
// 		//catalogPage.open();
// 	});
	
	xit("Make BudgetaryUnits and budgets Inactive", async function () {
		//Get list of budgets
		var budgetaryUnitCode,budgetId;
		var budgetaryUnitStatus,budgetStatus;
		await apiUtil.getBudgetList().then(async function(budgetList){			
			for (var i = 0; i < budgetList.length; i++){
				budgetaryUnitCode = budgetList[i].budgetcode;
				budgetaryUnitStatus = budgetList[i].status
				//Get Associated Budget for Active budgetaryUnit
				if(budgetaryUnitStatus == "Active"){
					await apiUtil.getBudget(budgetaryUnitCode).then(async function(budget){
						//Check if budgets are present
						if(budget.size != 0){
							for (var j = 0; j < budget.size; j++){
								budgetStatus = budget["response"][j].status
								if(budgetStatus == "Active"){
									//Make budget Inactive
									await apiUtil.makeBudgetInactive(budgetaryUnitCode, budget["response"][j]);								
								}
							}					
						}
						//Make budgetary unit Inactive 
						await apiUtil.makeBudgetaryUnitInactive(budgetaryUnitCode, budgetList[i]);
					});
				}

			}

		});

	});
	//Pre-Requisite
	/*1.Make sure to have budget is already created.
	2.Context text for Environment and application must be available.
	3.Context must be mapped to TEAM.*/

	it('GCP-Single User-Add new budgetry Unit for E2E budget Flow ', function () {
		orderFlowUtil.closeHorizontalSliderIfPresent();
		budgetryPage.open();		
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMapBudget);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		var startPeriod = budgetaryFlow.incrementMonth(0);
		modifiedNewBudgetParamMap = { "Name": budgetaryNewBudgetName, "Start Period": startPeriod, "Notify When Soft Quota reached": "budgetTEAM2", "Notify When Hard Quota reached": "budgetTEAM2" };
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		budgetryPage.clickOnNotificationCloseButton();
		//Verify if budget fields are enabled on successive edits
		 budgetryPage.clickViewDetailActionIcon();
		 budgetryPage.clickViewDetailBtn();
		 budgetryPage.clickBudgetEditButton();
		 budgetryPage.clickAfterEditingBudgetaryBackButton();

// 		budgetryPage.clickViewDetailActionIcon();
// 		budgetryPage.clickViewDetailBtn();
		budgetryPage.clickBudgetEditButton();
		//Check status of fields 
		expect(budgetryPage.checkFieldStateOnBudgetPage("Name")).toBe(false);
		expect(budgetryPage.checkFieldStateOnBudgetPage("Start Period")).toBe(false);
		expect(budgetryPage.checkFieldStateOnBudgetPage("End Period")).toBe(false);
		expect(budgetryPage.checkFieldStateOnBudgetPage("Currency")).toBe(false);
		expect(budgetryPage.checkFieldStateOnBudgetPage("Available Amount")).toBe(false);
		expect(budgetryPage.checkFieldStateOnBudgetPage("Under Approval Amount")).toBe(false);
		expect(budgetryPage.checkFieldStateOnBudgetPage("Committed Amount")).toBe(false);
		expect(budgetryPage.checkFieldStateOnBudgetPage("Actual Charges")).toBe(false);
		budgetryPage.clickAfterEditingBudgetaryBackButton();
		budgetryPage.clickBudgetSliderCloseButton();
		orderFlowUtil.closeHorizontalSliderIfPresent();
	});

	it('GCP-Single User-Budget Validation for GCP Service', function () {
		var availBudgetProvCompleted, afterProvCommittedAmnt, beforePovisioningAvailBudget, calculatedEstAmtOnBudgetPage, afterProvCommittedAmntOnBudgetPage, afterPovisioningAvailBudgetOnBudgetPage;
		var orderObject = {};
		var persistentDiskInsObject = JSON.parse(JSON.stringify(persistentDiskTemplate));
		orderObject.servicename = serviceName;
		global.serviceName = serviceName;
		orderFlowUtil.closeHorizontalSliderIfPresent();
		catalogPage.open();
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
		catalogPage.clickProviderOrCategoryCheckbox(persistentDiskTemplate.Category);
		catalogPage.clickConfigureButtonBasedOnName(persistentDiskTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetails(persistentDiskTemplate, modifiedParamMap).then(async function (ttt) {
			//Submit order
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			// Open Order page and Approve Order 
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			//Open Approve order page
			ordersPage.open();
			//Search by Order ID and verify the parameters on View order page
			ordersPage.searchOrderById(orderObject.orderNumber);
			//select Budgetary Unit
			ordersPage.selectBudgetaryUnit(budgetaryName);
			//util.waitForAngular();
			if (browser.params.defaultCurrency == "USD") {
				expect(ordersPage.getTextBudgetAmmount()).toEqual(persistentDiskTemplate.OrdersPageBudgetAmount);
				//Fetch the Available budget and committed Amount after order is submitted for further calculation
				var beforePovisioningCommittedAmount = await ordersPage.getTextBudgetaryCommittedAmmount();

				//Other orders awaiting approval amount should be equal to the estimated Amount  
				//This will pass if no other user are using this budget and the initial amount for this is equal to USD 0.00

				var calculatedEstAmount = ordersPage.calculateBudgetaryEstimatedAmmountforOrder(persistentDiskTemplate.budgetDuration, persistentDiskTemplate.TotalCost);
				beforePovisioningAvailBudget = await ordersPage.getTextAvailableBudget();
				var costOtherOrdersAwaitingApprovalBeforeProvision = await ordersPage.getTextOtherOrdersAwaitingApproval();

				//As the spend amount is always zero 
				expect(ordersPage.getTextBudgetarySpendAmmount()).toEqual("USD 0.00");
				expect(ordersPage.getTextBudgetaryEstimatedAmmountforOrder()).toContain(calculatedEstAmount);
			}
		
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState).then(function () {
				//order status completed 
				if (browser.params.defaultCurrency == "USD") {
					availBudgetProvCompleted = ordersPage.calculateAvailableBudgetAfterProvCompleted(beforePovisioningAvailBudget, calculatedEstAmount);
					expect(ordersPage.getTextAvailableBudget()).toContain(availBudgetProvCompleted);
					//once the provisioning completed Other total amount will be equal to ( Other total amount before provision - calculated Est Amount)
					var actualOrdersAwaitingApprovalAmout = ordersPage.calculateAfterProvOtherOrderAwaitingApprovalAmount(costOtherOrdersAwaitingApprovalBeforeProvision, calculatedEstAmount);
					ordersPage.getTextOtherOrdersAwaitingApproval().then(function (expctdOrdersAwaitingApprovalAmout) {
						expect(expctdOrdersAwaitingApprovalAmout.replace(",", "")).toEqual(actualOrdersAwaitingApprovalAmout);
					});
					afterProvCommittedAmnt = ordersPage.calculateCommittedAmountAfterProvCompleted(beforePovisioningCommittedAmount, calculatedEstAmount);
					expect(ordersPage.getTextBudgetaryCommittedAmmount()).toContain(afterProvCommittedAmnt);
					expect(ordersPage.getTextBudgetarySpendAmmount()).toEqual("USD 0.00");

					calculatedEstAmtOnBudgetPage = budgetryPage.calculateEstimatedAmmountforOrder(persistentDiskTemplate.budgetDuration, persistentDiskTemplate.TotalCost);
					afterProvCommittedAmntOnBudgetPage = budgetryPage.calculateCommittedAmountAfterProvCompletedOnBudgetPage(beforePovisioningCommittedAmount, calculatedEstAmtOnBudgetPage);
					afterPovisioningAvailBudgetOnBudgetPage = budgetryPage.calculateAvailableBudgetAfterProvCompletedOnBudgetPage(beforePovisioningAvailBudget, calculatedEstAmtOnBudgetPage);
				}
				budgetryPage.open();				
				expect(util.getCurrentURL()).toMatch(appUrls.budgetaryUrl);
				//util.waitForAngular();
				budgetryPage.isPresentbudgetryUnitsText();
				budgetryPage.isPresentAddNewBudgetryUnitBtn();
				budgetryPage.isPresentBudgetryUnitsTable();
				budgetryPage.searchBudegtaryUnit(budgetaryName);
				//budgetryPage.selectbudgetaryPaginationDropDown();
				budgetryPage.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName)
				var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
				expect(status).toEqual("Active");
				if (browser.params.defaultCurrency == "USD") {
					budgetryPage.clickOnViewDetailsForBudgetaryUnit(budgetaryName, budgetaryNewBudgetName);				
					expect(budgetryPage.getValueBasedOnLabelName("Budget Amount")).toEqual(persistentDiskTemplate.BudgetAmount);
					budgetryPage.getValueBasedOnLabelName("Available Amount").then(function (val) {
						var roundOffValArr = util.roundOffTotalCost(val, afterPovisioningAvailBudgetOnBudgetPage);
						expect(roundOffValArr[0]).toEqual(roundOffValArr[1]);					
					});
					budgetryPage.getValueBasedOnLabelName("Committed Amount").then(function (val) {
						var comtdValArr = util.roundOffTotalCost(val, afterProvCommittedAmntOnBudgetPage);
						expect(comtdValArr[0]).toEqual(comtdValArr[1]);					
					});
					expect(budgetryPage.getValueBasedOnLabelName("Under Approval Amount")).toEqual("USD " + persistentDiskTemplate.zerobudgetAmount);
					budgetryPage.clickBudgetSliderCloseButton();
					budgetryPage.clickBudgetSliderCloseButton();
				}

				//Delete Service instance				
				orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
				expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
				orderFlowUtil.approveDeletedOrder(orderObject);
				orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
				expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState);
				if (browser.params.defaultCurrency == "USD") {
					var estCostAfterDeleting1MonthOrder = ordersPage.calculateEstCostAfterDeleting1MonthOrder(calculatedEstAmount, persistentDiskInsObject.TotalCost);
					expect(estCostAfterDeleting1MonthOrder).toContain(ordersPage.getTextBudgetaryEstimatedAmmountforOrder());

					var deletedCommittedAmnt = ordersPage.calculateDeleteCommittedAmount(afterProvCommittedAmnt, estCostAfterDeleting1MonthOrder);
					expect(deletedCommittedAmnt).toContain(ordersPage.getTextBudgetaryCommittedAmmount());

					var deletedAvailableBudget = ordersPage.calculateAfterDeletingAvailBudget(availBudgetProvCompleted, estCostAfterDeleting1MonthOrder);
					expect(deletedAvailableBudget).toContain(ordersPage.getTextAvailableBudget());
				}
			});

		});

	});

	afterAll(function () {
		 orderFlowUtil.closeHorizontalSliderIfPresent();
		 budgetryPage.deleteBudget(budgetaryName);
		 orderFlowUtil.closeHorizontalSliderIfPresent();
		// expect(budgetryPage.getNotificationMsg()).toContain(messageStrings.budgetaryUnitDeleteSuccessMsg);
	});	

});
