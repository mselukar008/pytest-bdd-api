/*
Spec_Name: e2eRegexvsphereVirtualMachine.spec.js 
Description:  Regex service e2e provision and validation error message checked for parameters who has regex.  
Author: Swaroop Sudhakar Kotme
//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.
*/

"use strict";

var CatalogPage            = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage         = require('../../../pageObjects/placeOrder.pageObject.js'),
	Orders                 = require('../../../pageObjects/orders.pageObject.js'),
	OrderHistoryPage       = require('../../../pageObjects/ordersHistory.pageObject.js'),
	util                   = require('../../../../helpers/util.js'),
	orderFlowUtil          = require('../../../../helpers/orderFlowUtil.js'),
	appUrls                = require('../../../../testData/appUrls.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	RegexvSphereVmTemplate  = require('../../../../testData/OrderIntegration/ICAM/RegexVspherevirtualmachine.json');
	
    
describe('E2E Test cases for ICAM-ON Vsphere Virtual Machine service', function() {
	var catalogPage, placeOrderPage,ordersPage,serviceName,vmName,randomrootdisk,randomipaddress,randommemory,randomprefix,orderHistoryPage;
	var modifiedParamMap = {};
    var messageStrings = {
			providerName                      : RegexvSphereVmTemplate.providerName,
			orderSubmittedConfirmationMessage : RegexvSphereVmTemplate.orderSubmittedConfirmationMessage,
			category                          :	RegexvSphereVmTemplate.category,
			estimatedPrice                    : RegexvSphereVmTemplate.estimatedPrice,
            providerAccount                   : RegexvSphereVmTemplate.providerAccount,
			completedState                    : RegexvSphereVmTemplate.completedState,
			approvalState                     : RegexvSphereVmTemplate.approvalState,
			orderTypeDel                      : RegexvSphereVmTemplate.orderTypeDel,
			urlOrders                         : RegexvSphereVmTemplate.urlOrders,
            estimatedCost                     : RegexvSphereVmTemplate.estimatedCost,
            rootdiskerrorMessage              : RegexvSphereVmTemplate.rootdiskerrorMessage,
            iperrorMessage                    : RegexvSphereVmTemplate.iperrorMessage,
            memoryerrorMessage                : RegexvSphereVmTemplate.memoryerrorMessage,
            prefixerrorMessage                : RegexvSphereVmTemplate.prefixerrorMessage
     };
    
  	beforeAll(function() {
	    ordersPage = new Orders();
    	catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		orderHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
    });
    
  	beforeEach(function() {
    	catalogPage.open();
    	expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
    	catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    	serviceName = RegexvSphereVmTemplate.serviceNamePrefix+"-"+util.getRandomString(5);
        vmName = RegexvSphereVmTemplate.virtualMachineNamePrefix+"-"+util.getRandomString(5);
        randomrootdisk=RegexvSphereVmTemplate.rootdisksize+util.getRandomString(3);
        randomipaddress=RegexvSphereVmTemplate.ipaddress+util.getRandomString(3);
        randommemory=RegexvSphereVmTemplate.memorysize+util.getRandomString(3);
        randomprefix=RegexvSphereVmTemplate.prefixlength+util.getRandomString(3);
		modifiedParamMap = {"Service Instance Name":serviceName,"Vm 1 Hostname - vm 1":vmName};
    });
  
  	it('ICAM : ICAM-ON Regex Vsphere Virtual Machine ---- Verify fields on Main Parameters page', function(){
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);	
		catalogPage.clickConfigureButtonBasedOnName(RegexvSphereVmTemplate.bluePrintName);
    	expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
    	placeOrderPage.setServiceNameTextICAM("icam-automation-vm-" + util.getRandomString(4));
    	placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
    	expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
  	});

 	it('ICAM : ICAM-ON Regex Vsphere Virtual Machine ---- Verify Summary details and Additional Details are listed in review Order page', function() {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(RegexvSphereVmTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetailsICAM(RegexvSphereVmTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
			//expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPrice);
			expect(requiredReturnMap["Actual"]["User Defined Tag"]).toEqual(requiredReturnMap["Expected"]["User Defined Tag"]);
			expect(requiredReturnMap["Actual"]["Regex tag"]).toEqual(requiredReturnMap["Expected"]["Regex tag"]);
			expect(requiredReturnMap["Actual"]["Instance Plan"]).toEqual(requiredReturnMap["Expected"]["Instance Plan"]);
            expect(requiredReturnMap["Actual"]["Vm 1 Hostname - vm 1"]).toEqual(requiredReturnMap["Expected"]["Vm 1 Hostname - vm 1"]);
            expect(requiredReturnMap["Actual"]["Domain Name - vm 1"]).toEqual(requiredReturnMap["Expected"]["Domain Name - vm 1"]);
            expect(requiredReturnMap["Actual"]["Root Disk Size - vm 1"]).toEqual(requiredReturnMap["Expected"]["Root Disk Size - vm 1"]);
            expect(requiredReturnMap["Actual"]["Operating System ID / Template - vm 1"]).toEqual(requiredReturnMap["Expected"]["Operating System ID / Template - vm 1"]);
            expect(requiredReturnMap["Actual"]["Template Disk Datastore - vm 1"]).toEqual(requiredReturnMap["Expected"]["Template Disk Datastore - vm 1"]);
            expect(requiredReturnMap["Actual"]["Template Disk Type - vm 1"]).toEqual(requiredReturnMap["Expected"]["Template Disk Type - vm 1"]);
            expect(requiredReturnMap["Actual"]["Virtual Machine IP Address - vm 1"]).toEqual(requiredReturnMap["Expected"]["Virtual Machine IP Address - vm 1"]);
            expect(requiredReturnMap["Actual"]["Virtual Machine Memory - vm 1"]).toEqual(requiredReturnMap["Expected"]["Virtual Machine Memory - vm 1"]);
            expect(requiredReturnMap["Actual"]["Virtual Machine Netmask Prefix - vm 1"]).toEqual(requiredReturnMap["Expected"]["Virtual Machine Netmask Prefix - vm 1"]);
			expect(requiredReturnMap["Actual"]["Virtual Machine vCPUs - vm 1"]).toEqual(requiredReturnMap["Expected"]["Virtual Machine vCPUs - vm 1"]);
			
			expect(requiredReturnMap["Actual"]["Virtual Machine vSphere Port Group - vm 1"]).toEqual(requiredReturnMap["Expected"]["Virtual Machine vSphere Port Group - vm 1"]);
			expect(requiredReturnMap["Actual"]["VSphere Cluster - vm 1"]).toEqual(requiredReturnMap["Expected"]["VSphere Cluster - vm 1"]);
			expect(requiredReturnMap["Actual"]["VSphere Datacenter - vm 1"]).toEqual(requiredReturnMap["Expected"]["VSphere Datacenter - vm 1"]);
			expect(requiredReturnMap["Actual"]["VSphere Resource Pool - vm 1"]).toEqual(requiredReturnMap["Expected"]["VSphere Resource Pool - vm 1"]);

        });
  	});	

  	it('ICAM : ICAM-ON Regex Vsphere Virtual Machine ---- Verify Order is listed in Orders details page once it is submitted from catalog page',function(){
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(RegexvSphereVmTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetailsICAM(RegexvSphereVmTemplate, modifiedParamMap).then(function(requiredReturnMap){
	//	var priceInReviewOrder = placeOrderPage.getEstimatedPrice_ReviewOrder();
        placeOrderPage.submitOrder();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
		var orderId = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	//	var priceInSubmitOrderPopup = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
	//	expect(priceInSubmitOrderPopup).toEqual(priceInReviewOrder);
		placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
		
	    //Service details on Order History page
	    orderHistoryPage.open();
		orderHistoryPage.searchOrderById(orderId);
		//No more support on UI 
	    // var priceInOrderHistory = orderHistoryPage.getTextEstimatedCostOrderHistory();
	    // expect(priceInOrderHistory).toEqual(priceInSubmitOrderPopup);
	    orderHistoryPage.clickServiceDetailsLink();
	    expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("User Defined Tag")).toEqual((requiredReturnMap["Expected"]["User Defined Tag"]));
	    expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Regex_tag")).toEqual((requiredReturnMap["Expected"]["Regex tag"]));
	    expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Plan")).toEqual((requiredReturnMap["Expected"]["Instance Plan"]));
	    expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Vm 1 Hostname - vm_1")).toEqual((requiredReturnMap["Expected"]["Vm 1 Hostname - vm 1"]));
	    expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Domain Name - vm_1")).toEqual((requiredReturnMap["Expected"]["Domain Name - vm 1"]));
		expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Root Disk Size - vm_1")).toEqual((requiredReturnMap["Expected"]["Root Disk Size - vm 1"]));
		expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Operating System ID / Template - vm_1")).toEqual((requiredReturnMap["Expected"]["Operating System ID / Template - vm 1"]));
		expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Template Disk Type - vm_1")).toEqual((requiredReturnMap["Expected"]["Template Disk Type - vm 1"]));
		expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Template Disk Datastore - vm_1")).toEqual((requiredReturnMap["Expected"]["Template Disk Datastore - vm 1"]));
		expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Virtual Machine IP Address - vm_1")).toEqual((requiredReturnMap["Expected"]["Virtual Machine IP Address - vm 1"]));
		expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Virtual Machine Memory - vm_1")).toEqual((requiredReturnMap["Expected"]["Virtual Machine Memory - vm 1"]));
		expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Virtual Machine Netmask Prefix - vm_1")).toEqual((requiredReturnMap["Expected"]["Virtual Machine Netmask Prefix - vm 1"]));
		expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Virtual Machine vCPUs - vm_1")).toEqual((requiredReturnMap["Expected"]["Virtual Machine vCPUs - vm 1"]));
		expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Virtual Machine vSphere Port Group - vm_1")).toEqual((requiredReturnMap["Expected"]["Virtual Machine vSphere Port Group - vm 1"]));
		expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("VSphere Cluster - vm_1")).toEqual((requiredReturnMap["Expected"]["VSphere Cluster - vm 1"]));
		expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("VSphere Datacenter - vm_1")).toEqual((requiredReturnMap["Expected"]["VSphere Datacenter - vm 1"]));
		expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("VSphere Resource Pool - vm_1")).toEqual((requiredReturnMap["Expected"]["VSphere Resource Pool - vm 1"]));
		orderHistoryPage.clickBillOfMaterialsTabInServiceDetails();
	  //  expect(orderHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);
	    orderHistoryPage.closeServiceDetailsSlider();
	    orderHistoryPage.clickBillOfMaterials();
	//	expect(orderHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);
		
		//Service details on Approve Orders page
        ordersPage.open();
        expect(util.getCurrentURL()).toMatch(messageStrings.urlOrders);
        ordersPage.searchOrderById(orderId);
		expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderId);
		//No more support on UI 
		// var priceInApproveOrders = ordersPage.getTextFirstAmountOrdersTable();
	    // expect(priceInApproveOrders).toEqual(priceInSubmitOrderPopup);
		var orderAmount = ordersPage.getTextFirstAmountOrdersTable();
        ordersPage.clickFirstViewDetailsOrdersTable();
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
        expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual(messageStrings.approvalState);
        expect(ordersPage.getTextSubmittedByOrderDetails()).toContain(catalogPage.extractUserFirstName());
        expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
        expect(ordersPage.isDisplayedDenyButtonOrderDetails()).toEqual(true);
        ordersPage.clickServiceConfigurationsTabOrderDetails();
		expect(ordersPage.getTextBasedOnLabelName("User Defined Tag")).toEqual((requiredReturnMap["Expected"]["User Defined Tag"]));
		expect(ordersPage.getTextBasedOnLabelName("Regex_tag")).toEqual((requiredReturnMap["Expected"]["Regex tag"]));
		expect(ordersPage.getTextBasedOnLabelName("Instance Plan")).toEqual((requiredReturnMap["Expected"]["Instance Plan"]));
		expect(ordersPage.getTextBasedOnLabelName("Vm 1 Hostname - vm_1")).toEqual((requiredReturnMap["Expected"]["Vm 1 Hostname - vm 1"]));
		expect(ordersPage.getTextBasedOnLabelName("Domain Name - vm_1")).toEqual((requiredReturnMap["Expected"]["Domain Name - vm 1"]));
		expect(ordersPage.getTextBasedOnLabelName("Root Disk Size - vm_1")).toEqual((requiredReturnMap["Expected"]["Root Disk Size - vm 1"]));
		expect(ordersPage.getTextBasedOnLabelName("Operating System ID / Template - vm_1")).toEqual((requiredReturnMap["Expected"]["Operating System ID / Template - vm 1"]));		
		expect(ordersPage.getTextBasedOnLabelName("Template Disk Datastore - vm_1")).toEqual((requiredReturnMap["Expected"]["Template Disk Datastore - vm 1"]));
		expect(ordersPage.getTextBasedOnLabelName("Template Disk Type - vm_1")).toEqual((requiredReturnMap["Expected"]["Template Disk Type - vm 1"]));
		expect(ordersPage.getTextBasedOnLabelName("Virtual Machine IP Address - vm_1")).toEqual((requiredReturnMap["Expected"]["Virtual Machine IP Address - vm 1"]));
		expect(ordersPage.getTextBasedOnLabelName("Virtual Machine Memory - vm_1")).toEqual((requiredReturnMap["Expected"]["Virtual Machine Memory - vm 1"]));
		expect(ordersPage.getTextBasedOnLabelName("Virtual Machine Netmask Prefix - vm_1")).toEqual((requiredReturnMap["Expected"]["Virtual Machine Netmask Prefix - vm 1"]));
		expect(ordersPage.getTextBasedOnLabelName("Virtual Machine vCPUs - vm_1")).toEqual((requiredReturnMap["Expected"]["Virtual Machine vCPUs - vm 1"]));
		expect(ordersPage.getTextBasedOnLabelName("Virtual Machine vSphere Port Group - vm_1")).toEqual((requiredReturnMap["Expected"]["Virtual Machine vSphere Port Group - vm 1"]));		
		expect(ordersPage.getTextBasedOnLabelName("VSphere Cluster - vm_1")).toEqual((requiredReturnMap["Expected"]["VSphere Cluster - vm 1"]));
		expect(ordersPage.getTextBasedOnLabelName("VSphere Datacenter - vm_1")).toEqual((requiredReturnMap["Expected"]["VSphere Datacenter - vm 1"]));
		expect(ordersPage.getTextBasedOnLabelName("VSphere Resource Pool - vm_1")).toEqual((requiredReturnMap["Expected"]["VSphere Resource Pool - vm 1"]));

        ordersPage.clickBillOfMaterialsTabOrderDetails();
    //    expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);
      
        }); 
	});
	
	if(isProvisioningRequired == "true") {
		it('ICAM-ON Regex Vsphere Virtual Machine --- Verify Provision and Delete services', function() {
		
			var orderObject = {} ;
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.clickConfigureButtonBasedOnName(RegexvSphereVmTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetailsICAM(RegexvSphereVmTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			//orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject,messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState); 
			orderFlowUtil.verifyOrderStatus(orderObject).then(function(status){
						
				    //Delete service
					if (status == 'Completed') {
						orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
						expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
						orderFlowUtil.approveDeletedOrder(orderObject);
						orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
						expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState);
				  }    
	         });     
		});
     }

        it('ICAM : ICAM-ON Regex Vsphere Virtual Machine ---- Verify that for Regex Vsphere Virtual Machine dynamic validation is working or not', function () {

			var orderObject = {} ;
			var modifiedParamMap = { "dynamicValidation":true,"Service Instance Name":serviceName,
			"Root Disk Size - vm 1": randomrootdisk,
			"Virtual Machine IP Address - vm 1": randomipaddress};
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.clickConfigureButtonBasedOnName(RegexvSphereVmTemplate.bluePrintName);
			placeOrderPage.setServiceNameText("icam-automation-Regex-" + util.getRandomString(4));
			orderFlowUtil.fillOrderDetails(RegexvSphereVmTemplate, modifiedParamMap)
			placeOrderPage.setRegexRootdisksizeText(randomrootdisk);
			expect(placeOrderPage.dynamicErrorrootdisksize()).toContain(messageStrings.rootdiskerrorMessage);
			placeOrderPage.setRegexvirtualmachineipText(randomipaddress);
            expect(placeOrderPage.dynamicErrorvirtualmachineip()).toContain(messageStrings.iperrorMessage);
        });
  });