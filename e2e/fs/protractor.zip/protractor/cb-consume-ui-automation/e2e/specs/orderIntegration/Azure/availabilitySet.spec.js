/*
Spec_Name: Availability Set .spec.js 
Description: This spec will cover E2E testing of Availability Set  service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../../testData/appUrls.json'),
        orderDetailsJson = require('../../../../testData/orderDetails.json'),
        userCredentialsTemplate = require('../../../../testData/credentials.json'),
        superUserUsername = browser.params.username,
        util = require('../../../../helpers/util.js'),
        jsonUtil = require('../../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
        AVtemplate = require('../../../../testData/OrderIntegration/Azure/av.json');

describe('Azure - Availability Set ', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, ordersHistoryPage, catalogDetailsPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Other services' };
        var modifiedParamMap = {};
        var servicename = "AutoAVsrv" + util.getRandomString(5);
        var rgName = "gslautotc_azureAVRG101" + util.getRandomString(5);
        var avName = "autoAV" + util.getRandomString(5);
        var SOIComponents;
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Availability Set Name": avName };

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                catalogDetailsPage = new CatalogDetailsPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                ordersHistoryPage = new OrderHistoryPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
                rgName = "gslautotc_azureAVRG101" + util.getRandomString(5);
                avName = "autoAV" + util.getRandomString(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Availability Set Name": avName };
                SOIComponents = [avName]
        });

        //Checking parameters on Details page
        it('Azure: T368860- verify that for Availability Set Service all parameters on catlog Details page / main parameters are present.', function () {
                var orderObject = JSON.parse(JSON.stringify(AVtemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
                expect(catalogDetailsPage.getServiceName()).toBe(orderObject.bluePrintName)
                expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true);
                expect(catalogDetailsPage.isPresentLinkToProviderSite()).toBe(true);
                expect(catalogDetailsPage.isPresentFeaturesLabel()).toBe(true);
                expect(catalogDetailsPage.isPresentDetailsLabel()).toBe(true);
                expect(catalogDetailsPage.getTextFeaturesLabel()).toBe(orderObject.FeaturesLabel);
                expect(catalogDetailsPage.getTextDetailsLabel()).toBe(orderObject.DetailsLabel);
                expect(catalogDetailsPage.isPresentFeaturesInfo()).toBe(true);
                expect(catalogDetailsPage.isPresentDetailsInfo()).toBe(true);
                if (browser.params.defaultCurrency == "USD") {
                        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
                }
        });

        //Checking values all parameters on Review Order Page and View Order Details
        it('Azure: T368873 verify that for Availability Set  Service all values on Review Order Details page and View Order Details page matches with input.', function () {
                var returnObj = {};
                returnObj.servicename = servicename;
                var orderObject = JSON.parse(JSON.stringify(AVtemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(AVtemplate, modifiedParamMap);
                //Checking Service Details in ReviewOrder
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
                if (browser.params.defaultCurrency == "USD") {
                        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
                }
                //Checking Additional Details in ReviewOrder
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                expect(placeOrderPage.getTextBasedOnLabelName("Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(placeOrderPage.getTextBasedOnLabelName("Availability Set Name:")).toEqual(avName);
                expect(placeOrderPage.getTextBasedOnLabelName("Availability Set Location:")).toEqual(jsonUtil.getValue(orderObject, "Availability Set Location"));
                expect(placeOrderPage.getTextBasedOnLabelName("Use Managed Disk:")).toEqual(jsonUtil.getValue(orderObject, "Use Managed Disk"));
                expect(placeOrderPage.getTextBasedOnLabelName("Fault Domains:")).toEqual(jsonUtil.getValue(orderObject, "Fault Domains"));
                expect(placeOrderPage.getTextBasedOnLabelName("Update Domains:")).toEqual(jsonUtil.getValue(orderObject, "Update Domains"));
                expect(placeOrderPage.getTextBasedOnLabelName("Proximity Placement Group:")).toEqual(jsonUtil.getValue(orderObject, "Proximity Placement Group"));
                placeOrderPage.submitOrder();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                ordersPage.open();
                ordersPage.searchOrderById(returnObj.orderNumber);
                if (browser.params.defaultCurrency == "USD") {
                        expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(orderObject.EstimatedCost);
                }
                ordersPage.clickFirstViewDetailsOrdersTable();
                //Checking Order Details in View order details
                expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
                //Checking Service Configuration Parameters
                ordersPage.clickServiceConfigurationsTabOrderDetails();
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
                expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Availability Set Name")).toEqual(avName);
                expect(ordersPage.getTextBasedOnExactLabelName("Availability Set Location")).toEqual(jsonUtil.getValue(orderObject, "Availability Set Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Use Managed Disk")).toEqual(jsonUtil.getValue(orderObject, "Use Managed Disk"));
                expect(ordersPage.getTextBasedOnExactLabelName("Fault Domains")).toEqual(jsonUtil.getValue(orderObject, "Fault Domains"));
                expect(ordersPage.getTextBasedOnExactLabelName("Update Domains")).toEqual(jsonUtil.getValue(orderObject, "Update Domains"));
                //Checking Bill Of Material
                if (browser.params.defaultCurrency == "USD") {
                        ordersPage.clickBillOfMaterialsTabOrderDetails();
                        expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
                }
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(returnObj.orderNumber);
                if (browser.params.defaultCurrency == "USD") {
                        expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(orderObject.EstimatedCost);
                }
        });
        
        //E2E Availability Set  order Submit, Approve, Delete Service with New Resource Group.
        if (isProvisioningRequired == "true") {
                it('Azure: T368884- Verify that for Availability Set  Service,if service is created with new resource group with valid name and location,create valid Availability Set  Name and Availability Set  Location', function () {

                        var approvedBy = orderDetailsJson.approvedBy +  userCredentialsTemplate.superUserName +  " (" + superUserUsername + ") on "+ util.getMonthOfCurrentYear() +  " " + util.getTodaysDate() + ", "  + util.getFullYearOfTodaysDate();
                        var provisionedBy = orderDetailsJson.provisionedBy  +"System started on "+ util.getMonthOfCurrentYear() +  " " + util.getTodaysDate() + ", "  + util.getFullYearOfTodaysDate();
                        var completedBy = orderDetailsJson.completedBy   +"System on "+ util.getMonthOfCurrentYear() +  " " + util.getTodaysDate() + ", "  + util.getFullYearOfTodaysDate();
                        var orderObject = JSON.parse(JSON.stringify(AVtemplate));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};
                        orderFlowUtil.fillOrderDetails(AVtemplate, modifiedParamMap);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        //Search order 
                        ordersPage.open();
                        ordersPage.searchOrderById(returnObj.orderNumber);
                        if (browser.params.defaultCurrency == "USD") {
                                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(orderObject.EstimatedCost);
                        }
                        //Go to order update section
                        ordersPage.clickOnViewDetailsLink();
                        //Verify order Submitted state before approval 
                        expect(ordersPage.getTextOrderStateOnOrderUpdateTab(orderDetailsJson.submittedOrderStatus, 0)).toContain(orderDetailsJson.submittedOrderStatus);
                        ordersPage.clickOnCloseButtonOfViewDetailSlidder();
                        //Go to order history page > search order > order details
                        ordersHistoryPage.open();
                        ordersHistoryPage.searchOrderById(returnObj.orderNumber);
                        ordersHistoryPage.clickOnOrderDetails();
                        //Verify order Submitted state before approval for order history page
                        util.waitForAngular();
                        expect(ordersPage.getTextOrderStateOnOrderUpdateTab(orderDetailsJson.submittedOrderStatus, 4)).toContain(orderDetailsJson.submittedOrderStatus);
                        ordersPage.clickOnCloseButtonOfViewDetailSlidder();
                        // approve the order
                        orderFlowUtil.approveOrder(returnObj);
                        // wait for order to get in completed state
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                       
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Checking Inventory Page Service Configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(inventoryPage.getTextBasedOnLabelName("Availability Set Name:")).toEqual(avName);
                        expect(inventoryPage.getTextBasedOnLabelName("Availability Set Location:")).toEqual(jsonUtil.getValue(orderObject, "Availability Set Location"));
                        expect(inventoryPage.getTextBasedOnLabelName("Use Managed Disk:")).toEqual(jsonUtil.getValue(orderObject, "Use Managed Disk"));
                        expect(inventoryPage.getTextBasedOnLabelName("Fault Domains:")).toEqual(jsonUtil.getValue(orderObject, "Fault Domains"));
                        expect(inventoryPage.getTextBasedOnLabelName("Update Domains:")).toEqual(jsonUtil.getValue(orderObject, "Update Domains"));
                        expect(inventoryPage.getTextBasedOnLabelName("Proximity Placement Group:")).toEqual(jsonUtil.getValue(orderObject, "Proximity Placement Group"));
                        inventoryPage.closeViewDetailsTab();
                        //Checking SOI Components
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.clickExpandFirstRow().then(function () {
                                        browser.executeScript('window.scrollTo(0,0);');
                                        var i = 1;
                                        async.forEachSeries(SOIComponents, function (component, callback) {
                                                inventoryPage.clickOverMenuIcon(i).then(function () {
                                                        inventoryPage.clickOnViewComponent(i).then(function () {
                                                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.bluePrintName);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(rgName);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.mcmpTag);
                                                                inventoryPage.closeViewComponent();
                                                                browser.sleep(10000);
                                                                i++;
                                                                return callback();
                                                        });
                                                })
                                        }, function (error) {
                                                if (error) {
                                                        logger.info('Unable to Get SOI component')
                                                }
                                        })
                                })
                        }
                        ordersPage.open();
                       // Delete  Availability Set.
                        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                        orderFlowUtil.approveDeletedOrder(returnObj);
                        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
                        browser.sleep(8000);
                         // search order and go to order update section
                         ordersPage.open();
                         ordersPage.clickAllOrdersUnderOrdersSection();
                         ordersPage.searchOrderById(returnObj.orderNumber);
                         ordersPage.clickOnViewDetailsLink();
                         //Verify order approval state
                         expect(ordersPage.getTextOrderStateOnOrderUpdateTab(orderDetailsJson.approvedOrderStatus, 0)).toContain(orderDetailsJson.approvedOrderStatus);
                         //verify technical and financial approval section
                         expect(ordersPage.verifyApprovalOrderStatus(orderDetailsJson.approvedOrderStatus)).toBe(true, "Approval Status does not Matched");
                         ordersPage.expandTheFinancialApprovalFromTheOrderDetailsPage();
                         expect(ordersPage.getFinancialApprovalDetails()).toContain(approvedBy);
                         ordersPage.expandTheTechnicalApprovalFromTheOrderDetailsPage();
                         expect(ordersPage.getTechnicalApproversDetails()).toContain(approvedBy);
                         //Verify provisioning in progress state and metadata
                         expect(ordersPage.getTextOrderStateOnOrderUpdateTab(orderDetailsJson.provisioningOrderStatus, 0)).toContain(provisionedBy);
                         //Verify completed state and metadata
                         expect(ordersPage.getTextOrderStateOnOrderUpdateTab(orderDetailsJson.completedOrderStatus, 0)).toContain(completedBy);
                         ordersPage.clickOnCloseButtonOfViewDetailSlidder();
                         //search order and go to order update section of order history page
                         //Go to order history page > search order > order details
                         ordersHistoryPage.open();
                         ordersHistoryPage.searchOrderById(returnObj.orderNumber);
                         ordersHistoryPage.clickOnOrderDetails();
                         //Verify order approval state in order history page
                         expect(ordersPage.getTextOrderStateOnOrderUpdateTab(orderDetailsJson.approvedOrderStatus, 1)).toContain(orderDetailsJson.approvedOrderStatus);
                         //verify technical and financial approval section in order history page
                         expect(ordersHistoryPage.verifyApprovalOrderStatus(orderDetailsJson.approvedOrderStatus)).toBe(true, "Approval Status does not Matched");
                         ordersHistoryPage.expandTheFinancialApprovalFromTheOrderDetailsPage();
                         expect(ordersHistoryPage.getFinancialApprovalDetails()).toContain(approvedBy);
                         ordersHistoryPage.expandTheTechnicalApprovalFromTheOrderDetailsPage();
                         expect(ordersHistoryPage.getTechnicalApproversDetails()).toContain(approvedBy);
                         //Verify provisioning in progress state and metadata in order history page
                         expect(ordersPage.getTextOrderStateOnOrderUpdateTab(orderDetailsJson.provisioningOrderStatus, 1)).toContain(provisionedBy);
                         //Verify completed state and metadata in order history page
                         expect(ordersPage.getTextOrderStateOnOrderUpdateTab(orderDetailsJson.completedOrderStatus, 1)).toContain(completedBy);
                         ordersPage.clickOnCloseButtonOfViewDetailSlidder();
                });
        }
});