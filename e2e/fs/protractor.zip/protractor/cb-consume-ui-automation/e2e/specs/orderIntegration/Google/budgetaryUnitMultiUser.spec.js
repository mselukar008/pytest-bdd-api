"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
	HomePage = require('../../../pageObjects/home.pageObject.js'),
	CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
	BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),
	budgetDeleteApi = require('../../../../helpers/budgetDeleteApiUtil.js'),
	util = require('../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	budgetaryFlow = require('../../../../helpers/budgetaryFlow.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	superUserUsername = browser.params.username,
	superUserPassword = browser.params.password,
	userCredentialsTemplate = require('../../../../testData/credentials.json'),
	persistentDiskTemplate = require('../../../../testData/OrderIntegration/Google/persistentdisk.json'),
	budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
	budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryAddNewBudgetDetails.json');

describe('GCP - Multi user budget Functionlaities', function () {
	var ordersPage, homePage, catalogPage, placeOrderPage, cartListPage, budgetryPage, orderHistoryPage, budgetaryUnitCode, budgetaryNewBudgetName, budgetaryName, serviceName, cartName, userCredntialsObject, budgetName;
	var modifiedParamMap = {};
	var modifiedParamMapBudget = {};
	var modifiedNewBudgetParamMap = {};
	var messageStrings = {
		catalogPageTitle: persistentDiskTemplate.catalogPageTitle,
		inputServiceNameWarning: persistentDiskTemplate.inputServiceNameWarning,
		orderSubmittedConfirmationMessage: persistentDiskTemplate.orderSubmittedConfirmationMessage,
		providerName: persistentDiskTemplate.provider,
		completedState: persistentDiskTemplate.completedState,
		budgetDeletedApiSucessMsg: "Success",
		budgetaryUnitDeletedApiSucessMsg: "Success",
		budgetaryUnitDeleteSuccessMsg:budgetaryUnitDetailsTemplate.budgetaryUnitDeleteSuccessMsg
	};

	beforeAll(function () {
		ordersPage = new Orders();
		homePage = new HomePage();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		orderHistoryPage = new OrderHistoryPage();
		budgetryPage = new BudgetaryPage();
		browser.driver.manage().window().maximize();
		userCredntialsObject = JSON.parse(JSON.stringify(userCredentialsTemplate));
		budgetaryName = "gcpAutMultiUser" + util.getRandomString(8);
		budgetaryNewBudgetName = "newgcpAut" + util.getRandomString(8);
		budgetaryUnitCode = "gcpCode" + util.getRandomString(8);
		serviceName = "multiUserbudgetGcp" + util.getRandomString(5);
		modifiedParamMap = { "Service Instance Name": serviceName, "Team": "budgetTEAM1", "Environment": "gcpEnv", "Application": "gcpApp", "Provider Account": "" };
		modifiedParamMapBudget = { "budgetary Name": budgetaryName, "budgetary unit code": budgetaryUnitCode, "Choose Entity": "Organization", "Entity Value": "budgetORG", "Environment": "gcpEnv", "Application": "gcpApp" };

	});
	
	//Pre-Requisite
	/*1.Make sure to have budget is already created.
	2.Context text for Environment and application must be available.
	3.Context must be mapped to TEAM.*/

	it('MultiuserBudget - Add new budgetry Unit for E2E budget Flow ', function () {
		orderFlowUtil.closeHorizontalSliderIfPresent();
		catalogPage.getUserID(userCredentialsTemplate.superUserName).then(function (status) {
			if (status != true) {			
				cartListPage.clickUserIcon();	
				cartListPage.clickLogoutButton();
				cartListPage.loginFromOtherUser(userCredentialsTemplate.superUserID, userCredentialsTemplate.superUserPassword);
				catalogPage.open();
				expect(catalogPage.getUserID(userCredentialsTemplate.superUserName)).toBe(true);
			}			
		});
		budgetryPage.open();		
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMapBudget);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		var startPeriod = budgetaryFlow.incrementMonth(0);
		modifiedNewBudgetParamMap = { "Name": budgetaryNewBudgetName, "Start Period": startPeriod, "Notify When Soft Quota reached": "budgetTEAM1", "Notify When Hard Quota reached": "budgetTEAM1" };		
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		budgetryPage.clickOnNotificationCloseButton();
		//budgetryPage.clickOnBudgetaryBackBudgetButton();
		budgetryPage.clickBudgetSliderCloseButton();
	});

	it('GCP : Multi User Budget Validation for GCP Persistent disk Service', async function () {
		var availBudgetProvCompleted, afterProvCommittedAmnt, beforePovisioningAvailBudget;
		var orderObject = {};
		//var persistentDiskInsObject = JSON.parse(JSON.stringify(persistentDiskTemplate));
		// Logout from the super user
		orderFlowUtil.closeHorizontalSliderIfPresent();
		catalogPage.open();
		//cartListPage.clickUserIcon();
		//cartListPage.clickLogoutButton();
		//login with the buyer role user and place order
		await cartListPage.loginFromOtherUser(userCredntialsObject.buyerUserID, userCredntialsObject.buyerUserPassword);
		catalogPage.open();
		expect(catalogPage.getUserID(userCredntialsObject.buyerUserName)).toBe(true);
		util.switchToFrame();
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
		catalogPage.clickProviderOrCategoryCheckbox(persistentDiskTemplate.Category);
		orderObject.servicename = serviceName;
		global.serviceName = serviceName;
		catalogPage.clickConfigureButtonBasedOnName(persistentDiskTemplate.bluePrintName);

		orderFlowUtil.fillOrderDetails(persistentDiskTemplate, modifiedParamMap).then(async function (ttt) {
			//Submit order
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();

			placeOrderPage.getTextSubmittedByOrderSubmittedModal().then(function (ordersubmittedBy) {
				expect(ordersubmittedBy.split(" ")[0]).toEqual((userCredntialsObject.buyerUserName).split(" ")[0]);
			});

			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

			// Logout from the buyer role user
			//cartListPage.clickUserIcon();
			//cartListPage.clickLogoutButton();

			await cartListPage.loginFromOtherUser(userCredntialsObject.technicalApprovalUserID, userCredntialsObject.technicalApprovalUserPass);
			expect(catalogPage.getUserID(userCredntialsObject.technicalApprovalUser)).toBe(true);
			orderFlowUtil.approveOrderTechnically(orderObject);
			//to check budget is not present as the user have only technical approval role
			await expect(ordersPage.checkInvisibilityOfBudgetDetails()).toBe(false, "For technically approval role user Budget details is not present on the Approve order page.")

			//log out from the technically approval role user
			//browser.ignoreSynchronization = false;
			//ordersPage.open();
			catalogPage.open();
			//cartListPage.clickUserIcon();
			//cartListPage.clickLogoutButton();

			//login from the financially approval role user
			await cartListPage.loginFromOtherUser(userCredntialsObject.financialApprovalUserID, userCredntialsObject.financialApprovalUserPass);
			expect(catalogPage.getUserID(userCredntialsObject.financialApprovalUser)).toBe(true);

			ordersPage.open();
			ordersPage.searchOrderById(orderObject.orderNumber);
			//select Budgetary Unit
			ordersPage.selectBudgetaryUnit(budgetaryName);
			util.waitForAngular();
			//Budget verification 
			if (browser.params.defaultCurrency == "USD") {
				expect(ordersPage.getTextBudgetAmmount()).toEqual(persistentDiskTemplate.OrdersPageBudgetAmount);
				var beforePovisioningCommittedAmount = await ordersPage.getTextBudgetaryCommittedAmmount();
				var calculatedEstAmount = ordersPage.calculateBudgetaryEstimatedAmmountforOrder(persistentDiskTemplate.budgetDuration, persistentDiskTemplate.TotalCost);
				beforePovisioningAvailBudget = await ordersPage.getTextAvailableBudget();
				var costOtherOrdersAwaitingApprovalBeforeProvision = await ordersPage.getTextOtherOrdersAwaitingApproval();
				expect(ordersPage.getTextBudgetarySpendAmmount()).toEqual("USD 0.00");
				expect(ordersPage.getTextBudgetaryEstimatedAmmountforOrder()).toContain(calculatedEstAmount);
			}
			orderFlowUtil.approveOrderFinancially(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState).then(function () {

				/********** Order provisioning completed **********/
				//order status completed
				if (browser.params.defaultCurrency == "USD") {
					availBudgetProvCompleted = ordersPage.calculateAvailableBudgetAfterProvCompleted(beforePovisioningAvailBudget, calculatedEstAmount);
					expect(ordersPage.getTextAvailableBudget()).toContain(availBudgetProvCompleted);

					var actualOrdersAwaitingApprovalAmout = ordersPage.calculateAfterProvOtherOrderAwaitingApprovalAmount(costOtherOrdersAwaitingApprovalBeforeProvision, calculatedEstAmount);
					expect(ordersPage.getTextOtherOrdersAwaitingApproval()).toEqual(actualOrdersAwaitingApprovalAmout);

					afterProvCommittedAmnt = ordersPage.calculateCommittedAmountAfterProvCompleted(beforePovisioningCommittedAmount, calculatedEstAmount);
					expect(ordersPage.getTextBudgetaryCommittedAmmount()).toContain(afterProvCommittedAmnt);

					expect(ordersPage.getTextBudgetarySpendAmmount()).toEqual("USD 0.00");
				}
			});

			//browser.ignoreSynchronization = false;
			//Open Approve order page
			ordersPage.open();
			//Logout from the financial approval user roles
			//cartListPage.clickUserIcon();
			//cartListPage.clickLogoutButton();

			//Login from the buyer role user 
			await cartListPage.loginFromOtherUser(userCredntialsObject.buyerUserID, userCredntialsObject.buyerUserPassword);
			expect(catalogPage.getUserID(userCredntialsObject.buyerUserName)).toBe(true);
			//Place the deleteorder from the buyer role			
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			// expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
			//catalogPage.open();
			//Logout from the buyer role user
			//cartListPage.clickUserIcon();
			//cartListPage.clickLogoutButton();
			//Login from the technically approval role user
			await cartListPage.loginFromOtherUser(userCredntialsObject.technicalApprovalUserID, userCredntialsObject.technicalApprovalUserPass);
			expect(catalogPage.getUserID(userCredntialsObject.technicalApprovalUser)).toBe(true);
			orderFlowUtil.approveDeletedOrderTechnically(orderObject);
			//Logout from the technically approval role user
			//catalogPage.open();
			//cartListPage.clickUserIcon();
			//cartListPage.clickLogoutButton();
			//Login from the financially approval role user
			await cartListPage.loginFromOtherUser(userCredntialsObject.financialApprovalUserID, userCredntialsObject.financialApprovalUserPass);
			expect(catalogPage.getUserID(userCredntialsObject.financialApprovalUser)).toBe(true);
			//catalogPage.open();
			orderFlowUtil.approveDeletedOrderFinancially(orderObject);

			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState).then(function () {

				/********** Delete order status completed **********/
				if (browser.params.defaultCurrency == "USD") {
					var estCostAfterDeleting1MonthOrder = ordersPage.calculateEstCostAfterDeleting1MonthOrder(calculatedEstAmount, persistentDiskTemplate.TotalCost);
					expect(estCostAfterDeleting1MonthOrder).toContain(ordersPage.getTextBudgetaryEstimatedAmmountforOrder());

					var deletedCommittedAmnt = ordersPage.calculateDeleteCommittedAmount(afterProvCommittedAmnt, estCostAfterDeleting1MonthOrder);
					expect(deletedCommittedAmnt).toContain(ordersPage.getTextBudgetaryCommittedAmmount());

					var deletedAvailableBudget = ordersPage.calculateAfterDeletingAvailBudget(availBudgetProvCompleted, estCostAfterDeleting1MonthOrder);
					expect(deletedAvailableBudget).toContain(ordersPage.getTextAvailableBudget());
				}

			});
			//Logout from the financially approval role user
			//cartListPage.clickUserIcon();
			//cartListPage.clickLogoutButton();
			//Login with super user
			await cartListPage.loginFromOtherUser(superUserUsername, superUserPassword);
			expect(catalogPage.getUserID(userCredntialsObject.superUserName)).toBe(true);
		});

	});

	afterAll(async function () {				
		orderFlowUtil.closeHorizontalSliderIfPresent();		
		//catalogPage.open();			
		catalogPage.getUserID(userCredentialsTemplate.superUserName).then(async function (status) {
			if (status != true) {
				//cartListPage.clickUserIcon();
				//cartListPage.clickLogoutButton();
				await cartListPage.loginFromOtherUser(userCredentialsTemplate.superUserID, userCredentialsTemplate.superUserPassword);
				catalogPage.open();
				expect(catalogPage.getUserID(userCredentialsTemplate.superUserName)).toBe(true);
			}		
		});
		budgetryPage.deleteBudget(budgetaryName);
		//expect(budgetryPage.getNotificationMsg()).toContain(messageStrings.budgetaryUnitDeleteSuccessMsg);
	});

});
