//Author: Atiksha Batra
"use strict";
var logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    async = require('async'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    PostgreSQLSingleTemplate = require('../../../../testData/OrderIntegration/Azure/postgreSqlSingleServer.json');

describe('Azure - Azure Database for PostgreSQL servers (Single server) Service ', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, servicename, SOIComponents;
    var modifiedParamMap = {};
    var servicename = "AutoPostgresSqlsrv" + util.getRandomString(5);
    var newResourceGroupName = "gslautotc_azurePostgreSql-RG101" + util.getRandomString(4);
    var serverName = "autoserver" + util.getRandomString(4);
    serverName = serverName.toLowerCase();
    var messageStrings = { providerName: 'Azure', category: 'Databases', templateName: 'Azure Database for PostgreSQL servers (Single server)' };
    SOIComponents = [serverName]
    modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Server Name": serverName };

    beforeAll(function () {
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    afterAll(function () {
        // Delete Azure Database for PostgreSQL servers (Single server) Service 
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    it('Azure: Verify that for Azure Database for PostgreSQL servers (Single server) required parameters on Service Details Page are present.', function () {
        var postgreSqlSingleObject = JSON.parse(JSON.stringify(PostgreSQLSingleTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(postgreSqlSingleObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(postgreSqlSingleObject.bluePrintName);
        if (browser.params.defaultCurrency == "USD") {
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(postgreSqlSingleObject.BasePrice);
        }
    });

    it('Azure: Verify Review order and View Order Details for Azure Database for PostgreSQL servers (Single server)', function () {
        var orderObject = {};
        orderObject.servicename = servicename;
        var postgreSqlSingleObject = JSON.parse(JSON.stringify(PostgreSQLSingleTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(postgreSqlSingleObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(postgreSqlSingleObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(PostgreSQLSingleTemplate, modifiedParamMap);
        //Verify input values on Review Order page    
        expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "New Resource Group Required"));
        expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
        expect(placeOrderPage.getTextBasedOnLabelName("Location:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Server Name:")).toEqual(serverName);
        expect(placeOrderPage.getTextBasedOnLabelName("Data Source:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Data Source"));
        expect(placeOrderPage.getTextBasedOnLabelName("Server Location:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Server Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Version:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Version"));
        expect(placeOrderPage.getTextBasedOnLabelName("Compute + storage:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Compute + storage"));
        expect(placeOrderPage.getTextBasedOnLabelName("VCore:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "VCore"));
        expect(placeOrderPage.getTextBasedOnLabelName("Storage In GB:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Storage In GB"));
        expect(placeOrderPage.getTextBasedOnLabelName("Storage-auto-growth:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Storage-auto-growth"));
        expect(placeOrderPage.getTextBasedOnLabelName("Backup Retention Period:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Backup Retention Period"));
        expect(placeOrderPage.getTextBasedOnLabelName("Backup Redundancy Options:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Backup Redundancy Options"));
        expect(placeOrderPage.getTextBasedOnLabelName("Admin Username:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Admin Username"));
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(orderObject.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(orderObject.servicename);//Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe('Azure');//Checking Provider
        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "New Resource Group Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(newResourceGroupName);
        expect(ordersPage.getTextBasedOnExactLabelName("Server Name")).toEqual(serverName);
        expect(ordersPage.getTextBasedOnExactLabelName("Data Source")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Data Source"));
        expect(ordersPage.getTextBasedOnExactLabelName("Server Location")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Server Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("Version")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Version"));
        expect(ordersPage.getTextBasedOnExactLabelName("Compute + storage")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Compute + storage"));
        expect(ordersPage.getTextBasedOnExactLabelName("VCore")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "VCore"));
        expect(ordersPage.getTextBasedOnExactLabelName("Storage In GB")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Storage In GB"));
        expect(ordersPage.getTextBasedOnExactLabelName("Storage-auto-growth")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Storage-auto-growth"));
        expect(ordersPage.getTextBasedOnExactLabelName("Backup Retention Period")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Backup Retention Period"));
        expect(ordersPage.getTextBasedOnExactLabelName("Backup Redundancy Options")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Backup Redundancy Options"));
        expect(ordersPage.getTextBasedOnExactLabelName("Admin Username")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Admin Username"));
        //Checking Bill Of Material
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(ordersPage.getEstimatedCost()).toBe(postgreSqlSingleObject.TotalCost);
        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
    });

    if (isProvisioningRequired == "true") {
        it('Azure: Verify provisioning of Azure Database for Azure Database for PostgreSQL servers (Single server) using Consume UI', function () {
            var orderObject = {};
            orderObject.servicename = servicename;
            var postgreSqlSingleObject = JSON.parse(JSON.stringify(PostgreSQLSingleTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(postgreSqlSingleObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(postgreSqlSingleObject.bluePrintName);
            orderFlowUtil.fillOrderDetails(PostgreSQLSingleTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
            inventoryPage.clickViewService();
            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "New Resource Group Required"));
            expect(inventoryPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
            expect(inventoryPage.getTextBasedOnLabelName("Location:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Location"));
            expect(inventoryPage.getTextBasedOnLabelName("Server Name:")).toEqual(serverName);
            expect(inventoryPage.getTextBasedOnLabelName("Data Source:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Data Source"));
            expect(inventoryPage.getTextBasedOnLabelName("Server Location:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Server Location"));
            expect(inventoryPage.getTextBasedOnLabelName("Version:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Version"));
            expect(inventoryPage.getTextBasedOnLabelName("Compute + storage:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Compute + storage"));
            expect(inventoryPage.getTextBasedOnLabelName("Storage In GB:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Storage In GB"));
            expect(inventoryPage.getTextBasedOnLabelName("Storage-auto-growth:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Storage-auto-growth"));
            expect(inventoryPage.getTextBasedOnLabelName("Backup Retention Period:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Backup Retention Period"));
            expect(inventoryPage.getTextBasedOnLabelName("Backup Redundancy Options:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Backup Redundancy Options"));
            expect(inventoryPage.getTextBasedOnLabelName("Admin Username:")).toEqual(jsonUtil.getValue(postgreSqlSingleObject, "Admin Username"));
            inventoryPage.closeViewDetailsTab();
            //Checking SOI Components
            if (isDummyAdapterDisabled == "true") {
                inventoryPage.clickExpandFirstRow().then(function () {
                    browser.executeScript('window.scrollTo(0,0);');
                    var i = 1;
                    async.forEachSeries(SOIComponents, function (component, callback) {
                        inventoryPage.clickOverMenuIcon(i).then(function () {
                            inventoryPage.clickOnViewComponent(i).then(function () {
                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                expect(inventoryPage.getTagsOnInventory()).toContain(postgreSqlSingleObject.mcmpTag);
                                expect(inventoryPage.getTagsOnInventory()).toContain(postgreSqlSingleObject.bluePrintName);
                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                inventoryPage.closeViewComponent();
                                browser.sleep(10000);
                                i++;
                                return callback();
                            });
                        })
                    }, function (error) {
                        if (error) {
                            logger.info('Unable to Get SOI component')
                        }
                    })
                })
            }
            // check Non-Editable service Message
            inventoryPage.clickNonEditableInstance();
            expect(inventoryPage.getTextForInvalidEditModal()).toEqual(PostgreSQLSingleTemplate.nonEditableText);
            inventoryPage.clickOnInvalidEditOkModal();
        });
    }
});
