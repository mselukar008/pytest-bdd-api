"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	OrderHistoryPage = require('../../../../../pageObjects/ordersHistory.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	icdsRhel7x = require('../../../../../../testData/OrderIntegration/ServiceNOW/ICDSRhel7x.json'),
	icdsRhel7xShoppingCartSupport = require('../../../../../../testData/OrderIntegration/ServiceNOW/ICDSRhel7xShoppingCartSupport.json'),
	icdsWinR2V2 = require('../../../../../../testData/OrderIntegration/ServiceNOW/ICDSWindows2012R2V2.json'),
	shoppingCartTemplate   = require('../../../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('ICDS Hetero Cart- All services', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, provOrder, cartListPage, orderHistoryPage, groupName, policyPage, inventoryPage;
	var modifiedParamMap1 = {};
	var modifiedParamMap2 = {};
	var orderObject = {};
	var serviceName1 = "SNOWauto"+util.getRandomString(5);
	var serviceName2 = "SNOWauto"+util.getRandomString(5);
	var cartName = "SNOWautoCart" + util.getRandomString(5);
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var policyName = "SNOWQSAutoExtICDSPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWQSAutoExtICDSPolicyRule"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var icdsWinR2V2Obj = JSON.parse(JSON.stringify(icdsWinR2V2));
	//var icdsRhel71Obj = JSON.parse(JSON.stringify(icdsRhel71));
	var icdsRhel7xObj = JSON.parse(JSON.stringify(icdsRhel7x));

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		orderHistoryPage = new OrderHistoryPage();
		policyPage = new PolicyPage();
		inventoryPage = new InventoryPage();
		browser.driver.manage().window().maximize();
		
		//Delete policy if exists
		policyPage.open();
		util.waitForAngular();
		policyPage.deletePoliciesIfExist();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"TestSnowTeam (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["VRA"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
		"Financial":"External Approval", "Legal":""};
		groupName = "att-group-" + util.getRandomString(5);
		modifiedParamMap1 = {"Service Instance Name":serviceName1, "Cart Name":cartName, "Cart Service":"checkbox-useShoppingCart", "New Shopping Cart":"newCart", "Team":"TestSnowTeam", "Environment":"QA", "Application":"","vSphere_Machine_1 disks":"", "Capacity":"", "Label":""};
		modifiedParamMap2 = {"Service Instance Name":serviceName2, "Cart Name":"", "Cart Service":"", "New Shopping Cart":"", "Team":"", "Environment":"", "Application":"","Provider Account" : "VRA_ICDS_7.3 / VRA_ICDS_7.3"};
	});
	
	afterAll(function() {
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);
		  
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});
	
	it('Create Approval Policy for ICDS with Auto Technical and External Financial approval', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
		policyPage.selectExternalApprovalDropdownSNOW();
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
		  expect(policyNameInPolicyTable).toEqual(policyName);
	});	

	if(isProvisioningRequired == "true") {	
		it('Place an order for ICDS Hetero Cart- All services', function () {
			
			//Add Windows Server 2012 R2 v2 to cart
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsWinR2V2.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsWinR2V2.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsWinR2V2.bluePrintName);
			orderObject.servicename = serviceName1;
			orderFlowUtil.fillOrderDetails(icdsWinR2V2, modifiedParamMap1);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
			catalogPage.open();
	        
	        //Add RHEL7.x to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsRhel7xShoppingCartSupport.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsRhel7xShoppingCartSupport.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsRhel7xShoppingCartSupport.bluePrintName);
			orderObject.servicename = serviceName2;
			orderFlowUtil.fillOrderDetails(icdsRhel7xShoppingCartSupport, modifiedParamMap2);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
			
			//Submit Order
			cartListPage.submitOrder(0);
	    	orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
	    	orderObject.submittedBy = cartListPage.getTextSubmittedByOrderSubmittedModal
	        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(shoppingCartTemplate.orderSubmittedConfirmationMessage);
	    	provOrder = cartListPage.getTextOrderNumberOrderSubmittedModal();
	        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
	        orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(cartName);
			expect(snowPage.getCountOfRITMlinks()).toBe(parseInt("2"));
			
			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2V2.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2V2.provInProgressState);
		});
		
		it('Verify the First RITM for Provision functionality', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			
			
			var service = snowPage.getTextReqItemCorrIDQS();
			service.then(function(serviceName) {
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSRITMItemWin);
					expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDescWin);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);

				}
				else
				{
					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSRITMItemLinux);
					expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDescLinux);
					snowPage.clickReqItemVarTabQS();
					expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
					expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
					expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
					expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsRhel7xObj, "Environment"));
				}				
				snowPage.clickReqItemVarTabQS();
				expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Customer")).toBe(jsonUtil.getValue(icdsWinR2V2Obj, "Customer"));
				expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
				expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
				expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Service Collection")).toBe(jsonUtil.getValue(icdsWinR2V2Obj, "Servicecollection"));
				expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsWinR2V2Obj, "Environment"));
				expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Active Directory Domain")).toBe(snowInstanceTemplate.snowQSReqItemVarADDomain);
				expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Number of CPU Cores")).toBe(jsonUtil.getValue(icdsWinR2V2Obj, "CPUs"));
				expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Memory Size (GB)")).toBe(jsonUtil.getValue(icdsWinR2V2Obj, "Memory (MB)"));
				expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Disk 0 (System) Size (GB)")).toBe(snowInstanceTemplate.snowQSReqItemVarDisk0Size);
				expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Disk 0 (System) Name")).toBe(snowInstanceTemplate.snowQSReqItemVarDisk0Name);
			
				//Order Completion in SNOW
				snowPage.clickChangeRequestLinkQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
				snowPage.rightClickOnCMDBCIFormHeader();
				var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
				sysidofChangeRequest.then(function(sysidofChangeRequestValue){
				var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
				setChangeRequesttoImplementState.then(function(statuscode){
				expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
				});
				snowPage.checkIfAllEightChangeTasksClosed();
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(icdsWinR2V2.completedState);
				}
				else if(serviceName.includes(serviceName2))  {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(icdsRhel7x.completedState);
				}
			})
				
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);	
		});
	});
	
		it('Verify the Second RITM for Provision functionality', function () {
		
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			var service = snowPage.getTextReqItemCorrIDQS();
			service.then(function(serviceName) {
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSReqItemWin);
					expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemWin);
				}
				else if(serviceName.includes(serviceName2)) {
					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSRITMItemLinux);
					expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDescLinux);
					snowPage.clickReqItemVarTabQS();
					expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
					expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
					expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
					expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsRhel7xObj, "Environment"));
				}
				
				snowPage.clickReqItemVarTabQS();
				expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Customer")).toBe(jsonUtil.getValue(icdsWinR2V2Obj, "Customer"));
				expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
				expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
				expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Service Collection")).toBe(jsonUtil.getValue(icdsWinR2V2Obj, "Servicecollection"));
				expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsWinR2V2Obj, "Environment"));
				expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Active Directory Domain")).toBe(snowInstanceTemplate.snowQSReqItemVarADDomain);
				expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Number of CPU Cores")).toBe(jsonUtil.getValue(icdsWinR2V2Obj, "CPUs"));
				expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Memory Size (GB)")).toBe(jsonUtil.getValue(icdsWinR2V2Obj, "Memory (MB)"));
				expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Disk 0 (System) Size (GB)")).toBe(snowInstanceTemplate.snowQSReqItemVarDisk0Size);
				expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Disk 0 (System) Name")).toBe(snowInstanceTemplate.snowQSReqItemVarDisk0Name);
			
				//Order Completion in SNOW
				snowPage.clickChangeRequestLinkQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.checkIfAllEightChangeTasksClosed();
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(icdsWinR2V2.completedState);
				}
				else  {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(icdsRhel7x.completedState);
				}
			})
				
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickSecondRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);	
	    });
		
		it('Verify Delete functionality for first service', function () {
			
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName1;
			browser.get(consumeLaunchpadUrl);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			provOrder = inventoryPage.getDeleteOrderNumber();
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsWinR2V2.bluePrintName);
			
			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(icdsWinR2V2.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSRITMItemDeleteWin);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDescDelWin);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsWinR2V2Obj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.rightClickOnCMDBCIFormHeader();
			var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
			sysidofChangeRequest.then(function(sysidofChangeRequestValue){
			var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
			setChangeRequesttoImplementState.then(function(statuscode){
			expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			});
			snowPage.checkIfAllTwelveChangeTasksClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(icdsWinR2V2.completedState);
			
			//Validation on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);			
		 });
		});
		
		it('Verify Delete functionality for second service', function () {
			
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName2;
			browser.get(consumeLaunchpadUrl);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			provOrder = inventoryPage.getDeleteOrderNumber();
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsWinR2V2.bluePrintName);
			
			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(icdsWinR2V2.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSRITMItemDeleteWin);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDescDelWin);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsWinR2V2Obj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.rightClickOnCMDBCIFormHeader();
			var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
			sysidofChangeRequest.then(function(sysidofChangeRequestValue){
			var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
			setChangeRequesttoImplementState.then(function(statuscode){
			expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			});
			snowPage.checkIfAllTwelveChangeTasksClosed();	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(icdsWinR2V2.completedState);
			
			//Validation on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);			
		 });
		});
	 }
});
	
	
	
	