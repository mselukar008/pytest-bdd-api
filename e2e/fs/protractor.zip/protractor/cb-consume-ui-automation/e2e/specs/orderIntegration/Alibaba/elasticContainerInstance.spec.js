/*************************************************
Spec_Name: elasticContainerInstance.spec.js
Description: This spec will cover E2E testing of Eservice order submit,Elastic Container Instance approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".     
*************************************************/

"use strict";
var async = require('async'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    eciTemplate = require('../../../../testData/OrderIntegration/Alibaba/ElasticContainerInstance.json')

describe('Alibaba: Test cases for Elastic Container Instance', function () {
    var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage, homePage;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: 'Alibaba Cloud',
        category: 'Compute'
    };
    var servicename = "Gsl-Auto-ECI" + util.getRandomString(5);
    var Container = '[{"Image": "busybox:latest","Name":"first-container","Tty":"True","Memory": 0,"Cpu":0 },{"Image":"busybox:latest",  "Name":"second-container","Tty":"True","Memory": 0,"Cpu":0}]';

    beforeAll(function () {
        homePage = new HomePage();
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        modifiedParamMap = {
            "Service Instance Name": servicename,
            "Container": Container,
        };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    afterAll(function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    if (isProvisioningRequired == "true") {
        it('Aalibaba: TC-1 Verify that for Elastic Container Instance,if service is created with new VPC,Vswitch,SG and container configirations', function () {
            var orderObject = JSON.parse(JSON.stringify(eciTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            var returnObj = {};
            orderFlowUtil.fillOrderDetails(eciTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, orderObject.OrderStatus);

            //checking order on Inventory Page 
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();

            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
            expect(inventoryPage.getTextBasedOnLabelName(" Zone Id:")).toEqual(jsonUtil.getValue(orderObject, "Zone Id"));
            expect(inventoryPage.getTextBasedOnLabelName(" New VPC Required:")).toEqual(jsonUtil.getValue(orderObject, "New VPC Required"));
            expect(inventoryPage.getTextBasedOnLabelName(" VPC Name:")).toEqual(jsonUtil.getValue(orderObject, "VPC Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Cidr Block VPC:")).toEqual(jsonUtil.getValue(orderObject, "Cidr Block VPC"));
            expect(inventoryPage.getTextBasedOnLabelName(" Vswitch Name:")).toEqual(jsonUtil.getValue(orderObject, "Vswitch Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Cidr Block Vswitch:")).toEqual(jsonUtil.getValue(orderObject, "Cidr Block Vswitch"));
            expect(inventoryPage.getTextBasedOnLabelName(" New Eip Required:")).toEqual(jsonUtil.getValue(orderObject, "New Eip Required"));
            expect(inventoryPage.getTextBasedOnLabelName(" Network Traffic:")).toEqual(jsonUtil.getValue(orderObject, "Network Traffic"));
            expect(inventoryPage.getTextBasedOnLabelName(" Max Bandwidth:")).toEqual(jsonUtil.getValue(orderObject, "Max Bandwidth"));
            expect(inventoryPage.getTextBasedOnLabelName(" New SG Required:")).toEqual(jsonUtil.getValue(orderObject, "New SG Required"));
            expect(inventoryPage.getTextBasedOnLabelName(" Security Grp Name:")).toEqual(jsonUtil.getValue(orderObject, "Security Grp Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Restart Policy:")).toEqual(jsonUtil.getValue(orderObject, "Restart Policy"));
            expect(inventoryPage.getTextBasedOnLabelName(" Container Group Name:")).toEqual(jsonUtil.getValue(orderObject, "Container Group Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Cpu:")).toEqual(jsonUtil.getValue(orderObject, "Cpu"));
            expect(inventoryPage.getTextBasedOnLabelName(" Memory:")).toEqual(jsonUtil.getValue(orderObject, "Memory"));
            expect(inventoryPage.getTextBasedOnLabelName(" Sls Enable:")).toEqual(jsonUtil.getValue(orderObject, "Sls Enable"));
            inventoryPage.closeViewDetailsTab();
        });
    }

    it('Aalibaba: TC-2 verify that for Elastic Container Instance Service all parameters on Main Parameters Page are present.', function () {
        var orderObject = JSON.parse(JSON.stringify(eciTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);

        expect(catalogDetailsPage.getServiceName()).toBe(orderObject.bluePrintName)
        expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true);
        expect(catalogDetailsPage.isPresentLinkToProviderSite()).toBe(true);
        expect(catalogDetailsPage.isPresentFeaturesLabel()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsLabel()).toBe(true);
        expect(catalogDetailsPage.getTextFeaturesLabel()).toBe(orderObject.FeaturesLabel);
        expect(catalogDetailsPage.getTextDetailsLabel()).toBe(orderObject.DetailsLabel);
        expect(catalogDetailsPage.isPresentFeaturesInfo()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsInfo()).toBe(true);

        catalogDetailsPage.clickCatalogFromBreadCrumbNav();
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
        homePage.open();
    });

    it('Aalibaba: TC-3 verify that for Elastic Container Instance Service all parameters on Review Order page matches with input.', function () {
        var orderObject = JSON.parse(JSON.stringify(eciTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderObject.servicename = servicename;
        orderFlowUtil.fillOrderDetails(eciTemplate, modifiedParamMap);

        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(orderObject.servicename);
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);

        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Zone Id:")).toEqual(jsonUtil.getValue(orderObject, "Zone Id"));
        expect(placeOrderPage.getTextBasedOnLabelName(" New VPC Required:")).toEqual(jsonUtil.getValue(orderObject, "New VPC Required"));
        expect(placeOrderPage.getTextBasedOnLabelName(" VPC Name:")).toEqual(jsonUtil.getValue(orderObject, "VPC Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Cidr Block VPC:")).toEqual(jsonUtil.getValue(orderObject, "Cidr Block VPC"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Vswitch Name:")).toEqual(jsonUtil.getValue(orderObject, "Vswitch Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Cidr Block Vswitch:")).toEqual(jsonUtil.getValue(orderObject, "Cidr Block Vswitch"));
        expect(placeOrderPage.getTextBasedOnLabelName(" New Eip Required:")).toEqual(jsonUtil.getValue(orderObject, "New Eip Required"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Network Traffic:")).toEqual(jsonUtil.getValue(orderObject, "Network Traffic"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Max Bandwidth:")).toEqual(jsonUtil.getValue(orderObject, "Max Bandwidth"));
        expect(placeOrderPage.getTextBasedOnLabelName(" New SG Required:")).toEqual(jsonUtil.getValue(orderObject, "New SG Required"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Security Grp Name:")).toEqual(jsonUtil.getValue(orderObject, "Security Grp Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Restart Policy:")).toEqual(jsonUtil.getValue(orderObject, "Restart Policy"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Container Group Name:")).toEqual(jsonUtil.getValue(orderObject, "Container Group Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Cpu:")).toEqual(jsonUtil.getValue(orderObject, "Cpu"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Memory:")).toEqual(jsonUtil.getValue(orderObject, "Memory"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Sls Enable:")).toEqual(jsonUtil.getValue(orderObject, "Sls Enable"));
        homePage.open();
    });

    it('Aalibaba: TC-4 verify that for Elastic Container Instance Service all values on View Order Details page matches with input.', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(eciTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(eciTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();

        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);

        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("Region")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(ordersPage.getTextBasedOnExactLabelName("Zone Id")).toEqual(jsonUtil.getValue(orderObject, "Zone Id"));
        expect(ordersPage.getTextBasedOnExactLabelName("New VPC Required")).toEqual(jsonUtil.getValue(orderObject, "New VPC Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("VPC Name")).toEqual(jsonUtil.getValue(orderObject, "VPC Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Cidr Block VPC")).toEqual(jsonUtil.getValue(orderObject, "Cidr Block VPC"));
        expect(ordersPage.getTextBasedOnExactLabelName("Vswitch Name")).toEqual(jsonUtil.getValue(orderObject, "Vswitch Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Cidr Block Vswitch")).toEqual(jsonUtil.getValue(orderObject, "Cidr Block Vswitch"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Eip Required")).toEqual(jsonUtil.getValue(orderObject, "New Eip Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Network Traffic")).toEqual(jsonUtil.getValue(orderObject, "Network Traffic"));
        expect(ordersPage.getTextBasedOnExactLabelName("Max Bandwidth")).toEqual(jsonUtil.getValue(orderObject, "Max Bandwidth"));
        expect(ordersPage.getTextBasedOnExactLabelName("New SG Required")).toEqual(jsonUtil.getValue(orderObject, "New SG Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Security Grp Name")).toEqual(jsonUtil.getValue(orderObject, "Security Grp Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Restart Policy")).toEqual(jsonUtil.getValue(orderObject, "Restart Policy"));
        expect(ordersPage.getTextBasedOnExactLabelName("Container Group Name")).toEqual(jsonUtil.getValue(orderObject, "Container Group Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Cpu")).toEqual(jsonUtil.getValue(orderObject, "Cpu"));
        expect(ordersPage.getTextBasedOnExactLabelName("Memory")).toEqual(jsonUtil.getValue(orderObject, "Memory"));
        expect(ordersPage.getTextBasedOnExactLabelName("Sls Enable")).toEqual(jsonUtil.getValue(orderObject, "Sls Enable"));

        //Checking Bill Of Material
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(placeOrderPage.getTotalCost()).toBe(orderObject.TotalCost);

        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
        orderFlowUtil.denyOrder(returnObj);
    });
});