/*
Spec_Name: containerRegistry.spec.js 
Description: This spec will cover E2E testing of Container Registry service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    async = require('async'),
    logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    CRTemplate = require('../../../../testData/OrderIntegration/Azure/ContainerRegistry.json');

describe('Azure - Container Registry', function () {
    var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage;
    var modifiedParamMap = {};
    var messageStrings = { providerName: 'Azure', category: 'Storage' };
    var modifiedParamMapedit = {};
    var servicename = "AutoCRsrv" + util.getRandomString(5);
    var rgName = "gslautotc_azureCRRG101" + util.getRandomString(5);
    var crName = "autocr" + util.getRandomString(5);
    var SOIComponents;
    modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Registry Name": crName };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        catalogDetailsPage = new CatalogDetailsPage()
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        rgName = "gslautotc_azureCRRG101" + util.getRandomString(5);
        crName = "autocr" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Registry Name": crName };
        SOIComponents = [crName]
    });

    afterAll(function () {
        //Delete  Container Registry.
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    //E2E Container Registry order Submit, Approve, Delete Service with New Resource Group.
    if (isProvisioningRequired == "true") {
        it('Azure: TC-T366885 Verify if create new Container Registry with New Resource Group, SKU basic and Admin User enabled working fine.', function () {
            var orderObject = JSON.parse(JSON.stringify(CRTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.searchForBluePrint(orderObject.bluePrintName);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            var returnObj = {};
            var returnObj1 = {};
            orderFlowUtil.fillOrderDetails(CRTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
            inventoryPage.clickViewService();
            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
            expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
            expect(inventoryPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
            expect(inventoryPage.getTextBasedOnLabelName(" Registry Name:")).toEqual(crName);
            expect(inventoryPage.getTextBasedOnLabelName(" Registry Location:")).toEqual(jsonUtil.getValue(orderObject, "Registry Location"));
            expect(inventoryPage.getTextBasedOnLabelName(" Admin User:")).toEqual(jsonUtil.getValue(orderObject, "Admin User"));
            expect(inventoryPage.getTextBasedOnLabelName(" SKU:")).toEqual(jsonUtil.getValue(orderObject, "SKU"));
            inventoryPage.closeViewDetailsTab();
            //Checking SOI Components
            if (isDummyAdapterDisabled == "true") {
                inventoryPage.clickExpandFirstRow().then(function () {
                    browser.executeScript('window.scrollTo(0,0);');
                    var i = 1;
                    async.forEachSeries(SOIComponents, function (component, callback) {
                        util.waitForAngular();
                        inventoryPage.clickOverMenuIcon(i).then(function () {
                            inventoryPage.clickOnViewComponent(i).then(function () {
                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.mcmpTag);
                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.bluePrintName);
                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                inventoryPage.closeViewComponent();
                                browser.sleep(10000);
                                i++;
                                return callback();
                            });
                        })
                    }, function (error) {
                        if (error) {
                            logger.info('Unable to Get SOI component')
                        }
                    })
                })
            }
            element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
            inventoryPage.clickEditServiceIcon();
            browser.sleep(10000);
            modifiedParamMapedit = { "Service Instance Name": servicename, "EditService": true };
            orderFlowUtil.fillOrderDetails(CRTemplate, modifiedParamMapedit);
            placeOrderPage.submitOrder();
            returnObj1.servicename = servicename;
            returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            //Get details on pop up after submit
            var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            var orderprice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            //Open Order page and Approve Order 
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj1);
            orderFlowUtil.waitForOrderStatusChange(returnObj1, "Completed", 50);
        });
    }

    //Checking parameters on Main Parameters page
    it('Azure: TC-T366874 verify that for Container Registry Service all parameters on Main Parameters Page are present.', function () {
        var orderObject = JSON.parse(JSON.stringify(CRTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.searchForBluePrint(orderObject.bluePrintName);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        if (browser.params.defaultCurrency == "USD") {
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
        }
    });

    //Checking values all parameters on Review Order Page and View Order Details
    it('Azure: TC-T366876 verify that for Container Registry Service all values on Review Order Details and View Order Details page matches with input.', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(CRTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.searchForBluePrint(orderObject.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(CRTemplate, modifiedParamMap);
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
        if (browser.params.defaultCurrency == "USD") {
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
        }
        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
        expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Registry Name:")).toEqual(crName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Registry Location:")).toEqual(jsonUtil.getValue(orderObject, "Registry Location"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Admin User:")).toEqual(jsonUtil.getValue(orderObject, "Admin User"));
        expect(placeOrderPage.getTextBasedOnLabelName(" SKU:")).toEqual(jsonUtil.getValue(orderObject, "SKU"));
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
        //Checking Service Configuration Parameters
        expect(ordersPage.getTextBasedOnLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
        expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
        expect(ordersPage.getTextBasedOnLabelName("Registry Name")).toEqual(crName);
        expect(ordersPage.getTextBasedOnLabelName("Registry Location")).toEqual(jsonUtil.getValue(orderObject, "Registry Location"));
        expect(ordersPage.getTextBasedOnLabelName("Admin User")).toEqual(jsonUtil.getValue(orderObject, "Admin User"));
        expect(ordersPage.getTextBasedOnLabelName("SKU")).toEqual(jsonUtil.getValue(orderObject, "SKU"));
        //Checking Bill Of Material
        if (browser.params.defaultCurrency == "USD") {
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
        }
        ordersPage.clickServiceDetailSliderCloseButton();
    });
});