/*************************************************************
    AUTHOR: Atiksha
    This Spec Covers 3 Scenarios of policy rules with 
    multiple and same providers having 2 services in the cart
 *************************************************************/

"use strict";

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    PolicyPage = require('../../../pageObjects/policy.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    policyTemplate = require('../../../../testData/OrderIntegration/policy/policy.json'),
    addRulePolicyTemplate = require('../../../../testData/OrderIntegration/policy/addRulePolicy.json'),
    slShopBagTemplate = require('../../../../testData/OrderIntegration/Softlayer/SoftlayerShoppingCart.json'),
    azshopBagTemplate = require('../../../../testData/OrderIntegration/Azure/AzShoppingCart.json');

describe('Tests for policy tab - ', function () {
    var  catalogPage, placeOrderPage, policyPage, policyName, policyRule,  cartListPage,serviceName1, serviceName2, cartName, rgName1, rgName2, avName, secGrpName,modifiedParamMap,modifiedParamMap1, policyName1, policyRule1, policyName2, policyRule2;
    var modifiedParamMapAddPolicy = {};
    var modifiedParamMapAddRule = {};
    var messageStrings = {

        updatePolicySuccessMsg: policyTemplate.updatePolicySuccessMsg,
        deletePolicySuccessMsg: policyTemplate.deletePolicySuccessMsg,
        retiredPolicyStatus: policyTemplate.retiredPolicyStatus,
        activePolicyStatus: policyTemplate.activePolicyStatus,
        rejectedStatus: slShopBagTemplate.Rejected,
        completedStatus: slShopBagTemplate.Completed,
        providerName: 'Azure', category: 'Other services',
        orderSubmittedConfirmationMessage:'Order Submitted'
     
       
    };
    serviceName1 = "AzAVshopBagnewServ" + util.getRandomString(5);
    serviceName2 = "AzDnshopBagnewServ" + util.getRandomString(5);
    cartName = "AAzshopBagCart" + util.getRandomString(5);
    rgName1 = "gslauto_tcAVshopBagnewRG" + util.getRandomString(5);
    rgName2 = "gslauto_tcDnshopBagnewRG" + util.getRandomString(5);
    avName = "shopbagnewav" + util.getRandomNumber(5);
    secGrpName = "shopbag.newdz" + util.getRandomNumber(5);
    modifiedParamMap = { "Service Instance Name": serviceName1, "Team":"policyTEAM1","Environment": "policyEnv", "Application": "policyApp", "Cart Name": cartName, "Cart Service": "Add service to new cart","New Resource Group": rgName1, "Availability Set Name": avName, "Provider Account": ""};
    modifiedParamMap1 = { "Service Instance Name": serviceName2, "Security Group Name": secGrpName, "New Resource Group": rgName2, "Provider Account": "" };

    beforeAll(function () {
       
        policyPage = new PolicyPage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        cartListPage = new CartListPage();
        browser.driver.manage().window().maximize();
        serviceName = "policyauto" + util.getRandomString(5);
        policyName1 = "policy1" + util.getRandomString(4);
        policyRule1 = "rulePolicy1" + util.getRandomString(4);
        policyName = "policy" + util.getRandomString(4);
        policyRule = "rulePolicy" + util.getRandomString(4);
        policyName2 = "policy2" + util.getRandomString(4);
        policyRule2 = "rulePolicy2" + util.getRandomString(4);
        modifiedParamMapAddPolicy = { "policy Name": policyName };
        modifiedParamMapAddRule = { "Add Rule Name": policyRule, "Order Type": "New", "Provider": "Azure" };

    });

    beforeEach(function () {

    });

    /*TC:250205  Shopping cart with different providers but Policy with Rule for specific Provider (Manual Approval for specific provider Rule -> multiple services of different providers)*/
    it('Prerequisite : : Add Policy under Policy Tab :UI Automation (BCM-321) - Shopping cart with different providers but Policy with Rule for specific Provider -> Manual approval', function () {
        modifiedParamMapAddPolicy = { "policy Name": policyName };
        modifiedParamMapAddRule = { "Add Rule Name": policyRule, "Order Type": "New", "Provider": "Azure" ,"Budget Is":""};

        policyPage.open();
        policyPage.clickAddNewPolicyBtn();
        policyPage.selectStartDate();
        policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapAddPolicy);
        policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
        policyPage.clickApplyRulePolicyBtn();
        browser.sleep(2000);
        policyPage.clickCreatePolicyButton();
        browser.sleep(2000);

    });

    it('UI Automation (BCM-321) - Shopping cart with different providers but Policy with Rule for specific Provider -> Manual approval', function () {
        catalogPage.open();
        var orderObject = {};
        var orderObj = {};
       
        var avshopObj = JSON.parse(JSON.stringify(azshopBagTemplate.avServ));
        catalogPage.searchForBluePrint(avshopObj.bluePrintName)
        catalogPage.clickConfigureButtonBasedOnName(avshopObj.bluePrintName);
        orderObj.servicename = serviceName1;
        policyPage.fillPolicyDetails(avshopObj, modifiedParamMap);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);


        //Adding Another Service to same cart from Different Approval.
        cartListPage.continueShopping();

        var dnsshopObj = JSON.parse(JSON.stringify(slShopBagTemplate.secgrppolicy));
        // catalogPage.clickFirstCategoryCheckBoxBasedOnName(dnsshopObj.Category);
        catalogPage.searchForBluePrint(dnsshopObj.bluePrintName)
         catalogPage.clickConfigureButtonBasedOnName(dnsshopObj.bluePrintName);
        orderObject.servicename = serviceName2;
        policyPage.fillPolicyDetails(dnsshopObj, modifiedParamMap1);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);

        //Submitting Order
        cartListPage.submitOrder();
        orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.totalPrice = cartListPage.getTextTotalPriceOrderSubmittedModal();
        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        if (isProvisioningRequired == "true") {

            // check Manual Approval 
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, completedStatus, 90);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(completedStatus);
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == completedStatus) {
                    orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject); //Deleting Service 2
                    orderFlowUtil.approveDeletedOrder(orderObject);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, completedStatus, 35);
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(completedStatus);
                }
            })
            //Deleting Service 2
            orderObj.deleteOrderNumber = orderFlowUtil.deleteService(orderObj);
            orderFlowUtil.approveDeletedOrder(orderObj);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObj, completedStatus, 35);
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObj)).toBe(completedStatus);
        }
    });

    it('Delete the created policy:UI Automation (BCM-321) - Shopping cart with different providers but Policy with Rule for specific Provider -> Manual approval', function () {
        policyPage.open();
        util.waitForAngular();
        policyPage.searchPolicyInPolicyTextbox(policyName);
        policyPage.clickPolicyDetailIcon();
        policyPage.clickPolicyViewDetailButton();
        policyPage.clickRadioButtonRetiredOption();
        policyPage.clickUpdatePolicyBtn();
        expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.updatePolicySuccessMsg + " " + policyName + " successfully");
        var policyStatusInPolicy = policyPage.getTextPolicyStatusInPolicyTable(policyName);
        expect(policyStatusInPolicy).toEqual(messageStrings.retiredPolicyStatus);
        policyPage.searchPolicyInPolicyTextbox(policyName);
        policyPage.clickPolicyDetailIcon();
        policyPage.clickButtonDeletePolicyText();
        policyPage.clickDeleteConfirmationPopUpPolicyBtn();
        util.waitForAngular();
        browser.sleep(2000);
       
    });

    /* TC:250204 Shopping cart with multiple services from different providers (Auto Deny Rule -> multiple services of different providers)*/
    it('Prerequisite : : Add Policy under Policy Tab :(BCM-321): Shopping cart with multiple services from different providers -> Policy with Provider Rule as Empty -> Policy will be applied', function () {
        modifiedParamMapAddPolicy = { "policy Name": policyName1 };
        modifiedParamMapAddRule = { "Add Rule Name": policyRule1, "Order Type": "New", "Provider": "","financial": "Auto Deny","technical": "Auto Deny", "Budget Is":""};
        policyPage.open();
        policyPage.clickAddNewPolicyBtn();
        policyPage.selectStartDate();
        policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapAddPolicy);
        policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
        policyPage.clickApplyRulePolicyBtn();
        browser.sleep(2000);
        policyPage.clickCreatePolicyButton();
        browser.sleep(2000);
    });
     
    it('UI Automation (BCM-321) - (BCM-321): Shopping cart with multiple services from different providers -> Policy with Provider Rule as Empty -> Policy will be applied', function () {
     
        catalogPage.open();
        var orderObject = {};
        var orderObj = {};
        // catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        var avshopObj = JSON.parse(JSON.stringify(azshopBagTemplate.avServ));
        // catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
        catalogPage.searchForBluePrint(avshopObj.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(avshopObj.bluePrintName);
        orderObj.servicename = serviceName1;
        policyPage.fillPolicyDetails(avshopObj, modifiedParamMap);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
    
    
        // // Adding Another Service to same cart from Different Approval.
        cartListPage.continueShopping();
        var dnsshopObj = JSON.parse(JSON.stringify(slShopBagTemplate.secgrppolicy));
        catalogPage.searchForBluePrint(dnsshopObj.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(dnsshopObj.bluePrintName);
        orderObject.servicename = serviceName2;
        policyPage.fillPolicyDetails(dnsshopObj, modifiedParamMap1);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
    
        //Submitting Order
        cartListPage.submitOrder();
        orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.totalPrice = cartListPage.getTextTotalPriceOrderSubmittedModal();
        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
      
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(rejectedStatus);
    });
        
    it('Delete the created policy:(BCM-321): Shopping cart with multiple services from different providers -> Policy with Provider Rule as Empty -> Policy will be applied', function () {
        policyPage.open();
        util.waitForAngular();
        policyPage.searchPolicyInPolicyTextbox(policyName1);
        policyPage.clickPolicyDetailIcon();
        policyPage.clickPolicyViewDetailButton();
        policyPage.clickRadioButtonRetiredOption();
        policyPage.clickUpdatePolicyBtn();
        expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.updatePolicySuccessMsg + " " + policyName + " successfully");
        var policyStatusInPolicy = policyPage.getTextPolicyStatusInPolicyTable(policyName1);
        expect(policyStatusInPolicy).toEqual(messageStrings.retiredPolicyStatus);
        policyPage.searchPolicyInPolicyTextbox(policyName1);
        policyPage.clickPolicyDetailIcon();
        policyPage.clickButtonDeletePolicyText();
        policyPage.clickDeleteConfirmationPopUpPolicyBtn();
        util.waitForAngular();
        browser.sleep(2000);
       
    });

    /* TC:250203 Shopping cart with multiple services of same providers (Auto Approve Rule -> multiple services of same provider)*/

    it('Prerequisite : : Add Policy under Policy Tab :(BCM-321): Shopping cart with multiple services of same providers -> Expect policy will be applied', function () {
        modifiedParamMapAddPolicy = { "policy Name": policyName2 };
        modifiedParamMapAddRule = { "Add Rule Name": policyRule2, "Provider": "Azure","financial": "Auto Approve","technical": "Auto Approve","Budget Is":""};
        policyPage.open();
        policyPage.clickAddNewPolicyBtn();
        policyPage.selectStartDate();
        policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapAddPolicy);
        policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
        policyPage.clickApplyRulePolicyBtn();
        browser.sleep(2000);
        policyPage.clickCreatePolicyButton();
        browser.sleep(2000);
    });
     
    it('UI Automation (BCM-321) - (BCM-321): Shopping cart with multiple services from same providers -> Policy with Provider Rule as Empty -> Policy will be applied', function () {
     
        var orderObject = {};
        var orderObj = {};
        var avshopObj = JSON.parse(JSON.stringify(azshopBagTemplate.avServ));
        catalogPage.open();
        // catalogPage.clickFirstCategoryCheckBoxBasedOnName(avshopObj.Category);
        catalogPage.searchForBluePrint(avshopObj.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(avshopObj.bluePrintName);
        orderObj.servicename = serviceName1;
        policyPage.fillPolicyDetails(avshopObj, modifiedParamMap);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);

        //Adding Another Service to same cart.
        cartListPage.continueShopping();

        var dnsshopObj = JSON.parse(JSON.stringify(azshopBagTemplate.dnsServ));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(dnsshopObj.Category);
        catalogPage.searchForBluePrint(dnsshopObj.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(dnsshopObj.bluePrintName);
        orderObject.servicename = serviceName2;
        policyPage.fillPolicyDetails(dnsshopObj, modifiedParamMap1);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);

        //Submitting Order
        cartListPage.submitOrder();
        orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.totalPrice = cartListPage.getTextTotalPriceOrderSubmittedModal();
        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        if (isProvisioningRequired == "true") {
            orderFlowUtil.waitForOrderStatusChange(orderObject, completedStatus, 30);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(completedStatus);
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == completedStatus) {
                    orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject); //Deleting Service 2
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, completedStatus, 35);
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(completedStatus);
                }
            })
            //Deleting Service 2
            orderObj.deleteOrderNumber = orderFlowUtil.deleteService(orderObj);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObj, completedStatus , 35);
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObj)).toBe(completedStatus);
        }
    });
        
    it('Delete the created policy:(BCM-321): Shopping cart with multiple services from Same providers -> Policy with Provider Rule as Empty -> Policy will be applied', function () {
        policyPage.open();
        util.waitForAngular();
        policyPage.searchPolicyInPolicyTextbox(policyName2);
        policyPage.clickPolicyDetailIcon();
        policyPage.clickPolicyViewDetailButton();
        policyPage.clickRadioButtonRetiredOption();
        policyPage.clickUpdatePolicyBtn();
        expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.updatePolicySuccessMsg + " " + policyName2 + " successfully");
        var policyStatusInPolicy = policyPage.getTextPolicyStatusInPolicyTable(policyName2);
        expect(policyStatusInPolicy).toEqual(messageStrings.retiredPolicyStatus);
        policyPage.searchPolicyInPolicyTextbox(policyName2);
        policyPage.clickPolicyDetailIcon();
        policyPage.clickButtonDeletePolicyText();
        policyPage.clickDeleteConfirmationPopUpPolicyBtn();
        util.waitForAngular();
        browser.sleep(2000);
       
    });

});