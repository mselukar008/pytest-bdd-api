/*************************************************
	AUTHOR: Nikitha
 **************************************************/

"use strict"
var OperationsPolicy = require('../../../pageObjects/operationsPolicy.pageObject.js'),
    PolicyPage = require('../../../pageObjects/policy.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    operationGroupTemplate = require('../../../../testData/OrderIntegration/policy/operationGroup.json'),
    operationPolicyTemplate = require('../../../../testData/OrderIntegration/policy/operationPolicy.json')
    
describe("Test the Operation Policy ", function () {
    var operationPolicyName,operationGroupName, modifiedParamMap, editedOperationGroupName, approvalPolicyPage, operationPolicyPage;
    var modifiedParamMap = {};
    var modifiedParamMapEdit = {};
    var modifiedParamOperationMap = {};
    var messageStrings = {
    		 
    		operationPolicyCreatedMsg:            operationPolicyTemplate.operationPolicyCreatedMsg, 
    		operationPolicyDeleteMsg:             operationPolicyTemplate.operationPolicyDeleteMsg,
    		operationPolicyUpdateSuccessfulMsg:   operationPolicyTemplate.operationPolicyUpdateSuccessfulMsg,
    		activePolicyStatus:                   operationPolicyTemplate.activePolicyStatus,
    		deletePolicySuccessMsg:               operationPolicyTemplate.deletePolicySuccessMsg,
    		retiredPolicyStatus:                  operationPolicyTemplate.retiredPolicyStatus
      	};
   
    beforeAll(function () {
        operationPolicyPage = new OperationsPolicy();
        approvalPolicyPage = new PolicyPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        operationPolicyName = "autoOperationPolicy" + util.getRandomString(5);
        operationGroupName = "autoGroupPolicyForTagging"+ util.getRandomString(5);;
        modifiedParamOperationMap = { "policy Name": operationPolicyName,"Operation Group":[operationGroupName] };
        modifiedParamMap = { "Name": operationGroupName };
        modifiedParamMapEdit = { "Status": "Retired" };
    });

    it("Create, Edit and Delete the operation Policy", function () {
        operationPolicyPage.open();
        
        //creating active operation group before creating the operation policy
        operationPolicyPage.openOperationGroup();
        operationPolicyPage.clickNewOperationGroupButton();
        approvalPolicyPage.fillPolicyDetails(operationGroupTemplate, modifiedParamMap);
        operationPolicyPage.clickOnAddOperationGroupButton();
        expect(operationPolicyPage.verifyTheToastMsgOfOperationGroupPopUP()).toBe(operationGroupTemplate.operationGrpCreatedMsg);
        operationPolicyPage.clickCloseBtnOfNotificationPopUp();
        
        //Creating the operation policy and tagging above created operation group to it.
        operationPolicyPage.clickOperationPolicyTab();
        operationPolicyPage.clickAddOperationPolicyButton(); 
        approvalPolicyPage.fillPolicyDetails(operationPolicyTemplate,modifiedParamOperationMap);
        approvalPolicyPage.clickCreatePolicyButton();
        expect(operationPolicyPage.verifyTheToastMsgOfOperationGroupPopUP()).toBe(messageStrings.operationPolicyCreatedMsg);
        //operationPolicyPage.clickCloseBtnOfNotificationPopUp();
        
        //Validating the operation policy table once the operation policy is successfully created
        var policyNameInPolicyTable=approvalPolicyPage.getTextPolicyNameInPolicyTable(operationPolicyName);
		expect(policyNameInPolicyTable).toEqual(operationPolicyName);
		var operationPolicyStatusInOperPolicyTable=operationPolicyPage.getTextOperationPolicyStatusInOperationPolicyTable(operationPolicyName);
		expect(operationPolicyStatusInOperPolicyTable).toEqual(messageStrings.activePolicyStatus);
	
        //Updating the policy to Retired.
        operationPolicyPage.searchOperationGroup(operationPolicyName);
        approvalPolicyPage.clickPolicyDetailIcon();
        approvalPolicyPage.clickPolicyViewDetailText();
        util.waitForAngular();
        operationPolicyPage.clickOperationPolicyRetiredOption();
        operationPolicyPage.clickOnUpdateButtonOfOperationGroup();
        //expect(operationPolicyPage.verifyTheToastMsgOfOperationGroupPopUP()).toBe(messageStrings.operationPolicyUpdateSuccessfulMsg);
        //approvalPolicyPage.clickNotificationCloseButton();
        
        //Validating the status change to Retired in the operation policy table.
        var operationPolicyStatusInOperPolicyTable=operationPolicyPage.getTextOperationPolicyStatusInOperationPolicyTable(operationPolicyName);
		expect(operationPolicyStatusInOperPolicyTable).toEqual(messageStrings.retiredPolicyStatus);
		
		//Deleting the operation policy
		approvalPolicyPage.searchPolicyInPolicyTextbox(operationPolicyName);
		approvalPolicyPage.clickPolicyDetailIcon();
		approvalPolicyPage.clickButtonDeletePolicyText();
		operationPolicyPage.clickDeleteConfirmationPopUpApprovalPolicyBtn();
		//util.waitForAngular();
		expect(approvalPolicyPage.getTextSuccessfulToastPolicyNotification()).toEqual(operationPolicyName+" "+messageStrings.deletePolicySuccessMsg);
	    	//expect(approvalPolicyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.operationPolicyUpdateSuccessfulMsg);
		//approvalPolicyPage.clickNotificationCloseButton();
				
    });
    
});
    
       
        
        
        
        
            
        
