"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    Inventory = require('../../../pageObjects/inventory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    testEnvironment = browser.params.url.includes("cb-qa-2") ? "QA 2" : browser.params.url.includes("customer1") ? "Customer 1" : "QA 4",
    classicELBInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSClassicELBInstance.json');

describe('AWS - classicELB', function () {
    var ordersPage, homePage, catalogPage, placeOrderPage, inventoryPage, inventoryPage, serviceName, lbName, ClassicELBObject;

    var modifiedParamMap = {};
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Network',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        isDummyTagValue: 'Yes',
        systemTagText: "ibm_mcmp_soiid"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new Inventory();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(classicELBInstanceTemplate.bluePrintName);
        ClassicELBObject = JSON.parse(JSON.stringify(classicELBInstanceTemplate));
        serviceName = "auto-aws-clasicelb-" + util.getRandomString(5);
        lbName = "LBName" + util.getRandomString(5)
        modifiedParamMap = { "Service Instance Name": serviceName, "Load Balancer Name": lbName };
    });

    it('TC-C175375 : AWS classicELB - Verify fields on Main Parameters page is working fine', function () {

        expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
        //expect(placeOrderPage.getTextBluePrintName()).toContain(classicELBInstanceTemplate.descriptiveText);
        placeOrderPage.setServiceNameText("TestAutomation" + util.getRandomString(4));
        placeOrderPage.selectProviderAccount(ClassicELBObject["Order Parameters"]["Main Parameters"]["Provider Account"]["value"]["QA 1"]);
        expect(placeOrderPage.isNextButtonEnabled()).toBe(true);

    });

    it('TC-C175376 : AWS classicELB-  Verify Summary details and Additional Details are listed in review Order page', function () {

        orderFlowUtil.fillOrderDetails(classicELBInstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            //expect(requiredReturnMap["Actual"]["Service Instance Name"]).toEqual(requiredReturnMap["Expected"]["Service Instance Name"]);
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(classicELBInstanceTemplate.TotalCost);
                //BOM Validation as per components of service.
                expect(placeOrderPage.validateBOMOnReviewOrderPage(classicELBInstanceTemplate.Pricing)).toBe(true);
            }
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Load Balancer Name"]).toEqual(requiredReturnMap["Expected"]["Load Balancer Name"]);
            expect(requiredReturnMap["Actual"]["Scheme"]).toEqual(requiredReturnMap["Expected"]["Scheme"]);
            expect(requiredReturnMap["Actual"]["Load Balancer Protocol 1"]).toEqual(requiredReturnMap["Expected"]["Load Balancer Protocol 1"]);
            expect(requiredReturnMap["Actual"]["Load Balancer Port 1"]).toEqual(requiredReturnMap["Expected"]["Load Balancer Port 1"]);
            expect(requiredReturnMap["Actual"]["Instance Protocol 1"]).toEqual(requiredReturnMap["Expected"]["Instance Protocol 1"]);
            expect(requiredReturnMap["Actual"]["Instance Port 1"]).toEqual(requiredReturnMap["Expected"]["Instance Port 1"]);
            expect(requiredReturnMap["Actual"]["Policy Name 1"]).toEqual(requiredReturnMap["Expected"]["Policy Name 1"]);
            expect(requiredReturnMap["Actual"]["VPC"]).toEqual(requiredReturnMap["Expected"]["VPC"]);
            expect(requiredReturnMap["Actual"]["Availability Zone"]).toEqual(requiredReturnMap["Expected"]["Availability Zone"]);
            //expect(requiredReturnMap["Actual"]["Subnet"]).toEqual(requiredReturnMap["Expected"]["Subnet"]);
            expect(requiredReturnMap["Actual"]["Security Groups"]).toEqual(requiredReturnMap["Expected"]["Securities Groups"]);
            expect(requiredReturnMap["Actual"]["Select Policy Type"]).toEqual(requiredReturnMap["Expected"]["Select Policy Type"]);
            expect(requiredReturnMap["Actual"]["LB Cookie Stickiness Policy Name"]).toEqual(requiredReturnMap["Expected"]["LB Cookie Stickiness Policy Name"]);
            expect(requiredReturnMap["Actual"]["Cookie Expiration Period"]).toEqual(requiredReturnMap["Expected"]["Cookie Expiration Period"]);
            expect(requiredReturnMap["Actual"]["Enable Logging"]).toEqual(requiredReturnMap["Expected"]["Enable Logging"]);
            expect(requiredReturnMap["Actual"]["Ping Protocol"]).toEqual(requiredReturnMap["Expected"]["Ping Protocol"]);
            expect(requiredReturnMap["Actual"]["Ping Port"]).toEqual(requiredReturnMap["Expected"]["Ping Port"]);
            expect(requiredReturnMap["Actual"]["Ping Path"]).toEqual(requiredReturnMap["Expected"]["Ping Path"]);
            expect(requiredReturnMap["Actual"]["Response Timeout"]).toEqual(requiredReturnMap["Expected"]["Response Timeout"]);
            expect(requiredReturnMap["Actual"]["Interval"]).toEqual(requiredReturnMap["Expected"]["Interval"]);
            expect(requiredReturnMap["Actual"]["Healthy Threshold"]).toEqual(requiredReturnMap["Expected"]["Healthy Threshold"]);
            expect(requiredReturnMap["Actual"]["Unhealthy Threshold"]).toEqual(requiredReturnMap["Expected"]["Unhealthy Threshold"]);
            expect(requiredReturnMap["Actual"]["Instance Id"]).toEqual(requiredReturnMap["Expected"]["Instance Id"]);
            expect(requiredReturnMap["Actual"]["Cross Zone"]).toEqual(requiredReturnMap["Expected"]["Cross Zone"]);
            expect(requiredReturnMap["Actual"]["Connection Draining Policy Enabled"]).toEqual(requiredReturnMap["Expected"]["Connection Draining Policy Enabled"]);
            expect(requiredReturnMap["Actual"]["Idle Timeout"]).toEqual(requiredReturnMap["Expected"]["Idle Timeout"]);

        });
    });

    it('TC-C175377 : AWS classicELB - Verify Order is listed in Orders details page once it is submitted from catalog page', function () {
        var orderObject = {};

        orderFlowUtil.fillOrderDetails(classicELBInstanceTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        expect(util.getCurrentURL()).toMatch('orders');
        ordersPage.searchOrderById(orderObject.orderNumber);
        expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //orderFlowUtil.waitForOrderStatusChange(orderObject, 'Approval In Progress');
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
        expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
        expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
        expect(ordersPage.isDisplayedDenyButtonOrderDetails()).toEqual(true);
        util.waitForAngular();
        expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(ClassicELBObject, "AWS Region"));
        expect(ordersPage.getTextBasedOnLabelName("Load Balancer Name")).toEqual(lbName);
        expect(ordersPage.getTextBasedOnLabelName("Load Balancer Protocol")).toEqual(jsonUtil.getValue(ClassicELBObject, "Load Balancer Protocol"));
        expect(ordersPage.getTextBasedOnLabelName("Load Balancer Port")).toEqual(jsonUtil.getValue(ClassicELBObject, "Load Balancer Port"));
        expect(ordersPage.getTextBasedOnLabelName("Instance Protocol")).toEqual(jsonUtil.getValue(ClassicELBObject, "Instance Protocol"));
        expect(ordersPage.getTextBasedOnLabelName("Instance Port")).toEqual(jsonUtil.getValue(ClassicELBObject, "Instance Port"));
        //expect(ordersPage.getTextBasedOnLabelName("Policy Name")).toEqual(jsonUtil.getValue(ClassicELBObject, "Policy Name"));
        expect(ordersPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(ClassicELBObject, "VPC"));
        expect(ordersPage.getTextBasedOnLabelName("Availability Zone")).toEqual("us-east-1a,us-east-1b");
        expect(ordersPage.getTextBasedOnLabelName("Subnet")).toEqual("subnet-c5f664b2 | us-east-1b,subnet-a68b538d | us-east-1a");
        expect(ordersPage.getTextBasedOnLabelName("Security Groups")).toEqual("sg-4e88232a | default");
        expect(ordersPage.getTextBasedOnLabelName("Select Policy Type")).toEqual(jsonUtil.getValue(ClassicELBObject, "Select Policy Type"));
        //expect(ordersPage.getTextBasedOnLabelName("LB Cookie Stickiness Policy Name")).toEqual(jsonUtil.getValue(ClassicELBObject, "LB Cookie Stickiness Policy Name"));
        expect(ordersPage.getTextBasedOnLabelName("Cookie Expiration Period")).toEqual(jsonUtil.getValue(ClassicELBObject, "Cookie Expiration Period"));
        expect(ordersPage.getTextBasedOnLabelName("Enable Logging")).toEqual(jsonUtil.getValue(ClassicELBObject, "Enable Logging"));
        expect(ordersPage.getTextBasedOnLabelName("Ping Protocol")).toEqual(jsonUtil.getValue(ClassicELBObject, "Ping Protocol"));
        expect(ordersPage.getTextBasedOnLabelName("Ping Port")).toEqual(jsonUtil.getValue(ClassicELBObject, "Ping Port"));
        expect(ordersPage.getTextBasedOnLabelName("Ping Path")).toEqual(jsonUtil.getValue(ClassicELBObject, "Ping Path"));
        expect(ordersPage.getTextBasedOnLabelName("Response Timeout")).toEqual(jsonUtil.getValue(ClassicELBObject, "Response Timeout"));
        expect(ordersPage.getTextBasedOnLabelName("Interval")).toEqual(jsonUtil.getValue(ClassicELBObject, "Interval"));
        expect(ordersPage.getTextBasedOnLabelName("Healthy Threshold")).toEqual(jsonUtil.getValue(ClassicELBObject, "Healthy Threshold"));
        expect(ordersPage.getTextBasedOnLabelName("Unhealthy Threshold")).toEqual(jsonUtil.getValue(ClassicELBObject, "Unhealthy Threshold"));
        expect(ordersPage.getTextBasedOnLabelName("Instance Id")).toEqual(jsonUtil.getValue(ClassicELBObject, "Instance Id"));
        expect(ordersPage.getTextBasedOnLabelName("Cross Zone")).toEqual(jsonUtil.getValue(ClassicELBObject, "Cross Zone"));
        expect(ordersPage.getTextBasedOnLabelName("Connection Draining Policy Enabled")).toEqual(jsonUtil.getValue(ClassicELBObject, "Connection Draining Policy Enabled"));
        expect(ordersPage.getTextBasedOnLabelName("Idle Timeout")).toEqual(jsonUtil.getValue(ClassicELBObject, "Idle Timeout"));
        if (browser.params.defaultCurrency == "USD") {
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(classicELBInstanceTemplate.TotalCost);
        }
        ordersPage.clickServiceDetailSliderCloseButton();
    });

    if (isProvisioningRequired == "true") {
        it('TC-C175378 : AWS classicELB - E2E : Verify instance Order Provision and Deletion is working fine from consume App', function () {
            var orderObject = {};
            var serviceDetailsMap = {};
            orderObject.servicename = serviceName;

            orderFlowUtil.fillOrderDetails(classicELBInstanceTemplate, modifiedParamMap).then(function (serviceDetailsMapActual) {
                serviceDetailsMap = serviceDetailsMapActual;
            });

            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(classicELBInstanceTemplate.bluePrintName, "New");
            //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == 'Completed') {
                    //Verify Output parameter
                    expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);

                    //Validate service Tags
                    inventoryPage.open();
                    inventoryPage.getImiTags(orderObject).then(function (tags) {
                        var tagList = tags.split(",");
                        var tagMap = inventoryPage.getServiceTags(tagList);
                        var mcmpTag = false;
                        if (isDummyAdapterDisabled == "false") {
                            //verifying flags for dummy adapter
                            expect(tagMap["IsUsingDummy"]).toEqual(messageStrings.isDummyTagValue);
                            expect(tagMap["Name"]).toEqual(classicELBInstanceTemplate.bluePrintName);
                            expect(tagMap["PhysicalId"]).toContain(serviceName);
                            expect(Object.keys(tagMap).includes("Test")).toBe(true);
                            expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                        } else {
                            //verifying a system tag
                            expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                            //verifying some of the service tags
                            expect(tagMap["orderNumber"].toUpperCase()).toEqual(orderObject.orderNumber);
                            expect(tagMap["serviceInstanceName"].toLowerCase()).toContain(serviceName.toLowerCase());
                        }
                        orderFlowUtil.closeHorizontalSliderIfPresent();
                    });

                    //Edit flow
                    var modifiedParamMap = { "EditService": true };
                    orderFlowUtil.editService(orderObject);
                    orderFlowUtil.fillOrderDetails(classicELBInstanceTemplate, modifiedParamMap).then(function (reviewOrderExpActParamsMap) {
                        if (browser.params.defaultCurrency == "USD") {
                            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(classicELBInstanceTemplate.TotalCostPostEdit);
                        }
                        //browser.sleep(5000);
                        //Validate Review order page parameters
                        //expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
                    });
                    placeOrderPage.submitOrder();
                    orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(classicELBInstanceTemplate.bluePrintName, "New");
                    //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                    expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                    placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                    orderFlowUtil.approveOrder(orderObject);
                    orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                    orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                        if (status == 'Completed') {
                            //Verify updated details are reflected on order details page.						
                            ordersPage.clickFirstViewDetailsOrdersTable();
                            expect(ordersPage.getTextBasedOnLabelName("Load Balancer Protocol")).toEqual(jsonUtil.getValueEditParameter(ClassicELBObject, "Load Balancer Protocol"));
                            expect(ordersPage.getTextBasedOnLabelName("Load Balancer Port")).toEqual(jsonUtil.getValueEditParameter(ClassicELBObject, "Load Balancer Port"));
                            expect(ordersPage.getTextBasedOnLabelName("Instance Protocol")).toEqual(jsonUtil.getValueEditParameter(ClassicELBObject, "Instance Protocol"));
                            //expect(ordersPage.getTextBasedOnLabelName("Instance Port")).toEqual(jsonUtil.getValueEditParameter(ClassicELBObject, "Instance Port"));
                            if (browser.params.defaultCurrency == "USD") {
                                ordersPage.clickBillOfMaterialsTabOrderDetails();
                                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(ClassicELBObject.TotalCostPostEdit);
                            }
                            ordersPage.clickServiceDetailSliderCloseButton();
                        }
                        //Delete Service flow               
                       
                        orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, classicELBInstanceTemplate.bluePrintName);
                        orderFlowUtil.approveDeletedOrder(orderObject);
                        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
                    });
                }
            });
        });
    }
});
