//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.
"use strict";

var CatalogPage            = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage         = require('../../../pageObjects/placeOrder.pageObject.js'),
	Orders                 = require('../../../pageObjects/orders.pageObject.js'),
	jsonUtil = require('../../../../helpers/jsonUtil.js'),
	util                   = require('../../../../helpers/util.js'),
	orderFlowUtil          = require('../../../../helpers/orderFlowUtil.js'),
	appUrls                = require('../../../../testData/appUrls.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	vSphereVmTemplate  = require('../../../../testData/OrderIntegration/ICAM/vSphereVirtualMachine.json');
	
    
describe('E2E Test cases for ICAM-ON Vsphere Virtual Machine service', function() {
	var catalogPage, placeOrderPage,ordersPage,serviceName,vmName,VsphereEditsoiObject;
	var modifiedParamMap = {};
    var messageStrings = {
			providerName                      : vSphereVmTemplate.providerName,
			orderSubmittedConfirmationMessage : vSphereVmTemplate.orderSubmittedConfirmationMessage,
			category                          :	vSphereVmTemplate.category,
			estimatedPrice                    : vSphereVmTemplate.estimatedPrice,
            providerAccount                   : vSphereVmTemplate.providerAccount,
			completedState                    : vSphereVmTemplate.completedState,
			approvalState                     : vSphereVmTemplate.approvalState,
			orderTypeDel                      : vSphereVmTemplate.orderTypeDel,
			urlOrders                         : vSphereVmTemplate.urlOrders,
			estimatedCost                     : vSphereVmTemplate.estimatedCost
     };
    
  	beforeAll(function() {
	    ordersPage = new Orders();
    	catalogPage = new CatalogPage();
    	placeOrderPage = new PlaceOrderPage();
        browser.driver.manage().window().maximize();
    });
    
  	beforeEach(function() {
    	catalogPage.open();
    	expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		VsphereEditsoiObject = JSON.parse(JSON.stringify(vSphereVmTemplate));
    	serviceName = vSphereVmTemplate.serviceNamePrefix+"-"+util.getRandomString(5);
    	vmName = vSphereVmTemplate.virtualMachineNamePrefix+"-"+util.getRandomString(5);
		modifiedParamMap = {"Service Instance Name":serviceName,"Virtual machine name":vmName};
    });
  
  	it('TA : Vsphere Virtual Machine ---- Verify fields on Main Parameters page', function(){
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);	
		catalogPage.searchForBluePrint(vSphereVmTemplate.bluePrintName);
		catalogPage.clickConfigureButtonBasedOnName(vSphereVmTemplate.bluePrintName);
    	expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
    	placeOrderPage.setServiceNameTextICAM("icam-automation-vm-" + util.getRandomString(4));
    	placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
    	expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
  	});

 	it('TA : Vsphere Virtual Machine ---- Verify Summary details and Additional Details are listed in review Order page', function() {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.searchForBluePrint(vSphereVmTemplate.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(vSphereVmTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetailsICAM(vSphereVmTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
			//expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPrice);
			expect(requiredReturnMap["Actual"]["Instance Plan"]).toEqual(requiredReturnMap["Expected"]["Instance Plan"]);
            expect(requiredReturnMap["Actual"]["VSphere Cloud Connection"]).toEqual(requiredReturnMap["Expected"]["VSphere Cloud Connection"]);
            expect(requiredReturnMap["Actual"]["Virtual machine name"]).toEqual(requiredReturnMap["Expected"]["Virtual machine name"]);
            expect(requiredReturnMap["Actual"]["Virtual machine image / Template name"]).toEqual(requiredReturnMap["Expected"]["Virtual machine image / Template name"]);
            expect(requiredReturnMap["Actual"]["Virtual machine disk size"]).toEqual(requiredReturnMap["Expected"]["Virtual machine disk size"]);
            expect(requiredReturnMap["Actual"]["Root Disk Datastore"]).toEqual(requiredReturnMap["Expected"]["Root Disk Datastore"]);
            expect(requiredReturnMap["Actual"]["IPV4 Gateway"]).toEqual(requiredReturnMap["Expected"]["IPV4 Gateway"]);
            expect(requiredReturnMap["Actual"]["IPV4 Address"]).toEqual(requiredReturnMap["Expected"]["IPV4 Address"]);
            expect(requiredReturnMap["Actual"]["VM memory size"]).toEqual(requiredReturnMap["Expected"]["VM memory size"]);
            expect(requiredReturnMap["Actual"]["IPV4 prefix lengt"]).toEqual(requiredReturnMap["Expected"]["IPV4 prefix lengt"]);
            expect(requiredReturnMap["Actual"]["V-CPUS"]).toEqual(requiredReturnMap["Expected"]["V-CPUS"]);
            expect(requiredReturnMap["Actual"]["Network interface label"]).toEqual(requiredReturnMap["Expected"]["Network interface label"]);
        });
  	});	

  	it('TA : Vsphere Virtual Machine ---- Verify Order is listed in Orders details page once it is submitted from catalog page',function(){
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.searchForBluePrint(vSphereVmTemplate.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(vSphereVmTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetailsICAM(vSphereVmTemplate, modifiedParamMap).then(function(requiredReturnMap){
        placeOrderPage.submitOrder();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        var orderId = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        expect(util.getCurrentURL()).toMatch(messageStrings.urlOrders);
        ordersPage.searchOrderById(orderId);
        expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderId);
        ordersPage.clickFirstViewDetailsOrdersTable();
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
        expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual(messageStrings.approvalState);
        expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
        expect(ordersPage.isDisplayedDenyButtonOrderDetails()).toEqual(true);
        ordersPage.clickServiceConfigurationsTabOrderDetails();
		expect(ordersPage.getTextBasedOnLabelName("Instance Plan")).toEqual((requiredReturnMap["Expected"]["Instance Plan"]));
		expect(ordersPage.getTextBasedOnLabelName("VSphere Cloud Connection")).toEqual((requiredReturnMap["Expected"]["VSphere Cloud Connection"]));
		expect(ordersPage.getTextBasedOnLabelName("Virtual machine name")).toEqual((requiredReturnMap["Expected"]["Virtual machine name"]));
		expect(ordersPage.getTextBasedOnLabelName("Virtual machine image / Template name")).toEqual((requiredReturnMap["Expected"]["Virtual machine image / Template name"]));
		expect(ordersPage.getTextBasedOnLabelName("Virtual machine disk size")).toEqual((requiredReturnMap["Expected"]["Virtual machine disk size"]));
		expect(ordersPage.getTextBasedOnLabelName("Root Disk Datastore")).toEqual((requiredReturnMap["Expected"]["Root Disk Datastore"]));
		expect(ordersPage.getTextBasedOnLabelName("IPV4 Gateway")).toEqual((requiredReturnMap["Expected"]["IPV4 Gateway"]));
		expect(ordersPage.getTextBasedOnLabelName("IPV4 Address")).toEqual((requiredReturnMap["Expected"]["IPV4 Address"]));
		expect(ordersPage.getTextBasedOnLabelName("VM memory size")).toEqual((requiredReturnMap["Expected"]["VM memory size"]));
		expect(ordersPage.getTextBasedOnLabelName("IPV4 prefix lengt")).toEqual((requiredReturnMap["Expected"]["IPV4 prefix lengt"]));
		expect(ordersPage.getTextBasedOnLabelName("V-CPUS")).toEqual((requiredReturnMap["Expected"]["V-CPUS"]));
		expect(ordersPage.getTextBasedOnLabelName("Network interface label")).toEqual((requiredReturnMap["Expected"]["Network interface label"]));
        ordersPage.clickBillOfMaterialsTabOrderDetails();
      //  expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);
        }); 
	});
	if(isProvisioningRequired == "true") {
		it('TA- Vsphere Virtual Machine --- Verify Provision, Edit SOI and Delete services', function() {
			var orderObject = {} ;
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.searchForBluePrint(vSphereVmTemplate.bluePrintName);
			catalogPage.clickConfigureButtonBasedOnName(vSphereVmTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetailsICAM(vSphereVmTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
		//	orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
			 	//Delete service
			 	if (status == 'Completed') {
				var orderObject = {};
				var orderObject = { servicename: serviceName };
                 //Edit flow
                    var modifiedParamMap = { "EditService": true };
                    orderFlowUtil.editService(orderObject);
                    orderFlowUtil.fillOrderDetails(vSphereVmTemplate, modifiedParamMap).then(function () {
                        browser.sleep(5000);
                    });
					placeOrderPage.submitOrder();
					orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				//	orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
					placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
					orderFlowUtil.approveOrder(orderObject);
					orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
					expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
					orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
						if (status == 'Completed') {
                            //Verify updated details are reflected on order details page.						
                            ordersPage.clickFirstViewDetailsOrdersTable();
							expect(ordersPage.getTextBasedOnLabelName("Virtual machine disk size")).toEqual(jsonUtil.getValueEditParameter(VsphereEditsoiObject, "Virtual machine disk size"));
							expect(ordersPage.getTextBasedOnLabelName("V-CPUS")).toEqual(jsonUtil.getValueEditParameter(VsphereEditsoiObject, "V-CPUS"));
							expect(ordersPage.getTextBasedOnLabelName("Network interface label")).toEqual(jsonUtil.getValueEditParameter(VsphereEditsoiObject, "Network interface label"));
                            ordersPage.clickServiceDetailSliderCloseButton();
                        }
						// Delete Service flow                    
						 orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
						 //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
						 orderFlowUtil.approveDeletedOrder(orderObject);
						 orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
						 expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
					});    
               }
			});
		});
     }
  });
