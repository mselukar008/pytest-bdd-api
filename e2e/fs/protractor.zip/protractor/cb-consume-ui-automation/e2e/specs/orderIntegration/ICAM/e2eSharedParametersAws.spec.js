/*	
Spec_Name:e2eSharedParametersAws.spec copy.js
Description: It covers e2e flow of provisioning of aws service habing shared parameter feature support on mcmp.	
Author: Sarika Bothe

//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.
*/


"use strict";

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	Orders = require('../../../pageObjects/orders.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	vmInAwsTemplate = require('../../../../testData/OrderIntegration/ICAM/awsSharedParametes.json');


describe('TA - E2E Test cases for TA- Shared parameter of AWS service', function () {

	var catalogPage, placeOrderPage, ordersPage, orderHistoryPage, SubnetName, vpc, serviceName, virtualMachineName, awsSshKeyName;
	var modifiedParamMap = {};
	var messageStrings = {
		providerName: vmInAwsTemplate.providerName,
		category: vmInAwsTemplate.category,
		estimatedPrice: vmInAwsTemplate.estimatedPrice,
		providerAccount: vmInAwsTemplate.providerAccount,
		completedState: vmInAwsTemplate.completedState,
		approvalState: vmInAwsTemplate.approvalState,
		orderTypeDel: vmInAwsTemplate.orderTypeDel,
		urlOrders: vmInAwsTemplate.urlOrders,
		estimatedCost: vmInAwsTemplate.estimatedCost,
		cancelOrderSuccessMsg: vmInAwsTemplate.cancelOrderSuccessMsg,
		cancelledStatus: vmInAwsTemplate.cancelledStatus,
		provisiongstatus: vmInAwsTemplate.provisiongstatus,
		Cancelingstatus: vmInAwsTemplate.Cancelingstatus,
		orderSubmittedConfirmationMessage: vmInAwsTemplate.orderSubmittedConfirmationMessage,
		orderFailedStatus: vmInAwsTemplate.failedState
	};

	beforeAll(function () {
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		orderHistoryPage = new OrderHistoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		serviceName = vmInAwsTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
		SubnetName = vmInAwsTemplate.subnetnamePrefix + "-" + util.getRandomString(5);
		vpc = vmInAwsTemplate.vpcPrefix + "-" + util.getRandomString(5);
		virtualMachineName = vmInAwsTemplate.virtualMachineNamePrefix + "-" + util.getRandomString(5);
		awsSshKeyName = vmInAwsTemplate.awsSshKeyNamePrefix + "-" + util.getRandomString(5);
		modifiedParamMap = { "Service Instance Name": serviceName, "Public SSH Key Name": awsSshKeyName, "Virtual Machine name": virtualMachineName }
	});

	it('TA-Virtual machine in AWS ---- Verify fields on Main Parameters page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.searchForBluePrint(vmInAwsTemplate.bluePrintName);
		catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
		expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
		placeOrderPage.setServiceNameTextICAM(vmInAwsTemplate.serviceNamePrefix + "-" + util.getRandomString(4));
		placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
		expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
		//expect(placeOrderPage.getTextEstimatedPrice()).toBe(vmInAwsTemplate.EstimatedPrice);
	});

	it('TA-Virtual machine in AWS Shared parameter ---- Verify Order is listed in Orders details page once it is submitted from catalog page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.searchForBluePrint(vmInAwsTemplate.bluePrintName);
		catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			placeOrderPage.submitOrder();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			var orderId = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			ordersPage.open();
			expect(util.getCurrentURL()).toMatch(messageStrings.urlOrders);
			ordersPage.searchOrderById(orderId);
			expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderId);
			ordersPage.clickFirstViewDetailsOrdersTable();
			expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual(messageStrings.approvalState);
			//expect(ordersPage.getTextSubmittedByOrderDetails()).toContain(catalogPage.extractUserFirstName());
			expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
			expect(ordersPage.isDisplayedDenyButtonOrderDetails()).toEqual(true);
			ordersPage.clickServiceConfigurationsTabOrderDetails();
			expect(requiredReturnMap["Actual"]["Instance Plan"]).toEqual(requiredReturnMap["Expected"]["Instance Plan"]);
			expect(requiredReturnMap["Actual"]["Cloud Connection Name"]).toEqual(requiredReturnMap["Expected"]["Cloud Connection Name"]);			expect(requiredReturnMap["Actual"]["VPC Name tag"]).toEqual(requiredReturnMap["Expected"]["VPC Name tag"]);
			expect(requiredReturnMap["Actual"]["Subnet Name"]).toEqual(requiredReturnMap["Expected"]["Subnet Name"]);
			expect(requiredReturnMap["Actual"]["Public SSH Key Name"]).toEqual(requiredReturnMap["Expected"]["Public SSH Key Name"]);
			expect(requiredReturnMap["Actual"]["Public SSH Key"]).toBeDefined();
			ordersPage.clickBillOfMaterialsTabOrderDetails();
			//	expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);

		});
	});

	if (isProvisioningRequired == "true") {

		it('TA-Virtual machine in AWS Shared parameter --- Verify Provision and Delete services', function () {
			var orderObject = {}
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.searchForBluePrint(vmInAwsTemplate.bluePrintName);
			catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			//orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {

				//Delete service
				if (status == 'Completed') {
					orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
					expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
					orderFlowUtil.approveDeletedOrder(orderObject);
					orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
					expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState);
				}
			});
		});




	}
});
