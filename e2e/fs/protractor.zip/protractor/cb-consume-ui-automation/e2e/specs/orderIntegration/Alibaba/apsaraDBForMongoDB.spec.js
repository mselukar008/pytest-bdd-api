/*************************************************
Spec_Name: apsaraDBforMongoDB.spec.js
Description: This spec will cover E2E testing of ApsaraDB for MongoDB order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".  
**************************************************/

"use strict";
var async = require('async'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    apsaraDBForMongoDBTemplate = require('../../../../testData/OrderIntegration/Alibaba/ApsaraDBForMongoDB.json')

describe('Alibaba: Test cases for ApsaraDB for MongoDB', function () {
    var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage, homePage;
    var modifiedParamMap = {};
    var modifiedParamMapVPC = {};
    var messageStrings = {
        providerName: 'Alibaba Cloud',
        category: 'Databases'
    };
    var servicename = "Gsl-Auto-ApsaraDBForMongoDB" + util.getRandomString(5);
    var servicenameVPC = "Gsl-Auto-VPC" + util.getRandomString(5);
    modifiedParamMapVPC = {
        "Service Instance Name": servicenameVPC,
    };

    beforeAll(function () {
        homePage = new HomePage();
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        modifiedParamMap = {
            "Service Instance Name": servicename,
        };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    afterAll(function () {
        // Delete ApsaraDB for MongoDB
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');

        // Delete Virtual Private Cloud
        var returnObjVPC = {};
        returnObjVPC.servicename = servicenameVPC;
        returnObjVPC.deleteOrderNumber = orderFlowUtil.deleteService(returnObjVPC);
        orderFlowUtil.approveDeletedOrder(returnObjVPC);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObjVPC, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObjVPC)).toBe('Completed');
    });

    //Prerequisite: We need to create Virtual Private Cloud, which will be used by ApsaraDB for MongoDB Service.
    it('Aalibaba: TC-1 Prerequisite for ApsaraDB for MongoDB: Create new Virtual Private Cloud', function () {
        var orderObjectVPC = JSON.parse(JSON.stringify(apsaraDBForMongoDBTemplate.createVirtualPrivateCloud));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObjectVPC.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObjectVPC.bluePrintName);
        var returnObjVPC = {};
        orderFlowUtil.fillOrderDetails(apsaraDBForMongoDBTemplate.createVirtualPrivateCloud, modifiedParamMapVPC);
        placeOrderPage.submitOrder();
        returnObjVPC.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        returnObjVPC.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        returnObjVPC.servicename = servicenameVPC;
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObjectVPC.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(returnObjVPC);
        orderFlowUtil.waitForOrderStatusChange(returnObjVPC, orderObjectVPC.OrderStatus);
    });

    it('Aalibaba: TC-2 verify that for ApsaraDB for MongoDB all parameters on Main Parameters Page are present.', function () {
        var orderObject = JSON.parse(JSON.stringify(apsaraDBForMongoDBTemplate.createApsaraDBforMongoDB));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);

        expect(catalogDetailsPage.getServiceName()).toBe(orderObject.bluePrintName)
        expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true);
        expect(catalogDetailsPage.isPresentLinkToProviderSite()).toBe(true);
        expect(catalogDetailsPage.isPresentFeaturesLabel()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsLabel()).toBe(true);
        expect(catalogDetailsPage.getTextFeaturesLabel()).toBe(orderObject.FeaturesLabel);
        expect(catalogDetailsPage.getTextDetailsLabel()).toBe(orderObject.DetailsLabel);
        expect(catalogDetailsPage.isPresentFeaturesInfo()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsInfo()).toBe(true);

        catalogDetailsPage.clickCatalogFromBreadCrumbNav();
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
        homePage.open();
    });

    it('Aalibaba: TC-3 verify that for ApsaraDB for MongoDB all parameters on Review Order page matches with input.', function () {
        var orderObject = JSON.parse(JSON.stringify(apsaraDBForMongoDBTemplate.createApsaraDBforMongoDB));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderObject.servicename = servicename;
        orderFlowUtil.fillOrderDetails(apsaraDBForMongoDBTemplate.createApsaraDBforMongoDB, modifiedParamMap);

        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(orderObject.servicename);

        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Billing Method:")).toEqual(jsonUtil.getValue(orderObject, "Billing Method"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Database Type:")).toEqual(jsonUtil.getValue(orderObject, "Database Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Zone:")).toEqual(jsonUtil.getValue(orderObject, "Zone"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Database Version:")).toEqual(jsonUtil.getValue(orderObject, "Database Version"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Storage Engine:")).toEqual(jsonUtil.getValue(orderObject, "Storage Engine"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Replication Factor:")).toEqual(jsonUtil.getValue(orderObject, "Replication Factor"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Network Type:")).toEqual(jsonUtil.getValue(orderObject, "Network Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Vpc ID:")).toEqual(jsonUtil.getValue(orderObject, "Vpc ID"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Vswitch ID:")).toEqual(jsonUtil.getValue(orderObject, "Vswitch ID"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Specification:")).toEqual(jsonUtil.getValue(orderObject, "Specification"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Storage Space:")).toEqual(jsonUtil.getValue(orderObject, "Storage Space"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Set Password:")).toEqual(jsonUtil.getValue(orderObject, "Set Password"));
        homePage.open();
    });

    it('Aalibaba: TC-4 verify that for ApsaraDB for MongoDB all values on View Order Details page matches with input.', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(apsaraDBForMongoDBTemplate.createApsaraDBforMongoDB));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(apsaraDBForMongoDBTemplate.createApsaraDBforMongoDB, modifiedParamMap);
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();

        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename); //Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider); //Checking Provider

        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("Region")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(ordersPage.getTextBasedOnExactLabelName("Billing Method")).toEqual(jsonUtil.getValue(orderObject, "Billing Method"));
        expect(ordersPage.getTextBasedOnExactLabelName("Database Type")).toEqual(jsonUtil.getValue(orderObject, "Database Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Zone")).toEqual(jsonUtil.getValue(orderObject, "Zone"));
        expect(ordersPage.getTextBasedOnExactLabelName("Database Version")).toEqual(jsonUtil.getValue(orderObject, "Database Version"));
        expect(ordersPage.getTextBasedOnExactLabelName("Storage Engine")).toEqual(jsonUtil.getValue(orderObject, "Storage Engine"));
        expect(ordersPage.getTextBasedOnExactLabelName("Replication Factor")).toEqual(jsonUtil.getValue(orderObject, "Replication Factor"));
        expect(ordersPage.getTextBasedOnExactLabelName("Network Type")).toEqual(jsonUtil.getValue(orderObject, "Network Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Vpc ID")).toEqual(jsonUtil.getValue(orderObject, "Vpc ID"));
        expect(ordersPage.getTextBasedOnExactLabelName("Vswitch ID")).toEqual(jsonUtil.getValue(orderObject, "Vswitch ID"));
        expect(ordersPage.getTextBasedOnExactLabelName("Specification")).toEqual(jsonUtil.getValue(orderObject, "Specification"));
        expect(ordersPage.getTextBasedOnExactLabelName("Storage Space")).toEqual(jsonUtil.getValue(orderObject, "Storage Space"));
        expect(ordersPage.getTextBasedOnExactLabelName("Set Password")).toEqual(jsonUtil.getValue(orderObject, "Set Password"));

        //Checking Bill Of Material
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(placeOrderPage.getTotalCost()).toBe(orderObject.TotalCost);

        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
        orderFlowUtil.denyOrder(returnObj);
    });

    if (isProvisioningRequired == "true") {
        it('Aalibaba: TC-5 ApsaraDB for MongoDB -Verify Inventory / output parameters Details', function () {
            var orderObject = JSON.parse(JSON.stringify(apsaraDBForMongoDBTemplate.createApsaraDBforMongoDB));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            var returnObj = {};
            orderFlowUtil.fillOrderDetails(apsaraDBForMongoDBTemplate.createApsaraDBforMongoDB, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, orderObject.OrderStatus);

            //checking order on Inventory Page 
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();

            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
            expect(inventoryPage.getTextBasedOnLabelName(" Billing Method:")).toEqual(jsonUtil.getValue(orderObject, "Billing Method"));
            expect(inventoryPage.getTextBasedOnLabelName(" Database Type:")).toEqual(jsonUtil.getValue(orderObject, "Database Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" Zone:")).toEqual(jsonUtil.getValue(orderObject, "Zone"));
            expect(inventoryPage.getTextBasedOnLabelName(" Database Version:")).toEqual(jsonUtil.getValue(orderObject, "Database Version"));
            expect(inventoryPage.getTextBasedOnLabelName(" Storage Engine:")).toEqual(jsonUtil.getValue(orderObject, "Storage Engine"));
            expect(inventoryPage.getTextBasedOnLabelName(" Replication Factor:")).toEqual(jsonUtil.getValue(orderObject, "Replication Factor"));
            expect(inventoryPage.getTextBasedOnLabelName(" Network Type:")).toEqual(jsonUtil.getValue(orderObject, "Network Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" Vpc ID:")).toEqual(jsonUtil.getValue(orderObject, "Vpc ID"));
            expect(inventoryPage.getTextBasedOnLabelName(" Vswitch ID:")).toEqual(jsonUtil.getValue(orderObject, "Vswitch ID"));
            expect(inventoryPage.getTextBasedOnLabelName(" Specification:")).toEqual(jsonUtil.getValue(orderObject, "Specification"));
            expect(inventoryPage.getTextBasedOnLabelName(" Storage Space:")).toEqual(jsonUtil.getValue(orderObject, "Storage Space"));
            expect(inventoryPage.getTextBasedOnLabelName(" Set Password:")).toEqual(jsonUtil.getValue(orderObject, "Set Password"));
            inventoryPage.closeViewDetailsTab();
        });
    }
});