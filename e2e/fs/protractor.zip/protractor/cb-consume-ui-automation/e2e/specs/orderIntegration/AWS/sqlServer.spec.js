"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    sqlServTemplate = require('../../../../testData/OrderIntegration/AWS/sqlServer.json');

describe('AWS - RDS-SQLServer', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, dbInstance, sqlServObj, inventoryPage;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = sqlServTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Databases',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        systemTagText: "ibm_mcmp_soiid"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-sqlServer-" + util.getRandomString(5);
        dbInstance = "sqlSerDbIn" + util.getRandomString(5);
        sqlServObj = JSON.parse(JSON.stringify(sqlServTemplate));
    });

    beforeEach(function () {
        modifiedParamMap = { "Service Instance Name": serviceName, "DB instance identifier": dbInstance };
    });

    it('AWS-SQLServer - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        catalogPage.open();
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(sqlServTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(sqlServTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(sqlServTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(sqlServTemplate.TotalCost); expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["DB engine"]).toEqual(requiredReturnMap["Expected"]["DB engine"]);
            expect(requiredReturnMap["Actual"]["License Model"]).toEqual(requiredReturnMap["Expected"]["License Model"]);
            expect(requiredReturnMap["Actual"]["DB engine version"]).toEqual(requiredReturnMap["Expected"]["DB engine version"]);
            expect(requiredReturnMap["Actual"]["DB instance class"]).toEqual(requiredReturnMap["Expected"]["DB instance class"]);
            expect(requiredReturnMap["Actual"]["Storage type"]).toEqual(requiredReturnMap["Expected"]["Storage type"]);
            expect(requiredReturnMap["Actual"]["Allocated storage"]).toEqual(requiredReturnMap["Expected"]["Allocated storage"]);
            expect(requiredReturnMap["Actual"]["DB instance identifier"]).toEqual(dbInstance);
            expect(requiredReturnMap["Actual"]["Master username"]).toEqual(requiredReturnMap["Expected"]["Master username"]);
            expect(requiredReturnMap["Actual"]["Database port"]).toEqual(requiredReturnMap["Expected"]["Database port"]);
            expect(requiredReturnMap["Actual"]["Backup retention period"]).toEqual(requiredReturnMap["Expected"]["Backup retention period"]);
            expect(requiredReturnMap["Actual"]["Copy tags to snapshot"]).toEqual(requiredReturnMap["Expected"]["Copy tags to snapshot"]);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
           orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(sqlServTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 4000);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(sqlServTemplate.EstimatedPrice);
                //Validate pricing on order history page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(sqlServTemplate.EstimatedPrice);
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();            
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(sqlServObj,"AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("License Model")).toEqual(jsonUtil.getValue(sqlServObj,"License Model"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("DB engine")).toEqual(jsonUtil.getValue(sqlServObj,"DB engine"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(sqlServObj,"DB engine version"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(sqlServObj,"DB instance class"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Storage type")).toEqual(jsonUtil.getValue(sqlServObj,"Storage type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Allocated storage")).toEqual(jsonUtil.getValue(sqlServObj,"Allocated storage"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB instance identifier")).toEqual(dbInstance);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Master username")).toEqual(jsonUtil.getValue(sqlServObj,"Master username"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Database port")).toEqual(jsonUtil.getValue(sqlServObj,"Database port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValue(sqlServObj,"Backup retention period"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Copy tags to snapshot")).toEqual(jsonUtil.getValue(sqlServObj,"Copy tags to snapshot"));
 
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(sqlServTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(sqlServTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.clickAllOrdersUnderOrdersSection();
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(sqlServObj,"AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("License Model")).toEqual(jsonUtil.getValue(sqlServObj,"License Model"));
            expect(ordersPage.getTextBasedOnLabelName("DB engine")).toEqual(jsonUtil.getValue(sqlServObj,"DB engine"));
            expect(ordersPage.getTextBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(sqlServObj,"DB engine version"));
            expect(ordersPage.getTextBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(sqlServObj,"DB instance class"));
            expect(ordersPage.getTextBasedOnLabelName("Storage type")).toEqual(jsonUtil.getValue(sqlServObj,"Storage type"));
            expect(ordersPage.getTextBasedOnLabelName("Allocated storage")).toEqual(jsonUtil.getValue(sqlServObj,"Allocated storage"));
            expect(ordersPage.getTextBasedOnLabelName("DB instance identifier")).toEqual(dbInstance);
            expect(ordersPage.getTextBasedOnLabelName("Master username")).toEqual(jsonUtil.getValue(sqlServObj,"Master username"));
            expect(ordersPage.getTextBasedOnLabelName("Database port")).toEqual(jsonUtil.getValue(sqlServObj,"Database port"));
            expect(ordersPage.getTextBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValue(sqlServObj,"Backup retention period"));
            expect(ordersPage.getTextBasedOnLabelName("Copy tags to snapshot")).toEqual(jsonUtil.getValue(sqlServObj,"Copy tags to snapshot"));
 
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(sqlServTemplate.TotalCost);
            ordersPage.clickServiceDetailSliderCloseButton();
        });
    });

    it('AWS-SQLServer - Validate system tags, Edit and Delete Service', function () {
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            if (isDummyAdapterDisabled == "true") {
                orderObject.componentType = sqlServTemplate.componentType1;
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(sqlServTemplate.componentType1).then(function (index) {
                    inventoryPage.clickViewComponentBasedOnIndex(index - 1).then(function () {
                        //View Component VM details
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(sqlServTemplate.componentType1);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Resource Id")).toEqual(sqlServTemplate.resourceId);
                        //View Component Template Output Properties
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AvailabilityZone")).toContain(sqlServTemplate.availablilityZone);
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("LicenseModel")).toEqual(jsonUtil.getValue(sqlServObj,"License Model"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("EngineVersion")).toEqual(jsonUtil.getValue(sqlServObj,"DB engine version"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DBInstanceClass")).toEqual(jsonUtil.getValue(sqlServObj,"DB instance class"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("StorageType")).toEqual("gp2");
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AllocatedStorage")).toEqual(jsonUtil.getValue(sqlServObj,"Allocated storage"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DBInstanceIdentifier")).toEqual(dbInstance.toLowerCase());
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("MasterUsername")).toEqual(jsonUtil.getValue(sqlServObj,"Master username"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DbInstancePort")).toEqual(jsonUtil.getValue(sqlServObj,"Database port"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("BackupRetentionPeriod")).toEqual(jsonUtil.getValue(sqlServObj,"Backup retention period"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("CopyTagsToSnapshot")).toEqual(jsonUtil.getValue(sqlServObj,"Copy tags to snapshot"));
                          
                    });
                       
                    inventoryPage.getTagsOnInventory().then(function (tags) {
                        var tagList = tags.split(",");
                        var tagMap = inventoryPage.getServiceTags(tagList);                       
                        //verifying a system tag
                        expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                        //verifying some of the service tags             
                        expect(tagList.includes(tagList.find(tag => tag.includes("StackId:arn:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:logical-id:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-id:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-name")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("ibm_mcmp_soiid:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("orderNumber")))).toBe(true);
                        expect(tagMap["serviceInstanceName"].toLowerCase()).toContain(serviceName.toLowerCase());
                       // orderFlowUtil.closeHorizontalSliderIfPresent();
                    });                    
                });
            } else {
                inventoryPage.clickOverflowActionButtonForPowerStates();
                inventoryPage.clickViewComponentofAWSInstance();
                inventoryPage.getTagsOnInventory().then(function (tags) {
                    var tagList = tags.split(",");
                    var tagMap = inventoryPage.getServiceTags(tagList);
                    //verifying flags for dummy adapter
                    expect(tagMap["IsUsingDummy"]).toEqual("Yes");
                    expect(tagMap["Name"]).toEqual(sqlServTemplate.bluePrintName);
                    expect(tagMap["PhysicalId"]).toContain(serviceName);
                    expect(Object.keys(tagMap).includes("Test")).toBe(true);
                    expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                });
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AWS Region")).toEqual(jsonUtil.getValue(sqlServObj,"AWS Region"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("license Model")).toEqual(jsonUtil.getValue(sqlServObj,"License Model"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB engine version")).toEqual(jsonUtil.getValue(sqlServObj,"DB engine version"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB instance class")).toEqual(jsonUtil.getValue(sqlServObj,"DB instance class"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Storage type")).toEqual(jsonUtil.getValue(sqlServObj,"Storage type"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Allocated storage")).toEqual(jsonUtil.getValue(sqlServObj,"Allocated storage"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB instance identifier")).toEqual(jsonUtil.getValue(sqlServObj,"DB instance identifier"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Master username")).toEqual(jsonUtil.getValue(sqlServObj,"Master username"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Database port")).toEqual(jsonUtil.getValue(sqlServObj,"Database port"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Backup retention period")).toEqual(jsonUtil.getValue(sqlServObj,"Backup retention period"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Copy tags to snapshot")).toEqual(jsonUtil.getValue(sqlServObj,"Copy tags to snapshot"));
            }
            orderFlowUtil.closeHorizontalSliderIfPresent();
        });

        //Edit service flow
        var dbInstanceEdit = "sqlservnew"+ util.getRandomString(3); 
        var modifiedParamMapEdit = { "EditService": true, "DB instance identifier":dbInstanceEdit };
       
        orderFlowUtil.editService(orderObject);
        orderFlowUtil.fillOrderDetails(sqlServTemplate, modifiedParamMapEdit).then(function (reviewOrderExpActParamsMap) {
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(sqlServTemplate.TotalCostPostEdit);
            browser.sleep(5000);
            //Delete password key as its encrypted on UI.
            delete reviewOrderExpActParamsMap["Actual"]["Master password"];
            delete reviewOrderExpActParamsMap["Expected"]["Master password"];
            //Validate Review order page parameters
            expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
        });
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(sqlServTemplate.bluePrintName, "Edit");
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 5000);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == 'Completed') {
                //Verify updated details are reflected on order details page.						
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValueEditParameter(sqlServObj, "DB engine version"));
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(sqlServTemplate.TotalCostPostEdit);
                ordersPage.clickServiceDetailSliderCloseButton();
                //Delete Service flow                    
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, sqlServTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 3000);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            }
        });
     });
});
