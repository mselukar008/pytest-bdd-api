"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	gcpPubSubTemplate = require('../../../../../../testData/OrderIntegration/Google/pubsub.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('Google E2E cases for Auto New order and Auto Deny Delete order with Standard change', function() {
	var ordersPage, catalogPage, placeOrderPage, policyPage, snowPage, sampleOrder1, inventoryPage, cartListPage;
	var modifiedParamMap = {};
	var modifiedParamMapPolicyNew = {};
	var modifiedParamMapAddRuleNew = {};
	var modifiedParamMapPolicyDel = {};
	var modifiedParamMapAddRuleDel = {};
	var serviceName = "SNOWauto"+util.getRandomString(5);
	var policyNameNew = "SNOWautoGoogleNewPolicy"+util.getRandomString(5);
	var policyRuleNameNew = "SNOWautoGoogleNewPolicyRule"+util.getRandomString(5);
	var policyNameDel = "SNOWautoGoogleDelPolicy"+util.getRandomString(5);
	var policyRuleNameDel = "SNOWautoGoogleDelPolicyRule"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var topicName = "autom-" + util.getRandomString(5).toLowerCase();
    var suscrpName = "autom-" + util.getRandomString(5).toLowerCase();

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMapPolicyNew = {"policy Name":policyNameNew, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRuleNew = {"Add Rule Name":policyRuleNameNew,"Order Type": ["New"],"Provider":["Google"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":""};
		modifiedParamMapPolicyDel = {"policy Name":policyNameDel, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRuleDel = {"Add Rule Name":policyRuleNameDel,"Order Type": ["Deleted"],"Provider":["Google"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
				 					"Financial":"Auto Deny"};
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"","Name": topicName};
	});
	
	it('Set Change Request type to Standard in SNOW', function () {
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Approval Policy for Google with Auto New order and Auto Deny Delete order and Standard change', function () {
		
		//Create Policy for New Order
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicyNew);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRuleNew);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleNameNew);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleNameNew);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyNameNew);
  		expect(policyNameInPolicyTable).toEqual(policyNameNew);
  		
  		//Create Policy for Delete Order
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicyDel);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRuleDel);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleNameDel);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleNameDel);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyNameDel);
  		expect(policyNameInPolicyTable).toEqual(policyNameDel);
	});
	
	if(isProvisioningRequired == "true") {	
		it('Google: Pub/Sub ---- Verify Provision functionality with Auto New order and Auto Deny Delete order and Standard change', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(gcpPubSubTemplate.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(gcpPubSubTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(gcpPubSubTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(gcpPubSubTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(gcpPubSubTemplate.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":sampleOrder1};	
			
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(gcpPubSubTemplate.provInProgressState);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			}
			expect(snowPage.getTextShortDescription()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			}
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			snowPage.clickUpdateButton();
			
			//Validation on SNOW for Standard change
			snowPage.openRelatedChangeRequest();
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			}
			snowPage.clickBackButton();			
					
			//Order Completion in SNOW
			//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(gcpPubSubTemplate.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			
		  });		
	    });
	
		it('Google: Pub/Sub ---- Verify Delete functionality with Auto New order and Auto Deny Delete order and Standard change', function () {
		
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			sampleOrder1 = inventoryPage.getDeleteOrderNumber();
			
			//Validation in Marketplace 
			ordersPage.open();
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject,gcpPubSubTemplate.orderRejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(gcpPubSubTemplate.orderRejectedState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestRejectedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextShortDescription()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);		
			});		
		});
	 }
		
	it('Delete Approval Policy for Google with Auto New order and Auto Deny Delete order and Standard change', function () {
		
		//Delete New Order Policy
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyNameNew);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyNameNew+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyNameNew);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyNameNew);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	
	  	//Delete delete Order Policy
	  	policyPage.open();
	  	util.waitForAngular();
	  	browser.sleep(5000);
	  	policyPage.searchPolicyInPolicyTextbox(policyNameDel);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyNameDel+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyNameDel);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyNameDel);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyNameDel);
	  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);
   });  
});
	
	
	
	