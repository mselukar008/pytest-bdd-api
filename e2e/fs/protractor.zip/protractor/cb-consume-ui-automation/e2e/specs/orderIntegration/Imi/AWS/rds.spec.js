"use strict";
var Orders = require('../../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../../helpers/util.js'),
    jsonUtil = require('../../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../../testData/appUrls.json'),
    imiUtil = require('../../../../../helpers/imiApiUtil.js'),
    imiConfigTemplate = require('../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    imiManageServiceTemplate = require('../../../../../testData/OrderIntegration/Imi/manageService.json'),
    RDSInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSRDSInstance.json');

describe('IMI - RDS', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, RDSINSObject, dbInstanceIdentifier, inventoryPage, msgToVerify;
    var modifiedParamMap = {};
    var orderObject = {};
    var messageStrings = {
        providerName: 'Amazon',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        instanceName: RDSInstanceTemplate.instanceName,
        componentType: RDSInstanceTemplate.componentType,
        serviceId: RDSInstanceTemplate.serviceId,
        imiOrderSubmitted: "Configure IMI Managed Service"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
    });

    it('IMI:AWS RDS - Verify E2E flow for RDS with IMI Add On', function () {

        var serviceDetailsMap = {};

        serviceName = "aws-imi-rds-" + util.getRandomString(5);
        var addOnName = "rds-adOn-" + util.getRandomString(5);
        var dbInstanceIdentifier = "TestRdsInstance" + util.getRandomString(5);
        dbInstanceIdentifier = dbInstanceIdentifier.toLowerCase();
        var dbName = "TestDb" + util.getRandomString(5);
        dbName = dbName.toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "DB instance identifier": dbInstanceIdentifier, "Database name": dbName, "Add-On Name": addOnName };

        RDSINSObject = JSON.parse(JSON.stringify(RDSInstanceTemplate));
        orderObject.servicename = serviceName;
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(RDSInstanceTemplate.provider);
        catalogPage.clickProviderOrCategoryCheckbox(RDSInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(RDSInstanceTemplate.bluePrintName);

        //Update RDS template with IMI template
        delete RDSInstanceTemplate["Order Parameters"]["Configure Add-ons"];
        RDSInstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
        RDSInstanceTemplate["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
        RDSInstanceTemplate["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
        RDSInstanceTemplate["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(RDSInstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            //Restore template with default data	
            RDSInstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiManageServiceTemplate["Configure Add-ons"];
            delete RDSInstanceTemplate["Order Parameters"]["IMI Main Parameters"];
            delete RDSInstanceTemplate["Order Parameters"]["Configure manage service"];
            delete RDSInstanceTemplate["Order Parameters"]["Review IMI Config"];
            serviceDetailsMap = requiredReturnMap;
            util.waitForAngular();
            //Validate IMI configuration on Review Order page
            expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(placeOrderPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(placeOrderPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Provider Account", 1)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Provider Account IMI"));

            //Validate Review Order page with all Service Configuration
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(RDSInstanceTemplate.TotalCostWithAddOn);

            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["DB engine"]).toEqual(requiredReturnMap["Expected"]["DB engine"]);
            expect(requiredReturnMap["Actual"]["License Model"]).toEqual(requiredReturnMap["Expected"]["License Model"]);
            expect(requiredReturnMap["Actual"]["DB engine version"]).toEqual(requiredReturnMap["Expected"]["DB engine version"]);
            expect(requiredReturnMap["Actual"]["DB instance class"]).toEqual(requiredReturnMap["Expected"]["DB instance class"]);
            expect(requiredReturnMap["Actual"]["Multi-AZ deployment"]).toEqual(requiredReturnMap["Expected"]["Multi AZ deployment"]);
            expect(requiredReturnMap["Actual"]["Storage type"]).toEqual(requiredReturnMap["Expected"]["Storage type"]);
            expect(requiredReturnMap["Actual"]["Allocated storage"]).toEqual(requiredReturnMap["Expected"]["Allocated storage"]);
            expect(requiredReturnMap["Actual"]["DB instance identifier"]).toEqual(dbInstanceIdentifier);
            expect(requiredReturnMap["Actual"]["Master username"]).toEqual(requiredReturnMap["Expected"]["Master username"]);
            expect(requiredReturnMap["Actual"]["VPC Configuration Mode"]).toEqual(requiredReturnMap["Expected"]["VPC Configuration Mode"]);
            expect(requiredReturnMap["Actual"]["Public accessibility"]).toEqual(requiredReturnMap["Expected"]["Public accessibility"]);
            expect(requiredReturnMap["Actual"]["Availability zone for DB instance"]).toEqual(requiredReturnMap["Expected"]["Availability zone for DB instance"]);
            expect(requiredReturnMap["Actual"]["Database name"]).toEqual(dbName);
            expect(requiredReturnMap["Actual"]["Database port"]).toEqual(requiredReturnMap["Expected"]["Database port"]);
            expect(requiredReturnMap["Actual"]["DB parameter group"]).toEqual(requiredReturnMap["Expected"]["DB parameter group"]);
            expect(requiredReturnMap["Actual"]["Option group"]).toEqual(requiredReturnMap["Expected"]["Option group"]);
            expect(requiredReturnMap["Actual"]["Character set name"]).toEqual(requiredReturnMap["Expected"]["Character set name"]);
            expect(requiredReturnMap["Actual"]["Encryption"]).toEqual(requiredReturnMap["Expected"]["Encryption"]);
            expect(requiredReturnMap["Actual"]["Backup retention period"]).toEqual(requiredReturnMap["Expected"]["Backup retention period"]);
            expect(requiredReturnMap["Actual"]["Backup window"]).toEqual(requiredReturnMap["Expected"]["Backup window"]);
            expect(requiredReturnMap["Actual"]["Copy tags to snapshot"]).toEqual(requiredReturnMap["Expected"]["Copy tags to snapshot"]);
            expect(requiredReturnMap["Actual"]["Enhanced monitoring"]).toEqual(requiredReturnMap["Expected"]["Enhanced monitoring"]);
            expect(requiredReturnMap["Actual"]["Auto minor version upgrade"]).toEqual(requiredReturnMap["Expected"]["Auto minor version upgrade"]);
            expect(requiredReturnMap["Actual"]["Maintenance window"]).toEqual(requiredReturnMap["Expected"]["Maintenance window"]);

            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate Add on on orders page
            expect(ordersPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
            expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            util.waitForAngular();

            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(RDSINSObject, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("DB engine")).toEqual(jsonUtil.getValue(RDSINSObject, "DB engine"));
            expect(ordersPage.getTextBasedOnLabelName("License Model")).toEqual(jsonUtil.getValue(RDSINSObject, "License Model"));
            expect(ordersPage.getTextBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(RDSINSObject, "DB engine version"));
            expect(ordersPage.getTextBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(RDSINSObject, "DB instance class"));
            expect(ordersPage.getTextBasedOnLabelName("Multi-AZ deployment")).toEqual(jsonUtil.getValue(RDSINSObject, "Multi AZ deployment"));
            expect(ordersPage.getTextBasedOnLabelName("Storage type")).toEqual(jsonUtil.getValue(RDSINSObject, "Storage type"));
            expect(ordersPage.getTextBasedOnLabelName("Allocated storage")).toEqual(jsonUtil.getValue(RDSINSObject, "Allocated storage"));
            expect(ordersPage.getTextBasedOnLabelName("DB instance identifier")).toEqual(dbInstanceIdentifier);
            expect(ordersPage.getTextBasedOnLabelName("Master username")).toEqual(jsonUtil.getValue(RDSINSObject, "Master username"));
            expect(ordersPage.getTextBasedOnLabelName("VPC Configuration Mode")).toEqual(jsonUtil.getValue(RDSINSObject, "VPC Configuration Mode"));
            expect(ordersPage.getTextBasedOnLabelName("Public accessibility")).toEqual(jsonUtil.getValue(RDSINSObject, "Public accessibility"));
            expect(ordersPage.getTextBasedOnLabelName("Availability zone for DB instance")).toEqual(jsonUtil.getValue(RDSINSObject, "Availability zone for DB instance"));
            expect(ordersPage.getTextBasedOnLabelName("Database name")).toEqual(dbName);
            expect(ordersPage.getTextBasedOnLabelName("Database port")).toEqual(jsonUtil.getValue(RDSINSObject, "Database port"));
            expect(ordersPage.getTextBasedOnLabelName("DB parameter group")).toEqual(jsonUtil.getValue(RDSINSObject, "DB parameter group"));
            expect(ordersPage.getTextBasedOnLabelName("Option group")).toEqual(jsonUtil.getValue(RDSINSObject, "Option group"));
            expect(ordersPage.getTextBasedOnLabelName("Character set name")).toEqual(jsonUtil.getValue(RDSINSObject, "Character set name"));
            expect(ordersPage.getTextBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(RDSINSObject, "Encryption"));
            expect(ordersPage.getTextBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValue(RDSINSObject, "Backup retention period"));
            expect(ordersPage.getTextBasedOnLabelName("Backup window")).toEqual(jsonUtil.getValue(RDSINSObject, "Backup window"));
            expect(ordersPage.getTextBasedOnLabelName("Copy tags to snapshot")).toEqual(jsonUtil.getValue(RDSINSObject, "Copy tags to snapshot"));
            expect(ordersPage.getTextBasedOnLabelName("Enhanced monitoring")).toEqual(jsonUtil.getValue(RDSINSObject, "Enhanced monitoring"));
            expect(ordersPage.getTextBasedOnLabelName("Auto minor version upgrade")).toEqual(jsonUtil.getValue(RDSINSObject, "Auto minor version upgrade"));
            expect(ordersPage.getTextBasedOnLabelName("Maintenance window")).toEqual(jsonUtil.getValue(RDSINSObject, "Maintenance window"));

            //Validate Add On details
            ordersPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 2)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate estimated cost
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(RDSInstanceTemplate.TotalCostWithAddOn);
            //Validate BOM table on order details
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Database Instance": "25.296", "OnDemand Database Storage": "0.115", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(RDSInstanceTemplate.EstimatedPriceWithAddOn);
            }

            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            //Validate Add-On tag
            expect(ordersHistoryPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate Add On Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickExpandArrowForServiceAddOn();
            ordersHistoryPage.getAddOnDetails().then(function (addOnDetails) {
                expect(addOnDetails[1]).toContain(addOnName);
                expect(addOnDetails[3]).toContain(imiConfigTemplate.TotalCost);
                expect(addOnDetails[4]).toContain("Completed");
            })
            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(RDSINSObject, "AWS Region"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB engine")).toEqual(jsonUtil.getValue(RDSINSObject, "DB engine"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("License Model")).toEqual(jsonUtil.getValue(RDSINSObject, "License Model"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(RDSINSObject, "DB engine version"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(RDSINSObject, "DB instance class"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Multi-AZ deployment")).toEqual(jsonUtil.getValue(RDSINSObject, "Multi AZ deployment"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Storage type")).toEqual(jsonUtil.getValue(RDSINSObject, "Storage type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Allocated storage")).toEqual(jsonUtil.getValue(RDSINSObject, "Allocated storage"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB instance identifier")).toEqual(dbInstanceIdentifier);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Master username")).toEqual(jsonUtil.getValue(RDSINSObject, "Master username"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC Configuration Mode")).toEqual(jsonUtil.getValue(RDSINSObject, "VPC Configuration Mode"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Public accessibility")).toEqual(jsonUtil.getValue(RDSINSObject, "Public accessibility"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Availability zone for DB instance")).toEqual(jsonUtil.getValue(RDSINSObject, "Availability zone for DB instance"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Database name")).toEqual(dbName);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Database port")).toEqual(jsonUtil.getValue(RDSINSObject, "Database port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB parameter group")).toEqual(jsonUtil.getValue(RDSINSObject, "DB parameter group"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Option group")).toEqual(jsonUtil.getValue(RDSINSObject, "Option group"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Character set name")).toEqual(jsonUtil.getValue(RDSINSObject, "Character set name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(RDSINSObject, "Encryption"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValue(RDSINSObject, "Backup retention period"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Backup window")).toEqual(jsonUtil.getValue(RDSINSObject, "Backup window"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Copy tags to snapshot")).toEqual(jsonUtil.getValue(RDSINSObject, "Copy tags to snapshot"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Enhanced monitoring")).toEqual(jsonUtil.getValue(RDSINSObject, "Enhanced monitoring"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Auto minor version upgrade")).toEqual(jsonUtil.getValue(RDSINSObject, "Auto minor version upgrade"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Maintenance window")).toEqual(jsonUtil.getValue(RDSINSObject, "Maintenance window"));

            //Validate Add-On Details
            ordersHistoryPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 2)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 4)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(RDSInstanceTemplate.TotalCostWithAddOn);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Database Instance": "25.296", "OnDemand Database Storage": "0.115", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(RDSInstanceTemplate.TotalCostWithAddOn);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Verify Output parameter in Inventory
            expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            inventoryPage.clickViewAddOnDetails(orderObject);
            //Verify Add On details in Inventory
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Provider Name", 3)).toBe("IMI");
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Instance Status", 2)).toBe("Active");
            expect(inventoryPage.getTextImiMangmntLevl()).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            //expect(inventoryPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(inventoryPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //verify bom for Add On
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(imiConfigTemplate.TotalCost);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Validate IMI tags
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                var tagList = tags.split(",");
                if (isDummyAdapterDisabled == "true") {
                    expect(tagList[5]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[6]).toContain(imiConfigTemplate.ServiceTierName);
                } else {
                    expect(tagList[2]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[0]).toContain(imiConfigTemplate.ServiceTierName);
                }

                orderFlowUtil.closeHorizontalSliderIfPresent();
            });
        });
    });

    if (isDummyAdapterDisabled == "true") {

        it('IMI-AWS-RDS- Configure IMI Manage service having AddOn', function () {

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                    inventoryPage.clickConfigureImiService();
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });

            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost    
                expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                ordersPage.open();
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                orderFlowUtil.closeHorizontalSliderIfPresent();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);
                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);

                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                //ordersHistoryPage.clickAddOnDetails();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();

                //Validate Updated BOM on Inventory(AddOn+Manage Service)
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickOnInstanceTableActionIcon();
                inventoryPage.clickViewService();
                inventoryPage.clickBillOfMaterialsTabOrderDetails();
                //verify estimated cost for Add On
                expect(inventoryPage.getTextEstimatedCost()).toEqual(RDSInstanceTemplate.TotalCostWithAddOn);
                inventoryPage.clickMoreLinkinBom();
                //Validate BOM table for Add on
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                inventoryPage.clickViewServiceClosebutton();

            });
        });

    }

    it('IMI-AWS-RDS- Delete service having addon from Inventory', function () {
        //Delete Service flow
        orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
        //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
        orderFlowUtil.approveDeletedOrder(orderObject);
        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
    });

    if (isDummyAdapterDisabled == "true") {
        it('IMI-AWS-RDS- Configure Manage service from Inventory', function () {

            serviceName = "aws-auto-RDS-" + util.getRandomString(5);
            var dbInstanceIdentifier = "TestRdsInstance" + util.getRandomString(5);
            var dbName = "TestDb" + util.getRandomString(5);
            modifiedParamMap = { "Service Instance Name": serviceName, "DB instance identifier": dbInstanceIdentifier.toLowerCase(), "Database name": dbName.toLowerCase() };

            var RDSINSObject = JSON.parse(JSON.stringify(RDSInstanceTemplate));
            orderObject.servicename = serviceName;
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(RDSInstanceTemplate.provider);
            catalogPage.clickProviderOrCategoryCheckbox(RDSInstanceTemplate.Category);
            catalogPage.clickConfigureButtonBasedOnName(RDSInstanceTemplate.bluePrintName);
            //Fill Order Details
            orderFlowUtil.fillOrderDetails(RDSInstanceTemplate, modifiedParamMap);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(RDSInstanceTemplate.EstimatedPrice);

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                    inventoryPage.clickConfigureImiService();
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });

            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost    
                expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                ordersPage.open();
                //expect(util.getCurrentURL()).toMatch('orders');
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                //ordersHistoryPage.clickAddOnDetails();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                orderFlowUtil.closeHorizontalSliderIfPresent();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);
                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);

                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                //ordersHistoryPage.clickAddOnDetails();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();
                //Delete Service flow
                orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            });
        });
    }
});
