/********************
  Author : Pushpraj
 ********************/

"use strict";
var CatalogDiscoveryPage   = require('../../../pageObjects/catalogDiscovery.pageObject.js'),
	CatalogPage   		   = require('../../../pageObjects/catalog.pageObject.js'),
	util                   = require('../../../../helpers/util.js'),
	appUrls 			   = require('../../../../testData/appUrls.json'),
	logGenerator 	       = require("../../../../helpers/logGenerator.js"),
	logger 			       = logGenerator.getApplicationLogger(),
	catalogDiscoveryApi    = require('../../../../helpers/APIs/catalogDiscoveryServicesAPI.js'),
	catalogDiscoveryData   = require('../../../../testData/OrderIntegration/catalogDiscovery/catalogDiscovery_testData.json'),
	centos70_json_payload  = require('../../../../testData/OrderIntegration/catalogDiscovery/centos70_vRA75Payload.json');



describe('VRA - e2e Test cases for Catalog Discovery - ', function() {
	var catalogDiscoveryObj;	
	var catalogPageObj;
	var catalogDiscvrydata;
	var centos70_payLoad;

	beforeAll(function() {
		catalogPageObj = new CatalogPage();
		catalogDiscoveryObj = new CatalogDiscoveryPage();
		browser.driver.manage().window().maximize();
		catalogDiscvrydata = JSON.parse(JSON.stringify(catalogDiscoveryData));
		centos70_payLoad = JSON.parse(JSON.stringify(centos70_json_payload));
	});

	beforeEach(function() {
		browser.waitForAngularEnabled(false);
		catalogDiscoveryObj.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogAdminUrl);
	});

	it('navigate to catalog Admin page by clicking on the user menu humberger link', function(){
		catalogDiscoveryObj.navigateToCatalogAdminByHumburger();
		expect(catalogDiscoveryObj.getheaderTitleText()).toEqual(catalogDiscvrydata.headerText);
	});

	it('start catalog discovery for VRA from catalog Admin page', function(){
		catalogDiscoveryObj.clickOnStartCatalogDiscoveryBtn();
		catalogDiscoveryObj.clickOnProviderToStartDiscovery(catalogDiscvrydata.serviceCategoryProvider);
		catalogDiscoveryObj.selectVraAccountFromDrpDwn(catalogDiscvrydata.serviceAccount);
		catalogDiscoveryObj.clickOnOKBtnFromDiscoveryPopup();
		expect(catalogDiscoveryObj.getDiscoveryStartedPopupMsg()).toEqual(catalogDiscvrydata.discoveryStartedPopMsg);
		catalogDiscoveryObj.discoveryStartedPopup();
		catalogDiscoveryObj.open();
		catalogDiscoveryObj.clickOnProvidersToggleBtn();
		catalogDiscoveryObj.searchProviderByName("VRA");
		expect(catalogDiscoveryObj.getDiscoveryStatus()).toMatch(catalogDiscvrydata.discoveryStatusInProgress);
	});

	it('verify VRA Catalog discovery status', function(){
		catalogDiscoveryObj.waitToCompletDiscoveryStatus();
		logger.info("Current date "+catalogDiscoveryObj.currenDate());
		expect(catalogDiscoveryObj.getDiscoveryStatus()).toMatch(catalogDiscoveryObj.currenDate());
		catalogDiscoveryObj.clickOnVraHistoryLink();
		expect(catalogDiscoveryObj.getHistoryPageTitleText()).toMatch(catalogDiscvrydata.historyPageTitle);
		expect(catalogDiscoveryObj.getHeaderTextFromHistorySec()).toMatch(catalogDiscoveryObj.currenDate());
		expect(catalogDiscoveryObj.getStatusFromHistorySec()).toEqual(catalogDiscvrydata.discoveryStatusCompleted);
		expect(catalogDiscoveryObj.getAccountNameFromHistroySec()).toEqual(catalogDiscvrydata.serviceAccount);
	});

	it('click on service name view details and click on edit the service', function(){
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getServiceNameFromDraftSearchSection()).toEqual(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnViewDetailsLink();
		catalogDiscoveryObj.clickOnEditButton();
		catalogDiscoveryObj.clickOnCategoryDrpDwnFromEdit();
		catalogDiscoveryObj.clickOnComputeOptionFrmDrpDwn();
		catalogDiscoveryObj.clickPricingTab();
		catalogDiscoveryObj.sendFilePathToInputBox(catalogDiscvrydata.filePath);
		catalogDiscoveryObj.clickOnCancelBtn();
		catalogDiscoveryObj.clickOnCancelYesBtn();
		catalogDiscoveryObj.clickOnCatalogCategoryLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getEditedServiceStatus(catalogDiscvrydata.serviceName)).toEqual(catalogDiscvrydata.serviceStatusDraft);
	});

	it('change the configuarion and pricing json', async function(){
		catalogDiscoveryObj.getheaderTitleText().then(async function(){
			await catalogDiscoveryApi.putServiceCallForDraftToWIP(centos70_payLoad).then(function(obj){
				expect(200).toEqual(obj["statusCode"]);
				expect("OK").toEqual(obj["status"]);
				expect(catalogDiscvrydata.serviceId + "_WIP").toEqual(obj["id"]);
			});
		});
		catalogDiscoveryObj.clickOnDraftSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getServiceNameFromDraftSearchSection()).toEqual(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getEditedServiceStatus(catalogDiscvrydata.serviceName)).toEqual(catalogDiscvrydata.serviceStatusWIP);
	});

	it('Publish drafted service and validate the service in Published section', function(){
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnPublishService();
		catalogDiscoveryObj.getAlertNotificationTitle();
		catalogDiscoveryObj.getAlertNotificationSubTitle();
		catalogDiscoveryObj.getAlertNotificationCaption();
		expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(catalogDiscvrydata.publishSuccessfull);
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);		
		expect(catalogDiscoveryObj.getPublishedSerivceDate()).toMatch(catalogDiscoveryObj.currenDate());
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceName);
	});

	it('Verify published service should be availabe in catalog Page', function(){
		catalogPageObj.open();
		catalogPageObj.searchForBluePrint(catalogDiscvrydata.serviceName);
		expect(catalogPageObj.getBluePrintHeaderName()).toEqual(catalogDiscvrydata.serviceName);
	});

	it('retire the Published service and verify in Retired section', function(){
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);	
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnRetireServiceOption();
		catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
		catalogDiscoveryObj.getAlertNotificationTitle();
		catalogDiscoveryObj.getAlertNotificationSubTitle();
		catalogDiscoveryObj.getAlertNotificationCaption();
		catalogDiscoveryObj.clickOnRetiredSectionLink();
		expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(catalogDiscvrydata.retireSuccessfull);
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceName);
	});

	it('unretire the Published service and verify in Published section', function(){
		catalogDiscoveryObj.clickOnRetiredSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);	
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnUnretireServiceOption();
		catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
		catalogDiscoveryObj.getAlertNotificationTitle();
		catalogDiscoveryObj.getAlertNotificationSubTitle();
		catalogDiscoveryObj.getAlertNotificationCaption();
		expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(catalogDiscvrydata.unretireSuccessfull);
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName); 
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceName);
	});

	it('again retire the Published service and verify in Retired section', function(){
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);	
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnRetireServiceOption();
		catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
		catalogDiscoveryObj.getAlertNotificationTitle();
		catalogDiscoveryObj.getAlertNotificationSubTitle();
		catalogDiscoveryObj.getAlertNotificationCaption();
		catalogDiscoveryObj.clickOnRetiredSectionLink();
		expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(catalogDiscvrydata.retireSuccessfull);
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceName);
	});

	it('delete the retired service from Retired section and verify from API', async function(){
		catalogDiscoveryObj.clickOnRetiredSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);	
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceName);
		catalogDiscoveryObj.clickOnDeleteServiceOption();
		catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
		catalogDiscoveryObj.getAlertNotificationTitle();
		catalogDiscoveryObj.getAlertNotificationSubTitle();
		catalogDiscoveryObj.getAlertNotificationCaption();
		expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(catalogDiscvrydata.successMsg);
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceName);		
		expect(catalogDiscoveryObj.getNoDataAvailableTextPublishedSection()).toEqual(catalogDiscvrydata.noDataAvailabe);
		catalogDiscoveryObj.getheaderTitleText().then(async function(){
			let msg = await catalogDiscoveryApi.deletePublishedService(catalogDiscvrydata.serviceId);
			expect(msg).toEqual(catalogDiscvrydata.rows_affected);
		});
	});

	it('Verify deleted service should not be available in catalog Page', function(){
		catalogPageObj.open();
		catalogPageObj.searchForBluePrint(catalogDiscvrydata.serviceName);
		//expect(catalogPageObj.getBlueprintNotAvailableMsg()).toMatch(catalogDiscvrydata.noServiceFoundMsg);
		expect(catalogPageObj.getAllBluePrintHeaderName()).not.toBe(catalogDiscvrydata.serviceName);
	});

});
