//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.
"use strict";

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	Orders = require('../../../pageObjects/orders.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	jsonUtil = require('../../../../helpers/jsonUtil.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	vmInAwsAzureTemplate = require('../../../../testData/OrderIntegration/ICAM/AWSandAzureCallbacks.json');

describe('TA - E2E Test cases for ICAM-For Dynamic Callback service', function () {

	var catalogPage, placeOrderPage, ordersPage, orderHistoryPage, SubnetName, vpc, serviceName, virtualMachineName, awsSshKeyName, VsphereAwsEditsoiObject;
	var modifiedParamMap = {};
	var messageStrings = {
		providerName: vmInAwsAzureTemplate.providerName,
		category: vmInAwsAzureTemplate.category,
		providerAccount: vmInAwsAzureTemplate.providerAccount,
		completedState: vmInAwsAzureTemplate.completedState,
		approvalState: vmInAwsAzureTemplate.approvalState,
		orderTypeDel: vmInAwsAzureTemplate.orderTypeDel,
		urlOrders: vmInAwsAzureTemplate.urlOrders,
		provisiongstatus: vmInAwsAzureTemplate.provisiongstatus,
		orderSubmittedConfirmationMessage: vmInAwsAzureTemplate.orderSubmittedConfirmationMessage,
		orderFailedStatus: vmInAwsAzureTemplate.failedState
	};

	beforeAll(function () {
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		orderHistoryPage = new OrderHistoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		serviceName = vmInAwsAzureTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
		SubnetName = vmInAwsAzureTemplate.subnetnamePrefix + "-" + util.getRandomString(5);
		vpc = vmInAwsAzureTemplate.vpcPrefix + "-" + util.getRandomString(5);
		virtualMachineName = vmInAwsAzureTemplate.virtualMachineNamePrefix + "-" + util.getRandomString(5);
		awsSshKeyName = vmInAwsAzureTemplate.awsSshKeyNamePrefix + "-" + util.getRandomString(5);
		VsphereAwsEditsoiObject = JSON.parse(JSON.stringify(vmInAwsAzureTemplate));
		modifiedParamMap = { "Service Instance Name": serviceName, "Public SSH Key Name": awsSshKeyName, "Virtual Machine name": virtualMachineName }
	});



	if (isProvisioningRequired == "true") {
		it('TA : For Dynamic Callback service --- Verify Provision and Delete services', function () {
			var orderObject = {}
			catalogPage.clickConfigureButtonBasedOnName(vmInAwsAzureTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetailsICAM(vmInAwsAzureTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();

			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
				//  Delete service
				if (status == 'Completed') {
					var orderObject = {};
					var orderObject = { servicename: serviceName };
					//Edit flow
					var modifiedParamMap = { "EditService": true };
					orderFlowUtil.editService(orderObject);
					orderFlowUtil.fillOrderDetails(vmInAwsAzureTemplate, modifiedParamMap).then(function () {
						browser.sleep(5000);
					});
					placeOrderPage.submitOrder();
					orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();

					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
					placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
					orderFlowUtil.approveOrder(orderObject);
					orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
					expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
					orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
						if (status == 'Completed') {
							//Verify updated details are reflected on order details page.						
							ordersPage.clickFirstViewDetailsOrdersTable();
							expect(ordersPage.getTextBasedOnLabelName("AWS Region Name")).toEqual(jsonUtil.getValueEditParameter(VsphereAwsEditsoiObject, "AWS Region Name"));
							expect(ordersPage.getTextBasedOnLabelName("Virtual Private Cloud")).toEqual(jsonUtil.getValueEditParameter(VsphereAwsEditsoiObject, "Virtual Private Cloud"));
							expect(ordersPage.getTextBasedOnLabelName("Subnet Name")).toEqual(jsonUtil.getValueEditParameter(VsphereAwsEditsoiObject, "Subnet Name"));
							ordersPage.clickServiceDetailSliderCloseButton();
						}
						// Delete Service flow                    
						orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
						//expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
						orderFlowUtil.approveDeletedOrder(orderObject);
						orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
						expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
					});


				}
			});

		});
	}
});