/*
	
Spec_Name: e2ePricingValidation.spec.js
	
Description: It covers Pricing scenarios with some vaildations.  
	
Author: Swaroop Kotme
	
*/

//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.
"use strict";

const { browser } = require('protractor');

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	Orders = require('../../../pageObjects/orders.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
    pricingTemplate = require('../../../../testData/OrderIntegration/ICAM/PricingValidationService.json'),
    pricingNegativeCasesTemplate = require('../../../../testData/OrderIntegration/ICAM/e2ePricingNegativeCases.json')
	

describe('TA - E2E Pricing validation service', function () {

    var catalogPage,placeOrderPage,ordersPage, serviceName,modifiedParamMap,RandomPublicSSHKeyName;
    var orderObject = {};
    serviceName = pricingTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
    RandomPublicSSHKeyName = pricingTemplate.RandomPublicSSHKeyName + "-" + util.getRandomString(5);
	var messageStrings = {
		providerName				     : pricingTemplate.providerName,
		category					   	 : pricingTemplate.category,
        estimatedPrice				   	 : pricingTemplate.estimatedPrice,
		providerAccount				   	 : pricingTemplate.providerAccount,
		completedState				   	 : pricingTemplate.completedState,
		approvalState				   	 : pricingTemplate.approvalState,
		orderTypeDel				   	 : pricingTemplate.orderTypeDel,
		urlOrders					   	 : pricingTemplate.urlOrders,
		estimatedCost				   	 : pricingTemplate.estimatedCost,
		provisiongstatus                 : pricingTemplate.provisiongstatus,
		orderSubmittedConfirmationMessage: pricingTemplate.orderSubmittedConfirmationMessage,
		orderFailedStatus                : pricingTemplate.failedState,
		deletedStatus                    : pricingTemplate.deletedStatus,
        estimatedPriceforsmallplan       : pricingTemplate.estimatedPriceforsmallplan,
        estimatedPriceforMediumplan      : pricingTemplate.estimatedPriceforMediumplan,
        estimatedPriceforLargeplan       : pricingTemplate.estimatedPriceforLargeplan,
        estimatedPriceforslotwiseprice   : pricingNegativeCasesTemplate.Scenario2.estimatedPriceforslotwiseprice,
        estimatedPriceforZeroprice       : pricingNegativeCasesTemplate.Scenario3.estimatedPriceforZeroprice,
        planACPU			   	         : pricingNegativeCasesTemplate.Scenario1.planACPU,
        planARAM                         : pricingNegativeCasesTemplate.Scenario1.planARAM,
        planADisk                        : pricingNegativeCasesTemplate.Scenario1.planADisk,
        planBCPU			   	         : pricingNegativeCasesTemplate.Scenario2.planBCPU,
        planBRAM                         : pricingNegativeCasesTemplate.Scenario2.planBRAM,
        planBDisk                        : pricingNegativeCasesTemplate.Scenario2.planBDisk,
        pricingErrorMessage              : pricingNegativeCasesTemplate.Scenario2.pricingErrorMessage
	};
	
	beforeAll(function () {
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
	});

    if (isProvisioningRequired == "true") {
        it('TA - TC-1 e2e Pricing validation service --- Verify Provision services with verify total cost for SMALL plan', function () {
            modifiedParamMap = {"Service Instance Name": serviceName, "Public SSH Key Name": RandomPublicSSHKeyName};
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(pricingTemplate.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetailsICAM(pricingTemplate,modifiedParamMap);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPriceforsmallplan);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);

        });

        it('TA - TC-2 e2e Pricing validation service ---- Verify Delete services--- ', function () {
			var orderObject = {};
			orderObject.servicename = serviceName;
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
			orderFlowUtil.approveDeletedOrder(orderObject);
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState)
		});
    }

        it('TA - TC-3 e2e Pricing validation service --- Verify Total cost pricing for MEDIUM Plan', function () {
            var modifiedParamMap2 = {
                "dynamicValidation":true,"Service Instance Name": serviceName,"Public SSH Key Name": RandomPublicSSHKeyName}
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
                catalogPage.clickConfigureButtonBasedOnName(pricingTemplate.bluePrintName);
                placeOrderPage.setServiceNameTextICAM("TA-automation-Medium-plan-" + util.getRandomString(4));
                placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
                placeOrderPage.clickNextButton();
                orderFlowUtil.fillOrderDetails(pricingTemplate,modifiedParamMap2);
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPriceforMediumplan);

        });

        it('TA - TC-4 e2e Pricing validation service --- Verify Total cost pricing for LARGE Plan', function () 
        {
            var modifiedParamMap3 = {
                "EditService":true,"Service Instance Name": serviceName,"Public SSH Key Name": RandomPublicSSHKeyName}
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
                catalogPage.clickConfigureButtonBasedOnName(pricingTemplate.bluePrintName);
                placeOrderPage.setServiceNameTextICAM("TA-automation-LARGE-plan-" + util.getRandomString(4));
                placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
                placeOrderPage.clickNextButton();
                orderFlowUtil.fillOrderDetails(pricingTemplate,modifiedParamMap3);
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPriceforLargeplan);
                
        });

        it('TA - TC-5 e2e Pricing validation service --- Verify "one time charge price" is shown on config details page', function () 
        {
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
            catalogPage.searchForBluePrint(pricingTemplate.bluePrintName);
            catalogPage.clickDetailsButtonBasedOnName(pricingTemplate.bluePrintName);
            catalogPage.getOneTimeChargePrice();
            expect(catalogPage.getOneTimeChargePrice()).toBe(pricingTemplate.oneTimeChargeprice);
                
        });
        

        it('TA - TC-6 e2e Pricing validation service --- Verify Error message for No additional pricing condition for a user who give input more than base price condition', function () 
        {
            var modifiedParamMap = {"dynamicValidation":true,"Service Instance Name": serviceName}
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(pricingNegativeCasesTemplate.Scenario1.bluePrintName);
            placeOrderPage.setServiceNameTextICAM("TA-automation-BaseOnly-plan-" + util.getRandomString(4));
            placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
            placeOrderPage.clickNextButton();
            orderFlowUtil.fillOrderDetails(pricingNegativeCasesTemplate.Scenario1,modifiedParamMap);
            placeOrderPage.setCPUValueText(messageStrings.planACPU);
            placeOrderPage.setRAMValueText(messageStrings.planARAM);
            placeOrderPage.setDiskValueText(messageStrings.planADisk);
            placeOrderPage.clickNextButton();
            placeOrderPage.getTextpricingError();
            expect(placeOrderPage.getTextpricingError()).toBe(messageStrings.pricingErrorMessage);
                
        });

        it('TA - TC-7 e2e Pricing validation service --- Verify Error message for user entering invalid input for additional price condition', function () 
        {
            var modifiedParamMap = {"dynamicValidation":true,"Service Instance Name": serviceName}
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(pricingNegativeCasesTemplate.Scenario2.bluePrintName);
            placeOrderPage.setServiceNameTextICAM("TA-automation-invalid-base-input-" + util.getRandomString(4));
            placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
            placeOrderPage.clickNextButton();
            orderFlowUtil.fillOrderDetails(pricingNegativeCasesTemplate.Scenario2,modifiedParamMap);
            placeOrderPage.setCPUValueText(messageStrings.planBCPU);
            placeOrderPage.setRAMValueText(messageStrings.planBRAM);
            placeOrderPage.setDiskValueText(messageStrings.planBDisk);
            placeOrderPage.clickNextButton();
            placeOrderPage.getTextpricingError();
            expect(placeOrderPage.getTextpricingError()).toBe(messageStrings.pricingErrorMessage);
                
        });

        it('TA - TC-8 e2e Pricing validation service --- Verify Slot wise pricing is getting calculated correct or not', function () 
        {
            var modifiedParamMap = {"Service Instance Name": serviceName, "Public SSH Key Name": RandomPublicSSHKeyName}
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(pricingNegativeCasesTemplate.Scenario2.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetailsICAM(pricingNegativeCasesTemplate.Scenario2,modifiedParamMap);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPriceforslotwiseprice);
                
        });

});
