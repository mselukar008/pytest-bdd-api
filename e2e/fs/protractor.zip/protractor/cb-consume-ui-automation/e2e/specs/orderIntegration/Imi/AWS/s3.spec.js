"use strict";
var Orders = require('../../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../../helpers/util.js'),
    jsonUtil = require('../../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../../testData/appUrls.json'),
    imiUtil = require('../../../../../helpers/imiApiUtil.js'),
    imiConfigTemplate = require('../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    imiManageServiceTemplate = require('../../../../../testData/OrderIntegration/Imi/manageService.json'),
    s3InstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSS3Instance.json');

describe('IMI-AWS- S3', function () {
    var inventoryPage, ordersPage, homePage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, bucketName, logBucketName, S3INSObject, bucketPolicyEditor;
    var modifiedParamMap = {};
    var orderObject = {};
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Storage',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        orderTypeAction: "Action",
        instanceName: s3InstanceTemplate.instanceName,
        componentType: s3InstanceTemplate.componentType,
        imiOrderSubmitted: "Configure IMI Managed Service"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();

    });


    it('IMI:AWS S3 - Verify E2E flow for S3 with IMI Add On', function () {

        var serviceDetailsMap = {};
        serviceName = "aws-auto-s3-" + util.getRandomString(5);
        var addOnName = "s3-adOn-" + util.getRandomString(5);
        S3INSObject = JSON.parse(JSON.stringify(s3InstanceTemplate));
        orderObject.servicename = serviceName;

        bucketName = "buckettestaut" + util.getRandomString(5);
        bucketName = bucketName.toLowerCase();
        bucketPolicyEditor = JSON.stringify({ "Version": "2012-10-17", "Statement": [{ "Sid": "PublicRead", "Effect": "Allow", "Principal": "*", "Action": ["s3:GetObject"], "Resource": ["arn:aws:s3:::" + bucketName + "/*"] }] });
        logBucketName = "logbuckettestaut" + util.getRandomString(5);
        logBucketName = logBucketName.toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "Bucket Name": bucketName, "Log Bucket Name": logBucketName, "Bucket Policy Editor": bucketPolicyEditor, "Add-On Name": addOnName };


        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(s3InstanceTemplate.bluePrintName);

        //Update S3 template with IMI template
        delete s3InstanceTemplate["Order Parameters"]["Configure Add-ons"];
        s3InstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
        s3InstanceTemplate["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
        s3InstanceTemplate["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
        s3InstanceTemplate["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(s3InstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            util.waitForAngular();
            //Validate IMI configuration on Review Order page
            expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(placeOrderPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(placeOrderPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate Review Order page with all Service Configuration
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            //expect(requiredReturnMap["Actual"]["Service Instance Name"]).toEqual(serviceName);
            expect(requiredReturnMap["Actual"]["Bucket Name"]).toEqual(bucketName);
            expect(requiredReturnMap["Actual"]["Versioning"]).toEqual(requiredReturnMap["Expected"]["Versioning"]);
            expect(requiredReturnMap["Actual"]["Server Access Logging"]).toEqual(requiredReturnMap["Expected"]["Server Access Logging"]);
            expect(requiredReturnMap["Actual"]["Default Encryption"]).toEqual(requiredReturnMap["Expected"]["Default Encryption"]);
            expect(requiredReturnMap["Actual"]["Access Control"]).toEqual(requiredReturnMap["Expected"]["Access Control"]);
            expect(requiredReturnMap["Actual"]["Transfer Acceleration"]).toEqual(requiredReturnMap["Expected"]["Transfer Acceleration"]);

            expect(requiredReturnMap["Actual"]["Enter a rule name"]).toEqual(requiredReturnMap["Expected"]["Enter a rule name"]);
            expect(requiredReturnMap["Actual"]["Add tags to Rule"]).toEqual(requiredReturnMap["Expected"]["Add tags to Rule"]);
            expect(requiredReturnMap["Actual"]["Add filter tag key name to limit scope to tags"]).toEqual(requiredReturnMap["Expected"]["Add filter tag key name to limit scope to tags"]);
            expect(requiredReturnMap["Actual"]["Add filter tag key value to limit scope to tags"]).toEqual(requiredReturnMap["Expected"]["Add filter tag key value to limit scope to tags"]);
            expect(requiredReturnMap["Actual"]["Static Website Hosting"]).toEqual(requiredReturnMap["Expected"]["Static Website Hosting"]);
            expect(requiredReturnMap["Actual"]["Target Bucket Or Domain"]).toEqual(requiredReturnMap["Expected"]["Target Bucket Or Domain"]);

            //Submit Order
            // util.waitForAngular();
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate Add on on orders page
            expect(ordersPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
            expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            util.waitForAngular();
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            //expect(requiredReturnMap["Actual"]["Service Instance Name"]).toEqual(serviceName);
            expect(requiredReturnMap["Actual"]["Bucket Name"]).toEqual(bucketName);
            expect(requiredReturnMap["Actual"]["Versioning"]).toEqual(requiredReturnMap["Expected"]["Versioning"]);
            expect(requiredReturnMap["Actual"]["Server Access Logging"]).toEqual(requiredReturnMap["Expected"]["Server Access Logging"]);
            expect(requiredReturnMap["Actual"]["Default Encryption"]).toEqual(requiredReturnMap["Expected"]["Default Encryption"]);
            expect(requiredReturnMap["Actual"]["Access Control"]).toEqual(requiredReturnMap["Expected"]["Access Control"]);
            expect(requiredReturnMap["Actual"]["Transfer Acceleration"]).toEqual(requiredReturnMap["Expected"]["Transfer Acceleration"]);

            expect(requiredReturnMap["Actual"]["Enter a rule name"]).toEqual(requiredReturnMap["Expected"]["Enter a rule name"]);
            expect(requiredReturnMap["Actual"]["Add tags to Rule"]).toEqual(requiredReturnMap["Expected"]["Add tags to Rule"]);
            expect(requiredReturnMap["Actual"]["Add filter tag key name to limit scope to tags"]).toEqual(requiredReturnMap["Expected"]["Add filter tag key name to limit scope to tags"]);
            expect(requiredReturnMap["Actual"]["Add filter tag key value to limit scope to tags"]).toEqual(requiredReturnMap["Expected"]["Add filter tag key value to limit scope to tags"]);
            expect(requiredReturnMap["Actual"]["Static Website Hosting"]).toEqual(requiredReturnMap["Expected"]["Static Website Hosting"]);
            expect(requiredReturnMap["Actual"]["Target Bucket Or Domain"]).toEqual(requiredReturnMap["Expected"]["Target Bucket Or Domain"]);
            //Validate Add On details
            ordersPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 2)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate estimated cost
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(s3InstanceTemplate.TotalCostWithAddOn);
            //Validate BOM table on order details
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Storage": "USD 0.023", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Approve Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(s3InstanceTemplate.EstimatedPriceWithAddOn);
            }

            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            //Validate Add-On tag
            expect(ordersHistoryPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate Add On Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickExpandArrowForServiceAddOn();
            ordersHistoryPage.getAddOnDetails().then(function (addOnDetails) {
                expect(addOnDetails[1]).toContain(addOnName);
                expect(addOnDetails[3]).toContain(imiConfigTemplate.TotalCost);
                expect(addOnDetails[4]).toContain("Completed");
            })
            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(S3INSObject, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Bucket Name")).toEqual(bucketName);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Access Control")).toEqual(jsonUtil.getValue(S3INSObject, "Access Control"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Server Access Logging")).toEqual(jsonUtil.getValue(S3INSObject, "Server Access Logging"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Versioning")).toEqual(jsonUtil.getValue(S3INSObject, "Versioning"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Transfer Acceleration")).toEqual(jsonUtil.getValue(S3INSObject, "Transfer Acceleration"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Default Encryption")).toEqual(jsonUtil.getValue(S3INSObject, "Default Encryption"));

            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Bucket Policy Editor")).toEqual(bucketPolicyEditor);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Enter a rule name")).toEqual(jsonUtil.getValue(S3INSObject, "Enter a rule name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Add tags to rule")).toEqual(jsonUtil.getValue(S3INSObject, "Add Tags to Rule"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Add filter tag key name to limit scope to tags")).toEqual(jsonUtil.getValue(S3INSObject, "Add filter tag key name to limit scope to tags"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Add filter tag key value to limit scope to tags")).toEqual(jsonUtil.getValue(S3INSObject, "Add filter tag key value to limit scope to tags"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Static Website Hosting")).toEqual(jsonUtil.getValue(S3INSObject, "Static Website Hosting"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Target Bucket Or Domain")).toEqual(jsonUtil.getValue(S3INSObject, "Target Bucket Or Domain"));

            //Validate Add-On Details
            ordersHistoryPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 2)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 4)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(s3InstanceTemplate.TotalCostWithAddOn);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Storage": "USD 0.023", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(s3InstanceTemplate.TotalCostWithAddOn);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Verify Output parameter in Inventory
            expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            inventoryPage.clickViewAddOnDetails(orderObject);
            //Verify Add On details in Inventory
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Provider Name", 3)).toBe("IMI");
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Instance Status", 2)).toBe("Active");
            expect(inventoryPage.getTextImiMangmntLevl()).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            //expect(inventoryPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(inventoryPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //verify bom for Add On
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(imiConfigTemplate.TotalCost);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Validate IMI tags
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                console.log(tags);
                var tagList = tags.split(",");
                if (isDummyAdapterDisabled == "true") {
                    expect(tagList[3]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[4]).toContain(imiConfigTemplate.ServiceTierName);
                } else {
                    expect(tagList[2]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[0]).toContain(imiConfigTemplate.ServiceTierName);
                }
                orderFlowUtil.closeHorizontalSliderIfPresent();
            });
        });
    });

    if (isDummyAdapterDisabled == "true") {
        it('AWS-S3-IMI-Configure IMI Manage service having AddOn', function () {

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                    inventoryPage.clickConfigureImiService();
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });

            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost    
                expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);

                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                ordersPage.open();
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);
                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);

                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();

                //Validate Updated BOM on Inventory(AddOn+Manage Service)
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickOnInstanceTableActionIcon();
                inventoryPage.clickViewService();
                inventoryPage.clickBillOfMaterialsTabOrderDetails();
                //verify estimated cost for Add On
                inventoryPage.getTextEstimatedCost().then(function (actPrice) {
                    var priceArr = util.roundOffTotalCost(actPrice, s3InstanceTemplate.TotalCostWithAddOn);
                    expect(priceArr[0]).toEqual(priceArr[1]);
                });
                inventoryPage.clickMoreLinkinBom();
                //Validate BOM table for Add on
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                inventoryPage.clickViewServiceClosebutton();

            });
        });
    }
    it('IMI-AWS-S3- Delete service having addon from Inventory', function () {
        //Delete Service flow
        orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
        //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
        orderFlowUtil.approveDeletedOrder(orderObject);
        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
    });
    if (isDummyAdapterDisabled == "true") {
        it('AWS-S3-IMI-Configure Manage service from Inventory', function () {
            var serviceDetailsMap = {};
            serviceName = "aws-auto-s3-" + util.getRandomString(5);
            bucketName = "buckettestaut" + util.getRandomString(5);
            bucketName = bucketName.toLowerCase();
            bucketPolicyEditor = JSON.stringify({ "Version": "2012-10-17", "Statement": [{ "Sid": "PublicRead", "Effect": "Allow", "Principal": "*", "Action": ["s3:GetObject"], "Resource": ["arn:aws:s3:::" + bucketName + "/*"] }] });
            logBucketName = "logbuckettestaut" + util.getRandomString(5);
            logBucketName = logBucketName.toLowerCase();
            modifiedParamMap = { "Service Instance Name": serviceName, "Bucket Name": bucketName, "Log Bucket Name": logBucketName, "Bucket Policy Editor": bucketPolicyEditor };
            S3INSObject = JSON.parse(JSON.stringify(s3InstanceTemplate));
            orderObject.servicename = serviceName;
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
            catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(s3InstanceTemplate.bluePrintName);
            //Fill Order Details
            orderFlowUtil.fillOrderDetails(s3InstanceTemplate, modifiedParamMap);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);

            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');

            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(s3InstanceTemplate.EstimatedPriceWithAddOn);
            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                    inventoryPage.clickConfigureImiService();
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });

            // Delete parameters
            //         delete imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
            //         delete imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
            //         delete imiConfigTemplate["Order Parameters"]["Review IMI Config"];
            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost    
                expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);

                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                //Navigate to Inventory and check same order id is generated after performing
                //same operation as the order is not approved, CON-34929
                //======================================================================
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                        inventoryPage.clickConfigureImiService();
                        inventoryPage.getCustomOpsWarningPopupText().then(function(text){
                            expect(text.split("Order Number:")[1]).toContain(orderObject.orderNumber);
                            inventoryPage.clickCustomOpsWarningOKButton(); 
                        });                                               
                    });
                });
                ordersPage.open();
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);
                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);

                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();

                //Delete Service flow
                orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            });
        });
    }

});
