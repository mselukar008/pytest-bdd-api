
/*
2	
Spec_Name: e2eVirtualMachineInAzure.spec.js
3	
Description: It covers e2e order provision  and deprovision flow for ICAM Azure service.  
4	
Author: Sarika Bothe
5	
//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.
*/


"use strict";

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	Orders = require('../../../pageObjects/orders.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	vmInAzureTemplate = require('../../../../testData/OrderIntegration/ICAM/AzureVirtualMachine.json');


describe('TA - E2E Virtual machine in Azure service', function () {

	var catalogPage, placeOrderPage, ordersPage, serviceName, orderHistoryPage, inventoryPage;
	var modifiedParamMap = {};
	var messageStrings = {
		providerName: vmInAzureTemplate.providerName,
		category: vmInAzureTemplate.category,
		estimatedPrice: vmInAzureTemplate.orderTypeDel,
		providerAccount: vmInAzureTemplate.providerAccount,
		completedState: vmInAzureTemplate.completedState,
		approvalState: vmInAzureTemplate.approvalState,
		orderTypeDel: vmInAzureTemplate.orderTypeDel,
		urlOrders: vmInAzureTemplate.urlOrders,
		estimatedCost: vmInAzureTemplate.estimatedCost,
		orderSubmittedConfirmationMessage: vmInAzureTemplate.orderSubmittedConfirmationMessage,
		outputPrameterKey: vmInAzureTemplate.outputPrameterKey,
		vm_private_ip: vmInAzureTemplate.vm_private_ip,
		privateIp: vmInAzureTemplate.privateIp,
		PopUpMsgone: vmInAzureTemplate.PopUpMsgone,
		PopUpMsgtwo: vmInAzureTemplate.PopUpMsgtwo,
		cancelOrderSuccessMsg : vmInAzureTemplate.cancelOrderSuccessMsg,
		cancelledStatus : vmInAzureTemplate.cancelledStatus

	};

	beforeAll(function () {
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		orderHistoryPage = new OrderHistoryPage();
		inventoryPage = new InventoryPage();
		serviceName = vmInAzureTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
		modifiedParamMap = { "Service Instance Name": serviceName }
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);

	});

	it('TA - Virtual machine in Azure 1 ---- Verify fields on Main Parameters page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.searchForBluePrint(vmInAzureTemplate.bluePrintName);
		catalogPage.clickConfigureButtonBasedOnName(vmInAzureTemplate.bluePrintName);
		expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
		placeOrderPage.setServiceNameTextICAM(vmInAzureTemplate.serviceNamePrefix + "-" + util.getRandomString(4));
		placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
		expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
		//expect(placeOrderPage.getTextEstimatedPrice()).toBe(vmInAzureTemplate.EstimatedPrice);
	});

	it('TA - Virtual machine in Azure 2 ---- Verify Summary details and Additional Details are listed in review Order page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.searchForBluePrint(vmInAzureTemplate.bluePrintName);
		catalogPage.clickConfigureButtonBasedOnName(vmInAzureTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetailsICAM(vmInAzureTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			//expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
			//expect(requiredReturnMap["Actual"]["Instance Plan"]).toEqual(requiredReturnMap["Expected"]["Instance Plan"]);

		});
	});

	it('TA - Virtual machine in Azure 3 ---- Verify Order is listed in Orders details page once it is submitted from catalog page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.searchForBluePrint(vmInAzureTemplate.bluePrintName);
		catalogPage.clickConfigureButtonBasedOnName(vmInAzureTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetailsICAM(vmInAzureTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			//	var priceInReviewOrder = placeOrderPage.getEstimatedPrice_ReviewOrder();
			placeOrderPage.submitOrder();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			var orderId = placeOrderPage.getTextOrderNumberOrderSubmittedModal();

			//New1
			var orderId = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			//	var priceInSubmitOrderPopup = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			//	expect(priceInSubmitOrderPopup).toEqual(priceInReviewOrder);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			catalogPage.open(); // ramdom click
			//Service details on Order History page
			orderHistoryPage.open();
			orderHistoryPage.searchOrderById(orderId);
			//No more support on UI
			// var priceInOrderHistory = orderHistoryPage.getTextEstimatedCostOrderHistory();
			// expect(priceInOrderHistory).toEqual(priceInSubmitOrderPopup);
			orderHistoryPage.clickOnOrderTableDetailsExpandArrow();
			orderHistoryPage.clickOrdersTableActionIcon();
			orderHistoryPage.clickServiceDetailsLinkForTA();
			orderHistoryPage.clickBillOfMaterialsTabInServiceDetails();
			//	expect(orderHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);
			orderHistoryPage.closeServiceDetailsSlider();
			orderHistoryPage.clickOrdersTableActionIcon();
			orderHistoryPage.clickBillOfMaterialsForTA();
			//	expect(orderHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);
			ordersPage.open();
			expect(util.getCurrentURL()).toMatch(messageStrings.urlOrders);
			ordersPage.searchOrderById(orderId);

			expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderId);
			//No more support on UI
			// var priceInApproveOrders = ordersPage.getTextFirstAmountOrdersTable();
			// expect(priceInApproveOrders).toEqual(priceInSubmitOrderPopup);
			var orderAmount = ordersPage.getTextFirstAmountOrdersTable();

			ordersPage.clickFirstViewDetailsOrdersTable();
			expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual(messageStrings.approvalState);

		//	expect(ordersPage.getTextSubmittedByOrderDetails()).toContain(catalogPage.extractUserFirstName());
			expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
			expect(ordersPage.isDisplayedDenyButtonOrderDetails()).toEqual(true);
			ordersPage.clickServiceConfigurationsTabOrderDetails();
			expect(ordersPage.getTextBasedOnLabelName("Instance Plan")).toEqual((requiredReturnMap["Expected"]["Instance Plan"]));

			ordersPage.clickBillOfMaterialsTabOrderDetails();
			//	expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);

		});
	});


	if (isProvisioningRequired == "true") {
		it('TA - Virtual machine in Azure 4 --- Verify Provision is successful----', function () {
			//Provision service
			var orderObject = {};
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			var orderObject = JSON.parse(JSON.stringify(vmInAzureTemplate));
			catalogPage.searchForBluePrint(vmInAzureTemplate.bluePrintName);
			catalogPage.clickConfigureButtonBasedOnName(vmInAzureTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetailsICAM(vmInAzureTemplate, modifiedParamMap).then(function (requiredReturnMap) {
				placeOrderPage.submitOrder();
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				//	orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
				placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
				orderFlowUtil.approveOrder(orderObject);
				orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
				orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
					//Delete service
					if (status == 'Completed') {
						expect(inventoryPage.verifyOutputParams(requiredReturnMap, orderObject)).toBe(true);
					}
				});
			});
		});
		it('TA - Virtual machine in Azure 5 ---- verification of output paramaeters and service configurations-----', function () {
			catalogPage.open();
			var orderObject = {};
			//	orderObject.serviceName = serviceName;
			var returnObj = { servicename: serviceName };
			inventoryPage.verifyOutputParamsLablesIcam(returnObj).then(function (arryList) {
				expect(arryList[0]).toContain(messageStrings.outputPrameterKey);
			});
			inventoryPage.verifyOutputParamsValueIcam(returnObj).then(function (arryList) {
				expect(arryList[0]).toContain(messageStrings.vm_private_ip);
			});
		});

		it('TA - Virtual machine in Azure 6 ---Verify on Virtual machine, Taint operation is successful or not---', function () {

			catalogPage.open();
			var orderObject = {};
			orderObject.serviceName = serviceName;
			var returnObj = {
				servicename: serviceName
			};
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(returnObj.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickForwardButtonIcam();
				inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
					inventoryPage.icamClickTaintButtonOfIcamAzureInstance();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnOFFPermission();

					util.waitForAngular();

				});
			}).then(function () {
				var orderObject = JSON.parse(JSON.stringify(vmInAzureTemplate));

				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();
				orderFlowUtil.approveOrder(orderObject);
				orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
				expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
				inventoryPage.open();
				inventoryPage.searchOrderByServiceName(returnObj.servicename);

			});
		});

		//untaint
		it('TA - Virtual machine in Azure 7 ---Verify on Start Virtual machine,Untaint operation is successful or not--', function () {
			catalogPage.open();
			var orderObject = {};
			var returnObj = { servicename: serviceName };
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(returnObj.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickForwardButtonIcam();
				inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
					inventoryPage.icamClickUntaintButtonOfIcamAzureInstance();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnOFFPermission();

					util.waitForAngular();

				});
			}).then(function () {
				var orderObject = JSON.parse(JSON.stringify(vmInAzureTemplate));

				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();
				orderFlowUtil.approveOrder(orderObject);
				orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
				expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
				inventoryPage.open();
				inventoryPage.searchOrderByServiceName(returnObj.servicename);

			});
		});

		//perform custom operation when one operation is already in progress
		it('TA - Virtual machine in Azure 8 ---Verify Error message if user perform one custom operation on another---', function () {
			catalogPage.open();
			var orderObject = {};
			var returnObj = { servicename: serviceName };
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(returnObj.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickForwardButtonIcam();
				inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
					inventoryPage.icamClickUntaintButtonOfIcamAzureInstance();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnOFFPermission();
					util.waitForAngular();
				});
			}).then(function () {

				var orderObject = JSON.parse(JSON.stringify(vmInAzureTemplate));
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				var orderNumbergetPromise = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderNumbergetPromise.then(function (orderNumberValue) {

					console.log('Promise resolved' + orderNumberValue);
					inventoryPage.clickOkForCustomOpnOrderButton();
					inventoryPage.searchOrderByServiceName(returnObj.servicename);
					inventoryPage.clickExpandFirstRow();
					inventoryPage.clickForwardButtonIcam();
					inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam();
					inventoryPage.icamClickTaintButtonOfIcamAzureInstance();
					inventoryPage.placeD2opsOrder();
					var warningMsgString = messageStrings.PopUpMsgone + " " + orderNumberValue + messageStrings.PopUpMsgtwo;
					console.log(warningMsgString + "--> warning message");
					util.waitForAngular();
					expect(inventoryPage.getTextOfToastMessageIcam()).toContain(warningMsgString);
					util.waitForAngular();
					orderHistoryPage.searchOrderClickCancelOrder(orderObject.orderNumber)
					orderHistoryPage.clickOnOrderTableActionsCancelYesButton();
					orderHistoryPage.getTextCancelOrderSuccessFulMsg();
					orderHistoryPage.clickCancelOrderOkButton();
					inventoryPage.open(); //random click
					orderFlowUtil.waitForOrderStatusChangeInOrderHistory(orderObject,messageStrings.cancelledStatus)
					expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.cancelledStatus);

				})

			});
		});

		//delete service 
		it('TA - Virtual machine in Azure 9 ---- Verify Delete services-----', function () {
			var orderObject = {};
			orderObject.serviceName = serviceName;
			var returnObj = { servicename: serviceName };
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
			orderFlowUtil.approveDeletedOrder(orderObject);
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState)
			
		});
	}
});