"use strict";

var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    helpers = require('../../../../helpers/onPrepare.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    orderBuyerFlow = require('../../../../helpers/orderBuyerFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    testEnvironment = browser.params.url.includes("cb-qa-2") ? "QA 2" : browser.params.url.includes("customer1") ? "Customer 1" : "QA 4",
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    pubSubTemplate = require('../../../../testData/OrderIntegration/Google/pubsub.json');

describe('Hybrid Authentication', function () {
    var ordersPage, homePage, catalogPage, placeOrderPage, inventoryPage, orderHistoryPage, serviceName, topicName, suscrpName;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: pubSubTemplate.provider,
        category: pubSubTemplate.Category,
        catalogPageTitle: pubSubTemplate.catalogPageTitle,
        inputServiceNameWarning: pubSubTemplate.inputServiceNameWarning,
        orderSubmittedConfirmationMessage: pubSubTemplate.orderSubmittedConfirmationMessage,
        systemTagText: pubSubTemplate.systemTagText,
        orderFailureMsg: pubSubTemplate.orderFailureMsg,
        orderRejectedState: pubSubTemplate.orderRejectedState,
        orderFailedStatus: "Failed"

    };

    beforeAll(function () {
        ordersPage = new Orders();
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        orderHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        serviceName = "auto-pub-sub-" + util.getRandomString(5);
        topicName = "autom-" + util.getRandomString(5).toLowerCase();
        suscrpName = "autom-" + util.getRandomString(5).toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": topicName };
    });

    it('HybridAuthentication - Google Pub/Sub : Verify Session timeout functionality ', function () {

        var startTime,endTime,elapsedTime;
	    global.serviceName = serviceName;
        var pubsubObj = JSON.parse(JSON.stringify(pubSubTemplate));
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(pubSubTemplate.bluePrintName);        
         // Get the start time before waiting
        browser.controlFlow().execute(function() {
            startTime = new Date().getTime();
        });
        //Wait for 20 mins
        browser.sleep(2 * 600000);
        //Check if session is timeout after 20 mins
        expect(helpers.isSessionAvailable()).toEqual(true);
	//Get session timeout message
        expect(helpers.getTextSessionInactiveMsg()).toEqual(pubSubTemplate.sessionTimeOutMsg);
        //Get the end time when session gets timeout
        browser.controlFlow().execute(function() {
            endTime = new Date().getTime();
            elapsedTime = endTime - startTime;
            console.log('elapsedTime = ' + elapsedTime + 'ms');
        });
	//Validate login screen with username and password field
        expect(helpers.checkLoginScreenAfterSessionTimeOut()).toBe(true);
        
    });    
});
