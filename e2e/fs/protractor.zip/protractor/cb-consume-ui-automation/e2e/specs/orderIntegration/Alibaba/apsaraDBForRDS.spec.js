/*************************************************
Spec_Name: apsaraDBforRDS.spec.js
Description: This spec will cover E2E testing of ApsaraDB for RDS order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".  
**************************************************/

"use strict";
var async = require('async'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    apsaraDBForRDSTemplate = require('../../../../testData/OrderIntegration/Alibaba/ApsaraDBForRDS.json')

describe('Alibaba: Test cases for ApsaraDB for RDS', function () {
    var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage, homePage;
    var modifiedParamMap = {};
    var modifiedParamMapVPC = {};
    var messageStrings = {
        providerName: 'Alibaba Cloud',
        category: 'Databases'
    };
    var servicename = "Gsl-Auto-ApsaraDBForRDS" + util.getRandomString(5);
    var servicenameVPC = "Gsl-Auto-VPC" + util.getRandomString(5);
    modifiedParamMapVPC = {
        "Service Instance Name": servicenameVPC,
    };

    beforeAll(function () {
        homePage = new HomePage();
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        modifiedParamMap = {
            "Service Instance Name": servicename,
        };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });


    afterAll(function () {
        // Delete ApsaraDB for RDS
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');

        // Delete Virtual Private Cloud
        var returnObjVPC = {};
        returnObjVPC.servicename = servicenameVPC;
        returnObjVPC.deleteOrderNumber = orderFlowUtil.deleteService(returnObjVPC);
        orderFlowUtil.approveDeletedOrder(returnObjVPC);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObjVPC, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObjVPC)).toBe('Completed');


    });

    //Prerequisite: We need to create Virtual Private Cloud, which will be used by ApsaraDB for RDS.
    it('Aalibaba: TC-1 Prerequisite for ApsaraDB for RDS: Create new Virtual Private Cloud', function () {
        var orderObjectVPC = JSON.parse(JSON.stringify(apsaraDBForRDSTemplate.createVirtualPrivateCloud));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObjectVPC.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObjectVPC.bluePrintName);
        var returnObjVPC = {};
        orderFlowUtil.fillOrderDetails(apsaraDBForRDSTemplate.createVirtualPrivateCloud, modifiedParamMapVPC);
        placeOrderPage.submitOrder();
        returnObjVPC.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        returnObjVPC.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        returnObjVPC.servicename = servicenameVPC;
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObjectVPC.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(returnObjVPC);
        orderFlowUtil.waitForOrderStatusChange(returnObjVPC, orderObjectVPC.OrderStatus);
        homePage.open();
    });

    it('Aalibaba: TC-2 verify that for ApsaraDB for RDS all parameters on Main Parameters Page are present.', function () {
        var orderObject = JSON.parse(JSON.stringify(apsaraDBForRDSTemplate.createApsaraDBforRDS));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);

        expect(catalogDetailsPage.getServiceName()).toBe(orderObject.bluePrintName)
        expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true);
        expect(catalogDetailsPage.isPresentLinkToProviderSite()).toBe(true);
        expect(catalogDetailsPage.isPresentFeaturesLabel()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsLabel()).toBe(true);
        expect(catalogDetailsPage.getTextFeaturesLabel()).toBe(orderObject.FeaturesLabel);
        expect(catalogDetailsPage.getTextDetailsLabel()).toBe(orderObject.DetailsLabel);
        expect(catalogDetailsPage.isPresentFeaturesInfo()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsInfo()).toBe(true);

        catalogDetailsPage.clickCatalogFromBreadCrumbNav();
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
        homePage.open();
    });

    it('Aalibaba: TC-3 verify that for ApsaraDB for RDS all parameters on Review Order page matches with input.', function () {
        var orderObject = JSON.parse(JSON.stringify(apsaraDBForRDSTemplate.createApsaraDBforRDS));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderObject.servicename = servicename;
        orderFlowUtil.fillOrderDetails(apsaraDBForRDSTemplate.createApsaraDBforRDS, modifiedParamMap);

        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(orderObject.servicename);
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);

        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Billing Method:")).toEqual(jsonUtil.getValue(orderObject, "Billing Method"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Zones:")).toEqual(jsonUtil.getValue(orderObject, "Zones"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Multi Zone:")).toEqual(jsonUtil.getValue(orderObject, "Multi Zone"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Database Engine:")).toEqual(jsonUtil.getValue(orderObject, "Database Engine"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Engine Version:")).toEqual(jsonUtil.getValue(orderObject, "Engine Version"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Edition:")).toEqual(jsonUtil.getValue(orderObject, "Edition"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Storage Type:")).toEqual(jsonUtil.getValue(orderObject, "Storage Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Instance Type:")).toEqual(jsonUtil.getValue(orderObject, "Instance Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Minimum Capacity:")).toEqual(jsonUtil.getValue(orderObject, "Minimum Capacity"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Maximum Capacity:")).toEqual(jsonUtil.getValue(orderObject, "Maximum Capacity"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Steps:")).toEqual(jsonUtil.getValue(orderObject, "Steps"));
        expect(placeOrderPage.getTextBasedOnLabelName(" VPC:")).toEqual(jsonUtil.getValue(orderObject, "VPC"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Virtual Switch:")).toEqual(jsonUtil.getValue(orderObject, "Virtual Switch"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Default Security IP:")).toEqual(jsonUtil.getValue(orderObject, "Default Security IP"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Add Account:")).toEqual(jsonUtil.getValue(orderObject, "Add Account"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Add Whitelist:")).toEqual(jsonUtil.getValue(orderObject, "Add Whitelist"));
        homePage.open();
    });

    it('Aalibaba: TC-4 verify that for ApsaraDB for RDS all values on View Order Details page matches with input.', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(apsaraDBForRDSTemplate.createApsaraDBforRDS));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(apsaraDBForRDSTemplate.createApsaraDBforRDS, modifiedParamMap);
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();

        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename); //Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider); //Checking Provider

        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("Region")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(ordersPage.getTextBasedOnExactLabelName("Billing Method")).toEqual(jsonUtil.getValue(orderObject, "Billing Method"));
        expect(ordersPage.getTextBasedOnExactLabelName("Zones")).toEqual(jsonUtil.getValue(orderObject, "Zones"));
        expect(ordersPage.getTextBasedOnExactLabelName("Multi Zone")).toEqual(jsonUtil.getValue(orderObject, "Multi Zone"));
        expect(ordersPage.getTextBasedOnExactLabelName("Database Engine")).toEqual(jsonUtil.getValue(orderObject, "Database Engine"));
        expect(ordersPage.getTextBasedOnExactLabelName("Engine Version")).toEqual(jsonUtil.getValue(orderObject, "Engine Version"));
        expect(ordersPage.getTextBasedOnExactLabelName("Edition")).toEqual(jsonUtil.getValue(orderObject, "Edition"));
        expect(ordersPage.getTextBasedOnExactLabelName("Storage Type")).toEqual(jsonUtil.getValue(orderObject, "Storage Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Instance Type")).toEqual(jsonUtil.getValue(orderObject, "Instance Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Minimum Capacity")).toEqual(jsonUtil.getValue(orderObject, "Minimum Capacity"));
        expect(ordersPage.getTextBasedOnExactLabelName("Maximum Capacity")).toEqual(jsonUtil.getValue(orderObject, "Maximum Capacity"));
        expect(ordersPage.getTextBasedOnExactLabelName("Steps")).toEqual(jsonUtil.getValue(orderObject, "Steps"));
        expect(ordersPage.getTextBasedOnExactLabelName("VPC")).toEqual(jsonUtil.getValue(orderObject, "VPC"));
        expect(ordersPage.getTextBasedOnExactLabelName("Virtual Switch")).toEqual(jsonUtil.getValue(orderObject, "Virtual Switch"));
        expect(ordersPage.getTextBasedOnExactLabelName("Default Security IP")).toEqual(jsonUtil.getValue(orderObject, "Default Security IP"));
        expect(ordersPage.getTextBasedOnExactLabelName("Add Account")).toEqual(jsonUtil.getValue(orderObject, "Add Account"));
        expect(ordersPage.getTextBasedOnExactLabelName("Add Whitelist")).toEqual(jsonUtil.getValue(orderObject, "Add Whitelist"));
        //Checking Bill Of Material
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(placeOrderPage.getTotalCost()).toBe(orderObject.TotalCost);

        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
        orderFlowUtil.denyOrder(returnObj);
    });

    if (isProvisioningRequired == "true") {
        it('Aalibaba: TC-5 ApsaraDB for RDS -Verify Inventory / output parameters Details', function () {
            var orderObject = JSON.parse(JSON.stringify(apsaraDBForRDSTemplate.createApsaraDBforRDS));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            var returnObj = {};
            orderFlowUtil.fillOrderDetails(apsaraDBForRDSTemplate.createApsaraDBforRDS, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, orderObject.OrderStatus);

            //checking order on Inventory Page 
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();

            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
            expect(inventoryPage.getTextBasedOnLabelName(" Billing Method:")).toEqual(jsonUtil.getValue(orderObject, "Billing Method"));
            expect(inventoryPage.getTextBasedOnLabelName(" Zones:")).toEqual(jsonUtil.getValue(orderObject, "Zones"));
            expect(inventoryPage.getTextBasedOnLabelName(" Multi Zone:")).toEqual(jsonUtil.getValue(orderObject, "Multi Zone"));
            expect(inventoryPage.getTextBasedOnLabelName(" Database Engine:")).toEqual(jsonUtil.getValue(orderObject, "Database Engine"));
            expect(inventoryPage.getTextBasedOnLabelName(" Engine Version:")).toEqual(jsonUtil.getValue(orderObject, "Engine Version"));
            expect(inventoryPage.getTextBasedOnLabelName(" Edition:")).toEqual(jsonUtil.getValue(orderObject, "Edition"));
            expect(inventoryPage.getTextBasedOnLabelName(" Storage Type:")).toEqual(jsonUtil.getValue(orderObject, "Storage Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" Instance Type:")).toEqual(jsonUtil.getValue(orderObject, "Instance Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" Minimum Capacity:")).toEqual(jsonUtil.getValue(orderObject, "Minimum Capacity"));
            expect(inventoryPage.getTextBasedOnLabelName(" Maximum Capacity:")).toEqual(jsonUtil.getValue(orderObject, "Maximum Capacity"));
            expect(inventoryPage.getTextBasedOnLabelName(" Steps:")).toEqual(jsonUtil.getValue(orderObject, "Steps"));
            expect(inventoryPage.getTextBasedOnLabelName(" Capacity:")).toEqual(jsonUtil.getValue(orderObject, "Capacity"));
            expect(inventoryPage.getTextBasedOnLabelName(" VPC:")).toEqual(jsonUtil.getValue(orderObject, "VPC"));
            expect(inventoryPage.getTextBasedOnLabelName(" Virtual Switch:")).toEqual(jsonUtil.getValue(orderObject, "Virtual Switch"));
            expect(inventoryPage.getTextBasedOnLabelName(" Default Security IP:")).toEqual(jsonUtil.getValue(orderObject, "Default Security IP"));
            expect(inventoryPage.getTextBasedOnLabelName(" Add Account:")).toEqual(jsonUtil.getValue(orderObject, "Add Account"));
            expect(inventoryPage.getTextBasedOnLabelName(" Add Whitelist:")).toEqual(jsonUtil.getValue(orderObject, "Add Whitelist"));
            inventoryPage.closeViewDetailsTab();
        });
    }
});