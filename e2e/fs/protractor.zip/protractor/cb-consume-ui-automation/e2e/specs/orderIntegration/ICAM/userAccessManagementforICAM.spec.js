
/*	
Spec_Name:userAccessManagementforICAM.spec.js
Description: It covers e2e flow of E2E CRUD operations on 'icam_namespace','env' and 'app' context.
add,edit.delete context ICAM_Namespace.	
Author: Sarika Bothe
*/

"use strict";

const { browserclea } = require('protractor');
var UserAccsmangmntPage = require('../../../pageObjects/userAccessManagement.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    userManagementDataTemplate = require('../../../../testData/OrderIntegration/ICAM/userManagement.json');

describe('TA - E2E User Access Management', function () {
    var userAccsMangmntPage;

    beforeAll(function () {
        userAccsMangmntPage = new UserAccsmangmntPage();
    });
    var msgString = {
        contxtAddedMsg: userManagementDataTemplate.SuccessMsg,
        ICAM_Namespace:userManagementDataTemplate.ICAM_Namespace,
        IcamNamspaceID:userManagementDataTemplate.IcamNamspaceID,
        contxtNameIcamNamspace:userManagementDataTemplate.contxtNameIcamNamspace,
        ICAM_env:userManagementDataTemplate.ICAM_env,
        ICAM_app:userManagementDataTemplate.ICAM_app,
        DeleteMsg:userManagementDataTemplate.DeleteMsg

    };

    it('TC 01 : TA - User Access Management- Add New Context Value for icam namespace', function () {
        var contextTypeName = msgString.ICAM_Namespace;
        var contextIdIcamNamspace = msgString.IcamNamspaceID + util.getRandomString(3);
        var contxtNameIcamNamspace = msgString.contxtNameIcamNamspace + util.getRandomString(3);
        var contextDetails1 = { "Context Type": contextTypeName, "Context Value Name": contxtNameIcamNamspace, "Context Value ID": contextIdIcamNamspace };
        orderFlowUtil.closeHorizontalSliderIfPresent();
        userAccsMangmntPage.openContextTypes();
        userAccsMangmntPage.clickSearchBtn();
        userAccsMangmntPage.searchContextType(contextTypeName);
        userAccsMangmntPage.clickOnThreeDotMenuIcon(contextTypeName);
        userAccsMangmntPage.clickaddContextValue();
        userAccsMangmntPage.setNewContextValueDetailsICAM(contextDetails1);
        expect(userAccsMangmntPage.getSuccessMsg()).toContain(msgString.contxtAddedMsg);
        userAccsMangmntPage.verifysuccessMsgnotPresent();
        userAccsMangmntPage.clickpaginationClickDropdown();
        userAccsMangmntPage.clickOnThirthyPageValue();
        userAccsMangmntPage.clickOnThreeDotMenuIcon(contxtNameIcamNamspace);
        userAccsMangmntPage.clickOndeleteNamespaceButton();
        userAccsMangmntPage.clickOkUnassignPopup();
        expect(userAccsMangmntPage.getSuccessMsg()).toContain(msgString.DeleteMsg);
        userAccsMangmntPage.verifysuccessMsgnotPresent();
    });

    it('TC 02 : TA- User Access Management- Add New Context Value for environment', function () {
        var contextTypeName = msgString.ICAM_env;
        var contextIdenv = msgString.ICAM_env + util.getRandomString(3);
        var contxtNameenv = msgString.ICAM_env + util.getRandomString(3);
        var contextDetails2 = { "Context Type": "Environment", "Context Value Name": contxtNameenv, "Context Value ID": contextIdenv };
        orderFlowUtil.closeHorizontalSliderIfPresent();
        userAccsMangmntPage.openContextTypes();
        userAccsMangmntPage.clickSearchBtn();
        userAccsMangmntPage.searchContextType(contextTypeName);
        userAccsMangmntPage.clickOnThreeDotMenuIcon(contextTypeName);
        userAccsMangmntPage.clickaddContextValue();
        userAccsMangmntPage.setNewContextValueDetailsICAM(contextDetails2);
        expect(userAccsMangmntPage.getSuccessMsg()).toContain(msgString.contxtAddedMsg);
        userAccsMangmntPage.verifysuccessMsgnotPresent();
        userAccsMangmntPage.clickpaginationClickDropdown();
        userAccsMangmntPage.clickOnThirthyPageValue();
        userAccsMangmntPage.clickOnThreeDotMenuIcon(contxtNameenv);
        userAccsMangmntPage.clickOndeleteNamespaceButton();
        userAccsMangmntPage.clickOkUnassignPopup();
        expect(userAccsMangmntPage.getSuccessMsg()).toContain(msgString.DeleteMsg);
        userAccsMangmntPage.verifysuccessMsgnotPresent();
    });

    it('TC 03 : TA - User Access Management- Add New Context Value for application', function () {
        var contextTypeName = msgString.ICAM_app;
        var contextIdApp = msgString.ICAM_app + util.getRandomString(3);
        var contxtNameApp = msgString.ICAM_app + util.getRandomString(3);
        var contextDetails2 = { "Context Type": "Application", "Context Value Name": contxtNameApp, "Context Value ID": contextIdApp };
        orderFlowUtil.closeHorizontalSliderIfPresent();
        userAccsMangmntPage.openContextTypes();
        userAccsMangmntPage.clickSearchBtn();
        userAccsMangmntPage.searchContextType(contextTypeName);
         userAccsMangmntPage.clickOnThreeDotMenuIcon(contextTypeName);
         userAccsMangmntPage.clickaddContextValue();
        userAccsMangmntPage.setNewContextValueDetailsICAM(contextDetails2);
        expect(userAccsMangmntPage.getSuccessMsg()).toContain(msgString.contxtAddedMsg);
        userAccsMangmntPage.verifysuccessMsgnotPresent();
        userAccsMangmntPage.clickpaginationClickDropdown();
        userAccsMangmntPage.clickOnThirthyPageValue();
        userAccsMangmntPage.clickOnThreeDotMenuIcon(contxtNameApp);
        userAccsMangmntPage.clickOndeleteNamespaceButton();
        userAccsMangmntPage.clickOkUnassignPopup();
        expect(userAccsMangmntPage.getSuccessMsg()).toContain(msgString.DeleteMsg);
        userAccsMangmntPage.verifysuccessMsgnotPresent();
    });


})