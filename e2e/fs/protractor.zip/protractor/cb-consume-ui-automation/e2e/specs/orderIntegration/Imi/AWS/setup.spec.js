"use strict";
var isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../../testData/appUrls.json'),
    imiUtil = require('../../../../../helpers/imiApiUtil.js'),
    componentMapping = require('../../../../../testData/OrderIntegration/Imi/componentMapping.json'),
    applicationELBInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSApplicationLoadBalancer.json'),
    classicELBInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSClassicELBInstance.json'),
    cloudFrontRTMPDistributionTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSCloudFrontRTMPDistribution.json'),
    ec2InstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSEC2Instance.json'),
    glacierInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSGlacierInstance.json'),
    kmsInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSKMSInstance.json'),
    lambdaInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSLambdaInstance.json'),
    memcachedInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSElastiCacheMemcached.json'),
    networkELBInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSNetworkLoadBalancer.json'),
    RDSInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSRDSInstance.json'),
    redisInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSElasticacheRedisInstance.json'),
    s3InstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSS3Instance.json'),
    sqsInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSSQSInstance.json'),
    vpcInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSVPCInstance.json'),
    redshiftInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSRedshift.json'),
    persistentDiskTemplate = require('../../../../../testData/OrderIntegration/Google/persistentdisk.json'),
    gcpComputeInsTemplate = require('../../../../../testData/OrderIntegration/Google/gcpComputeIns.json');


describe('IMI SetUp', function () {

    xit("IMI Onboarding - Services", function () {

        var serviceComponentObj = JSON.parse(JSON.stringify(componentMapping));
        var providersObj = Object.keys(serviceComponentObj);
        var provider;
        var services;

        providersObj.forEach(async function (providerName) {
            provider = providerName;
            services = Object.keys(serviceComponentObj[provider]);
            services.forEach(async function (service) {

                var serviceDetails = Object.values(serviceComponentObj[provider][service]);
                var componentType = serviceDetails[0];
                var description = serviceDetails[1];
                var serviceId = serviceDetails[2];
                var serviceDefinationMap = { "name": service, "description": description, "resourceType": componentType, "shortDesc": description };

                //Create service mapping for dummy adapter
                if (isDummyAdapterDisabled == "false") {
                    await imiUtil.setServiceMappingForDummyAdapter(provider, serviceId, componentType).then(async function (apiResponse) {
                        logger.info("Service Mapping is succesfully updated for : " + service);
                    });
                }
                //Onboard service
                await imiUtil.setServiceDefination(provider, serviceDefinationMap).then(async function (apiResponse) {
                    logger.info("Service Defination succesfully updated for : " + service);
                    await imiUtil.getRateCard(provider, componentType).then(async function (rateCard) {
                        logger.info("Rate Card succesfully retrieved for : " + service);
                        await imiUtil.updatePricingValue(provider, componentType, rateCard).then(async function (apiResponse) {
                            logger.info("Pricing Values succesfully updated for : " + service);
                        });
                    });
                });

            });
        });

    });

    it("IMI Onboarding - ApplicationLoadBalancer", async function () {
        var serviceDefinationMap = { "name": applicationELBInstanceTemplate.bluePrintName, "description": applicationELBInstanceTemplate.descriptiveText, "resourceType": applicationELBInstanceTemplate.componentType, "shortDesc": applicationELBInstanceTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", applicationELBInstanceTemplate.serviceId, applicationELBInstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for ApplicationLoadBalancer succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for ApplicationLoadBalancer succesfully updated");
            await imiUtil.getRateCard("aws", applicationELBInstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for ApplicationLoadBalancer succesfully retrieved");
                await imiUtil.updatePricingValue("aws", applicationELBInstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Onboarding - ClassicLoadBalancer", async function () {
        var serviceDefinationMap = { "name": classicELBInstanceTemplate.bluePrintName, "description": classicELBInstanceTemplate.descriptiveText, "resourceType": classicELBInstanceTemplate.componentType, "shortDesc": classicELBInstanceTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", classicELBInstanceTemplate.serviceId, classicELBInstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for ClassicLoadBalancer succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for ClassicLoadBalancer succesfully updated");
            await imiUtil.getRateCard("aws", classicELBInstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for ClassicLoadBalancer succesfully retrieved");
                await imiUtil.updatePricingValue("aws", classicELBInstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Onboarding - cloudFrontRTMPDistribution", async function () {
        var serviceDefinationMap = { "name": cloudFrontRTMPDistributionTemplate.bluePrintName, "description": cloudFrontRTMPDistributionTemplate.descriptiveText, "resourceType": cloudFrontRTMPDistributionTemplate.componentType, "shortDesc": cloudFrontRTMPDistributionTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", cloudFrontRTMPDistributionTemplate.serviceId, cloudFrontRTMPDistributionTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for cloudFrontRTMPDistribution succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for cloudFrontRTMPDistribution succesfully updated");
            await imiUtil.getRateCard("aws", cloudFrontRTMPDistributionTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for cloudFrontRTMPDistribution succesfully retrieved");
                await imiUtil.updatePricingValue("aws", cloudFrontRTMPDistributionTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Provisioning - EC2", async function () {
        var serviceDefinationMap = { "name": ec2InstanceTemplate.bluePrintName, "description": ec2InstanceTemplate.descriptiveText, "resourceType": ec2InstanceTemplate.componentType, "shortDesc": ec2InstanceTemplate.shortDesc };

        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", ec2InstanceTemplate.serviceId, ec2InstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for EC2 succesfully updated");
            });
        }

        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for EC2 succesfully updated");
            await imiUtil.getRateCard("aws", ec2InstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for EC2 succesfully retrieved");
                await imiUtil.updatePricingValue("aws", ec2InstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Onboarding - Glacier", async function () {
        var serviceDefinationMap = { "name": glacierInstanceTemplate.bluePrintName, "description": glacierInstanceTemplate.descriptiveText, "resourceType": glacierInstanceTemplate.componentType, "shortDesc": glacierInstanceTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", glacierInstanceTemplate.serviceId, glacierInstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for Glacier succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for Glacier succesfully updated");
            await imiUtil.getRateCard("aws", glacierInstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for Glacier succesfully retrieved");
                await imiUtil.updatePricingValue("aws", glacierInstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Onboarding - KMS", async function () {
        var serviceDefinationMap = { "name": kmsInstanceTemplate.bluePrintName, "description": kmsInstanceTemplate.descriptiveText, "resourceType": kmsInstanceTemplate.componentType, "shortDesc": kmsInstanceTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", kmsInstanceTemplate.serviceId, kmsInstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for KMS succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for KMS succesfully updated");
            await imiUtil.getRateCard("aws", kmsInstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for KMS succesfully retrieved");
                await imiUtil.updatePricingValue("aws", kmsInstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Onboarding - lambda", async function () {
        var serviceDefinationMap = { "name": lambdaInstanceTemplate.bluePrintName, "description": lambdaInstanceTemplate.descriptiveText, "resourceType": lambdaInstanceTemplate.componentType, "shortDesc": lambdaInstanceTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", lambdaInstanceTemplate.serviceId, lambdaInstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for lambda succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for lambda succesfully updated");
            await imiUtil.getRateCard("aws", lambdaInstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for lambda succesfully retrieved");
                await imiUtil.updatePricingValue("aws", lambdaInstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Onboarding - MemcacheElasticCache", async function () {
        var serviceDefinationMap = { "name": memcachedInstanceTemplate.bluePrintName, "description": memcachedInstanceTemplate.descriptiveText, "resourceType": memcachedInstanceTemplate.componentType, "shortDesc": memcachedInstanceTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", memcachedInstanceTemplate.serviceId, memcachedInstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for MemcacheElasticCache succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for MemcacheElasticCache succesfully updated");
            await imiUtil.getRateCard("aws", memcachedInstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for MemcacheElasticCache succesfully retrieved");
                await imiUtil.updatePricingValue("aws", memcachedInstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Onboarding - NetworkLoadBalancer", async function () {
        var serviceDefinationMap = { "name": networkELBInstanceTemplate.bluePrintName, "description": networkELBInstanceTemplate.descriptiveText, "resourceType": networkELBInstanceTemplate.componentType, "shortDesc": networkELBInstanceTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", networkELBInstanceTemplate.serviceId, networkELBInstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for NetworkLoadBalancer succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for NetworkLoadBalancer succesfully updated");
            await imiUtil.getRateCard("aws", networkELBInstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for NetworkLoadBalancer succesfully retrieved");
                await imiUtil.updatePricingValue("aws", networkELBInstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Onboarding - RDS", async function () {
        var serviceDefinationMap = { "name": RDSInstanceTemplate.bluePrintName, "description": RDSInstanceTemplate.descriptiveText, "resourceType": RDSInstanceTemplate.componentType, "shortDesc": RDSInstanceTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", RDSInstanceTemplate.serviceId, RDSInstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for RDS succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for RDS succesfully updated");
            await imiUtil.getRateCard("aws", RDSInstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for RDS succesfully retrieved");
                await imiUtil.updatePricingValue("aws", RDSInstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Onboarding - Elasticache Redis", async function () {
        var serviceDefinationMap = { "name": redisInstanceTemplate.bluePrintName, "description": redisInstanceTemplate.descriptiveText, "resourceType": redisInstanceTemplate.componentType, "shortDesc": redisInstanceTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", redisInstanceTemplate.serviceId, redisInstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for Elasticache Redis succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for Elasticache Redis succesfully updated");
            await imiUtil.getRateCard("aws", redisInstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for Elasticache Redis succesfully retrieved");
                await imiUtil.updatePricingValue("aws", redisInstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI on boarding of S3 service", async function () {
        var serviceDefinationMap = { "name": s3InstanceTemplate.bluePrintName, "description": s3InstanceTemplate.descriptiveText, "resourceType": s3InstanceTemplate.componentType, "shortDesc": s3InstanceTemplate.shortDesc };
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", s3InstanceTemplate.serviceId, lambdaInstanceTemplate.bluePrintName).then(async function (apiResponse) {
                logger.info("Service Mapping for S3 succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for S3 succesfully updated");
            await imiUtil.getRateCard("aws", s3InstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for S3 succesfully retrieved");
                await imiUtil.updatePricingValue("aws", s3InstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    })

    it("IMI on boarding of SQS service", async function () {
        var serviceDefinationMap = { "name": sqsInstanceTemplate.bluePrintName, "description": sqsInstanceTemplate.descriptiveText, "resourceType": sqsInstanceTemplate.componentType, "shortDesc": sqsInstanceTemplate.shortDesc };
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", sqsInstanceTemplate.serviceId, sqsInstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for SQS succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for SQS succesfully updated");
            await imiUtil.getRateCard("aws", sqsInstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for SQS succesfully retrieved");
                await imiUtil.updatePricingValue("aws", sqsInstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Onboarding - VPC", async function () {
        var serviceDefinationMap = { "name": vpcInstanceTemplate.bluePrintName, "description": vpcInstanceTemplate.descriptiveText, "resourceType": vpcInstanceTemplate.componentType, "shortDesc": vpcInstanceTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", vpcInstanceTemplate.serviceId, vpcInstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for VPC succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for VPC succesfully updated");
            await imiUtil.getRateCard("aws", vpcInstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for VPC succesfully retrieved");
                await imiUtil.updatePricingValue("aws", vpcInstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Onboarding - Redshift", async function () {
        var serviceDefinationMap = { "name": redshiftInstanceTemplate.bluePrintName, "description": redshiftInstanceTemplate.descriptiveText, "resourceType": redshiftInstanceTemplate.componentType, "shortDesc": redshiftInstanceTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if (isDummyAdapterDisabled == "false") {
            await imiUtil.setServiceMappingForDummyAdapter("aws", redshiftInstanceTemplate.serviceId, redshiftInstanceTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for Redshift succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("aws", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for Redshift succesfully updated");
            await imiUtil.getRateCard("aws", redshiftInstanceTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for redshift succesfully retrieved");
                await imiUtil.updatePricingValue("aws", redshiftInstanceTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Provisioning - Persistent Disk", async function () {
        var serviceDefinationMap = { "name": persistentDiskTemplate.bluePrintName, "description": persistentDiskTemplate.descriptiveText, "resourceType": persistentDiskTemplate.componentType, "shortDesc": persistentDiskTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if(isDummyAdapterDisabled == "false"){
            await imiUtil.setServiceMappingForDummyAdapter("google", persistentDiskTemplate.serviceIdComponent, persistentDiskTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for Persistent Disk succesfully updated");
            });
        }
        
        //Update service defination
        await imiUtil.setServiceDefination("google", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for Persistent Disk succesfully updated");
            await imiUtil.getRateCard("google", persistentDiskTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for Persistent Disk succesfully retrieved");
                await imiUtil.updatePricingValue("google", persistentDiskTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });

    it("IMI Provisioning - Compute Engine", async function () {
        var serviceDefinationMap = { "name": gcpComputeInsTemplate.bluePrintName, "description": gcpComputeInsTemplate.descriptiveText, "resourceType": gcpComputeInsTemplate.componentType, "shortDesc": gcpComputeInsTemplate.shortDesc };
        //Create service mapping for dummy adapter
        if(isDummyAdapterDisabled == "false"){
            await imiUtil.setServiceMappingForDummyAdapter("google", gcpComputeInsTemplate.serviceIdComponent, gcpComputeInsTemplate.componentType).then(async function (apiResponse) {
                logger.info("Service Mapping for Compute Engine succesfully updated");
            });
        }
        //Update service defination
        await imiUtil.setServiceDefination("google", serviceDefinationMap).then(async function (apiResponse) {
            logger.info("Service Defination for Compute Engine succesfully updated");
            await imiUtil.getRateCard("google", gcpComputeInsTemplate.componentType).then(async function (rateCard) {
                logger.info("Rate Card for compute engine succesfully retrieved");
                await imiUtil.updatePricingValue("google", gcpComputeInsTemplate.componentType, rateCard).then(async function (apiResponse) {
                    logger.info("Pricing Values succesfully updated.");
                });
            });
        });
    });


});
