'use strict';

var util = require('util');
var async = require('async');
var msRestAzure = require('ms-rest-azure');
var ResourceManagementClient = require('azure-arm-resource').ResourceManagementClient;

var subscriptionId = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';  //Provide subscription ID on which Resource Groups are created
var tenantId = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';     //Provide TenantID for above subscription
var clientId = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';     //Provide ID of API used for performing operations on above subscription
var secret = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';    //Provide Secret Key for Client ID
var resourceClient;


//Entrypoint for the sample script   //

msRestAzure.loginWithServicePrincipalSecret(clientId, secret, tenantId, function (err, credentials) {
  if (err) return console.log(err);
  resourceClient = new ResourceManagementClient(credentials, subscriptionId);
   
  async.series([
    function (callback) {
      listResourceGroups(function (err, result, request, response) {
        if (err) {
          return callback(err);
        }
        console.log("Listing Resources:")
        result.forEach(element => {
            if (element['name'].toLowerCase().indexOf('gslauto') > -1)
            deleteResourceGroup(callback, element['name']);
            else
            console.log('Skipped '+ element['name']);
         });
      });
    }
       
    
  ]);
});


// Helper functions

function listResourceGroups(callback) {
  console.log('\nListing all resource groups: ');
  return resourceClient.resourceGroups.list(callback);
}

function deleteResourceGroup(callback, resourceGroupName) {
  console.log('\nDeleting resource group: ' + resourceGroupName);
  return resourceClient.resourceGroups.deleteMethod(resourceGroupName, element => {
     console.log('Deleted resource group: ' + resourceGroupName)
  });
}
