/*
Spec_Name: fileService.spec.js 
Description: This spec will cover E2E testing of File Service Service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra 
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    async = require('async'),
    logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    FSTemplate = require('../../../../testData/OrderIntegration/Azure/FileService.json');

if (isDummyAdapterDisabled == "true") {
    describe('Azure - File Service', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage;
        var modifiedParamMap1 = {};
        var messageStrings = { providerName: 'Azure', category: 'Storage' };
        var modifiedParamMap = {};
        var servicename1 = "AutoSTsrv" + util.getRandomString(5);
        var rgName1 = "gslautotc_azureSARG101" + util.getRandomString(5);
        var SAName = "autosa" + util.getRandomNumber(5);
        var servicename = "AutoFSsrv" + util.getRandomString(5);
        var FSName = "gslautofsname" + util.getRandomNumber(5);
        var SOIComponents;
        modifiedParamMap = { "Service Instance Name": servicename, "Existing Resource Group List": rgName1, "Storage Account List": SAName, "File Share Name": FSName };
        modifiedParamMap1 = { "Service Instance Name": servicename1, "Storage Account Name": SAName, "New Resource Group": rgName1 };

        beforeAll(function () {
            ordersPage = new Orders();
            catalogPage = new CatalogPage();
            placeOrderPage = new PlaceOrderPage();
            inventoryPage = new InventoryPage();
            catalogDetailsPage = new CatalogDetailsPage();
            browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
            FSName = "gslautofsname" + util.getRandomNumber(5);
            modifiedParamMap = { "Service Instance Name": servicename, "Existing Resource Group List": rgName1, "Storage Account List": SAName, "File Share Name": FSName };
            SOIComponents = [FSName]
        });

        afterAll(function () {
            // Delete File Service
            var returnObj1 = {};
            returnObj1.servicename = servicename;
            returnObj1.deleteOrderNumber = orderFlowUtil.deleteService(returnObj1);
            orderFlowUtil.approveDeletedOrder(returnObj1);
            orderFlowUtil.waitForDeleteOrderStatusChange(returnObj1, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj1)).toBe('Completed');
            //Delete Storage Account Created in Prerequisite.
            var returnObj = {};
            returnObj.servicename = servicename1;
            returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
            orderFlowUtil.approveDeletedOrder(returnObj);
            orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        });

        it('Azure: Prerequisite for Storage Account: Create new Storage Account', function () {
            //Prerequisite: We need to create Storage Account, which will be used by File Service.
            var orderObject1 = JSON.parse(JSON.stringify(FSTemplate.createStorageAccount));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject1.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject1.bluePrintName);
            var returnObj1 = {};
            orderFlowUtil.fillOrderDetails(FSTemplate.createStorageAccount, modifiedParamMap1);
            placeOrderPage.submitOrder();
            returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj1);
            orderFlowUtil.waitForOrderStatusChange(returnObj1, 'Completed');
        });

        //E2E File Service order Submit, Approve, Delete Service with Existing resource group.
        if (isProvisioningRequired == "true") {
            it('Azure: T444471-Verify File Storage service created, if user select existing resource group with existing storage account of General Purpose V1 storage account with Standard replication type, Virtual Network Disabled and Secure Transfer Disabled', function () {
                var orderObject = JSON.parse(JSON.stringify(FSTemplate.createFileService));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                var returnObj = {};
                orderFlowUtil.fillOrderDetails(FSTemplate.createFileService, modifiedParamMap);
                placeOrderPage.submitOrder();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                returnObj.servicename = servicename;
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(returnObj);
                orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed', 100);
                inventoryPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                inventoryPage.clickViewService();
                //Checking Inventory Page Service Configuration
                expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                expect(inventoryPage.getTextBasedOnLabelName(" Existing Resource Group List:")).toEqual(rgName1);
                expect(inventoryPage.getTextBasedOnLabelName(" Resource Group Location:")).toEqual(jsonUtil.getValue(orderObject, "Resource Group Location"));
                expect(inventoryPage.getTextBasedOnLabelName(" Storage Account List:")).toEqual(SAName);
                expect(inventoryPage.getTextBasedOnLabelName(" Storage Account Location:")).toEqual(jsonUtil.getValue(orderObject, "Storage Account Location"));
                expect(inventoryPage.getTextBasedOnLabelName(" File Share Name:")).toEqual(FSName);
                expect(inventoryPage.getTextBasedOnLabelName(" Replication Type:")).toEqual(jsonUtil.getValue(orderObject, "Replication Type"));
                expect(inventoryPage.getTextBasedOnLabelName(" Quota:")).toEqual(jsonUtil.getValue(orderObject, "Quota"));
                inventoryPage.closeViewDetailsTab();
                //Checking SOI Components
                if (isDummyAdapterDisabled == "true") {
                    inventoryPage.clickExpandFirstRow().then(function () {
                        browser.executeScript('window.scrollTo(0,0);');
                        var i = 1;
                        async.forEachSeries(SOIComponents, function (component, callback) {
                            inventoryPage.clickOverMenuIcon(i).then(function () {
                                inventoryPage.clickOnViewComponent(i).then(function () {
                                    expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                    inventoryPage.closeViewComponent();
                                    browser.sleep(10000);
                                    i++;
                                    return callback();
                                });
                            })
                        }, function (error) {
                            if (error) {
                                logger.info('Unable to Get SOI component')
                            }
                        })
                    })
                }
                 // check Non-Editable service Message
                 inventoryPage.clickNonEditableInstance();
                 expect(inventoryPage.getTextForInvalidEditModal()).toEqual(FSTemplate.nonEditableText);
                 inventoryPage.clickOnInvalidEditOkModal();
            });
        }

        //Checking parameters on Main Parameters page
        it('Azure: T444440-Verify that for File Storage, all parameters on Main Parameters Page are present.', function () {
            var orderObject = JSON.parse(JSON.stringify(FSTemplate.createFileService));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
            if (browser.params.defaultCurrency == "USD") {
            expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
            }
        });

        //Checking values all parameters on Review Order Page and View Order Details
        it('Azure: T444443-Verify that for File Storage Service all values on Review Order Page and View Order Details page matches with input', function () {
            var returnObj = {};
            returnObj.servicename = servicename;
            var orderObject = JSON.parse(JSON.stringify(FSTemplate.createFileService));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            orderFlowUtil.fillOrderDetails(FSTemplate.createFileService, modifiedParamMap);
            //Checking Service Details in ReviewOrder
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
            if (browser.params.defaultCurrency == "USD") {
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
            }
            //Checking Additional Details in ReviewOrder
            expect(placeOrderPage.getTextBasedOnLabelName(" Existing Resource Group List:")).toEqual(rgName1);
            expect(placeOrderPage.getTextBasedOnLabelName(" Resource Group Location:")).toEqual(jsonUtil.getValue(orderObject, "Resource Group Location"));
            expect(placeOrderPage.getTextBasedOnLabelName(" Storage Account List:")).toEqual(SAName);
            expect(placeOrderPage.getTextBasedOnLabelName(" Storage Account Location:")).toEqual(jsonUtil.getValue(orderObject, "Storage Account Location"));
            expect(placeOrderPage.getTextBasedOnLabelName(" File Share Name:")).toEqual(FSName);
            expect(placeOrderPage.getTextBasedOnLabelName(" Replication Type:")).toEqual(jsonUtil.getValue(orderObject, "Replication Type"));
            expect(placeOrderPage.getTextBasedOnLabelName(" Quota:")).toEqual(jsonUtil.getValue(orderObject, "Quota"));
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            ordersPage.open();
            ordersPage.searchOrderById(returnObj.orderNumber);
            ordersPage.clickFirstViewDetailsOrdersTable();
            //Checking Order Details in View order details
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
            //Checking Service Configuration Parameters
            ordersPage.clickServiceConfigurationsTabOrderDetails();
            expect(ordersPage.getTextBasedOnLabelName("Existing Resource Group List")).toEqual(rgName1);
            expect(ordersPage.getTextBasedOnLabelName("Resource Group Location")).toEqual(jsonUtil.getValue(orderObject, "Resource Group Location"));
            expect(ordersPage.getTextBasedOnLabelName("Storage Account List")).toEqual(SAName);
            expect(ordersPage.getTextBasedOnLabelName("Storage Account Location")).toEqual(jsonUtil.getValue(orderObject, "Storage Account Location"));
            expect(ordersPage.getTextBasedOnLabelName("File Share Name")).toEqual(FSName);
            expect(ordersPage.getTextBasedOnLabelName("Replication Type")).toEqual(jsonUtil.getValue(orderObject, "Replication Type"));
            expect(ordersPage.getTextBasedOnLabelName("Quota")).toEqual(jsonUtil.getValue(orderObject, "Quota"));
            //Checking Bill Of Material
            if (browser.params.defaultCurrency == "USD") {
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
            }
            ordersPage.clickServiceDetailSliderCloseButton();
        });
    });
}