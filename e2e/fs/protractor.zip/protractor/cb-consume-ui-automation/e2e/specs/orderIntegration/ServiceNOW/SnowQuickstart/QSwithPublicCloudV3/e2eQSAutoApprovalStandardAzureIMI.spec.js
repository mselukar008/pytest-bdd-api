"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	OrderHistory = require('../../../../../pageObjects/ordersHistory.pageObject'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	azureLinuxTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/AzureLinuxVMSnow.json'),
	imiConfigTemplate = require('../../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');

describe('QS: Azure IMI E2E cases for Auto Technical, Financial and Legal approval with Standard change', function () {
	var ordersPage, orderHistoryPage, catalogPage, placeOrderPage, snowPage, provOrder, sampleOrder1, inventoryPage, policyPage, cartListPage;
	var modifiedParamMap = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var serviceName = "SNOWQSAzureAuto" + util.getRandomString(5);
	var policyName = "SNOWQSautoAzurePolicy" + util.getRandomString(5);
	var policyRuleName = "SNOWQSautoAzurePolicyRule" + util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var newResourceGroupName = "gslautotc_azureWVM-RG101" + util.getRandomString(4);
	var newVmName = "auto-VM101" + util.getRandomString(4);
	var newNetworkName = "auto-VN101" + util.getRandomString(4);
	var newSubnetName = "auto-SN101" + util.getRandomString(4);
	var newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
	var newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
	var newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
	var newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
	var addOnName = "lvm-addOn-" + util.getRandomString(5);
	var diskName = "autodisk" + util.getRandomString(4);
	diskName = diskName.toLocaleLowerCase();
	var azureLinuxObj = JSON.parse(JSON.stringify(azureLinuxTemplate.Scenario1));

	//Update template with IMI template
	delete azureLinuxObj["Order Parameters"]["Configure Add-ons"];
	azureLinuxObj["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
	azureLinuxObj["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
	azureLinuxObj["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
	azureLinuxObj["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];
	azureLinuxObj["TotalCost"] = imiConfigTemplate["TotalCost"];

	beforeAll(function () {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		orderHistoryPage = new OrderHistory();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
		
		 //Delete policy if exists
		policyPage.open();
		util.waitForAngular();
		policyPage.deletePoliciesIfExist();
	});

	beforeEach(function () {
		modifiedParamMapPolicy = { "policy Name": policyName, "Values": "Auto-TEAM1 (my_org)" };
		modifiedParamMapAddRule = { "Add Rule Name": policyRuleName, "Order Type": ["New", "Edited", "Deleted", "ServiceAction"], "Provider": ["Azure"], "Total Monthly Cost": "", "Monthly Cost": "", "Budget Is": "" };
		modifiedParamMap = { "Service Instance Name": serviceName, "Team": "Auto-TEAM1", "Environment": "QA", "Application": "", "New Resource Group": newResourceGroupName, "Disk Name": diskName, "Virtual Machine Name": newVmName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName, "Add-On Name": addOnName, "Provider Account IMI": "default_asset_account_imi_Auto-TEAM1 / test-account_Auto-TEAM1" };
	});

	afterAll(function() {

		//Delete Approval Policy
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});

	it('Set Change Request type to Standard in SNOW', function () {
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});

	it('Create Approval Policy for Azure with Auto Technical, Financial, Legal approval and Standard change', function () {
		policyPage.open();
		policyPage.clickAddNewPolicyBtn();
		policyPage.selectStartDate();
		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
		policyPage.clickApplyRulePolicyBtn();
		var policyRuleNameTextInApprovalPolicy = policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
		policyPage.clickCreatePolicyButton();
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
		policyPage.clickNotificationCloseButton();
		var policyNameInPolicyTable = policyPage.getTextPolicyNameInPolicyTable(policyName);
		expect(policyNameInPolicyTable).toEqual(policyName);
	});

	if (isProvisioningRequired == "true") {
		it('Azure: Linux Virtual Machine ---- Verify Provision functionality with Auto Technical, Financial, Legal approval and Standard change', function () {

			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
			catalogPage.clickProviderCheckBoxBasedOnName(azureLinuxObj.providerName);
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(azureLinuxObj.Category);
			catalogPage.clickConfigureButtonBasedOnName(azureLinuxObj.bluePrintName);
			orderObject.servicename = serviceName;

			orderFlowUtil.fillOrderDetails(azureLinuxObj, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(azureLinuxObj.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = { "orderNumber": provOrder };

			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.provInProgressState);

			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			if (isDummyAdapterDisabled == "true") {
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			}
			expect(snowPage.getTextShortDescription()).toBe(azureLinuxObj.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);
			expect(snowPage.getOrderNumberText()).toBe(provOrder);

			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			if (isDummyAdapterDisabled == "true") {
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			expect(snowPage.getTextRequestedItemShortDesc()).toContain(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescAzure);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAzure);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function (sName) {
				expect(sName).toContain(serviceName);
				// Broker Config values table validations
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Resource Group Required")).toEqual("Yes");
				expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("New Resource Group")).toEqual(newResourceGroupName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Location").toString().toLowerCase().replace(/\s/g, ''));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Name")).toEqual(newVmName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Virtual Machine Location"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Username")).toEqual(jsonUtil.getValue(azureLinuxObj, "Username"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Authentication Type"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Admin Password")).toEqual("XXXXXX");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Proximity Placement Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "Proximity Placement Group"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Availability Options")).toEqual("NoInfrastructureRedundancyRequired");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Image")).toEqual("RHEL, 7.4, RedHat");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vm Generation")).toEqual("V1");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Size")).toEqual("Basic_A0");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Virtual Network Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "New Virtual Network Required"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Network Name")).toEqual(newNetworkName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Address Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Address Prefix"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Name")).toEqual(newSubnetName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Subnet Prefix"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Interface Name")).toEqual(newNetworkInterfaceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Required"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Name")).toEqual(newPublicIpName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Ip Address Sku"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Type"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("NIC Network Security Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "NIC Network Security Group"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Inbound Ports")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Inbound Ports"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use Load Balancing")).toEqual(jsonUtil.getValue(azureLinuxObj, "Use Load Balancing"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(azureLinuxObj, "System Assigned Managed Identity"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "Boot Diagnostics"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "OS Guest Diagnostics"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(azureLinuxObj, "Enable Auto Shutdown"));

				// Addon Services Values table validations
				expect(snowPage.getTextReqItemAddOnValuesBasedOnName("Management level")).toEqual(snowInstanceTemplate.snowAzureAddOnManagementLevelValue);
				expect(snowPage.getTextReqItemAddOnValuesBasedOnName("Management level Summary")).toEqual(snowInstanceTemplate.snowAzureAddOnManagementLevelSummaryValue);
				expect(snowPage.getTextReqItemAddOnValuesBasedOnName("Plan level")).toEqual(snowInstanceTemplate.snowAzureAddOnPlanLevelValue);
				expect(snowPage.getTextReqItemAddOnValuesBasedOnName("Plan level Summary")).toEqual(snowInstanceTemplate.snowAzureAddOnPlanLevelSummaryValue);

				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem2Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem3Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem4Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem5Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem6Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNIAzure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem2Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVNAzure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem3Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNSGAzure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem4Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSBA0Azure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem5Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalPublicIPAzure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem6Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalHDDAzure);

				// Get Addon service name from table caption
				snowPage.getAddOnServiceNameFromRITM().then(function(addOnServiceName){
					// Validate BOM values for Addon service
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(addOnServiceName, snowInstanceTemplate.snowAzureAddOnItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(addOnServiceName, snowInstanceTemplate.snowAzureAddOnItem2Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(addOnServiceName, snowInstanceTemplate.snowAzureAddOnItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAzureIMI1);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(addOnServiceName, snowInstanceTemplate.snowAzureAddOnItem2Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAzureIMI2);
				})

				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				if (isDummyAdapterDisabled == "true") {
					expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
					expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				}
				snowPage.clickUpdateButton();

				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				if (isDummyAdapterDisabled == "true") {
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				snowPage.clickBackButton();

				//Standard change
				snowPage.openRelatedChangeRequest();

				//Order Completion in SNOW
				snowPage.checkIfProvisioningTaskClosed();

				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				// On Approve orders page
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.completedState);
				// On Order History page
				orderHistoryPage.open();
				orderHistoryPage.searchOrderById(orderObject.orderNumber);
				expect(orderHistoryPage.getTextFirstOrderStatusOrdersTable()).toBe(azureLinuxObj.completedState);
				orderHistoryPage.clickOnOrderTableDetailsExpandArrow();
				expect(orderHistoryPage.getStatusBasedOnServiceNameWithAddOn(sName)).toBe(azureLinuxObj.completedState);
				orderHistoryPage.clickExpandArrowForServiceAddOn();
				orderHistoryPage.getAddOnDetails().then(function (addOnDetails) {
					expect(addOnDetails[4]).toContain(azureLinuxObj.completedState);
				});

				//Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();

				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
			});
		});

		it('Azure: Linux Virtual Machine ---- Verify Delete functionality with Auto Technical, Financial, Legal approval and Standard change', function () {

			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			sampleOrder1 = inventoryPage.getDeleteOrderNumber();

			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(azureLinuxObj.provInProgressState);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(azureLinuxObj.orderTypeDel);

			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			if (isDummyAdapterDisabled == "true") {
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			}
			expect(snowPage.getTextShortDescription()).toBe(azureLinuxObj.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);

			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
			if (isDummyAdapterDisabled == "true") {
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			expect(snowPage.getTextRequestedItemShortDesc()).toContain(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescAzure);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAzure);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function (sName) {
				expect(sName).toContain(serviceName);

				// Broker Config values table validations
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Resource Group Required")).toEqual("Yes");
				expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("New Resource Group")).toEqual(newResourceGroupName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Location").toString().toLowerCase().replace(/\s/g, ''));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Name")).toEqual(newVmName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Virtual Machine Location"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Username")).toEqual(jsonUtil.getValue(azureLinuxObj, "Username"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Authentication Type"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Admin Password")).toEqual("XXXXXX");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Proximity Placement Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "Proximity Placement Group"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Availability Options")).toEqual("NoInfrastructureRedundancyRequired");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Image")).toEqual("RHEL, 7.4, RedHat");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vm Generation")).toEqual("V1");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Size")).toEqual("Basic_A0");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Virtual Network Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "New Virtual Network Required"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Network Name")).toEqual(newNetworkName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Address Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Address Prefix"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Name")).toEqual(newSubnetName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Subnet Prefix"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Interface Name")).toEqual(newNetworkInterfaceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Required"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Name")).toEqual(newPublicIpName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Ip Address Sku"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Type"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("NIC Network Security Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "NIC Network Security Group"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Inbound Ports")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Inbound Ports"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use Load Balancing")).toEqual(jsonUtil.getValue(azureLinuxObj, "Use Load Balancing"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(azureLinuxObj, "System Assigned Managed Identity"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "Boot Diagnostics"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "OS Guest Diagnostics"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(azureLinuxObj, "Enable Auto Shutdown"));

				// Addon Services Values table validations
				expect(snowPage.getTextReqItemAddOnValuesBasedOnName("Management level")).toEqual(snowInstanceTemplate.snowAzureAddOnManagementLevelValue);
				expect(snowPage.getTextReqItemAddOnValuesBasedOnName("Management level Summary")).toEqual(snowInstanceTemplate.snowAzureAddOnManagementLevelSummaryValue);
				expect(snowPage.getTextReqItemAddOnValuesBasedOnName("Plan level")).toEqual(snowInstanceTemplate.snowAzureAddOnPlanLevelValue);
				expect(snowPage.getTextReqItemAddOnValuesBasedOnName("Plan level Summary")).toEqual(snowInstanceTemplate.snowAzureAddOnPlanLevelSummaryValue);

				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem2Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem3Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem4Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem5Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem6Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNIAzure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem2Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVNAzure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem3Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNSGAzure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem4Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSBA0AzureDel);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem5Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalPublicIPAzureDel);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem6Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalHDDAzureDel);

				// Get Addon service name from table caption
				snowPage.getAddOnServiceNameFromRITM().then(function(addOnServiceName){
					// Validate BOM values for Addon service
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(addOnServiceName, snowInstanceTemplate.snowAzureAddOnItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(addOnServiceName, snowInstanceTemplate.snowAzureAddOnItem2Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(addOnServiceName, snowInstanceTemplate.snowAzureAddOnItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAzureIMI1Del);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(addOnServiceName, snowInstanceTemplate.snowAzureAddOnItem2Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAzureIMI2Del);
				});

				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				if (isDummyAdapterDisabled == "true") {
					expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
					expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				}
				snowPage.clickUpdateButton();

				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				if (isDummyAdapterDisabled == "true") {
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				snowPage.clickBackButton();

				//Standard change
				snowPage.openRelatedChangeRequest();

				//Order Completion in SNOW
				snowPage.checkIfProvisioningTaskClosed();

				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(azureLinuxObj.completedState);

				//Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
				snowPage.clickUpdateButton();

				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
			});
		});
	}
});



