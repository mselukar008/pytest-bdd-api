"use strict";
var Orders = require('../../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../../helpers/util.js'),
    jsonUtil = require('../../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../../testData/appUrls.json'),
    imiUtil = require('../../../../../helpers/imiApiUtil.js'),
    imiConfigTemplate = require('../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    imiManageServiceTemplate = require('../../../../../testData/OrderIntegration/Imi/manageService.json'),
    redisInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSElasticacheRedisInstance.json');

describe('IMI - Elasticache Redis', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, redisName, RedisInsObject, totalCostWithAddOnWithoutCurrencyType, inventoryPage;
    var modifiedParamMap = {};
    var orderObject = {};
    var messageStrings = {
        providerName: 'Amazon',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        instanceName: redisInstanceTemplate.instanceName,
        componentType: redisInstanceTemplate.componentType,
        serviceId: redisInstanceTemplate.serviceId,
        imiOrderSubmitted: "Configure IMI Managed Service"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
        totalCostWithAddOnWithoutCurrencyType = parseFloat((redisInstanceTemplate.TotalCostWithAddOn).replace("USD ", ""));
        totalCostWithAddOnWithoutCurrencyType = totalCostWithAddOnWithoutCurrencyType.toFixed(2);
    });

    it('IMI:AWS Elasticache Redis - Verify E2E flow for Elasticache Redis with IMI Add On', function () {

        var serviceDetailsMap = {};

        serviceName = "aws-imi-ElasticacheRedis-" + util.getRandomString(5);
        var addOnName = "ElasticacheRedis-adOn-" + util.getRandomString(5);
        redisName = "Redis" + util.getRandomString(5);
        redisName = redisName.toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": redisName, "Add-On Name": addOnName };

        RedisInsObject = JSON.parse(JSON.stringify(redisInstanceTemplate));
        orderObject.servicename = serviceName;
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(redisInstanceTemplate.provider);
        catalogPage.clickProviderOrCategoryCheckbox(redisInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(redisInstanceTemplate.bluePrintName);

        //Update Elasticache Redis template with IMI template
        delete redisInstanceTemplate["Order Parameters"]["Configure Add-ons"];
        redisInstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
        redisInstanceTemplate["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
        redisInstanceTemplate["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
        redisInstanceTemplate["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(redisInstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            //Restore template with default data	
            redisInstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiManageServiceTemplate["Configure Add-ons"];
            delete redisInstanceTemplate["Order Parameters"]["IMI Main Parameters"];
            delete redisInstanceTemplate["Order Parameters"]["Configure manage service"];
            delete redisInstanceTemplate["Order Parameters"]["Review IMI Config"];
            util.waitForAngular();
            //Validate IMI configuration on Review Order page
            expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(placeOrderPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(placeOrderPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Provider Account", 1)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Provider Account IMI"));

            //Validate Review Order page with all Service Configuration
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(redisInstanceTemplate.TotalCostWithAddOn);

            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Cluster Mode Enabled"]).toEqual(requiredReturnMap["Expected"]["Cluster Mode Enabled"]);
            expect(requiredReturnMap["Actual"]["Engine Version Compatibility"]).toEqual(requiredReturnMap["Expected"]["Engine Version Compatibility"]);
            expect(requiredReturnMap["Actual"]["Port"]).toEqual(requiredReturnMap["Expected"]["Port"]);
            expect(requiredReturnMap["Actual"]["Parameter Group"]).toEqual(requiredReturnMap["Expected"]["Parameter Group"]);
            expect(requiredReturnMap["Actual"]["Node Type"]).toEqual(requiredReturnMap["Expected"]["Node Type"]);
            expect(requiredReturnMap["Actual"]["Number Of Replicas"]).toEqual(requiredReturnMap["Expected"]["Number Of Replicas"]);
            expect(requiredReturnMap["Actual"]["Subnet Group"]).toEqual(requiredReturnMap["Expected"]["Subnet Group"]);
            expect(requiredReturnMap["Actual"]["Preferred Availability Zone"]).toEqual(requiredReturnMap["Expected"]["Preferred Availability Zone"]);
            expect(requiredReturnMap["Actual"]["VPC"]).toEqual(requiredReturnMap["Expected"]["VPC"]);
            expect(requiredReturnMap["Actual"]["Security Groups"]).toEqual(requiredReturnMap["Expected"]["Security Groups"]);
            expect(requiredReturnMap["Actual"]["Encryption At Rest"]).toEqual(requiredReturnMap["Expected"]["Encryption At Rest"]);
            expect(requiredReturnMap["Actual"]["Encryption In Transit"]).toEqual(requiredReturnMap["Expected"]["Encryption In Transit"]);
            expect(requiredReturnMap["Actual"]["Maintenance Window"]).toEqual(requiredReturnMap["Expected"]["Maintenance Window"]);
            expect(requiredReturnMap["Actual"]["Topic For SNS Notification"]).toEqual(requiredReturnMap["Expected"]["Topic For SNS Notification"]);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate Add on on orders page
            expect(ordersPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
            expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            util.waitForAngular();

            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(RedisInsObject, "AWS Region"));
            expect(ordersPage.getTextBasedOnExactLabelName("Name")).toEqual(redisName);
            expect(ordersPage.getTextBasedOnLabelName("Cluster Mode Enabled")).toEqual(jsonUtil.getValue(RedisInsObject, "Cluster Mode Enabled"));
            expect(ordersPage.getTextBasedOnLabelName("Engine Version Compatibility")).toEqual(jsonUtil.getValue(RedisInsObject, "Engine Version Compatibility"));
            expect(ordersPage.getTextBasedOnLabelName("Port")).toEqual(jsonUtil.getValue(RedisInsObject, "Port"));
            expect(ordersPage.getTextBasedOnLabelName("Parameter Group")).toEqual(jsonUtil.getValue(RedisInsObject, "Parameter Group"));
            expect(ordersPage.getTextBasedOnLabelName("Node Type")).toEqual(jsonUtil.getValue(RedisInsObject, "Node Type"));
            expect(ordersPage.getTextBasedOnLabelName("Number Of Replicas")).toEqual(jsonUtil.getValue(RedisInsObject, "Number Of Replicas"));
            expect(ordersPage.getTextBasedOnLabelName("Subnet Group")).toEqual(jsonUtil.getValue(RedisInsObject, "Subnet Group"));
            expect(ordersPage.getTextBasedOnLabelName("Preferred Availability Zone")).toEqual(jsonUtil.getValue(RedisInsObject, "Preferred Availability Zone"));
            expect(ordersPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(RedisInsObject, "VPC"));
            expect(ordersPage.getTextBasedOnLabelName("Security Groups")).toEqual(jsonUtil.getValue(RedisInsObject, "Security Groups"));
            expect(ordersPage.getTextBasedOnLabelName("Encryption At Rest")).toEqual(jsonUtil.getValue(RedisInsObject, "Encryption At Rest"));
            expect(ordersPage.getTextBasedOnLabelName("Encryption In Transit")).toEqual(jsonUtil.getValue(RedisInsObject, "Encryption In Transit"));
            expect(ordersPage.getTextBasedOnLabelName("Maintenance Window")).toEqual(jsonUtil.getValue(RedisInsObject, "Maintenance Window"));
            expect(ordersPage.getTextBasedOnLabelName("Topic For SNS Notification")).toEqual(jsonUtil.getValue(RedisInsObject, "Topic For SNS Notification"));

            //Validate Add On details
            ordersPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 2)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate estimated cost
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            //expect((ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toFixed(2)).toBe((redisInstanceTemplate.TotalCostWithAddOn).toFixed(2));
            ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails().then(function (totalCost) {
                totalCost = parseFloat((totalCost).replace("USD ", ""));
                totalCost = totalCost.toFixed(2);
                expect(totalCost).toBe(totalCostWithAddOnWithoutCurrencyType);
            });
            //Validate BOM table on order details
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Cache Instance": "50.592", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                //expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(redisInstanceTemplate.EstimatedPriceWithAddOn);
            }

            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            //Validate Add-On tag
            expect(ordersHistoryPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate Add On Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickExpandArrowForServiceAddOn();
            ordersHistoryPage.getAddOnDetails().then(function (addOnDetails) {
                expect(addOnDetails[1]).toContain(addOnName);
                expect(addOnDetails[3]).toContain(imiConfigTemplate.TotalCost);
                expect(addOnDetails[4]).toContain("Completed");
            })
            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(RedisInsObject, "AWS Region"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Name")).toEqual(redisName);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Cluster Mode Enabled")).toEqual(jsonUtil.getValue(RedisInsObject, "Cluster Mode Enabled"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Engine Version Compatibility")).toEqual(jsonUtil.getValue(RedisInsObject, "Engine Version Compatibility"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Port")).toEqual(jsonUtil.getValue(RedisInsObject, "Port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Parameter Group")).toEqual(jsonUtil.getValue(RedisInsObject, "Parameter Group"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Node Type")).toEqual(jsonUtil.getValue(RedisInsObject, "Node Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Number Of Replicas")).toEqual(jsonUtil.getValue(RedisInsObject, "Number Of Replicas"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Subnet Group")).toEqual(jsonUtil.getValue(RedisInsObject, "Subnet Group"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Preferred Availability Zone")).toEqual(jsonUtil.getValue(RedisInsObject, "Preferred Availability Zone"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(RedisInsObject, "VPC"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Security Groups")).toEqual(jsonUtil.getValue(RedisInsObject, "Security Groups"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Encryption At Rest")).toEqual(jsonUtil.getValue(RedisInsObject, "Encryption At Rest"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Encryption In Transit")).toEqual(jsonUtil.getValue(RedisInsObject, "Encryption In Transit"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Maintenance Window")).toEqual(jsonUtil.getValue(RedisInsObject, "Maintenance Window"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Topic For SNS Notification")).toEqual(jsonUtil.getValue(RedisInsObject, "Topic For SNS Notification"));
            //Validate Add-On Details
            ordersHistoryPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 2)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 4)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            //expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(redisInstanceTemplate.TotalCostWithAddOn);
            ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab().then(function (totalCost) {
                totalCost = parseFloat((totalCost).replace("USD ", ""));
                totalCost = totalCost.toFixed(2);
                expect(totalCost).toBe(totalCostWithAddOnWithoutCurrencyType);
            });
            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Cache Instance": "50.592", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            //expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(redisInstanceTemplate.TotalCostWithAddOn);
            ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab().then(function (totalCost) {
                totalCost = parseFloat((totalCost).replace("USD ", ""));
                totalCost = totalCost.toFixed(2);
                expect(totalCost).toBe(totalCostWithAddOnWithoutCurrencyType);
            });
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Verify Output parameter in Inventory
            expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            inventoryPage.clickViewAddOnDetails(orderObject);
            //Verify Add On details in Inventory
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Provider Name", 3)).toBe("IMI");
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Instance Status", 2)).toBe("Active");
            expect(inventoryPage.getTextImiMangmntLevl()).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            //expect(inventoryPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(inventoryPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //verify bom for Add On
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(imiConfigTemplate.TotalCost);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Validate IMI tags
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                var tagList = tags.split(",");
                if (isDummyAdapterDisabled == "true") {
                    expect(tagList[0]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[1]).toContain(imiConfigTemplate.ServiceTierName);
                } else {
                    expect(tagList[2]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[0]).toContain(imiConfigTemplate.ServiceTierName);
                }

                orderFlowUtil.closeHorizontalSliderIfPresent();
            });
        });
    });

    if (isDummyAdapterDisabled == "true") {
        it('IMI-AWS-Elasticache Redis-Configure IMI Manage service having AddOn', function () {

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                    inventoryPage.clickConfigureImiService();
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });

            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost    
                expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                ordersPage.open();
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 1)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                orderFlowUtil.closeHorizontalSliderIfPresent();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);

                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);

                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                //ordersHistoryPage.clickAddOnDetails();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);

                //Validate Updated BOM on Inventory(AddOn+Manage Service)
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickOnInstanceTableActionIcon();
                inventoryPage.clickViewService();
                inventoryPage.clickBillOfMaterialsTabOrderDetails();
                //verify estimated cost for Add On
                inventoryPage.getTextEstimatedCost().then(function (actPrice) {
                    var priceArr = util.roundOffTotalCost(actPrice, redisInstanceTemplate.TotalCostWithAddOn);
                    expect(priceArr[0]).toEqual(priceArr[1]);
                });

                inventoryPage.clickMoreLinkinBom();
                //Validate BOM table for Add on
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                inventoryPage.clickViewServiceClosebutton();
            });
        });
    }
    it('IMI-AWS-Elasticache Redis- Delete service having addon from Inventory', function () {
        //Delete Service flow
        orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
        //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
        orderFlowUtil.approveDeletedOrder(orderObject);
        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
    });
    if (isDummyAdapterDisabled == "true") {
        it('IMI-AWS-Elasticache Redis- Configure Manage service from Inventory', function () {

            serviceName = "aws-auto-ElasticacheRedis-" + util.getRandomString(5);
            redisName = "Redis" + util.getRandomString(5);
            redisName = redisName.toLowerCase();
            modifiedParamMap = { "Service Instance Name": serviceName, "Name": redisName };
            var RedisInsObject = JSON.parse(JSON.stringify(redisInstanceTemplate));
            orderObject.servicename = serviceName;
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(redisInstanceTemplate.provider);
            catalogPage.clickProviderOrCategoryCheckbox(redisInstanceTemplate.Category);
            catalogPage.clickConfigureButtonBasedOnName(redisInstanceTemplate.bluePrintName);
            //Fill Order Details
            orderFlowUtil.fillOrderDetails(redisInstanceTemplate, modifiedParamMap);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(redisInstanceTemplate.EstimatedPrice);

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                    inventoryPage.clickConfigureImiService();
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });

            // Delete parameters
            //         delete imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
            //         delete imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
            //         delete imiConfigTemplate["Order Parameters"]["Review IMI Config"];
            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost    
                expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                ordersPage.open();
                //expect(util.getCurrentURL()).toMatch('orders');
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                //ordersHistoryPage.clickAddOnDetails();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 1)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                orderFlowUtil.closeHorizontalSliderIfPresent();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);

                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);

                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                //ordersHistoryPage.clickAddOnDetails();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);

                //Delete Service flow
                orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            });
        });
    }
});
