"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
    CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
    util = require('../../../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
    jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
    appUrls = require('../../../../../../testData/appUrls.json'),
    snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
    SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
    url = browser.params.url,
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    awsEC2template = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSEC2InstanceSnowV3SpecstoSkipIMI.json'),
    imiConfigTemplate = require('../../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    imiManageServiceTemplate = require('../../../../../../testData/OrderIntegration/Imi/manageService.json'),
    PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
    policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
    addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
    snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');

describe('QS: AWS-IMI Edit: E2E cases for Manual Technical, Auto Financial and External Legal approval with Standard change', function () {
    var ordersPage, catalogPage, placeOrderPage, policyPage, snowPage, provOrder, inventoryPage, awsEC2obj, groupName, cartListPage;
    var modifiedParamMap = {};
    var modifiedParamMap1 = {};
    var modifiedParamMapPolicy = {};
    var modifiedParamMapAddRule = {};
    var serviceName = "SNOWQSAwsImiauto" + util.getRandomString(5);
    var policyName = "SNOWQSautoAWSPolicy" + util.getRandomString(5);
    var policyRuleName = "SNOWQSautoAWSPolicyRule" + util.getRandomString(5);
    var consumeLaunchpadUrl = url + '/launchpad';

    beforeAll(function () {
        snowPage = new SNOWPage();
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        policyPage = new PolicyPage();
        cartListPage = new CartListPage();
        browser.driver.manage().window().maximize();
        
        //Delete policy if exists
		policyPage.open();
		util.waitForAngular();
		policyPage.deletePoliciesIfExist();
    });

    beforeEach(function () {
        groupName = "att-group-" + util.getRandomString(5);
        awsEC2obj = JSON.parse(JSON.stringify(awsEC2template));
        modifiedParamMapPolicy = { "policy Name": policyName, "Values": "Auto-TEAM1 (my_org)" };
        modifiedParamMapAddRule = {
            "Add Rule Name": policyRuleName, "Order Type": ["New", "Edited", "Deleted", "ServiceAction"], "Provider": ["Amazon", "IMI"], "Total Monthly Cost": "", "Monthly Cost": "", "Budget Is": "",
            "Technical": "Manual Approval", "Legal": "External Approval"
        };
        modifiedParamMap = { "Service Instance Name": serviceName, "Team": "Auto-TEAM1", "Environment": "QA", "Application": "", "Provider Account": "AWS-SNOW / AWS-SNOW", "Group Name": groupName };
    });

    afterAll(function () {
        //Delete Approval Policy
        browser.get(consumeLaunchpadUrl);
        cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
        policyPage.open();
        util.waitForAngular();
        policyPage.searchPolicyInPolicyTextbox(policyName);
        policyPage.clickPolicyDetailIcon();
        policyPage.clickPolicyViewDetailButton();
        policyPage.clickRadioButtonRetiredOption();
        policyPage.clickUpdatePolicyBtn();
        expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg + " " + policyName + " successfully");
        var policyStatusInPolicy = policyPage.getTextPolicyStatusInPolicyTable(policyName);
        expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
        policyPage.searchPolicyInPolicyTextbox(policyName);
        policyPage.clickPolicyDetailIcon();
        policyPage.clickButtonDeletePolicyText();
        policyPage.clickDeleteConfirmationPopUpPolicyBtn();
        util.waitForAngular();
        policyPage.searchPolicyInPolicyTextbox(policyName);
        expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

        browser.get(consumeLaunchpadUrl);
        cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
    });

    it('Set Change Request type to Standard in SNOW', function () {
        expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
    });

    it('Create Approval Policy for AWS with Manual Technical, Auto Financial and External Legal approval and Standard change', function () {
        policyPage.open();
        policyPage.clickAddNewPolicyBtn();
        policyPage.selectStartDate();
        policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
        policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
        policyPage.selectExternalApprovalDropdownSNOW();
        policyPage.clickApplyRulePolicyBtn();
        var policyRuleNameTextInApprovalPolicy = policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
        expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
        policyPage.clickCreatePolicyButton();
        expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
        policyPage.clickNotificationCloseButton();
        var policyNameInPolicyTable = policyPage.getTextPolicyNameInPolicyTable(policyName);
        expect(policyNameInPolicyTable).toEqual(policyName);
    });

    if (isProvisioningRequired == "true") {
        it('AWS EC2 ---- Verify Provision functionality with Manual Technical, Auto Financial and External Legal approval and Standard change', function () {
            //Place Order for Provision in Marketplace
            var orderObject = {};
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(awsEC2template.provider);
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(awsEC2template.Category);
            catalogPage.clickConfigureButtonBasedOnName(awsEC2template.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetails(awsEC2template, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            var orderObject = { "orderNumber": provOrder };
            orderFlowUtil.waitForOrderStatusChange(orderObject, awsEC2template.appInProgressState);
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);

            //Approve Order in Marketplace
            orderFlowUtil.approveOrderButtonSNOW(orderObject);
            ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
            ordersPage.clickApproveButtonOrderApprovalModal();
            ordersPage.clickCancelButtonOrderApprovalModal();
            orderFlowUtil.waitForOrderStatusChange(orderObject, awsEC2template.appInProgressState);
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);

            //Validations on SNOW Request page after approval in Marketplace
            snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
            expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
            expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
            expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
            expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
            expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
            expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

            //Approve Order in SNOW
            snowPage.approveTheServiceNowRequestFromSnowPortal();

            //Validations on SNOW Request page after approval in SNOW
            snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
            expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
            if (isDummyAdapterDisabled == "true") {
                expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
            }
            expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
            expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);
            expect(snowPage.getOrderNumberText()).toBe(provOrder);

            //Validations on SNOW Requested Item page
            snowPage.clickRequestedItemLink();
            expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
            if (isDummyAdapterDisabled == "true") {
                expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
                expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
            }
            expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
            expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
            expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
            expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
            expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
            expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
            var serName = snowPage.getTextReqItemVariableServiceName();
            serName.then(function (sName) {
                expect(sName).toContain(serviceName);
                // Broker Config values table validations
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2obj, "Resource Name"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Type"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj, "Search By"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj, "Availability Zone"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj, "VPC Creation Mode"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("Subnet")).toEqual("subnet-a68b538d");
                expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("VPC")).toEqual("vpc-8eadd1eb");
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2obj, "Shutdown Behavior"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2obj, "T2/T3 Unlimited"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2obj, "User Data"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));
                
                expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAwsSrvcItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
                expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAwsSrvcItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalCIt2SmallAws);

                //Validations on SNOW Configuration Item- Service Instance CIs page
                snowPage.switchToDefaultContent();
                snowPage.switchToParentFrame();
                snowPage.openConfItemServiceInstanceCIs();
                expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
                if (isDummyAdapterDisabled == "true") {
                    expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
                    expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
                }
                snowPage.clickUpdateButton();

                //Validation on Catalog Task page
                snowPage.clickCatalogTaskLink();
                if (isDummyAdapterDisabled == "true") {
                    expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
                }
                snowPage.clickBackButton();

                //Standard change
                snowPage.openRelatedChangeRequest();

                //Order Completion in SNOW
                snowPage.checkIfProvisioningTaskClosed();

                //Validation in Marketplace
                browser.get(consumeLaunchpadUrl);
                cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);

                //Validations on SNOW Request page after Completion
                snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
                expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
                expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

                //Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
                snowPage.clickRequestedItemLink();
                expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
                snowPage.openConfItemServiceInstanceCIs();
                expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
                expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
                snowPage.clickUpdateButton();

                //Validation on Catalog Task page after completion
                snowPage.clickCatalogTaskLink();
                expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
                snowPage.clickUpdateButton();
            });
        });

        it("AWS EC2: Configure IMI from Ordered Services with Manual Technical, Auto Financial and External Legal approval and Standard change", function(){
            var orderObject = {};
            orderObject.servicename = serviceName;
            //Validation in Marketplace
            browser.get(consumeLaunchpadUrl);
            //Configure IMI to above provisioned service
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(awsEC2template.componentType).then(function () {
                    inventoryPage.clickConfigureImiServicefirst();
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });
            modifiedParamMap1 = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap1).then(function () {
                //Validate Estimated Cost
                expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.MonthlyCost);
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": awsEC2template.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": awsEC2template.MonthlyCost }
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                
                //Submit order
                placeOrderPage.submitOrder();
                inventoryPage.fetchD2opsOrderDetails();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.customOpsOrderSubmittedMsg);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.waitForOrderStatusChange(orderObject, awsEC2template.appInProgressState);

                //Approve Order in Marketplace
                orderFlowUtil.approveOrderButtonSNOW(orderObject);
                ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
                ordersPage.clickApproveButtonOrderApprovalModal();
                ordersPage.clickCancelButtonOrderApprovalModal();
                orderFlowUtil.waitForOrderStatusChange(orderObject, awsEC2template.appInProgressState);

                //Validations on SNOW Request page after approval in Marketplace
                snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObject.orderNumber);
                expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
                expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
                expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
                expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
                expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

                //Approve Order in SNOW
                snowPage.approveTheServiceNowRequestFromSnowPortal();

                //Validations on SNOW Request page after approval in SNOW
                snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObject.orderNumber);
                expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
                if (isDummyAdapterDisabled == "true") {
                    expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                    expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                    expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                    expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                    expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
                }
                expect(snowPage.getTextShortDescription()).toBe(awsEC2template.imiManagedServiceName);
                expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
                expect(snowPage.getOrderNumberText()).toBe(orderObject.orderNumber);

                //Validations on SNOW Requested Item page
                snowPage.clickRequestedItemLink();
                expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
                if (isDummyAdapterDisabled == "true") {
                    expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
                    expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
                }
                expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
                expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.imiManagedServiceName);
                expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescIMI);
                expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
                expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderIMI);
                expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryCompIMI);
                var serName = snowPage.getTextReqItemVariableServiceName();
                serName.then(function (sName) {
                    expect(sName).toContain(serviceName);
                    // Broker Config values table validations
                    expect(snowPage.getTextReqItemConfigValuesBasedOnName(imiConfigTemplate.managementLevelKey)).toEqual(snowInstanceTemplate.snowAzureAddOnManagementLevelValue);
                    expect(snowPage.getTextReqItemConfigValuesBasedOnName(imiConfigTemplate.managementLevelSummaryKey)).toEqual(snowInstanceTemplate.snowAzureAddOnManagementLevelSummaryValue);
                    expect(snowPage.getTextReqItemConfigValuesBasedOnName(imiConfigTemplate.planLevelKey)).toEqual(snowInstanceTemplate.snowAzureAddOnPlanLevelValue);
                    expect(snowPage.getTextReqItemConfigValuesBasedOnName(imiConfigTemplate.planLevelSummaryKey)).toContain(snowInstanceTemplate.snowAzureAddOnPlanLevelSummaryValue);
                    expect(snowPage.getTextReqItemConfigValuesBasedOnName(imiConfigTemplate.resourceNameKey)).toEqual(awsEC2template.resourceNameValue);
                    expect(snowPage.getTextReqItemConfigValuesBasedOnName(imiConfigTemplate.operationNameKey)).toContain(awsEC2template.operationNameValue);
                    
                    // Validate BOM values for Addon service
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAwsAddOnItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAwsAddOnItem2Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAwsAddOnItem1Value)).toBe(snowInstanceTemplate.snowAwsAddOnItem1TotalMonthlyValue);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAwsAddOnItem2Value)).toBe(snowInstanceTemplate.snowAwsAddOnItem2TotalMonthlyValue);

                    //Validations on SNOW Configuration Item- Service Instance CIs page
                    snowPage.switchToDefaultContent();
                    snowPage.switchToParentFrame();
                    snowPage.openConfItemServiceInstanceCIs();
                    expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
                    if (isDummyAdapterDisabled == "true") {
                        expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
                        expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
                    }
                    snowPage.clickUpdateButton();

                    //Validation on Catalog Task page
                    snowPage.clickCatalogTaskLink();
                    if (isDummyAdapterDisabled == "true") {
                        expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
                    }
                    snowPage.clickBackButton();

                    //Standard change
                    snowPage.openRelatedChangeRequest();

                    //Order Completion in SNOW
                    snowPage.checkIfProvisioningTaskClosed();

                    //Validation in Marketplace
                    browser.get(consumeLaunchpadUrl);
                    cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
                    expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);

                    //Validations on SNOW Request page after Completion
                    snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObject.orderNumber);
                    expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                    expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                    expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
                    expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                    expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

                    //Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
                    snowPage.clickRequestedItemLink();
                    expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
                    snowPage.openConfItemServiceInstanceCIs();
                    expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
                    expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
                    snowPage.clickUpdateButton();

                    //Validation on Catalog Task page after completion
                    snowPage.clickCatalogTaskLink();
                    expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
                    snowPage.clickUpdateButton();
                });
            });
        });

        it("AWS EC2: Delete the service with Manual Technical, Auto Financial and External Legal approval and Standard change", function(){
            var orderObject = {};
            orderObject.servicename = serviceName;
            //Validation in Marketplace
            browser.get(consumeLaunchpadUrl);
            orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			orderObject.orderNumber = inventoryPage.getDeleteOrderNumber();
            orderFlowUtil.waitForOrderStatusChange(orderObject, awsEC2template.appInProgressState);

            //Approve Order in Marketplace
            orderFlowUtil.approveOrderButtonSNOW(orderObject);
            ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
            ordersPage.clickApproveButtonOrderApprovalModal();
            ordersPage.clickCancelButtonOrderApprovalModal();
            orderFlowUtil.waitForOrderStatusChange(orderObject, awsEC2template.appInProgressState);

            //Validations on SNOW Request page after approval in Marketplace
            snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObject.orderNumber);
            expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
            expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
            expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
            expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
            expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
            expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

            //Approve Order in SNOW
            snowPage.approveTheServiceNowRequestFromSnowPortal();

            //Validations on SNOW Request page after approval in SNOW
            snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObject.orderNumber);
            expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
            if (isDummyAdapterDisabled == "true") {
                expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
            }
            expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
            expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);
            expect(snowPage.getOrderNumberText()).toBe(orderObject.orderNumber);

            //Validations on SNOW Requested Item page
            snowPage.clickRequestedItemLink();
            expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
            if (isDummyAdapterDisabled == "true") {
                expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
                expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
            }
            expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
            expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
            expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
            expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
            expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
            expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
            var serName = snowPage.getTextReqItemVariableServiceName();
            serName.then(function (sName) {
                expect(sName).toContain(serviceName);
                // Broker Config values table validations
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2obj, "Resource Name"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Type"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj, "Search By"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj, "Availability Zone"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj, "VPC Creation Mode"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("Subnet")).toEqual("subnet-a68b538d");
                expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("VPC")).toEqual("vpc-8eadd1eb");
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2obj, "Shutdown Behavior"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2obj, "T2/T3 Unlimited"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2obj, "User Data"));
                expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));
                
                expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAwsSrvcItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
                expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAwsSrvcItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWSDel);

                //Validations on SNOW Configuration Item- Service Instance CIs page
                snowPage.switchToDefaultContent();
                snowPage.switchToParentFrame();
                snowPage.openConfItemServiceInstanceCIs();
                expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
                if (isDummyAdapterDisabled == "true") {
                    expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
                    expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
                }
                snowPage.clickUpdateButton();

                //Validation on Catalog Task page
                snowPage.clickCatalogTaskLink();
                if (isDummyAdapterDisabled == "true") {
                    expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
                }
                snowPage.clickBackButton();

                //Standard change
                snowPage.openRelatedChangeRequest();

                //Order Completion in SNOW
                snowPage.checkIfProvisioningTaskClosed();

                //Validation in Marketplace
                browser.get(consumeLaunchpadUrl);
                cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);

                //Validations on SNOW Request page after Completion
                snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObject.orderNumber);
                expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
                expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

                //Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
                snowPage.clickRequestedItemLink();
                expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
                snowPage.openConfItemServiceInstanceCIs();
                expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
                expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
                snowPage.clickUpdateButton();

                //Validation on Catalog Task page after completion
                snowPage.clickCatalogTaskLink();
                expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
                snowPage.clickUpdateButton();
            });
        });
    }
});
