/*
Spec_Name: Azure Windows VM  .spec.js 
Description: This spec will cover IMI provisioning for Azure Windows VM service. 
Author: Ravi Jaisinghani
*/

"use strict";


var Orders = require('../../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../../../pageObjects/placeOrder.pageObject.js'),
        OrderHistoryPage = require('../../../../pageObjects/ordersHistory.pageObject.js'),
        InventoryPage = require('../../../../pageObjects/inventory.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../../../testData/appUrls.json'),
        imiUtil = require('../../../../../helpers/imiApiUtil.js'),
        imiConfigTemplate = require('../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
        util = require('../../../../../helpers/util.js'),
        jsonUtil = require('../../../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../../../helpers/orderFlowUtil.js'),
        Template = require('../../../../../testData/OrderIntegration/Imi/azure/newWindowsVM.json');

describe('Azure: Test cases for Azure Windows VM', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, ordersHistoryPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Compute', orderSubmittedConfirmationMessage: 'Order Submitted !', imiOrderSubmitted: "Configure IMI Managed Service" };
        var servicename = "AutoWindowsVm" + util.getRandomString(5);
        var newResourceGroupName, newVmName, newNetworkName, newSubnetName, newNetworkInterfaceName, newnetworkSecurityGroupName, newPublicIpName, newAvailabilitySetName, newStorageAccountName;
        var addOnName = "av-adOn-" + util.getRandomString(5);
        var SOIComponents;
        var serviceNameList = [];
        //Create Replica of Template for IMI flow 2,3
        var TemplateConstant = JSON.parse(JSON.stringify(Template));
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName, "Diagnostics Storage Account Name": newStorageAccountName };

        //Pricing Label Variables
        var serviceCostLabel = Template.ServiceCostLabel;
        var managedCloudLitePricingLabel = imiConfigTemplate.ManagedCloudLitePricingLabel;
        var managedCloudEnterprisePricingLabel = imiConfigTemplate.ManagedCloudEnterprisePricingLabel
        var monthlyBillingPricingLabel = imiConfigTemplate.MonthlyBillingPricingLabel;
        var hourlyBillingPricingLabel = imiConfigTemplate.HourlyBillingPricingLabel;

        //Update template with IMI template
        delete Template["Order Parameters"]["Configure Add-ons"];
        Template["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
        Template["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
        Template["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
        Template["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];
        Template["TotalCost"] = imiConfigTemplate["TotalCost"];


        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                ordersHistoryPage = new OrderHistoryPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
                newResourceGroupName = "gslautotc_azure_winvmRG" + util.getRandomString(4);
                newVmName = "auto-VM" + util.getRandomString(4);
                newNetworkName = "auto-VN101" + util.getRandomString(4);
                newSubnetName = "auto-SN101" + util.getRandomString(4);
                newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
                newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
                newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
                newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
                newStorageAccountName = "autods101" + util.getRandomString(4);
                newStorageAccountName = newStorageAccountName.toLocaleLowerCase();
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName, "Diagnostics Storage Account Name": newStorageAccountName, "Add-On Name": addOnName };
                SOIComponents = [newVmName];


        });
        afterAll(function () {

                //Delete The created services
                for (var i = 0; i < serviceNameList.length; i++) {
                        var returnObj = {};
                        returnObj.servicename = serviceNameList[i];
                        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                        orderFlowUtil.approveDeletedOrder(returnObj);
                        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
                }
        });
        //E2E Application Security Group order Submit, Approve, Delete Service with New Resource Group.

        // it("IMI Provisioning - Azure Windows VM", async function () {
        //         var serviceDefinationMap = { "name": Template.bluePrintName, "description": Template.descriptiveText, "resourceType": Template.resourceID, "shortDesc": Template.descriptiveText };
        //         //Update service defination
        //         await imiUtil.setServiceDefination("azure", serviceDefinationMap).then(async function (apiResponse) {
        //                 logger.info("Service Defination for Azure Windows VM succesfully updated");
        //                 await imiUtil.getRateCard("azure", Template.resourceID).then(async function (rateCard) {
        //                         logger.info("Rate Card for Azure Windows VM succesfully retrieved");
        //                         await imiUtil.updatePricingValue("azure", Template.resourceID, rateCard).then(async function (apiResponse) {
        //                                 logger.info("Pricing Values succesfully updated.");
        //                         });
        //                 });
        //         });
        // });


        it('Azure Windows VM group IMI-Flow-1:- Verify IMI provisioning flow for Azure Windows VM', function () {

                var serviceDetailsMap = {};
                var returnObj = {};
                var orderObject = JSON.parse(JSON.stringify(Template));
                var EC2INSObject = JSON.parse(JSON.stringify(Template));
                orderObject.servicename = servicename;
                returnObj.servicename = servicename;
                serviceNameList.push(servicename);
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(Template.Category);
                catalogPage.clickConfigureButtonBasedOnName(Template.bluePrintName);

                orderFlowUtil.fillOrderDetails(Template, modifiedParamMap).then(function (requiredReturnMap) {
                        serviceDetailsMap = requiredReturnMap;
                        util.waitForAngular();
                        //Validate IMI configuration on Review Order page
                        expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
                        expect(placeOrderPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                        expect(placeOrderPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                        //expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Provider Account", 1)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Provider Account IMI"));

                        //Validate Review Order page with all Service Configuration
                        expect(placeOrderPage.getTextBasedOnLabelName(Template.NewResourceRequiredLabel + ":")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(placeOrderPage.getTextBasedOnLabelName(Template.NewResourceLabel + ":")).toEqual(newResourceGroupName);
                        expect(placeOrderPage.getTextBasedOnLabelName(Template.LocationLabel + ":")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(placeOrderPage.getTextBasedOnLabelName(Template.ServiceNameLabel + ":")).toEqual(newVmName);
                        //expect(placeOrderPage.getTextBasedOnLabelName("Application Security Group Location:")).toEqual(jsonUtil.getValue(orderObject, "Application Security Group Location"));

                        //Submit Order
                        placeOrderPage.submitOrder();
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                        ordersPage.open();
                        expect(util.getCurrentURL()).toMatch('orders');
                        ordersPage.searchOrderById(orderObject.orderNumber);
                        expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                        //Validate Add on on orders page
                        expect(ordersPage.getTextImiAddOn()).toEqual(imiConfigTemplate.AddOnTag);
                        //Validate service parameters on Approve order page
                        ordersPage.clickFirstViewDetailsOrdersTable();
                        util.waitForAngular();
                        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
                        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider

                        ordersPage.clickServiceConfigurationsTabOrderDetails();
                        expect(ordersPage.getTextBasedOnExactLabelName(Template.NewResourceRequiredLabel)).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(ordersPage.getTextBasedOnExactLabelName(Template.NewResourceLabel)).toEqual(newResourceGroupName);
                        expect(ordersPage.getTextBasedOnExactLabelName(Template.LocationLabel)).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(ordersPage.getTextBasedOnExactLabelName(Template.ServiceNameLabel)).toEqual(newVmName);
                        // expect(ordersPage.getTextBasedOnExactLabelName("Application Security Group Location")).toEqual(jsonUtil.getValue(orderObject, "Application Security Group Location"));


                        //Validate Add On details
                        ordersPage.clickAddOnDetails();
                        expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
                        expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 2)).toEqual("IMI");
                        expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                        expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

                        //Validate estimated cost
                        ordersPage.clickBillOfMaterialsTabOrderDetails();
                        expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(Template.TotalServiceIMIcost);
                        //Validate BOM table on order details
                        ordersPage.clickMoreLinkBom();
                        var priceMap = {};
                        priceMap = { serviceCostLabel: Template.TotalCost, managedCloudLitePricingLabel: imiConfigTemplate.ManagedCloudLiteCost, monthlyBillingPricingLabel: imiConfigTemplate.MonthlyCost }
                        expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                        ordersPage.closeServiceDetailsSlider();
                        //Aprrove Order
                        if (isProvisioningRequired == "true") {
                                orderFlowUtil.approveOrder(orderObject);
                                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                        }

                        //Service details on Order History page
                        ordersHistoryPage.open();
                        ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                        //Validate Add-On tag
                        expect(ordersHistoryPage.getTextImiAddOn()).toEqual(imiConfigTemplate.AddOnTag);
                        //Validate Add On Details
                        ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
                        ordersHistoryPage.clickExpandArrowForServiceAddOn();
                        ordersHistoryPage.getAddOnDetails().then(function (addOnDetails) {
                                expect(addOnDetails[1]).toContain(addOnName);
                                expect(addOnDetails[3]).toContain(imiConfigTemplate.TotalCost);
                                expect(addOnDetails[4]).toContain("Completed");
                        })
                        //Validate Service Details
                        ordersHistoryPage.clickServiceDetailsLink();
                        util.waitForAngular();
                        expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName(Template.NewResourceRequiredLabel)).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName(Template.NewResourceLabel)).toEqual(newResourceGroupName);
                        expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName(Template.LocationLabel)).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName(Template.ServiceNameLabel)).toEqual(newVmName);
                        //expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Application Security Group Location")).toEqual(jsonUtil.getValue(orderObject, "Application Security Group Location"));

                        //Validate Add-On Details
                        ordersHistoryPage.clickAddOnDetails();
                        expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 2)).toEqual(addOnName);
                        expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 4)).toEqual("IMI");
                        expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                        expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

                        //Validate Estimated cost on order history page
                        ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                        expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(Template.TotalServiceIMIcost);

                        //Validate BOM table on order history page
                        ordersHistoryPage.clickMoreLinkBom();
                        var priceMap = {};
                        priceMap = { serviceCostLabel: Template.TotalCost, managedCloudLitePricingLabel: imiConfigTemplate.ManagedCloudLiteCost, monthlyBillingPricingLabel: imiConfigTemplate.MonthlyCost }
                        expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                        ordersHistoryPage.closeServiceDetailsSlider();
                        //Validate BOM link on order history
                        ordersHistoryPage.clickBillOfMaterials();
                        expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(Template.TotalServiceIMIcost);
                        ordersHistoryPage.clickMoreLinkBom();
                        expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                        ordersHistoryPage.closeServiceDetailsSlider();
                        //Verify Output parameter in Inventory
                        expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
                        // inventoryPage.clickSliderCloseIcon();
                        inventoryPage.clickViewAddOnDetails(orderObject);
                        //Verify Add On details in Inventory
                        expect(inventoryPage.getTextBasedOnLabelNameandIndex("Provider Name", 3)).toBe("IMI");
                        expect(inventoryPage.getTextBasedOnLabelNameandIndex("Instance Status", 2)).toBe("Active");
                        expect(inventoryPage.getTextBasedOnExactLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                        expect(inventoryPage.getTextBasedOnExactLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                        //verify bom for Add On
                        inventoryPage.clickBillOfMaterialsTabOrderDetails();
                        //verify estimated cost for Add On
                        expect(inventoryPage.getTextEstimatedCost()).toEqual(imiConfigTemplate.TotalCost);
                        inventoryPage.clickMoreLinkinBom();
                        //Validate BOM table for Add on
                        priceMap = { managedCloudLitePricingLabel: imiConfigTemplate.ManagedCloudLiteCost, monthlyBillingPricingLabel: imiConfigTemplate.MonthlyCost }
                        expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                        //Validate IMI tags
                        inventoryPage.clickSliderCloseIcon();
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.open();
                                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                                inventoryPage.clickExpandFirstRow();
                                inventoryPage.clickOverflowActionButtonForPowerStates();
                                inventoryPage.clickViewComponentofAWSInstance();
                                browser.sleep(2000);
                                expect(inventoryPage.getTagsOnInventory()).toContain(imiConfigTemplate.BillingPlanTag);
                                expect(inventoryPage.getTagsOnInventory()).toContain(imiConfigTemplate.ServiceTierTag);
                                inventoryPage.closeViewComponent();
                        }

                });


        });


        it('Azure Windows VM IMI-Flow-2: Configure Manage service from Inventory', function () {
                var serviceDetailsMap = {};
                servicename = "AutoWindowsVm" + util.getRandomString(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName, "Diagnostics Storage Account Name": newStorageAccountName };
                var orderObject = JSON.parse(JSON.stringify(TemplateConstant));
                orderObject.servicename = servicename;
                var returnObj = {};
                returnObj.servicename = servicename;
                serviceNameList.push(servicename);
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(Template.Category);
                catalogPage.clickConfigureButtonBasedOnName(TemplateConstant.bluePrintName);
                //Fill Order Details
                orderFlowUtil.fillOrderDetails(TemplateConstant, modifiedParamMap);
                //Submit Order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                catalogPage.open();
                orderFlowUtil.approveOrder(orderObject);
                //Validate Estimated price on approve order page
                //checkrv expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(ec2InstanceTemplate.EstimatedPrice);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');

                modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                        inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                                if (isDummyAdapterDisabled == "false") {
                                        inventoryPage.clickConfigureImiService();
                                        inventoryPage.clickOkButnInConfigrImiPopUp();
                                } else {
                                        inventoryPage.clickConfigureImiServicelast();
                                        inventoryPage.clickOkButnInConfigrImiPopUp();
                                }
                        });
                });

                // Delete parameters
                delete imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
                delete imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
                delete imiConfigTemplate["Order Parameters"]["Review IMI Config"];
                orderFlowUtil.fillOrderDetails(imiConfigTemplate, modifiedParamMap).then(function () {

                        inventoryPage.getTextUpdatedCostConfigureImiManagedService().then(function (totalCost) {
                                expect(totalCost.toString()).toEqual(imiConfigTemplate.TotalCost);
                        });
                        //Validate updated BOM table
                        var priceMap = { managedCloudLitePricingLabel: imiConfigTemplate.ManagedCloudLiteCost, monthlyBillingPricingLabel: imiConfigTemplate.MonthlyCost }
                        expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);

                        //Submit order
                        placeOrderPage.submitOrder();
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                        ordersPage.open();
                        //expect(util.getCurrentURL()).toMatch('orders');
                        ordersPage.searchOrderById(orderObject.orderNumber);
                        expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                        //Validate service details
                        ordersPage.clickFirstViewDetailsOrdersTable();
                        expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(imiConfigTemplate.ServiceTier);
                        expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(imiConfigTemplate.BillingPlan);
                        //Validate BOM on Approve order page
                        ordersPage.clickBOMTabImi();
                        expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                        ordersPage.clickMoreLinkBom();
                        var priceMap = {};
                        priceMap = { managedCloudLitePricingLabel: imiConfigTemplate.ManagedCloudLiteCost, monthlyBillingPricingLabel: imiConfigTemplate.MonthlyCost }
                        expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                        ordersPage.closeServiceDetailsSlider();
                        //Approve order 
                        orderFlowUtil.approveOrder(orderObject);
                        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                        //Validate Estimated price on approve order page
                        expect(ordersPage.getTextFirstAmountOrdersTable()).toContain(imiConfigTemplate.TotalCost);

                        //Service details on Order History page
                        ordersHistoryPage.open();
                        ordersHistoryPage.searchOrderById(orderObject.orderNumber);

                        //Validate Service Details
                        ordersHistoryPage.clickServiceDetailsLink();
                        expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Management level", 0)).toEqual(imiConfigTemplate.ServiceTier);
                        expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Plan level", 0)).toEqual(imiConfigTemplate.BillingPlan);

                        //Validate Estimated cost on order history page
                        ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                        expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                        //Validate BOM table on order history page
                        ordersHistoryPage.clickMoreLinkBom();
                        expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                        ordersHistoryPage.closeServiceDetailsSlider();
                        //Validate BOM link on order history
                        ordersHistoryPage.clickBillOfMaterials();
                        ordersHistoryPage.clickMoreLinkBom();
                        expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                        ordersHistoryPage.closeServiceDetailsSlider();
                        //Validate IMI tags
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.open();
                                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                                inventoryPage.clickExpandFirstRow();
                                inventoryPage.clickOverflowActionButtonForPowerStates();
                                inventoryPage.clickViewComponentofAWSInstance();
                                browser.sleep(2000);
                                expect(inventoryPage.getTagsOnInventory()).toContain(imiConfigTemplate.BillingPlanTag);
                                expect(inventoryPage.getTagsOnInventory()).toContain(imiConfigTemplate.ServiceTierTag);
                                inventoryPage.closeViewComponent();
                        }
                });
        });

        it('Azure Windows VM IMI-Flow-3: Configure Manage service from Inventory which is already configured while provisioning', function () {
                var serviceDetailsMap = {};
                servicename = "AutoWindowsVm" + util.getRandomString(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName, "Diagnostics Storage Account Name": newStorageAccountName, "Add-On Name": addOnName };
                var orderObject = JSON.parse(JSON.stringify(TemplateConstant));
                orderObject.servicename = servicename;
                var returnObj = {};
                returnObj.servicename = servicename;
                serviceNameList.push(servicename);
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(Template.Category);
                catalogPage.clickConfigureButtonBasedOnName(TemplateConstant.bluePrintName);
                //Fill Order Details
                orderFlowUtil.fillOrderDetails(Template, modifiedParamMap);
                //Submit Order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(orderObject);
                //Validate Estimated price on approve order page
                //checkrv expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(ec2InstanceTemplate.EstimatedPrice);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');

                modifiedParamMap = { "skipRevierOrderValidation": true, "Management level": "Managed Cloud Enterprise", "Plan level": "Hourly billing", "UpdateMainParamObject": false };
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                        inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                                if (isDummyAdapterDisabled == "false") {
                                        inventoryPage.clickConfigureImiService();
                                        inventoryPage.clickOkButnInConfigrImiPopUp();
                                } else {
                                        inventoryPage.clickConfigureImiServicelast();
                                        inventoryPage.clickOkButnInConfigrImiPopUp();
                                }
                        });
                });

                // Delete parameters
                delete imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
                delete imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
                delete imiConfigTemplate["Order Parameters"]["Review IMI Config"];
                orderFlowUtil.fillOrderDetails(imiConfigTemplate, modifiedParamMap).then(function () {
                        inventoryPage.getTextUpdatedCostConfigureImiManagedService().then(function (totalCost) {
                                expect(totalCost.toString()).toEqual(imiConfigTemplate.EnterpriseTotalCost);
                        });
                        //Validate updated BOM table
                        var priceMap = { managedCloudEnterprisePricingLabel: imiConfigTemplate.ManagedCloudEnterpriseCost, hourlyBillingPricingLabel: imiConfigTemplate.HourlyCost }
                        expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);

                        //Submit order
                        placeOrderPage.submitOrder();
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                        ordersPage.open();
                        //expect(util.getCurrentURL()).toMatch('orders');
                        ordersPage.searchOrderById(orderObject.orderNumber);
                        expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                        //Validate service details
                        ordersPage.clickFirstViewDetailsOrdersTable();
                        expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(imiConfigTemplate.ServiceTierEnterprise);
                        expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(imiConfigTemplate.BillingPlanHourly);
                        //Validate BOM on Approve order page
                        ordersPage.clickBOMTabImi();
                        expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.EnterpriseTotalCost);
                        ordersPage.clickMoreLinkBom();
                        var priceMap = {};
                        priceMap = { managedCloudEnterprisePricingLabel: imiConfigTemplate.ManagedCloudEnterpriseCost, hourlyBillingPricingLabel: imiConfigTemplate.HourlyCost }
                        expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                        ordersPage.closeServiceDetailsSlider();
                        //Approve order 
                        orderFlowUtil.approveOrder(orderObject);
                        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                        //Validate Estimated price on approve order page
                        expect(ordersPage.getTextFirstAmountOrdersTable()).toContain(imiConfigTemplate.EnterpriseTotalCost);


                        //Service details on Order History page
                        ordersHistoryPage.open();
                        ordersHistoryPage.searchOrderById(orderObject.orderNumber);

                        //Validate Service Details
                        ordersHistoryPage.clickServiceDetailsLink();
                        expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Management level", 0)).toEqual(imiConfigTemplate.ServiceTierEnterprise);
                        expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Plan level", 0)).toEqual(imiConfigTemplate.BillingPlanHourly);

                        //Validate Estimated cost on order history page
                        ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                        expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.EnterpriseTotalCost);

                        //Validate BOM table on order history page
                        ordersHistoryPage.clickMoreLinkBom();
                        expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                        ordersHistoryPage.closeServiceDetailsSlider();
                        //Validate BOM link on order history
                        ordersHistoryPage.clickBillOfMaterials();
                        ordersHistoryPage.clickMoreLinkBom();
                        expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                        ordersHistoryPage.closeServiceDetailsSlider();
                        //Validate IMI tags
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.open();
                                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                                inventoryPage.clickExpandFirstRow();
                                inventoryPage.clickOverflowActionButtonForPowerStates();
                                inventoryPage.clickViewComponentofAWSInstance();
                                browser.sleep(2000);
                                expect(inventoryPage.getTagsOnInventory()).toContain(imiConfigTemplate.BillingPlanHourlyTag);
                                expect(inventoryPage.getTagsOnInventory()).toContain(imiConfigTemplate.ServiceTierEnterpriseTag);
                                inventoryPage.closeViewComponent();
                        }
                });
        });






});