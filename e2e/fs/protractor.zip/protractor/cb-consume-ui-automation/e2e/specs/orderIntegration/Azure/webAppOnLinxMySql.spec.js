/*
Spec_Name: webAppOnLinxMySql.spec.js
Description: This spec will cover E2E testing of Web App On Linux + MySQL service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../../testData/appUrls.json'),
        util = require('../../../../helpers/util.js'),
        jsonUtil = require('../../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        WATemplate = require('../../../../testData/OrderIntegration/Azure/WebAppOnLinuxMySql.json');

describe('Azure - Web App + MySQL', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Other Services', bluePrintName: 'Web App + MySQL' };
        var modifiedParamMap = {};
        var servicename = "AutoWSQLLsrv" + util.getRandomString(5);
        var rgName, waName, aspName, serverName, dbName, SOIComponents;

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                catalogDetailsPage = new CatalogDetailsPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                rgName = "gslautotc_azure_walinRG" + util.getRandomString(5);
                waName = "AutoWSQLL" + util.getRandomString(5);
                aspName = "AutoASP" + util.getRandomString(5);
                serverName = "autoser" + util.getRandomNumber(5);
                dbName = "AutoDB" + util.getRandomString(5);
                dbName = dbName.toLowerCase();
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "App Name": waName, "New App Service Plan": aspName, "Server Name": serverName, "Database Name": dbName };
                SOIComponents = [serverName, dbName, aspName, waName, WATemplate.AllowAllWindowsAzureIps]
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        });

        afterAll(function () {
                //Delete WebApponLinux + MySQL
                var returnObj = {};
                returnObj.servicename = servicename;
                returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                orderFlowUtil.approveDeletedOrder(returnObj);
                orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        });

        //E2E Web App order Submit, Approve, Delete Service with New Resource Group.
        if (isProvisioningRequired == "true") {
                it('Azure: TC-C186648 Verify if create new Web App + MySQL with New Resource Group, New App Service Plan with New Server and New Database is successful', function () {
                        var waObject = JSON.parse(JSON.stringify(WATemplate));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(waObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(waObject.bluePrintName);
                        var returnObj = {};
                        orderFlowUtil.fillOrderDetails(WATemplate, modifiedParamMap);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Checking Inventory Page Service Configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                        expect(inventoryPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(waObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnExactLabelName("New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(waObject, "Location"));
                        expect(inventoryPage.getTextBasedOnLabelName("App Name:")).toEqual(waName);
                        expect(inventoryPage.getTextBasedOnExactLabelName("App Service Plan:")).toEqual(jsonUtil.getValue(waObject, "App Service Plan"));
                        expect(inventoryPage.getTextBasedOnLabelName("New App Service Plan:")).toEqual(aspName);
                        expect(inventoryPage.getTextBasedOnLabelName("App Service Plan Location:")).toEqual(jsonUtil.getValue(waObject, "App Service Plan Location"));
                        expect(inventoryPage.getTextBasedOnLabelName("Runtime Stack Options:")).toEqual(jsonUtil.getValue(waObject, "Runtime Stack Options"));
                        expect(inventoryPage.getTextBasedOnLabelName("Select Runtime Stack:")).toEqual(jsonUtil.getValue(waObject, "Select Runtime Stack"));
                        expect(inventoryPage.getTextBasedOnLabelName("Server Admin Login Name:")).toEqual(jsonUtil.getValue(waObject, "Server Admin Login Name"));
                        expect(inventoryPage.getTextBasedOnLabelName("Server Version:")).toEqual(jsonUtil.getValue(waObject, "Server Version"));
                        expect(inventoryPage.getTextBasedOnLabelName("Database Name:")).toEqual(dbName);
                        inventoryPage.closeViewDetailsTab();
                        //Checking SOI Components
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.open();
                                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                                inventoryPage.clickExpandFirstRow().then(function () {
                                        browser.executeScript('window.scrollTo(0,0);');
                                        var i = 1;
                                        async.forEachSeries(SOIComponents, function (component, callback) {
                                                inventoryPage.clickOverMenuIcon(i).then(function () {
                                                        inventoryPage.clickOnViewComponent(i).then(function () {
                                                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                                                inventoryPage.closeViewComponent();
                                                                browser.sleep(10000);
                                                                i++;
                                                                return callback();
                                                        });
                                                })
                                        }, function (error) {
                                                if (error) {
                                                        logger.info('Unable to Get SOI component')
                                                }
                                        })
                                })
                        }
             // check Non-Editable service Message
             inventoryPage.open();
             inventoryPage.searchOrderByServiceName(returnObj.servicename);
             inventoryPage.clickNonEditableInstance();
             expect(inventoryPage.getTextForInvalidEditModal()).toEqual(WATemplate.nonEditableText);
             inventoryPage.clickOnInvalidEditOkModal();
                });
        }

        //Checking parameters on Main Parameters page
        it('Azure: TC-C186625 verify that for Web App + MySQL Service all parameters on Main Parameters Page are present.', function () {
                var waObject = JSON.parse(JSON.stringify(WATemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(waObject.Category);
                catalogPage.clickDetailsButtonBasedOnName(waObject.bluePrintName);
                if (browser.params.defaultCurrency == "USD") {
                expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(waObject.BasePrice);
                }
        });

        //Checking values on View Order Details
        it('Azure: TC-C186627 verify that for Web App + MySQL Service all values on View Order Details page matches with input.', function () {
                var returnObj = {};
                returnObj.servicename = servicename;
                var waObject = JSON.parse(JSON.stringify(WATemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(waObject.Category);
                catalogPage.clickConfigureButtonBasedOnName(waObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(WATemplate, modifiedParamMap);
                //Checking Service Details in ReviewOrder
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
                if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(waObject.TotalCost);
                }
                //Checking Additional Details in ReviewOrder
                expect(placeOrderPage.getTextBasedOnLabelName("App Name:")).toEqual(waName);
                expect(placeOrderPage.getTextBasedOnLabelName("App Service Plan:")).toEqual(jsonUtil.getValue(waObject, "App Service Plan"));
                expect(placeOrderPage.getTextBasedOnLabelName("New App Service Plan:")).toEqual(aspName);
                expect(placeOrderPage.getTextBasedOnLabelName("App Service Plan Location:")).toEqual(jsonUtil.getValue(waObject, "App Service Plan Location"));
                expect(placeOrderPage.getTextBasedOnLabelName("Runtime Stack Options:")).toEqual(jsonUtil.getValue(waObject, "Runtime Stack Options"));
                expect(placeOrderPage.getTextBasedOnLabelName("Select Runtime Stack:")).toEqual(jsonUtil.getValue(waObject, "Select Runtime Stack"));
                expect(placeOrderPage.getTextBasedOnLabelName("Server Name:")).toEqual(serverName);
                expect(placeOrderPage.getTextBasedOnLabelName("Server Admin Login Name:")).toEqual(jsonUtil.getValue(waObject, "Server Admin Login Name"));
                expect(placeOrderPage.getTextBasedOnLabelName("Server Version:")).toEqual(jsonUtil.getValue(waObject, "Server Version"));
                expect(placeOrderPage.getTextBasedOnLabelName("Compute Generation:")).toEqual(jsonUtil.getValue(waObject, "Compute Generation"));
                expect(placeOrderPage.getTextBasedOnLabelName("VCore:")).toEqual(jsonUtil.getValue(waObject, "VCore"));
                expect(placeOrderPage.getTextBasedOnLabelName("Storage (Basic):")).toEqual(jsonUtil.getValue(waObject, "Storage (Basic)"));
                expect(placeOrderPage.getTextBasedOnLabelName("Backup Retention Period:")).toEqual(jsonUtil.getValue(waObject, "Backup Retention Period"));;
                expect(placeOrderPage.getTextBasedOnLabelName("Backup Redundancy Options:")).toEqual(jsonUtil.getValue(waObject, "Backup Redundancy Options"));
                expect(placeOrderPage.getTextBasedOnLabelName("Database Name:")).toEqual(dbName);
                expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(waObject, "New Resource Group Required"));
                expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(rgName);
                expect(placeOrderPage.getTextBasedOnLabelName("Location:")).toEqual(jsonUtil.getValue(waObject, "Location"));
                placeOrderPage.submitOrder();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                ordersPage.open();
                ordersPage.searchOrderById(returnObj.orderNumber);
                ordersPage.clickFirstViewDetailsOrdersTable();
                //Checking Order Details in View order details
                expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(waObject.provider);//Checking Provider
                //Checking Service Configuration Parameters
                expect(ordersPage.getTextBasedOnExactLabelName("App Name")).toEqual(waName);
                expect(ordersPage.getTextBasedOnExactLabelName("App Service Plan")).toEqual(jsonUtil.getValue(waObject, "App Service Plan"));
                expect(ordersPage.getTextBasedOnExactLabelName("New App Service Plan")).toEqual(aspName);
                expect(ordersPage.getTextBasedOnExactLabelName("App Service Plan Location")).toEqual(jsonUtil.getValue(waObject, "App Service Plan Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Runtime Stack Options")).toEqual(jsonUtil.getValue(waObject, "Runtime Stack Options"));
                expect(ordersPage.getTextBasedOnExactLabelName("Select Runtime Stack")).toEqual(jsonUtil.getValue(waObject, "Select Runtime Stack"));
                expect(ordersPage.getTextBasedOnExactLabelName("Server Admin Login Name")).toEqual(jsonUtil.getValue(waObject, "Server Admin Login Name"));
                expect(ordersPage.getTextBasedOnExactLabelName("Server Version")).toEqual(jsonUtil.getValue(waObject, "Server Version"));
                expect(ordersPage.getTextBasedOnExactLabelName("Database Name")).toEqual(dbName);
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(waObject, "New Resource Group Required"));
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
                expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(waObject, "Location"));
                //Checking Bill Of Material
                if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getEstimatedCost()).toBe(waObject.TotalCost);
                }
                ordersPage.clickServiceDetailSliderCloseButton();
        });
});
