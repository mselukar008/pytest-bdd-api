"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    oracleTemplate = require('../../../../testData/OrderIntegration/AWS/oracle.json');

describe('AWS - RDS-Oracle', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, dbInstance, oracleObj, inventoryPage;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = oracleTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Databases',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        systemTagText: "ibm_mcmp_soiid"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-oracle-" + util.getRandomString(5);
        dbInstance = "attDbInstance" + util.getRandomString(5);
        dbInstance = dbInstance.toLowerCase();
        oracleObj = JSON.parse(JSON.stringify(oracleTemplate));
    });

    beforeEach(function () {
        modifiedParamMap = { "Service Instance Name": serviceName, "DB instance identifier": dbInstance };
    });

    it('AWS-Oracle-Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        catalogPage.open();
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(oracleTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(oracleTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(oracleTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(oracleTemplate.TotalCost); expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["DB engine"]).toEqual(requiredReturnMap["Expected"]["DB engine"]);
            expect(requiredReturnMap["Actual"]["License Model"]).toEqual(requiredReturnMap["Expected"]["License Model"]);
            expect(requiredReturnMap["Actual"]["DB engine version"]).toEqual(requiredReturnMap["Expected"]["DB engine version"]);
            expect(requiredReturnMap["Actual"]["DB instance class"]).toEqual(requiredReturnMap["Expected"]["DB instance class"]);
            expect(requiredReturnMap["Actual"]["Storage type"]).toEqual(requiredReturnMap["Expected"]["Storage type"]);
            expect(requiredReturnMap["Actual"]["Allocated storage"]).toEqual(requiredReturnMap["Expected"]["Allocated storage"]);
            expect(requiredReturnMap["Actual"]["DB instance identifier"]).toEqual(dbInstance);
            expect(requiredReturnMap["Actual"]["Master username"]).toEqual(requiredReturnMap["Expected"]["Master username"]);
            expect(requiredReturnMap["Actual"]["Database name"]).toEqual(requiredReturnMap["Expected"]["Database Name"]);
            expect(requiredReturnMap["Actual"]["Database port"]).toEqual(requiredReturnMap["Expected"]["Database port"]);
            expect(requiredReturnMap["Actual"]["Backup retention period"]).toEqual(requiredReturnMap["Expected"]["Backup retention period"]);
            expect(requiredReturnMap["Actual"]["Copy tags to snapshot"]).toEqual(requiredReturnMap["Expected"]["Copy tags to snapshot"]);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(oracleTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 1200);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(oracleTemplate.EstimatedPrice);
                //Validate pricing on order history page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(oracleTemplate.EstimatedPrice);
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();            
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(oracleObj,"AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("License Model")).toEqual(jsonUtil.getValue(oracleObj,"License Model"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("DB engine")).toEqual(jsonUtil.getValue(oracleObj,"DB engine"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(oracleObj,"DB engine version"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(oracleObj,"DB instance class"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Storage type")).toEqual(jsonUtil.getValue(oracleObj,"Storage type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Allocated storage")).toEqual(jsonUtil.getValue(oracleObj,"Allocated storage"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB instance identifier")).toEqual(dbInstance);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Master username")).toEqual(jsonUtil.getValue(oracleObj,"Master username"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Database port")).toEqual(jsonUtil.getValue(oracleObj,"Database port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValue(oracleObj,"Backup retention period"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Copy tags to snapshot")).toEqual(jsonUtil.getValue(oracleObj,"Copy tags to snapshot"));
 
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(oracleTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(oracleTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.clickAllOrdersUnderOrdersSection();
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(oracleObj,"AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("License Model")).toEqual(jsonUtil.getValue(oracleObj,"License Model"));
            expect(ordersPage.getTextBasedOnLabelName("DB engine")).toEqual(jsonUtil.getValue(oracleObj,"DB engine"));
            expect(ordersPage.getTextBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(oracleObj,"DB engine version"));
            expect(ordersPage.getTextBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(oracleObj,"DB instance class"));
            expect(ordersPage.getTextBasedOnLabelName("Storage type")).toEqual(jsonUtil.getValue(oracleObj,"Storage type"));
            expect(ordersPage.getTextBasedOnLabelName("Allocated storage")).toEqual(jsonUtil.getValue(oracleObj,"Allocated storage"));
            expect(ordersPage.getTextBasedOnLabelName("DB instance identifier")).toEqual(dbInstance);
            expect(ordersPage.getTextBasedOnLabelName("Master username")).toEqual(jsonUtil.getValue(oracleObj,"Master username"));
            expect(ordersPage.getTextBasedOnLabelName("Database port")).toEqual(jsonUtil.getValue(oracleObj,"Database port"));
            expect(ordersPage.getTextBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValue(oracleObj,"Backup retention period"));
            expect(ordersPage.getTextBasedOnLabelName("Copy tags to snapshot")).toEqual(jsonUtil.getValue(oracleObj,"Copy tags to snapshot"));
 
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(oracleTemplate.TotalCost);
            ordersPage.clickServiceDetailSliderCloseButton();
        });
    });

    it('AWS-Oracle-Validate system tags, Edit and Delete Service', function () {        
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            if (isDummyAdapterDisabled == "true") {
                orderObject.componentType = oracleTemplate.componentType1;
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(oracleTemplate.componentType1).then(function (index) {
                    inventoryPage.clickViewComponentBasedOnIndex(index - 1).then(function () {
                        //View Component VM details
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(oracleTemplate.componentType1);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Resource Id")).toEqual(oracleTemplate.resourceId);
                    });
                    inventoryPage.getTagsOnInventory().then(function (tags) {
                        var tagList = tags.split(",");
                        var tagMap = inventoryPage.getServiceTags(tagList);                        
                        //verifying a system tag
                        expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                        //verifying some of the service tags             
                        expect(tagList.includes(tagList.find(tag => tag.includes("StackId:arn:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:logical-id:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-id:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-name")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("ibm_mcmp_soiid:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("orderNumber")))).toBe(true);
                        expect(tagMap["serviceInstanceName"].toLowerCase()).toContain(serviceName.toLowerCase());
                        //Validate Component Properties
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AvailabilityZone")).toContain(oracleTemplate.availablilityZone);
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("LicenseModel")).toEqual(jsonUtil.getValue(oracleObj,"License Model"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("EngineVersion")).toEqual(jsonUtil.getValue(oracleObj,"DB engine version"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DBInstanceClass")).toEqual(jsonUtil.getValue(oracleObj,"DB instance class"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("StorageType")).toEqual("gp2");
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AllocatedStorage")).toEqual(jsonUtil.getValue(oracleObj,"Allocated storage"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DBInstanceIdentifier")).toEqual(dbInstance);
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("MasterUsername")).toEqual(jsonUtil.getValue(oracleObj,"Master username"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DbInstancePort")).toEqual(jsonUtil.getValue(oracleObj,"Database port"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("BackupRetentionPeriod")).toEqual(jsonUtil.getValue(oracleObj,"Backup retention period"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("CopyTagsToSnapshot")).toEqual(jsonUtil.getValue(oracleObj,"Copy tags to snapshot"));
                    });                    
                });
            }else {
                inventoryPage.clickOverflowActionButtonForPowerStates();
                inventoryPage.clickViewComponentofAWSInstance();
                inventoryPage.getTagsOnInventory().then(function (tags) {
                    var tagList = tags.split(",");
                    var tagMap = inventoryPage.getServiceTags(tagList);
                    //verifying flags for dummy adapter
                    expect(tagMap["IsUsingDummy"]).toEqual("Yes");
                    expect(tagMap["Name"]).toEqual(oracleTemplate.bluePrintName);
                    expect(tagMap["PhysicalId"]).toContain(serviceName);
                    expect(Object.keys(tagMap).includes("Test")).toBe(true);
                    expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                });                
            
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AWS Region")).toEqual(jsonUtil.getValue(oracleObj,"AWS Region"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("license Model")).toEqual(jsonUtil.getValue(oracleObj,"License Model"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB engine version")).toEqual(jsonUtil.getValue(oracleObj,"DB engine version"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB instance class")).toEqual(jsonUtil.getValue(oracleObj,"DB instance class"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Storage type")).toEqual(jsonUtil.getValue(oracleObj,"Storage type"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Allocated storage")).toEqual(jsonUtil.getValue(oracleObj,"Allocated storage"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB instance identifier")).toEqual(dbInstance);
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Master username")).toEqual(jsonUtil.getValue(oracleObj,"Master username"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Database port")).toEqual(jsonUtil.getValue(oracleObj,"Database port"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Backup retention period")).toEqual(jsonUtil.getValue(oracleObj,"Backup retention period"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Copy tags to snapshot")).toEqual(jsonUtil.getValue(oracleObj,"Copy tags to snapshot"));
            }    
                orderFlowUtil.closeHorizontalSliderIfPresent();
        });

        //Edit service flow
        var dbInstanceEdit = "oracleNew"+ util.getRandomString(5); 
        var modifiedParamMapEdit = { "EditService": true, "DB instance identifier":dbInstanceEdit };
        
        orderFlowUtil.editService(orderObject);
        orderFlowUtil.fillOrderDetails(oracleTemplate, modifiedParamMapEdit).then(function (reviewOrderExpActParamsMap) {
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(oracleTemplate.TotalCostPostEdit);
            browser.sleep(5000);
            //Delete password key as its encrypted on UI.
            delete reviewOrderExpActParamsMap["Actual"]["Master password"];
            delete reviewOrderExpActParamsMap["Expected"]["Master password"];
            //Validate Review order page parameters
            expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
        });
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(oracleTemplate.bluePrintName, "Edit");
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 2000);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == 'Completed') {
                //Verify updated details are reflected on order details page.						
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValueEditParameter(oracleObj, "DB engine version"));
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(oracleTemplate.TotalCostPostEdit);
                ordersPage.clickServiceDetailSliderCloseButton();
                //Delete Service flow                    
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, oracleTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 2000);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            }
        });
     });
});
