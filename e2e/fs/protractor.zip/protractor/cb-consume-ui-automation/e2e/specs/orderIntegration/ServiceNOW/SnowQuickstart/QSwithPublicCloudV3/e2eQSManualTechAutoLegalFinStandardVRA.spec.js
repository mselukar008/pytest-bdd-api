"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	vRACentOS76Temp = require('../../../../../../testData/OrderIntegration/ServiceNOW/CloneCentOS76Snow.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('QS: vRA E2E cases for Manual Technical, Auto Financial and Legal approval with Standard change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, sampleOrder1, provOrder, resourceId, instName, inventoryPage, policyPage, cartListPage;
	var modifiedParamMap = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var serviceName = "SNOWQSauto"+util.getRandomString(5);
	var policyName = "SNOWQSautoVRAPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWQSautoVRAPolicyRule"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var vraCentOSObj = JSON.parse(JSON.stringify(vRACentOS76Temp));
	
	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["VRA"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
								  "Technical":"Manual Approval"};
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":""};
	});
	
	afterAll(function() {
		//Delete Approval Policy
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

	  //Disable Discovery Property flag
		snowPage.loginToSnowQSICDSPortal();
		snowPage.setQSflag(snowInstanceTemplate.snowDiscoveryProperty,snowInstanceTemplate.snowPropertyValueFalse);
		expect(snowPage.getTextValuePropertyQS()).toBe(snowInstanceTemplate.snowPropertyValueFalse);
		snowPage.clickUpdateButton();

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});
	
	it('Set Change Request type to Standard in SNOW', function () {
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Approval Policy for Manual Technical, Auto Financial and Legal approval and Standard change', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});

	//Enable Discovery Property flag
	it('Enable Discovery Property flag',function () {
		snowPage.loginToSnowQSICDSPortal();
		snowPage.setQSflag(snowInstanceTemplate.snowDiscoveryProperty,snowInstanceTemplate.snowPropertyValueTrue);
		expect(snowPage.getTextValuePropertyQS()).toBe(snowInstanceTemplate.snowPropertyValueTrue);
		snowPage.clickUpdateButton();
		});
	
	if(isProvisioningRequired == "true") {	
		it('vRA: Clone_CentOS7.6 ---- Verify Provision functionality with Manual Technical, Auto Financial and Legal approval and Standard change', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			
			//Validations on SNOW Request page before approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickOkInOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual(jsonUtil.getValue(vraCentOSObj, "Memory (MB)"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual(jsonUtil.getValue(vraCentOSObj, "CPUs"));

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue1CentOS76)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue2CentOS76)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue3CentOS76)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue1CentOS76)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRACentOS76New1);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue2CentOS76)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRACentOS76New2);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue3CentOS76)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRACentOS76New3);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe("");
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe("");
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();
			//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
					
			//Order Completion in SNOW
			//snowPage.clickImplementButtonQS();
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe("vsphere.local");
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.vraProviderAccount);
			resourceId = snowPage.getTextSerInstanceCIsResourceId();
			expect(snowPage.getTextSerInstanceCIsResourceId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
		    });		
		});
	
		it('vRA: Clone_CentOS7.6 ---- Verify Edit functionality with Manual Technical, Auto Financial and Legal approval and Standard change', function () {
			
			//Place Order for Edit in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			modifiedParamMap = {"Service Instance Name":"","Team":"","Environment":"","Application":"","Provider Account":"","Memory (MB)":"1024","CPUs":"2"};
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.editService(orderObject);
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			
			//Validations on SNOW Request page before approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickOkInOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestEdit);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual("1024");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual("2");

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue1CentOS76)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue2CentOS76)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue3CentOS76)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue1CentOS76)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRACentOS76Edit1);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue2CentOS76)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRACentOS76Edit2);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue3CentOS76)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRACentOS76Edit3);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toEqual("vsphere.local");
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.vraProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();
			//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
					
			//Order Completion in SNOW
			//snowPage.clickImplementButtonQS();
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toEqual("vsphere.local");
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.vraProviderAccount);
			resourceId = snowPage.getTextSerInstanceCIsResourceId();
			expect(snowPage.getTextSerInstanceCIsResourceId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();			
			});		
		});
	
		it('vRA: Clone_CentOS7.6 ---- Run Discovery for vRA before Turn OFF and verify the VM in SNOW', function () {
			var orderObject = {};
			orderObject.servicename = serviceName;
			snowPage.openDiscoverySchedulesQS();
			snowPage.runDiscoveryForVRA();
			expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function() {
		    instName = inventoryPage.getServiceInstanceNameTextVRA();
			instName.then(function(vmName){
				instName = vmName;
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.clickRequestedItemLink();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
				expect(snowPage.isPresentVMInstanceInCIVRA(vmName)).toBe(true);
				snowPage.clickVMInstanceInCILinkVRA(vmName);
				snowPage.switchCMDBCIViewToDefaultView();
				expect(snowPage.getTextCMDBActualCIName()).toBe(vmName);
				expect(snowPage.getTextVMCPU()).toBe(snowInstanceTemplate.cpuValue);
				expect(snowPage.getTextVMemory()).toBe(snowInstanceTemplate.memoryValue);
				expect(snowPage.getTextVMInstanceStateVRA()).toBe(snowInstanceTemplate.instanceStateOn);
				expect(snowPage.getTextCMDBActualCIDiskSizeDefaultViewCss()).toEqual("5");
		        });
			})			
		});
	
		it('vRA: Clone_CentOS7.6 ---- Verify Turn OFF functionality with Manual Technical, Auto Financial and Legal approval and Standard change', function () {
	
	        //Place order for Turn OFF in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA(vRACentOS76Temp.componentType).then(function () {
	                inventoryPage.clickTurnOFFButtonOfInstanceSNOW().then(function () {
	                    inventoryPage.clickOkForInstanceTurnOFFPermission();
	                });
	            });
	        }).then(function () {
	            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
	            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
	            sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            inventoryPage.clickOkForCustomOpnOrderButton();    
		
	            //Validations on SNOW Request page before approval
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
				
				//Approve Order in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				orderFlowUtil.approveOrderButtonSNOW(orderObject);
				ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
				ordersPage.clickApproveButtonOrderApprovalModal();
			    ordersPage.clickOkInOrderApprovalModal();
				orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
				expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
				
				//Validations on SNOW Request page after approval in Marketplace
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
				expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.serviceOfferingTurnOff);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
	    					
	    		//Validations on SNOW Requested Item page
	    		snowPage.clickRequestedItemLink();
	    		expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
	    		expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
	    		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
	    		expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
	    		expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.serviceOfferingTurnOff);
	    		expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOff);
	    		expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
	    		expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOff);
	    		expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
	    		var serName = snowPage.getTextReqItemVariableServiceName();
	    		serName.then(function(sName){
	    		expect(sName).toContain(serviceName);
	    		expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(instName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("stop");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextCMDBActualCIName()).toEqual(instName);
				expect(snowPage.getTextCMDBActualCIObjectIDHCMSView()).toEqual(resourceId);
				//expect(snowPage.getTextSerInstanceCIsStatusVRA()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();
				//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				//snowPage.clickImplementButtonQS();
				snowPage.checkIfProvisioningTaskClosed();
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
				inventoryPage.open();
		        inventoryPage.searchOrderByServiceName(orderObject.servicename);
		        inventoryPage.clickExpandFirstRow().then(function() {
		        	expect(inventoryPage.getInstancePowerStateStatusVRA(orderObject)).toContain(vRACentOS76Temp.powerStateOff);	          	
	      		});
				
		        //Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion			
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextCMDBActualCIName()).toEqual(instName);
				expect(snowPage.getTextCMDBActualCIObjectIDHCMSView()).toEqual(resourceId);
				//expect(snowPage.getTextSerInstanceCIsStatusVRA()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();

				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();			
				});		
	        });
		});
	
		it('vRA: Clone_CentOS7.6 ---- Run Discovery for VRA after Turn OFF and verify the state of VM in SNOW', function () {
			snowPage.openDiscoverySchedulesQS();
			snowPage.runDiscoveryForVRA();
			expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.clickRequestedItemLink();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextCMDBActualCIName()).toBe(instName);
			expect(snowPage.getTextCMDBActualCIObjectIDHCMSView()).toEqual(resourceId);
			snowPage.switchCMDBCIViewToDefaultView();
			expect(snowPage.getTextCMDBActualCIName()).toBe(instName);
			expect(snowPage.getTextVMInstanceStateVRA()).toBe(snowInstanceTemplate.instanceStateOff);
			expect(snowPage.getTextVMCPU()).toBe(snowInstanceTemplate.cpuValue);
			expect(snowPage.getTextVMemory()).toBe(snowInstanceTemplate.memoryValue);
			expect(snowPage.getTextCMDBActualCIDiskSizeDefaultViewCss()).toEqual("5");		
		});
	
		it('vRA: Clone_CentOS7.6 ---- Verify Turn ON functionality with Manual Technical, Auto Financial and Legal approval and Standard change', function () {
	
	        //Place order for Turn ON in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA(vRACentOS76Temp.componentType).then(function () {
	                inventoryPage.clickTurnONButtonOfInstanceSNOW().then(function () {
	                    inventoryPage.clickOkForInstanceTurnONPermission();
	                });
	            });
	        }).then(function () {
	            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
	            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
	            sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            inventoryPage.clickOkForCustomOpnOrderButton();    
		
	            //Validations on SNOW Request page before approval
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
				
				//Approve Order in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				orderFlowUtil.approveOrderButtonSNOW(orderObject);
				ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
				ordersPage.clickApproveButtonOrderApprovalModal();
			    ordersPage.clickOkInOrderApprovalModal();
				orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
				expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
				
				//Validations on SNOW Request page after approval in Marketplace
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
				expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.serviceOfferingTurnOn);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
	    					
	    		//Validations on SNOW Requested Item page
	    		snowPage.clickRequestedItemLink();
	    		expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
	    		expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
	    		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
	    		expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
	    		expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.serviceOfferingTurnOn);
	    		expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOn);
	    		expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
	    		expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOn);
	    		expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
	    		var serName = snowPage.getTextReqItemVariableServiceName();
	    		serName.then(function(sName){
	    		expect(sName).toContain(serviceName);
	    		expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(instName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("start");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextCMDBActualCIName()).toEqual(instName);
				expect(snowPage.getTextCMDBActualCIObjectIDHCMSView()).toEqual(resourceId);
				//expect(snowPage.getTextSerInstanceCIsStatusVRA()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();
				//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				//snowPage.clickImplementButtonQS();
				snowPage.checkIfProvisioningTaskClosed();
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
				inventoryPage.open();
		        inventoryPage.searchOrderByServiceName(orderObject.servicename);
		        inventoryPage.clickExpandFirstRow().then(function() {
		        	expect(inventoryPage.getInstancePowerStateStatusVRA(orderObject)).toContain(vRACentOS76Temp.powerStateOn);	          	
	      		});
				
		        //Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion			
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextCMDBActualCIName()).toEqual(instName);
				expect(snowPage.getTextCMDBActualCIObjectIDHCMSView()).toEqual(resourceId);
				//expect(snowPage.getTextSerInstanceCIsStatusVRA()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();				
				});		
	        });
		});
	
		it('vRA: Clone_CentOS7.6 ---- Run Discovery for VRA after Turn ON and verify the state of VM in SNOW', function () {
			snowPage.openDiscoverySchedulesQS();
			snowPage.runDiscoveryForVRA();
			expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.clickRequestedItemLink();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.switchCMDBCIViewToDefaultView();
			expect(snowPage.getTextCMDBActualCIName()).toBe(instName);
			expect(snowPage.getTextVMCPU()).toBe(snowInstanceTemplate.cpuValue);
			expect(snowPage.getTextVMemory()).toBe(snowInstanceTemplate.memoryValue);
			expect(snowPage.getTextVMInstanceStateVRA()).toBe(snowInstanceTemplate.instanceStateOn);
			expect(snowPage.getTextCMDBActualCIDiskSizeDefaultViewCss()).toEqual("5");					
		});
	
		it('vRA: Clone_CentOS7.6 ---- Verify Reboot functionality with Manual Technical, Auto Financial and Legal approval and Standard change', function () {
	
	        //Place order for Reboot in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA(vRACentOS76Temp.componentType).then(function () {
	                inventoryPage.clickRebootButtonOfInstanceSNOW().then(function () {
	                    inventoryPage.clickOkForInstanceRebootPermission();
	                });
	            });
	        }).then(function () {
	            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
	            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
	            sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            inventoryPage.clickOkForCustomOpnOrderButton();    
		
	            //Validations on SNOW Request page before approval
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
				
				//Approve Order in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				orderFlowUtil.approveOrderButtonSNOW(orderObject);
				ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
				ordersPage.clickApproveButtonOrderApprovalModal();
			    ordersPage.clickOkInOrderApprovalModal();
				orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
				expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
				
				//Validations on SNOW Request page after approval in Marketplace
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
				expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.serviceOfferingReboot);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
	    					
	    		//Validations on SNOW Requested Item page
	    		snowPage.clickRequestedItemLink();
	    		expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
	    		expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
	    		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
	    		expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
	    		expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.serviceOfferingReboot);
	    		expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescReboot);
	    		expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
	    		expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingReboot);
	    		expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
	    		var serName = snowPage.getTextReqItemVariableServiceName();
	    		serName.then(function(sName){
	    		expect(sName).toContain(serviceName);
	    		expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(instName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("reboot");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextCMDBActualCIName()).toEqual(instName);
				expect(snowPage.getTextCMDBActualCIObjectIDHCMSView()).toEqual(resourceId);
				//expect(snowPage.getTextSerInstanceCIsStatusVRA()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();
				//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				//snowPage.clickImplementButtonQS();
				snowPage.checkIfProvisioningTaskClosed();
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
				inventoryPage.open();
		        inventoryPage.searchOrderByServiceName(orderObject.servicename);
		        inventoryPage.clickExpandFirstRow().then(function() {
		        	expect(inventoryPage.getInstancePowerStateStatusVRA(orderObject)).toContain(vRACentOS76Temp.powerStateOn);	          	
	      		});
				
		        //Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion			
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextCMDBActualCIName()).toEqual(instName);
				expect(snowPage.getTextCMDBActualCIObjectIDHCMSView()).toEqual(resourceId);
				//expect(snowPage.getTextSerInstanceCIsStatusVRA()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();				
				});		
	        });
		});
	
		it('vRA: Clone_CentOS7.6 ---- Verify Delete functionality with Manual Technical, Auto Financial and Legal approval and Standard change', function () {
			
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			sampleOrder1 = inventoryPage.getDeleteOrderNumber();
			
			//Validations on SNOW Request page before approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.approveDeleteOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickOkInOrderApprovalModal();
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState,50);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue1CentOS76)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue2CentOS76)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue3CentOS76)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue1CentOS76)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRACentOS76Del1);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue2CentOS76)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRACentOS76Del2);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowVRASrvcItemValue3CentOS76)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRACentOS76Del3);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toEqual("vsphere.local");
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.vraProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();
			//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
					
			//Order Completion in SNOW
			//snowPage.clickImplementButtonQS();
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(vRACentOS76Temp.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);

			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toEqual("vsphere.local");
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.vraProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();		
			});		
		 });
	  }
	
});
	
	
	
	