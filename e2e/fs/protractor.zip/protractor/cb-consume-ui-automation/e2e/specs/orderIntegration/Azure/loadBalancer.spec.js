/*
Spec_Name: loadBalancerspec.js 
Description: This spec will cover E2E testing of Loadbalancer service order submit, approve, edit and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../../testData/appUrls.json'),
        util = require('../../../../helpers/util.js'),
        jsonUtil = require('../../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        LBTemplate = require('../../../../testData/OrderIntegration/Azure/LoadBalancer.json');
        
describe('Azure - Load Balancer', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Storage' };
        var modifiedParamMapedit = {};
        var servicename = "AutoLBsrv" + util.getRandomString(5);
        var rgName = "gslautotc_azureLBRG101" + util.getRandomString(5);
        var lbName = "autolb" + util.getRandomString(5);
        var pipName = "autopip" + util.getRandomString(5);
        var frontendIPConfigurationName ="frontendIP"+ util.getRandomString(5);
        var backendPoolName ="backEndPool"+ util.getRandomString(5);
        var healthProbeName ="healthProbeName"+ util.getRandomString(5);
        var SOIComponents;
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Load Balancer Name": lbName, "New Public Ip Name": pipName, "Frontend IP Configuration Name":frontendIPConfigurationName,"Backend Pool Name":backendPoolName,"Health Probe Name":healthProbeName };

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                catalogDetailsPage = new CatalogDetailsPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
                rgName = "gslautotc_azureLBRG101" + util.getRandomString(5);
                lbName = "autolb" + util.getRandomString(5);
                pipName = "autopip" + util.getRandomString(5);
                frontendIPConfigurationName ="frontendIP"+ util.getRandomString(5);
                backendPoolName ="backEndPool"+ util.getRandomString(5);
                healthProbeName ="healthProbeName"+ util.getRandomString(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Load Balancer Name": lbName, "New Public Ip Name": pipName, "Frontend IP Configuration Name":frontendIPConfigurationName,"Backend Pool Name":backendPoolName,"Health Probe Name":healthProbeName };
                SOIComponents = [lbName, pipName]
        });

        afterAll(function () {
                // Delete Load Balancer
                var returnObj = {};
                returnObj.servicename = servicename;
                returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                orderFlowUtil.approveDeletedOrder(returnObj);
                orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        });

        //E2E ExpressRoute Load Balancer order Submit, Approve, Edit and Delete Service with New Resource Group.
        if (isProvisioningRequired == "true") {
                it('Azure: TC-T367020-Sanity Verify if create new Public LoadBalancer with New Public IP and existing Resource Group is successful', function () {
                        var orderObject = JSON.parse(JSON.stringify(LBTemplate));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};
                        var returnObj1 = {};
                        orderFlowUtil.fillOrderDetails(LBTemplate, modifiedParamMap);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Chcecking Inventory service configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Load Balancer Name:")).toEqual(lbName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Load Balancer Location:")).toEqual(jsonUtil.getValue(orderObject, "Load Balancer Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Load Balancer Type:")).toEqual(jsonUtil.getValue(orderObject, "Load Balancer Type"));
                        expect(inventoryPage.getTextBasedOnLabelName(" SKU:")).toEqual(jsonUtil.getValue(orderObject, "SKU"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Public IP Address Assignment:")).toEqual(jsonUtil.getValue(orderObject, "Public Ip Address Assignment"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Public IP Address:")).toEqual(jsonUtil.getValue(orderObject, "Public Ip Address"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Public IP Name:")).toEqual(pipName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Frontend IP Configuration Name:")).toEqual(frontendIPConfigurationName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Backend Pool Name:")).toEqual(backendPoolName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Health Probe Name:")).toEqual(healthProbeName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Health Probe Protocol:")).toEqual(jsonUtil.getValue(orderObject, "Health Probe Protocol"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Health Probe Port:")).toEqual(jsonUtil.getValue(orderObject, "Health Probe Port"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Health Probe Interval:")).toEqual(jsonUtil.getValue(orderObject, "Health Probe Interval"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Health Probe Unhealthy Threshold:")).toEqual(jsonUtil.getValue(orderObject, "Health Probe Unhealthy Threshold"));
                        inventoryPage.closeViewDetailsTab();
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.clickExpandFirstRow().then(function () {
                                        browser.executeScript('window.scrollTo(0,0);');
                                        var i = 1;
                                        async.forEachSeries(SOIComponents, function (component, callback) {
                                                inventoryPage.clickOverMenuIcon(i).then(function () {
                                                        inventoryPage.clickOnViewComponent(i).then(function () {
                                                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                                                inventoryPage.closeViewComponent();
                                                                browser.sleep(10000);
                                                                i++;
                                                                return callback();
                                                        });
                                                })
                                        }, function (error) {
                                                if (error) {
                                                        logger.info('Unable to Get SOI component')
                                                }
                                        })
                                })
                        }
                        //Editing Load Balancer Service
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                        inventoryPage.clickEditServiceIcon();
                        modifiedParamMapedit = { "Service Instance Name": servicename, "EditService": true };
                        orderFlowUtil.fillOrderDetails(LBTemplate, modifiedParamMapedit);
                        placeOrderPage.submitOrder();
                        returnObj1.servicename = servicename;
                        returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        //Get details on pop up after submit
                        var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        var orderprice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                        var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        //Open Order page and Approve Order 
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj1);
                        orderFlowUtil.waitForOrderStatusChange(returnObj1, "Completed", 50);
                });
        }

        //Checking parameters on Main Parameters page
        it('Azure: TC-T366937 verify that for Load Balancer Service all parameters on Main Parameters Page are present.', function () {
                var orderObject = JSON.parse(JSON.stringify(LBTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
                if (browser.params.defaultCurrency == "USD") {
                expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
                }
        });

        //Checking values all parameters on Review Order Page and View Order Details
        it('Azure: TC-T366939 verify that for Load Balancer Service all values on Review Order Page and View Order Details page matches with input.', function () {
                var returnObj = {};
                returnObj.servicename = servicename;
                var orderObject = JSON.parse(JSON.stringify(LBTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(LBTemplate, modifiedParamMap);
                //Checking Service Details in ReviewOrder
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
                if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
                }
                //Checking Additional Details in ReviewOrder
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Load Balancer Name:")).toEqual(lbName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Load Balancer Location:")).toEqual(jsonUtil.getValue(orderObject, "Load Balancer Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Load Balancer Type:")).toEqual(jsonUtil.getValue(orderObject, "Load Balancer Type"));
                expect(placeOrderPage.getTextBasedOnLabelName(" SKU:")).toEqual(jsonUtil.getValue(orderObject, "SKU"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Frontend IP Configuration Name:")).toEqual(frontendIPConfigurationName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Backend Pool Name:")).toEqual(backendPoolName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Health Probe Name:")).toEqual(healthProbeName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Health Probe Protocol:")).toEqual(jsonUtil.getValue(orderObject, "Health Probe Protocol"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Health Probe Port:")).toEqual(jsonUtil.getValue(orderObject, "Health Probe Port"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Health Probe Interval:")).toEqual(jsonUtil.getValue(orderObject, "Health Probe Interval"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Health Probe Unhealthy Threshold:")).toEqual(jsonUtil.getValue(orderObject, "Health Probe Unhealthy Threshold"));
                placeOrderPage.submitOrder();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                ordersPage.open();
                ordersPage.searchOrderById(returnObj.orderNumber);
                ordersPage.clickFirstViewDetailsOrdersTable();
                //Checking Order Details in View order details
                expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
                //Checking Service Configuration Parameters
                expect(ordersPage.getTextBasedOnLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
                expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(ordersPage.getTextBasedOnLabelName("Load Balancer Name")).toEqual(lbName);
                expect(ordersPage.getTextBasedOnLabelName("Load Balancer Location")).toEqual(jsonUtil.getValue(orderObject, "Load Balancer Location"));
                expect(ordersPage.getTextBasedOnLabelName("Load Balancer Type")).toEqual(jsonUtil.getValue(orderObject, "Load Balancer Type"));
                expect(ordersPage.getTextBasedOnLabelName("SKU")).toEqual(jsonUtil.getValue(orderObject, "SKU"));
                expect(ordersPage.getTextBasedOnExactLabelName("Public IP Address")).toEqual(jsonUtil.getValue(orderObject, "Public Ip Address"));
                expect(ordersPage.getTextBasedOnExactLabelName("Public IP Address Assignment")).toEqual(jsonUtil.getValue(orderObject, "Public Ip Address Assignment"));
                expect(ordersPage.getTextBasedOnExactLabelName("New Public IP Name")).toEqual(pipName);
                expect(ordersPage.getTextBasedOnExactLabelName("Frontend IP Configuration Name")).toEqual(frontendIPConfigurationName);
                expect(ordersPage.getTextBasedOnExactLabelName("Backend Pool Name")).toEqual(backendPoolName);
                expect(ordersPage.getTextBasedOnExactLabelName("Health Probe Name")).toEqual(healthProbeName);
                expect(ordersPage.getTextBasedOnExactLabelName("Health Probe Protocol")).toEqual(jsonUtil.getValue(orderObject, "Health Probe Protocol"));
                expect(ordersPage.getTextBasedOnExactLabelName("Health Probe Port")).toEqual(jsonUtil.getValue(orderObject, "Health Probe Port"));
                expect(ordersPage.getTextBasedOnExactLabelName("Health Probe Interval")).toEqual(jsonUtil.getValue(orderObject, "Health Probe Interval"));
                expect(ordersPage.getTextBasedOnExactLabelName("Health Probe Unhealthy Threshold")).toEqual(jsonUtil.getValue(orderObject, "Health Probe Unhealthy Threshold"));
                //Checking Bill Of Material
                if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
                }
                ordersPage.clickServiceDetailSliderCloseButton();  
        });
});
