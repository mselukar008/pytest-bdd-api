"use strict";
var UserAccsmangmntPage = require('../../../pageObjects/userAccessManagement.pageObject.js'),
    AccountsPage = require('../../../pageObjects/account.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
    Orders = require('../../../pageObjects/orders.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    testEnvironment = browser.params.url.includes("cb-qa-2") ? "QA 2" : browser.params.url.includes("customer1") ? "Customer 1" : "QA 4",
    userAccessData = require('../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
    persistentDiskTemplate = require('../../../../testData/OrderIntegration/Google/persistentdisk.json'),
    userCredentialsTemplate = require('../../../../testData/credentials.json'),
    userManagementDataTemplate = require('../../../../testData/OrderIntegration/Google/userManagement.json');

describe('GCP - User Access Management', function () {
    var userAccsMangmntPage, accountPage, ordersPage, catalogPage, placeOrderPage, cartListPage, teamName, teamId, userCredntialsObject;
    var modifiedParamMap = {};
    beforeAll(function () {
        userAccsMangmntPage = new UserAccsmangmntPage();
        accountPage = new AccountsPage();
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        cartListPage = new CartListPage();
        userCredntialsObject = JSON.parse(JSON.stringify(userCredentialsTemplate));
        //userAccessDataObject = JSON.parse(JSON.stringify(userAccessData));
        // browser.driver.manage().window().maximize();
    });
    var msgString = {
        userName: userAccessData.userName,
        userAddedMsg: userManagementDataTemplate.userAddedMsg,
        userUnassignedMsg: userManagementDataTemplate.userUnassignedMsg,
        completedState: persistentDiskTemplate.completedState,
        orderTypeDelete: persistentDiskTemplate.orderTypeDel,
        providerAccount1: userManagementDataTemplate.providerAccount1,
        providerAccount2: userManagementDataTemplate.providerAccount2,
        assignRoles: userManagementDataTemplate.assignRoles,
        unassignRoles: userManagementDataTemplate.unassignRoles,
        organization: userManagementDataTemplate.organization,
        teamName: userManagementDataTemplate.teamName,
        teamid: userManagementDataTemplate.teamid,
        updatedTeamName: userManagementDataTemplate.newTeamName,
        teamUpdatedMsg: userManagementDataTemplate.teamUpdatedMsg,
        teamAddedMsg: userManagementDataTemplate.teamAddedMsg,
        contxtAddedMsg: userManagementDataTemplate.orgContextAdded,
        superUserUsername: userCredentialsTemplate.superUserID,
        superUserPassword: userCredentialsTemplate.superUserPassword,

    };

    xit('TC : GCP - User Access Management- Add New Context Value', function () {

        var contextIdEnv = "env-" + util.getRandomString(3);
        var contxtNameEnv = "env-" + util.getRandomString(3);
        var contextIdApp = "app-" + util.getRandomString(3);
        var contxtNameApp = "app-" + util.getRandomString(3);
        var contextDetails1 = { "Context Type": "Environment", "Context Value Name": contxtNameEnv, "Context Value ID": contextIdEnv };
        var contextDetails2 = { "Context Type": "Application", "Context Value Name": contxtNameApp, "Context Value ID": contextIdApp };
        orderFlowUtil.closeHorizontalSliderIfPresent();
        catalogPage.open();
//         catalogPage.getUserID(userCredentialsTemplate.superUserName).then(function (status) {
//             if (status != true) {
//                 cartListPage.clickUserIcon();
//                 cartListPage.clickLogoutButton();
//                 cartListPage.loginFromOtherUser(userCredentialsTemplate.superUserUsername, userCredentialsTemplate.superUserPassword);
//                 catalogPage.open();
//                 expect(catalogPage.getUserID(userCredentialsTemplate.superUserName)).toBe(true);
//             }
//         });
        userAccsMangmntPage.openContextTypes();
        //userAccsMangmntPage.clickContextValueLink();
        //add new environment
        userAccsMangmntPage.clickAddnewContextValue();
        userAccsMangmntPage.setNewContextValueDetails(contextDetails1);
        expect(userAccsMangmntPage.getNotificationMsg()).toContain(contxtNameEnv + msgString.contxtAddedMsg);
        //Verify COntext values details for environment       
        //Using search function of team for searching context
        userAccsMangmntPage.clickSearchBtn();
        userAccsMangmntPage.searchContextType(contxtNameEnv);
        expect(userAccsMangmntPage.verifyContexts(contextIdEnv, contxtNameEnv)).not.toEqual(false);
        //Delete Context
        userAccsMangmntPage.deleteEntity();
        catalogPage.open();
        userAccsMangmntPage.openContextTypes();
        //Add new application
        userAccsMangmntPage.clickAddnewContextValue();
        userAccsMangmntPage.setNewContextValueDetails(contextDetails2);
        //Verify Context values details for application
        userAccsMangmntPage.clickSearchBtn();
        userAccsMangmntPage.searchContextType(contxtNameApp);
        expect(userAccsMangmntPage.verifyContexts(contextIdApp, contxtNameApp)).not.toEqual(false);
        userAccsMangmntPage.deleteEntity();

    });

    xit('TC : GCP - User Access Management- Add/Delete Organization', function () {
        var organizName = "m-" + util.getRandomString(7);
        var organizId = "t-" + util.getRandomString(5);

        modifiedParamMap = { "Organization Id": organizId, "Organization Name": organizName, "Organization Description": "Automation organization" };

        userAccsMangmntPage.open();
        userAccsMangmntPage.clickOrganizationsLink();
        userAccsMangmntPage.clickAddNewOrganization();
        userAccsMangmntPage.setNewOrganizationDetails(modifiedParamMap);
        userAccsMangmntPage.clickCreateOrganizn();
        expect(userAccsMangmntPage.getNotificationMsg()).toContain(userManagementDataTemplate.orgContextAdded);
        userAccsMangmntPage.clickSearchBtn();
        userAccsMangmntPage.searchTeam(organizName).then(function () {
            //Validate newly added Organization
            expect(userAccsMangmntPage.validateNewOrganizationDetails(organizName, organizId)).toEqual(true);
            userAccsMangmntPage.clickActionBtn("Organization");
            userAccsMangmntPage.clickDeleteBtn("Organization");
            userAccsMangmntPage.clickOrgCnfrmDeleteBtn();
            expect(userAccsMangmntPage.getNotificationMsg()).toContain(userManagementDataTemplate.orgContextDeleted);
        });
    });

    it('TC : GCP - User Access Management- Add New Team', function () {

        // teamName = "m" + util.getRandomString(5) + msgString.teamName;
        // teamId = "m" + util.getRandomString(3) + msgString.teamid;
        teamName = "Auto-TEAM1";
        teamId = "Auto-TEAM1";

        var updatedTeamName = "m" + util.getRandomString(3) + msgString.updatedTeamName;
        modifiedParamMap = { "Team Id": teamId, "Team Name": teamName, "Organization": msgString.organization };
        userAccsMangmntPage.open();
        userAccsMangmntPage.clickTeamsLink();
        var roles = msgString.assignRoles;
        userAccsMangmntPage.clickAddNewTeam();
        userAccsMangmntPage.setNewTeamDetails(modifiedParamMap);
        userAccsMangmntPage.clickUpdate();
        //Validate Success Msg
        expect(userAccsMangmntPage.teamUpdatedmsg()).toContain(msgString.teamAddedMsg);
        userAccsMangmntPage.navigateTeamPage();
        userAccsMangmntPage.clickSearchBtn();
        userAccsMangmntPage.searchTeam(teamName);
        //Validate newly added team
        expect(userAccsMangmntPage.validateNewTeamDetails(teamName, teamId)).toEqual(true);
        //Select newly created team and edit its name
        userAccsMangmntPage.clickViewDetailsTeam();
        userAccsMangmntPage.clickEditBtn();
        userAccsMangmntPage.setUpdatedTeamNameTextbox(updatedTeamName);//.then(function(){
        userAccsMangmntPage.clickUpdateTeamBtn();
        expect(userAccsMangmntPage.teamUpdatedmsg()).toContain(msgString.teamUpdatedMsg);
        //});
        //Validate updated team
        userAccsMangmntPage.navigateTeamPage();
        userAccsMangmntPage.clickSearchBtn();
        userAccsMangmntPage.searchTeam(updatedTeamName);
        expect(userAccsMangmntPage.validateNewTeamDetails(updatedTeamName, teamId)).toEqual(true);
        //Revert team name to original team name.
        userAccsMangmntPage.clickViewDetailsTeam();
        userAccsMangmntPage.clickEditBtn();
        //Edit team name
        userAccsMangmntPage.setUpdatedTeamNameTextbox(teamName);
        userAccsMangmntPage.clickUpdateTeamBtn();

        expect(userAccsMangmntPage.teamUpdatedmsg()).toEqual(msgString.teamUpdatedMsg);
        userAccsMangmntPage.AddMultipleRolesForTeam(roles);
        //Validate all roles are added
        expect(userAccsMangmntPage.validateNewlyAddedRoles(roles)).toEqual(true);
        // userAccsMangmntPage.clickUserTab();

        userAccsMangmntPage.addNewuser("transfer");
        expect(userAccsMangmntPage.getTextUserAdded()).toContain(msgString.userAddedMsg);

        userAccsMangmntPage.clickFirstTeamRoleActionIcon();
        userAccsMangmntPage.clickFirstTeamRoleViewDetailBtn();

        // validate Buyer role contexts details
        expect(userAccsMangmntPage.getTextBasedOnContextLabelName("Team")).toContain(teamName);
        expect(userAccsMangmntPage.getTextBasedOnContextLabelName("Organization")).toContain(msgString.organization);
        expect(userAccsMangmntPage.getTextBasedOnContextLabelName("Environment")).toContain(userManagementDataTemplate.contextEnvValue);
        expect(userAccsMangmntPage.getTextBasedOnContextLabelName("Application")).toContain(userManagementDataTemplate.contextAppValue);
        userAccsMangmntPage.clickClose();


    });
    //Skipping this test as it required provider secret credentials which can not be stored on git.
    xit('TC : GCP - User Access Management- Provision Service using newly Created Team', async function () {

        //Update Provider Account with Newly created team
        var orderObject = {};
        //Login using Transfer cart user
        catalogPage.open();
        orderFlowUtil.closeHorizontalSliderIfPresent();
        //cartListPage.clickUserIcon();
        //cartListPage.clickLogoutButton().then(function () {
        await cartListPage.loginFromOtherUser(userCredntialsObject.transferCartUser, userCredntialsObject.transferCartPwd);
        //});
        catalogPage.open();
        accountPage.updateTeam(msgString.providerAccount1, teamName);
        //userAccsMangmntPage.clickSaveProviderDeatailsBtn();            
        //delete persistentDiskTemplate["Order Parameters"]["Configure Add-ons"];   

        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderOrCategoryCheckbox(persistentDiskTemplate.provider);
        catalogPage.clickProviderOrCategoryCheckbox(persistentDiskTemplate.Category);
        var serviceName = "aut0-disk-ua-" + util.getRandomString(3);
        modifiedParamMap = { "Service Instance Name": serviceName, "Team": teamId, "Provider Account": "" };
        catalogPage.clickConfigureButtonBasedOnName(persistentDiskTemplate.bluePrintName);
        orderObject.servicename = serviceName;
        global.serviceName = serviceName;
        // delete persistentDiskTemplate["Order Parameters"]["Configure Add-ons"];
        orderFlowUtil.fillOrderDetails(persistentDiskTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, msgString.completedState);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(msgString.completedState);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == msgString.completedState) {
                //Edit service flow
                //var editInsObject = JSON.parse(JSON.stringify(persistentDiskEditTemplate));
                var modifiedParamMap = { "Service Instance Name": "", "Instance Name": "", "EditService": true, "Size (GB)": "70" };
                orderFlowUtil.editService(orderObject);
                orderFlowUtil.fillOrderDetails(persistentDiskTemplate, modifiedParamMap).then(function () {
                    browser.sleep(5000);
                });
                placeOrderPage.submitOrder();
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, msgString.completedState);
                orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                    if (status == msgString.completedState) {
                        //Verify updated details are reflected on order details apge.                       
                        ordersPage.clickFirstViewDetailsOrdersTable();
                        expect(ordersPage.getTextBasedOnLabelName("Size (GB)")).toEqual(modifiedParamMap["Size (GB)"]);
                        //Delete Service flow
                        orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                        expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(msgString.orderTypeDelete);
                        orderFlowUtil.approveDeletedOrder(orderObject);
                        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, msgString.completedState);
                        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(msgString.completedState);
                    }
                });
            }
        });
    });

    xit('TC : GCP - User Access Management- Unassign user from Team', async function () {

        msgString.userName = "transfer Cart";
        orderFlowUtil.closeHorizontalSliderIfPresent();
        catalogPage.open();
        catalogPage.getUserID(userCredentialsTemplate.superUserName).then(async function (status) {
            if (status != true) {
                //cartListPage.clickUserIcon();
                //cartListPage.clickLogoutButton();
                await cartListPage.loginFromOtherUser(msgString.superUserUsername, msgString.superUserPassword);
                catalogPage.open();
                expect(catalogPage.getUserID(userCredentialsTemplate.superUserName)).toBe(true);
            }

            userAccsMangmntPage.open();
            userAccsMangmntPage.clickTeamsLink();
            userAccsMangmntPage.clickSearchBtn();
            userAccsMangmntPage.searchTeam(teamName);
            // expect(userAccsMangmntPage.validateNewTeamDetails(teamNameNew, teamId)).toEqual(true);
            //Unassign user
            userAccsMangmntPage.clickViewDetailsTeam();
            userAccsMangmntPage.unassignUser(msgString.userName);
            //Validate Success Message
            expect(userAccsMangmntPage.getNotificationMsgInsideFrame()).toContain(msgString.userUnassignedMsg);
            //Assign user back
            //userAccsMangmntPage.navigateTeamPage();
            // userAccsMangmntPage.open();
            // userAccsMangmntPage.clickTeamsLink();
            // userAccsMangmntPage.searchTeam(teamName);
            // userAccsMangmntPage.clickViewDetailsTeam();
            // userAccsMangmntPage.addNewuser(msgString.userName);
            // //Validate Success Message
            // expect(userAccsMangmntPage.getNotificationMsg()).toContain(msgString.userAddedMsg);
        });

    });

    xit('TC : GCP - User Access Management- Unassign roles from Team', function () {

        orderFlowUtil.closeHorizontalSliderIfPresent();
        userAccsMangmntPage.open();
        var roles = msgString.assignRoles;
        userAccsMangmntPage.clickTeamsLink();
        userAccsMangmntPage.clickSearchBtn();
        userAccsMangmntPage.searchTeam(teamName);
        expect(userAccsMangmntPage.validateNewTeamDetails(teamName, teamId)).toEqual(true);

        //Unassign roles        
        userAccsMangmntPage.clickViewDetailsTeam();
        userAccsMangmntPage.unassignRolesFromTeam(roles);
        expect(userAccsMangmntPage.validateUnassignedRoles(roles)).toEqual(true);
        //Assign back roles
        // userAccsMangmntPage.AddMultipleRolesForTeam(roles);
        // expect(userAccsMangmntPage.validateNewlyAddedRoles(roles)).toEqual(true);
        //Update TEAM
        //catalogPage.open();        
        //accountPage.updateTeam(msgString.providerAccount1, "TEAM1");
        // userAccsMangmntPage.clickSaveProviderDeatailsBtn();
        //Delete Team        
        userAccsMangmntPage.open();
        userAccsMangmntPage.clickTeamsLink();
        userAccsMangmntPage.clickSearchBtn();
        userAccsMangmntPage.searchTeam(teamName);
        userAccsMangmntPage.clickActionBtn("Team");
        userAccsMangmntPage.clickDeleteBtn("Team");
        // Check if valid team is getting deleted
        userAccsMangmntPage.getTeamName(teamName).then(function(deleteTeam){
            if(deleteTeam){
                userAccsMangmntPage.clickCnfrmDeleteBtn("Team");
                expect(userAccsMangmntPage.getNotificationMsg()).toContain(userManagementDataTemplate.orgContextDeleted);
            }else{
                userAccsMangmntPage.clickCancelBtn()
            }
            expect(deleteTeam).toBe(true)           
        }) 

    });
    
    afterAll(function () {		
        global.serviceName = undefined;
 	});

})
