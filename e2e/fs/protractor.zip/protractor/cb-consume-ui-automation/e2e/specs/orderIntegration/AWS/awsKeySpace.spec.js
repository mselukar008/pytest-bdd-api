"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    keySpaceTemplate = require('../../../../testData/OrderIntegration/AWS/awsKeyspace.json');

describe('AWS - KeySpace', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, tableName, keySpaceName, keySpaceObj, inventoryPage, msgToVerify;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = keySpaceTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Databases',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-keySpace-" + util.getRandomString(5);
        tableName = "table" + util.getRandomString(5);
        keySpaceName = "keyspace" + util.getRandomString(5);
    });

    beforeEach(function () {
        modifiedParamMap = { "Service Instance Name": serviceName, "Table name": tableName, "Keyspace name": keySpaceName };
    });

    it('AWS-KeySpaces - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        catalogPage.open();
        keySpaceObj = JSON.parse(JSON.stringify(keySpaceTemplate));
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(keySpaceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(keySpaceTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(keySpaceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(keySpaceTemplate.TotalCost); expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            }
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Keyspace name"]).toEqual(keySpaceName);
            expect(requiredReturnMap["Actual"]["Table name"]).toEqual(tableName);
            expect(requiredReturnMap["Actual"]["Column name"]).toEqual(requiredReturnMap["Expected"]["Column name"]);
            expect(requiredReturnMap["Actual"]["Column type"]).toEqual(requiredReturnMap["Expected"]["Column type"]);
            expect(requiredReturnMap["Actual"]["Capacity mode"]).toEqual(requiredReturnMap["Expected"]["Capacity mode"]);

            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(keySpaceTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                if (browser.params.defaultCurrency == "USD") {
                    //Validate Estimated price on approve order page
                    expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(keySpaceTemplate.EstimatedPrice);
                    //Validate pricing on order history page
                    ordersHistoryPage.open();
                    ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                    expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(keySpaceTemplate.EstimatedPrice);
                }
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();

            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(keySpaceObj, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Keyspace name")).toEqual(keySpaceName);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Table name")).toEqual(tableName);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Column name")).toEqual(jsonUtil.getValue(keySpaceObj, "Column name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Column type")).toEqual(jsonUtil.getValue(keySpaceObj, "Column type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Capacity mode")).toEqual(jsonUtil.getValue(keySpaceObj, "Capacity mode"));
            if (browser.params.defaultCurrency == "USD") {
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(keySpaceTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(keySpaceTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
            }

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.clickAllOrdersUnderOrdersSection();
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(keySpaceObj, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("Keyspace name")).toEqual(keySpaceName);
            expect(ordersPage.getTextBasedOnLabelName("Table name")).toEqual(tableName);
            expect(ordersPage.getTextBasedOnLabelName("Column name")).toEqual(jsonUtil.getValue(keySpaceObj, "Column name"));
            expect(ordersPage.getTextBasedOnLabelName("Column type")).toEqual(jsonUtil.getValue(keySpaceObj, "Column type"));
            expect(ordersPage.getTextBasedOnLabelName("Capacity mode")).toEqual(jsonUtil.getValue(keySpaceObj, "Capacity mode"));
            if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(keySpaceTemplate.TotalCost);
            }
            ordersPage.clickServiceDetailSliderCloseButton();
            if (isDummyAdapterDisabled == "true") {
                orderObject.componentType = keySpaceTemplate.componentType1;
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.clickOverflowACtionBtnBasedOnComponent(keySpaceTemplate.componentType1).then(function () {
                        inventoryPage.clickViewComponentofAWSInstance().then(function () {
                            //View Component VM details
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(keySpaceTemplate.componentType1);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelName("Name")).toEqual(keySpaceName);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);

                            //View Component Template Output Properties
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("TableName")).toEqual(tableName);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("KeyspaceName")).toContain(keySpaceName);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("BillingMode")).toContain(jsonUtil.getValue(keySpaceObj, "Capacity mode"));

                            inventoryPage.closeViewComponent();
                            inventoryPage.clickExpandFirstRow();
                        });
                    });
                });
            };

            //Delete Service flow                    
            //orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
            orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, keySpaceTemplate.bluePrintName);
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
        });
    });

});
