/*
Spec_Name: notificationHub.spec.js 
Description: This spec will cover E2E testing of Notification Hub service order submit, approve, edit and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../../testData/appUrls.json'),
        util = require('../../../../helpers/util.js'),
        jsonUtil = require('../../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        NHTemplate = require('../../../../testData/OrderIntegration/Azure/nh.json');

describe('Azure - Notification Hub', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, cartListPage, catalogDetailsPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Other Services', disabledState: NHTemplate.disabledState };
        var modifiedParamMapedit = {};
        var servicename = "AutoNHsrv" + util.getRandomString(5);
        var SOIComponents;

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                cartListPage = new CartListPage();
                catalogDetailsPage = new CatalogDetailsPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        });

        afterAll(function () {
                // Delete Notification Hub
                var returnObj = {};
                returnObj.servicename = servicename;
                returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                orderFlowUtil.approveDeletedOrder(returnObj);
                orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        });

        //E2E Notification Hub order Submit, Approve, Edit,  Delete Service with new Resource Group.
        if (isProvisioningRequired == "true") {
                it('Azure: T393911-Sanity Verify that for Notification Hub Service,if service is created with new resource group with valid name and location,create valid Notification Hub name enter valid Namespace Name, select Namespace Location and Pricing Tier', function () {
                        var orderObject = JSON.parse(JSON.stringify(NHTemplate));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.searchForBluePrint(orderObject.bluePrintName);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};
                        var returnObj1 = {};
                        var rgName = "gslautotc_azure_nhRG" + util.getRandomString(5);
                        var nsName = "autoNS" + util.getRandomString(5);
                        var nhName = "autoNH" + util.getRandomString(5);
                        SOIComponents = [nhName, nsName]
                        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Notification Hub Name": nhName, "New Namespace Name": nsName };
                        orderFlowUtil.fillOrderDetails(NHTemplate, modifiedParamMap);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj);
                        //expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe('Provisioning in Progress');
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Checking Inventory Page Service Configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Notification Hub Name:")).toEqual(nhName);
                        expect(inventoryPage.getTextBasedOnLabelName(" New Namespace Name:")).toEqual(nsName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Namespace Location:")).toEqual(jsonUtil.getValue(orderObject, "Namespace Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Namespace Pricing Tier:")).toEqual(jsonUtil.getValue(orderObject, "Namespace Pricing Tier"));
                        inventoryPage.closeViewDetailsTab();
                        //Checking SOI Components
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.clickExpandFirstRow().then(function () {
                                        browser.executeScript('window.scrollTo(0,0);');
                                        var i = 1;
                                        async.forEachSeries(SOIComponents, function (component, callback) {
                                                util.waitForAngular();
                                                inventoryPage.clickOverMenuIcon(i).then(function () {
                                                        inventoryPage.clickOnViewComponent(i).then(function () {
                                                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.mcmpTag);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.bluePrintName);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                                                inventoryPage.closeViewComponent();
                                                                browser.sleep(10000);
                                                                i++;
                                                                return callback();
                                                        });
                                                })
                                        }, function (error) {
                                                if (error) {
                                                        logger.info('Unable to Get SOI component')
                                                }
                                        })
                                })
                        }
                        //Editing Notification Hub Namespace Service
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                        inventoryPage.clickEditServiceIcon();
                        //Validate if main parameters are disabled during edit service
                        expect(cartListPage.isEnabledInstancePrefixTextbox()).toMatch(messageStrings.disabledState);
                        expect(cartListPage.isDisplayedEnvDropdown()).toBe(false);
                        expect(cartListPage.isDisplayedAppDropdown()).toBe(false);
                        expect(cartListPage.isDisplayedTeamRadioButton()).toBe(false);
                        expect(cartListPage.isDisabledProviderAccount()).toBe(true);
                        modifiedParamMapedit = { "Service Instance Name": servicename, "EditService": true };
                        orderFlowUtil.fillOrderDetails(NHTemplate, modifiedParamMapedit);
                        expect(placeOrderPage.getTextBasedOnLabelName(" Namespace Pricing Tier:")).toContain(jsonUtil.getValueEditParameter(orderObject, "Namespace Pricing Tier"));
                        placeOrderPage.submitOrder();
                        returnObj1.servicename = servicename;
                        returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        //Get details on pop up after submit
                        var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        var orderprice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                        var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        //Open Order page and Approve Order 
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj1);
                        orderFlowUtil.waitForOrderStatusChange(returnObj1, "Completed", 50);
                        orderFlowUtil.verifyOrderStatus(returnObj1).then(function (status) {
                                if (status == 'Completed') {
                                        // check edited value on View Details
                                        ordersPage.clickFirstViewDetailsOrdersTable();
                                        ordersPage.clickServiceConfigurationsTabOrderDetails();
                                        expect(ordersPage.getTextBasedOnExactLabelName("Namespace Pricing Tier")).toEqual(jsonUtil.getValueEditParameter(orderObject, "Namespace Pricing Tier"));
                                }
                        })
                        inventoryPage.open();
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        inventoryPage.clickOnInstanceTableActionIcon();
                        inventoryPage.clickViewService();

                        // check Edited value on Inventory
                        expect(inventoryPage.getTextBasedOnLabelName(" Namespace Pricing Tier:")).toEqual(jsonUtil.getValueEditParameter(orderObject, "Namespace Pricing Tier"));
                        inventoryPage.closeViewDetailsTab();

                });
        }

        //Checking parameters on Main Parameters page
        it('Azure: TC-T379402 verify that for Notification Hub Service all parameters on Main Parameters Page are present.', function () {
                var orderObject = JSON.parse(JSON.stringify(NHTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.searchForBluePrint(orderObject.bluePrintName);
                catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
                if (browser.params.defaultCurrency == "USD") {
                expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
                }
        });

        //Checking values all parameters on Review Order Page and View Order Details
        it('Azure: TC-T379412 verify that for Notification Hub Service all values on Review Order Page and View Order Details page matches with input.', function () {
                var rgName = "gslautotc_azure_nhRG" + util.getRandomString(5);
                var nsName = "autoNS" + util.getRandomString(5);
                var nhName = "autoNH" + util.getRandomString(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Notification Hub Name": nhName, "New Namespace Name": nsName };
                var returnObj = {};
                returnObj.servicename = servicename;
                var orderObject = JSON.parse(JSON.stringify(NHTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.searchForBluePrint(orderObject.bluePrintName);
                catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(NHTemplate, modifiedParamMap);
                //Checking Service Details in ReviewOrder
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
                if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
                }
                //Checking Additional Details in ReviewOrder
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Notification Hub Name:")).toEqual(nhName);
                expect(placeOrderPage.getTextBasedOnLabelName(" New Namespace Name:")).toEqual(nsName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Namespace Location:")).toEqual(jsonUtil.getValue(orderObject, "Namespace Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Namespace Pricing Tier")).toEqual(jsonUtil.getValue(orderObject, "Namespace Pricing Tier"));
                placeOrderPage.submitOrder();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                ordersPage.open();
                ordersPage.searchOrderById(returnObj.orderNumber);
                ordersPage.clickFirstViewDetailsOrdersTable();
                //Checking Order Details in View order details
                expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
                //Checking Service Configuration Parameters
                ordersPage.clickServiceConfigurationsTabOrderDetails();
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
                expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Notification Hub Name")).toEqual(nhName);
                expect(ordersPage.getTextBasedOnExactLabelName("New Namespace Name")).toEqual(nsName);
                expect(ordersPage.getTextBasedOnExactLabelName("Namespace Location")).toEqual(jsonUtil.getValue(orderObject, "Namespace Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Namespace Pricing Tier")).toEqual(jsonUtil.getValue(orderObject, "Namespace Pricing Tier"));
                //Checking Bill Of Material
                if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
                }
                ordersPage.clickServiceDetailSliderCloseButton();
        });
});
