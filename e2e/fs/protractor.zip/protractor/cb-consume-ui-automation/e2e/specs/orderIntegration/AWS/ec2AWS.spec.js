"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../testData/appUrls.json'),
    imiUtil = require('../../../../helpers/imiApiUtil.js'),
    shoppingCartTemplate = require('../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
    imiConfigTemplate = require('../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    ec2InstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSEC2Instance.json');

describe('AWS - EC2', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, EC2INSObject, inventoryPage, msgToVerify;
    var adapterName = "Real";
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = ec2InstanceTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Compute',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        powerStateOff: "Stopped",
        powerStateOn: "On",
        orderTypeAction: "Action",
        turnOnNegativeWarning: shoppingCartTemplate.turnOnNegativeWarning,
        turnOffNegativeWarning: shoppingCartTemplate.turnOffNegativeWarning,
        rebootNegativeWarning: shoppingCartTemplate.rebootNegativeWarning,
        turnOffNegativeWarningRealAdapter: "Turn OFF action cannot be performed in Stopped status.",
        rebootNegativeWarningrealAdapter: "Reboot action cannot be performed in Stopped status.",
        serviceOfferingTurnOff: "Turn OFF",
        serviceOfferingTurnOn: "Turn ON",
        serviceOfferingReboot: "Reboot",
        instanceName: ec2InstanceTemplate.instanceName,
        componentType: ec2InstanceTemplate.componentType,
        Imageid: ec2InstanceTemplate.Imageid,
        Instancetype: ec2InstanceTemplate.Instancetype,
        Keyname: ec2InstanceTemplate.Keyname,
        Subnetid: ec2InstanceTemplate.Subnetid,
        Architecture: ec2InstanceTemplate.Architecture,
        Vpcid: ec2InstanceTemplate.Vpcid,
        Virtualizationtype: ec2InstanceTemplate.Virtualizationtype,
        bomItem1: "OnDemand Compute Instance t2.small",
        bomItem2: imiConfigTemplate.bomItem2,
        bomItem3: imiConfigTemplate.bomItem3,
        imiOrderSubmitted: "Configure IMI Managed Service",
        isDummyTagValue: 'Yes',
        systemTagText: "ibm_mcmp_soiid"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-ec2-" + util.getRandomString(5);
    });

    beforeEach(function () {
        var groupName = "att-group-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Group Name": groupName };
    });

    if (browser.params.defaultCurrency == "USD") {
        it('AWS-EC2-Verify Pricing for Multiquantity instance on review Order page', function () {
            modifiedParamMap = { "Service Instance Name": serviceName, "Quantity": "2" };
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
            catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);
            //Fill Order Details
            orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
                //Validate Pricing is updated as per quantity            
                var qunatity = parseInt(modifiedParamMap["Quantity"]);
                var pricingOfOneInstance = ec2InstanceTemplate.TotalCost;
                pricingOfOneInstance = parseFloat(pricingOfOneInstance.replace("USD ", ""));
                var totalPriceAsPerQuantity = qunatity * pricingOfOneInstance;
                expect(placeOrderPage.getBOMTablePriceOnReviewOrder()).toBe("USD " + totalPriceAsPerQuantity).toString();
            });
        });
    }

    it('AWS-EC2 - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        catalogPage.open();
        EC2INSObject = JSON.parse(JSON.stringify(ec2InstanceTemplate));
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(ec2InstanceTemplate.TotalCost);
                //BOM Validation as per components of service.
                expect(placeOrderPage.validateBOMOnReviewOrderPage(ec2InstanceTemplate.Pricing)).toBe(true);
            }
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Resource Name"]).toEqual(requiredReturnMap["Expected"]["Resource Name"]);
            expect(requiredReturnMap["Actual"]["Instance Type"]).toEqual(requiredReturnMap["Expected"]["Instance Type"]);
            expect(requiredReturnMap["Actual"]["Availability Zone"]).toEqual(requiredReturnMap["Expected"]["Availability Zone"]);
            expect(requiredReturnMap["Actual"]["IAM Role"]).toEqual(requiredReturnMap["Expected"]["IAM Role"]);
            expect(requiredReturnMap["Actual"]["Shutdown Behavior"]).toEqual(requiredReturnMap["Expected"]["Shutdown Behavior"]);
            expect(requiredReturnMap["Actual"]["Enable Termination Protection"]).toEqual(jsonUtil.getValue(EC2INSObject, "Enable Termination Protection"));
            expect(requiredReturnMap["Actual"]["T2/T3 Unlimited"]).toEqual(requiredReturnMap["Expected"]["T2/T3 Unlimited"]);
            expect(requiredReturnMap["Actual"]["Key Pair"]).toEqual(requiredReturnMap["Expected"]["Key Pair"]);
            expect(requiredReturnMap["Actual"]["User Data"]).toEqual(requiredReturnMap["Expected"]["User Data"]);
            expect(requiredReturnMap["Actual"]["Size (GiB)"]).toEqual(requiredReturnMap["Expected"]["Size"]);
            expect(requiredReturnMap["Actual"]["Volume Type"]).toEqual(requiredReturnMap["Expected"]["Volume Type"]);
            expect(requiredReturnMap["Actual"]["IOPS"]).toEqual(requiredReturnMap["Expected"]["IOPS"]);
            expect(requiredReturnMap["Actual"]["Search By"]).toEqual(requiredReturnMap["Expected"]["Search By"]);
            expect(requiredReturnMap["Actual"]["Self Image"]).toEqual(requiredReturnMap["Expected"]["Self Image"]);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                if (browser.params.defaultCurrency == "USD") {
                    //Validate Estimated price on approve order page
                    expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(ec2InstanceTemplate.EstimatedPrice);
                    //Validate pricing on order history page
                    ordersHistoryPage.open();
                    ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                    expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(ec2InstanceTemplate.EstimatedPrice);
                }
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();

            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Resource Name")).toEqual(jsonUtil.getValue(EC2INSObject, "Resource Name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Search By")).toEqual(jsonUtil.getValue(EC2INSObject, "Search By"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Self Image")).toEqual(jsonUtil.getValue(EC2INSObject, "Self Image"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Availability Zone")).toEqual(jsonUtil.getValue(EC2INSObject, "Availability Zone"));
            // expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC Creation Mode")).toEqual(jsonUtil.getValue(EC2INSObject, "VPC Creation Mode"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("IAM Role")).toEqual(jsonUtil.getValue(EC2INSObject, "IAM Role"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Shutdown Behavior")).toEqual(jsonUtil.getValue(EC2INSObject, "Shutdown Behavior"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Enable Termination Protection")).toEqual(jsonUtil.getValue(EC2INSObject, "Enable Termination Protection"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Monitoring")).toEqual(jsonUtil.getValue(EC2INSObject, "Monitoring"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(EC2INSObject, "T2/T3 Unlimited"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Key Pair")).toEqual(jsonUtil.getValue(EC2INSObject, "Key Pair"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("SSH Location")).toEqual(jsonUtil.getValue(EC2INSObject, "SSH Location"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("User Data")).toEqual(jsonUtil.getValue(EC2INSObject, "User Data"));

            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Size (GiB)")).toEqual(jsonUtil.getValue(EC2INSObject, "Size"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Volume Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Volume Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("IOPS")).toEqual(jsonUtil.getValue(EC2INSObject, "IOPS"));
            //    expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(EC2INSObject, "Encryption"));
            if (browser.params.defaultCurrency == "USD") {
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(ec2InstanceTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(ec2InstanceTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
            }
            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            //orderFlowUtil.waitForOrderStatusChange(orderObject, 'Approval In Progress');
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            //expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
            //expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            // util.waitForAngular();
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("Resource Name")).toEqual(jsonUtil.getValue(EC2INSObject, "Resource Name"));
            expect(ordersPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            expect(ordersPage.getTextBasedOnLabelName("Availability Zone")).toEqual(jsonUtil.getValue(EC2INSObject, "Availability Zone"));
            expect(ordersPage.getTextBasedOnLabelName("IAM Role")).toEqual(jsonUtil.getValue(EC2INSObject, "IAM Role"));
            expect(ordersPage.getTextBasedOnLabelName("Shutdown Behavior")).toEqual(jsonUtil.getValue(EC2INSObject, "Shutdown Behavior"));
            expect(ordersPage.getTextBasedOnLabelName("Enable Termination Protection")).toEqual(jsonUtil.getValue(EC2INSObject, "Enable Termination Protection"));
            expect(ordersPage.getTextBasedOnLabelName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(EC2INSObject, "T2/T3 Unlimited"));
            expect(ordersPage.getTextBasedOnLabelName("Key Pair")).toEqual(jsonUtil.getValue(EC2INSObject, "Key Pair"));
            expect(ordersPage.getTextBasedOnLabelName("User Data")).toEqual(jsonUtil.getValue(EC2INSObject, "User Data"));
            expect(ordersPage.getTextBasedOnLabelName("Size (GiB)")).toEqual(jsonUtil.getValue(EC2INSObject, "Size"));
            expect(ordersPage.getTextBasedOnLabelName("Volume Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Volume Type"));
            expect(ordersPage.getTextBasedOnLabelName("IOPS")).toEqual(jsonUtil.getValue(EC2INSObject, "IOPS"));
            expect(ordersPage.getTextBasedOnLabelName("Search By")).toEqual(jsonUtil.getValue(EC2INSObject, "Search By"));
            expect(ordersPage.getTextBasedOnLabelName("Self Image")).toEqual(jsonUtil.getValue(EC2INSObject, "Self Image"));
            if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(ec2InstanceTemplate.TotalCost);
            }
            ordersPage.clickServiceDetailSliderCloseButton();
        });
    });

    if (isProvisioningRequired == "true") {

        if (isDummyAdapterDisabled == "true") {
            it('AWS-EC2-- Verify View Component-Template Output Parameters for the powered ON instance', function () {

                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                        inventoryPage.clickViewComponentofAWSInstance().then(function () {
                            //View Component VM details
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(messageStrings.componentType);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelName("Name")).toEqual(messageStrings.instanceName);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Status")).toEqual(messageStrings.powerStateOn);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);

                            //View Component Template Output Properties
                            //expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Keyname")).toEqual(messageStrings.Keyname);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("InstanceType")).toContain(messageStrings.Instancetype);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("ImageId")).toContain(messageStrings.Imageid);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("SubnetId")).toContain(messageStrings.Subnetid);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Architecture")).toEqual(messageStrings.Architecture);
                            //expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Vpc")).toEqual(messageStrings.Vpcid);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("VirtualizationType")).toEqual(messageStrings.Virtualizationtype);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("RootDeviceName")).toEqual(ec2InstanceTemplate.RootDeviceName);

                            inventoryPage.closeViewComponent();
                            inventoryPage.clickExpandFirstRow();
                        });
                    });
                });
            });
        }

        it('AWS EC2 Negative Scenario ---- Turn ON the instance when the VM state is ON', function () {
            // var orderObject = {};
            orderObject.servicename = serviceName;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickTurnONButtonOfInstance().then(function () {
                        //inventoryPage.placeD2opsOrder();
                        expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOnNegativeWarning);
                        inventoryPage.clickCustomOpsWarningOKButton();
                    });
                });
            });
        });

        it('AWS EC2 - Verify instance Turn OFF functionality', function () {

            //VM status for real adapter            
            orderObject.servicename = serviceName;
            var status = messageStrings.powerStateOff;
            var val = JSON.stringify({ "IsUsingDummy": "Yes" });
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                browser.executeScript('window.scrollTo(0,0);');
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                        inventoryPage.clickOkForInstanceTurnOFFPermission();
                    });
                });
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "TurnOff");
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingTurnOff);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.getComponentTags().then(function (text) {
                        if (val == text) {
                            //Status for dummy adapter
                            status = 'Off';
                            adapterName = "dummy";
                        }
                        //inventoryPage.waitForInstancStateStatusChange(orderObject, status).then(function(){
                        expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe(status);
                        //});                
                    });
                });
            });
        });

        it('AWS EC2 Negative Scenario ---- Turn OFF the instance when the VM state is OFF', function () {

            orderObject.servicename = serviceName;
            if (adapterName == "Real") {
                msgToVerify = messageStrings.turnOffNegativeWarningRealAdapter;
            } else {
                msgToVerify = messageStrings.turnOffNegativeWarning;
            }
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                        //inventoryPage.placeD2opsOrder();
                        expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(msgToVerify);
                        inventoryPage.clickCustomOpsWarningOKButton();
                    });
                });
            });
        });

        it('AWS EC2 Negative Scenario ---- Reboot the instance when the VM state is OFF', function () {
            //var orderObject = {};
            orderObject.servicename = serviceName;
            if (adapterName == "Real") {
                msgToVerify = messageStrings.rebootNegativeWarningrealAdapter;
            } else {
                msgToVerify = messageStrings.rebootNegativeWarning;
            }
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickRebootButtonOfInstance().then(function () {
                        //inventoryPage.placeD2opsOrder();
                        expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(msgToVerify);
                        inventoryPage.clickCustomOpsWarningOKButton();
                    });
                });
            });
        });

        it('AWS EC2 - Verify instance Turn ON functionality', function () {
            orderObject.servicename = serviceName;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                browser.executeScript('window.scrollTo(0,0);');
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickTurnONButtonOfInstance().then(function () {
                        inventoryPage.clickOkForInstanceTurnONPermission();
                    });
                });
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "TurnOn");
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                //orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provInProgressState);
                orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingTurnOn);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
                });
            });
        });

        it('AWS EC2 - Verify instance Reboot functionality', function () {
            orderObject.servicename = serviceName;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                browser.executeScript('window.scrollTo(0,0);');
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickRebootButtonOfInstance().then(function () {
                        inventoryPage.clickOkForInstanceRebootPermission();
                    });
                });
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "Reboot");
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                //orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provInProgressState);
                orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingReboot);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
                    // browser.sleep(1000);
                    inventoryPage.clickExpandFirstRow();
                });
            });

        });

        it('AWS EC2 - Validate system tags, Edit and Delete Service', function () {
            //Validate service Tags
            inventoryPage.open();
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                var tagList = tags.split(",");
                var tagMap = inventoryPage.getServiceTags(tagList);
                var mcmpTag = false;
                if (isDummyAdapterDisabled == "false") {
                    //verifying flags for dummy adapter
                    expect(tagMap["IsUsingDummy"]).toEqual(messageStrings.isDummyTagValue);
                    expect(tagMap["Name"]).toEqual(ec2InstanceTemplate.bluePrintName);
                    expect(tagMap["PhysicalId"]).toContain(serviceName);
                    expect(Object.keys(tagMap).includes("Test")).toBe(true);
                    expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                } else {
                    //verifying a system tag
                    expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                    //verifying some of the service tags
                    expect(tagList.includes(tagList.find(tag => tag.includes("stackId:arn:aws:cloudformation")))).toBe(true);
                    expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:logical-id")))).toBe(true);
                    expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-id")))).toBe(true);
                    expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-name")))).toBe(true);
                    expect(tagMap["serviceInstanceName"].toLowerCase()).toContain(serviceName.toLowerCase());
                }
                orderFlowUtil.closeHorizontalSliderIfPresent();
            });

            //Edit service flow
            var modifiedParamMap = { "EditService": true };
            orderFlowUtil.editService(orderObject);
            orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap).then(function (reviewOrderExpActParamsMap) {
                logger.info("Edit parameter details are filled.");
                if (browser.params.defaultCurrency == "USD") {
                    expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(ec2InstanceTemplate.TotalCostPostEdit);
                }
                // browser.sleep(5000);
                //Validate Review order page parameters
                expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
            });
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "Edit");
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == 'Completed') {
                    //Verify updated details are reflected on order details page.						
                    ordersPage.clickFirstViewDetailsOrdersTable();
                    expect(ordersPage.getTextBasedOnLabelName("Resource Name")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Resource Name"));
                    expect(ordersPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Instance Type"));
                    // expect(ordersPage.getTextBasedOnLabelName("IAM Role")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "IAM Role"));
                    expect(ordersPage.getTextBasedOnLabelName("Shutdown Behavior")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Shutdown Behavior"));
                    // expect(ordersPage.getTextBasedOnLabelName("Monitoring")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Monitoring"));
                    expect(ordersPage.getTextBasedOnLabelName("T2/T3 Unlimited")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "T2/T3 Unlimited"));
                    expect(ordersPage.getTextBasedOnLabelName("Unlimited Instance Type")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Unlimited Instance Type"));
                    expect(ordersPage.getTextBasedOnLabelName("User Data")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "User Data"));
                    expect(ordersPage.getTextBasedOnLabelName("Device Name")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Device Name"));
                    expect(ordersPage.getTextBasedOnLabelName("Volume Size")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Volume Size"));
                    expect(ordersPage.getTextBasedOnLabelNameandIndex("Volume Type", 1)).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Volume Type"));
                    //expect(ordersPage.getTextBasedOnLabelName("IOPS")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "IOPS"));
                    if (browser.params.defaultCurrency == "USD") {
                        ordersPage.clickBillOfMaterialsTabOrderDetails();
                        expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(ec2InstanceTemplate.TotalCostPostEdit);
                    }
                    ordersPage.clickServiceDetailSliderCloseButton();
                    //Delete Service flow                    
                    orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, ec2InstanceTemplate.bluePrintName);
                    //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                    orderFlowUtil.approveDeletedOrder(orderObject);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
                }
            });
        });

        if (isDummyAdapterDisabled == "true") {
            it('EC2-Create a new Key Pair/Download and Access EC2 ', function () {
                var keyName = "att" + util.getRandomString(5);
                var groupName = "att-group-" + util.getRandomString(5);
                var serviceInstance = "aws-windows-ec2-" + util.getRandomString(5);
                orderObject.servicename = serviceInstance;
                modifiedParamMap = { "Service Instance Name": serviceInstance, "Group Name": groupName, "Self Image": "dndAutoTestWindows", "Create a new key pair": "Create a new key pair", "Key pair name": keyName, "CreateDownload Key": "Click", "Key Pair Created": "was successfully created", "Key Pair": "", "Volume Type": "", "IOPS": "", "Size": "" };
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
                catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
                catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);
                //Fill Order Details
                orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap);
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "New-WithKeyPair");
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //wait for 4 mins so that password is available
                browser.sleep(240000);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(serviceInstance);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                        inventoryPage.clickAccessComponent().then(function () {
                            inventoryPage.uploadFile(keyName);
                            inventoryPage.clickDecryptBtn();
                            expect(inventoryPage.getPaswrdVm()).not.toBe(null);
                        });

                    });
                });
                //Delete Service flow                    
                // orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                orderFlowUtil.deleteService(orderObject).then(async function (orderNo) {
                    orderObject.deleteOrderNumber = orderNo;
                    await util.saveOrderId(ec2InstanceTemplate.bluePrintName, "Delete-WithKeyPair", orderNo);
                    orderFlowUtil.approveDeletedOrder(orderObject);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
                });
            });
        }
    }
});
