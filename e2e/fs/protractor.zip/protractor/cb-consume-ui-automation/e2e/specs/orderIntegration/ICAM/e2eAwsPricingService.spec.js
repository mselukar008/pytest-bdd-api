"use strict";

const { browser } = require('protractor');

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    Orders = require('../../../pageObjects/orders.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    vmInAwsTemplate = require('../../../../testData/OrderIntegration/ICAM/AWSPricing.json');


describe('E2E Test cases for ICAM-ON Virtual machine in AWS service', function () {

    var catalogPage, placeOrderPage, ordersPage, orderHistoryPage, SubnetName, vpc, serviceName, virtualMachineName, awsSshKeyName;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: vmInAwsTemplate.providerName,
        category: vmInAwsTemplate.category,
        estimatedPrice: vmInAwsTemplate.estimatedPrice,
        providerAccount: vmInAwsTemplate.providerAccount,
        completedState: vmInAwsTemplate.completedState,
        approvalState: vmInAwsTemplate.approvalState,
        orderTypeDel: vmInAwsTemplate.orderTypeDel,
        urlOrders: vmInAwsTemplate.urlOrders,
        estimatedCost: vmInAwsTemplate.estimatedCost,
        cancelOrderSuccessMsg: vmInAwsTemplate.cancelOrderSuccessMsg,
        cancelledStatus: vmInAwsTemplate.cancelledStatus,
        provisiongstatus: vmInAwsTemplate.provisiongstatus,
        Cancelingstatus: vmInAwsTemplate.Cancelingstatus,
        orderSubmittedConfirmationMessage: vmInAwsTemplate.orderSubmittedConfirmationMessage,
        orderFailedStatus: vmInAwsTemplate.failedState
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        orderHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        serviceName = vmInAwsTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
        SubnetName = vmInAwsTemplate.subnetnamePrefix + "-" + util.getRandomString(5);
        vpc = vmInAwsTemplate.vpcPrefix + "-" + util.getRandomString(5);
        virtualMachineName = vmInAwsTemplate.virtualMachineNamePrefix + "-" + util.getRandomString(5);
        awsSshKeyName = vmInAwsTemplate.awsSshKeyNamePrefix + "-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Public SSH Key Name": awsSshKeyName }
    });


    if (isProvisioningRequired == "true") {
        it('ICAM : ICAM-ON Virtual machine in AWS --- Verify Provision and Delete services', function () {
            var orderObject = {}
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
            catalogPage.searchForBluePrint(vmInAwsTemplate.bluePrintName);
            catalogPage.clickDetailsButtonBasedOnName(vmInAwsTemplate.bluePrintName);
            expect(catalogPage.getOneTimeChargePrice()).toBe("USD 25.50/ PLAN / Month + USD 0.00");
            catalogPage.open();
            catalogPage.searchForBluePrint(vmInAwsTemplate.bluePrintName);
            catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPrice);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextTotalPriceOrderSubmittedModal()).toBe(messageStrings.estimatedPrice);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            ordersPage.open();
            ordersPage.searchOrderById(orderObject.orderNumber);
            ordersPage.clickFirstViewDetailsOrdersTable();
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);
            ordersPage.closeServiceDetailsSlider();
            //
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {

             	//Delete service
            	if (status == 'Completed') { 
                    orderHistoryPage.open();
                    orderHistoryPage.searchOrderById(orderObject.orderNumber);
                    orderHistoryPage.clicklnkBillOfMaterialXapth(); 
                    expect(orderHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);
                    orderHistoryPage.clickMoreLinkBom();
                    expect(orderHistoryPage.getTotalMonthlyPricing()).toEqual(messageStrings.estimatedCost);
                    orderHistoryPage.closeServiceDetailsSlider();
            		orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
            		expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
            		orderFlowUtil.approveDeletedOrder(orderObject);
            		orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
            		expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState);
             	}
             });
       });
    }
});
