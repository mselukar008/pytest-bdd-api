"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	runSnowDiscovery = browser.params.runSnowDiscovery,
	azureLinuxTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/AzureLinuxVMSnowV3SpecstoSkipIMI.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('QS: Azure E2E cases for Auto Technical, Financial and Legal approval with Standard change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, provOrder, sampleOrder1, inventoryPage, policyPage, cartListPage;
	var modifiedParamMap = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var serviceName = "SNOWQSauto"+util.getRandomString(5);
	var policyName = "SNOWQSautoAzurePolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWQSautoAzurePolicyRule"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var newResourceGroupName = "gslautotc_azureWVM-RG101" + util.getRandomString(4);
	var newVmName = "auto-VM101" + util.getRandomString(4);
	var newNetworkName = "auto-VN101" + util.getRandomString(4);
	var newSubnetName = "auto-SN101" + util.getRandomString(4);
	var newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
	var newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
	var newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
	var newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
	var diskName = "autodisk" + util.getRandomString(4);
    diskName = diskName.toLocaleLowerCase();
	var azureLinuxObj = JSON.parse(JSON.stringify(azureLinuxTemplate.Scenario1));
	
	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["Azure"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":""};
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "New Resource Group": newResourceGroupName, "Disk Name": diskName, "Virtual Machine Name": newVmName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName };
	});
	
	afterAll(function() {

		//Delete Approval Policy
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});
	
	it('Set Change Request type to Standard in SNOW', function () {
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Approval Policy for Azure with Auto Technical, Financial, Legal approval and Standard change', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('Azure: Linux Virtual Machine ---- Verify Provision functionality with Auto Technical, Financial, Legal approval and Standard change', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(azureLinuxObj.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(azureLinuxObj.Category);
			catalogPage.clickConfigureButtonBasedOnName(azureLinuxObj.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(azureLinuxTemplate.Scenario1, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(azureLinuxObj.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.provInProgressState);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			}
			expect(snowPage.getTextShortDescription()).toBe(azureLinuxObj.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescAzure);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAzure);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Resource Group Required")).toEqual("Yes");
			expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("New Resource Group")).toEqual(newResourceGroupName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Location").toString().toLowerCase().replace(/\s/g,''));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Name")).toEqual(newVmName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Location")).toEqual(jsonUtil.getValue(azureLinuxObj,"Virtual Machine Location"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Username")).toEqual(jsonUtil.getValue(azureLinuxObj,"Username"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Authentication Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Admin Password")).toEqual("XXXXXX");	
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Proximity Placement Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "Proximity Placement Group"));			
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Availability Options")).toEqual("NoInfrastructureRedundancyRequired");			
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Image")).toEqual("RHEL, 7.4, RedHat");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vm Generation")).toEqual("V1");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Size")).toEqual("Basic_A0");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Virtual Network Required")).toEqual(jsonUtil.getValue(azureLinuxObj,"New Virtual Network Required"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Network Name")).toEqual(newNetworkName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Address Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Address Prefix"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Name")).toEqual(newSubnetName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Subnet Prefix"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Interface Name")).toEqual(newNetworkInterfaceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Required"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Name")).toEqual(newPublicIpName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Ip Address Sku"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("NIC Network Security Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "NIC Network Security Group"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Inbound Ports")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Inbound Ports"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use Load Balancing")).toEqual(jsonUtil.getValue(azureLinuxObj, "Use Load Balancing"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(azureLinuxObj, "System Assigned Managed Identity"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "Boot Diagnostics"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "OS Guest Diagnostics"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(azureLinuxObj, "Enable Auto Shutdown"));
			
			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem2Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem3Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem4Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem5Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem6Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNIAzure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem2Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVNAzure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem3Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNSGAzure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem4Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSBA0Azure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem5Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalPublicIPAzure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem6Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalHDDAzure);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			}
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();
			//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
					
			//Order Completion in SNOW
			//snowPage.clickImplementButtonQS();
			snowPage.checkIfProvisioningTaskClosed();
			/*snowPage.clickBackButton();
			snowPage.openRelatedChangeRequest();
			snowPage.clickCloseChangeRequestButton();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();			
		   });		
		});
		
		if(isDummyAdapterDisabled== "true") {
			it('Azure: Linux Virtual Machine ---- Verify Edit functionality with Auto Technical, Financial, Legal approval and Standard change', function () {
				
				//Place Order for Edit in Marketplace
				var orderObject = {};
				orderObject.servicename = serviceName;
				var modifiedParamMap = {"EditService": true };
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				orderFlowUtil.editService(orderObject);
				orderFlowUtil.fillOrderDetails(azureLinuxTemplate.Scenario1, modifiedParamMap);
				placeOrderPage.submitOrder();
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
				sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(azureLinuxObj.orderSubmittedConfirmationMessage);
				placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
				
				//Validation in Marketplace after auto approval
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.provInProgressState);
				expect(orderFlowUtil.verifyOrderType(orderObject)).toBe(azureLinuxObj.orderTypeEdit);
				
				//Validations on SNOW Request page after auto approval
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.waitUntilApprovalIsApprovedQS();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
				}
				expect(snowPage.getTextShortDescription()).toBe(azureLinuxObj.bluePrintName);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestEdit);		
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
							
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.bluePrintName);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescAzure);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAzure);
				expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Resource Group Required")).toEqual("Yes");
				expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("New Resource Group")).toEqual(newResourceGroupName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Location").toString().toLowerCase().replace(/\s/g,''));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Name")).toEqual(newVmName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Location")).toEqual(jsonUtil.getValue(azureLinuxObj,"Virtual Machine Location"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Username")).toEqual(jsonUtil.getValue(azureLinuxObj,"Username"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Authentication Type"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Admin Password")).toEqual("XXXXXX");	
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Proximity Placement Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "Proximity Placement Group"));			
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Availability Options")).toEqual("NoInfrastructureRedundancyRequired");			
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Image")).toEqual("RHEL, 7.4, RedHat");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vm Generation")).toEqual("V1");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Size")).toEqual("Basic_A1");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Virtual Network Required")).toEqual(jsonUtil.getValue(azureLinuxObj,"New Virtual Network Required"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Network Name")).toEqual(newNetworkName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Address Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Address Prefix"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Name")).toEqual(newSubnetName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Subnet Prefix"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Interface Name")).toEqual(newNetworkInterfaceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Required"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Name")).toEqual(newPublicIpName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Ip Address Sku"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Type"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("NIC Network Security Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "NIC Network Security Group"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Inbound Ports")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Inbound Ports"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use Load Balancing")).toEqual(jsonUtil.getValue(azureLinuxObj, "Use Load Balancing"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(azureLinuxObj, "System Assigned Managed Identity"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "Boot Diagnostics"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "OS Guest Diagnostics"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(azureLinuxObj, "Enable Auto Shutdown"));
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem2Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem3Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem4Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem5Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem6Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNIAzure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem2Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVNAzure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem3Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNSGAzure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem4Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSBA0Azure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem5Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalPublicIPAzure);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem6Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalHDDAzure);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
					expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				}
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();
				//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				//snowPage.clickImplementButtonQS();
				snowPage.checkIfProvisioningTaskClosed();
				/*snowPage.clickBackButton();
				snowPage.openRelatedChangeRequest();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.completedState);
				
				//Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();			
				});			
			});
		};
		
		if(runSnowDiscovery == "true") {
			it('Azure: Linux Virtual Machine ---- Run Discovery for Azure before Turn OFF and verify the state of VM', function () {
				snowPage.openDiscoverySchedulesQS();
				snowPage.runDiscoveryForAzure();
				expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
				snowPage.clickRequestedItemLink();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
				expect(snowPage.isPresentVMInstanceInCIAzure()).toBe(true);
				snowPage.clickVMInstanceInCILinkAzure();
				expect(snowPage.getTextVMInstanceState()).toBe(snowInstanceTemplate.instanceStateOn);			
			});
		};
		
		it('Azure: Linux Virtual Machine ---- Verify Turn OFF functionality with Auto Technical, Financial, Legal approval and Standard change', function () {

            //Place order for Turn OFF in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
            orderObject.servicename = serviceName;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                browser.executeScript('window.scrollTo(0,0);');
                if(isDummyAdapterDisabled== "true") {
	                inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
	                	browser.executeScript('window.scrollTo(0,0);');
	                	inventoryPage.azClickTurnOFFButtonOfInstanceSNOW().then(function () {
	                		inventoryPage.clickOkForInstanceTurnOFFPermission();
	                		util.waitForAngular();
	                	});
	                });
	            }
            	else {
            		inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
	                	browser.executeScript('window.scrollTo(0,0);');
	                	inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
	                		inventoryPage.clickOkForInstanceTurnOFFPermission();
	                		util.waitForAngular();
	                	});
	                });
            	};
            }).then(function() { 
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(azureLinuxObj.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                
                //Validation in Marketplace after auto approval
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(azureLinuxObj.orderTypeAction);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.provInProgressState);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(azureLinuxObj.serviceOfferingTurnOff);
            		
	            //Validations on SNOW Request page
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.waitUntilApprovalIsApprovedQS();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
				}
				expect(snowPage.getTextShortDescription()).toBe(azureLinuxObj.serviceOfferingTurnOff);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
				
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.serviceOfferingTurnOff);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOffAz);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOff);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAzure);
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("stop");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalAzure);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				}
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();
				//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				//snowPage.clickImplementButtonQS();
				snowPage.checkIfProvisioningTaskClosed();
				/*snowPage.clickBackButton();
				snowPage.openRelatedChangeRequest();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.completedState);
				inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function() {
               	 if (isDummyAdapterDisabled == "true") {
                        expect(inventoryPage.getInstancePowerStateStatusAzure(orderObject)).toContain(azureLinuxObj.powerStateOff);
                    }
                    else {
                        expect(inventoryPage.getInstancePowerStateStatusAzure(orderObject)).toContain(azureLinuxObj.powerStateOffDummy);
                    }
               });
				
                //Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				});		
            });
		});
		
		if(runSnowDiscovery == "true") {
			it('Azure: Linux Virtual Machine ---- Run Discovery for Azure after Turn OFF and verify the state of VM', function () {
				snowPage.openDiscoverySchedulesQS();
				snowPage.runDiscoveryForAzure();
				expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
				snowPage.clickRequestedItemLink();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
				expect(snowPage.isPresentVMInstanceInCIAzure()).toBe(true);
				snowPage.clickVMInstanceInCILinkAzure();
				expect(snowPage.getTextVMInstanceState()).toBe(snowInstanceTemplate.instanceStateOff);			
			});
		};
		
		it('Azure: Linux Virtual Machine ---- Verify Turn ON functionality with Auto Technical, Financial, Legal approval and Standard change', function () {

            //Place order for Turn ON in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
            orderObject.servicename = serviceName;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                browser.executeScript('window.scrollTo(0,0);');
                if(isDummyAdapterDisabled== "true") {
	                inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
	                	browser.executeScript('window.scrollTo(0,0);');
	                	inventoryPage.azClickTurnONButtonOfInstanceSNOW().then(function () {
	                		inventoryPage.clickOkForInstanceTurnOFFPermission();
	                		util.waitForAngular();
	                	});
	                });
	            }
            	else {
            		inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
	                	browser.executeScript('window.scrollTo(0,0);');
	                	inventoryPage.clickTurnONButtonOfInstance().then(function () {
	                		inventoryPage.clickOkForInstanceTurnOFFPermission();
	                		util.waitForAngular();
	                	});
	                });
            	};
            }).then(function() { 
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(azureLinuxObj.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                
                //Validation in Marketplace after auto approval
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(azureLinuxObj.orderTypeAction);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.provInProgressState);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(azureLinuxObj.serviceOfferingTurnOn);
            		
	            //Validations on SNOW Request page
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.waitUntilApprovalIsApprovedQS();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
				}
				expect(snowPage.getTextShortDescription()).toBe(azureLinuxObj.serviceOfferingTurnOn);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
				
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.serviceOfferingTurnOn);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOnAz);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOn);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAzure);
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("start");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalAzure);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				}
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();
				//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				//snowPage.clickImplementButtonQS();
				snowPage.checkIfProvisioningTaskClosed();
				/*snowPage.clickBackButton();
				snowPage.openRelatedChangeRequest();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.completedState);
				inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function() {
                	expect(inventoryPage.getInstancePowerStateStatusAzure(orderObject)).toContain(azureLinuxObj.powerStateOn);	          	
                });
				
                //Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				});		
            });
		});
		
		if(runSnowDiscovery == "true") {
			it('Azure: Linux Virtual Machine ---- Run Discovery for Azure after Turn ON and verify the state of VM', function () {
				snowPage.openDiscoverySchedulesQS();
				snowPage.runDiscoveryForAzure();
				expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
				snowPage.clickRequestedItemLink();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
				expect(snowPage.isPresentVMInstanceInCIAzure()).toBe(true);
				snowPage.clickVMInstanceInCILinkAzure();
				expect(snowPage.getTextVMInstanceState()).toBe(snowInstanceTemplate.instanceStateOn);			
			});
		};
		
		it('Azure: Linux Virtual Machine ---- Verify Reboot functionality with Auto Technical, Financial, Legal approval and Standard change', function () {

            //Place order for Reboot in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
            orderObject.servicename = serviceName;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                browser.executeScript('window.scrollTo(0,0);');
                if(isDummyAdapterDisabled== "true") {
	                inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
	                	browser.executeScript('window.scrollTo(0,0);');
	                	inventoryPage.azClickRebootButtonOfInstanceSNOW().then(function () {
	                		inventoryPage.clickOkForInstanceTurnOFFPermission();
	                		util.waitForAngular();
	                	});
	                });
	            }
            	else {
            		inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
	                	browser.executeScript('window.scrollTo(0,0);');
	                	inventoryPage.clickRebootButtonOfInstance().then(function () {
	                		inventoryPage.clickOkForInstanceTurnOFFPermission();
	                		util.waitForAngular();
	                	});
	                });
            	};
            }).then(function() { 
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(azureLinuxObj.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                
                //Validation in Marketplace after auto approval
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(azureLinuxObj.orderTypeAction);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.provInProgressState);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(azureLinuxObj.serviceOfferingReboot);
            		
	            //Validations on SNOW Request page
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.waitUntilApprovalIsApprovedQS();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
				}
				expect(snowPage.getTextShortDescription()).toBe(azureLinuxObj.serviceOfferingReboot);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
				
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.serviceOfferingReboot);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescRebootAz);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingReboot);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAzure);
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("reboot");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalAzure);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				}
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();
				//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				//snowPage.clickImplementButtonQS();
				snowPage.checkIfProvisioningTaskClosed();
				/*snowPage.clickBackButton();
				snowPage.openRelatedChangeRequest();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.completedState);
				inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function() {
                	expect(inventoryPage.getInstancePowerStateStatusAzure(orderObject)).toContain(azureLinuxObj.powerStateOn);	          	
                });
				
                //Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				});		
            });
		});
		
		it('Azure: Linux Virtual Machine ---- Verify Delete functionality with Auto Technical, Financial, Legal approval and Standard change', function () {
			
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			sampleOrder1 = inventoryPage.getDeleteOrderNumber();
			
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(azureLinuxObj.provInProgressState);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(azureLinuxObj.orderTypeDel);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			}
			expect(snowPage.getTextShortDescription()).toBe(azureLinuxObj.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescAzure);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAzure);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);

			// Broker Config values table validations
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Resource Group Required")).toEqual("Yes");
			expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("New Resource Group")).toEqual(newResourceGroupName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Location").toString().toLowerCase().replace(/\s/g, ''));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Name")).toEqual(newVmName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Virtual Machine Location"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Username")).toEqual(jsonUtil.getValue(azureLinuxObj, "Username"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Authentication Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Admin Password")).toEqual("XXXXXX");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Proximity Placement Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "Proximity Placement Group"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Availability Options")).toEqual("NoInfrastructureRedundancyRequired");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Image")).toEqual("RHEL, 7.4, RedHat");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vm Generation")).toEqual("V1");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Size")).toEqual("Basic_A0");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Virtual Network Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "New Virtual Network Required"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Network Name")).toEqual(newNetworkName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Address Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Address Prefix"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Name")).toEqual(newSubnetName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Subnet Prefix"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Interface Name")).toEqual(newNetworkInterfaceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Required"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Name")).toEqual(newPublicIpName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Ip Address Sku"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("NIC Network Security Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "NIC Network Security Group"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Inbound Ports")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Inbound Ports"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use Load Balancing")).toEqual(jsonUtil.getValue(azureLinuxObj, "Use Load Balancing"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(azureLinuxObj, "System Assigned Managed Identity"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "Boot Diagnostics"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "OS Guest Diagnostics"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(azureLinuxObj, "Enable Auto Shutdown"));

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem2Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem3Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem4Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem5Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem6Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNIAzure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem2Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVNAzure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem3Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNSGAzure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem4Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSBA0AzureDel);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem5Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalPublicIPAzureDel);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem6Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalHDDAzureDel);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			}
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();
			//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
					
			//Order Completion in SNOW
			//snowPage.clickImplementButtonQS();
			snowPage.checkIfProvisioningTaskClosed();
			/*snowPage.clickBackButton();
			snowPage.openRelatedChangeRequest();
			snowPage.clickCloseChangeRequestButton();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(azureLinuxObj.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();			
			});		
		});
	 }
		
	
});
	
	
	
	