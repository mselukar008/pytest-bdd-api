"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	runSnowDiscovery = browser.params.runSnowDiscovery,
	awsEC2template = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSEC2InstanceSnow.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('AWS E2E cases for External Approval False with Normal change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, sampleOrder1, provOrder, inventoryPage, cartListPage, awsEC2obj, groupName;
	var modifiedParamMap = {};
	var serviceName = "SNOWauto"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		cartListPage = new CartListPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		groupName = "att-group-" + util.getRandomString(5);
		awsEC2obj = JSON.parse(JSON.stringify(awsEC2template));
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"TEAM1", "Environment":"QA", "Application":"", "Provider Account":"AWS-SNOW / AWS-SNOW", "Group Name": groupName};
	});
	
	afterAll(function() {
		browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});
	
	it('Disable SNOW external approver for Enterprise Marketplace', function () {
		expect(snowAPI.disableExternalApprovalSnow()).toBe(snowInstanceTemplate.snowAPIResult);
	});
	
	it('Set Change Request type to Normal in SNOW', function () {
		expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	if(isProvisioningRequired == "true") {	
		it('AWS EC2 ---- Verify Provision functionality with Ext App False and Normal change', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(awsEC2template.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(awsEC2template.Category);
			catalogPage.clickConfigureButtonBasedOnName(awsEC2template.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(awsEC2template, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			
			//Validation on SNOW before approval in Marketplace
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.provInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequested();
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			//expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2obj, "Resource Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("Subnet")).toEqual("subnet-a68b538d");
			expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("VPC")).toEqual("vpc-8eadd1eb");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2obj, "Shutdown Behavior"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2obj, "T2/T3 Unlimited"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2obj, "User Data"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));			
			expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWS);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickUpdateButton();
			
			//Approvals in SNOW
			snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.openRelatedChangeRequest();
			snowPage.approveChangeRequestForEachState();
			snowPage.approveChangeRequestForEachState();
			
			//Validations on SNOW Request and RITM page after approvals
			snowPage.clickBackButton();
			snowPage.clickBackButton();
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			
			//Order Completion in SNOW
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			//snowPage.closePostImplementTestTask();
			//snowPage.closeImplementTask();
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
		});		
	});
	
	it('AWS EC2 ---- Verify Edit functionality with Ext App False and Normal change', function () {
		
		//Place Order for Edit in Marketplace
		var orderObject = {};
		orderObject.servicename = serviceName;
		var modifiedParamMap = {"EditService": true };
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		orderFlowUtil.editService(orderObject);
		orderFlowUtil.fillOrderDetails(awsEC2template, modifiedParamMap);
		placeOrderPage.submitOrder();
		orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
		orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
		sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
		expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
		placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
		
		//Validation on SNOW before approval in Marketplace
		snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
		expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
		expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
		expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
		expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
		expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
		
		//Approve Order in Marketplace
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		expect(orderFlowUtil.verifyOrderType(orderObject)).toBe(awsEC2template.orderTypeEdit);
		orderFlowUtil.approveOrder(orderObject);
		orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.provInProgressState);
		expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.provInProgressState);
		
		//Validations on SNOW Request page after approval in Marketplace
		snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
		//snowPage.waitUntilApprovalIsRequested();
		expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
		expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
		expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
		expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
		expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
		expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
		expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestEdit);		
		expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
		//expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
					
		//Validations on SNOW Requested Item page
		snowPage.clickRequestedItemLink();
		expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
		expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
		expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
		expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
		expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
		expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
		expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
		expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
		var serName = snowPage.getTextReqItemVariableServiceName();
		serName.then(function(sName){
		expect(sName).toContain(serviceName);
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Instance Type"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("Subnet")).toEqual("subnet-a68b538d");
		expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("VPC")).toEqual("vpc-8eadd1eb");
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Shutdown Behavior"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("unlimited Instance Type")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Unlimited Instance Type"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "User Data"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("Assign a security group")).toEqual(jsonUtil.getValue(awsEC2obj,"Assign a security group"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("device Name")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Device Name"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("volume Size")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Volume Size"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("volume Type")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Volume Type"));
		expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));			
		expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
		expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalEditAWS);
		
		//Validations on SNOW Configuration Item- Service Instance CIs page
		snowPage.switchToDefaultContent();
		snowPage.switchToParentFrame();
		snowPage.openConfItemServiceInstanceCIs();
		expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
		expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
		expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
		snowPage.clickUpdateButton();
		
		//Validation on Catalog Task page
		snowPage.clickCatalogTaskLink();
		expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
		snowPage.clickUpdateButton();
		
		//Approvals in SNOW
		snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
		snowPage.openRelatedChangeRequest();
		snowPage.approveChangeRequestForEachState();
		snowPage.approveChangeRequestForEachState();
		
		//Validations on SNOW Request and RITM page after approvals
		snowPage.clickBackButton();
		snowPage.clickBackButton();
		expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
		expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
		expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
		expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
		expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
		snowPage.clickRequestedItemLink();
		snowPage.openRelatedChangeRequest();
		
		//Order Completion in SNOW
		snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
		snowPage.openRelatedChangeRequest();
		snowPage.checkIfProvisioningTaskClosed();
		//snowPage.closePostImplementTestTask();
		//snowPage.closeImplementTask();
		snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
		snowPage.openRelatedChangeRequest();
		snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
		//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
		
		//Validation in Marketplace
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);
		
		//Validations on SNOW Request page after Completion
		snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
		expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
		expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
		expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
		expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
		expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
		
		//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
		snowPage.clickRequestedItemLink();
		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
		snowPage.openConfItemServiceInstanceCIs();
		expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
		expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
		snowPage.clickUpdateButton();
		
		//Validation on Catalog Task page after completion
		snowPage.clickCatalogTaskLink();
		expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
		snowPage.clickUpdateButton();
		
		});		
	});
	
	if(runSnowDiscovery == "true") {
		it('AWS EC2 ---- Run Discovery for AWS before Turn OFF and verify the state of VM in SNOW', function () {
			snowPage.openDiscoverySchedules();
			snowPage.runDiscoveryForAWS();
			expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
			expect(snowPage.isPresentVMInstanceInCI()).toBe(true);
			snowPage.clickVMInstanceInCILink();
			expect(snowPage.getTextVMInstanceState()).toBe(snowInstanceTemplate.instanceStateOn);			
		});
	};
	
	it('AWS EC2 ---- Verify Turn OFF functionality with Ext App False and Normal change', function () {

        //Place order for Turn OFF in Marketplace 
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		var orderObject = {};
		orderObject.componentType = awsEC2template.componentType;
        orderObject.servicename = serviceName;
        var val = JSON.stringify({ "IsUsingDummy": "Yes" });
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            util.scrollToTop();
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                    inventoryPage.clickOkForInstanceTurnOFFPermission();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();    
	
            //Validation on SNOW before approval in Marketplace
            snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
    		
    		//Approve Order in Marketplace
    		browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
    		expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(awsEC2template.orderTypeAction);
    		orderFlowUtil.approveOrder(orderObject);
    		orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.provInProgressState);
    		expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.provInProgressState);
    		expect(placeOrderPage.getServiceNameOfferingText()).toBe(awsEC2template.serviceOfferingTurnOff); 
    		
    		//Validations on SNOW Request page after approval in Marketplace
    		snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
    		snowPage.waitUntilApprovalIsRequested();
    		expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
    		expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
    		expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
    		expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
    		expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
    		//expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
    					
    		//Validations on SNOW Requested Item page
    		snowPage.clickRequestedItemLink();
    		expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
    		expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
    		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
    		expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
    		expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.serviceOfferingTurnOff);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOff);
    		expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
    		expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOff);
    		expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
    		var serName = snowPage.getTextReqItemVariableServiceName();
    		serName.then(function(sName){
    		expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("stop");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
			expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickUpdateButton();
			
			//Approvals in SNOW
			snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.openRelatedChangeRequest();
			snowPage.approveChangeRequestForEachState();
			snowPage.approveChangeRequestForEachState();
			
			//Validations on SNOW Request and RITM page after approvals
			snowPage.clickBackButton();
			snowPage.clickBackButton();
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			
			//Order Completion in SNOW
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			//snowPage.closePostImplementTestTask();
			//snowPage.closeImplementTask();
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);
			inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            var adapterName = "Real";
            var status = awsEC2template.stopStatus;
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.getComponentTags().then(function (text) {
                    if (val == text) {
                        status = 'Off';
                        adapterName = "dummy";
                    }
                    expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe(status);              
                });
            });
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW RITM page after Completion			
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			
			});		
        });
	});
	
	if(runSnowDiscovery == "true") {
		it('AWS EC2 ---- Run Discovery for AWS after Turn OFF and verify the state of VM in SNOW', function () {
			snowPage.openDiscoverySchedules();
			snowPage.runDiscoveryForAWS();
			expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
			expect(snowPage.isPresentVMInstanceInCI()).toBe(true);
			snowPage.clickVMInstanceInCILink();
			expect(snowPage.getTextVMInstanceState()).toBe(snowInstanceTemplate.instanceStateOff);			
		});
	};
	
	it('AWS EC2 ---- Verify Turn ON functionality with Ext App False and Normal change', function () {

        //Place order for Turn ON in Marketplace 
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		var orderObject = {};
		orderObject.componentType = awsEC2template.componentType;
        orderObject.servicename = serviceName;
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            util.scrollToTop();
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickTurnONButtonOfInstance().then(function () {
                    inventoryPage.clickOkForInstanceTurnONPermission();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();    
	
            //Validation on SNOW before approval in Marketplace
            snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
    		
    		//Approve Order in Marketplace
    		browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
    		expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(awsEC2template.orderTypeAction);
    		orderFlowUtil.approveOrder(orderObject);
    		orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.provInProgressState);
    		expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.provInProgressState);
    		expect(placeOrderPage.getServiceNameOfferingText()).toBe(awsEC2template.serviceOfferingTurnOn); 
    		
    		//Validations on SNOW Request page after approval in Marketplace
    		snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
    		snowPage.waitUntilApprovalIsRequested();
    		expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
    		expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
    		expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
    		expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
    		expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
    		//expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
    					
    		//Validations on SNOW Requested Item page
    		snowPage.clickRequestedItemLink();
    		expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
    		expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
    		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
    		expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
    		expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.serviceOfferingTurnOn);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOn);
    		expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
    		expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOn);
    		expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
    		var serName = snowPage.getTextReqItemVariableServiceName();
    		serName.then(function(sName){
    		expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("start");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
			expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickUpdateButton();
			
			//Approvals in SNOW
			snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.openRelatedChangeRequest();
			snowPage.approveChangeRequestForEachState();
			snowPage.approveChangeRequestForEachState();
			
			//Validations on SNOW Request and RITM page after approvals
			snowPage.clickBackButton();
			snowPage.clickBackButton();
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			
			//Order Completion in SNOW
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			//snowPage.closePostImplementTestTask();
			//snowPage.closeImplementTask();
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);
			inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
            });
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW RITM page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			
			});		
        });
	});
	
	if(runSnowDiscovery == "true") {
		it('AWS EC2 ---- Run Discovery for AWS after Turn ON and verify the state of VM in SNOW', function () {
			snowPage.openDiscoverySchedules();
			snowPage.runDiscoveryForAWS();
			expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
			expect(snowPage.isPresentVMInstanceInCI()).toBe(true);
			snowPage.clickVMInstanceInCILink();
			expect(snowPage.getTextVMInstanceState()).toBe(snowInstanceTemplate.instanceStateOn);			
		});
	};
	
	it('AWS EC2 ---- Verify Reboot functionality with Ext App False and Normal change', function () {

        //Place order for Reboot in Marketplace 
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		var orderObject = {};
		orderObject.componentType = awsEC2template.componentType;
        orderObject.servicename = serviceName;
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            util.scrollToTop();
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickRebootButtonOfInstance().then(function () {
                    inventoryPage.clickOkForInstanceRebootPermission();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();    
	
            //Validation on SNOW before approval in Marketplace
            snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
    		
    		//Approve Order in Marketplace
    		browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
    		expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(awsEC2template.orderTypeAction);
    		orderFlowUtil.approveOrder(orderObject);
    		orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.provInProgressState);
    		expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.provInProgressState);
    		expect(placeOrderPage.getServiceNameOfferingText()).toBe(awsEC2template.serviceOfferingReboot); 
    		
    		//Validations on SNOW Request page after approval in Marketplace
    		snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
    		snowPage.waitUntilApprovalIsRequested();
    		expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
    		expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
    		expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
    		expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
    		expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
    		//expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
    					
    		//Validations on SNOW Requested Item page
    		snowPage.clickRequestedItemLink();
    		expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
    		expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
    		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
    		expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
    		expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.serviceOfferingReboot);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescReboot);
    		expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
    		expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingReboot);
    		expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
    		var serName = snowPage.getTextReqItemVariableServiceName();
    		serName.then(function(sName){
    		expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("reboot");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
			expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickUpdateButton();
			
			//Approvals in SNOW
			snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.openRelatedChangeRequest();
			snowPage.approveChangeRequestForEachState();
			snowPage.approveChangeRequestForEachState();
			
			//Validations on SNOW Request and RITM page after approvals
			snowPage.clickBackButton();
			snowPage.clickBackButton();
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			
			//Order Completion in SNOW
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			//snowPage.closePostImplementTestTask();
			//snowPage.closeImplementTask();
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);
			inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
            });
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW RITM page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			
			});		
        });
	});
	
	it('AWS EC2 ---- Verify Delete functionality with Ext App False and Normal change', function () {
		
		//Place Order for Delete in Marketplace
		var orderObject = {};
		orderObject.servicename = serviceName;
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
		sampleOrder1 = inventoryPage.getDeleteOrderNumber();
		
		//Validation on SNOW before approval in Marketplace
		snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
		expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
		expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
		expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
		expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
		expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
		
		//Approve Order in Marketplace
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(awsEC2template.orderTypeDel);
		orderFlowUtil.approveDeletedOrder(orderObject);
		orderFlowUtil.waitForDeleteOrderStatusChange(orderObject,awsEC2template.provInProgressState,50);
		expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.provInProgressState);
		
		//Validations on SNOW Request page after approval in Marketplace
		snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
		snowPage.waitUntilApprovalIsRequested();
		expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
		expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
		expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
		expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
		expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
		expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
		expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
		expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
		//expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
					
		//Validations on SNOW Requested Item page
		snowPage.clickRequestedItemLink();
		expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
		expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
		expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
		expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
		expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
		expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
		expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
		expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
		var serName = snowPage.getTextReqItemVariableServiceName();
		serName.then(function(sName){
		expect(sName).toContain(serviceName);
		
		//Validations on SNOW Configuration Item- Service Instance CIs page
		snowPage.openConfItemServiceInstanceCIs();
		expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
		expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
		expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
		snowPage.clickUpdateButton();
		
		//Validation on Catalog Task page
		snowPage.clickCatalogTaskLink();
		expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
		snowPage.clickUpdateButton();
		
		//Approvals in SNOW
		snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
		snowPage.openRelatedChangeRequest();
		snowPage.approveChangeRequestForEachState();
		snowPage.approveChangeRequestForEachState();
		
		//Validations on SNOW Request and RITM page after approvals
		snowPage.clickBackButton();
		snowPage.clickBackButton();
		expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
		expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
		expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
		expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
		expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
		snowPage.clickRequestedItemLink();
		snowPage.openRelatedChangeRequest();
		
		//Order Completion in SNOW
		snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
		snowPage.openRelatedChangeRequest();
		snowPage.checkIfProvisioningTaskClosed();
		//snowPage.closePostImplementTestTask();
		//snowPage.closeImplementTask();
		snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
		snowPage.openRelatedChangeRequest();
		snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
		//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
		
		//Validation in Marketplace
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(awsEC2template.completedState);
		
		//Validations on SNOW Request page after Completion
		snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
		expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
		expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
		expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
		expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
		expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
		
		//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
		snowPage.clickRequestedItemLink();
		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
		snowPage.openConfItemServiceInstanceCIs();
		expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
		expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
		snowPage.clickUpdateButton();
		
		//Validation on Catalog Task page after completion
		snowPage.clickCatalogTaskLink();
		expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
		snowPage.clickUpdateButton();
		
		});		
	 });  
   }
});
	
	
	
	