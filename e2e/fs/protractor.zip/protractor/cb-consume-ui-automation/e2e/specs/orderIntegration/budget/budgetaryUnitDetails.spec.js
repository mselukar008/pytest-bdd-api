/*************************************************
	AUTHOR: Pushpraj Singh
 **************************************************/

"use strict";

var Orders = require('../../../pageObjects/orders.pageObject.js'),
BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),
budgetDeleteApi = require('../../../../helpers/budgetDeleteApiUtil.js'),
util = require('../../../../helpers/util.js'),
budgetaryFlow = require('../../../../helpers/budgetaryFlow.js'),
CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
HomePage = require('../../../pageObjects/home.pageObject.js'),
jsonUtil = require('../../../../helpers/jsonUtil.js'),
appUrls = require('../../../../testData/appUrls.json'),
credentialsTemplate = require('../../../../testData/credentials.json'),
orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
isProvisioningRequired = browser.params.isProvisioningRequired,
superUserUsername = browser.params.username,
superUserPassword = browser.params.password,
budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
budgetaryUnitEditDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitEditDetails.json'),
budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryAddNewBudgetDetails.json'),
budgetaryUnitDeleteTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDelete.json'),
budgetaryBudgetEditDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryBudgetEditDetails.json');

describe('budgetary Test cases - ', function() {
	var orders, budgetaryName, budgetaryEditName, budgetaryUnitCode, budgetaryDetailName,budgetRefId,budgetaryRefId,
	budgetaryNewBudgetName, userName, budgetryPage, cartListPage, homePage; 
	var modifiedParamMap = {};
	var modifiedEditParamMap = {};
	var modifiedNewBudgetParamMap = {};
	var messageStrings = {
			providerName: budgetaryUnitDetailsTemplate.provider,
			orderSubmittedConfirmationMessage: budgetaryUnitDetailsTemplate.orderSubmittedConfirmationMessage,
			budgetDesc: budgetaryUnitDetailsTemplate.budgetDesc,
			budgetRefId: budgetaryUnitDetailsTemplate.budgetRefId,
			budgetEntity: budgetaryUnitDetailsTemplate.budgetEntity,
			budgetEnv: budgetaryUnitDetailsTemplate.budgetEnv,
			budgetApp: budgetaryUnitDetailsTemplate.budgetApp,
			budgetTerm: budgetaryUnitDetailsTemplate.budgetTerm,
			budgetActive: budgetaryUnitDetailsTemplate.budgetActive,
			budgetErrorMsg: budgetaryUnitDetailsTemplate.budgetErrorMsg,
			budgetSuccessMsg: budgetaryUnitDetailsTemplate.budgetSuccessMsg,
			budgetExistsMsg: budgetaryUnitDetailsTemplate.budgetExistsMsg,
			budgetOverlapsMsg: budgetaryUnitDetailsTemplate.budgetOverlapsMsg,
			budgetaryUnitDeletedApiSucessMsg: budgetaryUnitDetailsTemplate.budgetaryUnitDeletedApiSucessMsg,
	        	budgetDeletedApiSucessMsg: budgetaryUnitDetailsTemplate.budgetDeletedApiSucessMsg,
			budgetZeroCharges: budgetaryBudgetEditDetailsTemplate.budgetZeroCharges,
			budgetaryUnitEditErrorMsg: budgetaryUnitEditDetailsTemplate.budgetaryUnitEditErrorMsg,
			budgetaryUnitDeleteSuccessMsg : budgetaryUnitDeleteTemplate.budgetaryUnitDeleteSuccessMsg,
			subHeading:  budgetaryUnitEditDetailsTemplate.budgetMgmtSubHeading
	};

	beforeAll(function() {
		orders = new Orders();
		budgetryPage = new BudgetaryPage();
		cartListPage = new CartListPage();
		homePage = new HomePage();
		browser.driver.manage().window().maximize();
		budgetaryName = "autoBudgetUnit"+util.getRandomString(8);
		budgetaryDetailName = "autoBudgetEdit"+util.getRandomString(8);
		budgetaryNewBudgetName = "autoBudget"+util.getRandomString(8);
		budgetaryEditName = "autoBudgetUnitEdit"+util.getRandomString(8);
		budgetaryUnitCode = "autoBudgetUnitCode"+util.getRandomString(8);
		budgetRefId = "autoRefId"+util.getRandomString(8);
		budgetaryRefId = "autoRefId"+util.getRandomString(8);
		modifiedParamMap = {"budgetary Name":budgetaryName, "budgetary unit code":budgetaryUnitCode};
		modifiedEditParamMap = {"budgetary Name":budgetaryEditName};
		userName = browser.params.username;
		//homePage.open();
	});

	beforeEach(function() {
		budgetryPage.closeBudgetSliderIfPresent();
		budgetryPage.open();
		//expect(util.getCurrentURL()).toMatch(appUrls.launchpadUrl);
	});

	it('Verifying Cancel button is working fine in budgetry Unit panel area', function () {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
		util.waitForAngular();	
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.isPresentAddNewBudgetryUnitPanel();
		budgetryPage.isPresentAddNewBudgetryUnitText();
		budgetryPage.clickOnBudgetryCancelBtn();
		budgetryPage.verifyAddNewBudgetryUnitPanelnotPresent();        
	});
	
	//Organization checkbox is non editable
	/*it('Add new budgetry Unit without selecting association checkbox and verify the error message', function () {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
		util.waitForAngular();	
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.isPresentAddNewBudgetryUnitPanel();
		budgetryPage.isPresentAddNewBudgetryUnitText();
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMap);
		budgetryPage.checkAlltheBudgetryAssociateCheckboxes();
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.isPresentBudgetryDetailsUnitPanel();
		expect(budgetryPage.getTextBudgetryNoAssociationErrorMessage()).toBe(messageStrings.budgetErrorMsg);	
	});*/

	it('Add new budgetry Unit by selecting association checkbox and verify the submitted data & Status', function () {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
		util.waitForAngular();	
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.isPresentAddNewBudgetryUnitPanel();
		budgetryPage.isPresentAddNewBudgetryUnitText();
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMap);
		//budgetryPage.checkAlltheBudgetryAssociateCheckboxes();
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetryPage.isPresentBudgetryDetailsUnitPanel();
		expect(budgetryPage.getTextBasedOnLabelName("Name")).toBe(budgetaryName);
		expect(budgetryPage.getTextBasedOnLabelName("Budgetary Unit Identifier")).toBe(budgetaryUnitCode);
		expect(budgetryPage.getTextBasedOnLabelName("Description")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetDesc));
		expect(budgetryPage.getTextBasedOnLabelName("External Reference Id")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetRefId));
		expect(budgetryPage.getTextBasedOnSpanName("Organization")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetEntity));
		expect(budgetryPage.getTextBasedOnSpanName("Environment")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetEnv));
		expect(budgetryPage.getTextBasedOnSpanName("Application")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetApp));
		expect(budgetryPage.getTextBasedOnLabelName("Budget Term")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetTerm));
		expect(budgetryPage.getTextBudgetryDetailsStatus()).toBe(messageStrings.budgetActive);
		budgetryPage.clickBudgetSliderCloseButton();
				
	});
	
	it('Verify newly created budgetary unit status from budgetary unit table ',async function() {
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
		util.waitForAngular();	
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		//budgetryPage.selectbudgetaryPaginationDropDown();
		budgetryPage.searchBudegtaryUnit(budgetaryName);
		//var budgetaryName = "autoBudgetUnitdWFVkK2Z";
		var status = await budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		await expect(status).toEqual(messageStrings.budgetActive);
		var term = await budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		await expect(term).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetTerm));

		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);		
		expect(budgetryPage.getTextBasedOnLabelName("Name")).toBe(budgetaryName);
		expect(budgetryPage.getTextBasedOnLabelName("Budgetary Unit Identifier")).toBe(budgetaryUnitCode);
		expect(budgetryPage.getTextBasedOnLabelName("Description")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetDesc));
		expect(budgetryPage.getTextBasedOnLabelName("External Reference Id")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetRefId));
		expect(budgetryPage.getTextBudgetryDetailsOrganization()).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetEntity));
		expect(budgetryPage.getTextBudgetryDetailsEnvironment()).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetEnv));
		expect(budgetryPage.getTextBudgetryDetailsApplication()).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetApp));
		expect(budgetryPage.getTextBasedOnLabelName("Budget Term")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetTerm));
		expect(budgetryPage.getTextBudgetryDetailsStatus()).toBe(messageStrings.budgetActive);
		budgetryPage.clickBudgetSliderCloseButton();
		
	});
	
	it('Edit new budgetry Unit and verify the submitted data', async function() {	
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryUnitEditDetailsTemplate));
		var budgetaryAddObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		//budgetryPage.selectbudgetaryPaginationDropDown();
		budgetryPage.searchBudegtaryUnit(budgetaryName);
		//var budgetaryName = "autoBudgetUnitQQRXzgxW";
		var status = await budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		await expect(status).toEqual(messageStrings.budgetActive);
		
		var term = await budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		await expect(term).toEqual(jsonUtil.getValue(budgetaryAddObject, messageStrings.budgetTerm));
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
		budgetryPage.isPresentBudgetryDetailsUnitPanel();
		util.waitForAngular();
		budgetryPage.clickOnEditBudgetaryButton();
		budgetryPage.isPresentBudgetryEditDetailsTxt();
		expect(budgetryPage.getTextBasedOnLabelName("Name")).toBe(budgetaryName);
		expect(budgetryPage.getTextBasedOnLabelName("Budgetary Unit Identifier")).toBe(budgetaryUnitCode);
		expect(budgetryPage.getTextBasedOnLabelName("Description")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetDesc));
		expect(budgetryPage.getTextBasedOnLabelName("External Reference Id")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetRefId));
		
		//expect(budgetryPage.getTextBudgetryOrganizationFromEditPage()).toEqual(jsonUtil.getValue(budgetaryObject, "Organization"));
		expect(budgetryPage.getTextBudgetryEnvironmentFromEditPage()).toEqual(jsonUtil.getValue(budgetaryAddObject, messageStrings.budgetEnv));
		expect(budgetryPage.getTextBudgetryApplicationFromEditPage()).toEqual(jsonUtil.getValue(budgetaryAddObject, messageStrings.budgetApp));
		//non-editable
		//expect(budgetryPage.getTextBasedOnLabelName("Budget Term")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetTerm));
		expect(budgetryPage.getTextBudgetryDetailsStatus()).toBe(messageStrings.budgetActive);
		budgetryPage.fillOrderDetails(budgetaryUnitEditDetailsTemplate, modifiedEditParamMap);
		budgetryPage.clickOnBudgetaryEditUpdateButton();
		budgetryPage.isPresentBudgetryEditUpdateSuccessMsg();
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		budgetaryName = budgetaryEditName;
		budgetryPage.isPresentBudgetryDetailsUnitPanel();
		expect(budgetryPage.getTextBasedOnLabelName("Name")).toBe(budgetaryName);
		expect(budgetryPage.getTextBasedOnLabelName("Budgetary Unit Identifier")).toBe(budgetaryUnitCode);
		expect(budgetryPage.getTextBasedOnLabelName("Description")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetDesc));
		expect(budgetryPage.getTextBasedOnLabelName("External Reference Id")).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetRefId));
		expect(budgetryPage.getTextBudgetryDetailsOrganization()).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetEntity));
		expect(budgetryPage.getTextBudgetryDetailsEnvironment()).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetEnv));
		expect(budgetryPage.getTextBudgetryDetailsApplication()).toEqual(jsonUtil.getValue(budgetaryObject, messageStrings.budgetApp));
		expect(budgetryPage.getTextBasedOnLabelName("Budget Term")).toEqual(jsonUtil.getValue(budgetaryAddObject, messageStrings.budgetTerm));
		expect(budgetryPage.getTextBudgetryDetailsStatus()).toBe(messageStrings.budgetActive);	
		budgetryPage.clickBudgetSliderCloseButton();
	});
	

	it('Add Budgets for newly created budgetary unit', async function() {	
	
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryAddNewBudgetDetailsTemplate));
		util.waitForAngular();	
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		//budgetryPage.selectbudgetaryPaginationDropDown();
		//var budgetaryName = "autoBudgetUnitEditblNVQr0X";
		budgetryPage.searchBudegtaryUnit(budgetaryName);
		var status = await budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		await expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);	
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(0); //Zero (0) for current month
		modifiedNewBudgetParamMap = {"Name":budgetaryNewBudgetName, "Start Period":startPeriod};
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		//budgetryPage.clickOnBudgetaryBackBudgetButton();
		budgetryPage.clickBudgetSliderCloseButton();
	});
	
	it('Edit Budget details of a budgetary unit', async function() {
				
		util.waitForAngular();	
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		//budgetryPage.selectbudgetaryPaginationDropDown();
		//var budgetaryName = "autoBudgetUnitEditblNVQr0X";
		budgetryPage.searchBudegtaryUnit(budgetaryName);
		var status = await budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		await expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);	
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickViewDetailActionIcon();
		budgetryPage.clickViewDetailBtn();
		budgetryPage.clickBudgetEditButton();
		var modifiedEditParamMap = {};
		budgetryPage.fillOrderDetails(budgetaryBudgetEditDetailsTemplate, modifiedEditParamMap);
		budgetryPage.clickSaveBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		if (browser.params.defaultCurrency == "USD") {
			expect(budgetryPage.getTextBasedOnLabelName("Under Approval Amount")).toBe(messageStrings.budgetZeroCharges);
			expect(budgetryPage.getTextBasedOnLabelName("Committed Amount")).toBe(messageStrings.budgetZeroCharges);
			expect(budgetryPage.getTextBasedOnLabelName("Actual Charges")).toBe(messageStrings.budgetZeroCharges);
		}
		budgetryPage.clickBudgetSliderCloseButton();
	});
	
	
	it('Validate error message while adding same name of budget in newly created budgetary unit though budget is already added', async function() {
	
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryAddNewBudgetDetailsTemplate));
		util.waitForAngular();	
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		//budgetryPage.selectbudgetaryPaginationDropDown();
		//var budgetaryName = "autoBudgetUnitEditblNVQr0X";
		budgetryPage.searchBudegtaryUnit(budgetaryName);
		var status = await budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		await expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);	
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(4); //Zero (0) for current month
		var endPeriod = budgetaryFlow.incrementMonth(2); //two (2) for Quarterly
		modifiedNewBudgetParamMap = {"Name":budgetaryNewBudgetName, "Start Period":startPeriod, "End Period":endPeriod};
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationErrorMsgBudgetPage()).toContain(messageStrings.budgetExistsMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
	});
	
	it('Validate error message while adding budget in newly created budgetary unit though budget is already added', async function() {
		
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryAddNewBudgetDetailsTemplate));
		var NewName = "NewName"+util.getRandomString(8);
		util.waitForAngular(); 
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		//budgetryPage.selectbudgetaryPaginationDropDown();
		//var budgetaryName = "autoBudgetUnitTnjWT4vl";
		budgetryPage.searchBudegtaryUnit(budgetaryName);
		var status = await budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
		await expect(status).toEqual(messageStrings.budgetActive);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);	
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.isBudgetaryAddNewBudgetTextDisplayed();
		var startPeriod = budgetaryFlow.incrementMonth(0); //Zero (0) for current month
		modifiedNewBudgetParamMap = {"Name":NewName, "Start Period":startPeriod};
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);		
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationErrorMsgBudgetPage()).toContain(messageStrings.budgetOverlapsMsg);
		//budgetryPage.clickOnNotificationCloseButton();
		
		//End Period is now disabled and will be auto filled
		//var endPeriod = budgetaryFlow.incrementMonth(2); //two (2) for Quarterly
		/*budgetryPage.setTextBudgetEndPeriod(budgetaryFlow.incrementMonth(3)); //One Month Extra
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		expect(budgetryPage.getTextNotificationErrorMsgBudgetPage()).toContain("endPeriod should be "+endPeriod+" instead of "+budgetaryFlow.incrementMonth(3)+" for budgetaryunit term Quarterly");
		budgetryPage.clickOnNotificationCloseButton();*/
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
	});

	it('Validate error message while editing Budgetary Unit when Budget within is active', function() {		
		
		util.waitForAngular();
		budgetryPage.isPresentbudgetryUnitsText();
		budgetryPage.isPresentAddNewBudgetryUnitBtn();
		budgetryPage.isPresentBudgetryUnitsTable();
		//budgetryPage.selectbudgetaryPaginationDropDown();
		//var budgetaryName = "autoBudgetUnitTnjWT4vl";
		budgetryPage.searchBudegtaryUnit(budgetaryName);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
		budgetryPage.clickOnEditBudgetaryButton();
		expect(budgetryPage.getTextEditBudgetaryUnitErrorMsg()).toContain(messageStrings.budgetaryUnitEditErrorMsg);
		budgetryPage.clickOnErrorMsgCloseBtn();
	});

	it('Validate and Edit Budget Parameter one by one', function () {
		
		budgetryPage.searchBudegtaryUnit(budgetaryName);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickViewDetailActionIcon();
		budgetryPage.clickViewDetailBtn();
		budgetryPage.clickBudgetEditButton();
		budgetryPage.setTextBudgetExternalRefId(budgetRefId);
		budgetryPage.clickSaveBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		expect(budgetryPage.getTextBasedOnLabelName("External Reference ID")).toBe(budgetRefId);

		/*Commented out these validations as soft and hard quota field is converted to dropdownsearch */
		
		//budgetryPage.clickBudgetEditButton();
		//budgetryPage.setTextSoftQutaMailTextbox(budgetaryBudgetEditDetailsTemplate.thresholdMailUser);
		//budgetryPage.clickSaveBudgetButton();
		//expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		//budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		//expect(budgetryPage.getTextSoftQutaMailTextbox()).toBe(budgetaryBudgetEditDetailsTemplate.thresholdMailUser);
		
		
		
		//budgetryPage.clickBudgetEditButton();
		//budgetryPage.setTextHardQutaMailTextbox(budgetaryBudgetEditDetailsTemplate.thresholdMailUser);
		//budgetryPage.clickSaveBudgetButton();
		//expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		//budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		//expect(budgetryPage.getTextHardQutaMailTextbox()).toBe(budgetaryBudgetEditDetailsTemplate.thresholdMailUser);

		budgetryPage.clickBudgetEditButton();
		budgetryPage.setTextSoftQuota(budgetaryBudgetEditDetailsTemplate.QuotaLimit);
		budgetryPage.clickSaveBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		
		//expect(budgetryPage.getBudgetEditableFieldBasedOnIndex("Soft Quota Threshold (Percentage)", 1)).toBe(budgetaryBudgetEditDetailsTemplate.QuotaLimit);
		expect(budgetryPage.getTextBasedOnLabelName("Soft Quota Threshold (Actual)")).toBe(budgetaryBudgetEditDetailsTemplate.QuotaLimit);

		budgetryPage.clickBudgetEditButton();
		budgetryPage.setTextHardQuota(budgetaryBudgetEditDetailsTemplate.QuotaLimit);
		budgetryPage.clickSaveBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		expect(budgetryPage.getTextBasedOnLabelName("Hard Quota Threshold (Actual)")).toBe(budgetaryBudgetEditDetailsTemplate.QuotaLimit);

		budgetryPage.clickBudgetEditButton();
		budgetryPage.setTextBudgetAmount(budgetaryBudgetEditDetailsTemplate.budgetAmount);
		budgetryPage.clickSaveBudgetButton();
		expect(budgetryPage.getTextNotificationMsgBudgetPage()).toContain(messageStrings.budgetSuccessMsg);
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		expect(budgetryPage.getTextBasedOnLabelName("Budget Amount")).toContain(budgetaryBudgetEditDetailsTemplate.budgetAmount);
		budgetryPage.clickBudgetSliderCloseButton();
	});

	it('Making the above created budget Inactive', function () {		
		budgetryPage.searchBudegtaryUnit(budgetaryName);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickViewDetailActionIcon();
		budgetryPage.clickViewDetailBtn();
		budgetryPage.clickBudgetEditButton();
		budgetryPage.clickBudgetInactiveStatusText();
		budgetryPage.clickSaveBudgetButton();
		budgetryPage.clickOnNotificationCloseButton();
		budgetryPage.clickBudgetSliderCloseButton();
	});

	it('Validate and Edit Budgetary Parameter one by one', function () {
		
		budgetryPage.searchBudegtaryUnit(budgetaryName);		
		var budgetaryObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
		var ApplicationId = budgetaryObject["Order Parameters"]["Main Parameters"]["Application"]["id"];
		var EnvironmentId = budgetaryObject["Order Parameters"]["Main Parameters"]["Environment"]["id"];

		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
		budgetryPage.clickOnEditBudgetaryButton();
		budgetryPage.setTextBudgetryName(budgetaryDetailName);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		expect(budgetryPage.getTextBasedOnLabelName("Name")).toBe(budgetaryDetailName);

		budgetaryName = budgetaryDetailName

		budgetryPage.clickOnEditBudgetaryButton();
		budgetryPage.setTextBudgetryDescription(budgetaryUnitEditDetailsTemplate.descriptionText);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		expect(budgetryPage.getTextBasedOnLabelName("Description")).toBe(budgetaryUnitEditDetailsTemplate.descriptionText);

		budgetryPage.clickOnEditBudgetaryButton();
		budgetryPage.setTextBudgetryExternalRefId(budgetaryRefId);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		expect(budgetryPage.getTextBasedOnLabelName("External Reference Id")).toBe(budgetaryRefId);

		budgetryPage.clickOnEditBudgetaryButton();
		budgetryPage.selectDropdownSearch(EnvironmentId, budgetaryUnitEditDetailsTemplate.environmentEditcontext);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		expect(budgetryPage.getTextBudgetryDetailsEnvironment()).toBe(budgetaryUnitEditDetailsTemplate.environmentEditcontext);

		budgetryPage.clickOnEditBudgetaryButton();
		budgetryPage.selectDropdownSearch(ApplicationId, budgetaryUnitEditDetailsTemplate.applicationEditContext);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
		expect(budgetryPage.getTextBudgetryDetailsApplication()).toBe(budgetaryUnitEditDetailsTemplate.applicationEditContext);
		// budgetryPage.clickBudgetSliderCloseButton();

	});

	it('798-Budget viewer role- verify "Add New Budgetary Unit" button is invisible  ',async  function () {		
		var budgetViewerBudgetObject = JSON.parse(JSON.stringify(credentialsTemplate));
		// cartListPage.clickUserIcon();
		// cartListPage.clickLogoutButton();

		//login with the buyer viewer role user
		await cartListPage.loginFromOtherUser(budgetViewerBudgetObject.budgetViewerID, budgetViewerBudgetObject.budgetViewerPass);
		//expect(budgetryPage.getUserName()).toContain(budgetViewerBudgetObject.budgetViewerName);

		budgetryPage.clickOnViewBudgetTab();

		//Verifying invisibility of Add New budgetary Button
		expect(budgetryPage.invisibilityOfAddBudgetryButton()).toBe(false);

		//Verifying subtitle is present
		//Commenting as its not applicable
		//expect(budgetryPage.getViewBudgetDescriptionText()).toEqual(messageStrings.subHeading)

		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetryPage.searchBudegtaryUnit(budgetaryDetailName);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryDetailName);
		expect(budgetryPage.getTextBudgetryDetailsName()).toBe(budgetaryDetailName);

		//verifying budget view details and invisibility of edit button
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickViewDetailActionIcon();
		budgetryPage.clickViewDetailBtn();
		expect(budgetryPage.invisibilityOfBudgetEditButton()).toBe(false);

		budgetryPage.clickBudgetSliderCloseButton();
        
    });
	
// 	afterAll(async function () {
// 		orderFlowUtil.closeHorizontalSliderIfPresent();
// 		// Logout with the Budget viewer user
// 		// cartListPage.clickUserIcon();
// 		// cartListPage.clickLogoutButton();

// 		// Login with the Super user
// 		await cartListPage.loginFromOtherUser(superUserUsername, superUserPassword);
		
// 		//Delete budgetary unit created above from budgetary unit details page 
// 		//util.waitForAngular();
// 		budgetryPage.open();
// 		budgetryPage.searchBudegtaryUnit(budgetaryName);
// // 		budgetryPage.selectbudgetaryPaginationDropDown();
// // 		budgetaryFlow.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
// 		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
// 		budgetryPage.clickOnDeleteBtnFromBudgetaryDetailsPage();
// 		budgetryPage.clickOnDeleteConfirmationButton();
// 		expect(budgetryPage.getNotificationMsg()).toContain(messageStrings.budgetaryUnitDeleteSuccessMsg);
		
// 		//Deleting budgetary unit from API is not used now as delete option aailable on UI.		
// 		/*	budgetryPage.closeBudgetSliderIfPresent();
// 			await budgetDeleteApi.getListOfBudegetaryUnit(budgetaryDetailName).then(async function (budget) {
// 	    	logger.info("budget details"+budget);
// 	    	await budgetDeleteApi.deleteInActiveBudget(budget["budgetcode"],budget["id"]).then(async function (status) {
// 			expect(status).toEqual(messageStrings.budgetDeletedApiSucessMsg);
// 			await budgetDeleteApi.deleteBudetaryUnit(budget["budgetcode"]).then(async function (status) {
// 			expect(status).toEqual(messageStrings.budgetaryUnitDeletedApiSucessMsg);
// 		   });
// 	     });
// 	   });*/		
		
// 	});
});
