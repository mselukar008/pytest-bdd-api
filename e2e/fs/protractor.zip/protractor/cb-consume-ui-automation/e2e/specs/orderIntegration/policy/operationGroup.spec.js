/*************************************************
	AUTHOR: Anjali Ghutke
 **************************************************/

"use strict"
var OperationsPolicy = require('../../../pageObjects/operationsPolicy.pageObject.js'),
    PolicyPage = require('../../../pageObjects/policy.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    operationGroupTemplate = require('../../../../testData/OrderIntegration/policy/operationGroup.json'),
    testEnvironment = browser.params.url.includes("cb-qa-1") ? "QA 1" : browser.params.url.includes("cb-qa-2") ? "QA 2" : browser.params.url.includes("customer1") ? "Customer 1" : "QA 4";



describe("Test the Operation Policy ", function () {


    var operationGroupName, modifiedParamMap, editedOperationGroupName, approvalPolicyPage, operationPolicyPage;
    var modifiedParamMapEdit = {};

    beforeAll(function () {
        operationPolicyPage = new OperationsPolicy();
        approvalPolicyPage = new PolicyPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        operationGroupName = "automationGroupPolicy" + util.getRandomString(5);
        editedOperationGroupName = "editAtuoOperationGrp" + util.getRandomString(4);
        modifiedParamMap = { "Name": operationGroupName };
        modifiedParamMapEdit = { "Name": editedOperationGroupName, "EditService": true };
    });

    it("Create, Edit and Delete the operation Group", function () {
        operationPolicyPage.open();
        operationPolicyPage.openOperationGroup();

        //Create a operation group
        operationPolicyPage.clickNewOperationGroupButton();
        approvalPolicyPage.fillPolicyDetails(operationGroupTemplate, modifiedParamMap);
        operationPolicyPage.clickOnAddOperationGroupButton();

        expect(operationPolicyPage.verifyTheToastMsgOfOperationGroupPopUP()).toBe(operationGroupTemplate.operationGrpCreatedMsg);
        operationPolicyPage.clickCloseBtnOfNotificationPopUp();
        operationPolicyPage.searchOperationGroup(operationGroupName);
        util.waitForAngular();

        //Verify the Details of the service
        operationPolicyPage.clickOnTheActionOverflowMenuIconOfOperationPolicyGroup();
        operationPolicyPage.clickOnViewDetailsActionOfOperationGroup();
        util.waitForAngular();

        //expect(operationPolicyPage.getOperationPolicySlidderPanelTitle()).toEqual("automationGroupPolicyT54QI");
        expect(operationPolicyPage.getOperationGroupNameFromTheViewDetailPage()).toEqual(operationGroupName);
        expect(operationPolicyPage.getOperationsFromTheViewDetailPage("AddDisk (VRA)")).toContain(operationGroupTemplate["Policy Parameters"]["Main Parameters"]["Operation"]["value"][testEnvironment])

        //Edit the operation group
        approvalPolicyPage.fillPolicyDetails(operationGroupTemplate, modifiedParamMapEdit);
        operationPolicyPage.clickOnUpdateButtonOfOperationGroup();

        
        operationPolicyPage.verifyTheToastMsgOfOperationGroupPopUP();

        //Verify the edited data
        util.waitForAngular();

        operationPolicyPage.searchOperationGroup(editedOperationGroupName);
        util.waitForAngular();

        //Verify the Details of the service
        operationPolicyPage.clickOnTheActionOverflowMenuIconOfOperationPolicyGroup();
        operationPolicyPage.clickOnViewDetailsActionOfOperationGroup();
        util.waitForAngular();

        //expect(operationPolicyPage.getOperationPolicySlidderPanelTitle()).toEqual("automationGroupPolicyT54QI");
        expect(operationPolicyPage.getOperationGroupNameFromTheViewDetailPage()).toEqual(editedOperationGroupName);
        expect(operationPolicyPage.getOperationsFromTheViewDetailPage("Turn ON (VRA)")).toContain(operationGroupTemplate["Edit Parameters"]["Edit Operation Group"]["Operation"]["value"][testEnvironment]);
        expect(operationPolicyPage.getOperationsFromTheViewDetailPage("AddDisk (VRA)")).toContain(operationGroupTemplate["Policy Parameters"]["Main Parameters"]["Operation"]["value"][testEnvironment]);
        

        operationPolicyPage.clickOnDeleteButtonOfOperationGroup();
        operationPolicyPage.clickOnContinueButtonOfDeletePopupOfOperationGroup();
        expect(operationPolicyPage.verifyTheToastMsgOfOperationGroupPopUP()).toBe(editedOperationGroupName + operationGroupTemplate.operationGrpDeleteMsg);
     
        //Verify the group deleted successfully.
        operationPolicyPage.searchOperationGroup(operationGroupName);
        expect(operationPolicyPage.verifyTheOperationGroupDeleted()).toBe(true);

    });

    it("Duplicate of the operation Group", function () {
        var duplicateOfOperationGroupName = "duplicateOperationGroup" + util.getRandomString(5);
        operationPolicyPage.open();
        operationPolicyPage.openOperationGroup();

        //Create a operation group
        operationPolicyPage.clickNewOperationGroupButton();
        approvalPolicyPage.fillPolicyDetails(operationGroupTemplate, modifiedParamMap);
        operationPolicyPage.clickOnAddOperationGroupButton();

        expect(operationPolicyPage.verifyTheToastMsgOfOperationGroupPopUP()).toBe(operationGroupTemplate.operationGrpCreatedMsg);
        operationPolicyPage.clickCloseBtnOfNotificationPopUp();

        operationPolicyPage.searchOperationGroup(operationGroupName);
        util.waitForAngular();

        //Create a duplicate of operation group
        operationPolicyPage.clickOnTheActionOverflowMenuIconOfOperationPolicyGroup();
        operationPolicyPage.clickOnDuplicateButtonOFOperationGroup();
        operationPolicyPage.enterTheDuplicateOperationGroupName(duplicateOfOperationGroupName);
        operationPolicyPage.clickOnDuplicateButtonOfOperationGroup();
        expect(operationPolicyPage.verifyTheToastMsgOfOperationGroupPopUP()).toContain(operationGroupTemplate.duplicateOperationGroup);


        operationPolicyPage.searchOperationGroup(duplicateOfOperationGroupName);
        util.waitForAngular();

        operationPolicyPage.clickOnTheActionOverflowMenuIconOfOperationPolicyGroup();
        operationPolicyPage.clickOnViewDetailsActionOfOperationGroup();
        util.waitForAngular();

        //Verify the details of the duplicate operation group the duplicate group operation should match
        //expect(operationPolicyPage.getOperationPolicySlidderPanelTitle()).toEqual("automationGroupPolicyT54QI");
        expect(operationPolicyPage.getOperationGroupNameFromTheViewDetailPage()).toEqual(duplicateOfOperationGroupName);
        expect(operationPolicyPage.getOperationsFromTheViewDetailPage("AddDisk (VRA)")).toContain(operationGroupTemplate["Policy Parameters"]["Main Parameters"]["Operation"]["value"][testEnvironment])

        //Delete the created duplicate operation group
        operationPolicyPage.clickOnDeleteButtonOfOperationGroup();
        operationPolicyPage.clickOnContinueButtonOfDeletePopupOfOperationGroup();
        expect(operationPolicyPage.verifyTheToastMsgOfOperationGroupPopUP()).toBe(duplicateOfOperationGroupName + operationGroupTemplate.operationGrpDeleteMsg);
        
        //Verify the group deleted successfully.
        operationPolicyPage.searchOperationGroup(duplicateOfOperationGroupName);
        expect(operationPolicyPage.verifyTheOperationGroupDeleted()).toBe(true);

        //Delete the operation group
        operationPolicyPage.searchOperationGroup(operationGroupName);
        util.waitForAngular();
        operationPolicyPage.clickOnTheActionOverflowMenuIconOfOperationPolicyGroup();
        operationPolicyPage.deleteOperationGroup();
        expect(operationPolicyPage.verifyTheToastMsgOfOperationGroupPopUP()).toBe(operationGroupName + operationGroupTemplate.operationGrpDeleteMsg);
        //Verify the group deleted successfully.
        operationPolicyPage.searchOperationGroup(operationGroupName);
        expect(operationPolicyPage.verifyTheOperationGroupDeleted()).toBe(true);

    });

    

});


