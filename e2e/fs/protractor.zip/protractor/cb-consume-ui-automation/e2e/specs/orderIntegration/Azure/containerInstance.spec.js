/*
Spec_Name: containerInstance.spec.js 
Description: This spec will cover E2E testing of Container Instance service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../../testData/appUrls.json'),
        util = require('../../../../helpers/util.js'),
        jsonUtil = require('../../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
        CITemplate = require('../../../../testData/OrderIntegration/Azure/ContainerInstance.json');

describe('Azure - Container Instance', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, orderHistoryPage, catalogDetailsPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Compute' };
        var modifiedParamMap = {};
        var servicename = "AutoCIsrv" + util.getRandomString(5);
        var rgName = "gslautotc_azureCIRG101" + util.getRandomString(5);
        var ciName = "autoci" + util.getRandomNumber(5);
        var dnsName = "autoci" + util.getRandomNumber(5);
        var SOIComponents, ciNameInventory;
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Container Name": ciNameInventory, "DNS Name Label": dnsName };

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                orderHistoryPage = new OrderHistoryPage();
                catalogDetailsPage = new CatalogDetailsPage()
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
                rgName = "gslautotc_azureCIRG101" + util.getRandomString(5);
                ciName = "autoci" + util.getRandomNumber(5);
                ciName = ciName.toLowerCase();
                dnsName = "autoci" + util.getRandomNumber(5);
                dnsName = dnsName.toLowerCase();
                ciNameInventory = ciName + "-aut1";
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Container Name": ciName, "DNS Name Label": dnsName };
                SOIComponents = [ciNameInventory]
        });
        afterAll(function () {
                //Delete  Container Instance.
                var returnObj = {};
                returnObj.servicename = servicename;
                returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                orderFlowUtil.approveDeletedOrder(returnObj);
                orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        });

        //E2E Container Instance order Submit, Approve, Delete Service with New Resource Group.
        if (isProvisioningRequired == "true") {
                it('Azure: TC-T467502 Verify if create new Container Instance with New Resource Group, with Image for Public Registry, with Public IP with additional Ports enabled, TCP, Restart Policy - Always, Environment Variables is working fine.', function () {
                        var orderObject = JSON.parse(JSON.stringify(CITemplate));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};
                        orderFlowUtil.fillOrderDetails(CITemplate, modifiedParamMap);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Checking Inventory Page Service Configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnLabelName("Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Container Name:")).toContain(ciName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Container Location:")).toEqual(jsonUtil.getValue(orderObject, "Container Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Container Image Type:")).toEqual(jsonUtil.getValue(orderObject, "Container Image Type"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Container Image:")).toEqual(jsonUtil.getValue(orderObject, "Container Image"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Operating System Type:")).toEqual(jsonUtil.getValue(orderObject, "Operating System Type"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Number Of Cores:")).toEqual(jsonUtil.getValue(orderObject, "Number Of Cores"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Memory (GB):")).toEqual(jsonUtil.getValue(orderObject, "Memory (GB)"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Public IP Address:")).toEqual(jsonUtil.getValue(orderObject, "Public IP Address"));
                        expect(inventoryPage.getTextBasedOnLabelName(" DNS Name Label:")).toContain(dnsName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Port:")).toEqual(jsonUtil.getValue(orderObject, "Port"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Open Additional Ports:")).toEqual(jsonUtil.getValue(orderObject, "Open Additional Ports"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Port Protocol:")).toEqual(jsonUtil.getValue(orderObject, "Port Protocol"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Restart Policy:")).toEqual(jsonUtil.getValue(orderObject, "Restart Policy"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Add Additional Environment Variables:")).toEqual(jsonUtil.getValue(orderObject, "Add Additional Environment Variables"));
                        inventoryPage.closeViewDetailsTab();
                        //Checking SOI Components
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.clickExpandFirstRow().then(function () {
                                        browser.executeScript('window.scrollTo(0,0);');
                                        var i = 1;
                                        async.forEachSeries(SOIComponents, function (component, callback) {
                                                inventoryPage.clickOverMenuIcon(i).then(function () {
                                                        inventoryPage.clickOnViewComponent(i).then(function () {
                                                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.bluePrintName);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.mcmpTag);
                                                                inventoryPage.closeViewComponent();
                                                                browser.sleep(10000);
                                                                i++;
                                                                return callback();
                                                        });
                                                })
                                        }, function (error) {
                                                if (error) {
                                                        logger.info('Unable to Get SOI component')
                                                }
                                        })
                                })
                        }
                       // check Non-Editable service Message
                       inventoryPage.clickNonEditableInstance();
                       expect(inventoryPage.getTextForInvalidEditModal()).toEqual(CITemplate.nonEditableText);
                       inventoryPage.clickOnInvalidEditOkModal();
                });
        }
        //Checking parameters on Main Parameters page
        it('Azure: TC-T467489 verify that for Container Instances Service all parameters on Main Parameters Page are present.', function () {
                var orderObject = JSON.parse(JSON.stringify(CITemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
                if (browser.params.defaultCurrency == "USD") {
                expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
                }
        });

        //Checking values all parameters on Review Order Page and View Order Details
        it('Azure: TC-T467491 verify that for Container Instance Service all values on Review Order Details and View Order Details page matches with input.', function () {
                var returnObj = {};
                returnObj.servicename = servicename;
                var orderObject = JSON.parse(JSON.stringify(CITemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(CITemplate, modifiedParamMap);
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
                if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
                }
                //Checking Additional Details in ReviewOrder
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Container Name:")).toEqual(ciName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Container Location:")).toEqual(jsonUtil.getValue(orderObject, "Container Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Container Image Type:")).toEqual(jsonUtil.getValue(orderObject, "Container Image Type"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Container Image:")).toEqual(jsonUtil.getValue(orderObject, "Container Image"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Operating System Type:")).toEqual(jsonUtil.getValue(orderObject, "Operating System Type"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Number Of Cores:")).toEqual(jsonUtil.getValue(orderObject, "Number Of Cores"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Memory (GB):")).toEqual(jsonUtil.getValue(orderObject, "Memory (GB)"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Public IP Address:")).toEqual(jsonUtil.getValue(orderObject, "Public IP Address"));
                expect(placeOrderPage.getTextBasedOnLabelName(" DNS Name Label:")).toEqual(dnsName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Port:")).toEqual(jsonUtil.getValue(orderObject, "Port"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Open Additional Ports:")).toEqual(jsonUtil.getValue(orderObject, "Open Additional Ports"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Port Protocol:")).toEqual(jsonUtil.getValue(orderObject, "Port Protocol"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Restart Policy:")).toEqual(jsonUtil.getValue(orderObject, "Restart Policy"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Add Additional Environment Variables:")).toEqual(jsonUtil.getValue(orderObject, "Add Additional Environment Variables"));
                placeOrderPage.submitOrder();
                var priceInReviewOrder = placeOrderPage.getEstimatedPrice_ReviewOrder();
                var priceInSubmitOrderPopup = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                if (browser.params.defaultCurrency == "USD") {
                expect(priceInSubmitOrderPopup).toEqual(priceInReviewOrder);
                }
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                ordersPage.open();
                ordersPage.searchOrderById(returnObj.orderNumber);
                if (browser.params.defaultCurrency == "USD") {
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(orderObject.EstimatedCost);
                }
                ordersPage.clickFirstViewDetailsOrdersTable();
                //Checking Order Details in View order details
                expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
                //Checking Service Configuration Parameters
                expect(ordersPage.getTextBasedOnLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
                expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(ordersPage.getTextBasedOnLabelName("Container Name")).toEqual(ciName);
                expect(ordersPage.getTextBasedOnLabelName("Container Location")).toEqual(jsonUtil.getValue(orderObject, "Container Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Container Image Type")).toEqual(jsonUtil.getValue(orderObject, "Container Image Type"));
                expect(ordersPage.getTextBasedOnExactLabelName("Container Image")).toEqual(jsonUtil.getValue(orderObject, "Container Image"));
                expect(ordersPage.getTextBasedOnLabelName("Operating System Type")).toEqual(jsonUtil.getValue(orderObject, "Operating System Type"));
                expect(ordersPage.getTextBasedOnLabelName("Number Of Cores")).toEqual(jsonUtil.getValue(orderObject, "Number Of Cores"));
                expect(ordersPage.getTextBasedOnLabelName("Memory (GB)")).toEqual(jsonUtil.getValue(orderObject, "Memory (GB)"));
                expect(ordersPage.getTextBasedOnLabelName("Public IP Address")).toEqual(jsonUtil.getValue(orderObject, "Public IP Address"));
                expect(ordersPage.getTextBasedOnLabelName("DNS Name Label")).toEqual(dnsName);
                expect(ordersPage.getTextBasedOnLabelName("Port")).toEqual(jsonUtil.getValue(orderObject, "Port"));
                expect(ordersPage.getTextBasedOnLabelName("Open Additional Ports")).toEqual(jsonUtil.getValue(orderObject, "Open Additional Ports"));
                expect(ordersPage.getTextBasedOnLabelName("Port Protocol")).toEqual(jsonUtil.getValue(orderObject, "Port Protocol"));
                expect(ordersPage.getTextBasedOnLabelName("Restart Policy")).toEqual(jsonUtil.getValue(orderObject, "Restart Policy"));
                expect(ordersPage.getTextBasedOnExactLabelName("Add Additional Environment Variables")).toEqual(jsonUtil.getValue(orderObject, "Add Additional Environment Variables"));
                //Checking Bill Of Material
                if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
                }
                orderHistoryPage.open();
                orderHistoryPage.searchOrderById(returnObj.orderNumber);
                orderHistoryPage.clickServiceDetailsLink();
                // Checking service view details on order history page
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Container Name")).toEqual(ciName);
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Operating System Type")).toEqual(jsonUtil.getValue(orderObject, "Operating System Type"));
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Number Of Cores")).toEqual(jsonUtil.getValue(orderObject, "Number Of Cores"));
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Memory (GB)")).toEqual(jsonUtil.getValue(orderObject, "Memory (GB)"));
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Public IP Address")).toEqual(jsonUtil.getValue(orderObject, "Public IP Address"));
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("DNS Name Label")).toEqual(dnsName);
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Open Additional Ports")).toEqual(jsonUtil.getValue(orderObject, "Open Additional Ports"));
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Port Protocol")).toEqual(jsonUtil.getValue(orderObject, "Port Protocol"));
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Restart Policy")).toEqual(jsonUtil.getValue(orderObject, "Restart Policy"));
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Add Additional Environment Variables")).toEqual(jsonUtil.getValue(orderObject, "Add Additional Environment Variables"));
                if (browser.params.defaultCurrency == "USD") {
                orderHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(orderHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(orderObject.TotalCost);
                }
                orderHistoryPage.closeServiceDetailsSlider();
        });
});