
/*	
Spec_Name:e2eGcpSingleVirtualMachine.spec.js
Description: It covers e2e flow of provisioning of GCP service,Access view component for vm. validation of base price, BOM for TA service.	
Author: Sarika Bothe
//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.
*/


"use strict";

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	Orders = require('../../../pageObjects/orders.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
	CatalogDiscoveryPage = require('../../../pageObjects/catalogDiscovery.pageObject.js'),
	ServiceVersiondetail = require('../../../../testData/OrderIntegration/ICAM/ServiceGroupAndVersion.json'),
	vmInGcpTemplate = require('../../../../testData/OrderIntegration/ICAM/GcpSingleVirtualMachine.json');

describe('TA - E2E Test cases for TA -ON Virtual machine in GCP service', function () {

	var catalogPage, placeOrderPage, ordersPage, serviceName, virtualMachineName, gcpSshKeyName, UniqueKeyName, inventoryPage,catalogDiscoveryObj;
	var modifiedParamMap = {};
	var messageStrings = {
		providerName: vmInGcpTemplate.providerName,
		category: vmInGcpTemplate.category,
		estimatedPrice: vmInGcpTemplate.estimatedPrice,
		providerAccount: vmInGcpTemplate.providerAccount,
		completedState: vmInGcpTemplate.completedState,
		approvalState: vmInGcpTemplate.approvalState,
		orderTypeDel: vmInGcpTemplate.orderTypeDel,
		urlOrders: vmInGcpTemplate.urlOrders,
		estimatedCost: vmInGcpTemplate.estimatedCost,
		orderSubmittedConfirmationMessage: vmInGcpTemplate.orderSubmittedConfirmationMessage,
	};

	beforeAll(function () {
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		catalogDiscoveryObj = new CatalogDiscoveryPage();
		inventoryPage = new InventoryPage();
		serviceName = vmInGcpTemplate.serviceNamePrefix + "-" + util.getRandomString(5);

		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		UniqueKeyName = vmInGcpTemplate.virtualMachineNamePrefix + (util.getRandomString(5)).toLowerCase();
		modifiedParamMap = { "Service Instance Name": serviceName, "Unique resource name": UniqueKeyName}
	});

	it('TC 01 : TA -ON Virtual machine in GCP ---- Verify fields on Main Parameters page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.clickConfigureButtonBasedOnName(vmInGcpTemplate.bluePrintName);
		expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
		placeOrderPage.setServiceNameTextICAM(vmInGcpTemplate.serviceNamePrefix + "-" + util.getRandomString(4));
		placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
		expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
		//expect(placeOrderPage.getTextEstimatedPrice()).toBe(vmInGcpTemplate.EstimatedPrice);
	});

	it('TC 02 : TA-ON Virtual machine in GCP ---- Verify Summary details and Additional Details are listed in review Order page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.clickConfigureButtonBasedOnName(vmInGcpTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetailsICAM(vmInGcpTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
			//	expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPrice);
			expect(requiredReturnMap["Actual"]["Instance Plan"]).toEqual(requiredReturnMap["Expected"]["Instance Plan"]);
			expect(requiredReturnMap["Actual"]["GCP connection"]).toEqual(requiredReturnMap["Expected"]["GCP connection"]);
		});
	});

	it('TC 03 : TA-ON Virtual machine in GCP ---- Verify Order is listed in Orders details page once it is submitted from catalog page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.clickConfigureButtonBasedOnName(vmInGcpTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetailsICAM(vmInGcpTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			placeOrderPage.submitOrder();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			var orderId = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			ordersPage.open();
			expect(util.getCurrentURL()).toMatch(messageStrings.urlOrders);
			ordersPage.searchOrderById(orderId);
			expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderId);
			ordersPage.clickFirstViewDetailsOrdersTable();
			expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual(messageStrings.approvalState);
			expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
			expect(ordersPage.isDisplayedDenyButtonOrderDetails()).toEqual(true);
			ordersPage.clickServiceConfigurationsTabOrderDetails();
			expect(ordersPage.getTextBasedOnLabelName("Instance Plan")).toEqual((requiredReturnMap["Expected"]["Instance Plan"]));
			expect(requiredReturnMap["Actual"]["GCP connection"]).toEqual(requiredReturnMap["Expected"]["GCP connection"]);
			ordersPage.clickBillOfMaterialsTabOrderDetails();
			//	expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);

		});
	});

	if (isProvisioningRequired == "true") {
		it('TC 04 : TA-ON Virtual machine in GCP --- Verify Provision of service  and  base price', function () {
			var orderObject = {};
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
            catalogPage.searchForBluePrint(vmInGcpTemplate.bluePrintName);
            catalogPage.clickDetailsButtonBasedOnName(vmInGcpTemplate.bluePrintName);
            expect(catalogPage.getOneTimeChargePrice()).toBe("USD 45.50/ PLAN / Month + USD 0.00");
            catalogPage.open();

			catalogPage.searchForBluePrint(vmInGcpTemplate.bluePrintName);
			catalogPage.clickConfigureButtonBasedOnName(vmInGcpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetailsICAM(vmInGcpTemplate, modifiedParamMap);
			expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPrice);
			placeOrderPage.submitOrder();
			 orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			 orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextTotalPriceOrderSubmittedModal()).toBe(messageStrings.estimatedPrice);
			 placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			 ordersPage.open();
			 ordersPage.searchOrderById(orderObject.orderNumber);
			 ordersPage.clickFirstViewDetailsOrdersTable();
			 ordersPage.clickBillOfMaterialsTabOrderDetails();
			 expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);
			 ordersPage.closeServiceDetailsSlider();
			 orderFlowUtil.approveOrder(orderObject);
			 orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
			 expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
		});

		it('TC 05 : TA -ON Virtual machine in GCP --- click on view access component for Virtual Machine', function () {

			catalogPage.open();
			var orderObject = {}; 
			orderObject.servicename = serviceName;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
					inventoryPage.clickViewAccessComponentIcam();
					inventoryPage.readAccessComponentIcam();
					inventoryPage.viewAccessComponentOkIcam();
					util.waitForAngular();
					});
				});
        });

		//taint operation
		it('TA 06: TA -ON Virtual machine in GCP - Verify for Start Virtual machine, taint operation is working fine or not', function () {
			var orderObject = {};
			orderObject.componentType = vmInGcpTemplate.componentType;
			orderObject.servicename = serviceName;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
					inventoryPage.clickTaintONButtonOfInstanceIcam();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnOFFPermission();
					util.waitForAngular();
				});
			}).then(function () {
				var orderObject = JSON.parse(JSON.stringify(vmInGcpTemplate));

				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();
				orderFlowUtil.approveOrder(orderObject);
				orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);

			});

		});

		//untaint operation
		it('TA 07: TA -ON Virtual machine in GCP - Verify for Start Virtual machine, untaint operation is working fine or not', function () {
			var orderObject = {};
			orderObject.componentType = vmInGcpTemplate.componentType;
			orderObject.servicename = serviceName;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
					inventoryPage.clickUntaintONButtonOfInstanceIcam();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnOFFPermission();
					util.waitForAngular();
				});
			}).then(function () {
				var orderObject = JSON.parse(JSON.stringify(vmInGcpTemplate));

				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();
				orderFlowUtil.approveOrder(orderObject);
				orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);

			});

		});
	
		//Shutdown operation
		it('TA 08: TA -ON Virtual machine in GCP - Verify for Shutdown Virtual machine, when VM is turned ON, status should get changed from ON to OFF', function () {
			var orderObject = {};
			orderObject.componentType = vmInGcpTemplate.componentType;
			orderObject.servicename = serviceName;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
					inventoryPage.icamClickShutdownButtonOfInstance();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnOFFPermission();
					util.waitForAngular();
				});

			}).then(function () {
				var orderObject = JSON.parse(JSON.stringify(vmInGcpTemplate));

				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();
				orderFlowUtil.approveOrder(orderObject);
				orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
			});

		});

		it('TC 09 : TA -ON Virtual machine in GCP - To verify service should not be able to delete if there are any active instances associated to it.  ', function () {
			catalogPage.open();
			catalogDiscoveryObj.open();
			catalogDiscoveryObj.clickOnPublishSectionLink();
			catalogDiscoveryObj.searchServiceOrProviderName(vmInGcpTemplate.bluePrintName);
			catalogDiscoveryObj.clickOnThreeDotMenuIcon(vmInGcpTemplate.bluePrintName);
			catalogDiscoveryObj.clickOnRetireServiceOption();
			catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
			expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(ServiceVersiondetail.RetiredMsg);
			catalogDiscoveryObj.clickOnRetiredSectionLink();
			catalogDiscoveryObj.searchServiceOrProviderName(vmInGcpTemplate.bluePrintName);
			catalogDiscoveryObj.clickOnThreeDotMenuIcon(vmInGcpTemplate.serviceVesrion);
			catalogDiscoveryObj.ClickOnDeleteService();
			catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
			expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(vmInGcpTemplate.UnretiredFailedMsg);
			catalogDiscoveryObj.open();
			catalogDiscoveryObj.clickOnRetiredSectionLink();
			catalogDiscoveryObj.searchServiceOrProviderName(vmInGcpTemplate.bluePrintName);
			catalogDiscoveryObj.clickOnThreeDotMenuIcon(vmInGcpTemplate.serviceVesrion);
			catalogDiscoveryObj.clickOnUnretireServiceOption();
			catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
			expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(ServiceVersiondetail.UnretiredMsg);
			catalogDiscoveryObj.clickOnPublishSectionLink();
			catalogDiscoveryObj.searchServiceOrProviderName(vmInGcpTemplate.bluePrintName);
			expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(vmInGcpTemplate.bluePrintName);

		});

		it('TA 10: TA -ON Virtual machine in GCP - Verify delete services', function () {

			var orderObject = {};
			orderObject.servicename = serviceName;
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
			orderFlowUtil.approveDeletedOrder(orderObject);
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState);
		});

	}
});
