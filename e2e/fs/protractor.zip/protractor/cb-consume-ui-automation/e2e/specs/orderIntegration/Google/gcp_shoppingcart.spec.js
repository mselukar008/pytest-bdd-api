
"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
	HomePage = require('../../../pageObjects/home.pageObject.js'),
	CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	cloudStorageTemplate = require('../../../../testData/OrderIntegration/Google/cloudstorage.json'),
	persistentDiskTemplate = require('../../../../testData/OrderIntegration/Google/persistentdisk.json'),
	vpcTemplate = require('../../../../testData/OrderIntegration/Google/vpc.json'),
	ec2InstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSEC2Instance.json'),
    	pubSubTemplate = require('../../../../testData/OrderIntegration/Google/pubsub.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,	
	userCredentialsTemplate = require('../../../../testData/credentials.json');

describe('GCP - Cart Functionlaities', function () {
	var ordersPage, homePage, catalogPage, placeOrderPage, cartListPage, orderHistoryPage, serviceName, cartName, userCredntialsObject;
	var modifiedParamMap = {};
	var multiquantityParamMap = {};
	var messageStrings = {
		providerName: 'Google',
		catalogPageTitle: 'Search, Select and Configure',
		inputServiceNameWarning: "Parameter Warning:",
		orderSubmittedConfirmationMessage: 'Order Submitted',
		cartSuccessfullyDeletedMessage: "Your cart has successfully been deleted.",
		cartSuccessfullyEmptiedMessage: "Your cart has successfully been emptied.",
		cartSuccessfullyTransferredToMessage: "Your cart has successfully been transferred to",
	};

	beforeAll(function () {
		ordersPage = new Orders();
		homePage = new HomePage();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		orderHistoryPage = new OrderHistoryPage();
		userCredntialsObject = JSON.parse(JSON.stringify(userCredentialsTemplate));
		global.serviceName = undefined;
		//browser.driver.manage().window().maximize();		
	});
	
// 	afterAll(async function () {		
// 		//Make sure that super user is logged in
// 		orderFlowUtil.closeHorizontalSliderIfPresent();
// 		catalogPage.open();			
// 		catalogPage.getUserID(userCredentialsTemplate.superUserName).then(function (status) {
// 			if (status != true) {	
// 				cartListPage.clickUserIcon();
// 				cartListPage.clickLogoutButton();
// 				cartListPage.loginFromOtherUser(userCredentialsTemplate.superUserID, userCredentialsTemplate.superUserPassword);
// 				catalogPage.open();
// 				expect(catalogPage.getUserID(userCredentialsTemplate.superUserName)).toBe(true);
// 			}			
// 		});
// 	});

	beforeEach(function () {
		orderFlowUtil.closeHorizontalSliderIfPresent();
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		serviceName = "auto-" + util.getRandomString(5);
		cartName = "aut-gcp-" + util.getRandomString(5);
		modifiedParamMap = { "Service Instance Name": serviceName, "Cart Service": "Click", "New Shopping Cart": "newCart", "Cart Name": cartName };
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
	});

// 	xit('GCP - Delete carts from cart list of transfer cart user if cart count is greater than 40', async function () {

// 		//Delete carts from current user
// 		/*cartListPage.deleteAllCartsfromCartList();
// 		cartListPage.clickUserIcon();
// 		cartListPage.clickLogoutButton().then(function () {
// 			cartListPage.loginFromOtherUser(userCredntialsObject.transferCartUser, userCredntialsObject.transferCartPwd);
// 			catalogPage.open();
// 			//Delete carts from transfercart user
// 			cartListPage.deleteAllCartsfromCartList();
// 		});
// 		//Login with cbadmn user		
// 		cartListPage.clickUserIcon();
// 		cartListPage.clickLogoutButton().then(function () {
// 			cartListPage.loginFromOtherUser(browser.params.username, browser.params.password);			
// 		});*/
		
// 		var bagId;
// 		//Get the total shopping carts count
// 		await apiUtil.getShoppingCartList().then(async function(response){
// 			response.forEach(async function(bagDetails) {
// 				bagId = bagDetails.bagId;
// 				//Delete cart
// 				await apiUtil.deleteShoppingCart(bagId).then(function(apiResponse){
// 					console.log(apiResponse["reasons"][0]["messages"][0]);
// 				});
// 			});			
// 		});
// 	});

	xit('TC- GCP-Cart-Pricing Validation for Multiqunatity service', function () {		
// 		catalogPage.getUserID(userCredentialsTemplate.superUserName).then(function (status) {
// 			if (status != true) {
// 				cartListPage.clickUserIcon();
// 				cartListPage.clickLogoutButton();
// 				cartListPage.loginFromOtherUser(userCredentialsTemplate.superUserID, userCredentialsTemplate.superUserPassword);
// 				catalogPage.open();
// 				expect(catalogPage.getUserID(userCredentialsTemplate.superUserName)).toBe(true);
// 				catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
// 			}
// 		});
		
		multiquantityParamMap = { "Service Instance Name": serviceName, "Quantity": "3", "Cart Service": "Click", "New Shopping Cart": "newCart", "Cart Name": cartName };
		//util.switchToFrame();
		catalogPage.clickProviderOrCategoryCheckbox(persistentDiskTemplate.Category);
		catalogPage.clickConfigureButtonBasedOnName(persistentDiskTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetails(persistentDiskTemplate, multiquantityParamMap);
		placeOrderPage.addToShoppingCart();
		expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
		//Verify Pricing
		if (browser.params.defaultCurrency == "USD") {
			cartListPage.expandsTheCartItemsTab();
			cartListPage.clickActionIcon(1);
			cartListPage.clickCurrentCartBOMDetails();
			expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toBe(persistentDiskTemplate.TotalEstimatedCost_Cart);
			cartListPage.clickOnCloseButtonOfViewDetailSlidder();
		}	
		//Delete the cart.
		cartListPage.clickMenuIcon(0);
		cartListPage.deleteCart(0);
	});

	it('GCP : E2E: Add Multiple Services to Cart, approve cart order and Delete the services', function () {
		var orderObject = {};
		var orderObj = {};
		var cloudStorageInsObject = JSON.parse(JSON.stringify(cloudStorageTemplate));
		var provdrAccnt = cloudStorageTemplate["Order Parameters"]["Main Parameters"]["Provider Account"]["value"]["QA 4"];
		orderObj.servicename = "auto-storage-" + util.getRandomString(5).toLowerCase();
		orderObj.bucketName = "qabucket-" + util.getRandomString(4).toLowerCase();
		modifiedParamMap = { "Service Instance Name": orderObj.servicename, "Name": orderObj.bucketName, "Cart Service": "Click", "New Shopping Cart": "newCart", "Cart Name": cartName };
		
		catalogPage.clickProviderOrCategoryCheckbox(cloudStorageInsObject.Category);
		catalogPage.clickConfigureButtonBasedOnName(cloudStorageInsObject.bluePrintName);
		//Check if cart checkbox is selected        
		cartListPage.isNewShoppingCartPresent();
		orderFlowUtil.fillOrderDetails(cloudStorageInsObject, modifiedParamMap);
		//Validate pricing on Review order page
		if (browser.params.defaultCurrency == "USD") {
			expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(cloudStorageInsObject.TotalCost);
		}
		placeOrderPage.addToShoppingCart();
		expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
		//Adding Another Service to same cart.
		//cartListPage.continueShopping();
		catalogPage.open();
		orderObject.servicename = "auto-vpc-" + util.getRandomString(5).toLowerCase();
		orderObject.vpcName = "auto-vpc-" + util.getRandomString(5).toLowerCase();
		modifiedParamMap = { "Service Instance Name": orderObject.servicename, "Name": orderObject.vpcName, "UpdateMainParamObject": false };
		
		var vpcInsObj = orderFlowUtil.getMainParameterObject(vpcTemplate, modifiedParamMap);		
		catalogPage.clickProviderOrCategoryCheckbox(vpcInsObj.provider);
		catalogPage.clickProviderOrCategoryCheckbox(vpcInsObj.Category);
		catalogPage.clickConfigureButtonBasedOnName(vpcInsObj.bluePrintName);
		
		placeOrderPage.setServiceName(orderObject.servicename);
		placeOrderPage.clickCheckboxAddToCart();
		placeOrderPage.clickCheckboxAddToCart();
		//placeOrderPage.selectExistingCart(cartName);
		placeOrderPage.selectProviderAccount(provdrAccnt);
		//Verify Next button is enabled
		expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
		placeOrderPage.clickNextButton();
		//fill order details
		delete vpcInsObj["Order Parameters"]["Main Parameters"];
		//modifiedParamMap = { "Service Instance Name": orderObject.servicename, "UpdateMainParamObject": false };
		orderFlowUtil.fillOrderDetails(vpcInsObj, modifiedParamMap);
		//Validate pricing on Review order page
		if (browser.params.defaultCurrency == "USD") {
			expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(vpcInsObj.TotalCost);
		}
		placeOrderPage.addToShoppingCart();
		//Add another service to existing shopping cart
		var pdserviceName = "auto-disk-" + util.getRandomString(3).toLowerCase();
		multiquantityParamMap = { "Service Instance Name": pdserviceName, "Quantity": "3", "UpdateMainParamObject": false };
		var persistentDiskInsObject = orderFlowUtil.getMainParameterObject(persistentDiskTemplate, multiquantityParamMap);
		catalogPage.open();
		catalogPage.clickProviderOrCategoryCheckbox(persistentDiskInsObject.provider);
		catalogPage.clickProviderOrCategoryCheckbox(persistentDiskInsObject.Category);
		catalogPage.clickConfigureButtonBasedOnName(persistentDiskInsObject.bluePrintName);
		
		placeOrderPage.setServiceName(pdserviceName);
		placeOrderPage.clickCheckboxAddToCart();
		placeOrderPage.clickCheckboxAddToCart();
		//placeOrderPage.selectExistingCart(cartName);
		placeOrderPage.selectProviderAccount(provdrAccnt);
		//Verify Next button is enabled
		expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
		placeOrderPage.clickNextButton();
		//fill order details
		delete persistentDiskInsObject["Order Parameters"]["Main Parameters"];
		modifiedParamMap = { "Service Instance Name": pdserviceName, "UpdateMainParamObject": false };
		orderFlowUtil.fillOrderDetails(persistentDiskInsObject, modifiedParamMap);
		//Validate pricing on Review order page
		if (browser.params.defaultCurrency == "USD") {
			expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(persistentDiskInsObject.TotalCost);
		}
		placeOrderPage.addToShoppingCart();		
		expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);		
		//Validate order Total on Shoppping cart page	
		cartListPage.getCartDetails(cartName).then(function(index){
			if (browser.params.defaultCurrency == "USD") {
				cartListPage.expandsTheCartItemsTabBasedOnIndex(index);
				cartListPage.validateEstimatedCostAllServicesCart(index).then(function (status) {
					expect(status).toEqual(true);
				});
			}
			//Delete multiquantity service from cart items list
			cartListPage.deleteItemsInShoppingCart(pdserviceName);
			cartListPage.clickDeleteOkButtonForCartItem();
			//Validate Pricing after deleting cart item
			if (browser.params.defaultCurrency == "USD") {
				cartListPage.validateEstimatedCostAllServicesCart(index).then(function (status) {
					expect(status).toEqual(true);
				});
			}
			//Submit Cart Order
			cartListPage.submitOrder(index);
		});
		
		//Icrease quantity by 1 
		// cartListPage.increaseQuntity("Persistent Disk");
		// //Validate order Total with increased quantity on Shoppping cart page
		// cartListPage.validateEstimatedCostAllServicesCart().then(function (status) {
		// 	expect(status).toEqual(true);
		// });
		
		orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
		//orderObject.totalPrice = cartListPage.getTextTotalPriceOrderSubmittedModal();
		expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
		cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

		var orderTotal = parseFloat((cloudStorageInsObject.TotalCost).replace("USD ", "")) + parseFloat((vpcInsObj.TotalCost).replace("USD ", ""));
		var serviceListWithPricing = {};
		serviceListWithPricing = { "Cloud Storage": cloudStorageInsObject.TotalCost, "VPC Network": vpcInsObj.TotalCost };

		if (isProvisioningRequired == "true") {
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 30);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
				if (status == 'Completed') {
					if (browser.params.defaultCurrency == "USD") {
					//Validate BOM of 1st and 2nd service on Approve Order -->Service Details page	
						orderFlowUtil.closeHorizontalSliderIfPresent();
						ordersPage.validateEstimatedCostAllServicesofCart(serviceListWithPricing).then(function (status) {
							expect(status).toEqual(true);
						});
						//Validate pricing on order history page. Sum of price of 2 services should be equal to order total
						orderHistoryPage.validatePricingonOrderHistory(orderObject.orderNumber, "USD " + orderTotal, serviceListWithPricing).then(function (status) {
							expect(status).toEqual(true);
						});
					}
					//Deleting Service 1
					orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObj);
					orderFlowUtil.approveDeletedOrder(orderObject);
					orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 35);
					orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject).then(function (status) {
						if (status == 'Completed') {
							//Deleting Service 2
							orderObj.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
							orderFlowUtil.approveDeletedOrder(orderObj);
							orderFlowUtil.waitForDeleteOrderStatusChange(orderObj, 'Completed', 35);
							expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObj)).toBe('Completed');
						}
					});
				}
			})
		}
	});

	it('GCP : Edit Service submitted through shopping cart', function () {
		var orderObject = {};
		var persistentDiskInsObject = cartListPage.getCartTestData(persistentDiskTemplate);
		orderObject.servicename = serviceName;
		//multiquantityParamMap = { "Service Instance Name": serviceName, "Quantity": "3" };
		catalogPage.clickProviderOrCategoryCheckbox(persistentDiskTemplate.Category);
		catalogPage.clickConfigureButtonBasedOnName(persistentDiskTemplate.bluePrintName);
		//Check if cart checkbox is selected        
		cartListPage.isNewShoppingCartPresent();
		orderFlowUtil.fillOrderDetails(persistentDiskInsObject, modifiedParamMap);
		placeOrderPage.addToShoppingCart();
		expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
		cartListPage.getCartDetails(cartName).then(function(index){			
			//Submit Cart Order
			cartListPage.submitOrder(index);
		});			
		
		orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
		//orderObject.totalPrice = cartListPage.getTextTotalPriceOrderSubmittedModal();
		expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
		cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();		
		if (isProvisioningRequired == "true") {
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
				if (status == 'Completed') {
					//Function to edit the service
					modifiedParamMap = { "Service Instance Name": "", "Instance Name": "", "EditService": true, "Size (GB)": "70" };
					orderFlowUtil.editService(orderObject);
					orderFlowUtil.fillOrderDetails(persistentDiskInsObject, modifiedParamMap);
					placeOrderPage.submitOrder();
					orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
					placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
					expect(orderFlowUtil.verifyOrderType(orderObject)).toBe('EditSOI');
					orderFlowUtil.approveOrder(orderObject);
					orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
					orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
						//Delete the Edited service
						if (status == 'Completed') {
							orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
							expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
							orderFlowUtil.approveDeletedOrder(orderObject);
							//orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Provisioning in Progress');
							//expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Provisioning in Progress');
							orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 35);
							expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
						}
					});
				}
			});

		}
		//Validate if shopping cart is also deleted
		catalogPage.clickCartIcon();
		cartName = modifiedParamMap["Cart Name"];
		expect(cartListPage.isPresentCartInCartList(cartName)).toBe(false);
		catalogPage.clickCartIcon();
	});
	//Skipping below test for now as AWS credentials are not available
	it('GCP : Add Services of multiple providers to Cart, approve cart order and Delete the services', function () {

		var orderObject = {};
		var orderObj = {};
		var cloudStorageInsObject = cartListPage.getCartTestData(cloudStorageTemplate);		
		var provdrAccnt = cloudStorageTemplate["Order Parameters"]["Main Parameters"]["Provider Account"]["value"]["QA 4"];
		var provdrAccntAws = ec2InstanceTemplate["Order Parameters"]["Main Parameters"]["Provider Account"]["value"]["QA 4"];
		orderObj.servicename = "auto-storage-" + util.getRandomString(5).toLowerCase();
		orderObj.bucketName = "qabucket-" + util.getRandomString(4).toLowerCase();
		modifiedParamMap = { "Service Instance Name": orderObj.servicename, "Name": orderObj.bucketName, "Cart Service": "Click", "New Shopping Cart": "newCart", "Cart Name": cartName };

		catalogPage.clickProviderOrCategoryCheckbox(cloudStorageInsObject.Category);
		catalogPage.clickConfigureButtonBasedOnName(cloudStorageInsObject.bluePrintName);
		//Check if cart checkbox is selected        
		cartListPage.isNewShoppingCartPresent();
		orderFlowUtil.fillOrderDetails(cloudStorageInsObject, modifiedParamMap);
		//Validate pricing on Review order page
		if (browser.params.defaultCurrency == "USD") {
			expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(cloudStorageInsObject.TotalCost);
		}
		placeOrderPage.addToShoppingCart();
		expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
		//Adding Another Service to same cart.
		//cartListPage.continueShopping();
		catalogPage.open();
		orderObject.servicename = "auto-ec2-" + util.getRandomString(5).toLowerCase();
		var groupName = "att-group-" + util.getRandomString(5);
		modifiedParamMap = { "Service Instance Name": orderObject.servicename, "Group Name": groupName, "UpdateMainParamObject": false };
		var ec2InsObject = orderFlowUtil.getMainParameterObject(ec2InstanceTemplate, modifiedParamMap);
						
		catalogPage.clickProviderOrCategoryCheckbox(ec2InsObject.provider);
		catalogPage.clickProviderOrCategoryCheckbox(ec2InsObject.Category);
		catalogPage.clickConfigureButtonBasedOnName(ec2InsObject.bluePrintName);
		placeOrderPage.setServiceName(orderObject.servicename);
		placeOrderPage.clickCheckboxAddToCart();
		placeOrderPage.clickCheckboxAddToCart();
		//placeOrderPage.selectExistingCart(cartName);
		placeOrderPage.selectProviderAccount(provdrAccntAws);
		//Verify Next button is enabled
		expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
		placeOrderPage.clickNextButton();
		//fill order details
		delete ec2InsObject["Order Parameters"]["Main Parameters"];
		modifiedParamMap = { "Service Instance Name": orderObject.servicename, "UpdateMainParamObject": false };
		orderFlowUtil.fillOrderDetails(ec2InsObject, modifiedParamMap);
		//Validate pricing on Review order page for second service
		if (browser.params.defaultCurrency == "USD") {
			expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(ec2InsObject.TotalCost);
		}
		placeOrderPage.addToShoppingCart();
		expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);		
		
		cartListPage.getCartDetails(cartName).then(function(index){
			if (browser.params.defaultCurrency == "USD") {
				cartListPage.expandsTheCartItemsTabBasedOnIndex(index);
				cartListPage.validateEstimatedCostAllServicesCart(index).then(function (status) {
					expect(status).toEqual(true);
				});			
			}	
			//Submit Cart Order
			cartListPage.submitOrder(index);
		});
		
		orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
		//orderObject.totalPrice = cartListPage.getTextTotalPriceOrderSubmittedModal();
		expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
		cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

		var orderTotal = parseFloat((cloudStorageInsObject.TotalCost).replace("USD ", "")) + parseFloat((ec2InsObject.TotalCost).replace("USD ", ""));
		var serviceListWithPricing = {};
		serviceListWithPricing = { "Cloud Storage": cloudStorageInsObject.TotalCost, "Elastic Compute Cloud (EC2)": ec2InsObject.TotalCost };

		if (isProvisioningRequired == "true") {
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 30);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
				if (status == 'Completed') {
					if (browser.params.defaultCurrency == "USD") {
						//Validate BOM of 1st and 2nd service on Approve Order -->Service Details page						
						ordersPage.validateEstimatedCostAllServicesofCart(serviceListWithPricing).then(function (status) {
							expect(status).toEqual(true);
						});
						//Validate pricing on order history page. Sum of price of 2 services should be equal to order total
						orderHistoryPage.validatePricingonOrderHistory(orderObject.orderNumber, "USD " + orderTotal, serviceListWithPricing).then(function (status) {
							expect(status).toEqual(true);
						});
					}
					//Deleting Service 1
					orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObj);
					orderFlowUtil.approveDeletedOrder(orderObject);
					orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 35);
					orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject).then(function (status) {
						if (status == 'Completed') {
							//Deleting Service 2
							orderObj.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
							orderFlowUtil.approveDeletedOrder(orderObj);
							orderFlowUtil.waitForDeleteOrderStatusChange(orderObj, 'Completed', 35);
							expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObj)).toBe('Completed');
						}
					});
				}
			});
		}
	});

	it('GCP : Verify if cart option is selected, user is able to select an existing cart', function () {

		var orderObject = {};
		var orderObj = {};
		var cloudStorageInsObject = cartListPage.getCartTestData(cloudStorageTemplate);
		//var cartName = cloudStorageInsObject["Order Parameters"]["Main Parameters"]["Cart Name"]["value"]["QA 4"];		
		var ec2InsObject = JSON.parse(JSON.stringify(ec2InstanceTemplate));
		var provdrAccnt = ec2InsObject["Order Parameters"]["Main Parameters"]["Provider Account"]["value"]["QA 4"];

		orderObj.servicename = "auto-storage-" + util.getRandomString(5).toLowerCase();
		orderObj.bucketName = "qabucket-" + util.getRandomString(4).toLowerCase();
		modifiedParamMap = { "Service Instance Name": orderObj.servicename, "Name": orderObj.bucketName, "Cart Service": "Click", "New Shopping Cart": "newCart", "Cart Name": cartName };
		//var cartName = modifiedParamMap["Cart Name"];
		catalogPage.clickProviderOrCategoryCheckbox(cloudStorageInsObject.Category);
		catalogPage.clickConfigureButtonBasedOnName(cloudStorageInsObject.bluePrintName);
		//Check if cart checkbox is selected        
		cartListPage.isNewShoppingCartPresent();
		orderFlowUtil.fillOrderDetails(cloudStorageInsObject, modifiedParamMap);//.then(function () {
		//Validate pricing on Review order page
		expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(cloudStorageInsObject.TotalCost);
		placeOrderPage.addToShoppingCart().then(function () {
			expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
			//Adding Another Service to Existing cart.
			//cartListPage.continueShopping();
			catalogPage.open();
			catalogPage.clickProviderOrCategoryCheckbox(ec2InsObject.provider);
			catalogPage.clickProviderOrCategoryCheckbox(ec2InsObject.Category);
			catalogPage.clickConfigureButtonBasedOnName(ec2InsObject.bluePrintName);
			orderObject.servicename = "auto-ec2-" + util.getRandomString(5).toLowerCase();
			placeOrderPage.setServiceName(orderObject.servicename);
			placeOrderPage.clickCheckboxAddToCart();
			placeOrderPage.clickCheckboxAddToCart();
			placeOrderPage.selectExistingCart(cartName);
			placeOrderPage.selectProviderAccount(provdrAccnt);
			//Verify Next button is enabled
			expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
			placeOrderPage.clickNextButton();
			//fill order details
			delete ec2InsObject["Order Parameters"]["Main Parameters"];
			modifiedParamMap = { "Service Instance Name": orderObject.servicename, "UpdateMainParamObject": false };
			orderFlowUtil.fillOrderDetails(ec2InsObject, modifiedParamMap);
			//Validate pricing on Review order page
			expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(ec2InsObject.TotalCost);
			placeOrderPage.addToShoppingCart();
			//Validate BOM
			cartListPage.getCartDetails(cartName).then(function(index){
				cartListPage.expandsTheCartItemsTabBasedOnIndex(index);
				cartListPage.validateEstimatedCostAllServicesCart(index).then(function (status) {
					expect(status).toEqual(true);
				});			
				//Submit Cart Order
				cartListPage.submitOrder(index);
			});
			//placeOrderPage.clickOrderSubmitConfrmnBtn();
			orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
			//orderObject.totalPrice = cartListPage.getTextTotalPriceOrderSubmittedModal();
			expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			//Deny Order
			orderFlowUtil.denyOrder(orderObject);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Rejected');
		});

	});

	it('GCP : Buyers ability to Transfer a shopping cart', async function () {
		var orderObject = {};
		var orderObj = {};
		var pubSubInsObject = cartListPage.getCartTestData(pubSubTemplate);
		catalogPage.clickProviderOrCategoryCheckbox(pubSubTemplate.Category);
		catalogPage.clickConfigureButtonBasedOnName(pubSubTemplate.bluePrintName);
		orderObj.servicename = "auto-gcp-cart-" + util.getRandomString(5).toLowerCase();
		orderObj.bucketName = "qabucket-" + util.getRandomString(4).toLowerCase();
		modifiedParamMap = { "Service Instance Name": orderObj.servicename, "Name": orderObj.bucketName, "Cart Service": "Click", "New Shopping Cart": "newCart", "Cart Name": cartName };
		//Check if cart checkbox is selected        
		cartListPage.isNewShoppingCartPresent();
		orderFlowUtil.fillOrderDetails(pubSubInsObject, modifiedParamMap);
		placeOrderPage.addToShoppingCart();
		expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
		//catalogPage.open();
		cartName = modifiedParamMap["Cart Name"];
		cartListPage.getCartDetails(cartName).then(async function(index){
			cartListPage.clickMenuIcon(index);
			//Transfer the cart.
			cartListPage.tranferCart(index);
			cartListPage.searchForUserID(userCredntialsObject.transferCartUser);
			cartListPage.confirmTransfer();
			expect(cartListPage.getTextSuccessMessageTransferCart()).toContain(messageStrings.cartSuccessfullyTransferredToMessage);
			// expect cart present in list and ownership is changed.
			catalogPage.open();
			cartListPage.clickCartIcon();
			cartListPage.clickOnViewAllCarts();			
			cartListPage.switchToFrame();
			expect(cartListPage.getCartDetails(cartName)).not.toEqual(-1);
			//Validate cart owner is now changed to tranfer cart
			expect(cartListPage.getCartOwner(index)).toEqual(userCredntialsObject.transferCartOwner);
			await cartListPage.loginFromOtherUser(userCredntialsObject.transferCartUser, userCredntialsObject.transferCartPwd);
			catalogPage.open();
			cartListPage.clickCartIcon();
			cartListPage.clickOnViewAllCarts();			
			cartListPage.switchToFrame();
			cartListPage.getCartDetails(cartName).then(async function(indexNew){
				cartListPage.clickMenuIcon(indexNew);
				cartListPage.deleteCart(indexNew);
			});			
			expect(cartListPage.getDeletedCartSuccessMessage()).toBe(messageStrings.cartSuccessfullyDeletedMessage);			
			await cartListPage.loginFromOtherUser(browser.params.username, browser.params.password);
		});
	});
	
	it('GCP : Edit/Empty/Delete shopping cart', function () {		
		var pubSUbInsObject = cartListPage.getCartTestData(pubSubTemplate);	
		catalogPage.clickProviderOrCategoryCheckbox(pubSubTemplate.Category);
		catalogPage.clickConfigureButtonBasedOnName(pubSubTemplate.bluePrintName);
		//Check if cart checkbox is selected        
		cartListPage.isNewShoppingCartPresent();
		orderFlowUtil.fillOrderDetails(pubSUbInsObject, modifiedParamMap);
		placeOrderPage.addToShoppingCart();
		expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
		//catalogPage.open();
		cartName = modifiedParamMap["Cart Name"];		
		//Edit Cart Flow
		cartListPage.getCartDetails(cartName).then(async function(index){
		cartListPage.clickMenuIcon(index);
        	cartListPage.clickOnEditCartContext(index);
				
			var newCartName = "new-cart-" + util.getRandomString(4).toLowerCase();
			//Adding below code for CON-21626, will uncomment it once issue is resolved.
			var modifiedParamMapEdit = { "Cart Name": newCartName };//, "Team":"EditCart", "Environment":"EditEnv", "Application":"EditApp"};
			//Edit the cart contexts
			cartListPage.editCartDetails(pubSubTemplate, modifiedParamMapEdit).then(function (requiredReturnMap) {
				//Click on update button cart button
				cartListPage.clickOnUpdateCartButton().then(function () {
					//Get the cart context details 			
					//browser.sleep(5000);
					orderFlowUtil.closeHorizontalSliderIfPresent();
					util.waitForAngular();
					//Get the cart context details
					//verify cart name is updated
					cartListPage.getCartDetails(newCartName).then(async function(indexEdit){		
						expect(indexEdit).not.toBe(-1);
						cartListPage.getCartContextDataBasedOnCartName(newCartName).then(function (actualMap) {
							//verify the updated cart details
							//expect(actualMap["Actual"]["Team"]).toBe(requiredReturnMap["Expected"]["Team"]);
							expect(actualMap["Actual"]["Environment"]).toBe(requiredReturnMap["Expected"]["Environment"]);
							expect(actualMap["Actual"]["Application"]).toBe(requiredReturnMap["Expected"]["Application"]);
							//expect(actualMap["Actual"]["Organization"]).toBe(requiredReturnMap["Expected"]["Organization"]);
						});
						//Empty Cart 		
						cartListPage.clickMenuIcon(0);
						expect(cartListPage.emptyCart(0)).toBe(true);
						//expect(cartListPage.getTextSuccessfullyEmptiedCart()).toBe(messageStrings.cartSuccessfullyEmptiedMessage);
						//Delete the cart.
						cartListPage.clickMenuIcon(0);
						cartListPage.deleteCart(0);
						//Verify Cart is Deleted
						catalogPage.open();
						cartListPage.clickCartIcon();
						cartListPage.clickOnViewAllCarts();			
						cartListPage.switchToFrame();
						expect(cartListPage.getCartDetails(cartName)).toEqual(-1);
					}); 				
					
				});
				
			});
		});
	});
});
