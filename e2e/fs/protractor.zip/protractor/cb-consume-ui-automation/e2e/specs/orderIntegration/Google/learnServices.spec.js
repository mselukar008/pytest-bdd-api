"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    kubernetesTemplate = require('../../../../testData/OrderIntegration/Google/kubernetesEngine.json'),
    cloudNatTemplate = require('../../../../testData/OrderIntegration/Google/cloudNat.json'),
    cloudVpnTemplate = require('../../../../testData/OrderIntegration/Google/cloudVpn.json'),
    httplbTemplate = require('../../../../testData/OrderIntegration/Google/httplb.json');

describe('GCP - LearnServices', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, kubernetesObj, inventoryPage, engineName;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = kubernetesTemplate.componentType;
    var messageStrings = {
        providerName: kubernetesTemplate.provider,              
        orderSubmittedConfirmationMessage: kubernetesTemplate.orderSubmittedConfirmationMessage,
        provInProgressState: kubernetesTemplate.provInProgressState,
        completedState: kubernetesTemplate.completedState
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "gcp-auto-kubernetes-" + util.getRandomString(5);
    });

    beforeEach(function () {
        engineName = "attgroup" + util.getRandomString(5);
        engineName = engineName.toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": engineName };
    });
    if (isDummyAdapterDisabled == "false") {
        it('Kubernetes - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
            var serviceDetailsMap = {};
            catalogPage.open();
            kubernetesObj = JSON.parse(JSON.stringify(kubernetesTemplate));
            orderObject.servicename = serviceName;
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
            catalogPage.clickProviderOrCategoryCheckbox(kubernetesTemplate.Category);
            catalogPage.clickConfigureButtonBasedOnName(kubernetesTemplate.bluePrintName);

            //Fill Order Details
            orderFlowUtil.fillOrderDetails(kubernetesTemplate, modifiedParamMap).then(function (requiredReturnMap) {
                serviceDetailsMap = requiredReturnMap;
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(kubernetesTemplate.TotalCost);
                expect(requiredReturnMap["Actual"]["Region"]).toEqual(requiredReturnMap["Expected"]["Region"]);
                expect(requiredReturnMap["Actual"]["Name"]).toEqual(engineName);
                expect(requiredReturnMap["Actual"]["Network"]).toEqual(requiredReturnMap["Expected"]["Network"]);
                expect(requiredReturnMap["Actual"]["Subnetwork"]).toEqual(requiredReturnMap["Expected"]["Subnetwork"]);
                expect(requiredReturnMap["Actual"]["Current Master Version"]).toEqual(requiredReturnMap["Expected"]["Current Master Version"]);
                expect(requiredReturnMap["Actual"]["Max Pods Per Node"]).toEqual(requiredReturnMap["Expected"]["Max Pods Per Node"]);
                expect(requiredReturnMap["Actual"]["NodePool NodeVersion"]).toEqual(requiredReturnMap["Expected"]["NodePool NodeVersion"]);
                expect(requiredReturnMap["Actual"]["Node Disk Type"]).toEqual(requiredReturnMap["Expected"]["Node Disk Type"]);
                expect(requiredReturnMap["Actual"]["Node Image Type"]).toEqual(requiredReturnMap["Expected"]["Node Image Type"]);

                //Submit Order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(kubernetesTemplate.bluePrintName, "New");
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                //Aprrove Order
                if (isProvisioningRequired == "true") {
                    orderFlowUtil.approveOrder(orderObject);
                    orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
                    expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
                    //Validate Estimated price on approve order page
                    expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(kubernetesTemplate.EstimatedPrice);
                    //Validate pricing on order history page
                    ordersHistoryPage.open();
                    ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                    expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(kubernetesTemplate.EstimatedPrice);
                    ////Verify Output parameter
                    expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
                }
                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                ordersHistoryPage.clickServiceDetailsLink();

                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Region")).toContain(jsonUtil.getValue(kubernetesObj, "Region"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Name")).toEqual(engineName);
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Network")).toEqual(jsonUtil.getValue(kubernetesObj, "Network"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Subnetwork")).toEqual(jsonUtil.getValue(kubernetesObj, "Subnetwork"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Current Master Version")).toEqual(jsonUtil.getValue(kubernetesObj, "Current Master Version"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Max Pods Per Node")).toEqual(jsonUtil.getValue(kubernetesObj, "Max Pods Per Node"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("NodePool NodeVersion")).toEqual(jsonUtil.getValue(kubernetesObj, "NodePool NodeVersion"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Machine Type: Custom Core")).toEqual(jsonUtil.getValue(kubernetesObj, "Machine Type: Custom Core"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Machine Type: Custom RAM")).toEqual(jsonUtil.getValue(kubernetesObj, "Machine Type: Custom RAM"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Node Disk Type")).toEqual(jsonUtil.getValue(kubernetesObj, "Node Disk Type"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Node Image Type")).toEqual(jsonUtil.getValue(kubernetesObj, "Node Image Type"));
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(kubernetesTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(kubernetesTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();

                ordersPage.open();
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service parameters on Approve order page
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
                expect(ordersPage.getTextBasedOnLabelName("Region")).toContain(jsonUtil.getValue(kubernetesObj, "Region"));
                expect(ordersPage.getTextBasedOnExactLabelName("Name")).toEqual(engineName);
                expect(ordersPage.getTextBasedOnLabelName("Network")).toEqual(jsonUtil.getValue(kubernetesObj, "Network"));
                expect(ordersPage.getTextBasedOnLabelName("Subnetwork")).toEqual(jsonUtil.getValue(kubernetesObj, "Subnetwork"));
                expect(ordersPage.getTextBasedOnLabelName("Current Master Version")).toEqual(jsonUtil.getValue(kubernetesObj, "Current Master Version"));
                expect(ordersPage.getTextBasedOnLabelName("Max Pods Per Node")).toEqual(jsonUtil.getValue(kubernetesObj, "Max Pods Per Node"));
                expect(ordersPage.getTextBasedOnLabelName("NodePool NodeVersion")).toEqual(jsonUtil.getValue(kubernetesObj, "NodePool NodeVersion"));
                expect(ordersPage.getTextBasedOnLabelName("Machine Type: Custom Core")).toEqual(jsonUtil.getValue(kubernetesObj, "Machine Type: Custom Core"));
                expect(ordersPage.getTextBasedOnLabelName("Machine Type: Custom RAM")).toEqual(jsonUtil.getValue(kubernetesObj, "Machine Type: Custom RAM"));
                expect(ordersPage.getTextBasedOnLabelName("Node Disk Type")).toEqual(jsonUtil.getValue(kubernetesObj, "Node Disk Type"));
                expect(ordersPage.getTextBasedOnLabelName("Node Image Type")).toEqual(jsonUtil.getValue(kubernetesObj, "Node Image Type"));
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(kubernetesTemplate.TotalCost);
                ordersPage.clickServiceDetailSliderCloseButton();

                //Delete Service flow                    
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, kubernetesTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState);
            });
        });
    }

    it('Cloud NAT - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        var natName = "attnat" + util.getRandomString(5);
        natName = natName.toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "NAT Name": natName };
        catalogPage.open();
        var cloudNatObj = JSON.parse(JSON.stringify(cloudNatTemplate));
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(cloudNatTemplate.provider);
        catalogPage.clickProviderOrCategoryCheckbox(cloudNatTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(cloudNatTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(cloudNatTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(cloudNatTemplate.TotalCost);
            expect(requiredReturnMap["Actual"]["Region"]).toEqual(requiredReturnMap["Expected"]["Region"]);
            expect(requiredReturnMap["Actual"]["NAT Name"]).toEqual(natName);
            expect(requiredReturnMap["Actual"]["Router Name"]).toEqual(requiredReturnMap["Expected"]["Router Name"]);
            expect(requiredReturnMap["Actual"]["NAT Source Subnetwork IP Ranges To Nat"]).toEqual(requiredReturnMap["Expected"]["NAT Source Subnetwork IP Ranges To Nat"]);
            expect(requiredReturnMap["Actual"]["Minimum ports per VM instance"]).toEqual(requiredReturnMap["Expected"]["Minimum ports per VM instance"]);
            expect(requiredReturnMap["Actual"]["UDP Idle Timeout (Sec)"]).toEqual(requiredReturnMap["Expected"]["UDP Idle Timeout (Sec)"]);
            expect(requiredReturnMap["Actual"]["TCP Established Idle Timeout (Sec)"]).toEqual(requiredReturnMap["Expected"]["TCP Established Idle Timeout (Sec)"]);
            expect(requiredReturnMap["Actual"]["TCP Transitory Idle Timeout (Sec)"]).toEqual(requiredReturnMap["Expected"]["TCP Transitory Idle Timeout (Sec)"]);
            expect(requiredReturnMap["Actual"]["ICMP Timeout (Sec)"]).toEqual(requiredReturnMap["Expected"]["ICMP Timeout (Sec)"]);

            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(cloudNatTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(cloudNatTemplate.EstimatedPrice);
                //Validate pricing on order history page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(cloudNatTemplate.EstimatedPrice);
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();

            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Region")).toContain(jsonUtil.getValue(cloudNatObj, "Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("NAT Name")).toEqual(natName);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Router Name")).toEqual(jsonUtil.getValue(cloudNatObj, "Router Name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("NAT Source Subnetwork IP Ranges To Nat")).toEqual(jsonUtil.getValue(cloudNatObj, "NAT Source Subnetwork IP Ranges To Nat"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Minimum ports per VM instance")).toEqual(jsonUtil.getValue(cloudNatObj, "Minimum ports per VM instance"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("UDP Idle Timeout (Sec)")).toEqual(jsonUtil.getValue(cloudNatObj, "UDP Idle Timeout (Sec)"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("TCP Established Idle Timeout (Sec)")).toEqual(jsonUtil.getValue(cloudNatObj, "TCP Established Idle Timeout (Sec)"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("TCP Transitory Idle Timeout (Sec)")).toEqual(jsonUtil.getValue(cloudNatObj, "TCP Transitory Idle Timeout (Sec)"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("ICMP Timeout (Sec)")).toEqual(jsonUtil.getValue(cloudNatObj, "ICMP Timeout (Sec)"));
            
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(cloudNatTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(cloudNatTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();

            ordersPage.open();
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("Region")).toContain(jsonUtil.getValue(cloudNatObj, "Region"));
            expect(ordersPage.getTextBasedOnExactLabelName("NAT Name")).toEqual(natName);
            expect(ordersPage.getTextBasedOnLabelName("Router Name")).toEqual(jsonUtil.getValue(cloudNatObj, "Router Name"));
            expect(ordersPage.getTextBasedOnLabelName("NAT Source Subnetwork IP Ranges To Nat")).toEqual(jsonUtil.getValue(cloudNatObj, "NAT Source Subnetwork IP Ranges To Nat"));
            expect(ordersPage.getTextBasedOnLabelName("Minimum ports per VM instance")).toEqual(jsonUtil.getValue(cloudNatObj, "Minimum ports per VM instance"));
            expect(ordersPage.getTextBasedOnLabelName("UDP Idle Timeout (Sec)")).toEqual(jsonUtil.getValue(cloudNatObj, "UDP Idle Timeout (Sec)"));
            expect(ordersPage.getTextBasedOnLabelName("TCP Established Idle Timeout (Sec)")).toEqual(jsonUtil.getValue(cloudNatObj, "TCP Established Idle Timeout (Sec)"));
            expect(ordersPage.getTextBasedOnLabelName("TCP Transitory Idle Timeout (Sec)")).toEqual(jsonUtil.getValue(cloudNatObj, "TCP Transitory Idle Timeout (Sec)"));
            expect(ordersPage.getTextBasedOnLabelName("ICMP Timeout (Sec)")).toEqual(jsonUtil.getValue(cloudNatObj, "ICMP Timeout (Sec)"));
            
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(cloudNatTemplate.TotalCost);
            ordersPage.clickServiceDetailSliderCloseButton();

            //Delete Service flow                    
            orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, cloudNatTemplate.bluePrintName);
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState);
        });
    });

    it('Cloud VPN - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        var vpnName = "attvpn" + util.getRandomString(5);
        vpnName = vpnName.toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": vpnName };
        catalogPage.open();
        var cloudVpnObj = JSON.parse(JSON.stringify(cloudVpnTemplate));
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(cloudVpnTemplate.provider);
        catalogPage.clickProviderOrCategoryCheckbox(cloudVpnTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(cloudVpnTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(cloudVpnTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(cloudVpnTemplate.TotalCost);
            expect(requiredReturnMap["Actual"]["Region"]).toEqual(requiredReturnMap["Expected"]["Region"]);
            expect(requiredReturnMap["Actual"]["Name"]).toEqual(vpnName);
            expect(requiredReturnMap["Actual"]["Network"]).toEqual(requiredReturnMap["Expected"]["Network"]);
            expect(requiredReturnMap["Actual"]["External IP"]).toEqual(requiredReturnMap["Expected"]["External IP"]);
            expect(requiredReturnMap["Actual"]["Peer IP"]).toEqual(requiredReturnMap["Expected"]["Peer IP"]);
            expect(requiredReturnMap["Actual"]["Shared Secret"]).toEqual(requiredReturnMap["Expected"]["Shared Secret"]);
            
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(cloudVpnTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(cloudVpnTemplate.EstimatedPrice);
                //Validate pricing on order history page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(cloudVpnTemplate.EstimatedPrice);
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();

            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Region")).toContain(jsonUtil.getValue(cloudVpnObj, "Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Name")).toEqual(vpnName);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Network")).toEqual(jsonUtil.getValue(cloudVpnObj, "Network"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("External IP")).toEqual(jsonUtil.getValue(cloudVpnObj, "External IP"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Peer IP")).toEqual(jsonUtil.getValue(cloudVpnObj, "Peer IP"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Shared Secret")).toEqual(jsonUtil.getValue(cloudVpnObj, "Shared Secret"));
                        
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(cloudVpnTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(cloudVpnTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();

            ordersPage.open();
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("Region")).toContain(jsonUtil.getValue(cloudVpnObj, "Region"));
            expect(ordersPage.getTextBasedOnExactLabelName("Name")).toEqual(vpnName);
            expect(ordersPage.getTextBasedOnLabelName("Network")).toEqual(jsonUtil.getValue(cloudVpnObj, "Network"));
            expect(ordersPage.getTextBasedOnLabelName("External IP")).toEqual(jsonUtil.getValue(cloudVpnObj, "External IP"));
            expect(ordersPage.getTextBasedOnLabelName("Peer IP")).toEqual(jsonUtil.getValue(cloudVpnObj, "Peer IP"));
            expect(ordersPage.getTextBasedOnLabelName("Shared Secret")).toEqual(jsonUtil.getValue(cloudVpnObj, "Shared Secret"));
                        
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(cloudVpnTemplate.TotalCost);
            ordersPage.clickServiceDetailSliderCloseButton();

            //Delete Service flow                    
            orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, cloudVpnTemplate.bluePrintName);
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState);
        });
    });

    it('HTTP Load Balancing - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        var lbName = "attlb" + util.getRandomString(5);
        lbName = lbName.toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": lbName };
        catalogPage.open();
        var httpLbObj = JSON.parse(JSON.stringify(httplbTemplate));
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(httplbTemplate.provider);
        catalogPage.clickProviderOrCategoryCheckbox(httplbTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(httplbTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(httplbTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(httplbTemplate.TotalCost);
            expect(requiredReturnMap["Actual"]["Region"]).toEqual(requiredReturnMap["Expected"]["Region"]);
            expect(requiredReturnMap["Actual"]["Name"]).toEqual(lbName);
            expect(requiredReturnMap["Actual"]["Backend Service Name"]).toEqual(requiredReturnMap["Expected"]["Backend Service Name"]);
            expect(requiredReturnMap["Actual"]["Instance Group"]).toEqual(requiredReturnMap["Expected"]["Instance Group"]);
            expect(requiredReturnMap["Actual"]["Balancing Mode"]).toEqual(requiredReturnMap["Expected"]["Balancing Mode"]);
                        
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(httplbTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(httplbTemplate.EstimatedPrice);
                //Validate pricing on order history page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(httplbTemplate.EstimatedPrice);
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();

            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Region")).toContain(jsonUtil.getValue(httpLbObj, "Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Name")).toEqual(lbName);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Backend Service Name")).toEqual(jsonUtil.getValue(httpLbObj, "Backend Service Name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Group")).toEqual(jsonUtil.getValue(httpLbObj, "Instance Group"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Balancing Mode")).toEqual(jsonUtil.getValue(httpLbObj, "Balancing Mode"));
                                    
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(httplbTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(httplbTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();

            ordersPage.open();
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("Region")).toContain(jsonUtil.getValue(httpLbObj, "Region"));
            expect(ordersPage.getTextBasedOnExactLabelName("Name")).toEqual(lbName);
            expect(ordersPage.getTextBasedOnLabelName("Backend Service Name")).toEqual(jsonUtil.getValue(httpLbObj, "Backend Service Name"));
            expect(ordersPage.getTextBasedOnLabelName("Instance Group")).toEqual(jsonUtil.getValue(httpLbObj, "Instance Group"));
            expect(ordersPage.getTextBasedOnLabelName("Balancing Mode")).toEqual(jsonUtil.getValue(httpLbObj, "Balancing Mode"));
                                   
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(httplbTemplate.TotalCost);
            ordersPage.clickServiceDetailSliderCloseButton();

            //Delete Service flow                    
            orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, httplbTemplate.bluePrintName);
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState);
        });
    });
   
});
