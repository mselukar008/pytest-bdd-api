/*************************************************
DESCRIPTION: The test script verifies the File Storage NAS Service functionality    
**************************************************/

"use strict";
var async = require('async'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    nasTemplate = require('../../../../testData/OrderIntegration/Alibaba/FileStorageNAS.json')

describe('Alibaba: Test cases for File Storage NAS Service', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, homePage;
    var modifiedParamMap = {};
    var modifiedParamMapVPC = {};
    var messageStrings = {
        providerName: 'Alibaba Cloud',
        category: 'Network'
    };
    var servicename = "Gsl-Auto-NAS" + util.getRandomString(5);
    var servicenameVPC = "Gsl-Auto-VPC" + util.getRandomString(5);
    modifiedParamMapVPC = {
        "Service Instance Name": servicenameVPC,
    };

    beforeAll(function () {
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        modifiedParamMap = {
            "Service Instance Name": servicename,
        };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    afterAll(function () {
        // Delete File Storage NAS
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');

        // Delete Virtual Private Cloud
        var returnObjVPC = {};
        returnObjVPC.servicename = servicenameVPC;
        returnObjVPC.deleteOrderNumber = orderFlowUtil.deleteService(returnObjVPC);
        orderFlowUtil.approveDeletedOrder(returnObjVPC);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObjVPC, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObjVPC)).toBe('Completed');
    });

    //Prerequisite: We need to create Virtual Private Cloud, which will be used by File Storage NAS Service.
    it('Aalibaba: TC-1 Prerequisite for File Storage NAS: Create new Virtual Private Cloud', function () {
        var orderObjectVPC = JSON.parse(JSON.stringify(nasTemplate.createVirtualPrivateCloud));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObjectVPC.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObjectVPC.bluePrintName);
        var returnObjVPC = {};
        orderFlowUtil.fillOrderDetails(nasTemplate.createVirtualPrivateCloud, modifiedParamMapVPC);
        placeOrderPage.submitOrder();
        returnObjVPC.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        returnObjVPC.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        returnObjVPC.servicename = servicenameVPC;
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObjectVPC.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(returnObjVPC);
        orderFlowUtil.waitForOrderStatusChange(returnObjVPC, orderObjectVPC.OrderStatus);
    });

    it('Aalibaba: TC-2 verify that for File Storage NAS Address Service all parameters on Main Parameters Page are present.', function () {
        var orderObject = JSON.parse(JSON.stringify(nasTemplate.createFileStorageNAS));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);

        expect(catalogDetailsPage.getServiceName()).toBe(orderObject.bluePrintName)
        expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true);
        expect(catalogDetailsPage.isPresentLinkToProviderSite()).toBe(true);
        expect(catalogDetailsPage.isPresentFeaturesLabel()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsLabel()).toBe(true);
        expect(catalogDetailsPage.getTextFeaturesLabel()).toBe(orderObject.FeaturesLabel);
        expect(catalogDetailsPage.getTextDetailsLabel()).toBe(orderObject.DetailsLabel);
        expect(catalogDetailsPage.isPresentFeaturesInfo()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsInfo()).toBe(true);

        catalogDetailsPage.clickCatalogFromBreadCrumbNav();
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
        homePage.open();
    });

    it('Aalibaba: TC-3 verify that for File Storage NAS Address Service all parameters on Review Order page matches with input.', function () {
        var orderObject = JSON.parse(JSON.stringify(nasTemplate.createFileStorageNAS));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderObject.servicename = servicename;
        orderFlowUtil.fillOrderDetails(nasTemplate.createFileStorageNAS, modifiedParamMap);

        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(orderObject.servicename);

        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Billing Method:")).toEqual(jsonUtil.getValue(orderObject, "Billing Method"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Zones:")).toEqual(jsonUtil.getValue(orderObject, "Zones"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Storage Type:")).toEqual(jsonUtil.getValue(orderObject, "Storage Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Protocol Type:")).toEqual(jsonUtil.getValue(orderObject, "Protocol Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Encryption Type:")).toEqual(jsonUtil.getValue(orderObject, "Encryption Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Network Type:")).toEqual(jsonUtil.getValue(orderObject, "Network Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" VPC:")).toEqual(jsonUtil.getValue(orderObject, "VPC"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Vswitch:")).toEqual(jsonUtil.getValue(orderObject, "Vswitch"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Add Mount Target:")).toEqual(jsonUtil.getValue(orderObject, "Add Mount Target"));
        homePage.open();
    });

    it('Aalibaba: TC-4 verify that for File Storage NAS Address Service all values on View Order Details page matches with input.', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(nasTemplate.createFileStorageNAS));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(nasTemplate.createFileStorageNAS, modifiedParamMap);
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();

        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename); //Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider); //Checking Provider

        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("Region")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(ordersPage.getTextBasedOnExactLabelName("Billing Method")).toEqual(jsonUtil.getValue(orderObject, "Billing Method"));
        expect(ordersPage.getTextBasedOnExactLabelName("Zones")).toEqual(jsonUtil.getValue(orderObject, "Zones"));
        expect(ordersPage.getTextBasedOnExactLabelName("Storage Type")).toEqual(jsonUtil.getValue(orderObject, "Storage Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Protocol Type")).toEqual(jsonUtil.getValue(orderObject, "Protocol Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Encryption Type")).toEqual(jsonUtil.getValue(orderObject, "Encryption Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Network Type")).toEqual(jsonUtil.getValue(orderObject, "Network Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("VPC")).toEqual(jsonUtil.getValue(orderObject, "VPC"));
        expect(ordersPage.getTextBasedOnExactLabelName("Vswitch")).toEqual(jsonUtil.getValue(orderObject, "Vswitch"));
        expect(ordersPage.getTextBasedOnExactLabelName("Add Mount Target")).toEqual(jsonUtil.getValue(orderObject, "Add Mount Target"));

        //Checking Bill Of Material
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(placeOrderPage.getTotalCost()).toBe(orderObject.Totalcost);

        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
        orderFlowUtil.denyOrder(returnObj);
    });

    if (isProvisioningRequired == "true") {
        it('Aalibaba: TC -5 Verify that for File Storage NAS Address Service provision with correct paramaters', function () {
            var orderObject = JSON.parse(JSON.stringify(nasTemplate.createFileStorageNAS));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            var returnObj = {};
            orderFlowUtil.fillOrderDetails(nasTemplate.createFileStorageNAS, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, orderObject.OrderStatus);

            //checking order on Inventory Page 
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();

            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
            expect(inventoryPage.getTextBasedOnLabelName(" Billing Method:")).toEqual(jsonUtil.getValue(orderObject, "Billing Method"));
            expect(inventoryPage.getTextBasedOnLabelName(" Zones:")).toEqual(jsonUtil.getValue(orderObject, "Zones"));
            expect(inventoryPage.getTextBasedOnLabelName(" Storage Type:")).toEqual(jsonUtil.getValue(orderObject, "Storage Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" Protocol Type:")).toEqual(jsonUtil.getValue(orderObject, "Protocol Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" Encryption Type:")).toEqual(jsonUtil.getValue(orderObject, "Encryption Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" Network Type:")).toEqual(jsonUtil.getValue(orderObject, "Network Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" VPC:")).toEqual(jsonUtil.getValue(orderObject, "VPC"));
            expect(inventoryPage.getTextBasedOnLabelName(" Vswitch:")).toEqual(jsonUtil.getValue(orderObject, "Vswitch"));
            expect(inventoryPage.getTextBasedOnLabelName(" Add Mount Target:")).toEqual(jsonUtil.getValue(orderObject, "Add Mount Target"));
            inventoryPage.closeViewDetailsTab();
        });
    }
});