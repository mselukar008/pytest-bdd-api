//Author: Atiksha Batra
"use strict";
var logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    async = require('async'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    RedhatTemplate = require('../../../../testData/OrderIntegration/Azure/redhatLinux3Tier.json');

describe('Azure - Azure Redhat Linux 3-tier Stack Service ', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, servicename, SOIComponents;
    var test, temp;
    var modifiedParamMap = {};
    var servicename = "AutoRedhatLinuxsrv" + util.getRandomString(5);
    var newResourceGroupName = "gslautotc_azureRedhatLinux-RG101" + util.getRandomString(4);
    var messageStrings = { providerName: 'Azure', category: 'Databases', templateName: 'Redhat Linux 3-tier Stack' };
    //SOIComponents = []
    modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName };

    beforeAll(function () {
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    afterAll(function () {
        // Delete Azure Redhat Linux 3-tier Stack 
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    it('Azure: Verify that for Azure Redhat Linux 3-tier Stack required parameters on Service Details Page are present.', function () {
        var redhatLinuxObject = JSON.parse(JSON.stringify(RedhatTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(redhatLinuxObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(redhatLinuxObject.bluePrintName);
        if (browser.params.defaultCurrency == "USD") {
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(redhatLinuxObject.BasePrice);
        }
    });

    it('Azure: Verify Review order and View Order Details for Azure Redhat Linux 3-tier Stack', function () {
        var orderObject = {};
        orderObject.servicename = servicename;
        var redhatLinuxObject = JSON.parse(JSON.stringify(RedhatTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(redhatLinuxObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(redhatLinuxObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(RedhatTemplate, modifiedParamMap);
        //Verify input values on Review Order page    
        expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "New Resource Group Required"));
        expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
        expect(placeOrderPage.getTextBasedOnLabelName("Location:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Resource Location:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Resource Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Admin Username:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Admin Username"));
        expect(placeOrderPage.getTextBasedOnLabelName("Web Tier VM Count:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Web Tier VM Count"));
        expect(placeOrderPage.getTextBasedOnLabelName("App Tier VM Count:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "App Tier VM Count"));
        expect(placeOrderPage.getTextBasedOnLabelName("Database Tier VM Count:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Database Tier VM Count"));
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(orderObject.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(orderObject.servicename);//Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe('Azure');//Checking Provider
        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(redhatLinuxObject, "New Resource Group Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(newResourceGroupName);
        expect(ordersPage.getTextBasedOnExactLabelName("Resource Location")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Resource Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("Admin Username")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Admin Username"));
        expect(ordersPage.getTextBasedOnExactLabelName("Web Tier VM Count")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Web Tier VM Count"));
        expect(ordersPage.getTextBasedOnExactLabelName("App Tier VM Count")).toEqual(jsonUtil.getValue(redhatLinuxObject, "App Tier VM Count"));
        expect(ordersPage.getTextBasedOnExactLabelName("Database Tier VM Count")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Database Tier VM Count"));
        //Checking Bill Of Material
        if (browser.params.defaultCurrency == "USD") {
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(ordersPage.getEstimatedCost()).toBe(redhatLinuxObject.TotalCost);
        }
        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
    });

    if (isProvisioningRequired == "true") {
        if (isDummyAdapterDisabled == "false") {
            it('Azure: Verify provisioning of Azure Redhat Linux 3-tier Stack using Consume UI', function () {
                var orderObject = {};
                orderObject.servicename = servicename;
                var redhatLinuxObject = JSON.parse(JSON.stringify(RedhatTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(redhatLinuxObject.Category);
                catalogPage.clickConfigureButtonBasedOnName(redhatLinuxObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(RedhatTemplate, modifiedParamMap);
                placeOrderPage.submitOrder();
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                inventoryPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                inventoryPage.clickViewService();
                //Checking Inventory Page Service Configuration
                expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                expect(inventoryPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "New Resource Group Required"));
                expect(inventoryPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
                expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Location"));
                expect(inventoryPage.getTextBasedOnLabelName("Resource Location:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Resource Location"));
                expect(inventoryPage.getTextBasedOnLabelName("Admin Username:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Admin Username"));
                expect(inventoryPage.getTextBasedOnLabelName("Web Tier VM Count:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Web Tier VM Count"));
                expect(inventoryPage.getTextBasedOnLabelName("App Tier VM Count:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "App Tier VM Count"));
                expect(inventoryPage.getTextBasedOnLabelName("Database Tier VM Count:")).toEqual(jsonUtil.getValue(redhatLinuxObject, "Database Tier VM Count"));
                inventoryPage.closeViewDetailsTab();
                
                // check Non-Editable service Message
                inventoryPage.clickNonEditableInstance();
                expect(inventoryPage.getTextForInvalidEditModal()).toEqual(RedhatTemplate.nonEditableText);
                inventoryPage.clickOnInvalidEditOkModal();
            });
        }  
    }
});
