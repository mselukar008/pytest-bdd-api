"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    async = require('async'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    gcpComputeInsTemplate = require('../../../../testData/OrderIntegration/Google/gcpComputeIns.json');

describe('GCP - Compute Engine', function () {
    var ordersPage, homePage, catalogPage, placeOrderPage, inventoryPage, ordersHistoryPage, serviceName, totalCostBOM, instanceName;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: gcpComputeInsTemplate.provider,
        category: gcpComputeInsTemplate.Category,
        catalogPageTitle: gcpComputeInsTemplate.catalogPageTitle,
        inputServiceNameWarning: gcpComputeInsTemplate.inputServiceNameWarning,
        orderSubmittedConfirmationMessage: gcpComputeInsTemplate.orderSubmittedConfirmationMessage,
        provInProgressState: gcpComputeInsTemplate.provInProgressState,
        completedState: gcpComputeInsTemplate.completedState,
        powerStateOff: gcpComputeInsTemplate.powerStateOff,
        powerStateOn: gcpComputeInsTemplate.powerStateOn,
        orderTypeAction: gcpComputeInsTemplate.orderTypeAction,
        turnOnNegativeWarning: gcpComputeInsTemplate.turnOnNegativeWarning,
        turnOffNegativeWarning: gcpComputeInsTemplate.turnOffNegativeWarning,
        rebootNegativeWarning: gcpComputeInsTemplate.rebootNegativeWarning,
        bluePrintNameTurnOn: gcpComputeInsTemplate.bluePrintNameTurnOn,
        bluePrintNameTurnOff: gcpComputeInsTemplate.bluePrintNameTurnOff,
        bluePrintNameReboot: gcpComputeInsTemplate.bluePrintNameReboot,
        systemTagText: gcpComputeInsTemplate.systemTagText,
        componentType: gcpComputeInsTemplate.componentType,
        machineType: gcpComputeInsTemplate.machineType,
        zone: gcpComputeInsTemplate.zone,
        Canipforward: gcpComputeInsTemplate.Canipforward,
        Cpuplatform: gcpComputeInsTemplate.Cpuplatform,
        Deletionprotection: gcpComputeInsTemplate.Deletionprotection,
        kind: gcpComputeInsTemplate.kind,
        Startrestricted: gcpComputeInsTemplate.Startrestricted

    };
    var orderObject = {};

    beforeAll(function () {
        ordersPage = new Orders();
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        // catalogPage.open();        
        serviceName = "att-compute-engine-" + util.getRandomString(5);
        instanceName = "att-vm-" + util.getRandomString(3);
        modifiedParamMap = { "Service Instance Name": serviceName, "Quantity": "2", "Instance Name": instanceName.toLowerCase() };
    });

    xit('Compute Engine : Verify Only One service is displaying after searching with servicename', function () {
        catalogPage.open();
        catalogPage.clickFirstCategoryCheckBoxBasedOnName("All Categories");
        browser.sleep(5000);
        catalogPage.searchForBluePrint(gcpComputeInsTemplate.bluePrintName);
        expect(catalogPage.checkServiceIsPresent(gcpComputeInsTemplate.bluePrintName)).toEqual(true);
        expect(catalogPage.validateIfOneServiceIsDisplayed()).toEqual(1);
    });

    xit('Compute Engine - Verify fields on Main Parameters page is working fine', function () {
        catalogPage.clickConfigureButtonBasedOnName(gcpComputeInsTemplate.bluePrintName);
        expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
        placeOrderPage.setServiceNameText(serviceName);
        placeOrderPage.selectProviderAccount(gcpComputeInsTemplate.providerAccount);
        expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
    });

    xit('Compute Engine - Verify Summary details and Additional Details are listed in review Order page', async function () {
        var ComputeINSObject = JSON.parse(JSON.stringify(gcpComputeInsTemplate));
        catalogPage.open();
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickFirstCategoryCheckBoxBasedOnName('Compute');
        catalogPage.clickConfigureButtonBasedOnName(gcpComputeInsTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetails(gcpComputeInsTemplate, modifiedParamMap).then(async function (requiredReturnMap) {
            var machineTypeAct = requiredReturnMap["Actual"]["Machine type"];
            machineTypeAct = machineTypeAct.split(" (")[0];
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(requiredReturnMap["Actual"]["Region"]).toEqual(requiredReturnMap["Expected"]["Region"]);
            expect(requiredReturnMap["Actual"]["Machine Type Edit Option"]).toEqual(requiredReturnMap["Expected"]["Machine Type Edit Option"]);
            expect(requiredReturnMap["Actual"]["Zone"]).toEqual(requiredReturnMap["Expected"]["Zone"]);
            expect(requiredReturnMap["Expected"]["Machine type"]).toContain(machineTypeAct);
            expect(requiredReturnMap["Actual"]["Network Tags"]).toEqual(requiredReturnMap["Expected"]["Network Tags"]);
            expect(requiredReturnMap["Actual"]["Encryption"]).toEqual(requiredReturnMap["Expected"]["Encryption"]);
            expect(requiredReturnMap["Actual"]["Encryption"]).toEqual(requiredReturnMap["Expected"]["Encryption"]);
            expect(requiredReturnMap["Actual"]["Source Image Type"]).toEqual(requiredReturnMap["Expected"]["Source Image Type"]);
            expect(requiredReturnMap["Actual"]["Boot Disk Type"]).toEqual(requiredReturnMap["Expected"]["Boot Disk Type"]);
            expect(requiredReturnMap["Actual"]["Size (GB)"]).toEqual(requiredReturnMap["Expected"]["Boot Disk Size in GB"]);
            if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(gcpComputeInsTemplate.TotalCost);
                //BOM Validation as per components of service.
                expect(placeOrderPage.validateBOMOnReviewOrderPage(gcpComputeInsTemplate.Pricing)).toBe(true);
            }
        });
    });

    xit('Compute Engine - Verify Orders details on Approve order and Order history page once it is submitted from catalog page', async function () {
        var orderObject = {};
        var orderAmount;
        global.serviceName = serviceName;
        var ComputeINSObject = JSON.parse(JSON.stringify(gcpComputeInsTemplate));
        catalogPage.open();
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickFirstCategoryCheckBoxBasedOnName('Compute');
        catalogPage.clickConfigureButtonBasedOnName(gcpComputeInsTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetails(gcpComputeInsTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);

        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        expect(util.getCurrentURL()).toMatch('orders');
        ordersPage.searchOrderById(orderObject.orderNumber);
        expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
        ordersPage.getTextFirstAmountOrdersTable().then(function (text) {
            orderAmount = text;
        });
        ordersPage.searchOrderById(orderObject.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
        expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
        expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
        expect(ordersPage.getTextBasedOnLabelName("Region")).toContain(jsonUtil.getValue(ComputeINSObject, "Region"));
        expect(ordersPage.getTextBasedOnLabelName("Machine type")).toEqual(jsonUtil.getValue(ComputeINSObject, "Machine type"));
        expect(ordersPage.getTextBasedOnLabelName("Zone")).toEqual(jsonUtil.getValue(ComputeINSObject, "Zone"));
        expect(ordersPage.getTextBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(ComputeINSObject, "Encryption"));
        expect(ordersPage.getTextBasedOnLabelName("Source Image Type")).toEqual(jsonUtil.getValue(ComputeINSObject, "Source Image Type"));
        expect(ordersPage.getTextBasedOnLabelName("Boot Disk Type")).toEqual(jsonUtil.getValue(ComputeINSObject, "Boot Disk Type"));
        expect(ordersPage.getTextBasedOnLabelName("Size (GB)")).toEqual(jsonUtil.getValue(ComputeINSObject, "Boot Disk Size in GB"));
        expect(ordersPage.getTextBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(ComputeINSObject, "Encryption"));
        if (browser.params.defaultCurrency == "USD") {
            //Validate BOM table
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(gcpComputeInsTemplate.TotalCost);
            totalCostBOM = await placeOrderPage.getBOMTablePrice();
            expect(gcpComputeInsTemplate.TotalCost).toContain(totalCostBOM);
            orderFlowUtil.closeHorizontalSliderIfPresent();
        }

        //Service details on Order History page
        ordersHistoryPage.open();
        ordersHistoryPage.searchOrderById(orderObject.orderNumber);
        ordersHistoryPage.clickServiceDetailsLink();
        expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Region")).toContain(jsonUtil.getValue(ComputeINSObject, "Region"));
        expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Machine type")).toEqual(jsonUtil.getValue(ComputeINSObject, "Machine type"));
        expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Zone")).toEqual(jsonUtil.getValue(ComputeINSObject, "Zone"));
        expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(ComputeINSObject, "Encryption"));
        expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Source Image Type")).toEqual(jsonUtil.getValue(ComputeINSObject, "Source Image Type"));
        expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Boot Disk Type")).toEqual(jsonUtil.getValue(ComputeINSObject, "Boot Disk Type"));
        expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Size (GB)")).toEqual(jsonUtil.getValue(ComputeINSObject, "Boot Disk Size in GB"));
        if (browser.params.defaultCurrency == "USD") {
            //Validate BOM table    
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(gcpComputeInsTemplate.TotalCost);
            totalCostBOM = await placeOrderPage.getBOMTablePrice();
            expect(gcpComputeInsTemplate.TotalCost).toContain(totalCostBOM);
            ordersHistoryPage.closeServiceDetailsSlider();
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(gcpComputeInsTemplate.TotalCost);
        }

    });

    it('Compute Engine - Verify GCP VM instance creation as part of pre-requisite data.', async function () {
        var ComputeINSObject = JSON.parse(JSON.stringify(gcpComputeInsTemplate));
        modifiedParamMap = { "Service Instance Name": serviceName, "Quantity": "1", "Instance Name": instanceName.toLowerCase() };
        catalogPage.open();
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickFirstCategoryCheckBoxBasedOnName('Compute');
        catalogPage.clickConfigureButtonBasedOnName(gcpComputeInsTemplate.bluePrintName);
        orderObject.servicename = serviceName;
        orderObject.instanceName = instanceName;
        global.serviceName = serviceName;
        orderFlowUtil.fillOrderDetails(gcpComputeInsTemplate, modifiedParamMap).then(async function () {
            logger.info("Order details are filled.");
            //Validate Estimated price on Review order page
            if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(gcpComputeInsTemplate.TotalCostSingleInstance);
            }
        });
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpComputeInsTemplate.bluePrintName, "New");
        //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
        if (browser.params.defaultCurrency == "USD") {
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(gcpComputeInsTemplate.EstimatedPriceSingleInstance);
            //Validate pricing on order history page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            browser.sleep(5000);
            expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(gcpComputeInsTemplate.EstimatedPriceSingleInstance);
        }
        if (isDummyAdapterDisabled == "true") {
            //Validate System Tags
            orderObject.componentType = gcpComputeInsTemplate.componentType;
            inventoryPage.open();
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                var tagList = tags.split(",");
                var tagMap = inventoryPage.getServiceTags(tagList);
                var mcmpTag = false;
                //if(isDummyAdapterDisabled == "true"){
                if (Object.keys(tagMap).includes(messageStrings.systemTagText)) {
                    mcmpTag = true;
                }
                expect(mcmpTag).toBe(true);
                inventoryPage.clickLabelsViewDetailsLink();
                //Verify system tags
                expect(inventoryPage.validateSystemTagValueIsDisplayed()).toBe(true);
                expect(inventoryPage.getSystemTagLabel()).toEqual(messageStrings.systemTagText);
                //}			                 
                expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderObject.orderNumber);
                expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
                expect(tagMap["serviceofferingname"]).toEqual(gcpComputeInsTemplate.serviceOffrngName);
            });
        }
        orderFlowUtil.closeHorizontalSliderIfPresent();

    });

    it('Compute Engine -  Edit functionality', function () {
        var editInsObject = JSON.parse(JSON.stringify(gcpComputeInsTemplate));
        var modifiedParamMap = { "EditService": true };
        //Edit function
        orderFlowUtil.editService(orderObject);
        browser.sleep(4000);
        orderFlowUtil.fillOrderDetails(gcpComputeInsTemplate, modifiedParamMap).then(function (reviewOrderExpActParamsMap) {
            logger.info("Edit parameter details are filled.");
            //browser.sleep(5000);
            //Validate Review order page parameters
            expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
        });

        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpComputeInsTemplate.bluePrintName, "Edit");
        //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        //New function
        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == 'Completed') {
                //Verify updated details are reflected on order details apge.
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelName("Machine Type Edit Option")).toEqual(jsonUtil.getValueEditParameter(editInsObject, "Machine Type Edit Option"));
                expect(ordersPage.getTextBasedOnLabelName("CPU Type")).toEqual(jsonUtil.getValueEditParameter(editInsObject, "CPU Type"));
                expect(ordersPage.getTextBasedOnLabelName("Cores")).toEqual(jsonUtil.getValueEditParameter(editInsObject, "Cores"));
                //expect(ordersPage.getTextBasedOnLabelName("CPU Memory")).toEqual(jsonUtil.getValue(editInsObject, "CPU Memory"));
                expect(ordersPage.getTextBasedOnLabelName("CPU platform")).toEqual(jsonUtil.getValueEditParameter(editInsObject, "CPU platform"));
                inventoryPage.closeViewComponent();
            }
        })
    });

    if (isDummyAdapterDisabled == 'true') {

        it('Compute Engine - Verify system tags of provisioned resources after Editing service', function () {
            serviceName = orderObject.servicename;
            inventoryPage.open();
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                var tagList = tags.split(",");
                var tagMap = inventoryPage.getServiceTags(tagList);
                var mcmpTag = false;
                if (isDummyAdapterDisabled == "true") {
                    if (Object.keys(tagMap).includes(messageStrings.systemTagText)) {
                        mcmpTag = true;
                    }
                    expect(mcmpTag).toBe(true);
                    inventoryPage.clickLabelsViewDetailsLink();
                    //Verify system tags
                    expect(inventoryPage.validateSystemTagValueIsDisplayed()).toBe(true);
                    expect(inventoryPage.getSystemTagLabel()).toEqual(messageStrings.systemTagText);
                }
                expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderObject.orderNumber);
                expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
                expect(tagMap["serviceofferingname"]).toEqual(gcpComputeInsTemplate.serviceOffrngName);
                orderFlowUtil.closeHorizontalSliderIfPresent();
            });
        });

        it('Compute Engine-- Verify View Component-Template Output Parameters for the powered ON VM', function () {

            var vmName = orderObject.instanceName;
            var val = JSON.stringify({ "IsUsingDummy": "Yes" });
            vmName = vmName.toLowerCase();
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.getComponentTags().then(function (text) {
                    if (val == text) {
                        //Status for dummy adapter
                        messageStrings.componentType = 'compute.v1.instance';
                    }
                    inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                        inventoryPage.clickViewComponentofAWSInstance().then(function () {
                            //View Component VM details
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(messageStrings.componentType);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Name")).toContain(vmName);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Status")).toEqual(messageStrings.powerStateOn);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);

                            //View Component Template Output Properties
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("name")).toContain(vmName);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("machineType")).toContain(gcpComputeInsTemplate.machineTypeForVm);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("zone")).toContain(messageStrings.zone);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("canIpForward")).toEqual(messageStrings.Canipforward);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("cpuPlatform")).toEqual(messageStrings.Cpuplatform);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("deletionProtection")).toEqual(messageStrings.Deletionprotection);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("kind")).toEqual(messageStrings.kind);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("startRestricted")).toEqual(messageStrings.Startrestricted);
                            inventoryPage.closeViewComponent();
                        });
                    });
                });

            });
        });
    }

    it('Compute Engine - Verify GCP VM instance Reboot functionality.', function () {

        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            browser.executeScript('window.scrollTo(0,0);');
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                //Validate component type on inventory page after expanding service instance
                expect(inventoryPage.getComponentNameOnInventoryPage()).toEqual(messageStrings.componentType);
                inventoryPage.clickRebootButtonOfInstance().then(function () {
                    inventoryPage.clickOkForInstanceRebootPermission();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpComputeInsTemplate.bluePrintName, "Reboot");
            //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(gcpComputeInsTemplate.bluePrintNameReboot);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe(messageStrings.powerStateOn);
            });
        });
    });

    it('Compute Engine - Verify GCP VM instance Turn OFF functionality.', function () {

        var val = JSON.stringify({ "IsUsingDummy": "Yes" });
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            browser.executeScript('window.scrollTo(0,0);');
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                    inventoryPage.clickOkForInstanceTurnOFFPermission();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpComputeInsTemplate.bluePrintName, "TurnOff");
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(gcpComputeInsTemplate.bluePrintNameTurnOff);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.getComponentTags().then(function (text) {
                    if (val == text) {
                        //Status for dummy adapter
                        messageStrings.powerStateOff = 'Off';
                    }
                    //inventoryPage.waitForInstancStateStatusChange(orderObject, status).then(function(){
                    expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe(messageStrings.powerStateOff);
                    //});                
                });
            });
        });
    });

    it('Compute Engine-Negative Scenario ---- Turn OFF the instance when the VM state is OFF', function () {

        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                    //inventoryPage.placeD2opsOrder();
                    expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOffNegativeWarning);
                    inventoryPage.clickCustomOpsWarningOKButton();
                });
            })
        })
    });

    it('Compute Engine-Negative Scenario ---- Reboot the instance when the VM state is OFF', function () {

        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickRebootButtonOfInstance().then(function () {
                    //inventoryPage.placeD2opsOrder();
                    expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.rebootNegativeWarning);
                    inventoryPage.clickCustomOpsWarningOKButton();
                });
            })
        })
    });

    it('Compute Engine - Verify GCP VM instance Turn ON functionality.', function () {
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            browser.executeScript('window.scrollTo(0,0);');
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickTurnONButtonOfInstance().then(function () {
                    inventoryPage.clickOkForInstanceTurnONPermission();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpComputeInsTemplate.bluePrintName, "TurnOn");
            //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            //orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provInProgressState);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(gcpComputeInsTemplate.bluePrintNameTurnOn);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe(messageStrings.powerStateOn);
            });
        });

    });

    it('Compute Engine-Negative Scenario ---- Turn ON the instance when the VM state is ON', function () {

        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickTurnONButtonOfInstance().then(function () {
                    //inventoryPage.placeD2opsOrder();
                    expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOnNegativeWarning);
                    inventoryPage.clickCustomOpsWarningOKButton();
                });
            })
        });

        orderFlowUtil.deleteService(orderObject).then(async function (orderNo) {
            orderObject.deleteOrderNumber = orderNo;
            await util.saveOrderId(gcpComputeInsTemplate.bluePrintName, "Delete2", orderNo);
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
        });


    });

})
