/*
Spec_Name: serviceBus.spec.js 
Description: This spec will cover E2E testing of Service Bus service order submit, approve, edit and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../../testData/appUrls.json'),
        util = require('../../../../helpers/util.js'),
        jsonUtil = require('../../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
        SBTemplate = require('../../../../testData/OrderIntegration/Azure/sb.json');

describe('Azure - Service Bus', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, SOIComponents, orderHistoryPage, catalogDetailsPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Integration' };
        var modifiedParamMap = {};
        var servicename = "AutoSBsrv" + util.getRandomString(5);
        var modifiedParamMapedit = {};

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                orderHistoryPage = new OrderHistoryPage();
                catalogDetailsPage = new CatalogDetailsPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        });

        afterAll(function () {
                // Delete Service Bus
                var returnObj = {};
                returnObj.servicename = servicename;
                returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                orderFlowUtil.approveDeletedOrder(returnObj);
                orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        });

        //E2E  order Submit, Approve, Edit, Delete Service with New Resource Group.
        if (isProvisioningRequired == "true") {
                it('Azure: T404873- Verify that for Service Bus Service,if service is created with new resource group with valid name and location,create valid Service Bus Name ,Service Bus Location , Pricing Tier-Premium Messaging units-4', async function () {
                        var orderObject = JSON.parse(JSON.stringify(SBTemplate));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};
                        var returnObj1 = {};
                        var rgName = "gslautotc_azure_sbRG" + util.getRandomString(5);
                        var sbName = "AutoSB101" + util.getRandomString(5);
                        SOIComponents = [sbName]
                        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Service Bus Name": sbName };
                        orderFlowUtil.fillOrderDetails(SBTemplate, modifiedParamMap);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Checking Inventory Page Service Configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Service Bus Name:")).toEqual(sbName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Service Bus Location:")).toEqual(jsonUtil.getValue(orderObject, "Service Bus Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Pricing Tier:")).toEqual(jsonUtil.getValue(orderObject, "Pricing Tier"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Messaging Units:")).toEqual(jsonUtil.getValue(orderObject, "Messaging Units"));
                        inventoryPage.closeViewDetailsTab();
                        //Checking SOI Components
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.clickExpandFirstRow().then(function () {
                                        browser.executeScript('window.scrollTo(0,0);');
                                        var i = 1;
                                        async.forEachSeries(SOIComponents, function (component, callback) {
                                                inventoryPage.clickOverMenuIcon(i).then(function () {
                                                        inventoryPage.clickOnViewComponent(i).then(function () {
                                                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.mcmpTag);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.bluePrintName);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                                                inventoryPage.closeViewComponent();
                                                                browser.sleep(10000);
                                                                i++;
                                                                return callback();
                                                        });
                                                })
                                        }, function (error) {
                                                if (error) {
                                                        logger.info('Unable to Get SOI component')
                                                }
                                        })
                                })
                        }
                        //edit       
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                        inventoryPage.clickEditServiceIcon();
                        modifiedParamMapedit = {
                                "Service Instance Name": servicename,
                                "EditService": true
                        };
                        orderFlowUtil.fillOrderDetails(SBTemplate, modifiedParamMapedit);
                        placeOrderPage.submitOrder();
                        returnObj1.servicename = servicename;
                        returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        //Open Order page and Approve Order 
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj1);
                        orderFlowUtil.waitForOrderStatusChange(returnObj1, "Completed", 50);
                        // Validate tabs under view Service on inventory page.
                        inventoryPage.open();
                        inventoryPage.searchOrderByServiceName(returnObj1.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        util.waitForAngular();
                        //Validating header 
                        expect(inventoryPage.getTextSOIName()).toContain(returnObj1.servicename);
                        //Validating Service Logs
                        inventoryPage.clickOnServiceLogsTab();
                        expect(inventoryPage.checkServiceLogsPresent()).toBe(true);
                        //Validating Order History Tab
                        inventoryPage.clickOrderHistorTab();
                        if (browser.params.defaultCurrency == "USD") {
                        expect(inventoryPage.getTextEstimatedCostOnOrderHistory()).toEqual(orderObject.TotalCost);
                        expect(inventoryPage.getTextEstimatedCostAfterEditOnOrderHistory()).toEqual(orderObject.CostAfterEdit);
                        }
                        expect(inventoryPage.getTextOrderIdOnOrderHistory()).toEqual(returnObj.orderNumber);
                        expect(inventoryPage.getTextOrderIdAfterEditOnOrderHistory()).toEqual(returnObj1.orderNumber);
                        expect(inventoryPage.getTextNewOperationType()).toMatch('New');
                        expect(inventoryPage.getTextEditOperationType()).toMatch('EditSOI');
                        // Validating BOM Tab
                        if (browser.params.defaultCurrency == "USD") {
                        inventoryPage.clickBOMButton();
                        var totalCostBOM = await placeOrderPage.getBOMTablePrice();
                        expect(orderObject.CostAfterEdit).toContain(totalCostBOM);
                        }
                });
        }

        //Checking parameters on Main Parameters page
        it('Azure: TC-T367005 verify that for Service all parameters on Main Parameters Page are present.', function () {
                var orderObject = JSON.parse(JSON.stringify(SBTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
                if (browser.params.defaultCurrency == "USD") {
                expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
                }
        });

        //Checking values all parameters on Review Order Page and View Order Details
        it('Azure: TC-T367007 verify that for  Service all values on Review Order Page and View Order Details page matches with input.', function () {
                var rgName = "gslautotc_azure_sbRG" + util.getRandomString(5);
                var sbName = "AutoSB101" + util.getRandomString(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Service Bus Name": sbName };
                var returnObj = {};
                returnObj.servicename = servicename;
                var orderObject = JSON.parse(JSON.stringify(SBTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(SBTemplate, modifiedParamMap);
                //Checking Service Details in ReviewOrder
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
                if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
                }
                //Checking Additional Details in ReviewOrder
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Service Bus Name:")).toEqual(sbName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Service Bus Location:")).toEqual(jsonUtil.getValue(orderObject, "Service Bus Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Pricing Tier:")).toEqual(jsonUtil.getValue(orderObject, "Pricing Tier"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Messaging Units:")).toEqual(jsonUtil.getValue(orderObject, "Messaging Units"));
                placeOrderPage.submitOrder();
                var priceInReviewOrder = placeOrderPage.getEstimatedPrice_ReviewOrder();
                var priceInSubmitOrderPopup = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                if (browser.params.defaultCurrency == "USD") {
                 expect(priceInSubmitOrderPopup).toContain(priceInReviewOrder);
                }
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                ordersPage.open();
                ordersPage.searchOrderById(returnObj.orderNumber);
                if (browser.params.defaultCurrency == "USD") {
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(orderObject.EstimatedCost);
                }
                ordersPage.clickFirstViewDetailsOrdersTable();
                //Checking Order Details in View order details
                expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
                //Checking Service Configuration Parameters
                ordersPage.clickServiceConfigurationsTabOrderDetails();
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
                expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Service Bus Name")).toEqual(sbName);
                expect(ordersPage.getTextBasedOnExactLabelName("Service Bus Location")).toEqual(jsonUtil.getValue(orderObject, "Service Bus Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Pricing Tier")).toEqual(jsonUtil.getValue(orderObject, "Pricing Tier"));
                expect(ordersPage.getTextBasedOnExactLabelName("Messaging Units")).toEqual(jsonUtil.getValue(orderObject, "Messaging Units"));
                //Checking Bill Of Material
                if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
                }
                orderHistoryPage.open();
                orderHistoryPage.searchOrderById(returnObj.orderNumber);
                orderHistoryPage.clickServiceDetailsLink();
                // Checking service view details on order history page
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Service Bus Name")).toEqual(sbName);
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Service Bus Location")).toEqual(jsonUtil.getValue(orderObject, "Service Bus Location"));
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Pricing Tier")).toEqual(jsonUtil.getValue(orderObject, "Pricing Tier"));
                expect(orderHistoryPage.getTextServiceDetailsBasedOnLabelName("Messaging Units")).toEqual(jsonUtil.getValue(orderObject, "Messaging Units"));
                if (browser.params.defaultCurrency == "USD") {
                orderHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(orderHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(orderObject.TotalCost);
                }
                orderHistoryPage.closeServiceDetailsSlider();
        });
});
