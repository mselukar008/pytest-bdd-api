"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    async = require('async'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    defaultCurrency = browser.params.defaultCurrency,
    userCredentialsTemplate = require('../../../../testData/credentials.json'),
    gcpCloudDNSTemplate = require('../../../../testData/OrderIntegration/Google/gcpCLoudDNSInstance.json');

describe('GCP - Cloud DNS', function () {
    var ordersPage, homePage, catalogPage, placeOrderPage, inventoryPage, ordersHistoryPage, totalCostBOM, serviceName, zoneName, dnsName, zonename;
    var modifiedParamMap = {};
    var orderObject = {};
    var orderobjectRecordSet = {};
    var messageStrings = {
        providerName: gcpCloudDNSTemplate.provider,
        category: gcpCloudDNSTemplate.Category,
        catalogPageTitle: gcpCloudDNSTemplate.catalogPageTitle,
        inputServiceNameWarning: gcpCloudDNSTemplate.inputServiceNameWarning,
        orderSubmittedConfirmationMessage: gcpCloudDNSTemplate.orderSubmittedConfirmationMessage,
        TTL: gcpCloudDNSTemplate.TTL,
        IPv4Address: gcpCloudDNSTemplate.IPv4Address,
        ResourceRecordType: gcpCloudDNSTemplate.ResourceRecordType,
        TTLUnit: gcpCloudDNSTemplate.TTLUnit,
        systemTagText: "ibm_mcmp_soiid"

    };

    beforeAll(function () {
        ordersPage = new Orders();
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        //browser.manage().window().setSize(1600, 1000);
        orderFlowUtil.closeHorizontalSliderIfPresent();

        //         catalogPage.getUserID(userCredentialsTemplate.superUserName).then(function (status) {
        //             if (status != true) {
        //                 cartListPage.clickUserIcon();
        //                 cartListPage.clickLogoutButton();
        //                 cartListPage.loginFromOtherUser(userCredentialsTemplate.superUserUsername, userCredentialsTemplate.superUserPassword);
        //                 catalogPage.open();
        //                 expect(catalogPage.getUserID(credentailsTemplate.superUserName)).toBe(true);
        //             }
        //         });
    });

    beforeEach(function () {
        serviceName = "auto-cloud-dns-" + util.getRandomString(5);
        zonename = "gcp-test-cbs" + util.getRandomString(5);
        zoneName = zonename.toLowerCase();
        dnsName = "auto.gcp." + util.getRandomString(3);
        dnsName = dnsName.toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "Zone name": zoneName, "DNS name": dnsName };

    });

    it('GCP DNS - Verify fields on Main Parameters page is working fine', function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(gcpCloudDNSTemplate.bluePrintName);
        expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
        placeOrderPage.setServiceNameText(serviceName);
        placeOrderPage.selectProviderAccount(gcpCloudDNSTemplate.providerAccount);
        expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
    });

    it('GCP DNS - Verify Summary details and Additional Details are listed in review Order page', async function () {
        var NetworkINSObject = JSON.parse(JSON.stringify(gcpCloudDNSTemplate));
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(gcpCloudDNSTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetails(gcpCloudDNSTemplate, modifiedParamMap).then(async function (requiredReturnMap) {
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(requiredReturnMap["Actual"]["Zone name"]).toEqual(requiredReturnMap["Expected"]["Zone name"]);
            expect(requiredReturnMap["Actual"]["DNS name"]).toEqual(requiredReturnMap["Expected"]["DNS name"]);
            expect(requiredReturnMap["Actual"]["Description"]).toEqual(requiredReturnMap["Expected"]["Description"]);
            expect(requiredReturnMap["Actual"]["DNSSEC State"]).toEqual(requiredReturnMap["Expected"]["DNSSEC State"]);
            if (defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(gcpCloudDNSTemplate.TotalCost);
                //BOM Validation as per components of service.
                expect(placeOrderPage.validateBOMOnReviewOrderPage(gcpCloudDNSTemplate.Pricing)).toBe(true);
            }


        });
    });

    it('GCP DNS - Verify Order is listed in Orders details page once it is submitted from catalog page', async function () {
        var orderObject = {};
        var orderAmount;
        global.serviceName = serviceName;
        var NetworkINSObject = JSON.parse(JSON.stringify(gcpCloudDNSTemplate));
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(gcpCloudDNSTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetails(gcpCloudDNSTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        //ordersPage.clickordersLink();
        expect(util.getCurrentURL()).toMatch('orders');
        ordersPage.searchOrderById(orderObject.orderNumber);
        expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
        //var orderAmount = ordersPage.getTextFirstAmountOrdersTable();	       
        ordersPage.getTextFirstAmountOrdersTable().then(function (text) {
            orderAmount = text;
        });
        ordersPage.clickFirstViewDetailsOrdersTable();
        //orderFlowUtil.waitForOrderStatusChange(orderObject, 'Approval In Progress');
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
        expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
        // util.waitForAngular();
        expect(ordersPage.getTextBasedOnLabelName("Zone name")).toEqual(zoneName);
        expect(ordersPage.getTextBasedOnLabelName("DNS name")).toEqual(dnsName);
        expect(ordersPage.getTextBasedOnLabelName("DNSSEC State")).toEqual(jsonUtil.getValue(NetworkINSObject, "DNSSEC State"));
        expect(ordersPage.getTextBasedOnLabelName("Description")).toEqual(jsonUtil.getValue(NetworkINSObject, "Description"));
        if (defaultCurrency == "USD") {
            ordersPage.clickBillOfMaterialsTabOrderDetails().then(async function () {
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(gcpCloudDNSTemplate.TotalCost);
                totalCostBOM = await placeOrderPage.getBOMTablePrice();
                expect(gcpCloudDNSTemplate.TotalCost).toContain(totalCostBOM);
            });
        }
        ordersPage.clickServiceDetailSliderCloseButton();
    });

    if (isProvisioningRequired == "true") {
        it('TC-C179968: GCP DNS - E2E : Verify Service Provision,Edit/Add Recordset & Deletion is working fine from consume App', function () {
            var NetworkINSObject = JSON.parse(JSON.stringify(gcpCloudDNSTemplate));
            orderObject.servicename = serviceName;
            global.serviceName = serviceName;
            orderObject.dnsname = dnsName;
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
            catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(gcpCloudDNSTemplate.bluePrintName);
            orderFlowUtil.fillOrderDetails(gcpCloudDNSTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpCloudDNSTemplate.bluePrintName, "New");
            //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == 'Completed') {
                    //Edit service flow					
                    var modifiedParamMapEdit = { "EditService": true };
                    orderFlowUtil.editService(orderObject);
                    orderFlowUtil.fillOrderDetails(gcpCloudDNSTemplate, modifiedParamMapEdit).then(function (reviewOrderExpActParamsMap) {
                        //  browser.sleep(5000);
                        //Validate Review order page parameters
                        expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
                    });
                    if (defaultCurrency == "USD") {
                        // Checking cost of BOM on Updated BOM tab (review Order Page)					
                        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(gcpCloudDNSTemplate.TotalCost);
                    }

                    placeOrderPage.submitOrder();
                    orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpCloudDNSTemplate.bluePrintName, "Edit");
                    //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                    expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');

                    //placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                    placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                    orderFlowUtil.approveOrder(orderObject);
                    orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                    ordersPage.open();
                    ordersPage.clickAllOrdersUnderOrdersSection();
                    ordersPage.searchOrderById(orderObject.orderNumber);
                    ordersPage.clickFirstViewDetailsOrdersTable();
                    expect(ordersPage.getTextBasedOnLabelName("Description")).toEqual(jsonUtil.getValueEditParameter(gcpCloudDNSTemplate, "Description"));
                    if (defaultCurrency == "USD") {
                        ordersPage.clickBillOfMaterialsTabOrderDetails();
                        // Checking cost of BOM on Updated BOM tab (Orders Page)
                        var totalCostUpdated = placeOrderPage.getTextUpdatedBOMTablePrice(2);
                        expect(gcpCloudDNSTemplate.TotalCost).toContain(totalCostUpdated);

                        // Checking cost of BOM on Current BOM tab(Orders Page)
                        totalCostBOM = placeOrderPage.getTextCurrentBOMTablePrice(0);
                        expect(gcpCloudDNSTemplate.TotalCost).toContain(totalCostBOM);
                        //Verify details on orderHistory page 
                        ordersHistoryPage.open();
                        ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                        ordersHistoryPage.clickServiceDetailsLink();
                        ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                        // Checking cost of BOM on Updated BOM tab(order History Page)
                        totalCostUpdated = placeOrderPage.getTextUpdatedBOMTablePrice(2);
                        expect(gcpCloudDNSTemplate.TotalCost).toContain(totalCostUpdated);
                        // Checking cost of BOM on Current BOM tab(order History Page)
                        totalCostBOM = placeOrderPage.getTextCurrentBOMTablePrice(0);
                        expect(gcpCloudDNSTemplate.TotalCost).toContain(totalCostBOM);
                        orderFlowUtil.closeHorizontalSliderIfPresent();
                        inventoryPage.open();
                        inventoryPage.searchOrderByServiceName(orderObject.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                        inventoryPage.clickViewService();
                        // Checking cost of BOM (Inventory Page)
                        inventoryPage.clickBOMButton();
                        totalCostUpdated = placeOrderPage.getBOMTablePrice();
                        expect(gcpCloudDNSTemplate.TotalCost).toContain(totalCostUpdated);
                    }
                    orderFlowUtil.closeHorizontalSliderIfPresent();
                    
                    if (isDummyAdapterDisabled == 'true') {
                        //Validate System tags
                        inventoryPage.open();
                        inventoryPage.searchOrderByServiceName(orderObject.servicename);
                        inventoryPage.clickExpandFirstRow().then(function () {
                            browser.executeScript('window.scrollTo(0,0);');
                            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                                inventoryPage.clickViewComponentofAWSInstance().then(function () {
                                    inventoryPage.clickLabelsViewDetailsLink();
                                    //Verify system tags
                                    expect(inventoryPage.validateSystemTagValueIsDisplayed()).toBe(true);
                                    expect(inventoryPage.getSystemTagLabel()).toEqual(messageStrings.systemTagText);
                                    inventoryPage.closeViewComponent();
                                    inventoryPage.clickExpandFirstRow();
                                });
                            });
                        });
                    }
                }
            });
        });

        if (isDummyAdapterDisabled == 'true') {
            it('GCP DNS - Add Recordset', async function () {
                //Add Recordset flow            
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                        inventoryPage.clickAddRecordSet().then(function () {
                            inventoryPage.clickTurnOnOakybutton();
                            inventoryPage.fillDnsRecordSetDetails();
                        });
                    });
                });
                placeOrderPage.submitOrder();
                inventoryPage.fetchD2opsOrderDetails();
                orderobjectRecordSet.orderNumber = placeOrderPage.getAndSaveOrderId(gcpCloudDNSTemplate.bluePrintName, "AddRecordSet");
                //orderobjectRecordSet.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderobjectRecordSet.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.waitForOrderStatusChange(orderobjectRecordSet, 'Completed');
                orderFlowUtil.verifyOrderStatus(orderobjectRecordSet).then(function (status) {
                    if (status == 'Completed') {
                        //Verify updated details are reflected on order details apge.
                        ordersPage.clickFirstViewDetailsOrdersTable();
                        expect(ordersPage.getTextBasedOnLabelName("DNS name")).toEqual(gcpCloudDNSTemplate.dnsname);
                        expect(ordersPage.getTextBasedOnLabelName("TTL")).toEqual(messageStrings.TTL);
                        expect(ordersPage.getTextBasedOnLabelName("IPv4 Address")).toEqual(messageStrings.IPv4Address);
                        expect(ordersPage.getTextBasedOnLabelName("Resource Record Type")).toEqual(messageStrings.ResourceRecordType);
                        expect(ordersPage.getTextBasedOnLabelName("TTL Unit")).toEqual(messageStrings.TTLUnit);
                        inventoryPage.closeViewComponent();
                    }
                });
            });

            it('GCP DNS - Delete Recordset', async function () {
                var modifiedParamMapDns = { "CustomOperation": true, "Recordsets": gcpCloudDNSTemplate.dnsname + "." + orderObject.dnsname + "." };
                //Delete Recordset flow 
                orderObject.componentType = "dns.v1.managedZone";
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                        inventoryPage.clickDeleteRecordSet().then(function () {
                            //inventoryPage.clickConfirmCheckBoxDeleteServiceModal();
                            inventoryPage.clickOKDeleteServiceModal();
                            orderFlowUtil.fillOrderDetails(gcpCloudDNSTemplate, modifiedParamMapDns);
                        });
                    });
                });

                placeOrderPage.submitOrder();
                inventoryPage.fetchD2opsOrderDetails();
                orderobjectRecordSet.orderNumber = placeOrderPage.getAndSaveOrderId(gcpCloudDNSTemplate.bluePrintName, "DeleteRecordSet");
                //orderobjectRecordSet.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Request Initiated!');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                catalogPage.open();
                orderFlowUtil.waitForOrderStatusChange(orderobjectRecordSet, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderobjectRecordSet)).toBe('Completed');
            });
        }

        it('GCP DNS - Delete Service Instance', async function () {
            //Verify service can be deleted
            //orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
            orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, gcpCloudDNSTemplate.bluePrintName);
            expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
        });
    }
});
