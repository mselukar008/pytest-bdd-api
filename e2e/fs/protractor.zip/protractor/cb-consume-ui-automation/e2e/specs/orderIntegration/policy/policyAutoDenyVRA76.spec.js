"use strict";

var OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
PolicyPage = require('../../../pageObjects/policy.pageObject.js'),
util = require('../../../../helpers/util.js'),
CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
budgetaryFlow = require('../../../../helpers/budgetaryFlow.js'),
budgetDeleteApi = require('../../../../helpers/budgetDeleteApiUtil.js'),
BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),
isProvisioningRequired = browser.params.isProvisioningRequired,
centOs70VRA76Template = require('../../../../testData/OrderIntegration/VRA/CentOs70VRA76.json'),
dynamic76Template = require('../../../../testData/OrderIntegration/VRA/DynamicDropdownVRA76.json'),
policyTemplate = require('../../../../testData/OrderIntegration/policy/policy.json'),
addRulePolicyTemplate = require('../../../../testData/OrderIntegration/policy/addRulePolicy.json'),
credentialsTemplate = require('../../../../testData/credentials.json'),
budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryAddNewBudgetDetails.json'),
centOs70VRA76TemplateObj = JSON.parse(JSON.stringify(centOs70VRA76Template));

describe('Tests for VRA7.6 Auto Deny policy E2E Flow ', function() {
	var ordersPage,catalogPage,budgetaryUnitCode,placeOrderPage,policyPage,policyName,policyRule,serviceName,serviceName1,cartName,policyUpdateSuccessMsg,policyDeleteSuccessMsg,cartListPage,budgetryPage,budgetaryName,budgetaryNewBudgetName; 
    var modifiedParamMap = {};
    var modifiedParamMapAddRule = {};
    var modifiedParamMapBudget = {};
    var modifiedNewBudgetParamMap = {};
	var messageStrings = {
	    providerName:                          centOs70VRA76Template.provider,
        orderSubmittedConfirmationCartMessage: centOs70VRA76Template.orderSubmittedConfirmationCartMessage,
        providerAccount:                       centOs70VRA76Template.providerAccount,
        completedState:                        centOs70VRA76Template.completedState,
        denyState:                             centOs70VRA76Template.denyState,
        updatePolicySuccessMsg:                policyTemplate.updatePolicySuccessMsg, 
        deletePolicySuccessMsg:                policyTemplate.deletePolicySuccessMsg,
        policyAddRuleSuccessMsg:               policyTemplate.policyAddRuleSuccessMsg,
        policyCreateSuccessMsg:                policyTemplate.policyCreateSuccessMsg,    
        budgetaryUnitDeletedApiSucessMsg:      budgetaryUnitDetailsTemplate.budgetaryUnitDeletedApiSucessMsg,
        budgetDeletedApiSucessMsg:             budgetaryUnitDetailsTemplate.budgetDeletedApiSucessMsg,
        budgetNotPresentMsg:                   centOs70VRA76Template.budgetNotPresentMsg
		};
	
	beforeAll(function() {
		ordersPage = new OrdersPage();
		policyPage = new PolicyPage();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		budgetryPage = new BudgetaryPage();
		browser.driver.manage().window().maximize();
		serviceName = "policyAutoDeny" + util.getRandomString(5);
		policyName = "policyVRA"+util.getRandomString(4);
		policyRule = "policyRuleVRA"+util.getRandomString(4);
		modifiedParamMap = {"policy Name":policyName};
		modifiedParamMapAddRule = {"Add Rule Name":policyRule,"technical": "Auto Deny","financial": "Auto Deny"};
		budgetaryName = "autoBudgetUnit"+util.getRandomString(8);
		budgetaryNewBudgetName = "autoBudget"+util.getRandomString(8);
		budgetaryUnitCode = "autoBudgetUnitCode"+util.getRandomString(8);
        modifiedParamMapBudget = {"budgetary Name":budgetaryName, "budgetary unit code":budgetaryUnitCode,"Choose Entity": "Organization","Entity Value": "MYORG","Environment": "policyEnv", "Application": "policyApp"};	
	});

  	it('Create Auto Deny Policy for VRA services', function () {
  		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMap);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		expect(policyPage.getAddRuleSuccessMsgText()).toMatch(policyRule + messageStrings.policyAddRuleSuccessMsg);
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRule);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRule);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(messageStrings.policyCreateSuccessMsg);
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	 });
  	
    it('Create budget for Auto Deny policy', function () {
    	budgetryPage.clickBudgetTab();
    	util.waitForAngular();    
    	budgetryPage.clickOnAddNewBudgetryUnitBtn();
    	budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMapBudget);
    	budgetryPage.clickOnBudgetrySaveBtn();
    	budgetryPage.clickOnBudgetryBudgetsLink();
    	budgetryPage.clickOnBudgetaryAddBudgetButton();
    	var startPeriod = budgetaryFlow.incrementMonth(0); //Zero (0) for current month
    	modifiedNewBudgetParamMap = {"Name":budgetaryNewBudgetName, "Start Period":startPeriod};
    	budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);		
    	budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
    	budgetryPage.clickOnBudgetaryBackBudgetButton();
    });
  	
	
    if (isProvisioningRequired == "true") {
    	fit('VRA7.6- Verify Auto Deny policy for Centos66-7.6 service ', function () {
    		catalogPage.open()
	    	var orderObject = {};
    		modifiedParamMap = {"Service Instance Name":serviceName,"Cart Name":"","Cart Service":"","Team":"policyTEAM1","Environment": "policyEnv", "Application": "policyApp","Provider Account":"policyAcc7.6 / policyAcc7.6","CentOS70 disks":"","Capacity":"","Label":"","User Created":"","Volume ID":""};
    		var modifiedParamMap1 = {"Service Instance Name":serviceName1,"Team":"","Environment": "", "Application": "","Provider Account":"policyAcc7.6 / policyAcc7.6"};
        
	        // Logout from Super User
	        cartListPage.clickUserIcon();
	        cartListPage.clickLogoutButton();
	        browser.sleep(5000);
	      
	        // Login as User with Buyer role and place order
	        cartListPage.loginFromOtherUser(credentialsTemplate.policyBuyerUserID, credentialsTemplate.policyBuyerUserPassword);
	        catalogPage.open();     
	      
	        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(centOs70VRA76TemplateObj.Category);
	        catalogPage.clickConfigureButtonBasedOnName(centOs70VRA76TemplateObj.bluePrintName);
	        orderObject.servicename = serviceName;
	        orderFlowUtil.fillOrderDetails(centOs70VRA76Template, modifiedParamMap).then(async function (requiredReturnMap) {
	       	                   
	        // Submit Orders
	        placeOrderPage.submitOrder();
	        
	       // Get details from popup after submit
	        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
	        var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
	        expect(ordersubmittedBy).toEqual(credentialsTemplate.policyBuyerUser);
	        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
	        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
	              
	        // Logout from Buyer role user
	        cartListPage.clickUserIcon();
	        cartListPage.clickLogoutButton();
	                      
	        /* Login as User with Technical Approver role for which orders
			  are AutoApproved and status moved to Deny state */
	        cartListPage.loginFromOtherUser(credentialsTemplate.technicalApprovalUserID, credentialsTemplate.technicalApprovalUserPass);
	        orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.denyState);
	        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.denyState);
	         
	        // Verify budget is not displayed since user has Technical approver role only
	        await expect(ordersPage.checkInvisibilityOfBudgetDetails()).toBe(false, messageStrings.budgetNotPresentMsg);
	          
	        // Logout from Technical approver user
	        cartListPage.clickUserIcon();
	        cartListPage.clickLogoutButton();
	          
	        // Login as User with Financial Approver role
	        cartListPage.loginFromOtherUser(credentialsTemplate.financialApprovalUserID, credentialsTemplate.financialApprovalUserPass);
	        util.waitForAngular();
	
	        // Check if Budget exists
	        ordersPage.open();
	        ordersPage.clickAllOrdersUnderOrdersSection();
	        ordersPage.searchOrderById(orderObject.orderNumber)
            expect(ordersPage.getBudgetNameAllOrdersText()).toContain(budgetaryName);       
            
	        // AutoDenied and status moved to Deny state(Rejected) for financial approver
	        orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.denyState);      	
	          
	        // Logout from Financial approver user
	        cartListPage.clickUserIcon();
	        cartListPage.clickLogoutButton();
	          
	        // Login as User with Buyer role
	        cartListPage.loginFromOtherUser(credentialsTemplate.policyBuyerUserID, credentialsTemplate.policyBuyerUserPassword);
	               
	        // Login with Super User
	        cartListPage.loginFromOtherUser(credentialsTemplate.superUserID, credentialsTemplate.superUserPassword);
	        catalogPage.open();
	        expect(catalogPage.extractUserFirstName()).toEqual(credentialsTemplate.superUserName);
       });
     });
  // });		
  }
	
	  it('Delete the created policy', function () {
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.clickNotificationCloseButton();
	  	browser.sleep(2000);
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.deletePolicySuccessMsg+" "+policyName+" successfully");
	});
	
	 it('Making the above created budget Inactive', function () {  
		budgetryPage.open();
		budgetryPage.selectbudgetaryPaginationDropDown();
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
    	budgetryPage.clickOnBudgetryBudgetsLink();
    	budgetryPage.clickViewDetailActionIcon();
    	budgetryPage.clickViewDetailBtn();
    	budgetryPage.clickBudgetEditButton();
    	budgetryPage.clickBudgetInactiveStatusText();
    	budgetryPage.clickSaveBudgetButton();
    	budgetryPage.clickOnNotificationCloseButton();
    	budgetryPage.clickAfterEditingBudgetaryBackButton();
    	budgetryPage.clickOnBudgetryDetailsLink();
	});
	    
	afterAll(async function () {
		await budgetDeleteApi.getListOfBudegetaryUnit(budgetaryName).then(async function (budget) {
    	logger.info("budget details"+budget);
    	await budgetDeleteApi.deleteInActiveBudget(budget["budgetcode"],budget["id"]).then(async function (status) {
		expect(status).toEqual(messageStrings.budgetDeletedApiSucessMsg);
		await budgetDeleteApi.deleteBudetaryUnit(budget["budgetcode"]).then(async function (status) {
		expect(status).toEqual(messageStrings.budgetaryUnitDeletedApiSucessMsg);
	   });
     });
   });
 });
	
});
