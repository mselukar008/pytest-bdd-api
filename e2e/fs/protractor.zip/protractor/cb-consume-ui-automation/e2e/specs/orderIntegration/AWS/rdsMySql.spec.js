"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    mysqlTemplate = require('../../../../testData/OrderIntegration/AWS/rdsMySql.json');

describe('AWS - RDS-MYSQL', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, dbInstance, serviceName, mysqlObj, inventoryPage;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = mysqlTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Databases',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        systemTagText: "ibm_mcmp_soiid"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-mysql-" + util.getRandomString(5);
        dbInstance = "mysqlDbIn" + util.getRandomString(5);
        mysqlObj = JSON.parse(JSON.stringify(mysqlTemplate));
    });

    beforeEach(function () {
        modifiedParamMap = { "Service Instance Name": serviceName, "DB instance identifier": dbInstance };
    });

    it('AWS-MySQL - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        catalogPage.open();
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(mysqlTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(mysqlTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(mysqlTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(mysqlTemplate.TotalCost); expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["License Model"]).toEqual(requiredReturnMap["Expected"]["License Model"]);
            expect(requiredReturnMap["Actual"]["DB engine version"]).toEqual(requiredReturnMap["Expected"]["DB engine version"]);
            expect(requiredReturnMap["Actual"]["DB instance class"]).toEqual(requiredReturnMap["Expected"]["DB instance class"]);
            expect(requiredReturnMap["Actual"]["Storage type"]).toEqual(requiredReturnMap["Expected"]["Storage type"]);
            expect(requiredReturnMap["Actual"]["Allocated storage"]).toEqual(requiredReturnMap["Expected"]["Allocated storage"]);
            expect(requiredReturnMap["Actual"]["Provisioned IOPS"]).toEqual(requiredReturnMap["Expected"]["Provisioned IOPS"]);
            expect(requiredReturnMap["Actual"]["DB instance identifier"]).toEqual(dbInstance);
            expect(requiredReturnMap["Actual"]["Master username"]).toEqual(requiredReturnMap["Expected"]["Master username"]);
            expect(requiredReturnMap["Actual"]["Database name"]).toEqual(requiredReturnMap["Expected"]["Database name"]);
            expect(requiredReturnMap["Actual"]["Database port"]).toEqual(requiredReturnMap["Expected"]["Database port"]);
            expect(requiredReturnMap["Actual"]["Backup retention period"]).toEqual(requiredReturnMap["Expected"]["Backup retention period"]);
            expect(requiredReturnMap["Actual"]["Copy tags to snapshot"]).toEqual(requiredReturnMap["Expected"]["Copy tags to snapshot"]);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(mysqlTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 5000);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(mysqlTemplate.EstimatedPrice);
                //Validate pricing on order history page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(mysqlTemplate.EstimatedPrice);
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();            
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(mysqlObj,"AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("License Model")).toEqual(jsonUtil.getValue(mysqlObj,"License Model"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(mysqlObj,"DB engine version"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(mysqlObj,"DB instance class"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Storage type")).toEqual(jsonUtil.getValue(mysqlObj,"Storage type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Allocated storage")).toEqual(jsonUtil.getValue(mysqlObj,"Allocated storage"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Provisioned IOPS")).toEqual(jsonUtil.getValue(mysqlObj,"Provisioned IOPS"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB instance identifier")).toEqual(dbInstance);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Master username")).toEqual(jsonUtil.getValue(mysqlObj,"Master username"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Database name")).toEqual(jsonUtil.getValue(mysqlObj,"Database name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Database port")).toEqual(jsonUtil.getValue(mysqlObj,"Database port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValue(mysqlObj,"Backup retention period"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Copy tags to snapshot")).toEqual(jsonUtil.getValue(mysqlObj,"Copy tags to snapshot"));
 
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(mysqlTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(mysqlTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.clickAllOrdersUnderOrdersSection();
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(mysqlObj,"AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("License Model")).toEqual(jsonUtil.getValue(mysqlObj,"License Model"));
            expect(ordersPage.getTextBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(mysqlObj,"DB engine version"));
            expect(ordersPage.getTextBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(mysqlObj,"DB instance class"));
            expect(ordersPage.getTextBasedOnLabelName("Storage type")).toEqual(jsonUtil.getValue(mysqlObj,"Storage type"));
            expect(ordersPage.getTextBasedOnLabelName("Allocated storage")).toEqual(jsonUtil.getValue(mysqlObj,"Allocated storage"));
            expect(ordersPage.getTextBasedOnLabelName("Provisioned IOPS")).toEqual(jsonUtil.getValue(mysqlObj,"Provisioned IOPS"));
            expect(ordersPage.getTextBasedOnLabelName("DB instance identifier")).toEqual(dbInstance);
            expect(ordersPage.getTextBasedOnLabelName("Master username")).toEqual(jsonUtil.getValue(mysqlObj,"Master username"));
            expect(ordersPage.getTextBasedOnLabelName("Database name")).toEqual(jsonUtil.getValue(mysqlObj,"Database name"));
            expect(ordersPage.getTextBasedOnLabelName("Database port")).toEqual(jsonUtil.getValue(mysqlObj,"Database port"));
            expect(ordersPage.getTextBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValue(mysqlObj,"Backup retention period"));
            expect(ordersPage.getTextBasedOnLabelName("Copy tags to snapshot")).toEqual(jsonUtil.getValue(mysqlObj,"Copy tags to snapshot"));
 
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(mysqlTemplate.TotalCost);
            ordersPage.clickServiceDetailSliderCloseButton();
        });
    });

    it('AWS-MySQL - Validate system tags, Edit and Delete Service', function () {     
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            if (isDummyAdapterDisabled == "true") {
                orderObject.componentType = mysqlTemplate.componentType1;
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(mysqlTemplate.componentType1).then(function (index) {
                    inventoryPage.clickViewComponentBasedOnIndex(index - 1).then(function () {
                        //View Component VM details
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(mysqlTemplate.componentType1);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Resource Id")).toEqual(mysqlTemplate.resourceId);
                        //View Component Template Output Properties
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AvailabilityZone")).toContain(mysqlTemplate.availablilityZone);
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("LicenseModel")).toEqual(jsonUtil.getValue(mysqlObj,"License Model"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("EngineVersion")).toEqual(jsonUtil.getValue(mysqlObj,"DB engine version"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DBInstanceClass")).toEqual(jsonUtil.getValue(mysqlObj,"DB instance class"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("StorageType")).toEqual("io1");
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AllocatedStorage")).toEqual(jsonUtil.getValue(mysqlObj,"Allocated storage"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DBInstanceIdentifier")).toEqual(dbInstance.toLowerCase());
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("MasterUsername")).toEqual(jsonUtil.getValue(mysqlObj,"Master username"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DbInstancePort")).toEqual(jsonUtil.getValue(mysqlObj,"Database port"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("BackupRetentionPeriod")).toEqual(jsonUtil.getValue(mysqlObj,"Backup retention period"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("CopyTagsToSnapshot")).toEqual(jsonUtil.getValue(mysqlObj,"Copy tags to snapshot"));
                    });
                    inventoryPage.getTagsOnInventory().then(function (tags) {
                        var tagList = tags.split(",");
                        var tagMap = inventoryPage.getServiceTags(tagList);
                        var mcmpTag = false;
                        //verifying a system tag
                        expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                        //verifying some of the service tags             
                        expect(tagList.includes(tagList.find(tag => tag.includes("StackId:arn:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:logical-id:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-id:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-name")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("ibm_mcmp_soiid:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("orderNumber")))).toBe(true);
                        orderFlowUtil.closeHorizontalSliderIfPresent();
                    });
                    
                });
            } else {
                inventoryPage.clickOverflowActionButtonForPowerStates();
                inventoryPage.clickViewComponentofAWSInstance();
                inventoryPage.getTagsOnInventory().then(function (tags) {
                    var tagList = tags.split(",");
                    var tagMap = inventoryPage.getServiceTags(tagList);
                    //verifying flags for dummy adapter
                    expect(tagMap["IsUsingDummy"]).toEqual("Yes");
                    expect(tagMap["Name"]).toEqual(mysqlTemplate.bluePrintName);
                    expect(tagMap["PhysicalId"]).toContain(serviceName);
                    expect(Object.keys(tagMap).includes("Test")).toBe(true);
                    expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                });
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AWS Region")).toEqual(jsonUtil.getValue(mysqlObj,"AWS Region"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("license Model")).toEqual(jsonUtil.getValue(mysqlObj,"License Model"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB engine version")).toEqual(jsonUtil.getValue(mysqlObj,"DB engine version"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB instance class")).toEqual(jsonUtil.getValue(mysqlObj,"DB instance class"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Storage type")).toEqual(jsonUtil.getValue(mysqlObj,"Storage type"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Allocated storage")).toEqual(jsonUtil.getValue(mysqlObj,"Allocated storage"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Provisioned IOPS")).toEqual(jsonUtil.getValue(mysqlObj,"Provisioned IOPS"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB instance identifier")).toEqual(jsonUtil.getValue(mysqlObj,"DB instance identifier"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Master username")).toEqual(jsonUtil.getValue(mysqlObj,"Master username"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Database name")).toEqual(jsonUtil.getValue(mysqlObj,"Database name"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Database port")).toEqual(jsonUtil.getValue(mysqlObj,"Database port"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Backup retention period")).toEqual(jsonUtil.getValue(mysqlObj,"Backup retention period"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Copy tags to snapshot")).toEqual(jsonUtil.getValue(mysqlObj,"Copy tags to snapshot"));
 
            }
            orderFlowUtil.closeHorizontalSliderIfPresent();
        });

        //Edit service flow
        var dbInstanceEdit = "sqlservnew"+ util.getRandomString(3); 
        var modifiedParamMapEdit = { "EditService": true, "DB instance identifier":dbInstanceEdit };
        orderFlowUtil.editService(orderObject);
        orderFlowUtil.fillOrderDetails(mysqlTemplate, modifiedParamMapEdit).then(function (reviewOrderExpActParamsMap) {
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(mysqlTemplate.TotalCostPostEdit);
           // browser.sleep(5000);
            //Validate Review order page parameters
            //Delete password key as its encrypted on UI.
            delete reviewOrderExpActParamsMap["Actual"]["Master password"];
            delete reviewOrderExpActParamsMap["Expected"]["Master password"];
            expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
        });
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(mysqlTemplate.bluePrintName, "Edit");
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 5000);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == 'Completed') {
                //Verify updated details are reflected on order details page.						
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelName("DB instance identifier")).toEqual(dbInstanceEdit);
                expect(ordersPage.getTextBasedOnLabelName("Storage type")).toEqual(jsonUtil.getValueEditParameter(mysqlObj, "Storage type"));
                expect(ordersPage.getTextBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValueEditParameter(mysqlObj, "DB instance class"));
                expect(ordersPage.getTextBasedOnLabelName("Copy tags to snapshot")).toEqual(jsonUtil.getValueEditParameter(mysqlObj, "Copy tags to snapshot"));
                expect(ordersPage.getTextBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValueEditParameter(mysqlObj, "Backup retention period"));
                
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(mysqlTemplate.TotalCostPostEdit);
                ordersPage.clickServiceDetailSliderCloseButton();
                //Delete Service flow                    
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, mysqlTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 5000);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            }
        });
    });
});
