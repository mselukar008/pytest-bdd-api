/*
Spec_Name: e2eOperatorUserFlow.spec.js 
Description: This spec will cover E2E testing with super user is order submit, approve and Edit Service with Operator User and 
then deny and than delete the  service with Super User 
Author: Atiksha Batra
*/

"use strict";


var Orders = require('../../../pageObjects/orders.pageObject.js'),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        appUrls = require('../../../../testData/appUrls.json'),
        util = require('../../../../helpers/util.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        EC = protractor.ExpectedConditions,
        EHTemplate = require('../../../../testData/OrderIntegration/Azure/eh.json'),
        CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
        credentialJson =require('../../../../testData/credentials.json'),
        superUserUsername = browser.params.username,
        superUserPassword = browser.params.password
        


describe('Azure - Operator User Flow', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage,cartListPage;
        var modifiedParamMapedit = {};
        var messageStrings = { providerName: 'Azure', category: 'Other Services' };
        var modifiedParamMap = {};
        var servicename = "AutoEHsrv" + util.getRandomString(5);
        var rgName = "gslautotc_azureEHRG101" + util.getRandomString(5);
        var ehName = "autoEH" + util.getRandomString(5);
       
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Event Hub Namespace Name": ehName };
        beforeAll(async function () {
                ordersPage = new Orders();
                cartListPage = new CartListPage();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                browser.driver.manage().window().maximize();
                await cartListPage.loginFromOtherUser(superUserUsername, superUserPassword);
        });

        beforeEach(function () {
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
                rgName = "gslautotc_azureEHRG101" + util.getRandomString(5);
                ehName = "autoEH" + util.getRandomString(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Event Hub Namespace Name": ehName };
                
        });

    afterAll(async function () {
        
            //log out from the opeartor user
            ordersPage.open();
            //login from Super user
            await cartListPage.loginFromOtherUser(superUserUsername, superUserPassword);
            // Delete Event Hub
              var returnObj = {};
              returnObj.servicename = servicename;
              returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
              orderFlowUtil.approveDeletedOrder(returnObj);
              orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, EHTemplate.completedStatus);
              expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe(EHTemplate.completedStatus);
      });

    it('e2e -check  Edit Sercvice from the User having roles as "operators"',async function () {

            var orderObject = JSON.parse(JSON.stringify(EHTemplate));
            catalogPage.clickProviderOrCategoryCheckbox(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            var returnObj = {};
            var returnObj1 = {};


            orderFlowUtil.fillOrderDetails(EHTemplate, modifiedParamMap);

            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(EHTemplate.orderSubmitted);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            orderFlowUtil.approveOrder(returnObj);
            //expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe('Provisioning in Progress');
            orderFlowUtil.waitForOrderStatusChange(returnObj, EHTemplate.completedStatus);


            catalogPage.open();
            //log out from the supper user
        //     cartListPage.clickUserIcon();
        //     cartListPage.clickLogoutButton();


            //login from the operator user
            await cartListPage.loginFromOtherUser(EHTemplate.operatorID, EHTemplate.operatorUserPass);
           
            //Edit order flow
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
            inventoryPage.clickEditServiceIcon();
            inventoryPage.clickNextButton();
            // browser.wait(EC.visibilityOf(element(by.id("button-next-button-mainParams"))),15000);
            modifiedParamMapedit = { "Service Instance Name": servicename, "EditService": true };
            orderFlowUtil.fillOrderDetails(EHTemplate, modifiedParamMapedit);

          
            placeOrderPage.submitOrder();

            returnObj1.servicename = servicename;
            returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();


            //Open Order page and Approve Order 
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(EHTemplate.orderSubmitted);
            placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
           

            ////log out from the opeartor user
            ordersPage.open();
        //     cartListPage.clickUserIcon();
        //     cartListPage.clickLogoutButton();

            //login from Super user
            await cartListPage.loginFromOtherUser(superUserUsername, superUserPassword);
            ordersPage.open();
            //deny Order
            ordersPage.searchOrderById(returnObj1.orderNumber);
            orderFlowUtil.approveOrder(returnObj1);
            orderFlowUtil.waitForOrderStatusChange(returnObj, EHTemplate.completedStatus);
    });
});
