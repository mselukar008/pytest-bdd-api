"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	OrderHistoryPage = require('../../../../../pageObjects/ordersHistory.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	slSecurityGrpTemplate = require('../../../../../../testData/OrderIntegration/Softlayer/SecurityGroupService.json'),
	shoppingCartTemplate   = require('../../../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json');
	
describe('QS: E2E cases for Homo cart with three IBM Cloud services and Manual, External, Manual approval with Normal change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, provOrder, cartListPage, orderHistoryPage, policyPage;
	var modifiedParamMapSL1 = {};
	var modifiedParamMapSL2 = {};
	var modifiedParamMapSL3 = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var orderObject = {};
	var serviceName1 = "SNOWQSauto"+util.getRandomString(5);
	var serviceName2 = "SNOWQSauto"+util.getRandomString(5);
	var serviceName3 = "SNOWQSauto"+util.getRandomString(5);
	var policyName = "SNOWQSautoSLPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWQSautoSLPolicyRule"+util.getRandomString(5);
	var cartName = "SNOWQSautoCart" + util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var secGrpName1 = "SNOWsecGrp"+util.getRandomString(5);
	var secGrpName2 = "SNOWsecGrp"+util.getRandomString(5);
	var secGrpName3 = "SNOWsecGrp"+util.getRandomString(5);

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		orderHistoryPage = new OrderHistoryPage();
		policyPage = new PolicyPage();
		browser.driver.manage().window().maximize();
		
		//Delete policy if exists
		policyPage.open();
		util.waitForAngular();
		policyPage.deletePoliciesIfExist();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New"],"Provider":["IBM Cloud"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
								  "Technical":"Manual Approval","Financial":"External Approval","Legal":"Manual Approval"};
		modifiedParamMapSL1 = {"Service Instance Name":serviceName1, "Cart Name":cartName, "Cart Service":"checkbox-useShoppingCart", "New Shopping Cart":"newCart", "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "Provider Account":"SL-Testing / SL-Testing","Security Group Name":secGrpName1};		
		modifiedParamMapSL2 = {"Service Instance Name":serviceName2,"Cart Name": "","Cart Service": "","Team":"","Environment":"","Application":"","Provider Account":"SL-Testing / SL-Testing","Security Group Name":secGrpName2};
		modifiedParamMapSL3 = {"Service Instance Name":serviceName3,"Cart Name": "","Cart Service": "","Team":"","Environment":"","Application":"","Provider Account":"SL-Testing / SL-Testing","Security Group Name":secGrpName3};

	});
	
	afterAll(function() {
		browser.get(consumeLaunchpadUrl);	
		policyPage.open();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		policyPage.clickRadioButtonRetiredOption();
		policyPage.clickUpdatePolicyBtn();
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickButtonDeletePolicyText();
		policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);

	});
	
	it('Set Change Request type to Normal in SNOW', function () {
		expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Manual, External, Manual Approval Policy IBM Cloud provider', function() {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.selectExternalApprovalDropdownSNOW();
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('Place an order for Homo cart with three IBM Cloud services and Manual, External, Manual approval with Normal change', function () {
			
			//Add first IBM Cloud service to cart
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName1;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL1);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
	        
	        //Add second IBM Cloud service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName2;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL2);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
	        
	        //Add third IBM Cloud service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName3;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL3);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
			
			//Submit Order
			cartListPage.submitOrder(0);
	    	orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
	    	orderObject.submittedBy = cartListPage.getTextSubmittedByOrderSubmittedModal
	        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(shoppingCartTemplate.orderSubmittedConfirmationMessage);
	    	provOrder = cartListPage.getTextOrderNumberOrderSubmittedModal();
	        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
	        orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.approvalState); 
		
			//Validations on SNOW Request page before approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickLegalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
			ordersPage.clickOkInOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,slSecurityGrpTemplate.ProvisioningInProgressText);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
			expect(snowPage.getTextShortDescription()).toBe(cartName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
			expect(snowPage.getCountOfRITMlinks()).toBe(parseInt("3"));
		});
		
		it('Verify the First RITM for Provision functionality with Normal change', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
			var service = snowPage.getTextReqItemVariableServiceName();
			service.then(function(serviceName) {
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName1);
				}
				else if(serviceName.includes(serviceName2)) {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName2);
				}
				else {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName3);
				}

				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(serviceName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(serviceName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Normal change
				snowPage.openRelatedChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
				snowPage.enterChangeReqValues();
				snowPage.enterPlanningValues();
				snowPage.enterScheduleValues();
				snowPage.clickCalculateRiskLink();
				snowPage.clickAssessButton();
				
				//Approvals in SNOW
				snowPage.clickRequestApprovalInChangeRequestPage();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveRequestQS();
				snowPage.approveRequestQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				snowPage.rightClickOnCMDBCIFormHeader();
				var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
				sysidofChangeRequest.then(function(sysidofChangeRequestValue){
				var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
				setChangeRequesttoImplementState.then(function(statuscode){
				expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
				});
			});
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.closeNotifySerDeskTask();
				snowPage.closeImplementTask();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(slSecurityGrpTemplate.completedOrderStatus);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(slSecurityGrpTemplate.completedOrderStatus);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(slSecurityGrpTemplate.completedOrderStatus);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickBackButton();
	    });
	
		it('Verify the Second RITM for Provision functionality with Normal change', function () {
		
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
			var service = snowPage.getTextReqItemVariableServiceName();
			service.then(function(serviceName) {
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName1);
				}
				else if(serviceName.includes(serviceName2)) {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName2);
				}
				else {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName3);
				}
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(serviceName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(serviceName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Normal change
				snowPage.openRelatedChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
				snowPage.enterChangeReqValues();
				snowPage.enterPlanningValues();
				snowPage.enterScheduleValues();
				snowPage.clickCalculateRiskLink();
				snowPage.clickAssessButton();
				
				//Approvals in SNOW
				snowPage.clickRequestApprovalInChangeRequestPage();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveRequestQS();
				snowPage.approveRequestQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				snowPage.rightClickOnCMDBCIFormHeader();
				var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
				sysidofChangeRequest.then(function(sysidofChangeRequestValue){
				var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
				setChangeRequesttoImplementState.then(function(statuscode){
				expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
				});
			});
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.closeNotifySerDeskTask();
				snowPage.closeImplementTask();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(slSecurityGrpTemplate.completedOrderStatus);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(slSecurityGrpTemplate.completedOrderStatus);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(slSecurityGrpTemplate.completedOrderStatus);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickBackButton();
	    });
		
		it('Verify the Third RITM for Provision functionality with Normal change', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickThirdRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
			var service = snowPage.getTextReqItemVariableServiceName();
			service.then(function(serviceName) {
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName1);
				}
				else if(serviceName.includes(serviceName2)) {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName2);
				}
				else {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName3);
				}
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(serviceName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(serviceName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Normal change
				snowPage.openRelatedChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
				snowPage.enterChangeReqValues();
				snowPage.enterPlanningValues();
				snowPage.enterScheduleValues();
				snowPage.clickCalculateRiskLink();
				snowPage.clickAssessButton();
				
				//Approvals in SNOW
				snowPage.clickRequestApprovalInChangeRequestPage();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveRequestQS();
				snowPage.approveRequestQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				snowPage.rightClickOnCMDBCIFormHeader();
				var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
				sysidofChangeRequest.then(function(sysidofChangeRequestValue){
				var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
				setChangeRequesttoImplementState.then(function(statuscode){
				expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
				});
			});
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.closeNotifySerDeskTask();
				snowPage.closeImplementTask();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.completedOrderStatus);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(slSecurityGrpTemplate.completedOrderStatus);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(slSecurityGrpTemplate.completedOrderStatus);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(slSecurityGrpTemplate.completedOrderStatus);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickThirdRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickBackButton();
			
			//Validations on SNOW Request page after Completion of all RITM's
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
	    });
	 }
	
	 
});
	
	
	
	