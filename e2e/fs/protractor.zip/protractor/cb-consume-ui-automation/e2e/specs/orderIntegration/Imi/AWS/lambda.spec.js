"use strict";
var Orders = require('../../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../../helpers/util.js'),
    jsonUtil = require('../../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../../testData/appUrls.json'),
    imiUtil = require('../../../../../helpers/imiApiUtil.js'),    
    imiConfigTemplate = require('../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    imiManageServiceTemplate = require('../../../../../testData/OrderIntegration/Imi/manageService.json'),
    lambdaInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSLambdaInstance.json');

describe('IMI-AWS-Lambda', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, LambdaINSObject, inventoryPage, msgToVerify;
    var modifiedParamMap = {};
    var orderObject = {};
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Compute',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",        
        instanceName: lambdaInstanceTemplate.instanceName,
        componentType: lambdaInstanceTemplate.componentType,
        serviceId:lambdaInstanceTemplate.serviceId,        
        imiOrderSubmitted: "Configure IMI Managed Service"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
    });
    
//    afterEach(function(){
//         catalogPage.open();
//         browser.navigate().refresh()
//     });

//     beforeEach(function(){
//         catalogPage.open();        
//     });
       
    it('IMI-AWS-Lambda-Verify E2E flow with IMI Add On', function () {

        var serviceDetailsMap = {};
        serviceName = "aws-imi-lambda-" + util.getRandomString(5);
        var addOnName = "lambda-adOn-" + util.getRandomString(5);
        var Name= "auto-lambda-" + util.getRandomString(4);
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": Name, "Add-On Name": addOnName };        
        LambdaINSObject = JSON.parse(JSON.stringify(lambdaInstanceTemplate));
        orderObject.servicename = serviceName;
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(lambdaInstanceTemplate.bluePrintName);

        //Update lambda template with IMI template
        delete lambdaInstanceTemplate["Order Parameters"]["Configure Add-ons"];
        lambdaInstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
        lambdaInstanceTemplate["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
        lambdaInstanceTemplate["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
        lambdaInstanceTemplate["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(lambdaInstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            lambdaInstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiManageServiceTemplate["Configure Add-ons"];
            delete lambdaInstanceTemplate["Order Parameters"]["IMI Main Parameters"];
            delete lambdaInstanceTemplate["Order Parameters"]["Configure manage service"];
            delete lambdaInstanceTemplate["Order Parameters"]["Review IMI Config"];
            serviceDetailsMap = requiredReturnMap;
            util.waitForAngular();
            //Validate IMI configuration on Review Order page
            expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(placeOrderPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(placeOrderPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Provider Account", 1)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Provider Account IMI"));

            //Validate Review Order page with all Service Configuration
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
           // expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(lambdaInstanceTemplate.TotalCostWithAddOn);
            placeOrderPage.getEstimatedPrice_ReviewOrder().then(function(price){
                price = parseFloat(price.replace("USD ", ""));
                price = util.roundOffNumber(price);
                //expect("USD " + price.toFixed(2)).toEqual(lambdaInstanceTemplate.TotalCostWithAddOn);
                expect(lambdaInstanceTemplate.TotalCostWithAddOn).toContain("USD " + price.toFixed(2));
            });
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Runtime"]).toEqual(requiredReturnMap["Expected"]["Runtime"]);
            //expect(requiredReturnMap["Actual"]["Role"]).toEqual(requiredReturnMap["Expected"]["Role"]);
            expect(requiredReturnMap["Actual"]["S3 Bucket"]).toEqual(requiredReturnMap["Expected"]["S3 Bucket"]);
            expect(requiredReturnMap["Actual"]["S3 Key"]).toEqual(requiredReturnMap["Expected"]["S3 Key"]);
            expect(requiredReturnMap["Actual"]["Handler"]).toEqual(requiredReturnMap["Expected"]["Handler"]);
            expect(requiredReturnMap["Actual"]["Timeout"]).toEqual(requiredReturnMap["Expected"]["Timeout"]);
            expect(requiredReturnMap["Actual"]["Tracing Config"]).toEqual(requiredReturnMap["Expected"]["Tracing Config"]);
            expect(requiredReturnMap["Actual"]["Memory"]).toEqual(requiredReturnMap["Expected"]["Memory"]);
            expect(requiredReturnMap["Actual"]["DLQ Resource"]).toEqual(requiredReturnMap["Expected"]["DLQ Resource"]);
            expect(requiredReturnMap["Actual"]["Concurrency"]).toEqual(requiredReturnMap["Expected"]["Concurrency"]);
            expect(requiredReturnMap["Actual"]["With VPC"]).toEqual(requiredReturnMap["Expected"]["With VPC"]);
            expect(requiredReturnMap["Actual"]["VPC"]).toEqual(requiredReturnMap["Expected"]["VPC"]);
            //expect(requiredReturnMap["Actual"]["Subnets"]).toEqual(requiredReturnMap["Expected"]["Subnets"]);
            expect(requiredReturnMap["Actual"]["Security Groups"]).toEqual(requiredReturnMap["Expected"]["Security Groups"]);
            expect(requiredReturnMap["Actual"]["Encryption Configuration"]).toEqual(requiredReturnMap["Expected"]["Encryption Configuration"]);
            expect(requiredReturnMap["Actual"]["Layer selection"]).toEqual(requiredReturnMap["Expected"]["Layer selection"]);
            expect(requiredReturnMap["Actual"]["Layer"]).toEqual(requiredReturnMap["Expected"]["Layer"]);
            expect(requiredReturnMap["Actual"]["Version"]).toEqual(requiredReturnMap["Expected"]["Version"]);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate Add on on orders page
            expect(ordersPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
            expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            util.waitForAngular();
            expect(ordersPage.getTextBasedOnExactLabelName("AWS Region")).toEqual(jsonUtil.getValue(LambdaINSObject, "AWS Region"));
            //expect(ordersPage.getTextBasedOnExactLabelName("Name")).toEqual(lambdaFunctionName);
            expect(ordersPage.getTextBasedOnExactLabelName("Runtime")).toEqual(jsonUtil.getValue(LambdaINSObject, "Runtime"));
            expect(ordersPage.getTextBasedOnExactLabelName("Role")).toEqual(jsonUtil.getValue(LambdaINSObject, "Role"));
            expect(ordersPage.getTextBasedOnExactLabelName("S3 Bucket")).toEqual(jsonUtil.getValue(LambdaINSObject, "S3 Bucket"));
            expect(ordersPage.getTextBasedOnExactLabelName("S3 Key")).toEqual(jsonUtil.getValue(LambdaINSObject, "S3 Key"));
            expect(ordersPage.getTextBasedOnExactLabelName("Handler")).toEqual(jsonUtil.getValue(LambdaINSObject, "Handler"));
            expect(ordersPage.getTextBasedOnExactLabelName("Timeout")).toEqual(jsonUtil.getValue(LambdaINSObject, "Timeout"));
            expect(ordersPage.getTextBasedOnExactLabelName("Tracing Config")).toEqual(jsonUtil.getValue(LambdaINSObject, "Tracing Config"));
            expect(ordersPage.getTextBasedOnExactLabelName("Memory")).toEqual(jsonUtil.getValue(LambdaINSObject, "Memory"));
            expect(ordersPage.getTextBasedOnExactLabelName("DLQ Resource")).toEqual(jsonUtil.getValue(LambdaINSObject, "DLQ Resource"));
            expect(ordersPage.getTextBasedOnExactLabelName("Concurrency")).toEqual(jsonUtil.getValue(LambdaINSObject, "Concurrency"));
            expect(ordersPage.getTextBasedOnExactLabelName("With VPC")).toEqual(jsonUtil.getValue(LambdaINSObject, "With VPC"));
            expect(ordersPage.getTextBasedOnExactLabelName("VPC")).toEqual(jsonUtil.getValue(LambdaINSObject, "VPC"));
            //expect(ordersPage.getTextBasedOnExactLabelName("Subnets")).toEqual("subnet-f3a23cff (us-east-1f),subnet-db6217be (us-east-1d)");
            expect(ordersPage.getTextBasedOnExactLabelName("Security Groups")).toEqual("sg-0293b6716a6781643 | launch-wizard-11");
            expect(ordersPage.getTextBasedOnExactLabelName("Encryption Configuration")).toEqual(jsonUtil.getValue(LambdaINSObject, "Encryption Configuration"));
            expect(ordersPage.getTextBasedOnExactLabelName("Layer selection")).toEqual(jsonUtil.getValue(LambdaINSObject, "Layer selection"));
            expect(ordersPage.getTextBasedOnExactLabelName("Layer")).toEqual(jsonUtil.getValue(LambdaINSObject, "Layer"));
            expect(ordersPage.getTextBasedOnExactLabelName("Version")).toEqual(jsonUtil.getValue(LambdaINSObject, "Version"));
            //Validate Add On details
            ordersPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 2)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate estimated cost
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            //expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(lambdaInstanceTemplate.TotalCostWithAddOn);
            ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails().then(function(actPrice){
                var price = ordersPage.roundOffEstimatedPricing(actPrice, lambdaInstanceTemplate.TotalCostWithAddOn);
                expect(price[0]).toEqual(price[1]);
            });    
            //Validate BOM table on order details
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Serverless": "0.000016", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);                
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                //expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(lambdaInstanceTemplate.EstimatedPriceWithAddOn);
                ordersPage.getTextFirstAmountOrdersTable().then(function(actPrice){
                    var price = ordersPage.roundOffTotalCost(actPrice, lambdaInstanceTemplate.EstimatedPriceWithAddOn);
                    expect(price[0]).toEqual(price[1]);
                });    
            }

            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            //Validate Add-On tag
            expect(ordersHistoryPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate Add On Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickExpandArrowForServiceAddOn();
            ordersHistoryPage.getAddOnDetails().then(function (addOnDetails) {
                expect(addOnDetails[1]).toContain(addOnName);
                expect(addOnDetails[3]).toContain(imiConfigTemplate.EstimatedPrice);
                expect(addOnDetails[4]).toContain("Completed");
            })
            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(LambdaINSObject, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Runtime")).toEqual(jsonUtil.getValue(LambdaINSObject, "Runtime"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Role")).toEqual(jsonUtil.getValue(LambdaINSObject, "Role"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("S3 Bucket")).toEqual(jsonUtil.getValue(LambdaINSObject, "S3 Bucket"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("S3 Key")).toEqual(jsonUtil.getValue(LambdaINSObject, "S3 Key"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Handler")).toEqual(jsonUtil.getValue(LambdaINSObject, "Handler"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Timeout")).toEqual(jsonUtil.getValue(LambdaINSObject, "Timeout"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Tracing Config")).toEqual(jsonUtil.getValue(LambdaINSObject, "Tracing Config"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Memory")).toEqual(jsonUtil.getValue(LambdaINSObject, "Memory"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DLQ Resource")).toEqual(jsonUtil.getValue(LambdaINSObject, "DLQ Resource"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Concurrency")).toEqual(jsonUtil.getValue(LambdaINSObject, "Concurrency"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("With VPC")).toEqual(jsonUtil.getValue(LambdaINSObject, "With VPC"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(LambdaINSObject, "VPC"));            
            ordersHistoryPage.getTextBasedOnLabelName("VPC").then(function(vpc){
                expect(vpc[3]).toEqual(jsonUtil.getValue(LambdaINSObject, "VPC"));            
            });
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Security Groups")).toEqual("sg-0293b6716a6781643 | launch-wizard-11");
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Encryption Configuration")).toEqual(jsonUtil.getValue(LambdaINSObject, "Encryption Configuration"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Layer selection")).toEqual(jsonUtil.getValue(LambdaINSObject, "Layer selection"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Layer")).toEqual(jsonUtil.getValue(LambdaINSObject, "Layer"));
            ordersHistoryPage.getTextBasedOnLabelName("Layer").then(function(Layer){
                expect(Layer[3]).toEqual(jsonUtil.getValue(LambdaINSObject, "Layer"));            
            });
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Version")).toEqual(jsonUtil.getValue(LambdaINSObject, "Version"));
            ordersHistoryPage.getTextBasedOnLabelName("Version").then(function(Version){
                expect(Version[5]).toEqual(jsonUtil.getValue(LambdaINSObject, "Version"));            
            });
            //Validate Add-On Details
            ordersHistoryPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 2)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 4)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
           // expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(lambdaInstanceTemplate.TotalCostWithAddOn);
            ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab().then(function(actPrice){
                var price = ordersPage.roundOffTotalCost(actPrice, lambdaInstanceTemplate.TotalCostWithAddOn);
                expect(price[0]).toEqual(price[1]);
            });
            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Serverless": "USD 0.000016", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
           // expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(lambdaInstanceTemplate.TotalCostWithAddOn);
            ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab().then(function(actPrice){
                var price = ordersPage.roundOffTotalCost(actPrice, lambdaInstanceTemplate.TotalCostWithAddOn);
                expect(price[0]).toEqual(price[1]);
            });
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Verify Output parameter in Inventory
            expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            inventoryPage.clickViewAddOnDetails(orderObject);
            //Verify Add On details in Inventory
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Provider Name", 3)).toBe("IMI");
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Instance Status", 2)).toBe("Active");
            expect(inventoryPage.getTextImiMangmntLevl()).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            //expect(inventoryPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(inventoryPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //verify bom for Add On
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(imiConfigTemplate.TotalCost);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Validate IMI tags
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                 var tagList = tags.split(",");               
                if(isDummyAdapterDisabled == "true"){
                    expect(tagList[4]).toContain(imiConfigTemplate.ServiceTierName); 
                    expect(tagList[3]).toContain(imiConfigTemplate.BillingPlanName);  
                }else{
                    expect(tagList[0]).toContain(imiConfigTemplate.ServiceTierName); 
                    expect(tagList[2]).toContain(imiConfigTemplate.BillingPlanName);  
                } 
                orderFlowUtil.closeHorizontalSliderIfPresent();
            });          
        });
    });

    it('IMI-AWS-Lambda-Configure IMI Manage service having AddOn', function () {
        
        modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickConfigureImiServicefirst();
                inventoryPage.clickOkButnInConfigrImiPopUp();
            });
        });
     
        orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
            //Validate Estimated Cost    
            expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
            //Validate updated BOM table
            var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": "USD 10.00", "Monthly billing (This is the maximum estimated amount)": "USD 20.00" }
            expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
            //Submit order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            //expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service details
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //Validate BOM on Approve order page
            ordersPage.clickBOMTabImi();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": "USD 10.00", "Monthly billing (This is the maximum estimated amount)": "USD 20.00" }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();            
            //Approve order            
            orderFlowUtil.approveOrder(orderObject);
            
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);

            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);

            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            ordersHistoryPage.getImiManagedServiceDetails().then(function(imiDetails){
               expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
            });

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();

            //Validate Updated BOM on Inventory(AddOn+Manage Service)
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(lambdaInstanceTemplate.TotalCostWithAddOn);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            inventoryPage.clickViewServiceClosebutton();
          
            //Delete Service flow
            orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
            //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
        });
    });

    
    it('IMI-AWS-Lambda- Configure Manage service from Inventory', function () {
        var serviceDetailsMap = {};
        serviceName = "aws-auto-lambda-" + util.getRandomString(5);
        var Name= "auto-lambda-" + util.getRandomString(4);
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": Name }; 
        
        LambdaINSObject = JSON.parse(JSON.stringify(lambdaInstanceTemplate));
        orderObject.servicename = serviceName;
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(lambdaInstanceTemplate.provider);
        catalogPage.clickProviderOrCategoryCheckbox(lambdaInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(lambdaInstanceTemplate.bluePrintName);
      
        //Fill Order Details
        orderFlowUtil.fillOrderDetails(lambdaInstanceTemplate, modifiedParamMap);
        //Submit Order
        placeOrderPage.submitOrder();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);       
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
         //Validate Estimated price on approve order page
        //expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(lambdaInstanceTemplate.EstimatedPrice);
        ordersPage.getTextFirstAmountOrdersTable().then(function(price){            
            var price = ordersPage.roundOffEstimatedPricing(price,lambdaInstanceTemplate.EstimatedPrice);
            expect(price[0]).toEqual(price[1]);                        
        });
        modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickConfigureImiServicefirst();
                inventoryPage.clickOkButnInConfigrImiPopUp();
            });
        });

        // Delete parameters
//         delete imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
//         delete imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
//         delete imiConfigTemplate["Order Parameters"]["Review IMI Config"];
        orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
            //Validate Estimated Cost    
            expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
            //Validate updated BOM table
            var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": "USD 10.00", "Monthly billing (This is the maximum estimated amount)": "USD 20.00" }
            expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
            //Submit order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Navigate to Inventory and check same order id is generated after performing
            //same operation as the order is not approved, CON-34929
            //======================================================================        
               
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                    inventoryPage.clickConfigureImiService();
                    inventoryPage.getCustomOpsWarningPopupText().then(function(text){
                        expect(text.split("Order Number:")[1]).toContain(orderObject.orderNumber);
                        inventoryPage.clickCustomOpsWarningOKButton(); 
                    });                                               
                });
            });
            ordersPage.open();
            //expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service details
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //Validate BOM on Approve order page
            ordersPage.clickBOMTabImi();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": "USD 10.00", "Monthly billing (This is the maximum estimated amount)": "USD 20.00" }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();            
            //Approve order            
            orderFlowUtil.approveOrder(orderObject);
            
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);

            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);

            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            ordersHistoryPage.getImiManagedServiceDetails().then(function(imiDetails){
               expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
            });

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
             ordersHistoryPage.closeServiceDetailsSlider();
            //Validate IMI tags
//            if(isDummyAdapterDisabled == "true"){
//                 inventoryPage.getImiTags(orderObject).then(function (tags) {
//                     var tagList = tags.split(",");
//                     expect(tagList[2]).toContain(imiConfigTemplate.BillingPlan);
//                     expect(tagList[0]).toContain(imiConfigTemplate.ServiceTier);
//                     orderFlowUtil.closeHorizontalSliderIfPresent();
//                 });
//             }

            //Delete Service flow
            orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
            //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
        });
    });
});
