
"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
	HomePage = require('../../../pageObjects/home.pageObject.js'),
	CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	async = require('async'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	jsonUtil = require('../../../../helpers/jsonUtil.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	cloudStorageTemplate = require('../../../../testData/OrderIntegration/Google/cloudstorage.json');


describe('GCP - Cloud Storage', function () {
	var ordersPage, homePage, catalogPage, placeOrderPage, inventoryPage, ordersHistoryPage, totalCostBOM, totalCostUpdated, serviceName, bucketname, bucketName;
	var modifiedParamMap = {};
	var messageStrings = {
		providerName: 'Google',
		category: 'Storage',
		orderSubmittedConfirmationMessage: 'Order Submitted !',
		systemTagText: "ibm_mcmp_soiid"
	};

	beforeAll(function () {
		ordersPage = new Orders();
		homePage = new HomePage();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		ordersHistoryPage = new OrderHistoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		serviceName = "auto-cloud-storage-" + util.getRandomString(5);
		bucketname = "qabucket-" + util.getRandomString(5);
		bucketName = bucketname.toLowerCase()
		modifiedParamMap = { "Name": bucketName, "Service Instance Name": serviceName };
	});

	it('Google Cloud Storage : Verify Only One service is displaying after searching with servicename', async function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
		catalogPage.searchForBluePrint(cloudStorageTemplate.bluePrintName);
		expect(catalogPage.checkServiceIsPresent(cloudStorageTemplate.bluePrintName)).toEqual(true);
		expect(catalogPage.validateIfOneServiceIsDisplayed()).toEqual(1);

		
	});

	it('Google Cloud Storage : Verify fields on Main Parameters page are working fine.', function () {

		catalogPage.clickConfigureButtonBasedOnName(cloudStorageTemplate.bluePrintName);
		expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
		placeOrderPage.setServiceNameText(serviceName);
		placeOrderPage.selectProviderAccount(cloudStorageTemplate.providerAccount);
		//Verify Next button is enabled, provider name and category is as per service.
		expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
	});

	it('Google Cloud Storage : Verify Service Details are listed in Review Order page', async function () {
		var cloudStorageInsObject = JSON.parse(JSON.stringify(cloudStorageTemplate));
		//Select provider to display related services
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
		catalogPage.clickConfigureButtonBasedOnName(cloudStorageTemplate.bluePrintName);
		//Fill order details.
		orderFlowUtil.fillOrderDetails(cloudStorageTemplate, modifiedParamMap).then(async function (requiredReturnMap) {
			var googleKey = requiredReturnMap["Actual"]["Encryption"];
			var storageClass = requiredReturnMap["Actual"]["Storage class"];
			storageClass = storageClass.split(" (")[0];
			googleKey = googleKey.split(" (")[0];
			expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
			//Verify Additional Details            
			expect(requiredReturnMap["Actual"]["Name"]).toEqual(bucketName);
			expect(requiredReturnMap["Expected"]["Storage Class"]).toContain(storageClass);
			expect(requiredReturnMap["Actual"]["Location"]).toEqual(requiredReturnMap["Expected"]["Location"]);
			expect(requiredReturnMap["Expected"]["Encryption"]).toContain(googleKey);
			expect(requiredReturnMap["Actual"]["Key"]).toEqual(requiredReturnMap["Expected"]["Key"]);
			expect(requiredReturnMap["Actual"]["Value"]).toEqual(requiredReturnMap["Expected"]["Value"]);
			if (browser.params.defaultCurrency == "USD") {
				expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(cloudStorageTemplate.TotalCost);
				//BOM Validation as per components of service.
				expect(placeOrderPage.validateBOMOnReviewOrderPage(cloudStorageTemplate.Pricing)).toBe(true);
			}
		});

	});

	it('Google Cloud Storage : Verify Order Details on Approve order page and order history page once order is submitted from catalog page', async function () {
		var orderObject = {};
		var orderAmount;
		global.serviceName = serviceName;
		var cloudStorageInsObject = JSON.parse(JSON.stringify(cloudStorageTemplate));
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
		catalogPage.clickConfigureButtonBasedOnName(cloudStorageTemplate.bluePrintName);
		//var servicename = orderFlowUtil.fillOrderDetails(cloudStorageTemplate);
		orderFlowUtil.fillOrderDetails(cloudStorageTemplate, modifiedParamMap);
		placeOrderPage.submitOrder();
		expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
		orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
		placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

		//Service details on Approve Order page
		ordersPage.open();
		ordersPage.searchOrderById(orderObject.orderNumber);
		expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
		ordersPage.getTextFirstAmountOrdersTable().then(function (text) {
			orderAmount = text;
		});
		ordersPage.clickFirstViewDetailsOrdersTable();
		//orderFlowUtil.waitForOrderStatusChange(orderObject, 'Approval In Progress');
		//Validate Service Instance Name on Order Detail page.
		expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
		//Validate Provider Name on Order Detail page.
		expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
		//Validate Order Status on Order Detail page.		
		expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
		//Validate Approve Button is displayed Order Detail page
		expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
		//Validate Deny Button is displayed Order Detail page
		expect(ordersPage.isPresentDenyButtonOrderDetails()).toEqual(true);
		//Verify details from service configurations tab.		
		//expect(placeOrderPage.getTextBasedOnLabelName("Name")).toEqual(bucketName);
		expect(ordersPage.getTextBasedOnLabelName("Storage class")).toEqual(jsonUtil.getValue(cloudStorageInsObject, "Storage Class"));
		expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(cloudStorageInsObject, "Location"));
		expect(ordersPage.getTextBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(cloudStorageInsObject, "Encryption"));
		expect(ordersPage.getTextBasedOnLabelName("Key")).toEqual(jsonUtil.getValue(cloudStorageInsObject, "Key"));
		expect(ordersPage.getTextBasedOnLabelName("Value")).toEqual(jsonUtil.getValue(cloudStorageInsObject, "Value"));
		if (browser.params.defaultCurrency == "USD") {
			//verify details from Bill of Materials Page.			
			ordersPage.clickBillOfMaterialsTabOrderDetails().then(async function () {
				expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(cloudStorageTemplate.TotalCost);
				totalCostBOM = await placeOrderPage.getBOMTablePrice();
				expect(cloudStorageTemplate.TotalCost).toContain(totalCostBOM);
				//ordersPage.clickServiceDetailSliderCloseButton();
			});
		}
		//Service details on Order History page
		ordersHistoryPage.open();
		ordersHistoryPage.searchOrderById(orderObject.orderNumber);
		ordersHistoryPage.clickServiceDetailsLink();
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Storage class")).toEqual(jsonUtil.getValue(cloudStorageInsObject, "Storage Class"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Location")).toEqual(jsonUtil.getValue(cloudStorageInsObject, "Location"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(cloudStorageInsObject, "Encryption"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Key")).toEqual(jsonUtil.getValue(cloudStorageInsObject, "Key"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Value")).toEqual(jsonUtil.getValue(cloudStorageInsObject, "Value"));
		
		if (browser.params.defaultCurrency == "USD") {
			ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
			expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(cloudStorageTemplate.TotalCost);
			totalCostBOM = await placeOrderPage.getBOMTablePrice();
			expect(cloudStorageTemplate.TotalCost).toContain(totalCostBOM);
			ordersHistoryPage.closeServiceDetailsSlider();
			ordersHistoryPage.clickBillOfMaterials();
			expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(cloudStorageTemplate.TotalCost);
			
		}
	});

	if (isProvisioningRequired == "true") {
		var orderObject = {};
		it('Google Cloud Storage : E2E:Verify Google cloud storage Order Provisioning is working fine from consume Application', async function () {
			var cloudStorageInsObject = JSON.parse(JSON.stringify(cloudStorageTemplate));
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
			catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
			catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
			catalogPage.clickConfigureButtonBasedOnName(cloudStorageTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			global.serviceName = serviceName;
			orderFlowUtil.fillOrderDetails(cloudStorageTemplate, modifiedParamMap).then(function () {
				//Validate Estimated price on Review order.
				if(browser.params.defaultCurrency == "USD"){
					expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(cloudStorageTemplate.TotalCost);
				}
			});;
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(cloudStorageTemplate.bluePrintName, "New");
			//orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
			//Validate Estimated price on approve order page
			expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(cloudStorageTemplate.EstimatedPrice);
			//Edit and Delete flow
			orderFlowUtil.verifyOrderStatus(orderObject).then(async function (status) {
				if (status == 'Completed') {
					if(browser.params.defaultCurrency == "USD"){
						//Validate pricing on order history page
						ordersHistoryPage.open();
						ordersHistoryPage.searchOrderById(orderObject.orderNumber);
						expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(cloudStorageTemplate.EstimatedPrice);
					}
					if (isDummyAdapterDisabled == "true") {
						inventoryPage.open();
						//Validate service Tags
						inventoryPage.getImiTags(orderObject).then(function (tags) {
							var tagList = tags.split(",");
							var tagMap = inventoryPage.getServiceTags(tagList);
							var mcmpTag = false;
							if (isDummyAdapterDisabled == "true") {
								if (Object.keys(tagMap).includes(messageStrings.systemTagText)) {
									mcmpTag = true;
								}
								expect(mcmpTag).toBe(true);
								//Verify system tags
								inventoryPage.clickLabelsViewDetailsLink();
								expect(inventoryPage.validateSystemTagValueIsDisplayed()).toBe(true);
								expect(inventoryPage.getSystemTagLabel()).toEqual(messageStrings.systemTagText);
							}
							expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderObject.orderNumber);
							expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
							expect(tagMap["serviceofferingname"]).toEqual(cloudStorageTemplate.serviceOffrngName);

						});
					}
					orderFlowUtil.closeHorizontalSliderIfPresent();

				}
			});
		});

		it("Cloud storage - Edit and Delete Service", async function () {			
			//Edit service flow					
			var modifiedParamMap = { "Service Instance Name": "", "EditService": true, "Storage class": "Nearline (Best for backups and data accessed less than " };
			serviceName = orderObject.servicename;
			orderFlowUtil.editService(orderObject);
			orderFlowUtil.fillOrderDetails(cloudStorageTemplate, modifiedParamMap).then(function (reviewOrderExpActParamsMap) {
				browser.sleep(5000);
				//Validate Review order page parameters
				expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
			});
			if (browser.params.defaultCurrency == "USD") {
				// Checking cost of BOM on Updated BOM tab (review Order Page)					
				expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(cloudStorageTemplate.TotalCostAfterEdit);
			}
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(cloudStorageTemplate.bluePrintName, "Edit");
			//orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();              
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');

			placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
			if (browser.params.defaultCurrency == "USD") {
				ordersPage.open();
				ordersPage.clickAllOrdersUnderOrdersSection();
				ordersPage.searchOrderById(orderObject.orderNumber);
				ordersPage.clickFirstViewDetailsOrdersTable();
				ordersPage.clickBillOfMaterialsTabOrderDetails();

				// Checking cost of BOM on Updated BOM tab (Orders Page)
				totalCostUpdated = placeOrderPage.getTextUpdatedBOMTablePrice(2);
				expect(cloudStorageTemplate.TotalCostAfterEdit).toContain(totalCostUpdated);

				// Checking cost of BOM on Current BOM tab(Orders Page)
				totalCostBOM = placeOrderPage.getTextCurrentBOMTablePrice(0);
				expect(cloudStorageTemplate.TotalCost).toContain(totalCostBOM);
				ordersPage.clickServiceDetailSliderCloseButton();
			}

			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
				if (status == 'Completed') {
					//Verify updated details are reflected on order details apge.						
					ordersPage.clickFirstViewDetailsOrdersTable();
					expect(ordersPage.getTextBasedOnLabelName("Storage class")).toContain(modifiedParamMap["Storage class"]);
					ordersPage.clickServiceDetailSliderCloseButton();
					if (browser.params.defaultCurrency == "USD") {
						inventoryPage.open();
						inventoryPage.searchOrderByServiceName(orderObject.servicename);
						element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
						inventoryPage.clickViewService();
						// Checking cost of BOM (Inventory Page Page)
						inventoryPage.clickBOMButton();
						totalCostUpdated = placeOrderPage.getBOMTablePrice();
						expect(cloudStorageTemplate.TotalCostAfterEdit).toContain(totalCostUpdated);
						inventoryPage.closeViewComponent();

						ordersHistoryPage.open();
						ordersHistoryPage.searchOrderById(orderObject.orderNumber);
						ordersHistoryPage.clickServiceDetailsLink();
						ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();

						// Checking cost of BOM on Updated BOM tab(order History Page)
						totalCostUpdated = placeOrderPage.getTextUpdatedBOMTablePrice(2);
						expect(cloudStorageTemplate.TotalCostAfterEdit).toContain(totalCostUpdated);

						// Checking cost of BOM on Current BOM tab(order History Page)
						totalCostBOM = placeOrderPage.getTextCurrentBOMTablePrice(0);
						expect(cloudStorageTemplate.TotalCost).toContain(totalCostBOM);
						ordersHistoryPage.closeServiceDetailsSlider();
					}
					if (isDummyAdapterDisabled == "true") {
						inventoryPage.open();
						//Validate service Tags
						inventoryPage.getImiTags(orderObject).then(function (tags) {
							var tagList = tags.split(",");
							var tagMap = inventoryPage.getServiceTags(tagList);
							var mcmpTag = false;
							if (isDummyAdapterDisabled == "true") {
								if (Object.keys(tagMap).includes(messageStrings.systemTagText)) {
									mcmpTag = true;
								}
								expect(mcmpTag).toBe(true);
								//Verify system tags
								inventoryPage.clickLabelsViewDetailsLink();
								expect(inventoryPage.validateSystemTagValueIsDisplayed()).toBe(true);
								expect(inventoryPage.getSystemTagLabel()).toEqual(messageStrings.systemTagText);
							}
							expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderObject.orderNumber);
							expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
							expect(tagMap["serviceofferingname"]).toEqual(cloudStorageTemplate.serviceOffrngName);
							orderFlowUtil.closeHorizontalSliderIfPresent();
						});
					}

					//Delete Service flow
					//orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
					orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, cloudStorageTemplate.bluePrintName);
					expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
					orderFlowUtil.approveDeletedOrder(orderObject);
					orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
					expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
				}
			});
		})
	}
});
