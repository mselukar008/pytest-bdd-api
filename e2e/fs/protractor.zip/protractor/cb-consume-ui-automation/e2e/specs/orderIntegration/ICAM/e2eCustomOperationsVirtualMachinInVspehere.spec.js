/*
2	
Spec_Name:e2eCustomOperationsVirtualMachineInVsphere.spec.js.spec.js
3	
Description: It covers custom operations for vssphere icam service like start,stop,shutdown.
4	
Author: Sarika Bothe
5	
//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.
*/



"use strict";

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    Orders = require('../../../pageObjects/orders.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    vSphereVmTemplate = require('../../../../testData/OrderIntegration/ICAM/vSphereVirtualMachine.json'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js')




describe('E2E Test cases for Custom operations of ICAM-ON Vsphere Virtual Machine service', function () {
    var catalogPage, placeOrderPage, ordersPage, serviceName, vmName, inventoryPage, orderHistoryPage;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: vSphereVmTemplate.providerName,
        orderSubmittedConfirmationMessage: vSphereVmTemplate.orderSubmittedConfirmationMessage,
        category: vSphereVmTemplate.category,
        estimatedPrice: vSphereVmTemplate.estimatedPrice,
        providerAccount: vSphereVmTemplate.providerAccount,
        completedState: vSphereVmTemplate.completedState,
        approvalState: vSphereVmTemplate.approvalState,
        orderTypeDel: vSphereVmTemplate.orderTypeDel,
        urlOrders: vSphereVmTemplate.urlOrders,
        estimatedCost: vSphereVmTemplate.estimatedCost,
        MessageForStartOnStart			  : vSphereVmTemplate.MessageForStartOnStart,
        MessageForStopOnStop			  : vSphereVmTemplate.MessageForStopOnStop

};

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        orderHistoryPage = new OrderHistoryPage();
        inventoryPage = new InventoryPage();

        serviceName = vSphereVmTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
        vmName = vSphereVmTemplate.virtualMachineNamePrefix + "-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Virtual machine name": vmName };
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);

    });

    it('ICAM : ICAM-ON Virtual machine in vsphere ---- 1 Verify fields on Main Parameters page', function () {
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
        catalogPage.searchForBluePrint(vSphereVmTemplate.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(vSphereVmTemplate.bluePrintName);
        expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
        placeOrderPage.setServiceNameTextICAM(vSphereVmTemplate.serviceNamePrefix + "-" + util.getRandomString(4));
        placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
        expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
        //  expect(placeOrderPage.getTextEstimatedPrice()).toBe(vSphereVmTemplate.EstimatedPrice);
    });


    it('ICAM : ICAM-ON Virtual machine in Azure ---- 2 Verify Summary details and Additional Details,pricing values are listed in review Order page', function () {

        catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
        catalogPage.searchForBluePrint(vSphereVmTemplate.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(vSphereVmTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetailsICAM(vSphereVmTemplate, modifiedParamMap).then(function (requiredReturnMap) {
          //  var priceInReviewOrder = placeOrderPage.getEstimatedPrice_ReviewOrder();
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            var orderId = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
           // var priceInSubmitOrderPopup = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
           // expect(priceInSubmitOrderPopup).toEqual(priceInReviewOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            orderHistoryPage.open();
            orderHistoryPage.searchOrderById(orderId);
            //No more support on UI
            // var priceInOrderHistory = orderHistoryPage.getTextEstimatedCostOrderHistory();
            // expect(priceInOrderHistory).toEqual(priceInSubmitOrderPopup);
            orderHistoryPage.clickServiceDetailsLink();
            orderHistoryPage.clickBillOfMaterialsTabInServiceDetails();
           // expect(orderHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);
            orderHistoryPage.closeServiceDetailsSlider();
            orderHistoryPage.clickBillOfMaterials();
          //  expect(orderHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);
            ordersPage.open();
            expect(util.getCurrentURL()).toMatch(messageStrings.urlOrders);
            ordersPage.searchOrderById(orderId);

            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderId);
            //No more support on UI
            // var priceInApproveOrders = ordersPage.getTextFirstAmountOrdersTable();
            // expect(priceInApproveOrders).toEqual(priceInSubmitOrderPopup);
            var orderAmount = ordersPage.getTextFirstAmountOrdersTable();

            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual(messageStrings.approvalState);

            expect(ordersPage.getTextSubmittedByOrderDetails()).toContain(catalogPage.extractUserFirstName());
            expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            expect(ordersPage.isDisplayedDenyButtonOrderDetails()).toEqual(true);
            ordersPage.clickServiceConfigurationsTabOrderDetails();
            expect(ordersPage.getTextBasedOnLabelName("Instance Plan")).toEqual((requiredReturnMap["Expected"]["Instance Plan"]));

            ordersPage.clickBillOfMaterialsTabOrderDetails();
          //  expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);


        });
    });


    if (isProvisioningRequired == "true") {

        it('ICAM-ON Vsphere Virtual Machine 3- Provision vsphere service and place order from catlog page ', function () {

            var orderObject = {};

            catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
            catalogPage.searchForBluePrint(vSphereVmTemplate.bluePrintName);
            catalogPage.clickConfigureButtonBasedOnName(vSphereVmTemplate.bluePrintName);
            expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
            orderObject.serviceName = serviceName;
            orderFlowUtil.fillOrderDetailsICAM(vSphereVmTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();

            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
          //  orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState, 50);

        });

        //--------------------------------StartOnStart
        it('ICAM-ON Vsphere Virtual Machine- Verify for Start Virtual machine, when VM is turned ON, Validation should come up', function () {
            catalogPage.open();
            var orderObject = {};
            var returnObj = {
                servicename: serviceName
            };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
                    inventoryPage.clickTurnONButtonOfInstanceNegativeIcam()
                        expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.MessageForStartOnStart);
                        util.waitForAngular();
           
                });
            })
        });

        it('ICAM-ON Vsphere Virtual Machine 2 - Verify for Stop Virtual machine, when VM is turned OFF, status should get changed from ON to OFF', function () {

            var orderObject = {};
            orderObject.serviceName = serviceName;
            var returnObj = { servicename: serviceName };

            inventoryPage.open();

            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
                    inventoryPage.clickTurnOFFButtonOfInstanceIcam()
                        inventoryPage.clickOkForInstanceTurnOFFPermission();
                        util.waitForAngular();

                });
            }).then(function () {
                var orderObject = JSON.parse(JSON.stringify(vSphereVmTemplate));

                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(returnObj.servicename);

            });



        });


        //--------------------------------StopOnStop
        it('ICAM-ON Vsphere Virtual Machine- Verify for Stop Virtual machine, when VM is turned OFF already, Validation should come up', function () {
            var orderObject = {};
            orderObject.serviceName = serviceName;
            var returnObj = {
                servicename: serviceName
            };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
                    inventoryPage.clickTurnOFFButtonOfInstanceIcam()
                        expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.MessageForStopOnStop);
                        util.waitForAngular();

                });
            })
        });

        it('ICAM-ON Vsphere Virtual Machine 3 - Verify for Start Virtual machine, when VM is turned ON, status should get changed from OFF to ON', function () {


            catalogPage.open();
            var orderObject = {};
            var returnObj = { servicename: serviceName };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
                    inventoryPage.clickTurnONButtonOfInstanceNegativeIcam()
                        inventoryPage.clickOkForInstanceTurnOFFPermission();

                        util.waitForAngular();

                });
            }).then(function () {
                var orderObject = JSON.parse(JSON.stringify(vSphereVmTemplate));

                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);

            });

        });

        //taint operation
        it('ICAM-ON Vsphere Virtual Machine 3 - Verify for Start Virtual machine, taint operation is working fine or not', function () {
            catalogPage.open();
            var orderObject = {};
            var returnObj = { servicename: serviceName };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
                    inventoryPage.clickTaintONButtonOfInstanceIcam()
                        inventoryPage.clickOkForInstanceTurnOFFPermission();
                        util.waitForAngular();                 
                });
            }).then(function () {
                var orderObject = JSON.parse(JSON.stringify(vSphereVmTemplate));

                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);

            });

        });
        //untaint operation
        it('ICAM-ON Vsphere Virtual Machine 3 - Verify for Start Virtual machine, untaint operation is working fine or not', function () {
            catalogPage.open();
            var orderObject = {};
            var returnObj = { servicename: serviceName };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
                    inventoryPage.clickUntaintONButtonOfInstanceIcam()
                        inventoryPage.clickOkForInstanceTurnOFFPermission();
                        util.waitForAngular();
                });
            }).then(function () {
                var orderObject = JSON.parse(JSON.stringify(vSphereVmTemplate));

                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);

            });

        });

        it('ICAM-ON Vsphere Virtual Machine 4 - Verify for Shutdown Virtual machine, when VM is turned ON, status should get changed from ON to OFF', function () {


            catalogPage.open();
            var orderObject = {};
            var returnObj = { servicename: serviceName };


            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
                    inventoryPage.icamClickShutdownButtonOfInstance()
                        inventoryPage.clickOkForInstanceTurnOFFPermission();
                        util.waitForAngular();
                    });

            }).then(function () {
                var orderObject = JSON.parse(JSON.stringify(vSphereVmTemplate));

                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(returnObj.servicename);



            });


        });

        it('ICAM-ON Vsphere Virtual Machine 4 -- Verify delete services', function () {

            var orderObject = {} ;
            orderObject.serviceName = serviceName;

            var returnObj = { servicename:serviceName};
            orderObject.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
            expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState)
        });







    }







});  
