"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    auroraDbTemplate = require('../../../../testData/OrderIntegration/AWS/auroraDb.json');

describe('AWS - RDS-AuroraDb', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, dbInstance, serviceName, myrdsObj, inventoryPage;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = auroraDbTemplate.componentType;
    var messageStrings = {
        providerName: auroraDbTemplate.provider,
        category: auroraDbTemplate.Category,
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        systemTagText: "ibm_mcmp_soiid"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-aurora-" + util.getRandomString(5);
        dbInstance = "auroralDbIn" + util.getRandomString(5);
        dbInstance = dbInstance.toLowerCase();
        myrdsObj = JSON.parse(JSON.stringify(auroraDbTemplate));
    });

    it('AWS-Aurora - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        modifiedParamMap = { "Service Instance Name": serviceName, "DB instance identifier": dbInstance };
        catalogPage.open();
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(auroraDbTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(auroraDbTemplate.bluePrintName);
        
        //Fill Order Details
        orderFlowUtil.fillOrderDetails(auroraDbTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(auroraDbTemplate.TotalCost);
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);          
            expect(requiredReturnMap["Actual"]["DB engine"]).toEqual(requiredReturnMap["Expected"]["DB engine"]);
            expect(requiredReturnMap["Actual"]["DB engine version"]).toEqual(requiredReturnMap["Expected"]["DB engine version"]);
            expect(requiredReturnMap["Actual"]["DB instance class"]).toEqual(requiredReturnMap["Expected"]["DB instance class"]);
            expect(requiredReturnMap["Actual"]["DB instance identifier"]).toEqual(dbInstance);
            expect(requiredReturnMap["Actual"]["Master username"]).toEqual(requiredReturnMap["Expected"]["Master username"]);
            expect(requiredReturnMap["Actual"]["Database name"]).toEqual(requiredReturnMap["Expected"]["Database name"]);
            expect(requiredReturnMap["Actual"]["Database port"]).toEqual(requiredReturnMap["Expected"]["Database port"]);
            expect(requiredReturnMap["Actual"]["DB cluster parameter group"]).toEqual(requiredReturnMap["Expected"]["DB cluster parameter group"]);
            expect(requiredReturnMap["Actual"]["Backup retention period"]).toEqual(requiredReturnMap["Expected"]["Backup retention period"]);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 5000);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(auroraDbTemplate.EstimatedPrice);
                //Validate pricing on order history page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(auroraDbTemplate.EstimatedPrice);
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(myrdsObj, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("DB engine")).toEqual(jsonUtil.getValue(myrdsObj, "DB engine"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(myrdsObj, "DB engine version"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(myrdsObj, "DB instance class"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB instance identifier")).toEqual(dbInstance);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Master username")).toEqual(jsonUtil.getValue(myrdsObj, "Master username"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Database name")).toEqual(jsonUtil.getValue(myrdsObj, "Database name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Database port")).toEqual(jsonUtil.getValue(myrdsObj, "Database port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("DB cluster parameter group")).toEqual(jsonUtil.getValue(myrdsObj, "DB cluster parameter group"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValue(myrdsObj, "Backup retention period"));

            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(auroraDbTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(auroraDbTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.clickAllOrdersUnderOrdersSection();
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(myrdsObj, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("DB engine")).toEqual(jsonUtil.getValue(myrdsObj, "DB engine"));
            expect(ordersPage.getTextBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(myrdsObj, "DB engine version"));
            expect(ordersPage.getTextBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(myrdsObj, "DB instance class"));
            expect(ordersPage.getTextBasedOnLabelName("DB instance identifier")).toEqual(dbInstance);
            expect(ordersPage.getTextBasedOnLabelName("Master username")).toEqual(jsonUtil.getValue(myrdsObj, "Master username"));
            expect(ordersPage.getTextBasedOnLabelName("Database name")).toEqual(jsonUtil.getValue(myrdsObj, "Database name"));
            expect(ordersPage.getTextBasedOnLabelName("DB cluster parameter group")).toEqual(jsonUtil.getValue(myrdsObj, "DB cluster parameter group"));
            expect(ordersPage.getTextBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValue(myrdsObj, "Backup retention period"));

            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(auroraDbTemplate.TotalCost);
            ordersPage.clickServiceDetailSliderCloseButton();
        });
    });

    it('AWS-AuroraDb - Validate system tags, Edit and Delete Service', function () {
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            if (isDummyAdapterDisabled == "true") {
                orderObject.componentType = auroraDbTemplate.componentType1;
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(auroraDbTemplate.componentType1).then(function (index) {
                    inventoryPage.clickViewComponentBasedOnIndex(index - 1).then(function () {
                        //View Component VM details
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(auroraDbTemplate.componentType1);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Resource Id")).toEqual(auroraDbTemplate.resourceId);
                        //View Component Template Output Properties
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AvailabilityZone")).toEqual(auroraDbTemplate.availablilityZone);
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("EngineVersion")).toEqual(jsonUtil.getValue(myrdsObj, "DB engine version"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DBInstanceClass")).toEqual(jsonUtil.getValue(myrdsObj, "DB instance class"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AllocatedStorage")).toEqual(jsonUtil.getValue(myrdsObj, "Allocated storage"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DBInstanceIdentifier")).toEqual(dbInstance.toLowerCase());
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("MasterUsername")).toEqual(jsonUtil.getValue(myrdsObj, "Master username"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DbInstancePort")).toEqual(jsonUtil.getValue(myrdsObj, "Database port"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("BackupRetentionPeriod")).toEqual(jsonUtil.getValue(myrdsObj, "Backup retention period"));
                    });
                    inventoryPage.getTagsOnInventory().then(function (tags) {
                        var tagList = tags.split(",");
                        var tagMap = inventoryPage.getServiceTags(tagList);
                        var mcmpTag = false;
                        //verifying a system tag
                        expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                        //verifying some of the service tags             
                        expect(tagList.includes(tagList.find(tag => tag.includes("StackId:arn:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:logical-id:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-id:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-name")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("ibm_mcmp_soiid:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("orderNumber")))).toBe(true);
                        orderFlowUtil.closeHorizontalSliderIfPresent();
                    });

                });
            } else {
                inventoryPage.clickOverflowActionButtonForPowerStates();
                inventoryPage.clickViewComponentofAWSInstance();
                inventoryPage.getTagsOnInventory().then(function (tags) {
                    var tagList = tags.split(",");
                    var tagMap = inventoryPage.getServiceTags(tagList);
                    //verifying flags for dummy adapter
                    expect(tagMap["IsUsingDummy"]).toEqual("Yes");
                    expect(tagMap["Name"]).toEqual(auroraDbTemplate.bluePrintName);
                    expect(tagMap["PhysicalId"]).toContain(orderObject.servicename);
                    expect(Object.keys(tagMap).includes("Test")).toBe(true);
                    expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                });
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AWS Region")).toEqual(jsonUtil.getValue(myrdsObj, "AWS Region"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB engine")).toEqual(jsonUtil.getValue(myrdsObj, "DB engine"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB engine version")).toEqual(jsonUtil.getValue(myrdsObj, "DB engine version"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB instance class")).toEqual(jsonUtil.getValue(myrdsObj, "DB instance class"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DB instance identifier")).toEqual(dbInstance);
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Master username")).toEqual(jsonUtil.getValue(myrdsObj, "Master username"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Database name")).toEqual(jsonUtil.getValue(myrdsObj, "Database name"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Database port")).toEqual(jsonUtil.getValue(myrdsObj, "Database port"));
                expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Backup retention period")).toEqual(jsonUtil.getValue(myrdsObj, "Backup retention period"));
                
            }
            orderFlowUtil.closeHorizontalSliderIfPresent();
        });

        //Edit service flow
        var dbInstanceEdit = "auroraDbnew" + util.getRandomString(3);
        var modifiedParamMapEdit = { "EditService": true, "DB instance identifier": dbInstanceEdit };
        orderFlowUtil.editService(orderObject);
        orderFlowUtil.fillOrderDetails(auroraDbTemplate, modifiedParamMapEdit).then(function (reviewOrderExpActParamsMap) {
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(auroraDbTemplate.TotalCostPostEdit);
            browser.sleep(5000);
            //Validate Review order page parameters
            //Delete password key as its encrypted on UI.
            delete reviewOrderExpActParamsMap["Actual"]["Master password"];
            delete reviewOrderExpActParamsMap["Expected"]["Master password"];
            expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
        });
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 5000);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == 'Completed') {
                //Verify updated details are reflected on order details page.						
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelName("DB instance identifier")).toEqual(dbInstanceEdit);               
                expect(ordersPage.getTextBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValueEditParameter(myrdsObj, "DB instance class"));
                expect(ordersPage.getTextBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValueEditParameter(myrdsObj, "Backup retention period"));

                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(auroraDbTemplate.TotalCostPostEdit);
                ordersPage.clickServiceDetailSliderCloseButton();
                //Delete Service flow                    
                orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 5000);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            }
        });
    });
});
