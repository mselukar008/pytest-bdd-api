/*
Spec_Name: e2ecp4mcmLaunchpadTerraformLink.spec.js
Description:Link and Launchpad page link, left side Navigation menus verification for TA provider.
This covers verification of cp4mcm links ,open linka nd verify its navigate to right URL.
Author: Sarika Bothe
*/

"use strict";

//const catalog = require('../../../pageObjects/catalog.pageObject.js');

var CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    AccountsPage = require('../../../pageObjects/account.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    mcmpUIDataTemplate = require('../../../../testData/OrderIntegration/ICAM/terraformLaunchpadMcmpUIData.json');
var EC = protractor.ExpectedConditions;


describe('TA - E2E Test cases for launchpad links and left navigation links for Terraform Automation ', function () {
    var catalogPage, homePage, accountsPage;

    beforeAll(function () {
        catalogPage = new CatalogPage();
        homePage = new HomePage();
        accountsPage = new AccountsPage();
        browser.driver.manage().window().maximize();
        homePage.open();
        catalogPage.clickHamburgerCatalog();
        catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonAdmin);
        catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
        catalogPage.clickHamburgerCatalog();
    });

    beforeEach(function () {
        browser.switchTo().defaultContent();
        catalogPage.clickHamburgerCatalog();

    });

    it('TA: Verify clicking on hamburger button should open left navigation bar', function () {
        expect(catalogPage.checkLeftNavBarOpened()).toContain(mcmpUIDataTemplate.leftNavBarClass);
        catalogPage.clickHamburgerCatalog();
    });

    it('TA:Verify clicking on pin button should keep the left navigation bar open', function () {
        catalogPage.clickPinLeftNavBar();
        expect(catalogPage.checkLeftNavBarOpened()).toContain(mcmpUIDataTemplate.leftNavBarPinnedClass);
        catalogPage.clickHamburgerCatalog();
    });

    it('TA:Verify clicking on arrow button should close the left navigation bar', function () {
        catalogPage.clickPinLeftNavBar();
        catalogPage.clickArrowLeftNavBar();
        expect(catalogPage.checkLeftNavBarOpened()).toContain(mcmpUIDataTemplate.leftNavBarArrowClass);
    });

    it('TA:Verify clicking on Portal link navigates to launchpad', function () {
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkPortal);
        expect(util.getCurrentURL()).toMatch(appUrls.launchpadUrl);
        expect(homePage.getTextHeaderUser()).toContain(mcmpUIDataTemplate.launchpadHeader);
    });

    it('TA:Verify clicking on User Access link navigates to admin page', function () {
        catalogPage.checkIfleftNavAdminExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkUserAccess);
        expect(util.getCurrentURL()).toMatch(appUrls.adminUrl);
        expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.userAccessPageHeader);
    });

    it('TA:Verify clicking on Context Type link navigates to contexttypes page', function () {
        catalogPage.checkIfleftNavAdminExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkContexttype);
        expect(util.getCurrentURL()).toMatch(appUrls.adminUrl);
        expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.leftNavLinkContexttype);
    });

    it('TA:Verify clicking on Provider Account link navigates to accounts page', function () {
        catalogPage.checkIfleftNavAdminExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkProviderAccount);
        expect(util.getCurrentURL()).toMatch(appUrls.accountsUrl);
        expect(accountsPage.getTextPageHeader()).toBe(mcmpUIDataTemplate.accountsPageHeader);
    });

    it('TA:Verify clicking on Approve Orders link navigates to approver page', function () {
        catalogPage.checkIfleftNavStoreExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkApproveOrders);
        expect(util.getCurrentURL()).toMatch(appUrls.approveOrdersUrl);
        homePage.switchToFrame();
        expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.ordersPageHeader);
    });

    it('TA:Verify clicking on Order History link navigates to my-orders page', function () {
        catalogPage.checkIfleftNavStoreExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkOrderHistory);
        homePage.switchToFrame();
        expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.orderHistoryPageHeader);
    });

    it('TA:Verify clicking on Catalog link navigates to main page', function () {
        catalogPage.checkIfleftNavStoreExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkCatalog);
        homePage.switchToFrame();
        expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.catalogPageHeader);
    });

    it('TA:Verify clicking on Inventory link navigates to inventory page', function () {
        catalogPage.checkIfleftNavStoreExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkInventory);
        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
        homePage.switchToFrame();
        expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.inventoryPageHeader);
    });

    it('TA:Verify clicking on Catalog Admin link navigates to catalogAdmin page', function () {
        catalogPage.checkIfleftNavStoreExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkCatalogAdmin);
        expect(util.getCurrentURL()).toMatch(appUrls.catalogAdminUrl);
        homePage.switchToFrame();
        expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.catalogAdminPageHeader);
    });

    it('TA:Verify clicking on Policy Approvals link navigates to policies page', function () {
        catalogPage.checkIfleftNavStoreExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkPolicyApprovals);
        expect(util.getCurrentURL()).toMatch(appUrls.policyApprovalUrl);
        homePage.switchToFrame();
        expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.approvalPolicyPageHeader);
    });

    //verified and tested

    it('TA:Verify clicking on Portal Settings link navigates to settings page', function () {
        catalogPage.checkIfleftNavAdminExpanded();
        catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonSettings);
        catalogPage.checkIfleftNavSettingsExpanded();
        catalogPage.clickLeftNavAdminPortalLink();
        expect(util.getCurrentURL()).toMatch(appUrls.settingsUrl);
        expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.portalSettingsPageHeader);
    });

    it('TA:Verify clicking on Manage service Liberary link navigates to sso sign in page ', function () {
        catalogPage.checkIfleftTerraformAutomaitonExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkManageServiceLib).then(function () {
            expect(util.getCurrentURL()).toMatch(appUrls.terraformManageServiceLibURL);
        })

    });

    it('TA:Verify clicking on Deployed Instances link Navigates to sso sign in page', function () {
        catalogPage.checkIfleftTerraformAutomaitonExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkDeployedInstance).then(function () {
            expect(util.getCurrentURL()).toMatch(appUrls.terraformDeployedInstaceURL);
        })

    });

    it('TA:Verify clicking on Manage Terraform Automation link Navigates to sso sign in page', function () {
        catalogPage.checkIfleftTerraformAutomaitonExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkManageTerraformAutomation).then(function () {
            expect(util.getCurrentURL()).toMatch(appUrls.terraformManageTAAutomationURL);
        })

    });

    it('TA:Verify clicking on Portal link navigates to launchpad', function () {
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkPortal);
        expect(util.getCurrentURL()).toMatch(appUrls.launchpadUrl);
        expect(homePage.getTextHeaderUser()).toContain(mcmpUIDataTemplate.launchpadHeader);
    });

    it('TA:Clicking Enterprise Marketplace link navigates to Enterprise Marketplace page', function () {
        util.waitForAngular();
        homePage.clickStoreLink();
    });

    it('TA:Verify clicking on Portal link navigates to launchpad', function () {
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkPortal);
        expect(util.getCurrentURL()).toMatch(appUrls.launchpadUrl);
        expect(homePage.getTextHeaderUser()).toContain(mcmpUIDataTemplate.launchpadHeader);
    });

    it('TA:Verify clicking on Manage Applications link navigates to sign in page', function () {
        homePage.clickLaunchpadLink(mcmpUIDataTemplate.leftNavLinkManageApplications);
        expect(util.getCurrentURL()).toMatch(appUrls.terraformManageApplicationsURL);
    });

    it('TA:Verify clicking on Portal link navigates to launchpad', function () {
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkPortal);
        expect(util.getCurrentURL()).toMatch(appUrls.launchpadUrl);
        expect(homePage.getTextHeaderUser()).toContain(mcmpUIDataTemplate.launchpadHeader);
    });

    it('TA:Verify clicking on Advanced Cluster Manager link navigates to sign in page', function () {
        homePage.clickLaunchpadLink(mcmpUIDataTemplate.leftNavLinkAdvanceClusterManager);
        expect(util.getCurrentURL()).toMatch(appUrls.terraformAdvancedClusterManagerURL);
    });

    it('TA:Verify clicking on Portal link navigates to launchpad', function () {
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkPortal);
        expect(util.getCurrentURL()).toMatch(appUrls.launchpadUrl);
        expect(homePage.getTextHeaderUser()).toContain(mcmpUIDataTemplate.launchpadHeader);
    });

    it('TA:Verify clicking on Security Governance Compliance  link navigates to sign in page', function () {
        homePage.clickLaunchpadLink(mcmpUIDataTemplate.leftNavLinkSecurityGovComplience);
        expect(util.getCurrentURL()).toMatch(appUrls.terraformSecurityGovernanceComplianceURL);
    });

    it('TA:Verify clicking on Portal link navigates to launchpad', function () {
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkPortal);
        expect(util.getCurrentURL()).toMatch(appUrls.launchpadUrl);
        expect(homePage.getTextHeaderUser()).toContain(mcmpUIDataTemplate.launchpadHeader);
    });
    it('TA:Verify clicking on Identity and access navigates to new tab open sign in page.. ', function () {
        catalogPage.checkIfleftCloudpakAdministrationExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkIdentityAccess).then(function () {
            catalogPage.navigateToNewTab().then(function (parentGUID) {
                expect(util.getCurrentURL()).toMatch(appUrls.identityAccessAndMeeteringURL);
                expect(homePage.verifyCloudPakHeaderlIsVisible()).toBe(mcmpUIDataTemplate.terraformcloudPakSignInHeader);
                expect(homePage.verifyAuthenticationSamlIsVisible()).toBe(mcmpUIDataTemplate.terraformAuthenticationSamlLink);
                expect(homePage.VerifyAuthenticationDefaultIsVisible()).toBe(mcmpUIDataTemplate.terraformAuthenticationDefaultLink);
                catalogPage.closeCurrentTabNavigateToParentTab(parentGUID);

            });
        })

    });
    it('TA:Verify clicking on Metering navigates to new tab open sign in page.. ', function () {
        catalogPage.checkIfleftCloudpakAdministrationExpanded();
        catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkMetering).then(function () {
            catalogPage.navigateToNewTab().then(function (parentGUID) {
                expect(util.getCurrentURL()).toMatch(appUrls.identityAccessAndMeeteringURL);
                expect(homePage.verifyCloudPakHeaderlIsVisible()).toBe(mcmpUIDataTemplate.terraformcloudPakSignInHeader);
                expect(homePage.verifyAuthenticationSamlIsVisible()).toBe(mcmpUIDataTemplate.terraformAuthenticationSamlLink);
                expect(homePage.VerifyAuthenticationDefaultIsVisible()).toBe(mcmpUIDataTemplate.terraformAuthenticationDefaultLink);
                catalogPage.closeCurrentTabNavigateToParentTab(parentGUID);
            });
        })

    });
});