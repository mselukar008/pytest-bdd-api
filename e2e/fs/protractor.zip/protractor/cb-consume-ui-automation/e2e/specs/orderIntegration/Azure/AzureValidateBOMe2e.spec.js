/************************************************
        AUTHOR: Atiksha Batra
BOM validation in submit order,Review Order,order history and inventory page before
and after editing the Service(current and Updated)

************************************************/
"use strict";

const { browser } = require('protractor');

var Orders = require('../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        appUrls = require('../../../../testData/appUrls.json'),
        util = require('../../../../helpers/util.js'),
        jsonUtil = require('../../../../helpers/jsonUtil.js'),
        OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        EC = protractor.ExpectedConditions,
        NHTemplate = require('../../../../testData/OrderIntegration/Azure/nh.json')

describe('Azure - Checking bill of materials', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, orderHistoryPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Other Services' };
        var modifiedParamMapedit = {};
        var servicename = "AutoNHsrv" + util.getRandomString(5);
        var totalCostBOM, totalCostUpdated, SOIComponents;

        var orderObject = JSON.parse(JSON.stringify(NHTemplate));
        var returnObj = {};
        var returnObj1 = {};
        returnObj.servicename = servicename;

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                orderHistoryPage = new OrderHistoryPage();
                //browser.driver.manage().window().maximize();
        });

        beforeEach(function () {

                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        });

        afterAll(function () {
                // Delete Notification Hub
                var returnObj = {};
                returnObj.servicename = servicename;
                returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                orderFlowUtil.approveDeletedOrder(returnObj);
                orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        });

        //E2E for Validating BOM before and after editing for Notification Hub.
        if (isProvisioningRequired == "true") {
                it('Azure: TC-01-Verify BOM for Notification Hub Service,if service is created with new resource group with valid name and location,create valid Notification Hub name enter valid Namespace Name, Pricing Tier', async function () {

                        catalogPage.clickProviderOrCategoryCheckbox(orderObject.Category);
                        catalogPage.searchForBluePrint(orderObject.bluePrintName);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};

                        var rgName = "gslautotc_azure_nhRG" + util.getRandomString(5);
                        var nsName = "autoNS" + util.getRandomString(5);
                        var nhName = "autoNH" + util.getRandomString(5);
                        SOIComponents = [nhName, nsName]
                        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Notification Hub Name": nhName, "New Namespace Name": nsName};

                        orderFlowUtil.fillOrderDetails(NHTemplate, modifiedParamMap);

                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;

                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');

                        ordersPage.open();
                        ordersPage.clickAllOrdersUnderOrdersSection();
                        ordersPage.searchOrderById(returnObj.orderNumber);

                        //BOM check On View Order Details

                        ordersPage.clickFirstViewDetailsOrdersTable();
                        ordersPage.clickBillOfMaterialsTabOrderDetails();

                        totalCostBOM = await placeOrderPage.getBOMTablePrice();
                        if(browser.params.defaultCurrency == "USD"){
                                expect(orderObject.TotalCost).toContain(totalCostBOM);
                        }
                        //BOM check On order History Page(View Details)
                        orderHistoryPage.open();
                        orderHistoryPage.searchOrderById(returnObj.orderNumber);
                        orderHistoryPage.clickServiceDetailsLink();
                        orderHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                        totalCostBOM = await placeOrderPage.getBOMTablePrice();
                        if(browser.params.defaultCurrency == "USD"){
                                expect(orderObject.TotalCost).toContain(totalCostBOM);
                        }

                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);

                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();

                        //BOM check On Inventory View Order Details
                        inventoryPage.clickBOMButton();

                        totalCostBOM = await placeOrderPage.getBOMTablePrice();
                        if(browser.params.defaultCurrency == "USD"){
                                expect(orderObject.TotalCost).toContain(totalCostBOM);
                        }


                });

                /*E2E for Validating BOM after editing service*/
                it('Azure: Notification hub- check Bill of materials after editing service for pricing tier', function () {
                        inventoryPage.open();
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                        inventoryPage.clickEditServiceIcon();
                        modifiedParamMapedit = { "Service Instance Name": servicename, "EditService": true };

                        orderFlowUtil.fillOrderDetails(NHTemplate, modifiedParamMapedit);

                        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toContain(returnObj.servicename);
                        if(browser.params.defaultCurrency == "USD"){
                                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCostAfterEdit);
                        }

                        expect(placeOrderPage.isServiceDetailsPresent()).toBe(true);
                        expect(placeOrderPage.isAdditionalDetailsPresent()).toBe(true);
                        expect(placeOrderPage.getcurrentStepProgressSection()).toMatch('Review Order');
                        expect(placeOrderPage.isMainParameterPresent()).toMatch('Main Parameters');
                        expect(placeOrderPage.isSubmitButtonPresent()).toBe(true);
                        expect(placeOrderPage.isPreviousButtonPresent()).toBe(true);
                        expect(placeOrderPage.getEditableFieldtext()).toMatch('Updated');

                        placeOrderPage.submitOrder();

                        returnObj1.servicename = servicename;
                        returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();

                        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();

                        //Open Order page and Approve Order
                        orderFlowUtil.approveOrder(returnObj1);

                        orderFlowUtil.waitForOrderStatusChange(returnObj1, 'Completed');

                        ordersPage.open();
                        ordersPage.clickAllOrdersUnderOrdersSection();
                        ordersPage.searchOrderById(returnObj1.orderNumber);
                        ordersPage.clickFirstViewDetailsOrdersTable();
                        ordersPage.clickBillOfMaterialsTabOrderDetails().then(async function () {
                                // Checking cost of BOM on Updated BOM tab (Orders Page)
                                totalCostUpdated = placeOrderPage.getTextUpdatedBOMTablePrice(orderObject.noOfComponent);
                                if(browser.params.defaultCurrency == "USD"){
                                        expect(orderObject.TotalCostAfterEdit).toContain(totalCostUpdated);
                                }

                                // Checking cost of BOM on Current BOM tab(Orders Page)
                                totalCostBOM = placeOrderPage.getTextCurrentBOMTablePrice(orderObject.noOfComponent);
                                if(browser.params.defaultCurrency == "USD"){
                                        expect(orderObject.TotalCost).toContain(totalCostBOM);
                                }

                                inventoryPage.open();
                                expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);

                                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                                element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                                inventoryPage.clickViewService();
                                // Checking cost of BOM (Inventory Page Page)

                                inventoryPage.clickBOMButton().then(function () {
                                        totalCostUpdated = placeOrderPage.getBOMTablePrice();
                                        if(browser.params.defaultCurrency == "USD"){
                                                expect(orderObject.TotalCostAfterEdit).toContain(totalCostUpdated);
                                        }
                                })
                                orderHistoryPage.open();
                                orderHistoryPage.searchOrderById(returnObj1.orderNumber);
                                orderHistoryPage.clickServiceDetailsLink();
                                orderHistoryPage.clickBillOfMaterialsTabInServiceDetails().then(function () {
                                        // Checking cost of BOM on Updated BOM tab(order History Page)
                                        totalCostUpdated = placeOrderPage.getTextUpdatedBOMTablePrice(orderObject.noOfComponent);
                                        if(browser.params.defaultCurrency == "USD"){
                                                expect(orderObject.TotalCostAfterEdit).toContain(totalCostUpdated);
                                        }

                                        // Checking cost of BOM on Current BOM tab(order History Page)
                                        totalCostBOM = placeOrderPage.getTextCurrentBOMTablePrice(orderObject.noOfComponent);
                                        if(browser.params.defaultCurrency == "USD"){
                                                expect(orderObject.TotalCost).toContain(totalCostBOM);
                                        }
                                        
                                })
                        })
                });
        }
});