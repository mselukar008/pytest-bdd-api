

"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	alicloudECStemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/AliCloudElasticComputeServiceSnow.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
    
    describe('QS: AliCloud E2E cases for Manual Technical, External Financial and Auto Legal approval with Standard change', function() {
        var ordersPage, catalogPage, placeOrderPage, policyPage, snowPage, sampleOrder1, provOrder, inventoryPage, cartListPage, alicloudECSobj;
        var modifiedParamMap = {};
        var modifiedParamMapPolicy = {};
        var modifiedParamMapAddRule = {};
        var serviceName = "SNOWQSauto"+util.getRandomString(5);
        var policyName = "SNOWQSautoAliCloudPolicy"+util.getRandomString(5);
        var policyRuleName = "SNOWQSautoAliCloudPolicyRule"+util.getRandomString(5);
        var consumeLaunchpadUrl = url + '/launchpad';

        beforeAll(function() {
            snowPage = new SNOWPage();
            ordersPage = new Orders();
            catalogPage = new CatalogPage();
            placeOrderPage = new PlaceOrderPage();
            inventoryPage = new InventoryPage();
            policyPage = new PolicyPage();
            cartListPage = new CartListPage();
            browser.driver.manage().window().maximize();
            
            //Delete policy if exists
    		policyPage.open();
    		util.waitForAngular();
    		policyPage.deletePoliciesIfExist();
    });

    beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
        modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["Alibaba Cloud"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
        "Technical":"Manual Approval","Financial":"External Approval"};
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "Provider Account":"ALICLOUD-SNOW / ALICLOUD-SNOW"};
		alicloudECSobj = JSON.parse(JSON.stringify(alicloudECStemplate));
    });

    afterAll(function() {
		//Delete Approval Policy
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);
		  
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
    });

    it('Set Change Request type to Standard in SNOW', function () {
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
    });
    
    it('Create Approval Policy for AliCloud with Auto Technical, Financial, Legal approval and Normal change', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
        policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
        policyPage.selectExternalApprovalDropdownSNOW();
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
    });


    if(isProvisioningRequired == "true") {	
		it('AliCloud ECS ---- Verify Provision functionality with Manual Technical, External Financial, Auto Legal approval and Standard change', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(alicloudECStemplate.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(alicloudECStemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(alicloudECStemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(alicloudECStemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(alicloudECStemplate.SubmitOrder);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            var orderObject = {"orderNumber":provOrder};

            //Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
			ordersPage.clickCancelButtonOrderApprovalModal();
            
             //Validation in Marketplace after auto approval
             expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.approvalState);
			
            //Validations on SNOW Request page  after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(alicloudECStemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe(""); 
            
            //Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();

            //Validation in Marketplace after approval in SNOW
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			//orderFlowUtil.waitForOrderStatusChange(orderObject,gcpComputeEngineTemplate.provInProgressState);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.provInProgressState);

            //Validations on SNOW Request page after approval in SNOW
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(alicloudECStemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(alicloudECStemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAliCloud);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);

			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDECS);

			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAliCloud);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);

			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");

			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function (sName) {
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Region")).toEqual("me-east-1");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Billing Method")).toEqual("PostPaid");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Zones")).toEqual("me-east-1a");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Type")).toEqual(jsonUtil.getValue(alicloudECSobj,"Operating System Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Instance Type")).toEqual(jsonUtil.getValue(alicloudECSobj,"Instance Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Image")).toContain("freebsd");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Disk Category")).toEqual("cloud_efficiency");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Disk Size")).toEqual(jsonUtil.getValue(alicloudECSobj,"System Disk Size"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Name")).toEqual(jsonUtil.getValue(alicloudECSobj,"VPC Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("CIDR Block VPC")).toEqual(jsonUtil.getValue(alicloudECSobj,"CIDR Block VPC"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vswitch Name")).toEqual(jsonUtil.getValue(alicloudECSobj,"Vswitch Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("CIDR Block Vswitch")).toEqual(jsonUtil.getValue(alicloudECSobj,"CIDR Block Vswitch"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(jsonUtil.getValue(alicloudECSobj, "Security Group Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Elastic Network Interface")).toEqual(jsonUtil.getValue(alicloudECSobj, "Elastic Network Interface"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(alicloudECSobj, "Authentication Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Instance Name")).toEqual(jsonUtil.getValue(alicloudECSobj, "Instance Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("ECS Description")).toEqual(jsonUtil.getValue(alicloudECSobj, "ECS Description"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Release Protection")).toEqual("false");

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS1)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
            expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS2)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
            expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS3)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
            expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS4)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

            expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS1)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAliCloudECSNew1);
            expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS2)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAliCloudECSNew2);
            expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS3)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
            expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS4)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);

			}).then(function(){	

				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
					expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				}
				snowPage.clickUpdateButton();

				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();

				expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInCatalogTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
				expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
				expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				snowPage.clickUpdateButton();

                //Standard change
				snowPage.openRelatedChangeRequest();
				
				//Change Request Short Desc and Desc
                expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
                expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescNewOrder);

                //Order Completion in SNOW
				snowPage.checkIfProvisioningTaskClosed();

                //Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.completedState);

				//Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				
				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				snowPage.getTextCMDBShellCIName();
				expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
				snowPage.getTextCMDBShellCIAssignmentGroup();
				expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
				expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
				expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.alicloudProviderAccountID);
				expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.alicloudProviderAccount);
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();	

				//Change Task Page Validations 
				snowPage.openRelatedChangeRequest();
				snowPage.clickProvTaskLink();
				expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
				expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
				expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
				expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
				expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
				snowPage.clickClosureInfoInChangeTask();
				expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
				snowPage.clickBackButton();

				//Validation on Catalog Task page after completion
				snowPage.clickBackButton();
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				});
		});
		
		it('AliCloud ECS ---- Verify Edit functionality with Manual Technical, External Financial, Auto Legal approval and Standard change', function () {
			
			//Place Order for Edit in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			var modifiedParamMap = {"EditService": true };
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.editService(orderObject);
			orderFlowUtil.fillOrderDetails(alicloudECStemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(alicloudECStemplate.SubmitOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            //Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
			ordersPage.clickCancelButtonOrderApprovalModal();
            
             //Validation in Marketplace after auto approval
			 expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.approvalState);
			 expect(orderFlowUtil.verifyOrderType(orderObject)).toBe(alicloudECStemplate.orderTypeEdit);

            //Validations on SNOW Request page  after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(alicloudECStemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestEdit);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
            
            //Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();

            //Validation in Marketplace after approval in SNOW
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			//orderFlowUtil.waitForOrderStatusChange(orderObject,gcpComputeEngineTemplate.provInProgressState);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.provInProgressState);

            //Validations on SNOW Request page after approval in SNOW
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(alicloudECStemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestEdit);
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(alicloudECStemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAliCloud);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);

			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDECS);

			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAliCloud);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);

			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");

			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function (sName) {
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Region")).toEqual("me-east-1");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Billing Method")).toEqual("PostPaid");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Zones")).toEqual("me-east-1a");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Type")).toEqual(jsonUtil.getValue(alicloudECSobj,"Operating System Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Instance Type")).toEqual(jsonUtil.getValue(alicloudECSobj,"Instance Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Image")).toContain("freebsd");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Disk Category")).toEqual("cloud_efficiency");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Disk Size")).toEqual(jsonUtil.getValueEditParameter(alicloudECSobj,"System Disk Size"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Name")).toEqual(jsonUtil.getValue(alicloudECSobj,"VPC Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("CIDR Block VPC")).toEqual(jsonUtil.getValue(alicloudECSobj,"CIDR Block VPC"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vswitch Name")).toEqual(jsonUtil.getValue(alicloudECSobj,"Vswitch Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("CIDR Block Vswitch")).toEqual(jsonUtil.getValue(alicloudECSobj,"CIDR Block Vswitch"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(jsonUtil.getValue(alicloudECSobj, "Security Group Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Elastic Network Interface")).toEqual(jsonUtil.getValue(alicloudECSobj, "Elastic Network Interface"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(alicloudECSobj, "Authentication Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Instance Name")).toEqual(jsonUtil.getValue(alicloudECSobj, "Instance Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("ECS Description")).toEqual(jsonUtil.getValue(alicloudECSobj, "ECS Description"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Release Protection")).toEqual("false");

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS1)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
            expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS2)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
            expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS3)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
            expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS4)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

            expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS1)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAliCloudECSEdit1);
            expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS2)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAliCloudECSNew2);
            expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS3)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
            expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS4)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);

			}).then(function(){	

				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextCMDBShellCIName()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
				snowPage.getTextCMDBShellCIAssignmentGroup();
				expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
				expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
				expect(snowPage.getTextCMDBShellCIAccountID()).not.toBe("");
				expect(snowPage.getTextCMDBShellCIAccountName()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsResourceId()).not.toBe("");
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				}
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();

				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();

				expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInCatalogTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
				expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
				expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();

                //Standard change
				snowPage.openRelatedChangeRequest();
				
				//Change Request Short Desc and Desc
                expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
				expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescEditOrder);

                //Order Completion in SNOW
				snowPage.checkIfProvisioningTaskClosed();

                //Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.completedState);

				//Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);

				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				snowPage.getTextCMDBShellCIName();
				expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
				snowPage.getTextCMDBShellCIAssignmentGroup();
				expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
				expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
				expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.alicloudProviderAccountID);
				expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.alicloudProviderAccount);
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();	

				//Change Task Page Validations 
				snowPage.openRelatedChangeRequest();
				snowPage.clickProvTaskLink();
				expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
				expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
				expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
				expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
				expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
				snowPage.clickClosureInfoInChangeTask();
				expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
				snowPage.clickBackButton();

				//Validation on Catalog Task page after completion
				snowPage.clickBackButton();
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				});
		});

		it('AliCloud ECS  ---- Verify Turn OFF functionality with Manual Technical, External Financial and Auto Legal approval and Standard change', function () {

            //Place order for Turn OFF in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
			orderObject.componentType = alicloudECStemplate.componentType;
            orderObject.servicename = serviceName;
            var val = JSON.stringify({ "IsUsingDummy": "Yes" });
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                util.scrollToTop();
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                        inventoryPage.clickOkForInstanceTurnOFFPermission();
                    });
                });
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(alicloudECStemplate.SubmitOrder);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(alicloudECStemplate.orderTypeAction);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.approvalState);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(alicloudECStemplate.turnOff);	

               //Approve Order in Marketplace
				orderFlowUtil.approveOrderButtonSNOW(orderObject);
				ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
				ordersPage.clickApproveButtonOrderApprovalModal();
				ordersPage.clickCancelButtonOrderApprovalModal();
    			orderFlowUtil.waitForOrderStatusChange(orderObject,alicloudECStemplate.approvalState);
    			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(alicloudECStemplate.approvalState);

				//Validation in Marketplace after auto approval
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.approvalState);
    			
    			//Validations on SNOW Request page after approval in Marketplace
    			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
    			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
    			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
    			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
    			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
    			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
    			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
    			
    			//Approve Order in SNOW
    			snowPage.approveTheServiceNowRequestFromSnowPortal();
    			
    			//Validations on SNOW Request page after approval in SNOW
    			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
    			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
    			
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
    			
    			expect(snowPage.getTextShortDescription()).toBe(alicloudECStemplate.turnOff);
    			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
    			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
    			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
				
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(alicloudECStemplate.turnOff);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOffAliCloud);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOff);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAliCloud);
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValue(alicloudECSobj, "VPC Name"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("stop");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalNA);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
			
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				}
				
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();
				//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				//snowPage.clickImplementButtonQS();
				snowPage.checkIfProvisioningTaskClosed();
				/*snowPage.clickBackButton();
				snowPage.openRelatedChangeRequest();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.completedState);
				inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                var adapterName = "Real";
                var status = alicloudECStemplate.stopStatus;
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.getComponentTags().then(function (text) {
                        if (val == text) {
                            status = 'Off';
                            adapterName = "dummy";
                        }
                        expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe(status);              
                    });
                });
				
                //Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				
				});		
            });
		});
		
		it('AliCloud ECS  ---- Verify Turn ON functionality with Manual Technical, External Financial and Auto Legal approval and Standard change', function () {

            //Place order for Turn ON in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
			orderObject.componentType = alicloudECStemplate.componentType;
            orderObject.servicename = serviceName;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                util.scrollToTop();
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickTurnONButtonOfInstance().then(function () {
                        inventoryPage.clickOkForInstanceTurnONPermission();
                    });
                });
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(alicloudECStemplate.SubmitOrder);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(alicloudECStemplate.orderTypeAction);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.approvalState);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(alicloudECStemplate.turnOn);
			 	
                //Approve Order in Marketplace
				orderFlowUtil.approveOrderButtonSNOW(orderObject);
				ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
				ordersPage.clickApproveButtonOrderApprovalModal();
				ordersPage.clickCancelButtonOrderApprovalModal();
    			orderFlowUtil.waitForOrderStatusChange(orderObject,alicloudECStemplate.approvalState);
    			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(alicloudECStemplate.approvalState);
    			
    			//Validations on SNOW Request page after approval in Marketplace
    			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
    			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
    			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
    			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
    			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
    			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
    			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
    			
    			//Approve Order in SNOW
    			snowPage.approveTheServiceNowRequestFromSnowPortal();
    			
    			//Validations on SNOW Request page after approval in SNOW
    			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
    			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
    			
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
    			
    			expect(snowPage.getTextShortDescription()).toBe(alicloudECStemplate.turnOn);
    			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
    			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
    			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
				
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
			
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(alicloudECStemplate.turnOn);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOnAliCloud);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOn);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAliCloud);
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValue(alicloudECSobj, "VPC Name"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("start");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
					
					// Validate BOM values from Broker config values
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
	
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalNA);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				}
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();
				//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				//snowPage.clickImplementButtonQS();
				snowPage.checkIfProvisioningTaskClosed();
				/*snowPage.clickBackButton();
				snowPage.openRelatedChangeRequest();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.completedState);
				inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
                });
				
                //Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				});		
            });
		});
		
		it('AliCloud ECS  ---- Verify Reboot functionality with Manual Technical, External Financial and Auto Legal approval and Standard change', function () {

            //Place order for Reboot in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
			orderObject.componentType = alicloudECStemplate.componentType;
            orderObject.servicename = serviceName;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                util.scrollToTop();
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickRebootButtonOfInstance().then(function () {
                        inventoryPage.clickOkForInstanceRebootPermission();
                    });
                });
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(alicloudECStemplate.SubmitOrder);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(alicloudECStemplate.orderTypeAction);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.approvalState);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(alicloudECStemplate.reboot);         
		
                //Approve Order in Marketplace
				orderFlowUtil.approveOrderButtonSNOW(orderObject);
				ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
				ordersPage.clickApproveButtonOrderApprovalModal();
				ordersPage.clickCancelButtonOrderApprovalModal();
    			orderFlowUtil.waitForOrderStatusChange(orderObject,alicloudECStemplate.approvalState);
    			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(alicloudECStemplate.approvalState);
    			
    			//Validations on SNOW Request page after approval in Marketplace
    			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
    			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
    			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
    			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
    			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
    			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
    			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
    			
    			//Approve Order in SNOW
    			snowPage.approveTheServiceNowRequestFromSnowPortal();
    			
    			//Validations on SNOW Request page after approval in SNOW
    			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
    			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
    			
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
    			
    			expect(snowPage.getTextShortDescription()).toBe(alicloudECStemplate.reboot);
    			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
    			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
    			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
				
				//Validations on SNOW Requested Item page
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(alicloudECStemplate.reboot);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescRebootAliCloud);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingReboot);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAliCloud);
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValue(alicloudECSobj, "VPC Name"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("reboot");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
					
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalNA);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				}
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				if(isDummyAdapterDisabled== "true") {
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();
				//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				//snowPage.clickImplementButtonQS();
				snowPage.checkIfProvisioningTaskClosed();
				/*snowPage.clickBackButton();
				snowPage.openRelatedChangeRequest();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(alicloudECStemplate.completedState);
				inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
                });
				
                //Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				
				});		
            });
		});

		it('AliCloud ECS ---- Verify Delete functionality with Manual Technical, External Financial, Auto Legal approval and Standard change', function () {
		
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			sampleOrder1 = inventoryPage.getDeleteOrderNumber();

			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(alicloudECStemplate.orderTypeDel);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(alicloudECStemplate.approvalState);
			
			//Approve Order in Marketplace
			orderFlowUtil.approveDeleteOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
			ordersPage.clickCancelButtonOrderApprovalModal();

			
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject,alicloudECStemplate.approvalState,50);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(alicloudECStemplate.approvalState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
			
			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(alicloudECStemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe(""); 

			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Validations on SNOW Request page after approval in SNOW
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(alicloudECStemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(alicloudECStemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAliCloud);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			
			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDECS);

			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAliCloud);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			
			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
			
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Region")).toEqual("me-east-1");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Billing Method")).toEqual("PostPaid");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Zones")).toEqual("me-east-1a");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Type")).toEqual(jsonUtil.getValue(alicloudECSobj,"Operating System Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Instance Type")).toEqual(jsonUtil.getValue(alicloudECSobj,"Instance Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Image")).toContain("freebsd");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Disk Category")).toEqual("cloud_efficiency");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Disk Size")).toEqual(jsonUtil.getValueEditParameter(alicloudECSobj,"System Disk Size"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Name")).toEqual(jsonUtil.getValue(alicloudECSobj,"VPC Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("CIDR Block VPC")).toEqual(jsonUtil.getValue(alicloudECSobj,"CIDR Block VPC"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vswitch Name")).toEqual(jsonUtil.getValue(alicloudECSobj,"Vswitch Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("CIDR Block Vswitch")).toEqual(jsonUtil.getValue(alicloudECSobj,"CIDR Block Vswitch"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(jsonUtil.getValue(alicloudECSobj, "Security Group Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Elastic Network Interface")).toEqual(jsonUtil.getValue(alicloudECSobj, "Elastic Network Interface"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(alicloudECSobj, "Authentication Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Instance Name")).toEqual(jsonUtil.getValue(alicloudECSobj, "Instance Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("ECS Description")).toEqual(jsonUtil.getValue(alicloudECSobj, "ECS Description"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Release Protection")).toEqual("false");			

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS1)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
            expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS2)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
            expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS3)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
            expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS4)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

            expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS1)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAliCloudECSDel1);
            expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS2)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAliCloudECSDel2);
            expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS3)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
            expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAliCloudSrvcItemValueECS4)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			}
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();

			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			snowPage.clickUpdateButton();

			
			//Standard change
			snowPage.openRelatedChangeRequest();
			//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
			
			//Change Request Short Desc and Desc
			expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescDeleteOrder);

			//Order Completion in SNOW
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(alicloudECStemplate.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.alicloudProviderAccountID);
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.alicloudProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			snowPage.clickUpdateButton();	

			//Change Task Page Validations 
			snowPage.openRelatedChangeRequest();
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickClosureInfoInChangeTask();
			expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			snowPage.clickBackButton();

			//Validation on Catalog Task page after completion
			snowPage.clickBackButton();
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			});		
		}); 



	};

});

