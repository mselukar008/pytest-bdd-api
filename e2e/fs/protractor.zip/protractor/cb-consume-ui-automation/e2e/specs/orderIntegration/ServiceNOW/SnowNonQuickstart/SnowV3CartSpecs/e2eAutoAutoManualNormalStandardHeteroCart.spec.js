"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	OrderHistoryPage = require('../../../../../pageObjects/ordersHistory.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	vRACentOS76Temp = require('../../../../../../testData/OrderIntegration/ServiceNOW/CloneCentOS76Snow.json'),
	gcpPubSubTemplate = require('../../../../../../testData/OrderIntegration/Google/pubsub.json'),
	slSecurityGrpTemplate = require('../../../../../../testData/OrderIntegration/Softlayer/SecurityGroupService.json'),
	shoppingCartTemplate   = require('../../../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json');
	
describe('E2E cases for Hetero cart with VRA, GCP, IBM Cloud services and Auto, Auto, Manual approval with Normal and Standard change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, provOrder, cartListPage, orderHistoryPage, policyPage;
	var modifiedParamMapVRA = {};
	var modifiedParamMapGoogle = {};
	var modifiedParamMapSL = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var orderObject = {};
	var serviceName1 = "SNOWauto"+util.getRandomString(5);
	var serviceName2 = "SNOWauto"+util.getRandomString(5);
	var serviceName3 = "SNOWauto"+util.getRandomString(5);
	var policyName = "SNOWautoAllPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWautoAllPolicyRule"+util.getRandomString(5);
	var cartName = "SNOWautoCart" + util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var topicName = "autom-" + util.getRandomString(5).toLowerCase();
	var secGrpName = "SNOWsecGrp"+util.getRandomString(5);
	var vraCentOSObj = JSON.parse(JSON.stringify(vRACentOS76Temp));

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		orderHistoryPage = new OrderHistoryPage();
		policyPage = new PolicyPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New"],"Provider":["Amazon","Google","IBM Cloud"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
								  "Legal":"Manual Approval"};
		modifiedParamMapVRA = {"Service Instance Name":serviceName1, "Cart Name":cartName, "Cart Service":"checkbox-useShoppingCart", "New Shopping Cart":"newCart", "Team":"TEAM1", "Environment":"QA", "Application":""};
		modifiedParamMapGoogle = {"Service Instance Name":serviceName2,"Cart Name": "","Cart Service": "","Team":"","Environment":"","Application":"","Name": topicName};
		modifiedParamMapSL = {"Service Instance Name":serviceName3,"Cart Name": "","Cart Service": "","Team":"","Environment":"","Application":"","Provider Account":"SL-Testing / SL-Testing","Security Group Name":secGrpName};
	});
	
	afterAll(function() {
		browser.get(consumeLaunchpadUrl);
	});
	
	it('Set Change Request type to Standard for VRA, GCP and Normal for IBM Cloud in SNOW', function () {
		expect(snowAPI.setCustomPolicyForAWSVRAAZGCPStdSLNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Auto, Auto, Manual Approval Policy for VRA, GCP and IBM Cloud Providers', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('Place an order for Hetero cart with VRA, GCP, IBM Cloud services and Auto, Auto, Manual approval with Normal and Standard change', function () {
			
			//Add VRA service to cart
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
			catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName1;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapVRA);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
			
	        //Add Google service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(gcpPubSubTemplate.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(gcpPubSubTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(gcpPubSubTemplate.bluePrintName);
			orderObject.servicename = serviceName2;
			orderFlowUtil.fillOrderDetails(gcpPubSubTemplate, modifiedParamMapGoogle);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
	        
	        //Add Softlayer service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName3;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
			
			//Submit Order
			cartListPage.submitOrder(0);
	    	orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
	    	orderObject.submittedBy = cartListPage.getTextSubmittedByOrderSubmittedModal
	        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(shoppingCartTemplate.orderSubmittedConfirmationMessage);
	    	provOrder = cartListPage.getTextOrderNumberOrderSubmittedModal();
	        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
	        orderObject = {"orderNumber":provOrder};	
		
	        //Validations on SNOW Request page before approval
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickLegalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickOkInOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			expect(snowPage.getTextShortDescription()).toBe(cartName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
			expect(snowPage.getCountOfRITMlinks()).toBe(parseInt("3"));
		});
		
		it('Verify the First RITM for Provision functionality', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			
			var providerName = snowPage.getTextReqItemVariableSOProvider();
			providerName.then(function(provider) {
				if(provider=="vra") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(sName){
					expect(sName).toContain(serviceName1);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual(jsonUtil.getValue(vraCentOSObj, "Memory (MB)"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual(jsonUtil.getValue(vraCentOSObj, "CPUs"));
					expect(snowPage.getTextReqItemBOMTotalVRA()).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRA);
					})
				}
				else if(provider=="gcp") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName2);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
					})
				}
				else {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName3);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					})
				}
					
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				if(provider=="ibmcloud") {				
					//Approvals in SNOW for Normal change
					snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
					snowPage.openRelatedChangeRequest();
					snowPage.approveChangeRequestForEachState();
					snowPage.approveChangeRequestForEachState();			
							
					//Order Completion in SNOW
					snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
					snowPage.openRelatedChangeRequest();
					snowPage.checkIfProvisioningTaskClosed();
					/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
					snowPage.openRelatedChangeRequest();
					snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
					expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				}
				else { 				
					//Validation on SNOW for Standard change
					snowPage.openRelatedChangeRequest();
					expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
					snowPage.clickBackButton();			
							
					//Order Completion in SNOW
					//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
					snowPage.openRelatedChangeRequest();
					snowPage.checkIfProvisioningTaskClosed();
					snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
					snowPage.openRelatedChangeRequest();
					snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
					expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				}
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(provider=="vra") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(awsEC2template.completedState);
				}
				else if(provider=="gcp") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(awsEC2template.completedState);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(awsEC2template.completedState);
				}
					
				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
				snowPage.clickFirstRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();	
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
			});
	    });
	
		it('Verify the Second RITM for Provision functionality', function () {
		
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			
			var providerName = snowPage.getTextReqItemVariableSOProvider();
			providerName.then(function(provider) {
				if(provider=="vra") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(sName){
					expect(sName).toContain(serviceName1);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual(jsonUtil.getValue(vraCentOSObj, "Memory (MB)"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual(jsonUtil.getValue(vraCentOSObj, "CPUs"));
					expect(snowPage.getTextReqItemBOMTotalVRA()).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRA);
					})
				}
				else if(provider=="gcp") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName2);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
					})
				}
				else {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName3);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					})
				}
					
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				if(provider=="ibmcloud") {				
					//Approvals in SNOW for Normal change
					snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
					snowPage.openRelatedChangeRequest();
					snowPage.approveChangeRequestForEachState();
					snowPage.approveChangeRequestForEachState();			
							
					//Order Completion in SNOW
					snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
					snowPage.openRelatedChangeRequest();
					snowPage.checkIfProvisioningTaskClosed();
					snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
					snowPage.openRelatedChangeRequest();
					snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
					expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				}
				else { 				
					//Validation on SNOW for Standard change
					snowPage.openRelatedChangeRequest();
					expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
					snowPage.clickBackButton();			
							
					//Order Completion in SNOW
					//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
					snowPage.openRelatedChangeRequest();
					snowPage.checkIfProvisioningTaskClosed();
					/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
					snowPage.openRelatedChangeRequest();
					snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
					expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				}
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(provider=="vra") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(awsEC2template.completedState);
				}
				else if(provider=="gcp") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(awsEC2template.completedState);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(awsEC2template.completedState);
				}
					
				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
				snowPage.clickSecondRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();	
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
			});
	    });
		
		it('Verify the Third RITM for Provision functionality', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickThirdRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			
			var providerName = snowPage.getTextReqItemVariableSOProvider();
			providerName.then(function(provider) {
				if(provider=="vra") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(sName){
					expect(sName).toContain(serviceName1);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual(jsonUtil.getValue(vraCentOSObj, "Memory (MB)"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual(jsonUtil.getValue(vraCentOSObj, "CPUs"));
					expect(snowPage.getTextReqItemBOMTotalVRA()).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRA);
					})
				}
				else if(provider=="gcp") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName2);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
					})
				}
				else {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName3);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					})
				}
					
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				if(provider=="ibmcloud") {				
					//Approvals in SNOW for Normal change
					snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
					snowPage.openRelatedChangeRequest();
					snowPage.approveChangeRequestForEachState();
					snowPage.approveChangeRequestForEachState();			
							
					//Order Completion in SNOW
					snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
					snowPage.openRelatedChangeRequest();
					snowPage.checkIfProvisioningTaskClosed();
					snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
					snowPage.openRelatedChangeRequest();
					snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
					expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				}
				else { 				
					//Validation on SNOW for Standard change
					snowPage.openRelatedChangeRequest();
					expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
					snowPage.clickBackButton();			
							
					//Order Completion in SNOW
					//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
					snowPage.openRelatedChangeRequest();
					snowPage.checkIfProvisioningTaskClosed();
					/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
					snowPage.openRelatedChangeRequest();
					snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
					expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				}
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(provider=="vra") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(awsEC2template.completedState);
				}
				else if(provider=="gcp") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(awsEC2template.completedState);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(awsEC2template.completedState);
				}
					
				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
				snowPage.clickThirdRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();	
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				
				//Validations on SNOW Request page after Completion of all RITM's
				snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			});
	    });	    
	 }
		
	 it('Delete Auto, Auto, Manual Approval Policy for VRA, GCP and IBM Cloud Providers', function () {
		browser.get(consumeLaunchpadUrl);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);
     });   
});
	
	
	
	