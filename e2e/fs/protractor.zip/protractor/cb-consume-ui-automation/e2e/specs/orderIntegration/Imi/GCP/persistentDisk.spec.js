
"use strict";
var Orders = require('../../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../../helpers/util.js'),
    jsonUtil = require('../../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../../testData/appUrls.json'),
    imiUtil = require('../../../../../helpers/imiApiUtil.js'),
    shoppingCartTemplate = require('../../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
    imiConfigTemplate = require('../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    imiManageServiceTemplate = require('../../../../../testData/OrderIntegration/Imi/manageService.json'),
    persistentDiskTemplate = require('../../../../../testData/OrderIntegration/Google/persistentdisk.json');


describe('IMI-GCP-Persistent Disk', function () {

    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, persistentDiskInsObject, inventoryPage, msgToVerify;
    var adapterName = "Real";
    var modifiedParamMap = {};
    var orderObject = {};
    var messageStrings = {
        providerName: 'Google',
        category: 'Storage',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        componentType: persistentDiskTemplate.componentType,
        imiOrderSubmitted: "Configure IMI Managed Service"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
    });


    fit('IMI-Persistent Disk- Verify E2E flow for Persistent Disk with IMI Add On', function () {

        var serviceDetailsMap = {};
        serviceName = "imiGcp-persistentDisk-" + util.getRandomString(5);
        var addOnName = "disk-adon-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Quantity": "1", "Add-On Name": addOnName };
        persistentDiskInsObject = JSON.parse(JSON.stringify(persistentDiskTemplate));
        orderObject.servicename = serviceName;
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(persistentDiskTemplate.bluePrintName);

        //Update ec2 template with IMI template
        delete persistentDiskTemplate["Order Parameters"]["Configure Add-ons"];
        persistentDiskTemplate["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
        persistentDiskTemplate["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
        persistentDiskTemplate["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
        persistentDiskTemplate["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(persistentDiskTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            //Restore template with default data	
            persistentDiskTemplate["Order Parameters"]["Configure Add-ons"] = imiManageServiceTemplate["Configure Add-ons"];
            delete persistentDiskTemplate["Order Parameters"]["IMI Main Parameters"];
            delete persistentDiskTemplate["Order Parameters"]["Configure manage service"];
            delete persistentDiskTemplate["Order Parameters"]["Review IMI Config"];

            serviceDetailsMap = requiredReturnMap;
            util.waitForAngular();
            //Validate IMI configuration on Review Order page
            expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(placeOrderPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(placeOrderPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Provider Account", 1)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Provider Account IMI"));

            //Validate Review Order page with all Service Configuration
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(persistentDiskTemplate.TotalCostWithAddOn);

            expect(requiredReturnMap["Actual"]["Region"]).toContain(requiredReturnMap["Expected"]["Region"]);
            expect(requiredReturnMap["Actual"]["Zone"]).toEqual(requiredReturnMap["Expected"]["Zone"]);
            expect(requiredReturnMap["Actual"]["Name"]).toEqual(requiredReturnMap["Expected"]["Name"]);
            expect(requiredReturnMap["Actual"]["Source Type"]).toEqual(requiredReturnMap["Expected"]["Source Type"]);
            //expect(requiredReturnMap["Actual"]["Image"]).toContain(requiredReturnMap["Expected"]["Image"]);
            expect(requiredReturnMap["Actual"]["Disk Type"]).toEqual(requiredReturnMap["Expected"]["Disk Type"]);
            expect(requiredReturnMap["Actual"]["Size (GB)"]).toEqual(requiredReturnMap["Expected"]["Size (GB)"]);
            expect(requiredReturnMap["Actual"]["Disk Mode"]).toEqual(requiredReturnMap["Expected"]["Disk Mode"]);
            expect(requiredReturnMap["Actual"]["Encryption"]).toEqual(requiredReturnMap["Expected"]["Encryption"]);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(persistentDiskTemplate.bluePrintName, "New-AddON");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate Add on on orders page
            expect(ordersPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
            expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            util.waitForAngular();
            expect(ordersPage.getTextBasedOnLabelName("Zone")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Zone"));
            expect(ordersPage.getTextBasedOnLabelName("Region")).toContain(jsonUtil.getValue(persistentDiskInsObject, "Region"));
            expect(ordersPage.getTextBasedOnLabelName("Source Type")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Source Type"));
            expect(ordersPage.getTextBasedOnLabelName("Disk Type")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Disk Type"));
            expect(ordersPage.getTextBasedOnLabelName("Size (GB)")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Size (GB)"));
            expect(ordersPage.getTextBasedOnLabelName("Disk Mode")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Disk Mode"));
            expect(ordersPage.getTextBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Encryption"));
            //Validate Add On details
            ordersPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelName("Add-on Name")).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 2)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate estimated cost
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(persistentDiskTemplate.TotalCostWithAddOn);
            //Validate BOM table on order details
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "SSD backed PD Capacity": "USD 6.80", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersPage.closeServiceDetailsSlider();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                //Validate Estimated price on approve order page                
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(persistentDiskTemplate.EstimatedPriceWithAddOn);
            }

            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            //Validate Add-On tag
            expect(ordersHistoryPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate Add On Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickExpandArrowForServiceAddOn();
            ordersHistoryPage.getAddOnDetails().then(function (addOnDetails) {
                expect(addOnDetails[1]).toContain(addOnName);
                expect(addOnDetails[3]).toContain(imiConfigTemplate.TotalCost);
                expect(addOnDetails[4]).toContain("Completed");
            });
            //Validate Service Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Region")).toContain(jsonUtil.getValue(persistentDiskInsObject, "Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Zone")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Zone"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Source Type")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Source Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Disk Type")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Disk Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Size (GB)")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Size (GB)"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Disk Mode")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Disk Mode"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Encryption"));
            //Validate Add-On Details
            ordersHistoryPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelName("Add-on Name")).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 4)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(persistentDiskTemplate.TotalCostWithAddOn);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "SSD backed PD Capacity": "USD 6.80", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(persistentDiskTemplate.TotalCostWithAddOn);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            //Verify Output parameter in Inventory
            expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            inventoryPage.clickViewAddOnDetails(orderObject);
            //Verify Add On details in Inventory
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Provider Name", 3)).toBe("IMI");
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Instance Status", 2)).toBe("Active");
            expect(inventoryPage.getTextImiMangmntLevl()).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
           // expect(inventoryPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(inventoryPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //verify bom for Add On
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(imiConfigTemplate.TotalCost);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }

            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            inventoryPage.clickViewServiceClosebutton();
            //Validate IMI tags
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                var tagList = tags.split(",");
                if (isDummyAdapterDisabled == "true") {
                    var planName = imiConfigTemplate.BillingPlanName;
                    expect(tagList[1]).toContain(planName.toLowerCase());
                    expect(tagList[2]).toContain(imiConfigTemplate.ServiceTierName);
                } else {
                    expect(tagList[2]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[0]).toContain(imiConfigTemplate.ServiceTierName);
                }

                orderFlowUtil.closeHorizontalSliderIfPresent();
            });

        });
    });
    if (isDummyAdapterDisabled == "true") {
        it('IMI-Persistent Disk-Configure IMI Manage Service having Add On', function () {

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false, };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                    inventoryPage.clickConfigureImiService();
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });

            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost    
                expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(persistentDiskTemplate.bluePrintName, "NewAddOnManageService");
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                ordersPage.open();
                //expect(util.getCurrentURL()).toMatch('orders');
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                //Validate Estimated price on approve order page            
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);
                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate Updated BOM on Inventory
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickOnInstanceTableActionIcon();
                inventoryPage.clickViewService();
                inventoryPage.clickBillOfMaterialsTabOrderDetails();
                //verify estimated cost for Add On
                expect(inventoryPage.getTextEstimatedCost()).toEqual(persistentDiskTemplate.TotalCostWithAddOn);
                inventoryPage.clickMoreLinkinBom();
                //Validate BOM table for Add on
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                inventoryPage.clickViewServiceClosebutton();
                
            });

        });
    }
    it('IMI-AWS-Persistent Disk- Delete service having addon from Inventory', function () {
        //Delete Service flow
        orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, persistentDiskTemplate.bluePrintName);
        //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
        orderFlowUtil.approveDeletedOrder(orderObject);
        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
    });

    if (isDummyAdapterDisabled == "true") {
        it('IMI-Persistent Disk-Configure Manage service from Inventory', function () {

            var serviceDetailsMap = {};
            serviceName = "gcp-auto-disk-" + util.getRandomString(5);
            modifiedParamMap = { "Service Instance Name": serviceName };
            orderObject.servicename = serviceName;
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
            catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(persistentDiskTemplate.bluePrintName);
            //Fill Order Details
            orderFlowUtil.fillOrderDetails(persistentDiskTemplate, modifiedParamMap);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(persistentDiskTemplate.bluePrintName, "ManageService");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(persistentDiskTemplate.EstimatedPrice);

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                    inventoryPage.clickConfigureImiService();
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });

            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost    
                expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
               orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(persistentDiskTemplate.bluePrintName, "ManageService-Inv");
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                
                //Navigate to Inventory and check same order id is generated after performing
                //same operation as the order is not approved, CON-34929
                //======================================================================              
               
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                        inventoryPage.clickConfigureImiService();
                        inventoryPage.getCustomOpsWarningPopupText().then(function(text){
                            expect(text.split("Order Number:")[1]).toContain(orderObject.orderNumber);
                            inventoryPage.clickCustomOpsWarningOKButton(); 
                        });                                               
                    });
                });

                ordersPage.open();
                //expect(util.getCurrentURL()).toMatch('orders');
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                //Validate Estimated price on approve order page            
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);
                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Delete Service flow
                orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                orderFlowUtil.deleteService(orderObject).then(async function(orderNo){
                    orderObject.deleteOrderNumber = orderNo;
                    await util.saveOrderId(persistentDiskTemplate.bluePrintName, "DeleteManageService", orderNo);
                    orderFlowUtil.approveDeletedOrder(orderObject);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
                });                
            });
        });
    }
});
