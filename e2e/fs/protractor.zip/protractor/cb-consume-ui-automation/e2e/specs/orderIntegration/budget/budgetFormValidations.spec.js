"use strict";


var BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    budgetaryFlow = require('../../../../helpers/budgetaryFlow.js'),
    appUrls = require('../../../../testData/appUrls.json'),
	budgetFormValidationsTemplate = require('../../../../testData/OrderIntegration/budget/budgetFormValidations.json'),
	budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
    budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryAddNewBudgetDetails.json');

describe('Budgetary Unit and Budget Form Validations TCs :', function() {
	var buAlphaNumericLongName, buAlphaNumericLongIdentifier, buAlphaNumericLongDesc, buAlphaNumericLongExtRefId, budgetryPage;
	var buAlphaNumericName, buAlphaNumericIdentifier, buAlphaNumericDesc, buAlphaNumericExtRefId;
	var buSpecialCharName, buSpecialCharIdentifier, buSpecialCharDesc, buSpecialCharExtRefId;
	var buDotName, buDotIdentifier, buDotDesc, buDotExtRefId;
	var buSpaceName, buSpaceIdentifier, buSpaceDesc, buSpaceExtRefId;
	var buUnderscoreHyphenName, buUnderscoreHyphenIdentifier, buUnderscoreHyphenDesc, buUnderscoreHyphenExtRefId;
	
	var budgetAlphaNumericName, budgetAlphaNumericExtRefId;
	var budgetAlphaNumericLongName, budgetSpecialCharName, budgetSpacePeriodName, budgetUnderscoreHyphenName;
	var budgetAlphaNumericLongExtRefId, budgetSpecialCharExtRefId, budgetSpacePeriodExtRefId, budgetUnderscoreHyphenExtRefId;
	
	var budgetFormObj = JSON.parse(JSON.stringify(budgetFormValidationsTemplate));
	var BUObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
    var budgetObject = JSON.parse(JSON.stringify(budgetaryAddNewBudgetDetailsTemplate));
	var modifiedBUParamMap = {};
	var modifiedBudgetParamMap = {};

	beforeAll(function() {
		budgetryPage = new BudgetaryPage();
		browser.driver.manage().window().maximize();
		buSpecialCharName = "budgetaryName$@" + util.getRandomString(5);
		buSpecialCharIdentifier = "budgetaryIdentifier*+" + util.getRandomString(5);
		buSpecialCharDesc = "budgetaryDesc!&" + util.getRandomString(5);
		buSpecialCharExtRefId = "budgetaryRefId%)" + util.getRandomString(5);
		buSpaceName = "budgetaryName " + util.getRandomString(5);
		buSpaceIdentifier = "budgetaryIdentifier " + util.getRandomString(5);
		buSpaceDesc = "budgetaryDesc " + util.getRandomString(5);
		buSpaceExtRefId = "budgetaryRefId " + util.getRandomString(5);
		buDotName = "budgetaryName." + util.getRandomString(5);
		buDotIdentifier = "budgetaryIdentifier." + util.getRandomString(5);
		buDotDesc = "budgetaryDesc." + util.getRandomString(5);
		buDotExtRefId = "budgetaryRefId." + util.getRandomString(5);
		buUnderscoreHyphenName = "budgetaryName_-" + util.getRandomString(5);
		buUnderscoreHyphenIdentifier = "budgetaryIdentifier_-" + util.getRandomString(5);
		buUnderscoreHyphenDesc = "budgetaryDesc_-" + util.getRandomString(5);
		buUnderscoreHyphenExtRefId = "budgetaryRefId_-" + util.getRandomString(5);
		buAlphaNumericLongName = "budgetaryName12" + util.getRandomString(50);
		buAlphaNumericLongIdentifier = "budgetaryIdentifier12" + util.getRandomString(50);
		buAlphaNumericLongDesc = "budgetaryDesc12" + util.getRandomString(260);
		buAlphaNumericLongExtRefId = "budgetaryRefId12" + util.getRandomString(2048);
		buAlphaNumericName = "budgetaryName12" + util.getRandomString(5);
		buAlphaNumericIdentifier = "budgetaryIdentifier12" + util.getRandomString(5);
		buAlphaNumericDesc = "budgetaryDesc12" + util.getRandomString(5);
		buAlphaNumericExtRefId = "budgetaryRefId12" + util.getRandomString(5);
		budgetAlphaNumericLongName ="budgetName12" + util.getRandomString(50);
		budgetAlphaNumericLongExtRefId = "budgetRefId12" + util.getRandomString(2048);
		budgetSpecialCharName = "budgetName$@" + util.getRandomString(5);
		budgetSpecialCharExtRefId = "budgetRefId%)" + util.getRandomString(5);
		budgetSpacePeriodName = "budgetName ." + util.getRandomString(5);
		budgetSpacePeriodExtRefId = "budgetIdentifier ." + util.getRandomString(5);
		budgetUnderscoreHyphenName = "budgetName_-" + util.getRandomString(5);
		budgetUnderscoreHyphenExtRefId = "budgetRefId_-" + util.getRandomString(5);
		budgetAlphaNumericName = "budgetName12" + util.getRandomString(5);
		budgetAlphaNumericExtRefId = "budgetRefId12" + util.getRandomString(5);
	});

	beforeEach(function() {
		budgetryPage.closeBudgetSliderIfPresent();
		budgetryPage.open();
		//util.waitForAngular();
		expect(util.getCurrentURL()).toMatch(appUrls.budgetaryUrl);
	});

	// Create Budgetary Unit Form
	it('Verify Create Budgetary unit form fields for special characters', function () {
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.setTextBudgetryName(buSpecialCharName);
		budgetryPage.setTextBudgetryUnitCode(buSpecialCharIdentifier);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryNameName)).toBe(budgetFormObj.budgetaryNameValidationText);
		budgetryPage.setTextBudgetryDescription(buSpecialCharDesc);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryUnitIdentifierName)).toBe(budgetFormObj.budgetaryUnitIdentifierValidationText);
		budgetryPage.setTextBudgetryExternalRefId(buSpecialCharExtRefId);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryDescName)).toBe(budgetFormObj.budgetaryDescNameValidationText);
		budgetryPage.clickOnBudgetrySaveBtn();
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryExternalRefIdName)).toBe(budgetFormObj.budgetaryExternalRedIdValidationText);
	});
	
	it('Verify Create Budgetary unit form fields for space character', function () {
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.setTextBudgetryName(buSpaceName);
		budgetryPage.setTextBudgetryUnitCode(buSpaceIdentifier);
		expect(budgetryPage.verifyBudgetFormNameValidations(budgetFormObj.budgetaryNameName)).toBe(false);
		budgetryPage.setTextBudgetryDescription(buSpaceDesc);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryUnitIdentifierName)).toBe(budgetFormObj.budgetaryUnitIdentifierValidationText);
		budgetryPage.setTextBudgetryExternalRefId(buSpaceExtRefId);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryDescName)).toBe(false);
		budgetryPage.clickOnBudgetrySaveBtn();
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryExternalRefIdName)).toBe(false);
	});
	
	it('Verify Create Budgetary unit form fields for period(.) character', function () {
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.setTextBudgetryName(buDotName);
		budgetryPage.setTextBudgetryUnitCode(buDotIdentifier);
		expect(budgetryPage.verifyBudgetFormNameValidations(budgetFormObj.budgetaryNameName)).toBe(false);
		budgetryPage.setTextBudgetryDescription(buDotDesc);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryUnitIdentifierName)).toBe(budgetFormObj.budgetaryUnitIdentifierValidationText);
		budgetryPage.setTextBudgetryExternalRefId(buDotExtRefId);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryDescName)).toBe(false);
		budgetryPage.clickOnBudgetrySaveBtn();
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryExternalRefIdName)).toBe(false);
	});
	
	it('Verify Create Budgetary unit form fields for Underscore and Hyphen characters', function () {
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.setTextBudgetryName(buUnderscoreHyphenName);
		budgetryPage.setTextBudgetryUnitCode(buUnderscoreHyphenIdentifier);
		expect(budgetryPage.verifyBudgetFormNameValidations(budgetFormObj.budgetaryNameName)).toBe(false);
		budgetryPage.setTextBudgetryDescription(buUnderscoreHyphenDesc);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryUnitIdentifierName)).toBe(false);
		budgetryPage.setTextBudgetryExternalRefId(buUnderscoreHyphenExtRefId);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryDescName)).toBe(false);
		budgetryPage.clickOnBudgetrySaveBtn();
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetaryExternalRefIdName)).toBe(false);
	});
	
	it('Verify Create Budgetary unit form fields for Alpha-Numeric Long characters', function () {
		modifiedBUParamMap = { "budgetary Name": buAlphaNumericLongName, "budgetary unit code": buAlphaNumericLongIdentifier, "budgetary Description": buAlphaNumericLongDesc, "budgetary External Referance Id": buAlphaNumericLongExtRefId, "Environment": "slEnv", "Application": "slApp" };
        budgetryPage.clickOnAddNewBudgetryUnitBtn();
        budgetryPage.fillOrderDetails(BUObject, modifiedBUParamMap);
		budgetryPage.clickOnBudgetrySaveBtn().then(function(){
			budgetryPage.getTextBudgetryDetailsName().then(function(buName){
				budgetryPage.getTextBudgetryDetailsUnitCode().then(function(buCode){
					budgetryPage.getTextBudgetryDetailsDescription().then(function(buDesc){
						budgetryPage.getTextBudgetryDetailsExternalRefId().then(function(buExtRefId){
							util.waitForAngular();
							expect(budgetryPage.verifyBudgetFieldTextLength(buName, 50)).toBe(true);
							expect(budgetryPage.verifyBudgetFieldTextLength(buCode, 50)).toBe(true);
							expect(budgetryPage.verifyBudgetFieldTextLength(buDesc, 260)).toBe(true);
							expect(budgetryPage.verifyBudgetFieldTextLength(buExtRefId, 2048)).toBe(true);
						});
					});
				});
			});
		});
		
		// Delete created Budgetary unit
		budgetryPage.clickOnDeleteBtnFromBudgetaryDetailsPage();
        budgetryPage.clickOnDeleteConfirmationButton();
	});
	
	// Create Budget Form
	it('Pre-requisite: Verify Create Budget form fields - Name & External RefID - for special characters', function() {
		modifiedBUParamMap = { "budgetary Name": buAlphaNumericName, "budgetary unit code": buAlphaNumericIdentifier, "budgetary Description": buAlphaNumericDesc, "budgetary External Referance Id": buAlphaNumericExtRefId, "Environment": "slEnv", "Application": "slApp" };
        budgetryPage.clickOnAddNewBudgetryUnitBtn();
        budgetryPage.fillOrderDetails(BUObject, modifiedBUParamMap);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickOnBudgetryBudgetsLink();
		
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.setTextBudgetName(budgetSpecialCharName);
		budgetryPage.setTextBudgetExternalRefId(budgetSpecialCharExtRefId);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetNameName)).toBe(budgetFormObj.budgetNameValidationText);
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmtValid);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetExternalRefIdName)).toBe(budgetFormObj.budgetExternalRefIdValidationText);
	});

	it('Verify Create Budget form fields - Name & External RefID - for space and period characters', function() {
		budgetryPage.searchBudegtaryUnit(buAlphaNumericName);
        budgetryPage.checkBudgetaryNameInBudgetaryUnitTable(buAlphaNumericName);
        budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(buAlphaNumericName);
		 budgetryPage.clickOnBudgetryBudgetsLink();
		
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.setTextBudgetName(budgetSpacePeriodName);
		budgetryPage.setTextBudgetExternalRefId(budgetSpacePeriodExtRefId);
		expect(budgetryPage.verifyBudgetFormNameValidations(budgetFormObj.budgetNameName)).toBe(false);
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmtValid);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetExternalRefIdName)).toBe(false);
	});

	it('Verify Create Budget form fields - Name & External RefID - for underscore and hyphen characters', function() {
		budgetryPage.searchBudegtaryUnit(buAlphaNumericName);
        budgetryPage.checkBudgetaryNameInBudgetaryUnitTable(buAlphaNumericName);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(buAlphaNumericName);
		util.waitForAngular();
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.setTextBudgetName(budgetUnderscoreHyphenName);
		budgetryPage.setTextBudgetExternalRefId(budgetUnderscoreHyphenExtRefId);
		expect(budgetryPage.verifyBudgetFormNameValidations(budgetFormObj.budgetNameName)).toBe(false);
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmtValid);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetExternalRefIdName)).toBe(false);
	});

	it('Verify Create Budget form fields - Name & External RefID - for Alpha-Numeric Long characters', function () {
		budgetryPage.searchBudegtaryUnit(buAlphaNumericName);
        budgetryPage.checkBudgetaryNameInBudgetaryUnitTable(buAlphaNumericName);
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(buAlphaNumericName);
		budgetryPage.clickOnBudgetryBudgetsLink();

		budgetryPage.clickOnBudgetaryAddBudgetButton();
        modifiedBudgetParamMap = { "Name": budgetAlphaNumericLongName, "External Ref Id": budgetAlphaNumericLongExtRefId, "Start Period": budgetFormObj.budgetStartPeriodValid, "Budget Amount": budgetFormObj.budgetAmtValid };
        budgetryPage.fillOrderDetails(budgetObject, modifiedBudgetParamMap);
        budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		budgetryPage.getTextBudgetName().then(function(budgetName){
			budgetryPage.getTextBudgetExternalRefId().then(function(budgetExtRefId){
				expect(budgetryPage.verifyBudgetFieldTextLength(budgetName, 50)).toBe(true);
				expect(budgetryPage.verifyBudgetFieldTextLength(budgetExtRefId, 2048)).toBe(true);
			});
		});
	});

	it('Verify Create Budget form field - Soft Quota & Hard Quota:Percentage', function() {
		budgetryPage.searchBudegtaryUnit(buAlphaNumericName);
        budgetryPage.checkBudgetaryNameInBudgetaryUnitTable(buAlphaNumericName);
        budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(buAlphaNumericName);
		budgetryPage.clickOnBudgetryBudgetsLink();
		
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.setTextBudgetName(budgetAlphaNumericName);
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmtValid);
		budgetryPage.clickBudgetSoftQuotaText();
		budgetryPage.clickBudgetHardQuotaText();
		// Valid values
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQPercentageValid);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQPercentageValid);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(false);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(false);
		// Values with 2 decimals
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQPercentage2Decimals);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQPercentage2Decimals);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(false);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(false);
		// Values with 3 decimals
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQPercentage3Decimals);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQPercentage3Decimals);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(budgetFormObj.budgetSQThresholdPercentageValidationText);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(budgetFormObj.budgetHQThresholdPercentageValidationText);
		// Maximum Values
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQPercentage100);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQPercentage200);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(false);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(false);
		// Maximum values with 2 decimals
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQPercentage100With2Decimals);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQPercentage200With2Decimals);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(budgetFormObj.budgetSQThresholdPercentageValidationText);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(budgetFormObj.budgetHQThresholdPercentageValidationText);
		// Minimum Values
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQPercentage0);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQPercentage0);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(false);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(false);
		// Negative Values
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQPercentageNegative);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQPercentageNegative);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(budgetFormObj.budgetSQThresholdPercentageValidationText);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(budgetFormObj.budgetHQThresholdPercentageValidationText);
	});
    it('Verify Create Budget form field - Budget Amount & Start Period', function() {
		budgetryPage.searchBudegtaryUnit(buAlphaNumericName);
        budgetryPage.checkBudgetaryNameInBudgetaryUnitTable(buAlphaNumericName);
        budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(buAlphaNumericName);
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.setTextBudgetName(budgetAlphaNumericName);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId);
		budgetryPage.clickBudgetSoftQuotaText();
		budgetryPage.clickBudgetHardQuotaText();
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQPercentageValid);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQPercentageValid);
		// Valid values
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmtValid);
		budgetryPage.setTextBudgetStartPeriod(budgetFormObj.budgetStartPeriodValid);
		expect(budgetryPage.verifyBudgetFormNameValidations(budgetFormObj.budgetAmountName)).toBe(false);
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmtValid);
		//budget start date textfield valdiations are not supported as textfield is changed with Mon-year calender
		//expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetStartPeriodName)).toBe(false);
		// Budget amount-2 decimal value & Start Period-0th Month value
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmt2Decimals);
		budgetryPage.setTextBudgetStartPeriod(budgetFormObj.budgetStartPeriod0thMonth);
		//expect(budgetryPage.verifyBudgetFormNameValidations(budgetFormObj.budgetAmountName)).toBe(false);
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmtValid);
		//expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetStartPeriodName)).toBe(budgetFormObj.budgetStartPeriodValidationText);
		// Budget amount-3 decimal value & Start Period-19th century value
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmt3Decimals);
		budgetryPage.setTextBudgetStartPeriod(budgetFormObj.budgetStartPeriod19thCentury);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetAmountName)).toBe(budgetFormObj.budgetAmountValidationText);
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmtValid);
		//expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetStartPeriodName)).toBe(budgetFormObj.budgetStartPeriodValidationText);
		// Budget amount-Negative value & Start Period-MMYYYY value
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmtNegative);
		budgetryPage.setTextBudgetStartPeriod(budgetFormObj.budgetStartPeriodMMYYYY);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetAmountName)).toBe(budgetFormObj.budgetAmountValidationText);
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmtValid);
		//expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetStartPeriodName)).toBe(budgetFormObj.budgetStartPeriodValidationText);
		// Budget amount-0 value & Start Period-30th century value
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmt0);
		budgetryPage.setTextBudgetStartPeriod(budgetFormObj.budgetStartPeriod30thCentury);
		expect(budgetryPage.verifyBudgetFormNameValidations(budgetFormObj.budgetAmountName)).toBe(false);
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmtValid);
		//expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetStartPeriodName)).toBe(budgetFormObj.budgetStartPeriodValidationText);	
	});

	it('Verify Create Budget form field - Soft Quota & Hard Quota:Actual', function() {
		budgetryPage.searchBudegtaryUnit(buAlphaNumericName);
        budgetryPage.checkBudgetaryNameInBudgetaryUnitTable(buAlphaNumericName);
        budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(buAlphaNumericName);
		budgetryPage.clickOnBudgetryBudgetsLink();
		
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		budgetryPage.setTextBudgetName(budgetAlphaNumericName);
		budgetryPage.setTextBudgetAmount(budgetFormObj.budgetAmtValid);
		budgetryPage.clickBudgetSoftQuotaText();
		budgetryPage.clickBudgetHardQuotaText();
		budgetryPage.clickOnQuotaValueType(budgetFormObj.budgetSQThresholdId, budgetFormObj.budgetQuotaActualType);
		budgetryPage.clickOnQuotaValueType(budgetFormObj.budgetHQThresholdId, budgetFormObj.budgetQuotaActualType);
		// Valid values
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQActualValid);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQActualValid);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(false);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId)
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(false);
		// Values with 2 decimals
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQActual2Decimals);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQActual2Decimals);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(false);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId)
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(false);
		// Values with 3 decimals
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQActual3Decimals);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQActual3Decimals);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(budgetFormObj.budgetSQThresholdActualValidationText);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId)
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(budgetFormObj.budgetHQThresholdActualValidationText);
		// Maximum Values
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQActualLong);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQActualLong);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(false);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId)
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(false);
		// Minimum Values
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQActual0);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQActual0);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(false);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId)
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(false);
		// Negative Values
		budgetryPage.setTextSoftQuota(budgetFormObj.budgetSQActualNegative);
		budgetryPage.setTextHardQuota(budgetFormObj.budgetHQActualNegative);
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetSQThresholdName)).toBe(budgetFormObj.budgetSQThresholdActualValidationText);
		budgetryPage.setTextBudgetExternalRefId(budgetAlphaNumericExtRefId)
		expect(budgetryPage.verifyBudgetFormValidations(budgetFormObj.budgetHQThresholdName)).toBe(budgetFormObj.budgetHQThresholdActualValidationText);
	});

	
	afterAll(async function () {
		// Delete created Budgetary unit
		budgetryPage.closeBudgetSliderIfPresent();		
		budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(buAlphaNumericName);
		budgetryPage.clickOnDeleteBtnFromBudgetaryDetailsPage();
        budgetryPage.clickOnDeleteConfirmationButton();
		budgetryPage.closeBudgetSliderIfPresent();		
	});
});