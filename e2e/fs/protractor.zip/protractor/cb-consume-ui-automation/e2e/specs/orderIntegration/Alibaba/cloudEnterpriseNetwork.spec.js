/*************************************************
Spec_Name: cloudEnterpriseNetwork.spec.js
Description: This spec will cover E2E testing of Cloud Enterprise Network service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".     
**************************************************/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    CENTemplate = require('../../../../testData/OrderIntegration/Alibaba/CloudEnterpriseNetwork.json')

describe('Alibaba: Test cases for Cloud Enterprise Network ', function () {
    var ordersPage, catalogPage, catalogDetailsPage, inventoryPage, placeOrderPage, homePage;
    var modifiedParamMap = {};
    var modifiedParamMapVPC = {};
    var modifiedParamMapedit = {};
    var messageStrings = {
        providerName: 'Alibaba Cloud',
        category: 'Network'
    };
    var servicename = "Gsl-Auto-CEN" + util.getRandomString(5);
    var servicenameVPC = "Gsl-Auto-VPC" + util.getRandomString(5);
    modifiedParamMapVPC = {
        "Service Instance Name": servicenameVPC,
    };

    beforeAll(function () {
        homePage = new HomePage();
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        modifiedParamMap = {
            "Service Instance Name": servicename,
        };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });


    afterAll(function () {
        // Delete Cloud Enterprise Network
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');

        // Delete Virtual Private Cloud
        var returnObjVPC = {};
        returnObjVPC.servicename = servicenameVPC;
        returnObjVPC.deleteOrderNumber = orderFlowUtil.deleteService(returnObjVPC);
        orderFlowUtil.approveDeletedOrder(returnObjVPC);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObjVPC, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObjVPC)).toBe('Completed');
    });

    //Prerequisite: We need to create Virtual Private Cloud, which will be used by Cloud Enterprise Network Service.
    it('Aalibaba: TC-1 Prerequisite for Cloud Enterprise Network: Create new Virtual Private Cloud', function () {
        var orderObjectVPC = JSON.parse(JSON.stringify(CENTemplate.createVirtualPrivateCloud));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObjectVPC.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObjectVPC.bluePrintName);
        var returnObjVPC = {};
        orderFlowUtil.fillOrderDetails(CENTemplate.createVirtualPrivateCloud, modifiedParamMapVPC);
        placeOrderPage.submitOrder();
        returnObjVPC.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        returnObjVPC.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        returnObjVPC.servicename = servicenameVPC;
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObjectVPC.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(returnObjVPC);
        orderFlowUtil.waitForOrderStatusChange(returnObjVPC, orderObjectVPC.OrderStatus);
        homePage.open();
    });

    it('Aalibaba: TC-2 verify that for Cloud Enterprise Network Service all parameters on Main Parameters Page are present.', function () {
        var orderObject = JSON.parse(JSON.stringify(CENTemplate.createCloudEnterpriseNetwork));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);

        expect(catalogDetailsPage.getServiceName()).toBe(orderObject.bluePrintName)
        expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true);
        expect(catalogDetailsPage.isPresentLinkToProviderSite()).toBe(true);
        expect(catalogDetailsPage.isPresentFeaturesLabel()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsLabel()).toBe(true);
        expect(catalogDetailsPage.getTextFeaturesLabel()).toBe(orderObject.FeaturesLabel);
        expect(catalogDetailsPage.getTextDetailsLabel()).toBe(orderObject.DetailsLabel);
        expect(catalogDetailsPage.isPresentFeaturesInfo()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsInfo()).toBe(true);
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);

        catalogDetailsPage.clickCatalogFromBreadCrumbNav();
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
        homePage.open();
    });

    it('Aalibaba: TC-3 verify that for Cloud Enterprise Network Service all parameters on Review Order page matches with input.', function () {
        var orderObject = JSON.parse(JSON.stringify(CENTemplate.createCloudEnterpriseNetwork));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderObject.servicename = servicename;
        orderFlowUtil.fillOrderDetails(CENTemplate.createCloudEnterpriseNetwork, modifiedParamMap);

        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(orderObject.servicename);

        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Description:")).toEqual(jsonUtil.getValue(orderObject, "Description"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Network Instance Type:")).toEqual(jsonUtil.getValue(orderObject, "Network Instance Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" VPC List:")).toEqual(jsonUtil.getValue(orderObject, "VPC List"));
        homePage.open();
    });

    it('Aalibaba: TC-4 verify that for Cloud Enterprise Network Service all values on View Order Details page matches with input.', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(CENTemplate.createCloudEnterpriseNetwork));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(CENTemplate.createCloudEnterpriseNetwork, modifiedParamMap);
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();

        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);

        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("Region")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(ordersPage.getTextBasedOnExactLabelName("Description")).toEqual(jsonUtil.getValue(orderObject, "Description"));
        expect(ordersPage.getTextBasedOnExactLabelName("Network Instance Type")).toEqual(jsonUtil.getValue(orderObject, "Network Instance Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("VPC List")).toEqual(jsonUtil.getValue(orderObject, "VPC List"));

        //Checking Bill Of Material
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(placeOrderPage.getTotalCost()).toBe(orderObject.Totalcost);

        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
        orderFlowUtil.denyOrder(returnObj);
    });

    if (isProvisioningRequired == "true") {
        it('Aalibaba: TC-5 Verify that for Cloud Enterprise Network Service,if service is created with new valid name and Region, create Description and VPC List', function () {
            var modifiedParamMapEditForNegativeScenario = {
                "EditService": true,
                "UpdateMainParamObject": false
            };
            var returnObj = {};
            var returnObjForEdit = {};
            var editServiceObj = JSON.parse(JSON.stringify(CENTemplate.createCloudEnterpriseNetwork.negativeScenarioForEditService));
            var orderObject = JSON.parse(JSON.stringify(CENTemplate.createCloudEnterpriseNetwork));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            orderFlowUtil.fillOrderDetails(CENTemplate.createCloudEnterpriseNetwork, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, orderObject.OrderStatus);

            //checking order on Inventory Page 
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();

            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
            expect(inventoryPage.getTextBasedOnLabelName(" Description:")).toEqual(jsonUtil.getValue(orderObject, "Description"));
            expect(inventoryPage.getTextBasedOnLabelName(" Network Instance Type:")).toEqual(jsonUtil.getValue(orderObject, "Network Instance Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" VPC List:")).toEqual(jsonUtil.getValue(orderObject, "VPC List"));
            inventoryPage.closeViewDetailsTab();

            //Edit order flow
            modifiedParamMapedit = {
                "EditService": true,
                "UpdateMainParamObject": false
            };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickEditServiceIcon();
            inventoryPage.clickNextButton();
            orderFlowUtil.fillOrderDetails(editServiceObj, modifiedParamMapEditForNegativeScenario);
            placeOrderPage.EditsubmitOrder();
            placeOrderPage.clickOnNotificationCloseButton();
            placeOrderPage.clickPreviousButton();
            placeOrderPage.clickPreviousButton();
            placeOrderPage.clickPreviousButton();
            orderFlowUtil.fillOrderDetails(CENTemplate.createCloudEnterpriseNetwork, modifiedParamMapedit);
            placeOrderPage.submitOrder();
            returnObjForEdit.servicename = servicename;
            returnObjForEdit.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObjForEdit.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
            expect(orderFlowUtil.verifyOrderType(returnObjForEdit)).toBe('EditSOI');
            orderFlowUtil.approveOrder(returnObjForEdit);
            orderFlowUtil.waitForOrderStatusChange(returnObjForEdit, 'Completed', 50);
        });
    }
});