"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	OrderHistoryPage = require('../../../../../pageObjects/ordersHistory.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	awsEC2template = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSEC2InstanceSnow.json'),
	vRACentOS76Temp = require('../../../../../../testData/OrderIntegration/ServiceNOW/CloneCentOS76Snow.json'),
	azureLinuxTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/AzureLinuxVMSnow.json'),
	gcpPubSubTemplate = require('../../../../../../testData/OrderIntegration/Google/pubsub.json'),
	slSecurityGrpTemplate = require('../../../../../../testData/OrderIntegration/Softlayer/SecurityGroupService.json'),
	shoppingCartTemplate   = require('../../../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json');
	
describe('E2E cases for Hetero cart with all Provider services and Manual, External, Manual approval with Normal change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, provOrder, cartListPage, orderHistoryPage, policyPage, groupName;
	var modifiedParamMapAWS = {};
	var modifiedParamMapVRA = {};
	var modifiedParamMapAzure = {};
	var modifiedParamMapGoogle = {};
	var modifiedParamMapSL = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var orderObject = {};
	var serviceName1 = "SNOWauto"+util.getRandomString(5);
	var serviceName2 = "SNOWauto"+util.getRandomString(5);
	var serviceName3 = "SNOWauto"+util.getRandomString(5);
	var serviceName4 = "SNOWauto"+util.getRandomString(5);
	var serviceName5 = "SNOWauto"+util.getRandomString(5);
	var policyName = "SNOWautoAllPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWautoAllPolicyRule"+util.getRandomString(5);
	var cartName = "SNOWautoCart" + util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var newResourceGroupName = "gslautotc_azureWVM-RG101" + util.getRandomString(4);
	var newVmName = "auto-VM101" + util.getRandomString(4);
	var newNetworkName = "auto-VN101" + util.getRandomString(4);
	var newSubnetName = "auto-SN101" + util.getRandomString(4);
	var newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
	var newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
	var newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
	var newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
	var diskName = "autodisk" + util.getRandomString(4);
    diskName = diskName.toLocaleLowerCase();
	var topicName = "autom-" + util.getRandomString(5).toLowerCase();
	var secGrpName = "SNOWsecGrp"+util.getRandomString(5);
	var vraCentOSObj = JSON.parse(JSON.stringify(vRACentOS76Temp));
	var awsEC2obj = JSON.parse(JSON.stringify(awsEC2template));
	var azureLinuxObj = JSON.parse(JSON.stringify(azureLinuxTemplate.Scenario1));

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		orderHistoryPage = new OrderHistoryPage();
		policyPage = new PolicyPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		groupName = "att-group-" + util.getRandomString(5);
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New"],"Provider":["Amazon","Azure","Google","VRA","IBM Cloud"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
								  "Technical":"Manual Approval","Financial":"External Approval","Legal":"Manual Approval"};
		modifiedParamMapAWS = {"Service Instance Name":serviceName1, "Cart Name":cartName, "Cart Service":"checkbox-useShoppingCart", "New Shopping Cart":"newCart", "Team":"TEAM1", "Environment":"QA", "Application":"", "Provider Account":"AWS-SNOW / AWS-SNOW", "Group Name": groupName};
		modifiedParamMapVRA = {"Service Instance Name":serviceName2,"Cart Name": "","Cart Service": "","Team":"","Environment":"","Application":""};
		modifiedParamMapAzure = {"Service Instance Name":serviceName3,"Cart Name": "","Cart Service": "","Team":"","Environment":"","Application":"","New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Disk Name": diskName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName };
		modifiedParamMapGoogle = {"Service Instance Name":serviceName4,"Cart Name": "","Cart Service": "","Team":"","Environment":"","Application":"","Name": topicName};
		modifiedParamMapSL = {"Service Instance Name":serviceName5,"Cart Name": "","Cart Service": "","Team":"","Environment":"","Application":"","Provider Account":"SL-Testing / SL-Testing","Security Group Name":secGrpName};
	});
	
	afterAll(function() {
		browser.get(consumeLaunchpadUrl);
	});
	
	it('Set Change Request type to Normal in SNOW', function () {
		expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Manual, External, Manual Approval Policy for all Providers', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.selectExternalApprovalDropdownSNOW();
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('Place an order for Hetero cart with all Provider services and Manual, External, Manual approval with Normal change', function () {
			
			//Add AWS service to cart
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(awsEC2template.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(awsEC2template.Category);
			catalogPage.clickConfigureButtonBasedOnName(awsEC2template.bluePrintName);
			orderObject.servicename = serviceName1;
			orderFlowUtil.fillOrderDetails(awsEC2template, modifiedParamMapAWS);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
			
	        //Add VRA service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName2;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapVRA);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
	        
	        //Add Azure service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(azureLinuxObj.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(azureLinuxObj.Category);
			catalogPage.clickConfigureButtonBasedOnName(azureLinuxObj.bluePrintName);
			orderObject.servicename = serviceName3;
			orderFlowUtil.fillOrderDetails(azureLinuxTemplate.Scenario1, modifiedParamMapAzure);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
	        
	        //Add Google service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(gcpPubSubTemplate.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(gcpPubSubTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(gcpPubSubTemplate.bluePrintName);
			orderObject.servicename = serviceName4;
			orderFlowUtil.fillOrderDetails(gcpPubSubTemplate, modifiedParamMapGoogle);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
	        
	        //Add Softlayer service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName5;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
			
			//Submit Order
			cartListPage.submitOrder(0);
	    	orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
	    	orderObject.submittedBy = cartListPage.getTextSubmittedByOrderSubmittedModal
	        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(shoppingCartTemplate.orderSubmittedConfirmationMessage);
	    	provOrder = cartListPage.getTextOrderNumberOrderSubmittedModal();
	        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
	        orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.appInProgressState); 
		
			//Validations on SNOW Request page before approval
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequested();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickLegalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
			ordersPage.clickOkInOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.provInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			expect(snowPage.getTextShortDescription()).toBe(cartName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
			expect(snowPage.getCountOfRITMlinks()).toBe(parseInt("5"));
		});
		
		it('Verify the First RITM for Provision functionality with Normal change', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			
			var providerName = snowPage.getTextReqItemVariableSOProvider();
			providerName.then(function(provider) {
				if(provider=="aws") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName1);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2obj, "Resource Name"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet")).toEqual("subnet-a68b538d");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("VPC")).toEqual("vpc-8eadd1eb");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2obj, "Shutdown Behavior"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2obj, "T2/T3 Unlimited"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2obj, "User Data"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));			
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWS);
					})
				}
				else if(provider=="vra") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName2);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual(jsonUtil.getValue(vraCentOSObj, "Memory (MB)"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual(jsonUtil.getValue(vraCentOSObj, "CPUs"));
					expect(snowPage.getTextReqItemBOMTotalVRA()).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRA);
					})
				}
				else if(provider=="azure") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescAzure);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName3);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Resource Group Required")).toEqual("Yes");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("New Resource Group")).toEqual(newResourceGroupName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Location").toString().toLowerCase().replace(/\s/g,''));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Name")).toEqual(newVmName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Location")).toEqual(jsonUtil.getValue(azureLinuxObj,"Virtual Machine Location"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Username")).toEqual(jsonUtil.getValue(azureLinuxObj,"Username"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Authentication Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Admin Password")).toEqual("XXXXXX");	
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Proximity Placement Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "Proximity Placement Group"));			
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Availability Options")).toEqual("NoInfrastructureRedundancyRequired");			
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Image")).toEqual("RHEL, 7.4, RedHat");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vm Generation")).toEqual("V1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Size")).toEqual("Basic_A0");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Virtual Network Required")).toEqual(jsonUtil.getValue(azureLinuxObj,"New Virtual Network Required"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Network Name")).toEqual(newNetworkName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Address Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Address Prefix"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Name")).toEqual(newSubnetName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Subnet Prefix"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Interface Name")).toEqual(newNetworkInterfaceName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Required"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Name")).toEqual(newPublicIpName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Ip Address Sku"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("NIC Network Security Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "NIC Network Security Group"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Inbound Ports")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Inbound Ports"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use Load Balancing")).toEqual(jsonUtil.getValue(azureLinuxObj, "Use Load Balancing"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(azureLinuxObj, "System Assigned Managed Identity"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "Boot Diagnostics"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "OS Guest Diagnostics"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(azureLinuxObj, "Enable Auto Shutdown"));
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAzure);
					})
				}
				else if(provider=="gcp") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName4);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
					})
				}
				else {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName5);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					})
				}
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				//Approvals in SNOW
				snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
				snowPage.openRelatedChangeRequest();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveChangeRequestForEachState();			
						
				//Order Completion in SNOW
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(provider=="aws") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(awsEC2template.completedState);
				}
				else if(provider=="vra") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(awsEC2template.completedState);
				}
				else if(provider=="azure") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(awsEC2template.completedState);
				}
				else if(provider=="gcp") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName4);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName4)).toBe(awsEC2template.completedState);
				}
				else  {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName5);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName5)).toBe(awsEC2template.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
	    });
	
		it('Verify the Second RITM for Provision functionality with Normal change', function () {
		
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			
			var providerName = snowPage.getTextReqItemVariableSOProvider();
			providerName.then(function(provider) {
				if(provider=="aws") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName1);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2obj, "Resource Name"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet")).toEqual("subnet-a68b538d");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("VPC")).toEqual("vpc-8eadd1eb");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2obj, "Shutdown Behavior"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2obj, "T2/T3 Unlimited"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2obj, "User Data"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));			
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWS);
					})
				}
				else if(provider=="vra") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName2);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual(jsonUtil.getValue(vraCentOSObj, "Memory (MB)"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual(jsonUtil.getValue(vraCentOSObj, "CPUs"));
					expect(snowPage.getTextReqItemBOMTotalVRA()).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRA);
					})
				}
				else if(provider=="azure") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescAzure);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName3);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Resource Group Required")).toEqual("Yes");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("New Resource Group")).toEqual(newResourceGroupName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Location").toString().toLowerCase().replace(/\s/g,''));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Name")).toEqual(newVmName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Location")).toEqual(jsonUtil.getValue(azureLinuxObj,"Virtual Machine Location"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Username")).toEqual(jsonUtil.getValue(azureLinuxObj,"Username"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Authentication Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Admin Password")).toEqual("XXXXXX");	
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Proximity Placement Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "Proximity Placement Group"));			
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Availability Options")).toEqual("NoInfrastructureRedundancyRequired");			
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Image")).toEqual("RHEL, 7.4, RedHat");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vm Generation")).toEqual("V1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Size")).toEqual("Basic_A0");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Virtual Network Required")).toEqual(jsonUtil.getValue(azureLinuxObj,"New Virtual Network Required"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Network Name")).toEqual(newNetworkName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Address Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Address Prefix"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Name")).toEqual(newSubnetName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Subnet Prefix"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Interface Name")).toEqual(newNetworkInterfaceName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Required"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Name")).toEqual(newPublicIpName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Ip Address Sku"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("NIC Network Security Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "NIC Network Security Group"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Inbound Ports")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Inbound Ports"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use Load Balancing")).toEqual(jsonUtil.getValue(azureLinuxObj, "Use Load Balancing"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(azureLinuxObj, "System Assigned Managed Identity"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "Boot Diagnostics"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "OS Guest Diagnostics"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(azureLinuxObj, "Enable Auto Shutdown"));
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAzure);
					})
				}
				else if(provider=="gcp") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName4);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
					})
				}
				else {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName5);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					})
				}
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				//Approvals in SNOW
				snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
				snowPage.openRelatedChangeRequest();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveChangeRequestForEachState();			
						
				//Order Completion in SNOW
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(provider=="aws") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(awsEC2template.completedState);
				}
				else if(provider=="vra") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(awsEC2template.completedState);
				}
				else if(provider=="azure") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(awsEC2template.completedState);
				}
				else if(provider=="gcp") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName4);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName4)).toBe(awsEC2template.completedState);
				}
				else  {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName5);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName5)).toBe(awsEC2template.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
	    });
		
		it('Verify the Third RITM for Provision functionality with Normal change', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickThirdRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			
			var providerName = snowPage.getTextReqItemVariableSOProvider();
			providerName.then(function(provider) {
				if(provider=="aws") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName1);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2obj, "Resource Name"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet")).toEqual("subnet-a68b538d");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("VPC")).toEqual("vpc-8eadd1eb");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2obj, "Shutdown Behavior"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2obj, "T2/T3 Unlimited"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2obj, "User Data"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));			
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWS);
					})
				}
				else if(provider=="vra") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName2);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual(jsonUtil.getValue(vraCentOSObj, "Memory (MB)"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual(jsonUtil.getValue(vraCentOSObj, "CPUs"));
					expect(snowPage.getTextReqItemBOMTotalVRA()).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRA);
					})
				}
				else if(provider=="azure") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescAzure);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName3);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Resource Group Required")).toEqual("Yes");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("New Resource Group")).toEqual(newResourceGroupName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Location").toString().toLowerCase().replace(/\s/g,''));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Name")).toEqual(newVmName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Location")).toEqual(jsonUtil.getValue(azureLinuxObj,"Virtual Machine Location"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Username")).toEqual(jsonUtil.getValue(azureLinuxObj,"Username"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Authentication Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Admin Password")).toEqual("XXXXXX");	
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Proximity Placement Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "Proximity Placement Group"));			
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Availability Options")).toEqual("NoInfrastructureRedundancyRequired");			
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Image")).toEqual("RHEL, 7.4, RedHat");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vm Generation")).toEqual("V1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Size")).toEqual("Basic_A0");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Virtual Network Required")).toEqual(jsonUtil.getValue(azureLinuxObj,"New Virtual Network Required"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Network Name")).toEqual(newNetworkName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Address Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Address Prefix"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Name")).toEqual(newSubnetName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Subnet Prefix"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Interface Name")).toEqual(newNetworkInterfaceName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Required"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Name")).toEqual(newPublicIpName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Ip Address Sku"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("NIC Network Security Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "NIC Network Security Group"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Inbound Ports")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Inbound Ports"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use Load Balancing")).toEqual(jsonUtil.getValue(azureLinuxObj, "Use Load Balancing"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(azureLinuxObj, "System Assigned Managed Identity"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "Boot Diagnostics"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "OS Guest Diagnostics"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(azureLinuxObj, "Enable Auto Shutdown"));
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAzure);
					})
				}
				else if(provider=="gcp") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName4);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
					})
				}
				else {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName5);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					})
				}
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				//Approvals in SNOW
				snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
				snowPage.openRelatedChangeRequest();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveChangeRequestForEachState();			
						
				//Order Completion in SNOW
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(provider=="aws") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(awsEC2template.completedState);
				}
				else if(provider=="vra") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(awsEC2template.completedState);
				}
				else if(provider=="azure") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(awsEC2template.completedState);
				}
				else if(provider=="gcp") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName4);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName4)).toBe(awsEC2template.completedState);
				}
				else  {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName5);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName5)).toBe(awsEC2template.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickThirdRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
	    });
		
		it('Verify the Fourth RITM for Provision functionality with Normal change', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.clickFourthRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			
			var providerName = snowPage.getTextReqItemVariableSOProvider();
			providerName.then(function(provider) {
				if(provider=="aws") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName1);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2obj, "Resource Name"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet")).toEqual("subnet-a68b538d");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("VPC")).toEqual("vpc-8eadd1eb");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2obj, "Shutdown Behavior"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2obj, "T2/T3 Unlimited"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2obj, "User Data"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));			
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWS);
					})
				}
				else if(provider=="vra") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName2);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual(jsonUtil.getValue(vraCentOSObj, "Memory (MB)"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual(jsonUtil.getValue(vraCentOSObj, "CPUs"));
					expect(snowPage.getTextReqItemBOMTotalVRA()).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRA);
					})
				}
				else if(provider=="azure") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescAzure);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName3);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Resource Group Required")).toEqual("Yes");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("New Resource Group")).toEqual(newResourceGroupName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Location").toString().toLowerCase().replace(/\s/g,''));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Name")).toEqual(newVmName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Location")).toEqual(jsonUtil.getValue(azureLinuxObj,"Virtual Machine Location"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Username")).toEqual(jsonUtil.getValue(azureLinuxObj,"Username"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Authentication Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Admin Password")).toEqual("XXXXXX");	
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Proximity Placement Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "Proximity Placement Group"));			
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Availability Options")).toEqual("NoInfrastructureRedundancyRequired");			
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Image")).toEqual("RHEL, 7.4, RedHat");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vm Generation")).toEqual("V1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Size")).toEqual("Basic_A0");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Virtual Network Required")).toEqual(jsonUtil.getValue(azureLinuxObj,"New Virtual Network Required"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Network Name")).toEqual(newNetworkName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Address Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Address Prefix"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Name")).toEqual(newSubnetName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Subnet Prefix"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Interface Name")).toEqual(newNetworkInterfaceName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Required"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Name")).toEqual(newPublicIpName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Ip Address Sku"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("NIC Network Security Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "NIC Network Security Group"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Inbound Ports")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Inbound Ports"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use Load Balancing")).toEqual(jsonUtil.getValue(azureLinuxObj, "Use Load Balancing"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(azureLinuxObj, "System Assigned Managed Identity"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "Boot Diagnostics"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "OS Guest Diagnostics"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(azureLinuxObj, "Enable Auto Shutdown"));
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAzure);
					})
				}
				else if(provider=="gcp") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName4);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
					})
				}
				else {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName5);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					})
				}
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				//Approvals in SNOW
				snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
				snowPage.openRelatedChangeRequest();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveChangeRequestForEachState();			
						
				//Order Completion in SNOW
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(provider=="aws") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(awsEC2template.completedState);
				}
				else if(provider=="vra") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(awsEC2template.completedState);
				}
				else if(provider=="azure") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(awsEC2template.completedState);
				}
				else if(provider=="gcp") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName4);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName4)).toBe(awsEC2template.completedState);
				}
				else  {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName5);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName5)).toBe(awsEC2template.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickFourthRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();		
	    });
		
		it('Verify the Fifth RITM for Provision functionality with Normal change', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickFifthRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			
			var providerName = snowPage.getTextReqItemVariableSOProvider();
			providerName.then(function(provider) {
				if(provider=="aws") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName1);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2obj, "Resource Name"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet")).toEqual("subnet-a68b538d");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("VPC")).toEqual("vpc-8eadd1eb");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2obj, "Shutdown Behavior"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2obj, "T2/T3 Unlimited"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2obj, "User Data"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));			
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWS);
					})
				}
				else if(provider=="vra") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName2);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual(jsonUtil.getValue(vraCentOSObj, "Memory (MB)"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual(jsonUtil.getValue(vraCentOSObj, "CPUs"));
					expect(snowPage.getTextReqItemBOMTotalVRA()).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRA);
					})
				}
				else if(provider=="azure") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescAzure);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName3);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Resource Group Required")).toEqual("Yes");
					expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("New Resource Group")).toEqual(newResourceGroupName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Location").toString().toLowerCase().replace(/\s/g,''));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Name")).toEqual(newVmName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Location")).toEqual(jsonUtil.getValue(azureLinuxObj,"Virtual Machine Location"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Username")).toEqual(jsonUtil.getValue(azureLinuxObj,"Username"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Authentication Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Admin Password")).toEqual("XXXXXX");	
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Proximity Placement Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "Proximity Placement Group"));			
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Availability Options")).toEqual("NoInfrastructureRedundancyRequired");			
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Image")).toEqual("RHEL, 7.4, RedHat");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vm Generation")).toEqual("V1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Size")).toEqual("Basic_A0");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Virtual Network Required")).toEqual(jsonUtil.getValue(azureLinuxObj,"New Virtual Network Required"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Network Name")).toEqual(newNetworkName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Address Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Address Prefix"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Name")).toEqual(newSubnetName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Subnet Prefix"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Interface Name")).toEqual(newNetworkInterfaceName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Required"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Name")).toEqual(newPublicIpName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Ip Address Sku"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("NIC Network Security Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "NIC Network Security Group"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Inbound Ports")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Inbound Ports"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use Load Balancing")).toEqual(jsonUtil.getValue(azureLinuxObj, "Use Load Balancing"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(azureLinuxObj, "System Assigned Managed Identity"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "Boot Diagnostics"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "OS Guest Diagnostics"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(azureLinuxObj, "Enable Auto Shutdown"));
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAzure);
					})
				}
				else if(provider=="gcp") {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName4);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
					})
				}
				else {
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
					expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
					expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function(serviceName){
					expect(serviceName).toContain(serviceName5);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName);
					expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(serviceName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					})
				}
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				//Approvals in SNOW
				snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
				snowPage.openRelatedChangeRequest();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveChangeRequestForEachState();			
						
				//Order Completion in SNOW
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(provider=="aws") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(awsEC2template.completedState);
				}
				else if(provider=="vra") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(awsEC2template.completedState);
				}
				else if(provider=="azure") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(awsEC2template.completedState);
				}
				else if(provider=="gcp") {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName4);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName4)).toBe(awsEC2template.completedState);
				}
				else  {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName5);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName5)).toBe(awsEC2template.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickFifthRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			
			//Validations on SNOW Request page after Completion of all RITM's
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	    });
	 }
	
	it('Delete Manual, External, Manual Approval Policy for all Providers', function () {
		browser.get(consumeLaunchpadUrl);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);
     });   
});
	
	
	
	