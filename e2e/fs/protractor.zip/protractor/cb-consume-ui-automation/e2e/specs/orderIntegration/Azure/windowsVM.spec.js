/*
Spec_Name: windowsVM.spec.js 
Description: This spec will cover E2E testing of Windows VM service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    logGenerator = require("../../../../helpers/logGenerator.js"),
    Logger = logGenerator.getApplicationLogger(),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    WVMTemplate = require('../../../../testData/OrderIntegration/Azure/newWindowsVM.json'),
    HostTemplate = require('../../../../testData/OrderIntegration/Azure/host.json');

describe('Azure - Windows Virtual Machine', function () {
    var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage;
    var diskName;
    var hostOrderObject = {};
    var modifiedParamMap = {};
    var modifiedParamMapHostService = {};
    var messageStrings = { providerName: 'Azure', category: 'Compute' };
    var modifiedParamMapedit = {};
    var servicename = "AutoWVMsrv" + util.getRandomString(5);
    var hostName = "autoHost" + util.getRandomString(5);
    var servicenameHost = "GSLSLTestAutomation" + util.getRandomString(5);
    var hostGroupName = "hostGroupName" + util.getRandomString(5);
    var messageStrings = { providerName: 'Azure' };
    var newResourceGroupName, newVmName, newNetworkName, newSubnetName, newNetworkInterfaceName, newnetworkSecurityGroupName, newPublicIpName, newAvailabilitySetName;
    var SOIComponents;

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        catalogDetailsPage = new CatalogDetailsPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        newResourceGroupName = "gslautotc_azure_winvmRG" + util.getRandomString(4);
        newVmName = "auto-VM" + util.getRandomString(4);
        newNetworkName = "auto-VN101" + util.getRandomString(4);
        newSubnetName = "auto-SN101" + util.getRandomString(4);
        newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
        newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
        newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
        newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
        diskName = "autodisk" + util.getRandomString(4);
        diskName = diskName.toLocaleLowerCase();
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Disk Name": diskName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName, "UpdateMainParamObject": false };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        SOIComponents = [newVmName, newNetworkName, newNetworkInterfaceName, newnetworkSecurityGroupName, newPublicIpName, newAvailabilitySetName, diskName]
    });

    afterAll(function () {
        if (isDummyAdapterDisabled == "false") {
            //Delete Windows VM
            var returnObj = {};
            returnObj.servicename = servicename;
            returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
            orderFlowUtil.approveDeletedOrder(returnObj);
            orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        }
        // if (isDummyAdapterDisabled == "true") {
        //       //deletion for host service
        //    var returnObjHost = {};
        //    returnObjHost.servicename = servicenameHost;
        //    returnObjHost.deleteOrderNumber = orderFlowUtil.deleteService(returnObjHost);
        //    orderFlowUtil.approveDeletedOrder(returnObjHost);
        //    orderFlowUtil.waitForDeleteOrderStatusChange(returnObjHost, 'Completed');
        //    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObjHost)).toBe('Completed');
        // }
    });

    if (isProvisioningRequired == "true") {
        if (isDummyAdapterDisabled == "false") {
            it('Azure: TC-T374437-Sanity Verify if VM created with new RG,OS Publisher-Server,OS-DC,VM Size-BasicA0, new VN and Subnet, new NSG , new Public IP,AV-No,Boot-Enabled, new DSA', function () {
                var newWindowsVMObject = JSON.parse(JSON.stringify(WVMTemplate.Scenario1));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(newWindowsVMObject.Category);
                catalogPage.searchForBluePrint(newWindowsVMObject.bluePrintName);
                catalogPage.clickConfigureButtonBasedOnName(newWindowsVMObject.bluePrintName);
                var returnObj = {};
                var returnObj1 = {};
                orderFlowUtil.fillOrderDetails(WVMTemplate.Scenario1, modifiedParamMap);
                placeOrderPage.submitOrder();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                returnObj.servicename = servicename;
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(returnObj);
                orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed', 150);
                inventoryPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                inventoryPage.clickViewService();
                // Checking Inventory Page Service Configuration
                expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "New Resource Group Required"));
                expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(newResourceGroupName);
                expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Location"));
                expect(inventoryPage.getTextBasedOnLabelName(" Virtual Machine Name:")).toEqual(newVmName);
                expect(inventoryPage.getTextBasedOnExactLabelName("Virtual Machine Location:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Virtual Machine Location"));
                expect(inventoryPage.getTextBasedOnLabelName(" Proximity Placement Group:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Proximity Placement Group"));
                expect(inventoryPage.getTextBasedOnLabelName(" Availability Options:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Availability Options"));
                expect(inventoryPage.getTextBasedOnLabelName(" Operating System Image:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Operating System Image"));
                expect(inventoryPage.getTextBasedOnLabelName(" Vm Generation:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Vm Generation"));
                expect(inventoryPage.getTextBasedOnLabelName(" Admin Username:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Admin Username"));
                expect(inventoryPage.getTextBasedOnLabelName(" Virtual Machine Size:")).toEqual(jsonUtil.getValue(newWindowsVMObject, " Virtual Machine Size"));
                expect(inventoryPage.getTextBasedOnLabelName(" Use Managed Disk:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Use Managed Disk"))
                expect(inventoryPage.getTextBasedOnLabelName(" Use Ephemeral OS Disk:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Use Ephemeral OS Disk"));
                expect(inventoryPage.getTextBasedOnLabelName(" OS Disk Type:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "OS Disk Type"));
                expect(inventoryPage.getTextBasedOnLabelName(" Data Disk:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Data Disk"));
                expect(inventoryPage.getTextBasedOnLabelName(" Logical Unit Number (LUN):")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Logical Unit Number (LUN)"));
                expect(inventoryPage.getTextBasedOnLabelName(" Disk Name:")).toEqual(diskName);
                //expect(inventoryPage.getTextBasedOnLabelName(" Storage Type : Ultra Disk:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Storage Type : Ultra Disk"));
                expect(inventoryPage.getTextBasedOnLabelName(" Storage Type:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Storage Type"));
                expect(inventoryPage.getTextBasedOnLabelName(" Source Type:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Source Type"));
                expect(inventoryPage.getTextBasedOnLabelName(" Provide Custom Disk Size:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Provide Custom Disk Size"));
                expect(inventoryPage.getTextBasedOnLabelName(" Disk Size List In GB:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Disk Size List In GB"));
                expect(inventoryPage.getTextBasedOnLabelName(" Host Caching:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Host Caching"));
                expect(inventoryPage.getTextBasedOnLabelName(" New Virtual Network Required:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "New Virtual Network Required"));
                expect(inventoryPage.getTextBasedOnLabelName(" Virtual Network Name:")).toEqual(newNetworkName);
                expect(inventoryPage.getTextBasedOnLabelName(" Address Prefix:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Address Prefix"));
                expect(inventoryPage.getTextBasedOnLabelName(" Subnet Name:")).toEqual(newSubnetName);
                expect(inventoryPage.getTextBasedOnLabelName(" Subnet Prefix:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Subnet Prefix"));
                expect(inventoryPage.getTextBasedOnLabelName(" Network Interface Name:")).toEqual(newNetworkInterfaceName);
                expect(inventoryPage.getTextBasedOnLabelName(" Public IP Address Required:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Public IP Address Required"));
                expect(inventoryPage.getTextBasedOnLabelName(" NIC Network Security Group:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "NIC Network Security Group"));
                expect(inventoryPage.getTextBasedOnLabelName(" Public Inbound Ports:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Public Inbound Ports"));
                expect(inventoryPage.getTextBasedOnLabelName(" Network Security Group Name:")).toEqual(newnetworkSecurityGroupName);
                expect(inventoryPage.getTextBasedOnLabelName(" Public IP Address Name:")).toEqual(newPublicIpName);
                expect(inventoryPage.getTextBasedOnLabelName(" Public Ip Address Sku:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Public Ip Address Sku"));
                expect(inventoryPage.getTextBasedOnLabelName(" Public IP Address Type:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Public IP Address Type"));
                expect(inventoryPage.getTextBasedOnLabelName(" Use Load Balancing:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Use Load Balancing"));
                expect(inventoryPage.getTextBasedOnLabelName(" Boot Diagnostics:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Boot Diagnostics"));
                expect(inventoryPage.getTextBasedOnLabelName(" System Assigned Managed Identity:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "System Assigned Managed Identity"));
                expect(inventoryPage.getTextBasedOnLabelName(" OS Guest Diagnostics:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "OS Guest Daignostics"));
                expect(inventoryPage.getTextBasedOnLabelName(" Support For Premium Disks:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Support For Premium Disks"));
                expect(inventoryPage.getTextBasedOnLabelName(" Enable Auto Shutdown:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Enable Auto Shutdown"));
                inventoryPage.closeViewDetailsTab();
                // Edit is not supported anymore with Dummy Apdater Commenting below code (INT-7673)
                // //Edit order
                // inventoryPage.open();
                // inventoryPage.searchOrderByServiceName(returnObj.servicename);
                // element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                // inventoryPage.clickEditServiceIcon();
                // inventoryPage.clickNextButton();
                // modifiedParamMapedit = { "Service Instance Name": servicename, "Network Security Group Name": newnetworkSecurityGroupName, "EditService": true };
                // orderFlowUtil.fillOrderDetails(WVMTemplate.Scenario1, modifiedParamMapedit);
                // expect(placeOrderPage.getBOMTablePriceOnReviewOrder()).toBe(newWindowsVMObject.TotalCostAfterEdit);
                // placeOrderPage.submitOrder();
                // returnObj1.servicename = servicename;
                // returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                // returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                // //Get details on pop up after submit
                // var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                // var orderprice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                // var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                // var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                // //Open Order page and Approve Order 
                // expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                // placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                // orderFlowUtil.approveOrder(returnObj1);
                // orderFlowUtil.waitForOrderStatusChange(returnObj1, "Completed", 50);
            });
        }
    }

    //Checking parameters on Main Parameters page
    it('Azure: TC-T372617 Verify that for Windows VM Service, all parameters on Main Parameters Page are present..', function () {
        var newWindowsVMObject = JSON.parse(JSON.stringify(WVMTemplate.Scenario1));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(newWindowsVMObject.Category);
        catalogPage.searchForBluePrint(newWindowsVMObject.bluePrintName);
        catalogPage.clickDetailsButtonBasedOnName(newWindowsVMObject.bluePrintName);
        if (browser.params.defaultCurrency == "USD") {
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(newWindowsVMObject.BasePrice);
        }
    });

    //Checking values all parameters on Review Order Page and View Order Details
    it('Azure: TC-T372738 Verify that for Windows VM Service all values on Review Order Page and View Order Details page matches with input.', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var newWindowsVMObject = JSON.parse(JSON.stringify(WVMTemplate.Scenario1));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(newWindowsVMObject.Category);
        catalogPage.searchForBluePrint(newWindowsVMObject.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(newWindowsVMObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(WVMTemplate.Scenario1, modifiedParamMap);
        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
        if (browser.params.defaultCurrency == "USD") {
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(newWindowsVMObject.TotalCost);
        }
        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "New Resource Group Required"));
        expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(newResourceGroupName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Location"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Virtual Machine Name:")).toEqual(newVmName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Virtual Machine Location:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Virtual Machine Location"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Admin Username:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Admin Username"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Proximity Placement Group:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Proximity Placement Group"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Availability Options:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Availability Options"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Use Managed Disk:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Use Managed Disk"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Use Ephemeral OS Disk:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Use Ephemeral OS Disk"));
        expect(placeOrderPage.getTextBasedOnLabelName(" OS Disk Type:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "OS Disk Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Data Disk:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Data Disk"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Logical Unit Number (LUN):")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Logical Unit Number (LUN)"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Disk Name:")).toEqual(diskName);
        //expect(placeOrderPage.getTextBasedOnLabelName(" Storage Type : Ultra Disk")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Storage Type : Ultra Disk"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Storage Type:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Storage Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Source Type:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Source Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Provide Custom Disk Size:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Provide Custom Disk Size"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Host Caching:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Host Caching"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Vm Generation:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Vm Generation"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Virtual Network Name:")).toEqual(newNetworkName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Address Prefix:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Address Prefix"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Subnet Name:")).toEqual(newSubnetName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Subnet Prefix:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Subnet Prefix"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Network Interface Name:")).toEqual(newNetworkInterfaceName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Public IP Address Required:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Public IP Address Required"));
        expect(placeOrderPage.getTextBasedOnLabelName(" NIC Network Security Group:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "NIC Network Security Group"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Public Inbound Ports:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Public Inbound Ports"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Network Security Group Name:")).toEqual(newnetworkSecurityGroupName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Public IP Address Name:")).toEqual(newPublicIpName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Public Ip Address Sku:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Public Ip Address Sku"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Public IP Address Type:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Public IP Address Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Use Load Balancing:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Use Load Balancing"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Boot Diagnostics:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Boot Diagnostics"));
        expect(placeOrderPage.getTextBasedOnLabelName(" System Assigned Managed Identity:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "System Assigned Managed Identity"));
        expect(placeOrderPage.getTextBasedOnLabelName(" OS Guest Diagnostics:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "OS Guest Daignostics"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Enable Auto Shutdown:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Enable Auto Shutdown"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Support For Premium Disks:")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Support For Premium Disks"));
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(newWindowsVMObject.provider);//Checking Provider
        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(newWindowsVMObject, "New Resource Group Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(newResourceGroupName);
        expect(ordersPage.getTextBasedOnExactLabelName("Virtual Machine Name")).toEqual(newVmName);
        expect(ordersPage.getTextBasedOnExactLabelName("Virtual Machine Location")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Virtual Machine Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("Admin Username")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Admin Username"));
        expect(ordersPage.getTextBasedOnExactLabelName("Proximity Placement Group")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Proximity Placement Group"));
        expect(ordersPage.getTextBasedOnExactLabelName("Availability Options")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Availability Options"));
        expect(ordersPage.getTextBasedOnExactLabelName("Operating System Image")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Operating System Image"));
        expect(ordersPage.getTextBasedOnExactLabelName("Vm Generation")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Vm Generation"));
        expect(ordersPage.getTextBasedOnExactLabelName("Virtual Machine Size")).toEqual(jsonUtil.getValue(newWindowsVMObject, " Virtual Machine Size"));
        expect(ordersPage.getTextBasedOnExactLabelName("Use Managed Disk")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Use Managed Disk"))
        expect(ordersPage.getTextBasedOnExactLabelName("Use Ephemeral OS Disk")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Use Ephemeral OS Disk"));
        expect(ordersPage.getTextBasedOnExactLabelName("OS Disk Type")).toEqual(jsonUtil.getValue(newWindowsVMObject, "OS Disk Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Data Disk")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Data Disk"));
        expect(ordersPage.getTextBasedOnExactLabelName("Logical Unit Number (LUN)")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Logical Unit Number (LUN)"));
        expect(ordersPage.getTextBasedOnExactLabelName("Disk Name")).toEqual(diskName);
        expect(ordersPage.getTextBasedOnExactLabelName("Storage Type : Ultra Disk")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Storage Type : Ultra Disk"));
        expect(ordersPage.getTextBasedOnExactLabelName("Storage Type")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Storage Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Source Type")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Source Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Provide Custom Disk Size")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Provide Custom Disk Size"));
        expect(ordersPage.getTextBasedOnExactLabelName("Disk Size List In GB")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Disk Size List In GB"));
        expect(ordersPage.getTextBasedOnExactLabelName("Host Caching")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Host Caching"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Virtual Network Required")).toEqual(jsonUtil.getValue(newWindowsVMObject, "New Virtual Network Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Virtual Network Name")).toEqual(newNetworkName);
        expect(ordersPage.getTextBasedOnExactLabelName("Address Prefix")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Address Prefix"));
        expect(ordersPage.getTextBasedOnExactLabelName("Subnet Name")).toEqual(newSubnetName);
        expect(ordersPage.getTextBasedOnExactLabelName("Subnet Prefix")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Subnet Prefix"));
        expect(ordersPage.getTextBasedOnExactLabelName("Network Interface Name")).toEqual(newNetworkInterfaceName);
        expect(ordersPage.getTextBasedOnExactLabelName("Public IP Address Required")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Public IP Address Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("NIC Network Security Group")).toEqual(jsonUtil.getValue(newWindowsVMObject, "NIC Network Security Group"));
        expect(ordersPage.getTextBasedOnExactLabelName("Public Inbound Ports")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Public Inbound Ports"));
        expect(ordersPage.getTextBasedOnExactLabelName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
        expect(ordersPage.getTextBasedOnExactLabelName("Public IP Address Name")).toEqual(newPublicIpName);
        expect(ordersPage.getTextBasedOnExactLabelName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Public Ip Address Sku"));
        expect(ordersPage.getTextBasedOnExactLabelName("Public IP Address Type")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Public IP Address Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Use Load Balancing")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Use Load Balancing"));
        expect(ordersPage.getTextBasedOnExactLabelName("Boot Diagnostics")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Boot Diagnostics"));
        expect(ordersPage.getTextBasedOnExactLabelName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(newWindowsVMObject, "System Assigned Managed Identity"));
        expect(ordersPage.getTextBasedOnExactLabelName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(newWindowsVMObject, "OS Guest Daignostics"));
        expect(ordersPage.getTextBasedOnExactLabelName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Enable Auto Shutdown"));
        expect(ordersPage.getTextBasedOnExactLabelName("Support For Premium Disks")).toEqual(jsonUtil.getValue(newWindowsVMObject, "Support For Premium Disks"));
        //Checking Bill Of Material
        if (browser.params.defaultCurrency == "USD") {
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(ordersPage.getEstimatedCost()).toBe(newWindowsVMObject.TotalCost);
        }
        ordersPage.clickServiceDetailSliderCloseButton();
    });

    // Automated VM Scenario with Host but as Host costing is 3000$ plus so commenting the code
    // if (isProvisioningRequired == "true") {
    //     if (isDummyAdapterDisabled == "true") {
    //         it('Azure: Windows Virtual Machine - Create prerequisite Host Service for Windows Virtual Machine ', function () {
    //             var hostObject = JSON.parse(JSON.stringify(HostTemplate));
    //             catalogPage.searchForBluePrint(HostTemplate.bluePrintName);
    //             catalogPage.clickConfigureButtonBasedOnName(HostTemplate.bluePrintName);
    //             hostOrderObject.servicename = servicenameHost;
    //             modifiedParamMapHostService = {"Service Instance Name": servicenameHost, "New Resource Group": newResourceGroupName, "Host Name": hostName, "Host Group Name": hostGroupName, "Dedicate Host VM Family Size": "ESv3-Type2 ( 76 vCPUs )", "Host Group Availability Zone": "2" };
    //             orderFlowUtil.fillOrderDetails(HostTemplate, modifiedParamMapHostService);
    //             placeOrderPage.submitOrder();
    //             hostOrderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
    //             hostOrderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
    //             expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
    //             placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
    //             orderFlowUtil.approveOrder(hostOrderObject);
    //             orderFlowUtil.waitForOrderStatusChange(hostOrderObject, "Completed", 80);
    //         });

    //         it('Azure: Verify provisioning of Windows Virtual Machine using Consume UI for Scenario 2', function () {
    //             var newWindowsVMObject = JSON.parse(JSON.stringify(WVMTemplate.Scenario2));
    //              catalogPage.clickFirstCategoryCheckBoxBasedOnName(newWindowsVMObject.Category);
    //              catalogPage.clickConfigureButtonBasedOnName(newWindowsVMObject.bluePrintName);
    //              var servicename = "GSLSLTestAutomation" + util.getRandomString(5);
    //              modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName,"Disk Name": diskName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName,"Host": hostName, "Host Group": hostGroupName, "UpdateMainParamObject":false };
    //              orderFlowUtil.fillOrderDetails(WVMTemplate.Scenario2, modifiedParamMap);
    //              var returnObj = {};
    //              placeOrderPage.submitOrder();
    //              returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
    //              returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
    //              returnObj.servicename = servicename;
    //              expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
    //              placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
    //              orderFlowUtil.approveOrder(returnObj);
    //              orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed', 150);
    //              //deletion for Windows Host VM
    //             var returnObj = {};
    //             returnObj.servicename = servicename;
    //             returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
    //             orderFlowUtil.approveDeletedOrder(returnObj);
    //             orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
    //             expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    //          });
    //     }
    // }
});