"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	runSnowDiscovery = browser.params.runSnowDiscovery,
	vRACentOS76Temp = require('../../../../../../testData/OrderIntegration/ServiceNOW/CloneCentOS76Snow.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('vRA E2E cases for Manual Technical, Financial and Legal approval with Standard change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, sampleOrder1, provOrder, instName, inventoryPage, policyPage, cartListPage;
	var modifiedParamMap = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var serviceName = "SNOWauto"+util.getRandomString(5);
	var policyName = "SNOWautoVRAPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWautoVRAPolicyRule"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var vraCentOSObj = JSON.parse(JSON.stringify(vRACentOS76Temp));
	
	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["VRA"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
								  "Technical":"Manual Approval","Financial":"Manual Approval","Legal":"Manual Approval"};
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":""};
	});
	
	afterAll(function() {

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		policyPage.open();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		policyPage.clickRadioButtonRetiredOption();
		policyPage.clickUpdatePolicyBtn();
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickButtonDeletePolicyText();
		policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

		browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});
	
	it('Set Change Request type to Standard in SNOW', function () {
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Approval Policy for vRA with Manual Technical, Financial, Legal approval and Standard change', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('vRA: Clone_CentOS7.6 ---- Verify Provision functionality with Manual Technical, Financial, Legal approval and Standard change', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			
			//Validations on SNOW Request page before approval
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.approveOrderSNOW(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual(jsonUtil.getValue(vraCentOSObj, "Memory (MB)"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual(jsonUtil.getValue(vraCentOSObj, "CPUs"));
			expect(snowPage.getTextReqItemBOMTotalVRA()).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRA);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickUpdateButton();
			
			//Validation on SNOW for Standard change
			snowPage.openRelatedChangeRequest();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.clickBackButton();			
					
			//Order Completion in SNOW
			//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
		    });		
		});
		
		it('vRA: Clone_CentOS7.6 ---- Verify Edit functionality with Manual Technical, Financial, Legal approval and Standard change', function () {
			
			//Place Order for Edit in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			modifiedParamMap = {"Service Instance Name":"","Team":"","Environment":"","Application":"","Provider Account":"","Memory (MB)":"1024","CPUs":"2"};
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.editService(orderObject);
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			
			//Validations on SNOW Request page before approval
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderType(orderObject)).toBe(vRACentOS76Temp.orderTypeEdit);
			orderFlowUtil.approveOrderSNOW(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestEdit);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual("1024");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual("2");
			expect(snowPage.getTextReqItemBOMTotalVRA()).toBe(snowInstanceTemplate.snowreqItemBOMtotalEditVRA);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickUpdateButton();
			
			//Validation on SNOW for Standard change
			snowPage.openRelatedChangeRequest();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.clickBackButton();			
					
			//Order Completion in SNOW
			//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();			
			});		
		});
	
		if(runSnowDiscovery == "true") {
			it('vRA: Clone_CentOS7.6 ---- Run Discovery for vRA with Manual Technical, Financial, Legal approval and Standard change after Edit, before Turn OFF and verify the VM in SNOW', function () {
				var orderObject = {};
				orderObject.servicename = serviceName;
				snowPage.openDiscoverySchedulesDev();
				snowPage.runDiscoveryForVRA();
				expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				inventoryPage.open();
				inventoryPage.searchOrderByServiceName(orderObject.servicename);
		        inventoryPage.clickExpandFirstRow().then(function() {
			    instName = inventoryPage.getServiceInstanceNameTextVRA();
				instName.then(function(vmName){
					instName = vmName;
					snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
					snowPage.clickRequestedItemLink();
					snowPage.openConfItemServiceInstanceCIs();
					expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
					expect(snowPage.isPresentVMInstanceInCIVRA(vmName)).toBe(true);
					snowPage.clickVMInstanceInCILinkVRA(vmName);
					expect(snowPage.getTextVMCPU()).toBe(snowInstanceTemplate.cpuValue);
					expect(snowPage.getTextVMemory()).toBe(snowInstanceTemplate.memoryValue);
					expect(snowPage.getTextVMInstanceStateVRA()).toBe(snowInstanceTemplate.instanceStateOn);
			        });
				})			
			});
		};
	
		it('vRA: Clone_CentOS7.6 ---- Verify Turn OFF functionality with Manual Technical, Financial, Legal approval and Standard change', function () {
	
	        //Place order for Turn OFF in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            instName = inventoryPage.getServiceInstanceNameTextVRA();
				instName.then(function(vmName){
					instName = vmName;
		            inventoryPage.clickOverflowActionButtonVRA().then(function () {
		                inventoryPage.clickTurnOFFButtonOfInstanceSNOW().then(function () {
		                    inventoryPage.clickOkForInstanceTurnOFFPermission();
		                });
		            });
				});
	        }).then(function () {
	            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
	            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
	            sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            inventoryPage.clickOkForCustomOpnOrderButton();    
		
	            //Validations on SNOW Request page before approval
				snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
				
				//Approve Order in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				orderFlowUtil.approveOrderSNOW(orderObject);
				orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
				expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
				
				//Validations on SNOW Request page after approval in Marketplace
				snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
				expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.serviceOfferingTurnOff);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
	    					
	    		//Validations on SNOW Requested Item page
	    		snowPage.clickRequestedItemLink();
	    		expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
	    		expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
	    		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
	    		expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
	    		expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.serviceOfferingTurnOff);
	    		expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOff);
	    		expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
	    		expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOff);
	    		expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
	    		var serName = snowPage.getTextReqItemVariableServiceName();
	    		serName.then(function(sName){
	    		expect(sName).toContain(serviceName);
	    		expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(instName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("stop");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNA);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsStatusVRA()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				//Validation on SNOW for Standard change
				snowPage.openRelatedChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.clickBackButton();			
						
				//Order Completion in SNOW
				//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
				inventoryPage.open();
		        inventoryPage.searchOrderByServiceName(orderObject.servicename);
		        inventoryPage.clickExpandFirstRow().then(function() {
		        	expect(inventoryPage.getInstancePowerStateStatusVRA(orderObject)).toContain(vRACentOS76Temp.powerStateOff);	          	
	      		});
				
		        //Validations on SNOW Request page after Completion
				snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				//Validations on SNOW RITM page after Completion			
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();			
				});		
	        });
		});
		
		if(runSnowDiscovery == "true") {
			it('vRA: Clone_CentOS7.6 ---- Run Discovery for VRA with Manual Technical, Financial, Legal approval and Standard change after Turn OFF and verify the state of VM in SNOW', function () {
				snowPage.openDiscoverySchedulesDev();
				snowPage.runDiscoveryForVRA();
				expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
				snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
				snowPage.clickRequestedItemLink();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
				expect(snowPage.isPresentVMInstanceInCIVRA(instName)).toBe(true);
				snowPage.clickVMInstanceInCILinkVRA(instName);
				expect(snowPage.getTextVMInstanceStateVRA()).toBe(snowInstanceTemplate.instanceStateOff);			
			});
		};
	
		it('vRA: Clone_CentOS7.6 ---- Verify Turn ON functionality with Manual Technical, Financial, Legal approval and Standard change', function () {
	
	        //Place order for Turn ON in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            instName = inventoryPage.getServiceInstanceNameTextVRA();
				instName.then(function(vmName){
					instName = vmName;
		            inventoryPage.clickOverflowActionButtonVRA().then(function () {
		                inventoryPage.clickTurnONButtonOfInstanceSNOW().then(function () {
		                    inventoryPage.clickOkForInstanceTurnONPermission();
		                });
		            });
				});
	        }).then(function () {
	            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
	            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
	            sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            inventoryPage.clickOkForCustomOpnOrderButton();    
		
	            //Validations on SNOW Request page before approval
				snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
				
				//Approve Order in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				orderFlowUtil.approveOrderSNOW(orderObject);
				orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
				expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
				
				//Validations on SNOW Request page after approval in Marketplace
				snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
				expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.serviceOfferingTurnOn);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
	    					
	    		//Validations on SNOW Requested Item page
	    		snowPage.clickRequestedItemLink();
	    		expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
	    		expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
	    		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
	    		expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
	    		expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.serviceOfferingTurnOn);
	    		expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOn);
	    		expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
	    		expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOn);
	    		expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
	    		var serName = snowPage.getTextReqItemVariableServiceName();
	    		serName.then(function(sName){
	    		expect(sName).toContain(serviceName);
	    		expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(instName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("start");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNA);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsStatusVRA()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				//Validation on SNOW for Standard change
				snowPage.openRelatedChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.clickBackButton();			
						
				//Order Completion in SNOW
				//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
				inventoryPage.open();
		        inventoryPage.searchOrderByServiceName(orderObject.servicename);
		        inventoryPage.clickExpandFirstRow().then(function() {
		        	expect(inventoryPage.getInstancePowerStateStatusVRA(orderObject)).toContain(vRACentOS76Temp.powerStateOn);	          	
	      		});
				
		        //Validations on SNOW Request page after Completion
				snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				//Validations on SNOW RITM page after Completion			
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();				
				});		
	        });
		});
		
		if(runSnowDiscovery == "true") {
			it('vRA: Clone_CentOS7.6 ---- Run Discovery for VRA with Manual Technical, Financial, Legal approval and Standard change after Turn ON and verify the state of VM in SNOW', function () {
				snowPage.openDiscoverySchedulesDev();
				snowPage.runDiscoveryForVRA();
				expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
				snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
				snowPage.clickRequestedItemLink();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
				expect(snowPage.isPresentVMInstanceInCIVRA(instName)).toBe(true);
				snowPage.clickVMInstanceInCILinkVRA(instName);
				expect(snowPage.getTextVMInstanceStateVRA()).toBe(snowInstanceTemplate.instanceStateOn);			
			});
		};
	
		it('vRA: Clone_CentOS7.6 ---- Verify Reboot functionality with Manual Technical, Financial, Legal approval and Standard change', function () {
	
	        //Place order for Reboot in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            instName = inventoryPage.getServiceInstanceNameTextVRA();
				instName.then(function(vmName){
					instName = vmName;
		            inventoryPage.clickOverflowActionButtonVRA().then(function () {
		                inventoryPage.clickRebootButtonOfInstanceSNOW().then(function () {
		                    inventoryPage.clickOkForInstanceRebootPermission();
		                });
		            });
				});
	        }).then(function () {
	            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
	            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
	            sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            inventoryPage.clickOkForCustomOpnOrderButton();    
		
	            //Validations on SNOW Request page before approval
				snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
				
				//Approve Order in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				orderFlowUtil.approveOrderSNOW(orderObject);
				orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
				expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
				
				//Validations on SNOW Request page after approval in Marketplace
				snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
				expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.serviceOfferingReboot);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
	    					
	    		//Validations on SNOW Requested Item page
	    		snowPage.clickRequestedItemLink();
	    		expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
	    		expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
	    		expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
	    		expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
	    		expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.serviceOfferingReboot);
	    		expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescReboot);
	    		expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
	    		expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingReboot);
	    		expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
	    		var serName = snowPage.getTextReqItemVariableServiceName();
	    		serName.then(function(sName){
	    		expect(sName).toContain(serviceName);
	    		expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(instName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("reboot");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				expect(snowPage.getTextReqItemBOMCurrencyBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMTotalBasedOnServiceName(sName)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNA);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsStatusVRA()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				//Validation on SNOW for Standard change
				snowPage.openRelatedChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.clickBackButton();			
						
				//Order Completion in SNOW
				//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
				inventoryPage.open();
		        inventoryPage.searchOrderByServiceName(orderObject.servicename);
		        inventoryPage.clickExpandFirstRow().then(function() {
		        	expect(inventoryPage.getInstancePowerStateStatusVRA(orderObject)).toContain(vRACentOS76Temp.powerStateOn);	          	
	      		});
				
		        //Validations on SNOW Request page after Completion
				snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				//Validations on SNOW RITM page after Completion			
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();				
				});		
	        });
		});
	
		it('vRA: Clone_CentOS7.6 ---- Verify Delete functionality with Manual Technical, Financial, Legal approval and Standard change', function () {
			
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			sampleOrder1 = inventoryPage.getDeleteOrderNumber();
			
			//Validations on SNOW Request page before approval
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(vRACentOS76Temp.orderTypeDel);
			orderFlowUtil.approveDeletedOrderSNOW(orderObject);
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState,50);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickUpdateButton();
			
			//Validation on SNOW for Standard change
			snowPage.openRelatedChangeRequest();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.clickBackButton();			
					
			//Order Completion in SNOW
			//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(vRACentOS76Temp.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();		
			});		
		 });
	  }
	
});
	
	
	
	