
"use strict";

var Orders = require('../../../pageObjects/orders.pageObject.js'),
	HomePage = require('../../../pageObjects/home.pageObject.js'),
	CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	jsonUtil = require('../../../../helpers/jsonUtil.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	persistentDiskTemplate = require('../../../../testData/OrderIntegration/Google/persistentdisk.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled;

describe('GCP - Persistent Disk', function () {
	var ordersPage, homePage, catalogPage, placeOrderPage, inventoryPage, ordersHistoryPage, serviceName;
	var modifiedParamMap = {};
	var messageStrings = {
		providerName: 'Google',
		category: 'Storage',
		orderSubmittedConfirmationMessage: 'Order Submitted !',
		systemTagText: "ibm_mcmp_soiid"
	};

	beforeAll(function () {
		ordersPage = new Orders();
		homePage = new HomePage();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		ordersHistoryPage = new OrderHistoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		// catalogPage.open();
		// expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		// catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
		// catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
		serviceName = "auto-persistentdisk-" + util.getRandomString(5);
		modifiedParamMap = { "Service Instance Name": serviceName };
	});

	it('Google Persistent Disk : Verify Only One service is displaying after searching with servicename', function () {
		catalogPage.open();
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
		catalogPage.searchForBluePrint(persistentDiskTemplate.bluePrintName);
		expect(catalogPage.checkServiceIsPresent(persistentDiskTemplate.bluePrintName)).toEqual(true);
		expect(catalogPage.validateIfOneServiceIsDisplayed()).toEqual(1);
	});

	it('Google Persistent Disk : Verify fields on Main Parameters page are working fine while provisioning a Google persistent disk service', function () {

		catalogPage.clickConfigureButtonBasedOnName(persistentDiskTemplate.bluePrintName);
		expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
		//Verify Service Name is displayed on Main parameter page.						
		placeOrderPage.setServiceNameText(serviceName);
		placeOrderPage.selectProviderAccount(persistentDiskTemplate.providerAccount);
		//Verify Next button is enabled, provider name and category is as per service.
		expect(placeOrderPage.isNextButtonEnabled()).toBe(true);

	});

	it('Google Persistent Disk : Verify Service Details are listed in Review Order page', function () {

		var persistentDiskInsObject = JSON.parse(JSON.stringify(persistentDiskTemplate));
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);

		//Select provider to display related services		
		catalogPage.clickConfigureButtonBasedOnName(persistentDiskTemplate.bluePrintName);
		//Fill order details.
		orderFlowUtil.fillOrderDetails(persistentDiskTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
			expect(requiredReturnMap["Actual"]["Region"]).toEqual(requiredReturnMap["Expected"]["Region"]);
			expect(requiredReturnMap["Actual"]["Zone"]).toEqual(requiredReturnMap["Expected"]["Zone"]);
			expect(requiredReturnMap["Actual"]["Name"]).toEqual(requiredReturnMap["Expected"]["Name"]);
			expect(requiredReturnMap["Actual"]["Source Type"]).toEqual(requiredReturnMap["Expected"]["Source Type"]);
			expect(requiredReturnMap["Actual"]["Disk Type"]).toEqual(requiredReturnMap["Expected"]["Disk Type"]);
			expect(requiredReturnMap["Actual"]["Size (GB)"]).toEqual(requiredReturnMap["Expected"]["Size (GB)"]);
			expect(requiredReturnMap["Actual"]["Disk Mode"]).toEqual(requiredReturnMap["Expected"]["Disk Mode"]);
			expect(requiredReturnMap["Actual"]["Encryption"]).toEqual(requiredReturnMap["Expected"]["Encryption"]);
			if (browser.params.defaultCurrency == "USD") {
				expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(persistentDiskTemplate.TotalCost);
				//BOM Validation as per components of service.
				expect(placeOrderPage.validateBOMOnReviewOrderPage(persistentDiskTemplate.Pricing)).toBe(true);
			}


		});

	});

	fit('Google Persistent Disk : Verify Order Details on Approve order and order history page once order is submitted from catalog page', function () {
		var orderObject = {};
		var orderAmount;
		global.serviceName = serviceName;
		var persistentDiskInsObject = JSON.parse(JSON.stringify(persistentDiskTemplate));

		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
		catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);

		catalogPage.clickConfigureButtonBasedOnName(persistentDiskTemplate.bluePrintName);
		//var servicename = orderFlowUtil.fillOrderDetails(persistentDiskTemplate);
		orderFlowUtil.fillOrderDetails(persistentDiskTemplate, modifiedParamMap);
		placeOrderPage.submitOrder();
		expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
		orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
		placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
		//Service details on Approve Order page
		ordersPage.open();
		//ordersPage.clickordersLink();
		expect(util.getCurrentURL()).toMatch('orders');
		ordersPage.searchOrderById(orderObject.orderNumber);
		expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
		ordersPage.getTextFirstAmountOrdersTable().then(function (text) {
			orderAmount = text;
		});
		ordersPage.clickFirstViewDetailsOrdersTable();
		//orderFlowUtil.waitForOrderStatusChange(orderObject, 'Approval In Progress');
		//Validate Service Instance Name on Order Detail page.
		expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
		//Validate Provider Name on Order Detail page.
		expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
		//Validate Order Status on Order Detail page.
		expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");

		//Validate Approve Button is displayed Order Detail page
		expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
		//Validate Deny Button is displayed Order Detail page
		expect(ordersPage.isPresentDenyButtonOrderDetails()).toEqual(true);
		//Verify details from service configurations tab.		
		expect(ordersPage.getTextBasedOnLabelName("Zone")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Zone"));
		expect(ordersPage.getTextBasedOnLabelName("Region")).toContain(jsonUtil.getValue(persistentDiskInsObject, "Region"));
		//expect(placeOrderPage.getTextBasedOnLabelName("Name")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Name"));
		expect(ordersPage.getTextBasedOnLabelName("Source Type")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Source Type"));
		//expect(ordersPage.getTextBasedOnLabelName("Image")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Image"));
		expect(ordersPage.getTextBasedOnLabelName("Disk Type")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Disk Type"));
		expect(ordersPage.getTextBasedOnLabelName("Size (GB)")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Size (GB)"));
		expect(ordersPage.getTextBasedOnLabelName("Disk Mode")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Disk Mode"));
		expect(ordersPage.getTextBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Encryption"));
		//verify details from Bill of Materials Page.	
		if (browser.params.defaultCurrency == "USD") {
			ordersPage.clickBillOfMaterialsTabOrderDetails().then(function () {
				expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(persistentDiskTemplate.TotalCost);
			});
		}
		//Service details on Order History page
		ordersHistoryPage.open();
		ordersHistoryPage.searchOrderById(orderObject.orderNumber);
		ordersHistoryPage.clickServiceDetailsLink();
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Zone")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Zone"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Region")).toContain(jsonUtil.getValue(persistentDiskInsObject, "Region"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Source Type")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Source Type"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Disk Type")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Disk Type"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Size (GB)")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Size (GB)"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Disk Mode")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Disk Mode"));
		expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(persistentDiskInsObject, "Encryption"));
		if (browser.params.defaultCurrency == "USD") {
			ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
			expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(persistentDiskTemplate.TotalCost);
			ordersHistoryPage.closeServiceDetailsSlider();
			ordersHistoryPage.clickBillOfMaterials();
			expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(persistentDiskTemplate.TotalCost);
		}
		
	});

	if (isProvisioningRequired == "true") {
		var orderObject = {};
		it('Google Persistent Disk : E2E:Verify Google Persistent Disk Order Provisioning is working fine from consume Application', function () {
			var orderId;
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
			catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
			catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);

			catalogPage.clickConfigureButtonBasedOnName(persistentDiskTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			global.serviceName = serviceName;
			orderFlowUtil.fillOrderDetails(persistentDiskTemplate, modifiedParamMap).then(function () {
				//Validate Estimated price.
				if (browser.params.defaultCurrency == "USD") {
					expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(persistentDiskTemplate.TotalCost);
				}	
			});
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(persistentDiskTemplate.bluePrintName, "New");
			//orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			orderId = orderObject.orderNumber;
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
			//Validate pricing onApprove order page
			if (browser.params.defaultCurrency == "USD") {
				expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(persistentDiskTemplate.EstimatedPrice);
			}	
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
				if (status == 'Completed') {
					//Validate pricing on order history page
					ordersHistoryPage.open();
					ordersHistoryPage.searchOrderById(orderObject.orderNumber);
					if (browser.params.defaultCurrency == "USD") {
						expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(persistentDiskTemplate.EstimatedPrice);
					}
					if (isDummyAdapterDisabled == "true") {
						orderObject.componentType = persistentDiskTemplate.componentType;
						inventoryPage.open();
						//Validate service Tags
						inventoryPage.getImiTags(orderObject).then(function (tags) {
							var tagList = tags.split(",");
							var tagMap = inventoryPage.getServiceTags(tagList);
							var mcmpTag = false;
							//if(isDummyAdapterDisabled == "true"){
							if (Object.keys(tagMap).includes(messageStrings.systemTagText)) {
								mcmpTag = true;
							}
							expect(mcmpTag).toBe(true);
							//Verify system tags
							inventoryPage.clickLabelsViewDetailsLink();
							expect(inventoryPage.validateSystemTagValueIsDisplayed()).toBe(true);
							expect(inventoryPage.getSystemTagLabel()).toEqual(messageStrings.systemTagText);
							//}			                 
							expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderObject.orderNumber);
							expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
							expect(tagMap["serviceofferingname"]).toEqual(persistentDiskTemplate.serviceOffrngName);

						});
					}
					orderFlowUtil.closeHorizontalSliderIfPresent();
				}
			});

		});

		it("Google Persistent Disk : Edit and Delete Service instance", function () {
			var modifiedParamMap = { "Service Instance Name": "", "Instance Name": "", "EditService": true, "Size (GB)": "70" };
			serviceName = orderObject.servicename;
			orderFlowUtil.editService(orderObject);
			orderFlowUtil.fillOrderDetails(persistentDiskTemplate, modifiedParamMap).then(function (reviewOrderExpActParamsMap) {
				browser.sleep(5000);
				//Validate Review order page parameters
				expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
			});
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(persistentDiskTemplate.bluePrintName, "Edit");
			//orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();              
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
			placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
				if (status == 'Completed') {
					//Verify updated details are reflected on order details apge.						
					ordersPage.clickFirstViewDetailsOrdersTable();
					expect(ordersPage.getTextBasedOnLabelName("Size (GB)")).toEqual(modifiedParamMap["Size (GB)"]);
					if (isDummyAdapterDisabled == "true") {
						inventoryPage.open();
						//Validate service Tags
						inventoryPage.getImiTags(orderObject).then(function (tags) {
							var tagList = tags.split(",");
							var tagMap = inventoryPage.getServiceTags(tagList);
							var mcmpTag = false;
							//if(isDummyAdapterDisabled == "true"){
							if (Object.keys(tagMap).includes(messageStrings.systemTagText)) {
								mcmpTag = true;
							}
							expect(mcmpTag).toBe(true);
							inventoryPage.clickLabelsViewDetailsLink();
							//Verify system tags
							expect(inventoryPage.validateSystemTagValueIsDisplayed()).toBe(true);
							expect(inventoryPage.getSystemTagLabel()).toEqual(messageStrings.systemTagText);
							//}			                 
							expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderObject.orderNumber);
							expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
							expect(tagMap["serviceofferingname"]).toEqual(persistentDiskTemplate.serviceOffrngName);

						});
					}
					orderFlowUtil.closeHorizontalSliderIfPresent();
					//Delete Service flow
					//orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
					orderFlowUtil.deleteService(orderObject).then(async function (orderNo) {
						orderObject.deleteOrderNumber = orderNo;
						await util.saveOrderId(persistentDiskTemplate.bluePrintName, "Delete", orderNo);
						expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
						orderFlowUtil.approveDeletedOrder(orderObject);
						orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
						expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
					});
				}
			});
		});
	}
});
