/*************************************************
	AUTHOR: Nikitha
 **************************************************/

"use strict";

var OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
HomePage = require('../../../pageObjects/home.pageObject.js'),
DashBoard = require('../../../pageObjects/dashBoard.pageObject.js'),
CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
PolicyPage = require('../../../pageObjects/policy.pageObject.js'),
util = require('../../../../helpers/util.js'),
CartListPage            = require('../../../pageObjects/cartList.pageObject.js'),
orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
jsonUtil = require('../../../../helpers/jsonUtil.js'),
appUrls = require('../../../../testData/appUrls.json'),
budgetaryFlow           = require('../../../../helpers/budgetaryFlow.js'),
budgetDeleteApi         = require('../../../../helpers/budgetDeleteApiUtil.js'),
BudgetaryPage           = require('../../../pageObjects/budget.pageObject.js'),
isProvisioningRequired = browser.params.isProvisioningRequired,
centOs66VRA74Template   = require('../../../../testData/OrderIntegration/VRA/CentOs66VRA74.json'),
policyTemplate = require('../../../../testData/OrderIntegration/policy/policy.json'),
addRulePolicyTemplate = require('../../../../testData/OrderIntegration/policy/addRulePolicy.json'),
credentailsTemplate = require('../../../../testData/credentials.json'),
budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryAddNewBudgetDetails.json');


describe('Tests for VRA Policy E2E Flow: VRA_CentOS66_7.4 - ', function() {
	var ordersPage, homePage, dashBoard, catalogPage, budgetaryUnitCode, placeOrderPage,policyPage,policyName,policyRule,serviceName,policyUpdateSuccessMsg,policyDeleteSuccessMsg,cartListPage,budgetryPage,budgetaryName,budgetaryNewBudgetName; 
    var modifiedParamMap={};
    var modifiedParamMapAddRule={};
    var modifiedParamMapBudget={};
    var modifiedNewBudgetParamMap={};
	var messageStrings = {
		providerName:                      centOs66VRA74Template.providerName,
        estimatedPrice:                    centOs66VRA74Template.estimatedPrice,
        orderSubmittedConfirmationMessage: centOs66VRA74Template.orderSubmittedConfirmationMessage,
        providerAccount:                   centOs66VRA74Template.providerAccount,
        calculatedEstAmount:               centOs66VRA74Template.calculatedEstAmount,
        budgetSpendAmmount:                centOs66VRA74Template.budgetSpendAmmount,
        completed:                         centOs66VRA74Template.completed,
        policyUpdateSuccessMsg:            policyTemplate.policyUpdateSuccessMsg, 
        policyDeleteSuccessMsg:            policyTemplate.policyDeleteSuccessMsg,
        policypolicyBuyerUserID:           centOs66VRA74Template.policypolicyBuyerUserID, 
        policypolicyBuyerUserName:         centOs66VRA74Template.policypolicyBuyerUserName,
        policypolicyBuyerUserPassword:     centOs66VRA74Template.policypolicyBuyerUserPassword,
        superUserUsername:                 credentailsTemplate.superUserUsername,
        superUserPassword:                 credentailsTemplate.superUserPassword,
        policyRetiredStatus:               policyTemplate.policyTemplate,
        policyActiveStatus:                policyTemplate.policyActiveStatus,
        budgetaryUnitDeletedApiSucessMsg:  budgetaryUnitDetailsTemplate.budgetaryUnitDeletedApiSucessMsg,
        budgetDeletedApiSucessMsg:         budgetaryUnitDetailsTemplate.budgetDeletedApiSucessMsg
		};
	var centOs66VRA74TemplateObj = JSON.parse(JSON.stringify(centOs66VRA74Template));
	beforeAll(function() {
		ordersPage = new OrdersPage();
		policyPage = new PolicyPage();
		homePage = new HomePage(); 
		dashBoard = new DashBoard();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		budgetryPage = new BudgetaryPage();
		browser.driver.manage().window().maximize();
		serviceName = "policyauto" + util.getRandomString(5);
		policyName = "policy"+util.getRandomString(4);
		policyRule = "rulePolicy"+util.getRandomString(4);
		modifiedParamMap = {"policy Name":policyName};
		modifiedParamMapAddRule = {"Add Rule Name":policyRule};
		budgetaryName = "budgetaryName"+util.getRandomString(8);
		budgetaryNewBudgetName = "budgetaryNewBudgetName"+util.getRandomString(8);
		budgetaryUnitCode = "budgetaryUnitCode"+util.getRandomString(8);
        modifiedParamMapBudget = {"budgetary Name":budgetaryName, "budgetary unit code":budgetaryUnitCode,"Choose Entity": "Organization","Entity Value": "MYORG","Environment": "policyEnv", "Application": "policyApp"};
		
	});

	beforeEach(function() {
	
	});

  	it('Add Policy', function () {
		policyPage.open();
		policyPage.clickAddNewPolicyBtn();
		policyPage.selectStartDate();
		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMap);
		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
		policyPage.clickApplyRulePolicyBtn();
		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRule);
		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRule);
		browser.sleep(2000);
		policyPage.clickCreatePolicyButton();
		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
		expect(policyNameInPolicyTable).toEqual(policyName);
	});
  	
    it('Add new budgetry Unit for E2E budget Flow ', function () {
    	budgetryPage.clickBudgetTab();
    	var budgetaryObject = JSON.parse(JSON.stringify(budgetaryUnitDetailsTemplate));
    	var budgetaryObject = JSON.parse(JSON.stringify(budgetaryAddNewBudgetDetailsTemplate));
    	util.waitForAngular();    
    	budgetryPage.clickOnAddNewBudgetryUnitBtn();
    	budgetryPage.fillPolicyDetails(budgetaryUnitDetailsTemplate, modifiedParamMapBudget);
    	budgetryPage.clickOnBudgetrySaveBtn();
    	budgetryPage.clickOnBudgetryBudgetsLink();
    	budgetryPage.clickOnBudgetaryAddBudgetButton();
    	var startPeriod = budgetaryFlow.incrementMonth(0); //Zero (0) for current month
    	var endPeriod = budgetaryFlow.incrementMonth(2); //two (2) for Quarterly
    	modifiedNewBudgetParamMap = {"Name":budgetaryNewBudgetName, "Start Period":startPeriod, "End Period":endPeriod};
    	budgetryPage.fillPolicyDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);		
    	budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
    	budgetryPage.clickOnBudgetaryBackBudgetButton();
    });
  	
	
	if (isProvisioningRequired == "true") {
	  it('CentOS_VRA7.4- Verify the Policy E2E flow -AUT-606', function () {
		catalogPage.open()
	    var orderObject = {};
        var availBudgetProvCompleted, afterProvCommittedAmnt, beforeProvisioningAvailBudget;
        modifiedParamMap = {"Service Instance Name":serviceName,"Team":"policyTEAM1","Environment": "policyEnv", "Application": "policyApp","Provider Account":"policyAcc7.4 / policyAcc7.4","CentOS66 disks":"","Capacity":"","Label":"","User Created":"","Volume ID":"","CentOS66 disk":""};
        // Logout from Super User
        cartListPage.clickUserIcon();
        cartListPage.clickLogoutButton();
        browser.sleep(5000);
      
        // Login as User with Buyer role and place order
        cartListPage.loginFromOtherUser(centOs66VRA74TemplateObj.policyBuyerUserID, centOs66VRA74TemplateObj.policyBuyerUserPassword);
        catalogPage.open();
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(centOs66VRA74TemplateObj.Category);
      
        catalogPage.searchForBluePrint(centOs66VRA74TemplateObj.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(centOs66VRA74TemplateObj.bluePrintName);
	
        orderObject.servicename = serviceName;
      
        // Submit order through Buyer role user
        orderFlowUtil.fillPolicyDetails(centOs66VRA74Template, modifiedParamMap).then(async function (requiredReturnMap) {
      	placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
          
        // Get details from popup after submit
        var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        var orderprice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
        var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
          
        expect(ordersubmittedBy).toEqual(centOs66VRA74TemplateObj.policyBuyerUserName);
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
          
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
          
        // Logout from Buyer role user
        cartListPage.clickUserIcon();
        cartListPage.clickLogoutButton();
                      
        // Login as User with Technical Approver role for which orders
		// are AutoApproved and status moved to completed
        cartListPage.loginFromOtherUser(centOs66VRA74TemplateObj.technicalApprovalUserID, centOs66VRA74TemplateObj.technicalApprovalUserPass);
        orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completed);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completed);
         
        // Check budget is not displayed since user has Technical
		// Approver role only
        await expect(ordersPage.checkInvisibilityOfBudgetDetails()).toBe(false, "For technically approval role user Budget details is not present on the Approve order page.");
          
        // Logout from Technical approver user
        cartListPage.clickUserIcon();
        cartListPage.clickLogoutButton();
          
        // Login as User with Financial Approver role
        cartListPage.loginFromOtherUser(centOs66VRA74TemplateObj.financialApprovalUserID, centOs66VRA74TemplateObj.financialApprovalUserPass);
        ordersPage.open();
        util.waitForAngular();
          
        // AutoApproved and status moved to completed for financial
		// approver
        orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completed).then(function () {
        // expect(ordersPage.getTextBudgetNameInApproveOrder()).tobe(budgetaryName);
                        	
        });
        // browser.ignoreSynchronization = false;
        ordersPage.open();
          
        // Logout from Financial approver user
        cartListPage.clickUserIcon();
        cartListPage.clickLogoutButton();
          
        // Login as User with Buyer role
        cartListPage.loginFromOtherUser(centOs66VRA74TemplateObj.policyBuyerUserID, centOs66VRA74TemplateObj.policyBuyerUserPassword);
          
        // Place deleteOrder from Buyer role user
        orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
          
        // Logout from Buyer role user
        catalogPage.open();
        cartListPage.clickUserIcon();
        cartListPage.clickLogoutButton();
          
        // Login as User with Technical Approver role to approve
		// deleteOrder
        cartListPage.loginFromOtherUser(centOs66VRA74TemplateObj.technicalApprovalUserID, centOs66VRA74TemplateObj.technicalApprovalUserPass);
        orderFlowUtil.approveDeletedOrderTechnically(orderObject);
          
        // Logout from Technical approver user
        cartListPage.clickUserIcon();
        cartListPage.clickLogoutButton();
          
        // Login as User with Financial Approver role
        cartListPage.loginFromOtherUser(centOs66VRA74TemplateObj.financialApprovalUserID, centOs66VRA74TemplateObj.financialApprovalUserPass);
        orderFlowUtil.approveDeletedOrderFinancially(orderObject);
        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completed);
        // Logout from Financial approver role user
        cartListPage.clickUserIcon();
        cartListPage.clickLogoutButton();
          
        // Login with Super User
        cartListPage.loginFromOtherUser(messageStrings.superUserUsername, messageStrings.superUserPassword);
        catalogPage.open();
        expect(catalogPage.extractUserFirstName()).toEqual(centOs66VRA74TemplateObj.superUserName);
                
          
       });	
  		
  	});		
  }
	
	it('Delete the created policy', function () {
		policyPage.open();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		policyPage.clickRadioButtonRetiredOption();
		policyPage.clickUpdatePolicyBtn();
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.updatePolicySuccessMsg+" "+policyName+" successfully");
		var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		expect(policyStatusInPolicy).toEqual(messageStrings.retiredPolicyStatus);
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickButtonDeletePolicyText();
		policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		util.waitForAngular();
		policyPage.clickNotificationCloseButton();
		browser.sleep(2000);
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.deletePolicySuccessMsg+" "+policyName+" successfully");
	});
	
	 it('Making above created budget Inactive', function () {  
	        budgetryPage.open();
	    	budgetryPage.selectbudgetaryPaginationDropDown();
	    	budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
	    	budgetryPage.clickOnBudgetryBudgetsLink();
	    	budgetryPage.clickViewDetailActionIcon();
	    	budgetryPage.clickViewDetailBtn();
	    	budgetryPage.clickBudgetEditButton();
	    	budgetryPage.clickBudgetInactiveStatusText();
	    	budgetryPage.clickSaveBudgetButton();
	    	budgetryPage.clickOnNotificationCloseButton();
	    	budgetryPage.clickAfterEditingBudgetaryBackButton();
	    	budgetryPage.clickOnBudgetryDetailsLink();
	        });
	    
	    afterAll(async function () {
			await budgetDeleteApi.getListOfBudegetaryUnit(budgetaryName).then(async function (budget) {
	    	logger.info("budget details"+budget);
	    	await budgetDeleteApi.deleteInActiveBudget(budget["budgetcode"],budget["id"]).then(async function (status) {
			expect(status).toEqual(messageStrings.budgetDeletedApiSucessMsg);
			await budgetDeleteApi.deleteBudetaryUnit(budget["budgetcode"]).then(async function (status) {
			expect(status).toEqual(messageStrings.budgetaryUnitDeletedApiSucessMsg);
	    		});
			});
		});
	  });
});
