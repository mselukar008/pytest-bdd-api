/*************************************************
Spec_Name: alicloudDNS.spec.js
Description: This spec will cover E2E testing of Alicloud DNS service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".     
Author: Leena chouhan
**************************************************/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    DNSTemplate = require('../../../../testData/OrderIntegration/Alibaba/AlicloudDNS.json')

describe('Alibaba: Test cases for Alicloud DNS in detail', function () {
    var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage, homePage;
    var modifiedParamMap = {};
    var modifiedParamMapedit = {};
    var messageStrings = {
        providerName: 'Alibaba Cloud',
        category: 'Network'
    };
    var servicename = "GSLAutoDNS" + util.getRandomString(5);

    beforeAll(function () {
        homePage = new HomePage();
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        modifiedParamMap = {
            "Service Instance Name": servicename,
        };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });


    afterAll(function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    if (isProvisioningRequired == "true") {
        it('Aalibaba: TC-1 Verify that for Alicloud DNS Service,if service created with existing Domain name and new record', function () {
            var modifiedParamMapEditForNegativeScenario = {
                "EditService": true,
                "UpdateMainParamObject": false
            };
            var returnObj = {};
            var returnObjForEdit = {};
            var editServiceObj = JSON.parse(JSON.stringify(DNSTemplate.negativeScenarioForEditService));
            var orderObject = JSON.parse(JSON.stringify(DNSTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            orderFlowUtil.fillOrderDetails(DNSTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, orderObject.OrderStatus);

            //checking order on Inventory Page 
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();

            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
            expect(inventoryPage.getTextBasedOnLabelName(" Add Domain:")).toEqual(jsonUtil.getValue(orderObject, "Add Domain"));
            expect(inventoryPage.getTextBasedOnLabelName(" Existing Domain Name:")).toEqual(jsonUtil.getValue(orderObject, "Existing Domain Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Add Record:")).toEqual(jsonUtil.getValue(orderObject, "Add Record"));
            expect(inventoryPage.getTextBasedOnLabelName(" Type:")).toEqual(jsonUtil.getValue(orderObject, "Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" Host:")).toEqual(jsonUtil.getValue(orderObject, "Host"));
            expect(inventoryPage.getTextBasedOnLabelName(" ISP Line:")).toEqual(jsonUtil.getValue(orderObject, "ISP Line"));
            expect(inventoryPage.getTextBasedOnLabelName(" Value:")).toEqual(jsonUtil.getValue(orderObject, "Value"));
            expect(inventoryPage.getTextBasedOnLabelName(" TTL:")).toEqual(jsonUtil.getValue(orderObject, "TTL"));
            inventoryPage.closeViewDetailsTab();

            //Edit order flow
            modifiedParamMapedit = {
                "EditService": true,
                "UpdateMainParamObject": false
            };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickEditServiceIcon();
            inventoryPage.clickNextButton();
            orderFlowUtil.fillOrderDetails(editServiceObj, modifiedParamMapEditForNegativeScenario);
            placeOrderPage.EditsubmitOrder();
            placeOrderPage.clickOnNotificationCloseButton();
            placeOrderPage.clickPreviousButton();
            placeOrderPage.clickPreviousButton();
            placeOrderPage.clickPreviousButton();
            orderFlowUtil.fillOrderDetails(DNSTemplate, modifiedParamMapedit);
            placeOrderPage.submitOrder();
            returnObjForEdit.servicename = servicename;
            returnObjForEdit.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObjForEdit.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
            expect(orderFlowUtil.verifyOrderType(returnObjForEdit)).toBe('EditSOI');
            orderFlowUtil.approveOrder(returnObjForEdit);
            orderFlowUtil.waitForOrderStatusChange(returnObjForEdit, 'Completed', 50);
            homePage.open();
        });
    }

    it('Aalibaba: TC-2 verify that for Alicloud DNS Service all parameters on Main Parameters Page are present.', function () {
        var orderObject = JSON.parse(JSON.stringify(DNSTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);

        expect(catalogDetailsPage.getServiceName()).toBe(orderObject.bluePrintName)
        expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true);
        expect(catalogDetailsPage.isPresentLinkToProviderSite()).toBe(true);
        expect(catalogDetailsPage.isPresentFeaturesLabel()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsLabel()).toBe(true);
        expect(catalogDetailsPage.getTextFeaturesLabel()).toBe(orderObject.FeaturesLabel);
        expect(catalogDetailsPage.getTextDetailsLabel()).toBe(orderObject.DetailsLabel);
        expect(catalogDetailsPage.isPresentFeaturesInfo()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsInfo()).toBe(true);
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);

        catalogDetailsPage.clickCatalogFromBreadCrumbNav();
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
        homePage.open();
    });

    it('Aalibaba: TC-3 verify that for Alicloud DNS Service all parameters on Review Order page matches with input.', function () {
        var orderObject = JSON.parse(JSON.stringify(DNSTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderObject.servicename = servicename;
        orderFlowUtil.fillOrderDetails(DNSTemplate, modifiedParamMap);

        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(orderObject.servicename);
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);

        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Add Domain:")).toEqual(jsonUtil.getValue(orderObject, "Add Domain"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Existing Domain Name:")).toEqual(jsonUtil.getValue(orderObject, "Existing Domain Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Add Record:")).toEqual(jsonUtil.getValue(orderObject, "Add Record"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Type:")).toEqual(jsonUtil.getValue(orderObject, "Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Host:")).toEqual(jsonUtil.getValue(orderObject, "Host"));
        expect(placeOrderPage.getTextBasedOnLabelName(" ISP Line:")).toEqual(jsonUtil.getValue(orderObject, "ISP Line"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Value:")).toEqual(jsonUtil.getValue(orderObject, "Value"));
        expect(placeOrderPage.getTextBasedOnLabelName(" TTL:")).toEqual(jsonUtil.getValue(orderObject, "TTL"));
        homePage.open();
    });

    it('Aalibaba: TC-4 verify that for Alicloud DNS Service all values on View Order Details page matches with input.', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(DNSTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(DNSTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();

        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);

        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("Region")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(ordersPage.getTextBasedOnExactLabelName("Add Domain")).toEqual(jsonUtil.getValue(orderObject, "Add Domain"));
        expect(ordersPage.getTextBasedOnExactLabelName("Existing Domain Name")).toEqual(jsonUtil.getValue(orderObject, "Existing Domain Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Add Record")).toEqual(jsonUtil.getValue(orderObject, "Add Record"));
        expect(ordersPage.getTextBasedOnExactLabelName("Type")).toEqual(jsonUtil.getValue(orderObject, "Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("Host")).toEqual(jsonUtil.getValue(orderObject, "Host"));
        expect(ordersPage.getTextBasedOnExactLabelName("ISP Line")).toEqual(jsonUtil.getValue(orderObject, "ISP Line"));
        expect(ordersPage.getTextBasedOnExactLabelName("Value")).toEqual(jsonUtil.getValue(orderObject, "Value"));
        expect(ordersPage.getTextBasedOnExactLabelName("TTL")).toEqual(jsonUtil.getValue(orderObject, "TTL"));

        //Checking Bill Of Material
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(placeOrderPage.getTotalCost()).toBe(orderObject.TotalCost);

        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
        orderFlowUtil.denyOrder(returnObj);
    });
});