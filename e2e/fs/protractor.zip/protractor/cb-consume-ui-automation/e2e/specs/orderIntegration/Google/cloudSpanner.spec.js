"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'), 
    defaultCurrency = browser.params.defaultCurrency,
    gcpCloudSpannerTemplate = require('../../../../testData/OrderIntegration/Google/gcpCloudSpanner.json');

describe('GCP - Cloud Spanner', function () {
    var ordersPage, homePage, catalogPage, placeOrderPage, serviceName;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: 'Google',
        category: 'Databases',       
        orderSubmittedConfirmationMessage: 'Order Submitted !',
    };

    beforeAll(function () {
        ordersPage = new Orders();
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(gcpCloudSpannerTemplate.bluePrintName);
        serviceName = "auto-cloudSpanner-" + util.getRandomString(5);
        global.serviceName = serviceName;
        modifiedParamMap = { "Service Instance Name": serviceName };
    });

    it('GCP Spanner - Verify fields on Main Parameters page is working fine', function () {    
        
        expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);       
        placeOrderPage.setServiceNameText(serviceName);
        placeOrderPage.selectProviderAccount(gcpCloudSpannerTemplate["Order Parameters"]["Main Parameters"]["Provider Account"]["value"]["QA 4"]);
        expect(placeOrderPage.isNextButtonEnabled()).toBe(true);       
    });

    it('GCP Spanner - Verify Summary details and Additional Details are listed in review Order page', function () {
       
        orderFlowUtil.fillOrderDetails(gcpCloudSpannerTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            
            expect(requiredReturnMap["Actual"]["Instance name"]).toEqual(requiredReturnMap["Expected"]["Instance name"]);
            expect(requiredReturnMap["Actual"]["Instance ID"]).toEqual(requiredReturnMap["Expected"]["Instance ID"]);
            expect(requiredReturnMap["Actual"]["Configuration"]).toEqual(requiredReturnMap["Expected"]["Configuration"]);
            expect(requiredReturnMap["Actual"]["Location (Regional)"]).toEqual(requiredReturnMap["Expected"]["Location (Regional)"]);
            expect(requiredReturnMap["Actual"]["Nodes"]).toEqual(requiredReturnMap["Expected"]["Nodes"]);
            if (defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(gcpCloudSpannerTemplate.TotalCost); 
                //BOM Validation as per components of service.
                expect(placeOrderPage.validateBOMOnReviewOrderPage(gcpCloudSpannerTemplate.Pricing)).toBe(true);
            }    
         });
    });

    it('GCP Spanner - Verify Order is listed in Orders details page once it is submitted from catalog page', function () {
        var orderObject = {};	   
        var NetworkINSObject = JSON.parse(JSON.stringify(gcpCloudSpannerTemplate));      
        orderFlowUtil.fillOrderDetails(gcpCloudSpannerTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();      
        expect(util.getCurrentURL()).toMatch('orders');
        ordersPage.searchOrderById(orderObject.orderNumber);
        expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);        
        ordersPage.clickFirstViewDetailsOrdersTable();       
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);        
        expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");        
        expect(ordersPage.getTextOrderTypeOrderDetails()).toEqual("New");        
        expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);               
        expect(ordersPage.getTextBasedOnLabelName("Instance name")).toEqual(jsonUtil.getValue(NetworkINSObject, "Instance name"));
        expect(ordersPage.getTextBasedOnLabelName("Instance ID")).toEqual(jsonUtil.getValue(NetworkINSObject,"Instance ID"));
        expect(ordersPage.getTextBasedOnLabelName("Configuration")).toEqual(jsonUtil.getValue(NetworkINSObject, "Configuration"));
        expect(ordersPage.getTextBasedOnLabelName("Location (Regional)")).toContain(jsonUtil.getValue(NetworkINSObject, "Location (Regional)"));
        expect(ordersPage.getTextBasedOnLabelName("Nodes")).toEqual(jsonUtil.getValue(NetworkINSObject, "Nodes"));
        
        //Verify estimated price
        if (defaultCurrency == "USD") {
            ordersPage.clickBillOfMaterialsTabOrderDetails().then(function () {
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(NetworkINSObject.TotalCost);
                ordersPage.clickServiceDetailSliderCloseButton();
            });
        }
        orderFlowUtil.denyOrder(orderObject);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Rejected');   
             
    });

})
