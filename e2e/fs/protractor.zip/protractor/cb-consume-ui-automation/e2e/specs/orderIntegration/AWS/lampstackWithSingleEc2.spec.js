"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../helpers/logGenerator.js"),
    appUrls = require('../../../../testData/appUrls.json'),
    shoppingCartTemplate = require('../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
    imiConfigTemplate = require('../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    ec2InstanceTemplate = require('../../../../testData/OrderIntegration/AWS/lampstackWithSIngleEc2.json');

describe('AWS - Lampstack With Single EC2', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, keyPairName, EC2INSObject, inventoryPage, msgToVerify;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = ec2InstanceTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-ec2lampstack-" + util.getRandomString(5);
        keyPairName = "ec2lampstack" + util.getRandomString(5);
    });

    beforeEach(function () {
        modifiedParamMap = { "Service Instance Name": serviceName, "Key Pair Name": keyPairName };
    });

    it('AWS-LampstackEc2 - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        catalogPage.open();
        EC2INSObject = JSON.parse(JSON.stringify(ec2InstanceTemplate));
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(ec2InstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(ec2InstanceTemplate.TotalCost); expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            }
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Instance Type"]).toEqual(requiredReturnMap["Expected"]["Instance Type"]);
            expect(requiredReturnMap["Actual"]["VPC"]).toEqual(requiredReturnMap["Expected"]["VPC"]);
            expect(requiredReturnMap["Actual"]["Key Pair Name"]).toEqual(keyPairName);
            expect(requiredReturnMap["Actual"]["SSHLocation"]).toEqual(requiredReturnMap["Expected"]["SSH Location"]);
            expect(requiredReturnMap["Actual"]["DBName"]).toEqual(requiredReturnMap["Expected"]["DBName"]);
            expect(requiredReturnMap["Actual"]["DBUser"]).toEqual(requiredReturnMap["Expected"]["DBUser"]);

            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                if (browser.params.defaultCurrency == "USD") {
                    //Validate Estimated price on approve order page
                    expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(ec2InstanceTemplate.EstimatedPrice);
                    //Validate pricing on order history page
                    ordersHistoryPage.open();
                    ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                    expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(ec2InstanceTemplate.EstimatedPrice);
                }
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();

            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Key Pair Name")).toEqual(keyPairName);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("SSHLocation")).toEqual(jsonUtil.getValue(EC2INSObject, "SSH Location"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(EC2INSObject, "VPC"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DBName")).toEqual(jsonUtil.getValue(EC2INSObject, "DBName"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DBUser")).toEqual(jsonUtil.getValue(EC2INSObject, "DBUser"));
            if (browser.params.defaultCurrency == "USD") {
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(ec2InstanceTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(ec2InstanceTemplate.TotalCost);
            }
            ordersHistoryPage.closeServiceDetailsSlider();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            expect(ordersPage.getTextBasedOnLabelName("Key Pair Name")).toEqual(keyPairName);
            expect(ordersPage.getTextBasedOnLabelName("SSHLocation")).toEqual(jsonUtil.getValue(EC2INSObject, "SSH Location"));
            expect(ordersPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(EC2INSObject, "VPC"));
            expect(ordersPage.getTextBasedOnExactLabelName("DBName")).toEqual(jsonUtil.getValue(EC2INSObject, "DBName"));
            expect(ordersPage.getTextBasedOnLabelName("DBUser")).toEqual(jsonUtil.getValue(EC2INSObject, "DBUser"));
            if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(ec2InstanceTemplate.TotalCost);
            }
            ordersPage.clickServiceDetailSliderCloseButton();
        });
    });

    it('AWS-LampstackEc2 With SingleInstance-Verify Website URL', function () {
        if (isDummyAdapterDisabled == "true") {
            //Validate Service Details on Inventory Page            
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();
            expect(inventoryPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "AWS Region"));
            expect(inventoryPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "Instance Type"));
            expect(inventoryPage.getTextBasedOnLabelName("SSHLocation")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "SSH Location"));
            expect(inventoryPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "VPC"));
            expect(inventoryPage.getTextBasedOnLabelName("DBName")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "DBName"));
            expect(inventoryPage.getTextBasedOnLabelName("DBUser")).toEqual(jsonUtil.getValue(ec2InstanceTemplate, "DBUser"));
            expect(inventoryPage.getTextBasedOnLabelName("Key Pair Name")).toEqual(keyPairName);

            inventoryPage.getWebSiteUrl("WebsiteURL").then(function (webUrl) {
                //open url in new tab and check if website is displaying
                browser.executeScript("window.open()");
                return browser.getAllWindowHandles().then(function (handles) {
                    const newWindowHandle = handles[1];
                    browser.switchTo().window(newWindowHandle);
                    browser.get(webUrl).then(function () {
                        util.waitForAngular();
                        expect(inventoryPage.getEc2ServerHeading()).toEqual(ec2InstanceTemplate.ec2ServerMsg);
                        browser.close();
                        util.switchToParentWindow();
                        //util.switchToChildWindow();
                        util.switchToFrame();
                    });
                });
            });
            // Validate BOM (Inventory Page)
            if (browser.params.defaultCurrency == "USD") {
                inventoryPage.clickBomTab();
                expect(inventoryPage.getTextEstimatedCost()).toEqual(ec2InstanceTemplate.TotalCost);
                //Validate order history tab
                inventoryPage.clickOrderHistorTab();
                //expect(inventoryPage.getTextOrderIdOnOrderHistory()).toEqual(orderObject.orderNumber);
                expect(inventoryPage.getTextNewOperationType()).toEqual(ec2InstanceTemplate.newOrderType);
                expect(inventoryPage.getTextOrderStatus()).toEqual(messageStrings.completedState)
                expect(inventoryPage.getTextEstimatedCostOnOrderHistory()).toEqual(ec2InstanceTemplate.TotalCost);
                inventoryPage.closeViewComponent();
            }
        }
    });

    it('AWS LampstackEc2 - Validate system tags, Edit and Delete Service', function () {
        //Validate service Tags        
        orderFlowUtil.closeHorizontalSliderIfPresent();
        inventoryPage.open();
        if (isDummyAdapterDisabled == "false") {
            orderObject.componentType = "Applications";
        }
        inventoryPage.getImiTags(orderObject).then(function (tags) {
            var tagList = tags.split(",");
            var tagMap = inventoryPage.getServiceTags(tagList);
            var mcmpTag = false;
            if (isDummyAdapterDisabled == "false") {
                //verifying flags for dummy adapter
                expect(tagMap["IsUsingDummy"]).toEqual("Yes");
                expect(tagMap["Name"]).toEqual(ec2InstanceTemplate.bluePrintName);
                expect(tagMap["PhysicalId"]).toContain(serviceName);
                expect(Object.keys(tagMap).includes("Test")).toBe(true);
                expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
            } else {
                //verifying a system tag
                expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                //verifying some of the service tags
                expect(tagList.includes(tagList.find(tag => tag.includes("stackId:arn:aws:cloudformation")))).toBe(true);
                expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:logical-id")))).toBe(true);
                expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-id")))).toBe(true);
                expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-name")))).toBe(true);
                expect(tagMap["serviceInstanceName"].toLowerCase()).toContain(serviceName.toLowerCase());
            }
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Edit service flow
            var modifiedParamMap = { "EditService": true };
            orderFlowUtil.editService(orderObject);
            orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap).then(function (reviewOrderExpActParamsMap) {
                //logger.info("Edit parameter details are filled.");
                if (browser.params.defaultCurrency == "USD") {
                    expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(ec2InstanceTemplate.TotalCostPostEdit);
                }
            });
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "Edit");
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == 'Completed') {
                    //Verify updated details are reflected on order details page.						
                    ordersPage.clickFirstViewDetailsOrdersTable();
                    expect(ordersPage.getTextBasedOnLabelName("SSHLocation")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "SSH Location"));
                    expect(ordersPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Instance Type"));
                    expect(ordersPage.getTextBasedOnLabelNameandIndex("Key", 2)).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Key"));
                    expect(ordersPage.getTextBasedOnLabelName("Value")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Value"));
                    if (browser.params.defaultCurrency == "USD") {
                        ordersPage.clickBillOfMaterialsTabOrderDetails();
                        expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(ec2InstanceTemplate.TotalCostPostEdit);
                    }
                    ordersPage.clickServiceDetailSliderCloseButton();
                    //Delete Service flow                    
                    orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, ec2InstanceTemplate.bluePrintName);
                    //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                    orderFlowUtil.approveDeletedOrder(orderObject);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
                }
            });

        });

    });

});
