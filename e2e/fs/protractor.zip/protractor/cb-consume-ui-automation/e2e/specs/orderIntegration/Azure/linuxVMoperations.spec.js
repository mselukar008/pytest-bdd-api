/*
Spec_Name: linuxVMoperations.spec.js 
Description: This spec will cover Operations Off, On and Reboot on Azure Linux Virtual Machine
Author: Moti Prasad Ale
*/

"use strict";

var EC = protractor.ExpectedConditions,
    logGenerator = require("../../../../helpers/logGenerator.js"),
    Logger = logGenerator.getApplicationLogger(),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    newLinuxVMTemplate = require('../../../../testData/OrderIntegration/Azure/linuxVMoperations.json'),
    async = require('async'),
    testEnvironment = browser.params.url;


describe('Azure - Linux Virtual Machine Operations', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, servicename, diskName;
    var modifiedParamMap = {};
    var newResourceGroupName = "gslautotc_azureWVM-RG101" + util.getRandomString(4);
    var newVmName = "auto-VM101" + util.getRandomString(4);
    var newNetworkName = "auto-VN101" + util.getRandomString(4);
    var newSubnetName = "auto-SN101" + util.getRandomString(4);
    var newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
    var newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
    var newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
    var newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
    var newStorageAccountName = "AutoWVM-RG101" + util.getRandomString(4);
    var computeComponent = "shutdown-computevm-" + newVmName;
    var messageStrings = {
        providerName: 'Azure', category: 'Compute', catalogPageTitle: 'Search, Select and Configure',
        orderSubmittedConfirmationMessage: newLinuxVMTemplate.orderSubmittedConfirmationMessage,
        provInProgressState: newLinuxVMTemplate.provInProgressState,
        completedState: newLinuxVMTemplate.completedState,
        powerStateOff: newLinuxVMTemplate.powerStateOff,
        powerStateOn: newLinuxVMTemplate.powerStateOn,
        orderTypeAction: newLinuxVMTemplate.orderTypeAction,
        turnOnNegativeWarning: newLinuxVMTemplate.turnOnNegativeWarning,
        turnOffNegativeWarning: newLinuxVMTemplate.turnOffNegativeWarning,
        rebootNegativeWarning: newLinuxVMTemplate.rebootNegativeWarning,
        turnOn: newLinuxVMTemplate.turnOn,
        turnOff: newLinuxVMTemplate.turnOff,
        reboot: newLinuxVMTemplate.reboot

    };
    var newLinuxVMObject = JSON.parse(JSON.stringify(newLinuxVMTemplate.Scenario1));
    var SOIComponents
    servicename = "AzlinvmOp" + util.getRandomString(4);
    var returnObj = {};
    returnObj.servicename = servicename;
    var modifiedParamMapedit = {};

    beforeAll(function () {
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();

    });

    afterAll(function () {
        //Delete Linux VM
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, messageStrings.provInProgressState);


    });

    beforeEach(function () {
        newResourceGroupName = "gslautotc_azureLVM-RG101" + util.getRandomString(4);
        newVmName = "auto-VM101" + util.getRandomString(4);
        newNetworkName = "auto-VN101" + util.getRandomString(4);
        newSubnetName = "auto-SN101" + util.getRandomString(4);
        newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
        newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
        newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
        newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
        newStorageAccountName = "autosan" + util.getRandomString(4);
        newStorageAccountName = newStorageAccountName.toLocaleLowerCase();
        diskName = "autodisk" + util.getRandomString(4);
        diskName = diskName.toLocaleLowerCase();
        computeComponent = "shutdown-computevm-" + newVmName;
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Disk Name": diskName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName };
        SOIComponents = [newNetworkName, newPublicIpName, newnetworkSecurityGroupName, newNetworkInterfaceName, computeComponent, newVmName, diskName]
    });

    if (isProvisioningRequired == "true") {
        it('Azure: TC-T395763-Sanity Verify provisioning of Linux Virtual Machine using Consume UI for Scenario 1', function () {
            var orderObject = {};
            var returnObj1 = {};
            catalogPage.open();
            catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(newLinuxVMObject.Category);
            catalogPage.searchForBluePrint(newLinuxVMObject.bluePrintName);
            catalogPage.clickConfigureButtonBasedOnName(newLinuxVMObject.bluePrintName);
            orderObject.servicename = servicename;
            orderFlowUtil.fillOrderDetails(newLinuxVMTemplate.Scenario1, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState, 50);
            //Checking SOI Components
            if (isDummyAdapterDisabled == "true") {
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    browser.executeScript('window.scrollTo(0,0);');
                    var i = 1;
                    async.forEachSeries(SOIComponents, function (component, callback) {
                        inventoryPage.clickOverMenuIcon(i).then(function () {
                            browser.executeScript('window.scrollTo(0,0);');
                            inventoryPage.clickOnViewComponent(i).then(function () {
                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                inventoryPage.closeViewComponent();
                                browser.sleep(10000);
                                i++;
                                return callback();

                            });
                        })
                    }, function (error) {
                        if (error) {
                            logger.info('Unable to Get SOI component')
                        }
                    })
                })
                // edit check for real adapter
                element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                inventoryPage.clickEditServiceIcon();
                inventoryPage.clickNextButton();
                modifiedParamMapedit = { "Service Instance Name": servicename, "Network Security Group Name": newnetworkSecurityGroupName, "EditService": true };


                orderFlowUtil.fillOrderDetails(newLinuxVMTemplate.Scenario1, modifiedParamMapedit);
                placeOrderPage.submitOrder();

                returnObj1.servicename = servicename;
                returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();

                //Open Order page and Approve Order 
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);

                placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(returnObj1);
                orderFlowUtil.waitForOrderStatusChange(returnObj1, messageStrings.completedState, 50);
            }
        });

        it('Azure: TC-C173533-Sanity Verify for Virtual machine, when VM is turned OFF, status should get changed from ON to OFF', function () {
            catalogPage.open();
            var returnObj = {};
            returnObj.servicename = servicename;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {

                    browser.executeScript('window.scrollTo(0,0);');
                    inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.azClickTurnOFFButtonOfInstance().then(function () {
                            inventoryPage.clickOkForInstanceTurnOFFPermission();
                            //util.waitForAngular();
                        });
                    });
                }
                else {
                    if(testEnvironment.includes('release'))
                    {
    
                       inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.azClickTurnONButtonDummyOfInstance().then(function () {
                            inventoryPage.clickOkForInstanceTurnOFFPermission();
                            //util.waitForAngular();
                        });
                    });
                }
                else
                {
                    inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.azClickTurnOFFButtonDummyOfInstance().then(function () {
                            inventoryPage.clickOkForInstanceTurnOFFPermission();
                            //util.waitForAngular();
                        })
                    })
                }
                    
                }
            }).then(function () {
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderTypeCustomOps(returnObj)).toBe(messageStrings.orderTypeAction);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.turnOff);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.getInstancePowerStateStatusAzure(returnObj).then(function(status){
                        if(status !== "Off"){
                            browser.refresh(); //refreshing browser to check updated vm status
                            util.waitForAngular();
                            inventoryPage.open();
                            inventoryPage.searchOrderByServiceName(returnObj.servicename);
                            inventoryPage.clickExpandFirstRow();
                        }
                        if (isDummyAdapterDisabled == "true") {
                            expect(inventoryPage.getInstancePowerStateStatusAzure(returnObj)).toContain(messageStrings.powerStateOff);
                        }
                        else {
                            expect(inventoryPage.getInstancePowerStateStatusAzure(returnObj)).toContain(newLinuxVMTemplate.powerStateOffDummy);
                        }
                    });
                });
            });
        });
        it('Azure: Verify Negative scenario for Virtual machine, when VM is turned OFF,', function () {
            var returnObj = {};
            returnObj.servicename = servicename;
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {
                    browser.executeScript('window.scrollTo(0,0);');
                    util.waitForAngular();
                    inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.azClickTurnOFFButtonOfInstance().then(function () {
                            expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOffNegativeWarning);
                            inventoryPage.clickCustomOpsWarningOKButton()
                        });
                    });
                }
                else {
                    if(testEnvironment.includes('release'))
                    {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                            util.waitForAngular();
                            browser.executeScript('window.scrollTo(0,0);');
                            inventoryPage.azClickTurnONButtonDummyOfInstance().then(function () {
                                expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(newLinuxVMTemplate.turnOffNegativeWarningDummy);
                                inventoryPage.clickCustomOpsWarningOKButton()
                            });
                        });
                    }
                    else
                    {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                            util.waitForAngular();
                            browser.executeScript('window.scrollTo(0,0);');
                            inventoryPage.azClickTurnOFFButtonDummyOfInstance().then(function () {
                                expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(newLinuxVMTemplate.turnOffNegativeWarningDummy);
                                inventoryPage.clickCustomOpsWarningOKButton()
                            });
                        });
                    }
                    
                }
            })
        });

        it('Azure:  Negative Scenario ---- Reboot the instance when the VM state is OFF', function () {
            var returnObj = {};
            returnObj.servicename = servicename;
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {
                    browser.executeScript('window.scrollTo(0,0);');
                    util.waitForAngular();
                    inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
                        inventoryPage.azClickRebootButtonOfInstance().then(function () {
                            expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.rebootNegativeWarning);
                            inventoryPage.clickCustomOpsWarningOKButton();
                        });
                    });
                }
                else {
                    browser.executeScript('window.scrollTo(0,0);');
                    inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                        inventoryPage.azClickRebootButtonDummyOfInstance().then(function () {
                            expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(newLinuxVMTemplate.rebootNegativeWarningDummy);
                            inventoryPage.clickCustomOpsWarningOKButton();
                        });
                    });
                }
            });
        });


        it('Azure: TC-C173534-Sanity Verify for Virtual machine, when VM is turned ON, status should get changed from OFF to ON', function () {
            var returnObj = {};
            returnObj.servicename = servicename;
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {
                    browser.executeScript('window.scrollTo(0,0);');
                    util.waitForAngular();
                    inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
                        inventoryPage.azClickTurnONButtonOfInstance().then(function () {
                            util.waitForAngular();
                            inventoryPage.clickOkForInstanceTurnONPermission();
                            //util.waitForAngular();
                        });
                    });
                }
                else {
                    if(testEnvironment.includes('release'))
                    {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                            inventoryPage.azClickTurnOFFButtonDummyOfInstance().then(function () {
                                util.waitForAngular();
                                inventoryPage.clickOkForInstanceTurnONPermission();
                            });
                        });
                    }
                    else
                    {
                        browser.executeScript('window.scrollTo(0,0);');
                        inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                            inventoryPage.azClickTurnONButtonDummyOfInstance().then(function () {
                                util.waitForAngular();
                                inventoryPage.clickOkForInstanceTurnONPermission();
                            });
                        });
                    }

                }
            }).then(function () {
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderTypeCustomOps(returnObj)).toBe(messageStrings.orderTypeAction);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.turnOn);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.getInstancePowerStateStatusAzure(returnObj).then(function(status){
                    console.log("CustomOpsStatus:" + status);
                    if(status !== "On"){
                        browser.refresh(); //refreshing browser to check updated vm status
                        util.waitForAngular();
                        inventoryPage.open();
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        inventoryPage.clickExpandFirstRow();
                    }
                    expect(inventoryPage.getInstancePowerStateStatusAzure(returnObj)).toContain(messageStrings.powerStateOn);
                });
            });
                // inventoryPage.clickExpandFirstRow().then(function () {
                //     expect(inventoryPage.getInstancePowerStateStatusAzure(returnObj)).toContain(messageStrings.powerStateOn);
                // });
            });
        });


        it('Azure: Turn ON the instance when the VM state is ON', function () {
            var returnObj = {};
            returnObj.servicename = servicename;
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {
                    browser.executeScript('window.scrollTo(0,0);');
                    util.waitForAngular();
                    inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
                        inventoryPage.azClickTurnONButtonOfInstance().then(function () {
                            expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOnNegativeWarning);
                            inventoryPage.clickCustomOpsWarningOKButton();
                        });
                    });
                }
                else {
                    if(testEnvironment.includes('release'))
                    {
                        browser.executeScript('window.scrollTo(0,0);');
                        util.waitForAngular();
                        inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                            inventoryPage.azClickTurnOFFButtonDummyOfInstance().then(function () {
                                expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOnNegativeWarning);
                                inventoryPage.clickCustomOpsWarningOKButton();
    
                            });
                        });
                    }
                    else
                    {
                        browser.executeScript('window.scrollTo(0,0);');
                        util.waitForAngular();
                        inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                            inventoryPage.azClickTurnONButtonDummyOfInstance().then(function () {
                                expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOnNegativeWarning);
                                inventoryPage.clickCustomOpsWarningOKButton();
    
                            });
                        });
                    }
                    
                }
            })
        })

        it('Azure: TC-C173535-Sanity Verify for Virtual machine, when VM is rebooted, status should remain ON', function () {
            var returnObj = {};
            returnObj.servicename = servicename;
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {
                    browser.executeScript('window.scrollTo(0,0);');
                    inventoryPage.clickOverflowActionButtonForPowerStatesAz().then(function () {
                        inventoryPage.azClickRebootButtonOfInstance().then(function () {
                            inventoryPage.clickOkForInstanceTurnONPermission();
                            //util.waitForAngular();
                        });
                    });
                }
                else {
                    browser.executeScript('window.scrollTo(0,0);');
                    inventoryPage.clickOverflowActionButtonFisrtComponent().then(function () {
                        inventoryPage.azClickRebootButtonDummyOfInstance().then(function () {
                            inventoryPage.clickOkForInstanceTurnONPermission();
                            //util.waitForAngular();
                        });
                    });
                }
            }).then(function () {
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderTypeCustomOps(returnObj)).toBe(messageStrings.orderTypeAction);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.reboot);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    expect(inventoryPage.getInstancePowerStateStatusAzure(returnObj)).toContain(messageStrings.powerStateOn);
                });
            });
        });

    }

});

