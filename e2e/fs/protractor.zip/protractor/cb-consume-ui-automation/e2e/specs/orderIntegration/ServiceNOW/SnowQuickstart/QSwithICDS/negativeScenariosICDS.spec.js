"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	OrderHistoryPage = require('../../../../../pageObjects/ordersHistory.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	icdsRhel7x = require('../../../../../../testData/OrderIntegration/ServiceNOW/ICDSRhel7x.json'),
	icdsWinR2IIS = require('../../../../../../testData/OrderIntegration/ServiceNOW/ICDSWin2012R2IIS.json'),
	icdsWinR2SQL = require('../../../../../../testData/OrderIntegration/ServiceNOW/ICDSWin2012R2SQL.json'),
	icdsWinR2V2 = require('../../../../../../testData/OrderIntegration/ServiceNOW/ICDSWindows2012R2V2.json'),
	shoppingCartTemplate   = require('../../../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('Negative Scenarios- Single and Cart Orders', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, provOrder, cartListPage, orderHistoryPage, groupName;
	var modifiedParamMapFailCart = {};
	var modifiedParamMapFailSingle = {};
	var modifiedParamMap1 = {};
	var modifiedParamMap2 = {};
	var modifiedParamMapMQ = {};
	var orderObject = {};
	var serviceName1 = "SNOWauto"+util.getRandomString(5);
	var serviceName2 = "SNOWauto"+util.getRandomString(5);
	var serviceName3 = "SNOWauto"+util.getRandomString(5);
	var serviceName4 = "SNOWauto"+util.getRandomString(5);
	var serviceName5 = "SNOWauto"+util.getRandomString(5);
	var cartName = "SNOWautoCart" + util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var icdsWinR2V2Obj = JSON.parse(JSON.stringify(icdsWinR2V2));
	var icdsRhel7xObj = JSON.parse(JSON.stringify(icdsRhel7x));

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		orderHistoryPage = new OrderHistoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		groupName = "att-group-" + util.getRandomString(5);
		modifiedParamMapFailCart = {"Service Instance Name":serviceName1, "Cart Name":cartName, "Cart Service":"checkbox-useShoppingCart", "New Shopping Cart":"newCart", "Team":"TestSnowTeam", "Environment":"QA", "Application":"", "Capacity":"31"};
		modifiedParamMapFailSingle = {"Service Instance Name":serviceName, "Team":"TestSnowTeam", "Environment":"QA", "Application":"", "Capacity":"31"};
		modifiedParamMapMQ = {"Service Instance Name":serviceName, "Quantity":"2", "Team":"TestSnowTeam", "Environment":"QA", "Application":"", "vSphere_Machine_1 disks":"", "Capacity":"", "Label":""};
		modifiedParamMap1 = {"Service Instance Name":serviceName1, "Cart Name":cartName, "Cart Service":"checkbox-useShoppingCart", "New Shopping Cart":"newCart", "Team":"TestSnowTeam", "Environment":"QA", "Application":"", "vSphere_Machine_1 disks":"", "Capacity":"", "Label":""};
		modifiedParamMap2 = {"Service Instance Name":serviceName2, "Quantity":"", "Team":"", "Environment":"", "Application":"", "Customer":"", "Servicecollection":"", "User":""};
		
	});
	
	afterAll(function() {
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});
	
	it('Enable Manual approval in SNOW QS', function () {
		snowPage.loginToSnowQSICDSPortal();
		snowPage.enableManualApprovalQS(snowInstanceTemplate.snowReqGrpApprovalProperty);
	});
	
	if(isProvisioningRequired == "true") {	
		it('Submit and verify failure of 1 offering in a cart of 2 items.', function () {
			
			//Add Windows Server 2012 R2 v2 to cart
			browser.get(consumeLaunchpadUrl);
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsWinR2V2.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsWinR2V2.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsWinR2V2.bluePrintName);
			orderObject.servicename = serviceName1;
			orderFlowUtil.fillOrderDetails(icdsWinR2V2, modifiedParamMapFailCart);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        cartListPage.continueShopping();
	        
	        //Add RHEL7.x to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsRhel7x.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsRhel7x.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsRhel7x.bluePrintName);
			orderObject.servicename = serviceName2;
			orderFlowUtil.fillOrderDetails(icdsRhel7x, modifiedParamMap2);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
			
			//Submit Order
			cartListPage.submitOrder();
	    	orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
	    	orderObject.submittedBy = cartListPage.getTextSubmittedByOrderSubmittedModal
	        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(shoppingCartTemplate.orderSubmittedConfirmationMessage);
	    	provOrder = cartListPage.getTextOrderNumberOrderSubmittedModal();
	        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
	        orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.appInProgressState);
			
			//SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getCountOfRITMlinks()).toBe(parseInt("2"));
			
			//Approve in SNOW
			snowPage.approveRequestFromSnowQS();
	
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2V2.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2V2.provInProgressState);
			
			//First RITM link
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			
			//Order Completion
			var service = snowPage.getTextReqItemCorrIDQS();
			service.then(function(serviceName) {
				snowPage.clickReqItemVarTabQS();
				snowPage.clickChangeRequestLinkQS();
				snowPage.clickImplementButtonQS();
				snowPage.clickBackButton();
				snowPage.clickChangeRequestLinkQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
				if(serviceName.includes(serviceName1)) {
					snowPage.checkIfChangeTaskFailed();	
				}
				else {
					snowPage.checkIfAllChangeTasksClosed();	
				}
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);				
				if(serviceName.includes(serviceName1)) {
					expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.inProgWithFailureState);
					orderHistoryPage.searchOrder(orderObject.orderNumber);
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(icdsWinR2V2.failedState);
				}
				else {
					expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.provInProgressState);
					orderHistoryPage.searchOrder(orderObject.orderNumber);
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(icdsWinR2V2.completedState);
				}
				
				//Validations on SNOW after Completion
				snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				snowPage.clickFirstRequestedItemLink();
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
					snowPage.clickChangeRequestLinkQS();
					expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);					
				}
				else {
					expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					snowPage.clickChangeRequestLinkQS();
					expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
				}	
			});
			
			//Second RITM link
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			
			//Order Completion
			var service = snowPage.getTextReqItemCorrIDQS();
			service.then(function(serviceName) {
				snowPage.clickReqItemVarTabQS();
				snowPage.clickChangeRequestLinkQS();
				snowPage.clickImplementButtonQS();
				snowPage.clickBackButton();
				snowPage.clickChangeRequestLinkQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
				if(serviceName.includes(serviceName1)) {
					snowPage.checkIfChangeTaskFailed();	
				}
				else {
					snowPage.checkIfAllChangeTasksClosed();	
				}
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.completedWithFailure);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.searchOrder(orderObject.orderNumber);
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(icdsWinR2V2.failedState);
				}
				else {
					orderHistoryPage.searchOrder(orderObject.orderNumber);
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(icdsWinR2V2.completedState);
				}
				
				//Validations on SNOW after Completion
				snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				snowPage.clickSecondRequestedItemLink();
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
					snowPage.clickChangeRequestLinkQS();
					expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);					
				}
				else {
					expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					snowPage.clickChangeRequestLinkQS();
					expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
				}	
			});
	    });	
		
		it('Submit and verify cancel CR of 1 offering in a cart of 2 items', function () {
			
			//Add Windows Server 2012 R2 v2 to cart
			browser.get(consumeLaunchpadUrl);
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsWinR2V2.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsWinR2V2.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsWinR2V2.bluePrintName);
			orderObject.servicename = serviceName1;
			orderFlowUtil.fillOrderDetails(icdsWinR2V2, modifiedParamMap1);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        cartListPage.continueShopping();
	        
	        //Add RHEL7.x to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsRhel7x.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsRhel7x.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsRhel7x.bluePrintName);
			orderObject.servicename = serviceName2;
			orderFlowUtil.fillOrderDetails(icdsRhel7x, modifiedParamMap2);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
			
			//Submit Order
			cartListPage.submitOrder();
	    	orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
	    	orderObject.submittedBy = cartListPage.getTextSubmittedByOrderSubmittedModal
	        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(shoppingCartTemplate.orderSubmittedConfirmationMessage);
	    	provOrder = cartListPage.getTextOrderNumberOrderSubmittedModal();
	        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
	        orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.appInProgressState);
			
			//SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getCountOfRITMlinks()).toBe(parseInt("2"));
			
			//Approve in SNOW
			snowPage.approveRequestFromSnowQS();
	
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2V2.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2V2.provInProgressState);
			
			//First RITM link
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			
			//Cancel Change Request
			var service = snowPage.getTextReqItemCorrIDQS();
			service.then(function(serviceName) {
				snowPage.clickChangeRequestLinkQS();
				snowPage.cancelChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeTaskStateCancelled);
				snowPage.clickBackButton();
				
				//Validations after CR is cancelled
				expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(icdsWinR2V2.cancelledState);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(icdsWinR2V2.inProgressState);
				}
			})	
			
			//Second RITM link
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			
			//Order Completion
			var service = snowPage.getTextReqItemCorrIDQS();
			service.then(function(serviceName) {
				snowPage.clickChangeRequestLinkQS();
				snowPage.clickImplementButtonQS();
				snowPage.clickBackButton();
				snowPage.clickChangeRequestLinkQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.checkIfAllChangeTasksClosed();	
				snowPage.clickBackButton();
				
				//Validations after completion
				expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.completedState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(icdsWinR2V2.cancelledState);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(icdsWinR2V2.completedState);
				}
			});
				
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
	    });	
		
		it('Submit and verify cancel CR of 1 offering in a multi quantity order.', function () {
			
			//Place Order for Provision in Marketplace
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsWinR2V2.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsWinR2V2.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsWinR2V2.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(icdsWinR2V2, modifiedParamMapMQ);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsWinR2V2.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2V2.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2V2.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getCountOfRITMlinks()).toBe(parseInt("2"));
			
			//Approve in SNOW
			snowPage.approveRequestFromSnowQS();
	
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2V2.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2V2.provInProgressState);
			
			//First RITM link
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			
			//Cancel Change Request
			var service = snowPage.getTextReqItemCorrIDQS();
			service.then(function(serviceName) {
				snowPage.clickChangeRequestLinkQS();
				snowPage.cancelChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeTaskStateCancelled);
				snowPage.clickBackButton();
				
				//Validations after CR is cancelled
				expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(icdsWinR2V2.cancelledState);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(icdsWinR2V2.inProgressState);
				}
			})	
			
			//Second RITM link
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			
			//Order Completion
			var service = snowPage.getTextReqItemCorrIDQS();
			service.then(function(serviceName) {
				snowPage.clickChangeRequestLinkQS();
				snowPage.clickImplementButtonQS();
				snowPage.clickBackButton();
				snowPage.clickChangeRequestLinkQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.checkIfAllChangeTasksClosed();	
				snowPage.clickBackButton();
				
				//Validations after completion
				expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.completedState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(icdsWinR2V2.cancelledState);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(icdsWinR2V2.completedState);
				}
			});
				
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
		});
		
		it('Submit and verify failure of single order item', function () {
			
			//Place Order for Provision in Marketplace
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsWinR2V2.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsWinR2V2.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsWinR2V2.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(icdsWinR2V2, modifiedParamMapFailSingle);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsWinR2V2.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2V2.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2V2.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			
			//Approve in SNOW
			snowPage.approveRequestFromSnowQS();
	
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2V2.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2V2.provInProgressState);
			
			//RITM link
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			snowPage.clickChangeRequestLinkQS();
			snowPage.clickImplementButtonQS();
			snowPage.clickBackButton();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.checkIfChangeTaskFailed();	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.failedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);				
		});	
		
		it('Submit and verify cancel CR for single order', function () {
			
			//Place Order for Provision in Marketplace
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsWinR2V2.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsWinR2V2.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsWinR2V2.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(icdsWinR2V2, modifiedParamMapFailSingle);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsWinR2V2.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2V2.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2V2.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			
			//Approve in SNOW
			snowPage.approveRequestFromSnowQS();
	
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2V2.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2V2.provInProgressState);
			
			//First RITM link
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			
			//Cancel Change Request
			snowPage.clickChangeRequestLinkQS();
			snowPage.cancelChangeRequest();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeTaskStateCancelled);
						
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsWinR2V2.cancelledState);
				
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
		});
		
		it('Submit and verify rejection of SR from SNOW', function () {
			
			//Disable QS flag
			snowPage.loginToSnowQSICDSPortal();
			snowPage.setQSflag(snowInstanceTemplate.snowPropertyValueFalse);
			
			//Place Order for Provision in Marketplace
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsWinR2V2.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsWinR2V2.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsWinR2V2.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(icdsWinR2V2, modifiedParamMapFailSingle);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsWinR2V2.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsWinR2V2.rejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsWinR2V2.rejectedState);
			
			//Verify in SNOW
            snowPage.logInToSnowICDSPortalAndSearchOrderNotExists(provOrder);
			expect(snowPage.getTextOrderNotExists()).toBe(snowInstanceTemplate.orderNotExistsMessage);
			
			//Enable QS flag
			snowPage.loginToSnowQSICDSPortal();
			snowPage.setQSflag(snowInstanceTemplate.snowPropertyValueTrue);
		});				
	 }
});
	
	
	
	