/*
Spec_Name: MultiUserbudget.spec.js 
Description: This spec will cover E2E testing of Cosmos DB service order submit, approve and delete.
             Verify all parameters of Budget with Different Users.   
Author: Atiksha Batra
*/
"use strict";

var logGenerator = require("../../../../helpers/logGenerator.js"),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    superUserUsername = browser.params.username,
    superUserPassword = browser.params.password,
    budgetaryFlow = require('../../../../helpers/budgetaryFlow.js'),
    multiUserBudgetTemplate = require('../../../../testData/OrderIntegration/Azure/multiUserBudgetService.json'),
    budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
    budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryAddNewBudgetDetails.json'),
    BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),
    credentialJson = require('../../../../testData/credentials.json');


describe('Azure - Multi user Budget', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, serviceName, cartListPage, rgName, sbName, budgetaryName, budgetaryUnitCode,
        budgetaryNewBudgetName, budgetryPage;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: 'Azure', category: 'Other Services', budgetaryUnitDeletedApiSucessMsg: budgetaryUnitDetailsTemplate.budgetaryUnitDeletedApiSucessMsg,
        budgetDeletedApiSucessMsg: budgetaryUnitDetailsTemplate.budgetDeletedApiSucessMsg,
    };
    var modifiedParamMapBudget = {};
    var modifiedNewBudgetParamMap = {};
    

    beforeAll(function () {
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        catalogDetailsPage = new CatalogDetailsPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        cartListPage = new CartListPage();
        budgetryPage = new BudgetaryPage();
        browser.driver.manage().window().maximize();
        budgetaryName = "azbudgetaryName"+util.getRandomString(8);
		budgetaryNewBudgetName = "budgetaryNewBudgetName"+util.getRandomString(8);
        budgetaryUnitCode = "budgetaryUnitCode"+util.getRandomString(8);
        modifiedParamMapBudget = {"budgetary Name":budgetaryName, "budgetary unit code":budgetaryUnitCode,"Choose Entity":"Organization","Entity Value":"budgetORG","Environment": "azureENV", "Application": "azureAPP"};
        var startPeriod = budgetaryFlow.incrementMonth(0); //Zero (0) for current month
    	modifiedNewBudgetParamMap = {"Name":budgetaryNewBudgetName, "Start Period":startPeriod, "Budget Amount":"1000.00"};
    });

    beforeEach(function () {
        catalogPage.open();
        // expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        serviceName = "AzureTestAutomation" + util.getRandomString(5);
        rgName = "gslautotc_azure_sbRG" + util.getRandomString(5);
        sbName = "AutoSB101" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "New Resource Group": rgName, "Service Bus Name": sbName }
    });


    it('Add new budgetry Unit for E2E budget Flow ', function () {
        budgetryPage.closeBudgetSliderIfPresent();
        //catalogPage.checkCurrentUser(credentialJson.superUserName);
        budgetryPage.open();
    	util.waitForAngular();    
    	budgetryPage.clickOnAddNewBudgetryUnitBtn();
    	budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMapBudget);
    	budgetryPage.clickOnBudgetrySaveBtn();
    	budgetryPage.clickOnBudgetryBudgetsLink();
    	budgetryPage.clickOnBudgetaryAddBudgetButton();
    	
    	budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);		
        budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
        budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
        // budgetryPage.clickOnBudgetaryBackBudgetButton();
        budgetryPage.clickBudgetSliderCloseButton();
    });
    if (isProvisioningRequired == "true") {


        it('Service Bus Verify the budget for Service Bus', async function () {
            var orderObject = {};
            var availBudgetProvCompleted, afterProvCommittedAmnt, beforePovisioningAvailBudget;
            var multiUserBudgetObject = JSON.parse(JSON.stringify(multiUserBudgetTemplate));
            await cartListPage.loginFromOtherUser(multiUserBudgetObject.buyerUserID, multiUserBudgetObject.buyerUserPassword);
            catalogPage.open();
            // Logout from the super user
            // await cartListPage.clickUserIcon();
            // await cartListPage.clickLogoutButton();

            //login with the buyer role user and place order
          
            // catalogPage.open();
           // expect(catalogPage.getUserID(multiUserBudgetObject.buyerUserName)).toBe(true); 
           catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
           catalogPage.clickProviderOrCategoryCheckbox(multiUserBudgetObject.Category);


            catalogPage.searchForBluePrint(multiUserBudgetObject.bluePrintName);
            catalogPage.clickConfigureButtonBasedOnName(multiUserBudgetTemplate.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetailsICAM(multiUserBudgetTemplate, modifiedParamMap).then(async function (ttt) {
                //Submit order through the buyer role user
                placeOrderPage.submitOrder();
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();


                //Get details on pop up after submit
                var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                var orderprice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();

                expect(ordersubmittedBy).toEqual(multiUserBudgetTemplate.buyerUserName);
               
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
               // catalogPage.open();
                util.waitForAngular();
                // Logout from the buyer role user
                // cartListPage.clickUserIcon();
                // cartListPage.clickLogoutButton();

                //Login with technical approval role user to approve the order technically
               await cartListPage.loginFromOtherUser(multiUserBudgetObject.technicalApprovalUserID, multiUserBudgetObject.technicalApprovalUserPass);
                expect(catalogPage.getUserID(multiUserBudgetObject.technicalApprovalUser)).toBe(true);
                orderFlowUtil.approveOrderTechnically(orderObject);//.then(function(){
                //to check budget is not present as the user have only technical approval role
                await expect(ordersPage.checkInvisibilityOfBudgetDetails()).toBe(false, "For technically approval role user Budget details is not present on the Approve order page.")
                //})
                //log out from the technically approval role user
                // browser.ignoreSynchronization = false;
                // catalogPage.open();
                // cartListPage.clickUserIcon();
                // cartListPage.clickLogoutButton();


                //login from the financially approval role user
               await cartListPage.loginFromOtherUser(multiUserBudgetObject.financialApprovalUserID, multiUserBudgetObject.financialApprovalUserPass);
                expect(catalogPage.getUserID(multiUserBudgetObject.financialApprovalUser)).toBe(true);
                ordersPage.open();
                ordersPage.searchOrderById(orderObject.orderNumber);


                ordersPage.selectBudgetaryUnit(budgetaryName);
                util.waitForAngular();
                //Budget verification 
                expect(ordersPage.getTextBudgetAmmount()).toEqual(multiUserBudgetObject.BudgetAmount);
                var beforePovisioningCommittedAmount = await ordersPage.getTextBudgetaryCommittedAmmount();
                var calculatedEstAmount = ordersPage.calculateBudgetaryEstimatedAmmountforOrder(multiUserBudgetObject.budgetDuration, multiUserBudgetObject.TotalCost);
                beforePovisioningAvailBudget = await ordersPage.getTextAvailableBudget();
                var costOtherOrdersAwaitingApprovalBeforeProvision = await ordersPage.getTextOtherOrdersAwaitingApproval();
                expect(ordersPage.getTextBudgetarySpendAmmount()).toEqual("USD 0.00");
                expect(ordersPage.getTextBudgetaryEstimatedAmmountforOrder()).toContain(calculatedEstAmount);



                orderFlowUtil.approveOrderFinancially(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed').then(function () {

                    /********** Order provisioning completed **********/
                    //order status completed 
                    availBudgetProvCompleted = ordersPage.calculateAvailableBudgetAfterProvCompleted(beforePovisioningAvailBudget, calculatedEstAmount);
                    expect(ordersPage.getTextAvailableBudget()).toContain(availBudgetProvCompleted);


                    var actualOrdersAwaitingApprovalAmout = ordersPage.calculateAfterProvOtherOrderAwaitingApprovalAmount(costOtherOrdersAwaitingApprovalBeforeProvision, calculatedEstAmount);
                    expect(ordersPage.getTextOtherOrdersAwaitingApproval()).toEqual(actualOrdersAwaitingApprovalAmout);

                    afterProvCommittedAmnt = ordersPage.calculateCommittedAmountAfterProvCompleted(beforePovisioningCommittedAmount, calculatedEstAmount);
                    expect(ordersPage.getTextBudgetaryCommittedAmmount()).toContain(afterProvCommittedAmnt);

                    expect(ordersPage.getTextBudgetarySpendAmmount()).toEqual("USD 0.00");
                });

                //Logout from the financial approval user roles
                // cartListPage.clickUserIcon();
                // cartListPage.clickLogoutButton();

                //Login from the buyer role user 
               await cartListPage.loginFromOtherUser(multiUserBudgetObject.buyerUserID, multiUserBudgetObject.buyerUserPassword);
                expect(catalogPage.getUserID(multiUserBudgetObject.buyerUserName)).toBe(true); 
                //Place the deleteorder from the buyer role
                //catalogPage.open();
                orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                // expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                //catalogPage.open();
                //Logout from the buyer role user
                // cartListPage.clickUserIcon();
                // cartListPage.clickLogoutButton();
                //Login from the technically approval role user
                await cartListPage.loginFromOtherUser(multiUserBudgetObject.technicalApprovalUserID, multiUserBudgetObject.technicalApprovalUserPass);
                expect(catalogPage.getUserID(multiUserBudgetObject.technicalApprovalUser)).toBe(true);
                orderFlowUtil.approveDeletedOrderTechnically(orderObject);
                //Logout from the technically approval role user
                // catalogPage.open();
                // cartListPage.clickUserIcon();
                // cartListPage.clickLogoutButton();
                //Login from the financially approval role user
                await cartListPage.loginFromOtherUser(multiUserBudgetObject.financialApprovalUserID, multiUserBudgetObject.financialApprovalUserPass);
                expect(catalogPage.getUserID(multiUserBudgetObject.financialApprovalUser)).toBe(true);


                // catalogPage.open();
                orderFlowUtil.approveDeletedOrderFinancially(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed').then(function () {

                    /********** Delete order status completed **********/
                    var estCostAfterDeleting1MonthOrder = ordersPage.calculateEstCostAfterDeleting1MonthOrder(calculatedEstAmount, multiUserBudgetObject.TotalCost);
                    expect(estCostAfterDeleting1MonthOrder).toContain(ordersPage.getTextBudgetaryEstimatedAmmountforOrder());

                    var deletedCommittedAmnt = ordersPage.calculateDeleteCommittedAmount(afterProvCommittedAmnt, estCostAfterDeleting1MonthOrder);
                    expect(deletedCommittedAmnt).toContain(ordersPage.getTextBudgetaryCommittedAmmount());

                    var deletedAvailableBudget = ordersPage.calculateAfterDeletingAvailBudget(availBudgetProvCompleted, estCostAfterDeleting1MonthOrder);
                    expect(deletedAvailableBudget).toContain(ordersPage.getTextAvailableBudget());
                });
            });
        });
    }
    afterAll(async function () {
        budgetryPage.closeBudgetSliderIfPresent();
        //Logout from the financially approval role user
        // cartListPage.clickUserIcon();
        // cartListPage.clickLogoutButton();
        //Login with super user
        await cartListPage.loginFromOtherUser(superUserUsername, superUserPassword);
        expect(catalogPage.getUserID(credentialJson.superUserName)).toBe(true);
        //Inactivate Budget and Budgetary Unit
        budgetryPage.open();
        budgetryPage.searchBudegtaryUnit(budgetaryName);
        budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryName);
        budgetryPage.clickOnBudgetryBudgetsLink();
        budgetryPage.selectCheckBoxBasedOnName(budgetaryNewBudgetName);
        budgetryPage.clickonDeactivateBtnForSelectedItem();
        budgetryPage.clickOnDeactivateConfirmationBtn();
        budgetryPage.clickOnBudgetryDetailsLink();
        budgetryPage.clickOnEditBudgetaryButton();
        budgetryPage.clickBudgetStatustoglBtn();
        budgetryPage.clickOnBudgetrySaveBtn();
        budgetryPage.clickBudgetSliderCloseButton();
    });
});
