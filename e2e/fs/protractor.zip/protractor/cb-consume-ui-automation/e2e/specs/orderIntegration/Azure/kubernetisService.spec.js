//Author: Atiksha Batra
"use strict";
var logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    async = require('async'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    AKSTemplate = require('../../../../testData/OrderIntegration/Azure/aks.json')

describe('Azure - Azure Kubernetis Service ', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, servicename, SOIComponents;
    var modifiedParamMap = {};
    var servicename = "AutoAKSsrv" + util.getRandomString(5);
    var newResourceGroupName = "gslautotc_azureAKS-RG101" + util.getRandomString(4);
    var kubernetisClusterName = "auto-AKC101" + util.getRandomString(4);
    var virtualNetworkName = "auto-VN101" + util.getRandomString(4);
    var networkSubnetName = "auto-SN101" + util.getRandomString(4);
    var dnsPrefixName = "auto-DNS101" + util.getRandomString(4);
    var workspaceName = "auto-WorkSpace101" + util.getRandomString(4);
    var messageStrings = { providerName: 'Azure', category: 'Containers', templateName: 'Azure Kubernetes Service(AKS)' };

    beforeAll(function () {
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    afterAll(function () {
        // Delete AKS
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    beforeEach(function () {
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Kubernetes Cluster Name": kubernetisClusterName, "Virtual Network Name": virtualNetworkName, "Subnet Name": networkSubnetName, "Dns Name Prefix": dnsPrefixName, "Workspace Name": workspaceName, "UpdateMainParamObject": false };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        //SOIComponents = [virtualNetworkName]
    });

    it('Azure: Verify that for Azure Kubernetis Service required parameters on Service Details Page are present.', function () {
        var kubernetisServiceObject = JSON.parse(JSON.stringify(AKSTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(kubernetisServiceObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(kubernetisServiceObject.bluePrintName);
        if (browser.params.defaultCurrency == "USD") {
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(kubernetisServiceObject.BasePrice);
        }
    });

    it('Azure: Verify Review order and View Order Details for Azure Kubernetis Service', function () {
        var orderObject = {};
        orderObject.servicename = servicename;
        var kubernetisServiceObject = JSON.parse(JSON.stringify(AKSTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(kubernetisServiceObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(kubernetisServiceObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(AKSTemplate, modifiedParamMap);
        //Verify input values on Review Order page     
        expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "New Resource Group Required"));
        expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(newResourceGroupName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Location"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Kubernetes Cluster Name:")).toEqual(kubernetisClusterName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Resource Location:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Resource Location"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Kubernetes Version:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Kubernetes Version"));
        expect(placeOrderPage.getTextBasedOnLabelName("Node VM Name:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Node VM Name"));
        expect(placeOrderPage.getTextBasedOnLabelName("Os Disk Size GB:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Os Disk Size GB"));
        expect(placeOrderPage.getTextBasedOnLabelName("Node Count:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Node Count"));
        expect(placeOrderPage.getTextBasedOnLabelName("VM Scale Sets:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "VM Scale Sets"));
        expect(placeOrderPage.getTextBasedOnLabelName("Virtual Nodes:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Virtual Nodes"));
        expect(placeOrderPage.getTextBasedOnLabelName("Role-based access control (RBAC):")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Role-based access control (RBAC)"));
        expect(placeOrderPage.getTextBasedOnLabelName("Authentication Method:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Authentication Method"));
        expect(placeOrderPage.getTextBasedOnLabelName("Network Configuration:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Network Configuration"));
        expect(placeOrderPage.getTextBasedOnLabelName("New Virtual Network Required:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "New Virtual Network Required"));
        expect(placeOrderPage.getTextBasedOnLabelName("Virtual Network Name")).toEqual(virtualNetworkName);
        expect(placeOrderPage.getTextBasedOnLabelName("Address Prefix:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Address Prefix"));
        expect(placeOrderPage.getTextBasedOnLabelName("Subnet Name:")).toEqual(networkSubnetName);
        expect(placeOrderPage.getTextBasedOnLabelName("Subnet Prefix:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Subnet Prefix"));
        expect(placeOrderPage.getTextBasedOnLabelName("Kubernetes Service Address Range:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Kubernetes Service Address Range"));
        expect(placeOrderPage.getTextBasedOnLabelName("Kubernetes DNS Service IP Address:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Kubernetes DNS Service IP Address"));
        expect(placeOrderPage.getTextBasedOnLabelName("Docker Bridge Address:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Docker Bridge Address"));
        expect(placeOrderPage.getTextBasedOnLabelName("Dns Name Prefix:")).toEqual(dnsPrefixName);
        expect(placeOrderPage.getTextBasedOnLabelName("Enable Private Cluster:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Enable Private Cluster"));
        expect(placeOrderPage.getTextBasedOnLabelName("Network Policy:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Network Policy"));
        expect(placeOrderPage.getTextBasedOnLabelName("Enable Http Application Routing:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Enable Http Application Routing"));
        expect(placeOrderPage.getTextBasedOnLabelName("New Container Registry Required:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "New Container Registry Required"));
        expect(placeOrderPage.getTextBasedOnLabelName("Container monitoring:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Container monitoring"));
        expect(placeOrderPage.getTextBasedOnLabelName("New Log Analytics Workspace Required:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "New Log Analytics Workspace Required"));
        expect(placeOrderPage.getTextBasedOnLabelName("Workspace Region:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Workspace Region"));
        expect(placeOrderPage.getTextBasedOnLabelName("Workspace Name:")).toEqual(workspaceName);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(orderObject.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(orderObject.servicename);//Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe('Azure');//Checking Provider
        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "New Resource Group Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(newResourceGroupName);
        expect(ordersPage.getTextBasedOnExactLabelName("Kubernetes Cluster Name")).toEqual(kubernetisClusterName);
        expect(ordersPage.getTextBasedOnExactLabelName("Resource Location")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Resource Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("Kubernetes Version")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Kubernetes Version"));
        expect(ordersPage.getTextBasedOnExactLabelName("Node VM Name")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Node VM Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Node VM Size")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Node VM Size"));
        expect(ordersPage.getTextBasedOnExactLabelName("Os Disk Size GB")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Os Disk Size GB"));
        expect(ordersPage.getTextBasedOnExactLabelName("Node Count")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Node Count"));
        expect(ordersPage.getTextBasedOnExactLabelName("VM Scale Sets")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "VM Scale Sets"));
        expect(ordersPage.getTextBasedOnExactLabelName("Virtual Nodes")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Virtual Nodes"));
        expect(ordersPage.getTextBasedOnExactLabelName("Role-based access control (RBAC)")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Role-based access control (RBAC)"));
        expect(ordersPage.getTextBasedOnExactLabelName("Authentication Method")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Authentication Method"));
        expect(ordersPage.getTextBasedOnExactLabelName("Network Configuration")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Network Configuration"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Virtual Network Required")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "New Virtual Network Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Virtual Network Name")).toEqual(virtualNetworkName);
        expect(ordersPage.getTextBasedOnExactLabelName("Address Prefix")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Address Prefix"));
        expect(ordersPage.getTextBasedOnExactLabelName("Subnet Name")).toEqual(networkSubnetName);
        expect(ordersPage.getTextBasedOnExactLabelName("Subnet Prefix")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Subnet Prefix"));
        expect(ordersPage.getTextBasedOnExactLabelName("Kubernetes Service Address Range")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Kubernetes Service Address Range"));
        expect(ordersPage.getTextBasedOnExactLabelName("Kubernetes DNS Service IP Address")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Kubernetes DNS Service IP Address"));
        expect(ordersPage.getTextBasedOnExactLabelName("Docker Bridge Address")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Docker Bridge Address"));
        expect(ordersPage.getTextBasedOnExactLabelName("Dns Name Prefix")).toEqual(dnsPrefixName);
        expect(ordersPage.getTextBasedOnExactLabelName("Enable Private Cluster")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Enable Private Cluster"));
        expect(ordersPage.getTextBasedOnExactLabelName("Network Policy")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Network Policy"));
        expect(ordersPage.getTextBasedOnExactLabelName("Enable Http Application Routing")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Enable Http Application Routing"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Container Registry Required")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "New Container Registry Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Container monitoring")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Container monitoring"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Log Analytics Workspace Required")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "New Log Analytics Workspace Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Workspace Region")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Workspace Region"));
        expect(ordersPage.getTextBasedOnExactLabelName("Workspace Name")).toEqual(workspaceName);
        //Checking Bill Of Material
        if (browser.params.defaultCurrency == "USD") {
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(ordersPage.getEstimatedCost()).toBe(kubernetisServiceObject.TotalCost);
        }
        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
    });

    if (isProvisioningRequired == "true") {
        it('Azure: Verify provisioning of Azure Kubernetis Service using Consume UI', function () {
            var orderObject = {};
            orderObject.servicename = servicename;
            var kubernetisServiceObject = JSON.parse(JSON.stringify(AKSTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(kubernetisServiceObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(kubernetisServiceObject.bluePrintName);
            orderFlowUtil.fillOrderDetails(AKSTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
            inventoryPage.clickViewService();
            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "New Resource Group Required"));
            expect(inventoryPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
            expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Location"));
            expect(inventoryPage.getTextBasedOnLabelName("Kubernetes Cluster Name:")).toEqual(kubernetisClusterName);
            expect(inventoryPage.getTextBasedOnLabelName("Resource Location:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Resource Location"));
            expect(inventoryPage.getTextBasedOnLabelName("Kubernetes Version:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Kubernetes Version"));
            expect(inventoryPage.getTextBasedOnLabelName("Node VM Name:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Node VM Name"));
            expect(inventoryPage.getTextBasedOnExactLabelName("Node VM Size:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Node VM Size"));
            expect(inventoryPage.getTextBasedOnLabelName("Os Disk Size GB:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Os Disk Size GB"));
            expect(inventoryPage.getTextBasedOnLabelName("Node Count:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Node Count"));
            expect(inventoryPage.getTextBasedOnLabelName("VM Scale Sets:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "VM Scale Sets"));
            expect(inventoryPage.getTextBasedOnLabelName("Virtual Nodes:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Virtual Nodes"));
            expect(inventoryPage.getTextBasedOnLabelName("Role-based access control (RBAC):")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Role-based access control (RBAC)"));
            expect(inventoryPage.getTextBasedOnLabelName("Authentication Method:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Authentication Method"));
            expect(inventoryPage.getTextBasedOnLabelName("Network Configuration:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Network Configuration"));
            expect(inventoryPage.getTextBasedOnLabelName("New Virtual Network Required:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "New Virtual Network Required"));
            expect(inventoryPage.getTextBasedOnLabelName("Virtual Network Name:")).toEqual(virtualNetworkName);
            expect(inventoryPage.getTextBasedOnExactLabelName("Address Prefix:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Address Prefix"));
            expect(inventoryPage.getTextBasedOnLabelName("Subnet Name:")).toEqual(networkSubnetName);
            expect(inventoryPage.getTextBasedOnExactLabelName("Subnet Prefix:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Subnet Prefix"));
            expect(inventoryPage.getTextBasedOnLabelName("Kubernetes Service Address Range:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Kubernetes Service Address Range"));
            expect(inventoryPage.getTextBasedOnLabelName("Kubernetes DNS Service IP Address:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Kubernetes DNS Service IP Address"));
            expect(inventoryPage.getTextBasedOnLabelName("Docker Bridge Address:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Docker Bridge Address"));
            expect(inventoryPage.getTextBasedOnExactLabelName("Dns Name Prefix:")).toEqual(dnsPrefixName);
            expect(inventoryPage.getTextBasedOnLabelName("Enable Private Cluster:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Enable Private Cluster"));
            expect(inventoryPage.getTextBasedOnLabelName("Network Policy:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Network Policy"));
            expect(inventoryPage.getTextBasedOnLabelName("Enable Http Application Routing:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Enable Http Application Routing"));
            expect(inventoryPage.getTextBasedOnExactLabelName("New Container Registry Required:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "New Container Registry Required"));
            expect(inventoryPage.getTextBasedOnLabelName("Container monitoring:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Container monitoring"));
            expect(inventoryPage.getTextBasedOnLabelName("New Log Analytics Workspace Required:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "New Log Analytics Workspace Required"));
            expect(inventoryPage.getTextBasedOnLabelName("Workspace Region:")).toEqual(jsonUtil.getValue(kubernetisServiceObject, "Workspace Region"));
            expect(inventoryPage.getTextBasedOnLabelName("Workspace Name:")).toEqual(workspaceName);
            inventoryPage.closeViewDetailsTab();
            //Checking SOI Components
            if (isDummyAdapterDisabled == "true") {
                inventoryPage.clickExpandFirstRow().then(function () {
                    browser.executeScript('window.scrollTo(0,0);');
                    var i = 1;
                    async.forEachSeries(SOIComponents, function (component, callback) {
                        inventoryPage.clickOverMenuIcon(i).then(function () {
                            inventoryPage.clickOnViewComponent(i).then(function () {
                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                expect(inventoryPage.getTagsOnInventory()).toContain(kubernetisServiceObject.mcmpTag);
                                expect(inventoryPage.getTagsOnInventory()).toContain(kubernetisServiceObject.bluePrintName);
                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                inventoryPage.closeViewComponent();
                                browser.sleep(10000);
                                i++;
                                return callback();
                            });
                        })
                    }, function (error) {
                        if (error) {
                            logger.info('Unable to Get SOI component')
                        }
                    })
                })
            }
            // check Non-Editable service Message
            inventoryPage.clickNonEditableInstance();
            expect(inventoryPage.getTextForInvalidEditModal()).toEqual(AKSTemplate.nonEditableText);
            inventoryPage.clickOnInvalidEditOkModal();
        });
    }
});
