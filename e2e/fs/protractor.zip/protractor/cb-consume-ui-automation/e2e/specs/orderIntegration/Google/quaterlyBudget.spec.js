"use strict";
var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),	
	BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),	
	util = require('../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../testData/appUrls.json'),	
	budgetaryFlow = require('../../../../helpers/budgetaryFlow.js'),	
	budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
	budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/quaterlyNewbudgetDetails.json');


describe('GCP - Quaterly Budget Validation', function () {
	var catalogPage, budgetryPage, budgetaryName, budgetaryNewBudgetName, budgetaryUnitCode;	
	var modifiedParamMapQuatBudget = {};
	var modifiedParamMapBudget = {};
	var messageStrings = {		
		budgetDeletedApiSucessMsg: "Success",
		budgetaryUnitDeletedApiSucessMsg: "Success",
		budgetaryUnitDeleteSuccessMsg:budgetaryUnitDetailsTemplate.budgetaryUnitDeleteSuccessMsg
	};

	beforeAll(function () {		
		catalogPage = new CatalogPage();		
		budgetryPage = new BudgetaryPage();
		browser.driver.manage().window().maximize();
		budgetaryName = "gcpQuaterlyAut" + util.getRandomString(8);		
		budgetaryNewBudgetName = "newgcpAut" + util.getRandomString(8);		
		budgetaryUnitCode = "gcpQuaterlyCode" + util.getRandomString(8);		
		modifiedParamMapQuatBudget = {"Start Month":util.getLongMonthOfCurrentYear(), "Start Year": util.getFullYearOfTodaysDate(), "Notify When Soft Quota reached": "TEAM1", "Notify When Hard Quota reached": "TEAM1"};
		modifiedParamMapBudget = { "budgetary Name": budgetaryName, "budgetary unit code": budgetaryUnitCode, "Choose Entity": "Organization", "Entity Value": "budgetORG", "Environment": "gcpEnv", "Application": "gcpApp" };
	});
	
	it('Quaterly Budget - Add new budgetry Unit ', function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		budgetryPage.open();		
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMapBudget);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickOnBudgetryBudgetsLink();		
		budgetryPage.clickAddBudgetSetBtn();
		budgetryPage.setTotalBudgetAmount(budgetaryAddNewBudgetDetailsTemplate.totalBudgetAmount);
		//Verify if Total Budget Amount is evenly distributed in 4 quarters. 
		expect(budgetryPage.validateBudgetAmountEvenlyDistributed(budgetaryAddNewBudgetDetailsTemplate.totalBudgetAmount)).toBe(true);
		//Update budget Amount for All quarters and check if Total Budget Amount is Updated
		budgetryPage.updateQuaterlyBudgetAmount(budgetaryAddNewBudgetDetailsTemplate.quatBudgetAmount);
		expect(budgetryPage.validateBudgetAmountEvenlyDistributed(budgetaryAddNewBudgetDetailsTemplate.updatedTotalBudgetAmount)).toBe(true);
		//Update all quarters budget name
		budgetryPage.updateQuaterlyBudgetName(budgetaryAddNewBudgetDetailsTemplate.quaterBdgtName);
		
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedParamMapQuatBudget);
		budgetryPage.clickOnBudgetryBudgetsLink();
		//Validate quaterly budgets are updated
		budgetryPage.validateQuaterlyBudgetsList(budgetaryAddNewBudgetDetailsTemplate.bdgtAmntForEachQuatr).then(function(status){
			expect(status).toBe(true);
		});		
		
	});	

	afterAll(async function () {
		orderFlowUtil.closeHorizontalSliderIfPresent();
		budgetryPage.open();
		//budgetryPage.selectbudgetaryPaginationDropDown();
		budgetryPage.searchBudegtaryUnit(budgetaryName);
		budgetryPage.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName);
		budgetryPage.validateBudgetaryUnitIsAvailable(budgetaryName);			       
		budgetryPage.selectCheckBoxBasedOnName(budgetaryName);
		budgetryPage.clickonDeleteBtnForSelectedItem();
		budgetryPage.clickOnDeleteConfirmationBtn(3);
		expect(budgetryPage.getNotificationMsg()).toContain(messageStrings.budgetaryUnitDeleteSuccessMsg);
	});

});
