"use strict";
var Orders = require('../../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../../helpers/util.js'),
    jsonUtil = require('../../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../../testData/appUrls.json'),
    imiUtil = require('../../../../../helpers/imiApiUtil.js'),
    imiConfigTemplate = require('../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    imiManageServiceTemplate = require('../../../../../testData/OrderIntegration/Imi/manageService.json'),
    classicELBInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSClassicELBInstance.json');

describe('IMI - ClassicLoadBalancer', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, lbName, ClassicELBObject, inventoryPage;
    var modifiedParamMap = {};
    var orderObject = {};
    var messageStrings = {
        providerName: 'Amazon',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        instanceName: classicELBInstanceTemplate.instanceName,
        componentType: classicELBInstanceTemplate.componentType,
        serviceId: classicELBInstanceTemplate.serviceId,
        imiOrderSubmitted: "Configure IMI Managed Service"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
    });

    it('IMI:AWS ClassicLoadBalancer - Verify E2E flow for ClassicLoadBalancer with IMI Add On', function () {

        var serviceDetailsMap = {};

        serviceName = "aws-imi-clb-" + util.getRandomString(5);
        var addOnName = "clb-adon-" + util.getRandomString(5);

        lbName = "LBName" + util.getRandomString(5)
        modifiedParamMap = { "Service Instance Name": serviceName, "Load Balancer Name": lbName, "Add-On Name": addOnName };

        ClassicELBObject = JSON.parse(JSON.stringify(classicELBInstanceTemplate));
        orderObject.servicename = serviceName;
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(classicELBInstanceTemplate.provider);
        catalogPage.clickProviderOrCategoryCheckbox(classicELBInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(classicELBInstanceTemplate.bluePrintName);

        //Update ClassicLoadBalancer template with IMI template
        delete classicELBInstanceTemplate["Order Parameters"]["Configure Add-ons"];
        classicELBInstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
        classicELBInstanceTemplate["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
        classicELBInstanceTemplate["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
        classicELBInstanceTemplate["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(classicELBInstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            //Restore template with default data	
            classicELBInstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiManageServiceTemplate["Configure Add-ons"];
            delete classicELBInstanceTemplate["Order Parameters"]["IMI Main Parameters"];
            delete classicELBInstanceTemplate["Order Parameters"]["Configure manage service"];
            delete classicELBInstanceTemplate["Order Parameters"]["Review IMI Config"];
            serviceDetailsMap = requiredReturnMap;
            util.waitForAngular();
            //Validate IMI configuration on Review Order page
            expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(placeOrderPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(placeOrderPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Provider Account", 1)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Provider Account IMI"));

            //Validate Review Order page with all Service Configuration
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(classicELBInstanceTemplate.TotalCostWithAddOn);

            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Load Balancer Name"]).toEqual(requiredReturnMap["Expected"]["Load Balancer Name"]);
            expect(requiredReturnMap["Actual"]["Scheme"]).toEqual(requiredReturnMap["Expected"]["Scheme"]);
            expect(requiredReturnMap["Actual"]["Load Balancer Protocol 1"]).toEqual(requiredReturnMap["Expected"]["Load Balancer Protocol 1"]);
            expect(requiredReturnMap["Actual"]["Load Balancer Port 1"]).toEqual(requiredReturnMap["Expected"]["Load Balancer Port 1"]);
            expect(requiredReturnMap["Actual"]["Instance Protocol 1"]).toEqual(requiredReturnMap["Expected"]["Instance Protocol 1"]);
            expect(requiredReturnMap["Actual"]["Instance Port 1"]).toEqual(requiredReturnMap["Expected"]["Instance Port 1"]);
            // expect(requiredReturnMap["Actual"]["Policy Name 1"]).toEqual(requiredReturnMap["Expected"]["Policy Name 1"]);
            expect(requiredReturnMap["Actual"]["VPC"]).toEqual(requiredReturnMap["Expected"]["VPC"]);
            expect(requiredReturnMap["Actual"]["Availability Zone"]).toEqual(requiredReturnMap["Expected"]["Availability Zone"]);
            //expect(requiredReturnMap["Actual"]["Subnet"]).toEqual(requiredReturnMap["Expected"]["Subnet"]);
            expect(requiredReturnMap["Actual"]["Security Groups"]).toEqual(requiredReturnMap["Expected"]["Securities Groups"]);
            expect(requiredReturnMap["Actual"]["Select Policy Type"]).toEqual(requiredReturnMap["Expected"]["Select Policy Type"]);
            // expect(requiredReturnMap["Actual"]["LB Cookie Stickiness Policy Name"]).toEqual(requiredReturnMap["Expected"]["LB Cookie Stickiness Policy Name"]);
            expect(requiredReturnMap["Actual"]["Cookie Expiration Period"]).toEqual(requiredReturnMap["Expected"]["Cookie Expiration Period"]);
            expect(requiredReturnMap["Actual"]["Enable Logging"]).toEqual(requiredReturnMap["Expected"]["Enable Logging"]);
            expect(requiredReturnMap["Actual"]["Ping Protocol"]).toEqual(requiredReturnMap["Expected"]["Ping Protocol"]);
            expect(requiredReturnMap["Actual"]["Ping Port"]).toEqual(requiredReturnMap["Expected"]["Ping Port"]);
            expect(requiredReturnMap["Actual"]["Ping Path"]).toEqual(requiredReturnMap["Expected"]["Ping Path"]);
            expect(requiredReturnMap["Actual"]["Response Timeout"]).toEqual(requiredReturnMap["Expected"]["Response Timeout"]);
            expect(requiredReturnMap["Actual"]["Interval"]).toEqual(requiredReturnMap["Expected"]["Interval"]);
            expect(requiredReturnMap["Actual"]["Healthy Threshold"]).toEqual(requiredReturnMap["Expected"]["Healthy Threshold"]);
            expect(requiredReturnMap["Actual"]["Unhealthy Threshold"]).toEqual(requiredReturnMap["Expected"]["Unhealthy Threshold"]);
            expect(requiredReturnMap["Actual"]["Instance Id"]).toEqual(requiredReturnMap["Expected"]["Instance Id"]);
            expect(requiredReturnMap["Actual"]["Cross Zone"]).toEqual(requiredReturnMap["Expected"]["Cross Zone"]);
            expect(requiredReturnMap["Actual"]["Connection Draining Policy Enabled"]).toEqual(requiredReturnMap["Expected"]["Connection Draining Policy Enabled"]);
            expect(requiredReturnMap["Actual"]["Idle Timeout"]).toEqual(requiredReturnMap["Expected"]["Idle Timeout"]);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate Add on on orders page
            expect(ordersPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(ClassicELBObject, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("Load Balancer Name")).toEqual(lbName);
            expect(ordersPage.getTextBasedOnLabelName("Load Balancer Protocol")).toEqual(jsonUtil.getValue(ClassicELBObject, "Load Balancer Protocol"));
            expect(ordersPage.getTextBasedOnLabelName("Load Balancer Port")).toEqual(jsonUtil.getValue(ClassicELBObject, "Load Balancer Port"));
            expect(ordersPage.getTextBasedOnLabelName("Instance Protocol")).toEqual(jsonUtil.getValue(ClassicELBObject, "Instance Protocol"));
            expect(ordersPage.getTextBasedOnLabelName("Instance Port")).toEqual(jsonUtil.getValue(ClassicELBObject, "Instance Port"));
            // expect(ordersPage.getTextBasedOnLabelName("Policy Name")).toEqual(jsonUtil.getValue(ClassicELBObject, "Policy Name"));
            expect(ordersPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(ClassicELBObject, "VPC"));
            expect(ordersPage.getTextBasedOnLabelName("Availability Zone")).toEqual("us-east-1a,us-east-1b");
            expect(ordersPage.getTextBasedOnLabelName("Subnet")).toEqual("subnet-c5f664b2 | us-east-1b,subnet-a68b538d | us-east-1a");
            expect(ordersPage.getTextBasedOnLabelName("Security Groups")).toEqual("sg-4e88232a | default");
            expect(ordersPage.getTextBasedOnLabelName("Select Policy Type")).toEqual(jsonUtil.getValue(ClassicELBObject, "Select Policy Type"));
            //  expect(ordersPage.getTextBasedOnLabelName("LB Cookie Stickiness Policy Name")).toEqual(jsonUtil.getValue(ClassicELBObject, "LB Cookie Stickiness Policy Name"));
            expect(ordersPage.getTextBasedOnLabelName("Cookie Expiration Period")).toEqual(jsonUtil.getValue(ClassicELBObject, "Cookie Expiration Period"));
            expect(ordersPage.getTextBasedOnLabelName("Enable Logging")).toEqual(jsonUtil.getValue(ClassicELBObject, "Enable Logging"));
            expect(ordersPage.getTextBasedOnLabelName("Ping Protocol")).toEqual(jsonUtil.getValue(ClassicELBObject, "Ping Protocol"));
            expect(ordersPage.getTextBasedOnLabelName("Ping Port")).toEqual(jsonUtil.getValue(ClassicELBObject, "Ping Port"));
            expect(ordersPage.getTextBasedOnLabelName("Ping Path")).toEqual(jsonUtil.getValue(ClassicELBObject, "Ping Path"));
            expect(ordersPage.getTextBasedOnLabelName("Response Timeout")).toEqual(jsonUtil.getValue(ClassicELBObject, "Response Timeout"));
            expect(ordersPage.getTextBasedOnLabelName("Interval")).toEqual(jsonUtil.getValue(ClassicELBObject, "Interval"));
            expect(ordersPage.getTextBasedOnLabelName("Healthy Threshold")).toEqual(jsonUtil.getValue(ClassicELBObject, "Healthy Threshold"));
            expect(ordersPage.getTextBasedOnLabelName("Unhealthy Threshold")).toEqual(jsonUtil.getValue(ClassicELBObject, "Unhealthy Threshold"));
            expect(ordersPage.getTextBasedOnLabelName("Instance Id")).toEqual(jsonUtil.getValue(ClassicELBObject, "Instance Id"));
            expect(ordersPage.getTextBasedOnLabelName("Cross Zone")).toEqual(jsonUtil.getValue(ClassicELBObject, "Cross Zone"));
            expect(ordersPage.getTextBasedOnLabelName("Connection Draining Policy Enabled")).toEqual(jsonUtil.getValue(ClassicELBObject, "Connection Draining Policy Enabled"));
            expect(ordersPage.getTextBasedOnLabelName("Idle Timeout")).toEqual(jsonUtil.getValue(ClassicELBObject, "Idle Timeout"));

            //Validate Add On details
            ordersPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 2)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate estimated cost
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(classicELBInstanceTemplate.TotalCostWithAddOn);
            //Validate BOM table on order details
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Load Balancer-Network": "16.74", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(classicELBInstanceTemplate.EstimatedPriceWithAddOn);
            }

            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            //Validate Add-On tag
            expect(ordersHistoryPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate Add On Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickExpandArrowForServiceAddOn();
            ordersHistoryPage.getAddOnDetails().then(function (addOnDetails) {
                expect(addOnDetails[1]).toContain(addOnName);
                expect(addOnDetails[3]).toContain(imiConfigTemplate.TotalCost);
                expect(addOnDetails[4]).toContain("Completed");
            })
            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(ClassicELBObject, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Load Balancer Name")).toEqual(lbName);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Load Balancer Protocol")).toEqual(jsonUtil.getValue(ClassicELBObject, "Load Balancer Protocol"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Load Balancer Port")).toEqual(jsonUtil.getValue(ClassicELBObject, "Load Balancer Port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Protocol")).toEqual(jsonUtil.getValue(ClassicELBObject, "Instance Protocol"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Port")).toEqual(jsonUtil.getValue(ClassicELBObject, "Instance Port"));
            //  expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Policy Name")).toEqual(jsonUtil.getValue(ClassicELBObject, "Policy Name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(ClassicELBObject, "VPC"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Availability Zone")).toEqual("us-east-1a,us-east-1b");
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Subnet")).toEqual("subnet-c5f664b2 | us-east-1b,subnet-a68b538d | us-east-1a");
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Security Groups")).toEqual("sg-4e88232a | default");
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Select Policy Type")).toEqual(jsonUtil.getValue(ClassicELBObject, "Select Policy Type"));
            //  expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("LB Cookie Stickiness Policy Name")).toEqual(jsonUtil.getValue(ClassicELBObject, "LB Cookie Stickiness Policy Name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Cookie Expiration Period")).toEqual(jsonUtil.getValue(ClassicELBObject, "Cookie Expiration Period"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Enable Logging")).toEqual(jsonUtil.getValue(ClassicELBObject, "Enable Logging"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Ping Protocol")).toEqual(jsonUtil.getValue(ClassicELBObject, "Ping Protocol"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Ping Port")).toEqual(jsonUtil.getValue(ClassicELBObject, "Ping Port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Ping Path")).toEqual(jsonUtil.getValue(ClassicELBObject, "Ping Path"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Response Timeout")).toEqual(jsonUtil.getValue(ClassicELBObject, "Response Timeout"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Interval")).toEqual(jsonUtil.getValue(ClassicELBObject, "Interval"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Healthy Threshold")).toEqual(jsonUtil.getValue(ClassicELBObject, "Healthy Threshold"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Unhealthy Threshold")).toEqual(jsonUtil.getValue(ClassicELBObject, "Unhealthy Threshold"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Id")).toEqual(jsonUtil.getValue(ClassicELBObject, "Instance Id"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Cross Zone")).toEqual(jsonUtil.getValue(ClassicELBObject, "Cross Zone"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Connection Draining Policy Enabled")).toEqual(jsonUtil.getValue(ClassicELBObject, "Connection Draining Policy Enabled"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Idle Timeout")).toEqual(jsonUtil.getValue(ClassicELBObject, "Idle Timeout"));

            //Validate Add-On Details
            ordersHistoryPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 2)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 4)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(classicELBInstanceTemplate.TotalCostWithAddOn);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Load Balancer-Network": "16.74", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(classicELBInstanceTemplate.TotalCostWithAddOn);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Verify Output parameter in Inventory
            expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            inventoryPage.clickViewAddOnDetails(orderObject);
            //Verify Add On details in Inventory
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Provider Name", 3)).toBe("IMI");
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Instance Status", 2)).toBe("Active");
            expect(inventoryPage.getTextImiMangmntLevl()).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            //expect(inventoryPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(inventoryPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //verify bom for Add On
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(imiConfigTemplate.TotalCost);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Validate IMI tags
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                var tagList = tags.split(",");
                if (isDummyAdapterDisabled == "true") {
                    expect(tagList[5]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[6]).toContain(imiConfigTemplate.ServiceTierName);
                } else {
                    expect(tagList[2]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[0]).toContain(imiConfigTemplate.ServiceTierName);
                }

                orderFlowUtil.closeHorizontalSliderIfPresent();
            });

        });
    });

    if (isDummyAdapterDisabled == "true") {
        it('IMI-AWS-ClassicLoadBalancer- Configure IMI Manage service from Inventory having AddOn', function () {

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                util.waitForAngular();
                inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                    inventoryPage.clickConfigureImiService();
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });

            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost    
                //expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toEqual(imiConfigTemplate.TotalCost);
                inventoryPage.getTextUpdatedCostConfigureImiManagedService().then(function (totalCost) {
                    //totalCost = totalCost.replace("[ ", "").replace(" ]", "");
                    expect(totalCost.toString()).toEqual(imiConfigTemplate.TotalCost);
                });
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                ordersPage.open();
                //expect(util.getCurrentURL()).toMatch('orders');
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                //ordersHistoryPage.clickAddOnDetails();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                orderFlowUtil.closeHorizontalSliderIfPresent();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);
                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();

                //Validate Updated BOM on Inventory(AddOn+Manage Service)
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickOnInstanceTableActionIcon();
                inventoryPage.clickViewService();
                inventoryPage.clickBillOfMaterialsTabOrderDetails();
                //verify estimated cost for Add On
                expect(inventoryPage.getTextEstimatedCost()).toEqual(classicELBInstanceTemplate.TotalCostWithAddOn);
                inventoryPage.clickMoreLinkinBom();
                //Validate BOM table for Add on
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                inventoryPage.clickViewServiceClosebutton();
            });
        });

    }

    it('IMI-AWS-ClassicLoadBalancer- Delete service having addon from Inventory', function () {
        //Delete Service flow
        orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
        //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
        orderFlowUtil.approveDeletedOrder(orderObject);
        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
    });

    if (isDummyAdapterDisabled == "true") {
        it('IMI-AWS-ClassicLoadBalancer- Configure Manage service from Inventory', function () {
            var serviceDetailsMap = {};
            serviceName = "aws-auto-ClassicLoadBalancer-" + util.getRandomString(5);
            lbName = "LBName" + util.getRandomString(5)
            modifiedParamMap = { "Service Instance Name": serviceName, "Load Balancer Name": lbName };
            ClassicELBObject = JSON.parse(JSON.stringify(classicELBInstanceTemplate));
            orderObject.servicename = serviceName;
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(classicELBInstanceTemplate.provider);
            catalogPage.clickProviderOrCategoryCheckbox(classicELBInstanceTemplate.Category);
            catalogPage.clickConfigureButtonBasedOnName(classicELBInstanceTemplate.bluePrintName);

            //Fill Order Details
            orderFlowUtil.fillOrderDetails(classicELBInstanceTemplate, modifiedParamMap);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(classicELBInstanceTemplate.EstimatedPrice);

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                util.waitForAngular();
                inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                    inventoryPage.clickConfigureImiService();
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });

            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost    
                //expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toEqual(imiConfigTemplate.TotalCost);
                inventoryPage.getTextUpdatedCostConfigureImiManagedService().then(function (totalCost) {
                    //totalCost = totalCost.replace("[ ", "").replace(" ]", "");
                    expect(totalCost.toString()).toEqual(imiConfigTemplate.TotalCost);
                });
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                ordersPage.open();
                //expect(util.getCurrentURL()).toMatch('orders');
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                //ordersHistoryPage.clickAddOnDetails();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                orderFlowUtil.closeHorizontalSliderIfPresent();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);
                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                orderFlowUtil.closeHorizontalSliderIfPresent();

                //Delete Service flow
                orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            });
        });
    }
});
