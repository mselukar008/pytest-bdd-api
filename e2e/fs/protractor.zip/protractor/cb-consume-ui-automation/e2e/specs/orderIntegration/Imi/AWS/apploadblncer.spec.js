"use strict";
var Orders = require('../../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../../helpers/util.js'),
    jsonUtil = require('../../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../../testData/appUrls.json'),
    imiUtil = require('../../../../../helpers/imiApiUtil.js'),
    imiConfigTemplate = require('../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    imiManageServiceTemplate = require('../../../../../testData/OrderIntegration/Imi/manageService.json'),
    applicationELBInstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSApplicationLoadBalancer.json');

describe('IMI - ApplicationLoadBalancer', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, loadBalancerName, targetGroupName, AELBObject, inventoryPage;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = applicationELBInstanceTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        instanceName: applicationELBInstanceTemplate.instanceName,
        componentType: applicationELBInstanceTemplate.componentType,
        serviceId: applicationELBInstanceTemplate.serviceId,
        imiOrderSubmitted: "Configure IMI Managed Service"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
    });

    it('IMI:AWS ApplicationLoadBalancer - Verify E2E flow for ApplicationLoadBalancer with IMI Add On', function () {

        var serviceDetailsMap = {};

        serviceName = "aws-imi-alb-" + util.getRandomString(5);
        var addOnName = "alb-adOn-" + util.getRandomString(5);

        loadBalancerName = "ApplicationLoadBalancer" + util.getRandomString(5);
        targetGroupName = "TaregtGroupName" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": loadBalancerName, "Target Group Name": targetGroupName, "Add-On Name": addOnName };

        AELBObject = JSON.parse(JSON.stringify(applicationELBInstanceTemplate));
        orderObject.servicename = serviceName;
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(applicationELBInstanceTemplate.provider);
        catalogPage.clickProviderOrCategoryCheckbox(applicationELBInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(applicationELBInstanceTemplate.bluePrintName);

        //Update ApplicationLoadBalancer template with IMI template
        delete applicationELBInstanceTemplate["Order Parameters"]["Configure Add-ons"];
        applicationELBInstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
        applicationELBInstanceTemplate["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
        applicationELBInstanceTemplate["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
        applicationELBInstanceTemplate["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(applicationELBInstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            //Restore template with default data	
            applicationELBInstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiManageServiceTemplate["Configure Add-ons"];
            delete applicationELBInstanceTemplate["Order Parameters"]["IMI Main Parameters"];
            delete applicationELBInstanceTemplate["Order Parameters"]["Configure manage service"];
            delete applicationELBInstanceTemplate["Order Parameters"]["Review IMI Config"];

            serviceDetailsMap = requiredReturnMap;
           // util.waitForAngular();
            //Validate IMI configuration on Review Order page
            expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(placeOrderPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(placeOrderPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Provider Account", 1)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Provider Account IMI"));

            //Validate Review Order page with all Service Configuration
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            //expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(applicationELBInstanceTemplate.TotalCostWithAddOn);

            placeOrderPage.getEstimatedPrice_ReviewOrder().then(function (price) {
                price = parseFloat(price.replace("USD ", ""));
                price = util.roundOffNumber(price);
                expect("USD " + price.toFixed(2)).toEqual(applicationELBInstanceTemplate.TotalCostWithAddOn);
            });

            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Target Group Name"]).toEqual(requiredReturnMap["Expected"]["Target Group Name"]);
            expect(requiredReturnMap["Actual"]["Target Group Protocol"]).toEqual(requiredReturnMap["Expected"]["Target Group Protocol"]);
            expect(requiredReturnMap["Actual"]["Target Group Port"]).toEqual(requiredReturnMap["Expected"]["Target Group Port"]);
            expect(requiredReturnMap["Actual"]["Target Type"]).toEqual(requiredReturnMap["Expected"]["Target Type"]);
            expect(requiredReturnMap["Actual"]["IP"]).toEqual(requiredReturnMap["Expected"]["IP"]);
            expect(requiredReturnMap["Actual"]["Target Port"]).toEqual(requiredReturnMap["Expected"]["Target Port"]);
            expect(requiredReturnMap["Actual"]["Healthcheck Protocol"]).toEqual(requiredReturnMap["Expected"]["Healthcheck Protocol"]);
            expect(requiredReturnMap["Actual"]["Healthcheck Path"]).toEqual(requiredReturnMap["Expected"]["Healthcheck Path"]);
            expect(requiredReturnMap["Actual"]["Healthcheck Port"]).toEqual(requiredReturnMap["Expected"]["Healthcheck Port"]);
            expect(requiredReturnMap["Actual"]["Healthy Threshold"]).toEqual(requiredReturnMap["Expected"]["Healthy Threshold"]);
            expect(requiredReturnMap["Actual"]["Unhealthy Threshold"]).toEqual(requiredReturnMap["Expected"]["Unhealthy Threshold"]);
            expect(requiredReturnMap["Actual"]["Timeout In Seconds"]).toEqual(requiredReturnMap["Expected"]["Timeout In Seconds"]);
            expect(requiredReturnMap["Actual"]["Interval In Seconds"]).toEqual(requiredReturnMap["Expected"]["Interval In Seconds"]);
            expect(requiredReturnMap["Actual"]["Success Codes"]).toEqual(requiredReturnMap["Expected"]["Success Codes"]);
            expect(requiredReturnMap["Actual"]["VPC"]).toEqual(requiredReturnMap["Expected"]["VPC"]);
            expect(requiredReturnMap["Actual"]["Availability Zones"]).toEqual(requiredReturnMap["Expected"]["Availability Zones"]);
            expect(requiredReturnMap["Actual"]["Security Group"]).toEqual(requiredReturnMap["Expected"]["Security Group"]);
            expect(requiredReturnMap["Actual"]["Tag Value"]).toEqual(requiredReturnMap["Expected"]["Tag Value"]);

            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(applicationELBInstanceTemplate.bluePrintName, "New-AddOn");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate Add on on orders page
            expect(ordersPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
            expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            //util.waitForAngular();
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(AELBObject, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(AELBObject, "VPC"));
            expect(ordersPage.getTextBasedOnLabelName("Availability Zones")).toEqual("us-east-1a,us-east-1b");
            expect(ordersPage.getTextBasedOnLabelName("Subnet")).toEqual("subnet-c5f664b2 | us-east-1b,subnet-a68b538d | us-east-1a");
            expect(ordersPage.getTextBasedOnLabelName("Scheme")).toEqual(jsonUtil.getValue(AELBObject, "Scheme"));
            expect(ordersPage.getTextBasedOnLabelName("IP Address Type")).toEqual(jsonUtil.getValue(AELBObject, "IP Address Type"));
            expect(ordersPage.getTextBasedOnExactLabelName("First Load Balancer Port")).toEqual(jsonUtil.getValue(AELBObject, "First Load Balancer Port"));
            expect(ordersPage.getTextBasedOnExactLabelName("First Load Balancer Protocol")).toEqual(jsonUtil.getValue(AELBObject, "First Load Balancer Protocol"));
            //expect(ordersPage.getTextBasedOnExactLabelName("Second Load Balancer Port")).toEqual(jsonUtil.getValue(AELBObject, "Second Load Balancer Port"));
            //expect(ordersPage.getTextBasedOnExactLabelName("Second Load Balancer Protocol")).toEqual(jsonUtil.getValue(AELBObject, "Second Load Balancer Protocol"));
            expect(ordersPage.getTextBasedOnLabelName("Tag Key")).toEqual(jsonUtil.getValue(AELBObject, "Tag Key"));
            expect(ordersPage.getTextBasedOnLabelName("Tag Value")).toEqual(jsonUtil.getValue(AELBObject, "Tag Value"));
            expect(ordersPage.getTextBasedOnLabelName("Security Group")).toEqual(jsonUtil.getValue(AELBObject, "Security Group"));
            expect(ordersPage.getTextBasedOnLabelName("Target Group Name")).toEqual(targetGroupName);
            expect(ordersPage.getTextBasedOnLabelName("Target Group Protocol")).toEqual(jsonUtil.getValue(AELBObject, "Target Group Protocol"));
            expect(ordersPage.getTextBasedOnLabelName("Target Group Port")).toEqual(jsonUtil.getValue(AELBObject, "Target Group Port"));
            expect(ordersPage.getTextBasedOnLabelName("Target Type")).toEqual(jsonUtil.getValue(AELBObject, "Target Type"));
            expect(ordersPage.getTextBasedOnExactLabelName("IP")).toEqual(jsonUtil.getValue(AELBObject, "IP"));
            expect(ordersPage.getTextBasedOnLabelName("Target Port")).toEqual(jsonUtil.getValue(AELBObject, "Target Port"));
            expect(ordersPage.getTextBasedOnLabelName("Healthcheck Protocol")).toEqual(jsonUtil.getValue(AELBObject, "Healthcheck Protocol"));
            expect(ordersPage.getTextBasedOnLabelName("Healthcheck Path")).toEqual(jsonUtil.getValue(AELBObject, "Healthcheck Path"));
            expect(ordersPage.getTextBasedOnLabelName("Healthcheck Port")).toEqual(jsonUtil.getValue(AELBObject, "Healthcheck Port"));
            expect(ordersPage.getTextBasedOnLabelName("Healthy Threshold")).toEqual(jsonUtil.getValue(AELBObject, "Healthy Threshold"));
            expect(ordersPage.getTextBasedOnLabelName("Unhealthy Threshold")).toEqual(jsonUtil.getValue(AELBObject, "Unhealthy Threshold"));
            expect(ordersPage.getTextBasedOnLabelName("Timeout In Seconds")).toEqual(jsonUtil.getValue(AELBObject, "Timeout In Seconds"));
            expect(ordersPage.getTextBasedOnLabelName("Interval In Seconds")).toEqual(jsonUtil.getValue(AELBObject, "Interval In Seconds"));
            expect(ordersPage.getTextBasedOnLabelName("Success Codes")).toEqual(jsonUtil.getValue(AELBObject, "Success Codes"));

            //Validate Add On details
            ordersPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 2)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate estimated cost
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            //expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(applicationELBInstanceTemplate.TotalCostWithAddOn);
            ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails().then(function (price) {
                price = parseFloat(price.replace("USD ", ""));
                price = util.roundOffNumber(price);
                expect("USD " + price.toFixed(2)).toEqual(applicationELBInstanceTemplate.TotalCostWithAddOn);
            });
            //Validate BOM table on order details
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Load Balancer-Application": "16.74", "Managed Cloud Lite (This is the maximum estimated amount)": "USD 10.00", "Monthly billing (This is the maximum estimated amount)": "USD 20.00" }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page

                ordersPage.getTextFirstAmountOrdersTable().then(function (price) {
                    price = price.split(" /Month")[0];
                    price = parseFloat(price.replace("USD ", ""));
                    price = util.roundOffNumber(price);
                    expect("USD " + price.toFixed(2) + " /Month + USD 0.00 one time charges apply").toEqual(applicationELBInstanceTemplate.EstimatedPriceWithAddOn);
                });
            }

            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            //Validate Add-On tag
            expect(ordersHistoryPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate Add On Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickExpandArrowForServiceAddOn();
            ordersHistoryPage.getAddOnDetails().then(function (addOnDetails) {
                expect(addOnDetails[1]).toContain(addOnName);
                expect(addOnDetails[3]).toContain(imiConfigTemplate.TotalCost);
                expect(addOnDetails[4]).toContain("Completed");
            })
            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(AELBObject, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(AELBObject, "VPC"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Availability Zones")).toEqual("us-east-1a,us-east-1b");
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Subnet")).toEqual("subnet-c5f664b2 | us-east-1b,subnet-a68b538d | us-east-1a");
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Scheme")).toEqual(jsonUtil.getValue(AELBObject, "Scheme"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("IP Address Type")).toEqual(jsonUtil.getValue(AELBObject, "IP Address Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("First Load Balancer Port")).toEqual(jsonUtil.getValue(AELBObject, "First Load Balancer Port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("First Load Balancer Protocol")).toEqual(jsonUtil.getValue(AELBObject, "First Load Balancer Protocol"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Second Load Balancer Port")).toEqual(jsonUtil.getValue(AELBObject, "Second Load Balancer Port"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Second Load Balancer Protocol")).toEqual(jsonUtil.getValue(AELBObject, "Second Load Balancer Protocol"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Tag Key")).toEqual(jsonUtil.getValue(AELBObject, "Tag Key"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Tag Value")).toEqual(jsonUtil.getValue(AELBObject, "Tag Value"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Security Group")).toEqual(jsonUtil.getValue(AELBObject, "Security Group"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Target Group Name")).toEqual(targetGroupName);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Target Group Protocol")).toEqual(jsonUtil.getValue(AELBObject, "Target Group Protocol"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Target Group Port")).toEqual(jsonUtil.getValue(AELBObject, "Target Group Port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Target Type")).toEqual(jsonUtil.getValue(AELBObject, "Target Type"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("IP")).toEqual(jsonUtil.getValue(AELBObject, "IP"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Target Port")).toEqual(jsonUtil.getValue(AELBObject, "Target Port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Healthcheck Protocol")).toEqual(jsonUtil.getValue(AELBObject, "Healthcheck Protocol"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Healthcheck Path")).toEqual(jsonUtil.getValue(AELBObject, "Healthcheck Path"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Healthcheck Port")).toEqual(jsonUtil.getValue(AELBObject, "Healthcheck Port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Healthy Threshold")).toEqual(jsonUtil.getValue(AELBObject, "Healthy Threshold"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Unhealthy Threshold")).toEqual(jsonUtil.getValue(AELBObject, "Unhealthy Threshold"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Timeout In Seconds")).toEqual(jsonUtil.getValue(AELBObject, "Timeout In Seconds"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Interval In Seconds")).toEqual(jsonUtil.getValue(AELBObject, "Interval In Seconds"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Success Codes")).toEqual(jsonUtil.getValue(AELBObject, "Success Codes"));

            //Validate Add-On Details
            ordersHistoryPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 2)).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 4)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            // expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(applicationELBInstanceTemplate.TotalCostWithAddOn);
            ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab().then(function (price) {
                price = parseFloat(price.replace("USD ", ""));
                price = util.roundOffNumber(price);
                expect("USD " + price.toFixed(2)).toEqual(applicationELBInstanceTemplate.TotalCostWithAddOn);
            });

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Load Balancer-Application": "16.74", "Managed Cloud Lite (This is the maximum estimated amount)": "USD 10.00", "Monthly billing (This is the maximum estimated amount)": "USD 20.00" }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            //expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(applicationELBInstanceTemplate.TotalCostWithAddOn);
            ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab().then(function (price) {
                price = parseFloat(price.replace("USD ", ""));
                price = util.roundOffNumber(price);
                expect("USD " + price.toFixed(2)).toEqual(applicationELBInstanceTemplate.TotalCostWithAddOn);
            });
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Verify Output parameter in Inventory
            expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            inventoryPage.clickViewAddOnDetails(orderObject);
            //Verify Add On details in Inventory
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Provider Name", 3)).toBe("IMI");
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Instance Status", 2)).toBe("Active");
            expect(inventoryPage.getTextImiMangmntLevl()).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            //expect(inventoryPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(inventoryPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //verify bom for Add On
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(imiConfigTemplate.TotalCost);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": "USD 10.00", "Monthly billing (This is the maximum estimated amount)": "USD 20.00" }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Validate IMI tags
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                var tagList = tags.split(",");
                if (isDummyAdapterDisabled == "true") {
                    expect(tagList[1]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[2]).toContain(imiConfigTemplate.ServiceTierName);
                } else {
                    expect(tagList[2]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[0]).toContain(imiConfigTemplate.ServiceTierName);
                }
                orderFlowUtil.closeHorizontalSliderIfPresent();
            });

        });
    });

    if (isDummyAdapterDisabled == "true") {
        it('IMI-AWS-ApplicationLoadBalancer- Configure IMI Manage service having AddOn', function () {

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                util.waitForAngular();
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function (index) {
                    inventoryPage.clickConfigureImiServiceBasedOnIndex(index - 1);
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });

            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost               
                inventoryPage.getTextUpdatedCostConfigureImiManagedService().then(function (totalCost) {
                    expect(totalCost.toString()).toEqual(imiConfigTemplate.TotalCost);
                });
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": "USD 10.00", "Monthly billing (This is the maximum estimated amount)": "USD 20.00" }
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(applicationELBInstanceTemplate.bluePrintName, "AddOn-ManageService");
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                ordersPage.open();
                //expect(util.getCurrentURL()).toMatch('orders');
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                //ordersHistoryPage.clickAddOnDetails();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                orderFlowUtil.closeHorizontalSliderIfPresent();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": "USD 10.00", "Monthly billing (This is the maximum estimated amount)": "USD 20.00" }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);

                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                //Validate Updated BOM on Inventory(AddOn+Manage Service)
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickOnInstanceTableActionIcon();
                inventoryPage.clickViewService();
                inventoryPage.clickBillOfMaterialsTabOrderDetails();
                //verify estimated cost for Add On
                inventoryPage.getTextEstimatedCost().then(function (actPrice) {
                    var priceArr = util.roundOffTotalCost(actPrice, applicationELBInstanceTemplate.TotalCostWithAddOn);
                    expect(priceArr[0]).toEqual(priceArr[1]);
                });
                inventoryPage.clickMoreLinkinBom();
                //Validate BOM table for Add on
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                inventoryPage.clickViewServiceClosebutton();

            });
        });

    }

    it('IMI-AWS-ApplicationLoadBalancer- Delete service having addon from Inventory', function () {
        //Delete Service flow
        orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, applicationELBInstanceTemplate.bluePrintName);
        orderFlowUtil.approveDeletedOrder(orderObject);
        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
    });

    if (isDummyAdapterDisabled == "true") {
        it('IMI-AWS-ApplicationLoadBalancer- Configure Manage service from Inventory', function () {

            var serviceDetailsMap = {};
            serviceName = "aws-auto-ApplicationLoadBalancer-" + util.getRandomString(5);
            loadBalancerName = "ApplicationLoadBalancer" + util.getRandomString(5);
            targetGroupName = "TaregtGroupName" + util.getRandomString(5);
            modifiedParamMap = { "Service Instance Name": serviceName, "Name": loadBalancerName, "Target Group Name": targetGroupName };
            AELBObject = JSON.parse(JSON.stringify(applicationELBInstanceTemplate));
            orderObject.servicename = serviceName;
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(applicationELBInstanceTemplate.provider);
            catalogPage.clickProviderOrCategoryCheckbox(applicationELBInstanceTemplate.Category);

            catalogPage.clickConfigureButtonBasedOnName(applicationELBInstanceTemplate.bluePrintName);

            //Fill Order Details
            orderFlowUtil.fillOrderDetails(applicationELBInstanceTemplate, modifiedParamMap);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(applicationELBInstanceTemplate.bluePrintName, "ManageService");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(applicationELBInstanceTemplate.EstimatedPrice);

            modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                util.waitForAngular();
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function (index) {
                    inventoryPage.clickConfigureImiServiceBasedOnIndex(index - 1);
                    inventoryPage.clickOkButnInConfigrImiPopUp();
                });
            });

            orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
                //Validate Estimated Cost               
                inventoryPage.getTextUpdatedCostConfigureImiManagedService().then(function (totalCost) {
                    expect(totalCost.toString()).toEqual(imiConfigTemplate.TotalCost);
                });
                //Validate updated BOM table
                var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": "USD 10.00", "Monthly billing (This is the maximum estimated amount)": "USD 20.00" }
                expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
                //Submit order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(applicationELBInstanceTemplate.bluePrintName, "ManageSer-Inv");
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

                ordersPage.open();
                //expect(util.getCurrentURL()).toMatch('orders');
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service details
                ordersPage.clickFirstViewDetailsOrdersTable();
                //ordersHistoryPage.clickAddOnDetails();
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
                expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
                //Validate BOM on Approve order page
                ordersPage.clickBOMTabImi();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
                ordersPage.clickMoreLinkBom();
                orderFlowUtil.closeHorizontalSliderIfPresent();
                var priceMap = {};
                priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": "USD 10.00", "Monthly billing (This is the maximum estimated amount)": "USD 20.00" }
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                //Approve order            
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);

                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                //Validate Service Details
                ordersHistoryPage.clickServiceDetailsLink();
                ordersHistoryPage.getImiManagedServiceDetails().then(function (imiDetails) {
                    expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
                    expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
                });

                //Validate Estimated cost on order history page
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

                //Validate BOM table on order history page
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
                ordersHistoryPage.closeServiceDetailsSlider();
                //Validate BOM link on order history
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
                ordersHistoryPage.clickMoreLinkBom();
                expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);

                //Delete Service flow
                //orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                orderFlowUtil.deleteService(orderObject).then(async function(orderNo){
                    orderObject.deleteOrderNumber = orderNo;
                    await util.saveOrderId(applicationELBInstanceTemplate.bluePrintName, "ManageService-Delete", orderNo);
                    orderFlowUtil.approveDeletedOrder(orderObject);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
                });
                
            });
        });
    }

});
