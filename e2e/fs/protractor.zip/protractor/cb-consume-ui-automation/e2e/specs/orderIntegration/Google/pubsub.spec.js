"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    orderBuyerFlow = require('../../../../helpers/orderBuyerFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    testEnvironment = browser.params.url.includes("cb-qa-2") ? "QA 2" : browser.params.url.includes("customer1") ? "Customer 1" : "QA 4",
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    pubSubTemplate = require('../../../../testData/OrderIntegration/Google/pubsub.json');

describe('GCP - Pub/Sub', function () {
    var ordersPage, homePage, catalogPage, placeOrderPage, inventoryPage, orderHistoryPage, serviceName, topicName, suscrpName;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: pubSubTemplate.provider,
        category: pubSubTemplate.Category,
        catalogPageTitle: pubSubTemplate.catalogPageTitle,
        inputServiceNameWarning: pubSubTemplate.inputServiceNameWarning,
        orderSubmittedConfirmationMessage: pubSubTemplate.orderSubmittedConfirmationMessage,
        systemTagText: pubSubTemplate.systemTagText,
        orderFailureMsg: pubSubTemplate.orderFailureMsg,
        orderRejectedState: pubSubTemplate.orderRejectedState,
        orderFailedStatus: "Failed"

    };

    beforeAll(function () {
        ordersPage = new Orders();
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        orderHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        serviceName = "auto-pub-sub-" + util.getRandomString(5);
        topicName = "autom-" + util.getRandomString(5).toLowerCase();
        suscrpName = "autom-" + util.getRandomString(5).toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": topicName };
    });

    it('Google Pub/Sub : Verify fields on Main Parameters page are working fine while provisioning a Google Load Balancing', function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(pubSubTemplate.bluePrintName);
        expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
        placeOrderPage.setServiceNameText(serviceName);
        placeOrderPage.selectProviderAccount(pubSubTemplate.providerAccount);
        expect(placeOrderPage.isNextButtonEnabled()).toBe(true);

    });

    it('Google Pub/Sub : Verify Service Details are listed in Review Order page', function () {
        var pubsubObj = JSON.parse(JSON.stringify(pubSubTemplate));
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(pubSubTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetails(pubSubTemplate, modifiedParamMap).then(function (requiredReturnMap) {
        //Basic Details          
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
        //Additional Details
        expect(requiredReturnMap["Actual"]["Name"]).toEqual(requiredReturnMap["Expected"]["Name"]);
        expect(requiredReturnMap["Actual"]["Acknowledgment Deadline"]).toEqual(requiredReturnMap["Expected"]["Acknowledgment Deadline"]);
        if(browser.params.defaultCurrency == "USD") {
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(pubSubTemplate.TotalCost);    
        }    
    
    });
    });

    it('Google Pub/Sub : Verify Order Details once order is submitted from catalog page ', function () {

        var orderObject = {};
        var orderAmount;
        global.serviceName = serviceName;
        var pubsubObj = JSON.parse(JSON.stringify(pubSubTemplate));
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(pubSubTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetails(pubSubTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        expect(util.getCurrentURL()).toMatch('orders');
        ordersPage.searchOrderById(orderObject.orderNumber);
        expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
        ordersPage.getTextFirstAmountOrdersTable().then(function (text) {
            orderAmount = text;
        });
        ordersPage.clickFirstViewDetailsOrdersTable();
        expect(ordersPage.getTextBasedOnLabelName("Service Instance Prefix")).toEqual(serviceName);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
        expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
        expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);       
        expect(ordersPage.getTextBasedOnExactLabelName("Name")).toEqual(topicName);
        if(browser.params.defaultCurrency == "USD") {
            //Verify estimated price
            ordersPage.clickBillOfMaterialsTabOrderDetails().then(function () {
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(pubSubTemplate.TotalCost);
                ordersPage.clickServiceDetailSliderCloseButton();
            });
        }
        orderFlowUtil.denyOrder(orderObject);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Rejected');
    });

    if (isProvisioningRequired == "true") {
        var orderObject = {};
        it('TC-C187515 : Google Pub/Sub : E2E: Verify Order Provisioning is working fine from consume Application', function () {

            var pubsubObj = JSON.parse(JSON.stringify(pubSubTemplate));
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
            catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(pubSubTemplate.bluePrintName);
            orderObject.servicename = serviceName;
            global.serviceName = serviceName;
            orderFlowUtil.fillOrderDetails(pubSubTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(pubSubTemplate.bluePrintName, "New");
            //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == 'Completed') {
                    if (isDummyAdapterDisabled == "true") {
                        inventoryPage.open();
                        //Validate service Tags
                        inventoryPage.getImiTags(orderObject).then(function (tags) {
                            var tagList = tags.split(",");
                            var tagMap = inventoryPage.getServiceTags(tagList);
                            var mcmpTag = false;
                            if (isDummyAdapterDisabled == "true") {
                                if (Object.keys(tagMap).includes(messageStrings.systemTagText)) {
                                    mcmpTag = true;
                                }
                                expect(mcmpTag).toBe(true);
                                inventoryPage.clickLabelsViewDetailsLink();
                                //Verify system tags
                                expect(inventoryPage.validateSystemTagValueIsDisplayed()).toBe(true);
                                expect(inventoryPage.getSystemTagLabel()).toEqual(messageStrings.systemTagText);
                            }
                            expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderObject.orderNumber);
                            expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
                            expect(tagMap["serviceofferingname"]).toEqual(pubSubTemplate.serviceOffrngName);
                            orderFlowUtil.closeHorizontalSliderIfPresent();
                        });
                    }
                }
            });
        });

        it("PubSub - Delete service instance", function () {
            //orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
            //orderObject.servicename = "auto-pub-sub-G8vXe"
            orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, pubSubTemplate.bluePrintName);
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
        })
    };

    if (isProvisioningRequired == "true") {
        if (isDummyAdapterDisabled == 'true') {
            it('TC-C187515 : Google Pub/Sub : Verify Proper failure message in case of provisioning failure', function () {
                var orderObject = {};
                modifiedParamMap = { "Service Instance Name": serviceName, "Name": topicName, "Add Subscription": "click", "Subscription Name": suscrpName, "Delivery Type": "Push into an endpoint url", "Endpoint url": "test.com" };
                var pubsubObj = JSON.parse(JSON.stringify(pubSubTemplate));
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
                catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
                catalogPage.clickConfigureButtonBasedOnName(pubSubTemplate.bluePrintName);
                orderObject.servicename = serviceName;
                global.serviceName = serviceName;
                orderFlowUtil.fillOrderDetails(pubSubTemplate, modifiedParamMap);
                placeOrderPage.submitOrder();
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Failed');
                orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                    if (status == 'Failed') {
                        orderHistoryPage.getOrderFailureReason(orderObject.orderNumber).then(function (text) {
                            expect(text).toContain(messageStrings.orderFailureMsg);
                            orderHistoryPage.clickOrdersTableActionIcon();
                            orderHistoryPage.clickOnOrderTableActionsRetryOption();
                            orderHistoryPage.clickOnOrderTableActionsRetryYesButton();
                            orderHistoryPage.clickOnOrderTableActionsRetryModelOkButton();
                        });
                        orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.orderFailedStatus).then(function () {
                            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.orderFailedStatus);
                        });
                    }

                })
            });
        }
    }
});
