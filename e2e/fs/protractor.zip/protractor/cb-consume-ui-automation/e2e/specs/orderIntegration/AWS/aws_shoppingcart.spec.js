"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    efsInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSEFSInstance.json'),
    ec2InstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSEC2Instance.json'),
    snsInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSSNSInstance.json'),
    s3InstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSS3Instance.json'),
    cloudStorageTemplate = require('../../../../testData/OrderIntegration/Google/cloudstorage.json'),
    lambdaInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSLambdaInstance.json'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    userCredentialsTemplate = require('../../../../testData/credentials.json');


describe('AWS - Cart Functionlaities', function () {
    var ordersPage, homePage, catalogPage, placeOrderPage, cartListPage, serviceName, lambdaFunctionName, cartName, orderHistoryPage, userCredntialsObject;
    var modifiedParamMap = {};
    var EC = protractor.ExpectedConditions;
    var multiquantityParamMap = {};
    var messageStrings = {
        providerName: 'Amazon',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted',
        cartSuccessfullyDeletedMessage: "Your cart has successfully been deleted.",
        cartSuccessfullyEmptiedMessage: "Your cart has successfully been emptied.",
        cartSuccessfullyTransferredToMessage: "Your cart has successfully been transferred to",
        deleteCartItemHeader: "Delete Cart Item",
        cartItemDeleted: "Success"

    };

    beforeAll(function () {
        ordersPage = new Orders();
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        cartListPage = new CartListPage();
        orderHistoryPage = new OrderHistoryPage();
        userCredntialsObject = JSON.parse(JSON.stringify(userCredentialsTemplate));
        browser.driver.manage().window().maximize();
    });

    afterAll(async function () {
        //Make sure that super user is logged in
        catalogPage.open();
        catalogPage.getUserID(userCredentialsTemplate.superUserName).then(async function (status) {
            if (status != true) {
                //cartListPage.clickLogoutButton();
                await cartListPage.loginFromOtherUser(userCredentialsTemplate.superUserID, userCredentialsTemplate.superUserPassword);
                catalogPage.open();
                expect(catalogPage.getUserID(userCredentialsTemplate.superUserName)).toBe(true);
            }
        });
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        serviceName = "TestAutomationCart" + util.getRandomString(5);
        lambdaFunctionName = "lambda" + util.getRandomString(5);
        cartName = "aut-gcp-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": lambdaFunctionName, "Cart Service": "Click", "New Shopping Cart": "newCart", "Cart Name": cartName };
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
    });

    it('AWS - Shopping Cart : Add, edit and delete a service', function () {
        var orderObject = {};
        var LambdaINSObject = cartListPage.getCartTestData(lambdaInstanceTemplate);
        catalogPage.clickProviderOrCategoryCheckbox(LambdaINSObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(LambdaINSObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(LambdaINSObject, modifiedParamMap);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        orderObject.servicename = serviceName;        
        cartListPage.getCartDetails(cartName).then(function(index){			
			//Submit Cart Order
			cartListPage.submitOrder(index);
		});
       //placeOrderPage.clickOrderSubmitConfrmnBtn();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
       // orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == 'Completed') {
                var modifiedParamMap = { "EditService": true };
                orderFlowUtil.editService(orderObject);
                orderFlowUtil.fillOrderDetails(lambdaInstanceTemplate, modifiedParamMap).then(function () {
                    logger.info("Edit parameter details are filled.");
                    browser.sleep(5000);
                });
                placeOrderPage.submitOrder();
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                    if (status == 'Completed') {
                        //Verify updated details are reflected on order details page.						
                        ordersPage.clickFirstViewDetailsOrdersTable();
                        expect(ordersPage.getTextBasedOnExactLabelName("Description")).toEqual(jsonUtil.getValueEditParameter(LambdaINSObject, "Description"));
                        expect(ordersPage.getTextBasedOnExactLabelName("Runtime")).toEqual(jsonUtil.getValueEditParameter(LambdaINSObject, "Runtime"));
                        expect(ordersPage.getTextBasedOnExactLabelName("S3 Key")).toEqual(jsonUtil.getValueEditParameter(LambdaINSObject, "S3 Key"));
                        expect(ordersPage.getTextBasedOnExactLabelName("Handler")).toEqual(jsonUtil.getValueEditParameter(LambdaINSObject, "Handler"));
                        expect(ordersPage.getTextBasedOnExactLabelName("Timeout")).toEqual(jsonUtil.getValueEditParameter(LambdaINSObject, "Timeout"));
                        expect(ordersPage.getTextBasedOnExactLabelName("Memory")).toEqual(jsonUtil.getValueEditParameter(LambdaINSObject, "Memory"));
                        expect(ordersPage.getTextBasedOnExactLabelName("DLQ Resource")).toEqual(jsonUtil.getValueEditParameter(LambdaINSObject, "DLQ Resource"));
                        expect(ordersPage.getTextBasedOnExactLabelName("SNS ARN")).toEqual(jsonUtil.getValueEditParameter(LambdaINSObject, "SNS ARN"));
                        expect(ordersPage.getTextBasedOnExactLabelName("With VPC")).toEqual(jsonUtil.getValueEditParameter(LambdaINSObject, "With VPC"));
                        expect(ordersPage.getTextBasedOnExactLabelName("Key")).toEqual(jsonUtil.getValueEditParameter(LambdaINSObject, "Key"));
                        expect(ordersPage.getTextBasedOnExactLabelName("Value")).toEqual(jsonUtil.getValueEditParameter(LambdaINSObject, "Value"));
                        expect(ordersPage.getTextBasedOnExactLabelName("Layer")).toEqual(jsonUtil.getValueEditParameter(LambdaINSObject, "Layer"));

                        //Delete Service flow                     
                        orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                        //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                        orderFlowUtil.approveDeletedOrder(orderObject);
                        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
                    }
                });
            }
        });

    });
    it('AWS - Shopping Cart : Pricing Validation for Multiqunatity service', function () {
        var ec2InsObject = cartListPage.getCartTestData(ec2InstanceTemplate);        
        modifiedParamMap = { "Service Instance Name": serviceName, "Quantity": "3", "Cart Service": "Click", "New Shopping Cart": "newCart", "Cart Name": cartName };
        catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);
        //Check if cart checkbox is selected        
        cartListPage.isNewShoppingCartPresent();
        orderFlowUtil.fillOrderDetails(ec2InsObject, modifiedParamMap);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        //Verify Pricing       
		cartListPage.expandsTheCartItemsTab();
		cartListPage.clickActionIcon(1);
        cartListPage.clickCurrentCartBOMDetails();
        expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toBe(ec2InstanceTemplate.TotalEstimatedCost_Cart_Multiquantity);
		cartListPage.clickOnCloseButtonOfViewDetailSlidder();
		//Delete the cart.
		cartListPage.clickMenuIcon(0);
        cartListPage.deleteCart(0);
    });
    it('AWS - Shopping Cart : Add multiple Services to shopping cart, validate pricing, approve cart order and Delete the services', function () {
        var orderObject = {};
        var orderObj = {};
        var efsInsObject = cartListPage.getCartTestData(efsInstanceTemplate);
        orderObj.servicename = "efs-cart-" + util.getRandomString(5).toLowerCase();
        modifiedParamMap = { "Service Instance Name": orderObj.servicename, "Cart Service": "Click", "New Shopping Cart": "newCart", "Cart Name": cartName };

        catalogPage.clickProviderOrCategoryCheckbox(efsInsObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(efsInsObject.bluePrintName);
        //Check if cart checkbox is selected        
        cartListPage.isNewShoppingCartPresent();
        orderFlowUtil.fillOrderDetails(efsInsObject, modifiedParamMap);
        //Validate pricing on Review order page
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(efsInsObject.TotalCost);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        //Adding Another Service to same cart.
        catalogPage.open();
        orderObject.servicename = "aws-cart-" + util.getRandomString(5).toLowerCase();
        var topicName = "topicnamesns" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": orderObject.servicename, "Topic Name": topicName, "UpdateMainParamObject": false };
        //Remove TEAM,Environment & Application options from json object since its disabled while adding second service to the same cart
        var snsInsObj = orderFlowUtil.getMainParameterObject(snsInstanceTemplate, modifiedParamMap);
        catalogPage.clickProviderOrCategoryCheckbox(snsInsObj.Category);
        catalogPage.clickConfigureButtonBasedOnName(snsInsObj.bluePrintName);
        delete snsInsObj["Order Parameters"]["Main Parameters"];
        orderFlowUtil.fillOrderDetails(snsInsObj, modifiedParamMap);
        //Validate pricing on Review order page
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(snsInsObj.TotalCost);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        //Add a service with multiquantity with quantity as 3
        catalogPage.open();
        //var ec2InsObject = JSON.parse(JSON.stringify(ec2InstanceTemplate));
        var ec2ServiceName = "cart-ec2-" + util.getRandomString(3).toLowerCase();
        var groupName = "att-group-" + util.getRandomString(5);
        multiquantityParamMap = { "Service Instance Name": ec2ServiceName, "Quantity": "3", "Group Name": groupName, "UpdateMainParamObject": false };
        var ec2InsObject = orderFlowUtil.getMainParameterObject(ec2InstanceTemplate, multiquantityParamMap);

        catalogPage.clickProviderOrCategoryCheckbox(ec2InsObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);
        //Remove TEAM,Environment & Application options from json object since its disabled while adding second service to the same cart	
        delete ec2InsObject["Order Parameters"]["Main Parameters"];
        orderFlowUtil.fillOrderDetails(ec2InsObject, multiquantityParamMap);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        //Validate order Total on Shoppping cart page		
        cartListPage.getCartDetails(cartName).then(function(index){
			cartListPage.expandsTheCartItemsTabBasedOnIndex(index);
			cartListPage.validateEstimatedCostAllServicesCart(index).then(function (status) {
				expect(status).toEqual(true);
            });
            //Icrease quantity by 1 
            // cartListPage.increaseQuntity("Elastic Compute Cloud (EC2)");
            // ///Validate order Total with increased quantity on Shoppping cart page
            // cartListPage.validateEstimatedCostAllServicesCart().then(function (status) {
            //     expect(status).toEqual(true);
            // });
            //Delete multi-qunatity service from cart
            cartListPage.deleteItemsInShoppingCart(ec2ServiceName);
            cartListPage.clickOkInDeleteItemsInCartPopup();
            //Again Validate Estimated cost and Bill of materials of all services in cart after deleting 1 service
            //Validate Pricing after deleting cart item
			cartListPage.validateEstimatedCostAllServicesCart(index).then(function (status) {
				expect(status).toEqual(true);
			});
			//Submit Cart Order
			cartListPage.submitOrder(index);
        });     
       
        orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
       // orderObject.totalPrice = cartListPage.getTextTotalPriceOrderSubmittedModal();
        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

        var orderTotal = parseFloat((efsInsObject.TotalCost).replace("USD ", "")) + parseFloat((snsInsObj.TotalCost).replace("USD ", ""));
        orderTotal = orderTotal.toFixed(2);

        var serviceListWithPricing = {};
        serviceListWithPricing = { "Elastic Block Store (EBS)": efsInsObject.TotalCost, "Simple Notification Service (SN...": snsInsObj.TotalCost };

        if (isProvisioningRequired == "true") {
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 30);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == 'Completed') {
                    //Validate BOM of 1st and 2nd service on Approve Order -->Service Details page						
                    ordersPage.validateEstimatedCostAllServicesofCart(serviceListWithPricing).then(function (status) {
                        expect(status).toEqual(true);
                    });
                    //Validate pricing on order history page. Sum of price of 2 services should be equal to order total
                    orderHistoryPage.validatePricingonOrderHistory(orderObject.orderNumber, "USD " + orderTotal, serviceListWithPricing).then(function (status) {
                        expect(status).toEqual(true);
                    });

                    //Deleting Service 1
                    orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                    orderFlowUtil.approveDeletedOrder(orderObject);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 35);
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
                    orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject).then(function (status) {
                        if (status == 'Completed') {
                            //Deleting Service 2
                            orderObj.deleteOrderNumber = orderFlowUtil.deleteService(orderObj);
                            orderFlowUtil.approveDeletedOrder(orderObj);
                            orderFlowUtil.waitForDeleteOrderStatusChange(orderObj, 'Completed', 35);
                            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObj)).toBe('Completed');
                        }
                    });
                }

            });

        }

    });
    it('AWS - Shopping Cart : Edit/Empty/Delete shopping cart', function () {
        var topicName = "topicnamesns" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Topic Name": topicName, "Cart Service": "Click", "New Shopping Cart": "newCart", "Cart Name": cartName };
        var snsInsObj = orderFlowUtil.getMainParameterObject(snsInstanceTemplate, modifiedParamMap);
        catalogPage.clickProviderOrCategoryCheckbox(snsInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(snsInsObj.bluePrintName);
        //Check if cart checkbox is selected        
        cartListPage.isNewShoppingCartPresent();
        orderFlowUtil.fillOrderDetails(snsInsObj, modifiedParamMap);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        cartName = modifiedParamMap["Cart Name"];
        //Edit Cart Flow
        cartListPage.getCartDetails(cartName).then(async function(index){
		cartListPage.clickMenuIcon(index);
        	cartListPage.clickOnEditCartContext(index);
        
		var newCartName = "new-cart-" + util.getRandomString(4).toLowerCase();
		var modifiedParamMapEdit = { "Cart Name": newCartName };//, "Team":"EditCart", "Environment":"EditEnv", "Application":"EditApp"};
		//Edit the cart details
		cartListPage.editCartDetails(ec2InstanceTemplate, modifiedParamMapEdit).then(function (requiredReturnMap) {
		    //Click on update button cart button
		    cartListPage.clickOnUpdateCartButton().then(function () {
			browser.sleep(5000);
			orderFlowUtil.closeHorizontalSliderIfPresent();
			util.waitForAngular();
			//cartListPage.expandsTheCartDetailsTab().then(function () {
			    //Get the cart context details 
			   cartListPage.getCartContextDataBasedOnCartName(newCartName).then(function (actualMap) {
				//verify the updated cart details                        
				expect(actualMap["Actual"]["Environment"]).toBe(requiredReturnMap["Expected"]["Environment"]);
				expect(actualMap["Actual"]["Application"]).toBe(requiredReturnMap["Expected"]["Application"]);
				//verify cart name is updated		
				expect(cartListPage.getCartName()).toEqual(newCartName);
			    });                  

			//});
			//Empty Cart 		
			cartListPage.clickMenuIcon(index);
			cartListPage.emptyCart(index);
			expect(cartListPage.getTextSuccessfullyEmptiedCart()).toBe(messageStrings.cartSuccessfullyEmptiedMessage);
			//Delete the cart.
			cartListPage.clickMenuIcon(index);
			cartListPage.deleteCart();
			expect(cartListPage.getDeletedCartSuccessMessage()).toBe(messageStrings.cartSuccessfullyDeletedMessage);
			//Close Notification PopUp
			//cartListPage.closeNotificationPopUp();
			catalogPage.open();
			cartListPage.clickCartIcon();
			//expect cart not be present in Cart List
			cartListPage.clickOnViewAllCarts();			
			cartListPage.switchToFrame();
			expect(cartListPage.getCartDetails(cartName)).toEqual(-1);

		    });
		});
        });
    });
	
    it('AWS - Shopping Cart : Add Services of multiple providers to Cart, approve cart order and Delete the services', function () {
        var orderObject = {};
        var orderObj = {};
        var cloudStorageInsObject = cartListPage.getCartTestData(cloudStorageTemplate);
        orderObj.servicename = "auto-storage-" + util.getRandomString(5).toLowerCase();
        orderObj.bucketName = "qabucket-" + util.getRandomString(4).toLowerCase();
        modifiedParamMap = { "Service Instance Name": orderObj.servicename, "Name": orderObj.bucketName, "Cart Service": "Click", "New Shopping Cart": "newCart", "Cart Name": cartName };
        //uncheck Amazon provider
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(cloudStorageInsObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(cloudStorageInsObject.bluePrintName);
        //Check if cart checkbox is selected        
        cartListPage.isNewShoppingCartPresent();
        orderFlowUtil.fillOrderDetails(cloudStorageInsObject, modifiedParamMap);
        //Validate pricing on Review order page
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(cloudStorageInsObject.TotalCost);

        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        //Adding Another Service to same cart.
        //cartListPage.continueShopping();
        catalogPage.open();
        orderObject.servicename = "auto-ec2-" + util.getRandomString(5).toLowerCase();
        var groupName = "att-group-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": orderObject.servicename, "Group Name": groupName, "UpdateMainParamObject": false };
        var ec2InsObject = orderFlowUtil.getMainParameterObject(ec2InstanceTemplate, modifiedParamMap);
        //Remove TEAM,Environment & Application options from json object since its disabled while adding second service to the same cart
        delete ec2InsObject["Order Parameters"]["Main Parameters"];
        catalogPage.clickProviderOrCategoryCheckbox(ec2InsObject.provider);
        catalogPage.clickProviderOrCategoryCheckbox(ec2InsObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(ec2InsObject.bluePrintName);

        orderFlowUtil.fillOrderDetails(ec2InsObject, modifiedParamMap);
        //Validate pricing on Review order page for second service
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(ec2InsObject.TotalCost);

        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        cartListPage.getCartDetails(cartName).then(function(index){
			cartListPage.expandsTheCartItemsTabBasedOnIndex(index);
			cartListPage.validateEstimatedCostAllServicesCart(index).then(function (status) {
				expect(status).toEqual(true);
			});			
			//Submit Cart Order
			cartListPage.submitOrder(index);
		});        
        orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
      //  orderObject.totalPrice = cartListPage.getTextTotalPriceOrderSubmittedModal();
        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

        var orderTotal = parseFloat((cloudStorageInsObject.TotalCost).replace("USD ", "")) + parseFloat((ec2InsObject.TotalCost).replace("USD ", ""));
        var serviceListWithPricing = {};
        serviceListWithPricing = { "Cloud Storage": cloudStorageInsObject.TotalCost, "Elastic Compute Cloud (EC2)": ec2InsObject.TotalCost };

        if (isProvisioningRequired == "true") {
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 30);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == 'Completed') {
                    //Validate BOM of 1st and 2nd service on Approve Order -->Service Details page						
                    ordersPage.validateEstimatedCostAllServicesofCart(serviceListWithPricing).then(function (status) {
                        expect(status).toEqual(true);
                    });
                    //Validate pricing on order history page. Sum of price of 2 services should be equal to order total
                    orderHistoryPage.validatePricingonOrderHistory(orderObject.orderNumber, "USD " + orderTotal, serviceListWithPricing).then(function (status) {
                        expect(status).toEqual(true);
                    });
                    //Deleting Service 1
                    orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObj);
                    orderFlowUtil.approveDeletedOrder(orderObject);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 35);
                    orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject).then(function (status) {
                        if (status == 'Completed') {
                            //Deleting Service 2
                            orderObj.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                            orderFlowUtil.approveDeletedOrder(orderObj);
                            orderFlowUtil.waitForDeleteOrderStatusChange(orderObj, 'Completed', 35);
                            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObj)).toBe('Completed');
                        }
                    });
                }
            });
        }
    });
    it('AWS - Shopping Cart : Buyers ability to Transfer a shopping cart', async function () {
        var orderObject = {};
        var orderObj = {};
        var efsInsObject = cartListPage.getCartTestData(efsInstanceTemplate);
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(efsInsObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(efsInsObject.bluePrintName);
        //Check if cart checkbox is selected        
        cartListPage.isNewShoppingCartPresent();
        orderObj.servicename = "TestAutomationCart" + util.getRandomString(5).toLowerCase();
        modifiedParamMap = { "Service Instance Name": orderObj.servicename, "Cart Service": "Click", "New Shopping Cart": "newCart", "Cart Name": cartName };
        orderFlowUtil.fillOrderDetails(efsInsObject, modifiedParamMap);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        //catalogPage.open();
        cartName = modifiedParamMap["Cart Name"];
        cartListPage.getCartDetails(cartName).then(async function(index){
			cartListPage.clickMenuIcon(index);
			//Transfer the cart.
			cartListPage.tranferCart(index);        
            cartListPage.searchForUserID(userCredntialsObject.transferCartUser);
            cartListPage.confirmTransfer();
            expect(cartListPage.getTextSuccessMessageTransferCart()).toContain(messageStrings.cartSuccessfullyTransferredToMessage);
           // expect cart present in list and ownership is changed.
            catalogPage.open();
	    cartListPage.clickCartIcon();
	    cartListPage.clickOnViewAllCarts();			
	    cartListPage.switchToFrame();
            expect(cartListPage.getCartDetails(cartName)).not.toEqual(-1);
	   //Validate cart owner is now changed to tranfer cart
	    expect(cartListPage.getCartOwner(index)).toEqual(userCredntialsObject.transferCartOwner);	
            //Validate cart in transfered user
            await cartListPage.loginFromOtherUser(userCredntialsObject.transferCartUser, userCredntialsObject.transferCartPwd);
            catalogPage.open();
            cartListPage.clickCartIcon();
            cartListPage.clickOnViewAllCarts();			
			cartListPage.switchToFrame();
			cartListPage.getCartDetails(cartName).then(async function(indexNew){
				cartListPage.clickMenuIcon(indexNew);
				cartListPage.deleteCart(indexNew);
			});
            expect(cartListPage.getDeletedCartSuccessMessage()).toBe(messageStrings.cartSuccessfullyDeletedMessage);
            await cartListPage.loginFromOtherUser(browser.params.username, browser.params.password);
        });

    });
});

