/*************************************************
DESCRIPTION: The test script verifies the Server Load Balancer Service functionality    
AUTHOR: Leena chouhan
**************************************************/
"use strict";
var async = require('async'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    slbTemplate = require('../../../../testData/OrderIntegration/Alibaba/ServerLoadBalancer.json')

describe('Alibaba : Test case for Server Load Balancer Service', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, homePage;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: 'Alibaba Cloud',
        category: 'Network'
    };
    var servicename = "GslAutoSLB" + util.getRandomString(5);

    beforeAll(function () {
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        modifiedParamMap = {
            "Service Instance Name": servicename,
        };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    afterAll(function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    if (isProvisioningRequired == "true") {
        it('Aalibaba : TC-1 SLB -Verify Inventory / output parameters Details', function () {
            var orderObject = JSON.parse(JSON.stringify(slbTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            var returnObj = {};
            orderFlowUtil.fillOrderDetails(slbTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, orderObject.OrderStatus);

            //checking order on Inventory Page 
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();

            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
            expect(inventoryPage.getTextBasedOnLabelName(" Primary Zone:")).toEqual(jsonUtil.getValue(orderObject, "Primary Zone"));
            expect(inventoryPage.getTextBasedOnLabelName(" Instance Name:")).toEqual(jsonUtil.getValue(orderObject, "Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Backup Zone:")).toEqual(jsonUtil.getValue(orderObject, "Backup Zone"));
            expect(inventoryPage.getTextBasedOnLabelName(" Instance Type:")).toEqual(jsonUtil.getValue(orderObject, "Instance Type"));
            expect(inventoryPage.getTextBasedOnLabelName(" Instance Spec:")).toEqual(jsonUtil.getValue(orderObject, "Instance Spec"));
            inventoryPage.closeViewDetailsTab();
            homePage.open();
        });
    }

    it('Aalibaba : TC-2 Server Load Balancer- Verify Alibaba Server Load Balancer all parameters are present on Main parameters page', function () {
        var orderObject = JSON.parse(JSON.stringify(slbTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        expect(catalogDetailsPage.getServiceName()).toBe(orderObject.bluePrintName)
        expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true);
        expect(catalogDetailsPage.isPresentLinkToProviderSite()).toBe(true);
        expect(catalogDetailsPage.isPresentFeaturesLabel()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsLabel()).toBe(true);
        expect(catalogDetailsPage.getTextFeaturesLabel()).toBe(orderObject.FeaturesLabel);
        expect(catalogDetailsPage.getTextDetailsLabel()).toBe(orderObject.DetailsLabel);
        expect(catalogDetailsPage.isPresentFeaturesInfo()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsInfo()).toBe(true);
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
        catalogDetailsPage.clickCatalogFromBreadCrumbNav();
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
        catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
        homePage.open();
    });

    it('Aalibaba : TC-3 Server Load Balancer - Verify Alibaba Server Load Balancer review Parameters on review order page', function () {
        var orderObject = JSON.parse(JSON.stringify(slbTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderObject.servicename = servicename;
        orderFlowUtil.fillOrderDetails(slbTemplate, modifiedParamMap);

        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(orderObject.servicename);
        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);

        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Primary Zone:")).toEqual(jsonUtil.getValue(orderObject, "Primary Zone"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Instance Name:")).toEqual(jsonUtil.getValue(orderObject, "Instance Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Backup Zone:")).toEqual(jsonUtil.getValue(orderObject, "Backup Zone"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Instance Type:")).toEqual(jsonUtil.getValue(orderObject, "Instance Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Instance Spec:")).toEqual(jsonUtil.getValue(orderObject, "Instance Spec"));
        homePage.open();
    });

    it('Aalibaba : TC-4 Server Load Balancer - Verify all parameters present on View Order Details', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(slbTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(slbTemplate, modifiedParamMap);

        //Submit Order and grab the parameter values related to order 
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnLabelName("Region")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(ordersPage.getTextBasedOnLabelName("Primary Zone")).toEqual(jsonUtil.getValue(orderObject, "Primary Zone"));
        expect(ordersPage.getTextBasedOnLabelName("Instance Name")).toEqual(jsonUtil.getValue(orderObject, "Instance Name"));
        expect(ordersPage.getTextBasedOnLabelName("Backup Zone")).toEqual(jsonUtil.getValue(orderObject, "Backup Zone"));
        expect(ordersPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(orderObject, "Instance Type"));
        expect(ordersPage.getTextBasedOnLabelName("Instance Spec")).toEqual(jsonUtil.getValue(orderObject, "Instance Spec"));

        //Checking Bill Of Material
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(placeOrderPage.getTotalCost()).toBe(orderObject.TotalCost);

        //Deny order
        ordersPage.clickServiceDetailSliderCloseButton();
        orderFlowUtil.denyOrder(returnObj);
    });
});