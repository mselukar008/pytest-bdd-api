/*
* Test Cases for Transfer service automation 
* Author: Mahendra Selukar
*/

"use strict";

var EC = protractor.ExpectedConditions,
    async = require('async'),
    logGenerator = require("../../../../helpers/logGenerator.js"),
    Logger = logGenerator.getApplicationLogger(),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    userCredentialsTemplate = require('../../../../testData/credentials.json'),
    pubSubTemplate = require('../../../../testData/OrderIntegration/Google/pubsub.json');

describe('GCP-Transfer Service Flows', function () {
    var catalogPage, placeOrderPage, inventoryPage, serviceName, topicName, suscrpName, cartListPage;
    var modifiedParamMap = {};
    var messageStrings = { providerName: pubSubTemplate.provider, category: pubSubTemplate.Category };
    var pubSubObj = JSON.parse(JSON.stringify(pubSubTemplate));
    beforeAll(function () {
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        cartListPage = new CartListPage();
        browser.driver.manage().window().maximize();
    });

    afterAll(async function () {
        catalogPage.open();
        await cartListPage.loginFromOtherUser(userCredentialsTemplate.superUserID, userCredentialsTemplate.superUserPassword);
    });

    beforeEach(async function () {
        catalogPage.open();
        await cartListPage.loginFromOtherUser(userCredentialsTemplate.superUserID, userCredentialsTemplate.superUserPassword);
        serviceName = "auto-pub-sub-" + util.getRandomString(5);
        topicName = "autom-" + util.getRandomString(5).toLowerCase();
        suscrpName = "autom-" + util.getRandomString(5).toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": topicName };       
        catalogPage.open();
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(pubSubObj.Category);
    });


    if (isProvisioningRequired == "true") {
        it('Provision and change Ownership , Transfer with accept flow of transferred service', async function () {
            var pubSubObj = JSON.parse(JSON.stringify(pubSubTemplate));
            var orderObject = {};
            catalogPage.clickConfigureButtonBasedOnName(pubSubObj.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetails(pubSubTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(pubSubTemplate.orderSubmittedConfirmationMessage);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, pubSubTemplate.completedState, 50);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickOnActionIcon();
            inventoryPage.clickChangeOwner(1);
            inventoryPage.searchandSelectChangeOwner(userCredentialsTemplate.buyerUserID);
            inventoryPage.ConfirmChangeOwner();
            expect(inventoryPage.getSuccessNotificationPopupMsg()).toContain(pubSubTemplate.changeOwnerSuccessMessage);
            catalogPage.open();
            await cartListPage.loginFromOtherUser(userCredentialsTemplate.buyerUserID, userCredentialsTemplate.buyerUserPassword);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickOnActionIcon();
            inventoryPage.clickTransferService();
            inventoryPage.searchForTransferTeam(pubSubTemplate.transfereeTeamName);
            inventoryPage.confirmTransferService();
            expect(inventoryPage.getSuccessNotificationPopupMsg()).toContain(pubSubTemplate.transferSuccessMessage);
            inventoryPage.clickOnTransfersTab();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickOnActionIcon();
            inventoryPage.clickAcceptTransferService();
            inventoryPage.clickConfirmAcceptTransferService();
            expect(inventoryPage.getSuccessNotificationPopupMsg()).toContain(pubSubTemplate.transferSuccessMessage);
            inventoryPage.clickOnCompletedTransfersTab();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            expect(inventoryPage.getTextOfTransferorTeam()).toBe(pubSubTemplate.transferorTeamName);
            expect(inventoryPage.getTextOfTransfereeTeam()).toBe(pubSubTemplate.transfereeTeamName);
            expect(inventoryPage.getTextOfTransferStatus()).toBe(pubSubTemplate.completedTranferStatus);
            inventoryPage.clickOnAllServicesTab();
            orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, pubSubTemplate.completedOrderStatus);
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(pubSubTemplate.completedOrderStatus);
        });

        it('Provision and Bulk change Ownership and Transfer with cancel and Resend flow of transferred service ', async function () {
            var pubSubObj = JSON.parse(JSON.stringify(pubSubTemplate));
            var orderObject = {};
            catalogPage.clickConfigureButtonBasedOnName(pubSubObj.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetails(pubSubTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(pubSubTemplate.orderSubmittedConfirmationMessage);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, pubSubTemplate.completedState, 50);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickOnActionIcon();
            inventoryPage.clickChangeOwner(1);
            inventoryPage.searchandSelectChangeOwner(userCredentialsTemplate.buyerUserID);
            inventoryPage.ConfirmChangeOwner();
            expect(inventoryPage.getSuccessNotificationPopupMsg()).toContain(pubSubTemplate.changeOwnerSuccessMessage);
            catalogPage.open();
            await cartListPage.loginFromOtherUser(userCredentialsTemplate.buyerUserID, userCredentialsTemplate.buyerUserPassword);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.SelectCheckboxForFirstService();
            inventoryPage.clickTransferButton();
            inventoryPage.searchForTransferTeam(pubSubTemplate.transfereeTeamName);
            inventoryPage.confirmTransferService();
            expect(inventoryPage.getSuccessNotificationPopupMsg()).toContain(pubSubTemplate.transferSuccessMessage);
            inventoryPage.clickOnTransfersTab();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickOnActionIcon();
            inventoryPage.clickCancelTransferService();
            inventoryPage.ConfirmCancelTransferService();
            expect(inventoryPage.getSuccessNotificationPopupMsg()).toContain(pubSubTemplate.transferDenyAcceptMessage);
            inventoryPage.clickOnCompletedTransfersTab();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            expect(inventoryPage.getTextOfTransferorTeam()).toBe(pubSubTemplate.transferorTeamName);
            expect(inventoryPage.getTextOfTransfereeTeam()).toBe(pubSubTemplate.transfereeTeamName);
            expect(inventoryPage.getTextOfTransferStatus()).toBe(pubSubTemplate.canceledTranferStatus);
            inventoryPage.clickOnActionIcon();
            inventoryPage.clickOnResendButton();
            inventoryPage.ConfirmResendTransferService();
            expect(inventoryPage.getSuccessNotificationPopupMsg()).toContain(pubSubTemplate.transferSuccessMessage);
            inventoryPage.clickOnPendingTransfersTab();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickOnActionIcon();
            inventoryPage.clickCancelTransferService();
            inventoryPage.ConfirmCancelTransferService();
            inventoryPage.clickOnAllServicesTab();
            orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, pubSubTemplate.completedOrderStatus);
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(pubSubTemplate.completedOrderStatus);
        });
    }

    it('Provision and (Negative Scenario) change Ownership through Transfer with non accessible team and deny and View reason flow of transferred service ', async function () {
        var pubSubObj = JSON.parse(JSON.stringify(pubSubTemplate));
        var orderObject = {};
        catalogPage.clickConfigureButtonBasedOnName(pubSubObj.bluePrintName);
        orderObject.servicename = serviceName;
        orderFlowUtil.fillOrderDetails(pubSubTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(pubSubTemplate.orderSubmittedConfirmationMessage);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, pubSubTemplate.completedState, 50);
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickOnActionIcon();
        inventoryPage.clickTransferService();
        inventoryPage.searchForTransferTeam(pubSubTemplate.nonTranfereeTeamName);
        inventoryPage.confirmTransferService();
        expect(inventoryPage.getSuccessNotificationPopupMsg()).toContain(pubSubTemplate.nonTransfereeMessage);
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickOnActionIcon();
        inventoryPage.clickChangeOwner(1);
        inventoryPage.searchandSelectChangeOwner(userCredentialsTemplate.buyerUserID);
        inventoryPage.ConfirmChangeOwner();
        expect(inventoryPage.getSuccessNotificationPopupMsg()).toContain(pubSubTemplate.changeOwnerSuccessMessage);
        catalogPage.open();
        await cartListPage.loginFromOtherUser(userCredentialsTemplate.buyerUserID, userCredentialsTemplate.buyerUserPassword);
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickOnActionIcon();
        inventoryPage.clickTransferService();
        inventoryPage.searchForTransferTeam(pubSubTemplate.transfereeTeamName);
        inventoryPage.confirmTransferService();
        expect(inventoryPage.getSuccessNotificationPopupMsg()).toContain(pubSubTemplate.transferSuccessMessage);
        inventoryPage.clickOnTransfersTab();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickOnActionIcon();
        inventoryPage.clickDenyTransferService();
        inventoryPage.ConfirmDenyTranferService(pubSubTemplate.denyReason);
        expect(inventoryPage.getSuccessNotificationPopupMsg()).toContain(pubSubTemplate.transferDenyAcceptMessage);
        inventoryPage.clickOnCompletedTransfersTab();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        expect(inventoryPage.getTextOfTransferorTeam()).toBe(pubSubTemplate.transferorTeamName);
        expect(inventoryPage.getTextOfTransfereeTeam()).toBe(pubSubTemplate.transfereeTeamName);
        expect(inventoryPage.getTextOfTransferStatus()).toBe(pubSubTemplate.rejectedTranferStatus);
        inventoryPage.clickOnActionIcon();
        inventoryPage.clickViewReasonDeniedTransferService();
        expect(inventoryPage.getReasonTextofDeniedTransferService()).toBe(pubSubTemplate.denyReason);
        inventoryPage.clickOkButtonofDeniedModalTransferService();
        inventoryPage.clickOnAllServicesTab();
        orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
        orderFlowUtil.approveDeletedOrder(orderObject);
        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, pubSubTemplate.completedState);
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(pubSubTemplate.completedState);
    });

});
