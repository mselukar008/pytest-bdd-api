"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    Inventory = require('../../../pageObjects/inventory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    cloudFrontRTMPDistributionTemplate = require('../../../../testData/OrderIntegration/AWS/AWSCloudFrontRTMPDistribution.json'),
    cloudFrontWebDistributionTemplate = require('../../../../testData/OrderIntegration/AWS/AWSCloudFrontWebDistribution.json'),
    cloudTrailInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSCloudTrailInstance.json'),
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    memcachedInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSElastiCacheMemcached.json'),
    redisInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSElasticacheRedisInstance.json'),
    elasticSearchInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSElasticSearchInstance.json'),
    rdsInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSRDSInstance.json');

describe('AWS - e2e flows - Time Consuming Services', function () {
    var ordersPage, catalogPage, placeOrderPage, inventoryPage, serviceName, CloudFrontRTMPObject;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: 'Amazon',
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        orderStatus: 'Completed',
        isDummyTagValue: 'Yes',
        systemTagText: "ibm_mcmp_soiid"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new Inventory();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        catalogPage.open();
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    //Skipping below test as CLoudFrontRTMP is deprecated from AWS
    /*xit('TC-C176396 : AWS CloudFrtRTMP : Verify instance Order Provision and Deletion is working fine from consume App', function () {
        var orderObject = {};
        serviceName = "auto-aws-cloudfrontrtmpdistribution-" + util.getRandomString(5);
        var domainName = util.getRandomString(5) + ".s3.amazonaws.com"
        modifiedParamMap = { "Service Instance Name": serviceName, "Alternate Domain Names": domainName.toLowerCase() };
        catalogPage.clickProviderOrCategoryCheckbox(cloudFrontRTMPDistributionTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(cloudFrontRTMPDistributionTemplate.bluePrintName);
        orderObject.servicename = serviceName;
        orderFlowUtil.fillOrderDetails(cloudFrontRTMPDistributionTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(cloudFrontRTMPDistributionTemplate.bluePrintName, "New");
       // orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.orderStatus);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == messageStrings.orderStatus) {
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, cloudFrontRTMPDistributionTemplate.bluePrintName);
                //orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.orderStatus);
            }
        });
    });*/

    it('TC-C177201: AWS CloudFrtWebDist : Verify instance Order Provision and Deletion is working fine from consume App', function () {
        var orderObject = {};
        serviceName = "auto-aws-CloudFrtWebDist-" + util.getRandomString(5);
        var originId = "origin" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Origin ID": originId };
        catalogPage.clickProviderOrCategoryCheckbox(cloudFrontWebDistributionTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(cloudFrontWebDistributionTemplate.bluePrintName);
        orderObject.servicename = serviceName;
        orderFlowUtil.fillOrderDetails(cloudFrontWebDistributionTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(cloudFrontWebDistributionTemplate.bluePrintName, "New");
      //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.orderStatus);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == messageStrings.orderStatus) {
                //orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, cloudFrontWebDistributionTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.orderStatus);
            }
        });
    });

    it('TC-C177215: AWS CloudTrail : Verify instance Order Provision and Deletion is working fine from consume App', function () {
        var orderObject = {};
        serviceName = "aws-auto-cloudtrail-" + util.getRandomString(5);
        var bucketName = "buckettestaut" + util.getRandomString(5);
        var trailName = "att-" + util.getRandomString(5) + "-trail";
        var kmsKey = "key1-" + util.getRandomString(5);
        bucketName = bucketName.toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "Trail Name": trailName.toLowerCase(), "S3 Bucket": bucketName, "KMS Key": kmsKey.toLowerCase() };

        catalogPage.clickFirstCategoryCheckBoxBasedOnName(cloudTrailInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(cloudTrailInstanceTemplate.bluePrintName);
        orderObject.servicename = serviceName;
        orderFlowUtil.fillOrderDetails(cloudTrailInstanceTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(cloudTrailInstanceTemplate.bluePrintName, "New");
        //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.orderStatus);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == messageStrings.orderStatus) {
                orderObject.componentType = cloudTrailInstanceTemplate.componentType;
                //Validate service Tags
                inventoryPage.open();
                inventoryPage.getImiTags(orderObject).then(function (tags) {
                    var tagList = tags.split(",");
                    var tagMap = inventoryPage.getServiceTags(tagList);
                    var mcmpTag = false;
                    if (isDummyAdapterDisabled == "false") {
                        //verifying flags for dummy adapter
                        expect(tagMap["IsUsingDummy"]).toEqual(messageStrings.isDummyTagValue);
                        expect(tagMap["Name"]).toEqual(cloudTrailInstanceTemplate.bluePrintName);
                        expect(tagMap["PhysicalId"]).toContain(serviceName);
                        expect(Object.keys(tagMap).includes("Test")).toBe(true);
                        expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                    } else {
                        //verifying a system tag
                        expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                    }
                    orderFlowUtil.closeHorizontalSliderIfPresent();
                });
                //orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, cloudTrailInstanceTemplate.bluePrintName);
                //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.orderStatus);
            }
        });
    });

    it('TC-C179955: AWS ElastiCache Memcached - E2E : Verify instance Order Provision and Deletion is working fine from consume App', function () {
        var orderObject = {};
        serviceName = "auto-aws-eleasticmemcache-" + util.getRandomString(5);
        var name = "namememcached" + util.getRandomString(5);
        name = name.toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": name };
        catalogPage.clickProviderOrCategoryCheckbox(memcachedInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(memcachedInstanceTemplate.bluePrintName);
        orderObject.servicename = serviceName;
        orderFlowUtil.fillOrderDetails(memcachedInstanceTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(memcachedInstanceTemplate.bluePrintName, "New");
        //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.orderStatus);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == messageStrings.orderStatus) {
                //Validate service Tags
                inventoryPage.open();
                inventoryPage.getImiTags(orderObject).then(function (tags) {
                    var tagList = tags.split(",");
                    var tagMap = inventoryPage.getServiceTags(tagList);
                    var mcmpTag = false;
                    if (isDummyAdapterDisabled == "false") {
                        //verifying flags for dummy adapter
                        expect(tagMap["IsUsingDummy"]).toEqual(messageStrings.isDummyTagValue);
                        expect(tagMap["Name"]).toEqual(memcachedInstanceTemplate.bluePrintName);
                        expect(tagMap["PhysicalId"]).toContain(serviceName);
                        expect(Object.keys(tagMap).includes("Test")).toBe(true);
                        expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                    } else {
                        //verifying a system tag
                        expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                    }
                    orderFlowUtil.closeHorizontalSliderIfPresent();
                });
                //orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, memcachedInstanceTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.orderStatus);
            }
        });
    });

    it('TC-C180119: AWS ElastiCache Redis - E2E : Verify instance Order Provision and Deletion is working fine from consume App', function () {
        var orderObject = {};
        serviceName = "aws-auto-elastic-cacheredis" + util.getRandomString(3);
        var redisName = "Redis" + util.getRandomString(5);
        redisName = redisName.toLowerCase();
        modifiedParamMap = { "Service Instance Name": serviceName, "Name": redisName };
        catalogPage.clickProviderOrCategoryCheckbox(redisInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(redisInstanceTemplate.bluePrintName);
        orderObject.servicename = serviceName;
        orderFlowUtil.fillOrderDetails(redisInstanceTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(redisInstanceTemplate.bluePrintName, "New");
        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.orderStatus);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == messageStrings.orderStatus) {
                //Validate service Tags
                inventoryPage.open();
                inventoryPage.getImiTags(orderObject).then(function (tags) {
                    var tagList = tags.split(",");
                    var tagMap = inventoryPage.getServiceTags(tagList);
                    var mcmpTag = false;
                    if (isDummyAdapterDisabled == "false") {
                        //verifying flags for dummy adapter
                        expect(tagMap["IsUsingDummy"]).toEqual(messageStrings.isDummyTagValue);
                        expect(tagMap["Name"]).toEqual(redisInstanceTemplate.bluePrintName);
                        expect(tagMap["PhysicalId"]).toContain(serviceName);
                        expect(Object.keys(tagMap).includes("Test")).toBe(true);
                        expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                    } else {
                        //verifying a system tag
                        expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                    }
                    orderFlowUtil.closeHorizontalSliderIfPresent();
                });
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, redisInstanceTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.orderStatus);
            }
        });
    });

    it('TC-C180448: AWS ElasticSearch : Verify instance Order Provision and Deletion is working fine from consume App', function () {
        var orderObject = {};
        var elasticName = "att-" + util.getRandomString(5);
        serviceName = "aws-auto-elastic-search" + util.getRandomString(3);
        modifiedParamMap = { "Service Instance Name": serviceName, "Elasticsearch Domain Name": elasticName.toLowerCase() };
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(elasticSearchInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(elasticSearchInstanceTemplate.bluePrintName);
        orderObject.servicename = serviceName;
        orderFlowUtil.fillOrderDetails(elasticSearchInstanceTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(elasticSearchInstanceTemplate.bluePrintName, "New");
        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.orderStatus);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == messageStrings.orderStatus) {
                //Validate service Tags
                inventoryPage.open();
                inventoryPage.getImiTags(orderObject).then(function (tags) {
                    var tagList = tags.split(",");
                    var tagMap = inventoryPage.getServiceTags(tagList);
                    var mcmpTag = false;
                    if (isDummyAdapterDisabled == "false") {
                        //verifying flags for dummy adapter
                        expect(tagMap["IsUsingDummy"]).toEqual(messageStrings.isDummyTagValue);
                        expect(tagMap["Name"]).toEqual(elasticSearchInstanceTemplate.bluePrintName);
                        expect(tagMap["PhysicalId"]).toContain(serviceName);
                        expect(Object.keys(tagMap).includes("Test")).toBe(true);
                        expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                    } else {
                        //verifying a system tag
                        expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                    }
                    orderFlowUtil.closeHorizontalSliderIfPresent();
                });
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, elasticSearchInstanceTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.orderStatus);
            }
        });
    });

    it('TC-C172286 : AWS RDS - E2E : Verify instance Order Provision,Edit and Deletion is working fine from consume App', function () {
        var orderObject = {};
        var serviceName = "aws-rds-" + util.getRandomString(5);
        var dbInstanceIdentifier = "TestRdsInstance" + util.getRandomString(5);
        var dbName = "TestDb" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "DB instance identifier": dbInstanceIdentifier.toLowerCase(), "Database name": dbName.toLowerCase() };
        catalogPage.clickProviderOrCategoryCheckbox(rdsInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(rdsInstanceTemplate.bluePrintName);
        orderObject.servicename = serviceName;

        orderFlowUtil.fillOrderDetails(rdsInstanceTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(rdsInstanceTemplate.bluePrintName, "New");
        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.orderStatus, 800);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.orderStatus);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == messageStrings.orderStatus) {
                //Validate service Tags
                inventoryPage.open();
                inventoryPage.getImiTags(orderObject).then(function (tags) {
                    var tagList = tags.split(",");
                    var tagMap = inventoryPage.getServiceTags(tagList);
                    var mcmpTag = false;
                    if (isDummyAdapterDisabled == "false") {
                        //verifying flags for dummy adapter
                        expect(tagMap["IsUsingDummy"]).toEqual(messageStrings.isDummyTagValue);
                        expect(tagMap["Name"]).toEqual(rdsInstanceTemplate.bluePrintName);
                        expect(tagMap["PhysicalId"]).toContain(serviceName);
                        expect(Object.keys(tagMap).includes("Test")).toBe(true);
                        expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                    } else {
                        //verifying a system tag
                        expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                    }
                    orderFlowUtil.closeHorizontalSliderIfPresent();
                });

                var modifiedParamMap = { "EditService": true };
                orderFlowUtil.editService(orderObject);
                orderFlowUtil.fillOrderDetails(rdsInstanceTemplate, modifiedParamMap).then(function () {
                    expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(rdsInstanceTemplate.TotalCostPostEdit);
                });
                placeOrderPage.submitOrder();
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(rdsInstanceTemplate.bluePrintName, "Edit");
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                    if (status == 'Completed') {
                        //Verify updated details are reflected on order details page.						
                        ordersPage.clickFirstViewDetailsOrdersTable();
                        expect(ordersPage.getTextBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValueEditParameter(rdsInstanceTemplate, "DB instance class"));
                        expect(ordersPage.getTextBasedOnLabelName("Multi-AZ deployment")).toEqual(jsonUtil.getValueEditParameter(rdsInstanceTemplate, "Multi AZ deployment"));
                        expect(ordersPage.getTextBasedOnLabelName("Storage type")).toEqual(jsonUtil.getValueEditParameter(rdsInstanceTemplate, "Storage type"));
                        expect(ordersPage.getTextBasedOnLabelName("Provisioned IOPS")).toEqual(jsonUtil.getValueEditParameter(rdsInstanceTemplate, "Provisioned IOPS"));
                        expect(ordersPage.getTextBasedOnLabelName("Copy tags to snapshot")).toEqual(jsonUtil.getValueEditParameter(rdsInstanceTemplate, "Copy tags to snapshot"));
                        expect(ordersPage.getTextBasedOnLabelName("Enhanced monitoring")).toEqual(jsonUtil.getValueEditParameter(rdsInstanceTemplate, "Enhanced monitoring"));
                        expect(ordersPage.getTextBasedOnLabelName("Monitoring Role")).toEqual(jsonUtil.getValueEditParameter(rdsInstanceTemplate, "Monitoring Role"));
                        expect(ordersPage.getTextBasedOnLabelName("Auto minor version upgradee")).toEqual(jsonUtil.getValueEditParameter(rdsInstanceTemplate, "Auto minor version upgrade"));

                        ordersPage.clickBillOfMaterialsTabOrderDetails();
                        expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(rdsInstanceTemplate.TotalCostPostEdit);
                        ordersPage.clickServiceDetailSliderCloseButton();
                        //Delete Service flow                    
                        orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, rdsInstanceTemplate.bluePrintName);
                        orderFlowUtil.approveDeletedOrder(orderObject);
                        orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
                    }
                });

            }
        });
    });

});
