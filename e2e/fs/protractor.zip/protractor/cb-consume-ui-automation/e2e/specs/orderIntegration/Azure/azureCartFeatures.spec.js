/*
Spec_Name: azureCartFeatures.spec.js 
Description: This spec will cover  testing of Cart Features for shopping cart which includes Empty Cart , Transfer Cart,  Delete Cart and Edit Cart.
Author: Atiksha Batra
*/

"use strict";

var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    DashBoard = require('../../../pageObjects/dashBoard.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    CatalogDiscoveryPage = require('../../../pageObjects/catalogDiscovery.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    testEnvironment = browser.params.url.includes("cb-qa-2") ? "QA 2" : browser.params.url.includes("customer1") ? "Customer 1" : "QA 4",
    azshopBagTemplate = require('../../../../testData/OrderIntegration/Azure/AzShoppingCart.json'),
    credentialJson =require('../../../../testData/credentials.json'),
    superUserUsername = browser.params.username,
    superUserPassword = browser.params.password;


describe('Azure - Shopping cart Features', function () {
    var orders, homePage, inventoryPage,dashBoard, nhName,nsName,catalogPage, placeOrderPage, serviceName1, serviceName2, cartName, rgName1, rgName2, avName, dzName, cartListPage, editedCartName;
    var modifiedParamMap = {};
    var modifiedParamMap1 = {};
    var modifiedParamMap2 = {};
    var messageStrings = {
        providerName: 'Azure',
        orderSubmittedConfirmationMessage: 'Order Submitted',
        cartSuccessfullyTransferredToMessage: "Your cart has successfully been transferred to",
        cartSuccessfullyDeletedMessage: "Your cart has successfully been deleted.",
        cartSuccessfullyEmptiedMessage: "Your cart has successfully been emptied.",
        cartItemsSuccessfullyDeletedMessage: "The cart item(s) have been deleted successfully.",
        cartSuccessfullyAddedAddOnMessage  : "The add-ons have been successfully updated."
    };
    var modifiedParamMapEdit = {};

    serviceName1 = "AzAVshopBagnewServ" + util.getRandomString(5);
    serviceName2 = "AzDnshopBagnewServ" + util.getRandomString(5);
    cartName = "AAzshopBagCart" + util.getRandomString(5);
    nhName = "nhName" + util.getRandomString(5);
    nsName = "nsName" + util.getRandomString(5)
    rgName1 = "gslauto_tcAVshopBagnewRG" + util.getRandomString(5);
    rgName2 = "gslauto_tcDnshopBagnewRG" + util.getRandomString(5);
    avName = "shopbagnewav" + util.getRandomNumber(5);
    dzName = "shopbag.newdz" + util.getRandomNumber(5);
    editedCartName = "agslslEditCart" + util.getRandomString(5);
    var addOnName = "av-adOn-" + util.getRandomString(5);
    modifiedParamMap2 = {"Service Instance Name": serviceName1, "Cart Name": cartName, "Cart Service":"Click", "New Shopping Cart": "newCart", "New Resource Group": rgName1, "Notification Hub Name": nhName, "New Namespace Name": nsName, "Add-On Name": addOnName };
    modifiedParamMap = { "Service Instance Name": serviceName1, "Cart Name": cartName, "Cart Service": "Click", "New Shopping Cart": "newCart", "New Resource Group": rgName1, "Availability Set Name": avName };
    modifiedParamMap1 = { "Service Instance Name": serviceName2, "Cart Name": cartName, "New Resource Group": rgName1, "DNS Zone Name": dzName };

    //Update template with IMI template
    //delete Template["Order Parameters"]["Configure Add-ons"];
    beforeAll(async function () {
        orders = new Orders();
        homePage = new HomePage();
        dashBoard = new DashBoard();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        cartListPage = new CartListPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
        await cartListPage.loginFromOtherUser(superUserUsername, superUserPassword);
        // catalogPage.checkCurrentUser(credentialJson.superUserName);
    });

    beforeEach(function () {
       homePage.open();
       catalogPage.open();
       cartListPage.clickOnStorageHeaderLink();
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
    });
    afterAll(async function () {
        //Logout from the current user
    //     homePage.open();
      // catalogPage.open();
    // cartListPage.clickUserIcon();
    // cartListPage.clickLogoutButton();
    //Login with super-cbadmn user
    await cartListPage.loginFromOtherUser(superUserUsername, superUserPassword);
    catalogPage.open();
    });

    it("Add one service into cart, edit the cart details and delete the cart", function () {
        var orderObject = {};
        var orderObj = {};

        var avshopObj = JSON.parse(JSON.stringify(azshopBagTemplate.avServ));
        catalogPage.open();
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(avshopObj.Category);
        catalogPage.searchForBluePrint(avshopObj.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(avshopObj.bluePrintName);
        orderObj.servicename = serviceName1;
        orderFlowUtil.fillOrderDetails(avshopObj, modifiedParamMap);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        cartListPage.clickMenuIcon(0);
        cartListPage.clickOnEditCartContext(0);
        modifiedParamMapEdit = { "Cart Name": editedCartName };
        //Edit the cart details
        cartListPage.editCartDetails(azshopBagTemplate, modifiedParamMapEdit).then(function (requiredReturnMap) {
            //Click on update button cart button
            cartListPage.clickOnUpdateCartButton().then(function () {
                //util.waitForAngular();
                //Get the cart context details 
                cartListPage.getCartContextData().then(function (actualMap) {
                    //verify the updated cart details
                    expect(cartListPage.getCartName(editedCartName)).toBe(requiredReturnMap["Expected"]["Cart Name"]);
                });
            });
        });
        cartListPage.clickMenuIcon(0);
        //Delete the cart.
        cartListPage.deleteCart(0);
        expect(cartListPage.getDeletedCartSuccessMessage()).toBe(messageStrings.cartSuccessfullyDeletedMessage);
    });

    it('Azure : C195936 : Buyers ability to remove all service(s) at once (Empty Cart) BUT the shopping cart is existing there with Empty status  ', function () {
        var orderObj = {};
        var avshopObj = JSON.parse(JSON.stringify(azshopBagTemplate.avServ));
        catalogPage.clickProviderOrCategoryCheckbox(avshopObj.Category);
        catalogPage.searchForBluePrint(avshopObj.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(avshopObj.bluePrintName);
        orderObj.servicename = serviceName1;
        orderFlowUtil.fillOrderDetails(avshopObj, modifiedParamMap);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        cartListPage.clickMenuIcon(0);
        //Empty the cart.
        cartListPage.emptyCart(0);
        cartListPage.clickMenuIcon(0);
        //Delete the cart.
        cartListPage.deleteCart(0);
        expect(cartListPage.getDeletedCartSuccessMessage()).toBe(messageStrings.cartSuccessfullyDeletedMessage);
    });
    it('Azure :C195765: Buyers ability to delete a  shopping cart', function () {
        var orderObj = {};
        var avshopObj = JSON.parse(JSON.stringify(azshopBagTemplate.avServ));
        catalogPage.clickProviderOrCategoryCheckbox(avshopObj.Category);
        catalogPage.searchForBluePrint(avshopObj.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(avshopObj.bluePrintName);
        orderObj.servicename = serviceName1;
        orderFlowUtil.fillOrderDetails(avshopObj, modifiedParamMap);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        //Delete the cart.
        cartListPage.clickMenuIcon(0);
        cartListPage.deleteCart(0);

        expect(cartListPage.getDeletedCartSuccessMessage()).toBe(messageStrings.cartSuccessfullyDeletedMessage);
        cartListPage.clickCloseOnDeleteSuccessBox(); 
    });
    
    it("Add one service into cart,  Check service details and BOM, and delete the cart item", function () {
        var notiHubObj = JSON.parse(JSON.stringify(azshopBagTemplate.notiHub));
        var modifiedParamMapNh = { "Service Instance Name": serviceName1, "Cart Name": cartName, "Cart Service": "Click", "New Shopping Cart": "newCart", "New Resource Group": rgName1, "Notification Hub Name": nhName, "New Namespace Name": nsName };
        catalogPage.open();
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(notiHubObj.Category);
        catalogPage.searchForBluePrint(notiHubObj.bluePrintName);
        catalogPage.clickConfigureButtonBasedOnName(notiHubObj.bluePrintName);
        orderFlowUtil.fillOrderDetails(notiHubObj, modifiedParamMapNh);
        placeOrderPage.addToShoppingCart();
        expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
        cartListPage.expandsTheCartItemsTab();
        util.waitForAngular();
        browser.waitForAngularEnabled(false); 
        // view Service details of cart item
        cartListPage.clickActionIcon(1);
        cartListPage.clickCurrentCartServiceDetails();
        expect(cartListPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(notiHubObj, "New Resource Group Required"));
        expect(cartListPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName1);
        expect(cartListPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(notiHubObj, "Location"));
        expect(cartListPage.getTextBasedOnExactLabelName("Notification Hub Name")).toEqual(nhName);
        expect(cartListPage.getTextBasedOnExactLabelName("New Namespace Name")).toEqual(nsName);
        expect(cartListPage.getTextBasedOnExactLabelName("Namespace Location")).toEqual(jsonUtil.getValue(notiHubObj, "Namespace Location"));
        expect(cartListPage.getTextBasedOnExactLabelName("Namespace Pricing Tier")).toEqual(jsonUtil.getValue(notiHubObj, "Namespace Pricing Tier"));
        cartListPage.clickOnCloseButtonOfViewDetailSlidder();
        //Bill of Material
        if (browser.params.defaultCurrency == "USD") {
            cartListPage.clickActionIcon(1);
            cartListPage.clickCurrentCartBOMDetails();
            expect(orders.getEstimatedCostFromEstimatedCostTab()).toBe(notiHubObj.bomCost);
            cartListPage.clickOnCloseButtonOfViewDetailSlidder();
	    }
        // Delete cart Item service
        util.waitForAngular();
        cartListPage.clickActionIcon(1);
        cartListPage.clickCurrentCartDeleteFlow();
        cartListPage.clickDeleteOkButtonForCartItem();
        //delete cart
        cartListPage.clickMenuIcon(0);
        cartListPage.deleteCart(0);
        expect(cartListPage.getDeletedCartSuccessMessage()).toBe(messageStrings.cartSuccessfullyDeletedMessage);
        browser.ignoreSynchronization = false;
    });

    it("Add one service into cart, edit the cart service details, Check service details and BOM delete the cart", function () {
    var notiHubObj = JSON.parse(JSON.stringify(azshopBagTemplate.avServ));
    modifiedParamMap = { "Service Instance Name": serviceName1, "Cart Name": cartName, "Cart Service": "Click", "New Shopping Cart": "newCart", "New Resource Group": rgName1, "Availability Set Name": avName };
    catalogPage.open();
    catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
    catalogPage.clickProviderOrCategoryCheckbox(notiHubObj.Category);
    catalogPage.searchForBluePrint(notiHubObj.bluePrintName);
    catalogPage.clickConfigureButtonBasedOnName(notiHubObj.bluePrintName);
    orderFlowUtil.fillOrderDetails(notiHubObj, modifiedParamMap);
    placeOrderPage.addToShoppingCart();
    expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
    cartListPage.expandsTheCartItemsTab();
    util.waitForAngular();
    browser.waitForAngularEnabled(false);
    //Edit Cart service  Details
    cartListPage.clickActionIcon(1);
    cartListPage.clickCurrentCartEditFlow();
    var modifiedParamMapeEditCartItem = { "EditService": true};
    orderFlowUtil.fillOrderDetails(azshopBagTemplate.avServ, modifiedParamMapeEditCartItem);
    //check updated Parameter on Review Page
    expect(placeOrderPage.getTextBasedOnLabelName("Update Domains")).toContain(jsonUtil.getValueEditParameter(notiHubObj, "Update Domains"));
    cartListPage.clickOnEditSaveBtn();
    expect(cartListPage.isPresentSuccessfullyUpdatedCart()).toBe(true);

    // check Edited/updated Service details 
    cartListPage.expandsTheCartItemsTab();
    util.waitForAngular();
    cartListPage.clickActionIcon(1);
    cartListPage.clickCurrentCartServiceDetails();
    expect(cartListPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(notiHubObj, "New Resource Group Required"));
    expect(cartListPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName1);
    expect(cartListPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(notiHubObj, "Location"));
    expect(cartListPage.getTextBasedOnExactLabelName("Availability Set Name")).toEqual(avName);
    expect(cartListPage.getTextBasedOnExactLabelName("Availability Set Location")).toEqual(jsonUtil.getValue(notiHubObj, "Availability Set Location"));
    expect(cartListPage.getTextBasedOnExactLabelName("Use Managed Disk")).toEqual(jsonUtil.getValue(notiHubObj, "Use Managed Disk"));
    expect(cartListPage.getTextBasedOnExactLabelName("Fault Domains")).toEqual(jsonUtil.getValue(notiHubObj, "Fault Domains"));
    expect(cartListPage.getTextBasedOnExactLabelName("Update Domains")).toEqual(jsonUtil.getValueEditParameter(notiHubObj, "Update Domains"));
    expect(cartListPage.getTextBasedOnExactLabelName("Proximity Placement Group")).toEqual(jsonUtil.getValue(notiHubObj, "Proximity Placement Group"));
    cartListPage.clickOnCloseButtonOfViewDetailSlidder();
    util.waitForAngular();
    //check updated Bill of Material
    if (browser.params.defaultCurrency == "USD") {
        cartListPage.clickActionIcon(1);
        cartListPage.clickCurrentCartBOMDetails();
        expect(orders.getEstimatedCostFromEstimatedCostTab()).toBe(notiHubObj.bomCost);
        cartListPage.clickOnCloseButtonOfViewDetailSlidder();
    }
    //submit and Provision the order
    cartListPage.submitOrder(0);
    var orderObject ={};
    orderObject.servicename = serviceName1;
    orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
    orderObject.orderNumber = orderObject.orderNumber;
    //orderObject.totalPrice = cartListPage.getTextTotalPriceOrderSubmittedModal();
    expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
    cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
    if (isProvisioningRequired == "true") {
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 30);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == 'Completed') {
                orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject); //Deleting Service 2
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 35);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            }
        })
    }
    browser.ignoreSynchronization = false;
});

it("Add one service into cart, add add on to the cart , Check service details and BOM from  the cart", function () {
    var notiHubObj = JSON.parse(JSON.stringify(azshopBagTemplate.notiHub));
    var modifiedParamMapNh = { "Service Instance Name": serviceName1, "Cart Name": cartName, "Cart Service": "Click", "New Shopping Cart": "newCart", "New Resource Group": rgName1, "Notification Hub Name": nhName, "New Namespace Name": nsName, "Namespace Pricing Tier": "Free" };
    catalogPage.open();
    catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
    catalogPage.clickProviderOrCategoryCheckbox(notiHubObj.Category);
    catalogPage.searchForBluePrint(notiHubObj.bluePrintName);
    catalogPage.clickConfigureButtonBasedOnName(notiHubObj.bluePrintName);
    orderFlowUtil.fillOrderDetails(notiHubObj, modifiedParamMapNh);
    placeOrderPage.addToShoppingCart();
    expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
    cartListPage.expandsTheCartItemsTab();
    util.waitForAngular();
    browser.waitForAngularEnabled(false);
    // Add-on service
        util.waitForAngular();
        cartListPage.clickActionIcon(1);
        cartListPage.clickCurrentCartAddOnDetails();
        modifiedParamMap2 = { "UpdateMainParamObject": false,"skipRevierOrderValidation" : true}
        orderFlowUtil.fillOrderDetails(azshopBagTemplate.nhIMI, modifiedParamMap2);
    // Service details 
    cartListPage.expandsTheCartItemsTab();
    util.waitForAngular();
    expect(cartListPage.getIMITagInItemTableText()).toEqual(notiHubObj.IMITag)
    
    //Bill of Material
    if (browser.params.defaultCurrency == "USD") {
    cartListPage.clickActionIcon(1);
    cartListPage.clickCurrentCartBOMDetails();
    expect(orders.getEstimatedCostFromEstimatedCostTab()).toBe(notiHubObj.IMIBomCost);
    cartListPage.clickOnCloseButtonOfViewDetailSlidder();
    }
    //submit and Provision the order
    cartListPage.submitOrder(0);
    var orderObject ={}
    orderObject.servicename = serviceName1;
    orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
    orderObject.orderNumber = orderObject.orderNumber;
    //orderObject.totalPrice = cartListPage.getTextTotalPriceOrderSubmittedModal();
    expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
    cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
    if (isProvisioningRequired == "true") {
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 30);
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == 'Completed') {
                orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject); //Deleting Service 2
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 35);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            }
        })
    }
    browser.ignoreSynchronization = false;
});
it('Azure :C195765: Buyers ability to Transfer a  shopping cart', async function () {
    var orderObj = {};
    var avshopObj = JSON.parse(JSON.stringify(azshopBagTemplate.avServ));
    catalogPage.clickProviderOrCategoryCheckbox(avshopObj.Category);
    catalogPage.searchForBluePrint(avshopObj.bluePrintName);
    catalogPage.clickConfigureButtonBasedOnName(avshopObj.bluePrintName);
    orderObj.servicename = serviceName1;
    orderFlowUtil.fillOrderDetails(avshopObj, modifiedParamMap);
    placeOrderPage.addToShoppingCart();
    expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
    cartName = modifiedParamMap["Cart Name"];
        cartListPage.getCartDetails(cartName).then(async function(index){
			cartListPage.clickMenuIcon(index);
			//Transfer the cart.
			cartListPage.tranferCart(index);        
            cartListPage.searchForUserID(credentialJson.transferCartUser);
            cartListPage.confirmTransfer();
            expect(cartListPage.getTextSuccessMessageTransferCart()).toContain(messageStrings.cartSuccessfullyTransferredToMessage);
            //Validate if Cart is present or not
            catalogPage.open();
			cartListPage.clickCartIcon();
			cartListPage.clickOnViewAllCarts();			
			cartListPage.switchToFrame();
            expect(cartListPage.getCartDetails(cartName)).toEqual(0);
            //Validate cart in transfered user
            await cartListPage.loginFromOtherUser(credentialJson.transferCartUser, credentialJson.transferCartPwd);
            catalogPage.open();
            cartListPage.clickCartIcon();
            cartListPage.clickOnViewAllCarts();			
			cartListPage.switchToFrame();
			cartListPage.clickMenuIcon(index);
			cartListPage.deleteCart(index);
            expect(cartListPage.getDeletedCartSuccessMessage()).toBe(messageStrings.cartSuccessfullyDeletedMessage);
            
        });
        
});

});