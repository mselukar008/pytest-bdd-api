

/*
Spec_Name: e2eRetryEditSupportForAWS.spec.js
Description:This covers verification to perform retry edit on failed aws service order,verify  main order get canceled , new submitted order is completed and deleted.
Author: Sarika Bothe
*/

"use strict";

const { browser } = require('protractor');

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    vmInAwsTemplate = require('../../../../testData/OrderIntegration/ICAM/VirtualMachineInAWS.json');


describe('TA - E2E Retry Edit support on Virtual machine in AWS service....', function () {

    var catalogPage, placeOrderPage, orderHistoryPage, SubnetName, vpc, serviceName, virtualMachineName, awsSshKeyName, inventoryPage;
    var modifiedParamMap = {};
    var modifiedParamMap2 = {};
    var serviceNameProv = vmInAwsTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
    var messageStrings = {
        providerName: vmInAwsTemplate.providerName,
        category: vmInAwsTemplate.category,
        estimatedPrice: vmInAwsTemplate.estimatedPrice,
        providerAccount: vmInAwsTemplate.providerAccount,
        completedState: vmInAwsTemplate.completedState,
        approvalState: vmInAwsTemplate.approvalState,
        orderTypeDel: vmInAwsTemplate.orderTypeDel,
        urlOrders: vmInAwsTemplate.urlOrders,
        estimatedCost: vmInAwsTemplate.estimatedCost,
        cancelOrderSuccessMsg: vmInAwsTemplate.cancelOrderSuccessMsg,
        cancelledStatus: vmInAwsTemplate.cancelledStatus,
        provisiongstatus: vmInAwsTemplate.provisiongstatus,
        Cancelingstatus: vmInAwsTemplate.Cancelingstatus,
        orderSubmittedConfirmationMessage: vmInAwsTemplate.orderSubmittedConfirmationMessage,
        orderFailedStatus: vmInAwsTemplate.failedState,
        deletedStatus: vmInAwsTemplate.deletedStatus,
        resourcelogText: vmInAwsTemplate.resourcelogText,
        SuccessLogMsg: vmInAwsTemplate.SuccessLogMsg,
        sshValue: vmInAwsTemplate.sshValue,
        sshKeyName: vmInAwsTemplate.sshKeyName,
        SuccessLogMsg: vmInAwsTemplate.SuccessLogMsg

    };

    beforeAll(function () {
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        orderHistoryPage = new OrderHistoryPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        serviceName = vmInAwsTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
        SubnetName = vmInAwsTemplate.subnetnamePrefix + "-" + util.getRandomString(5);
        vpc = vmInAwsTemplate.vpcPrefix + "-" + util.getRandomString(5);
        virtualMachineName = vmInAwsTemplate.virtualMachineNamePrefix + "-" + util.getRandomString(5);
        awsSshKeyName = vmInAwsTemplate.awsSshKeyNamePrefix + "-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Public SSH Key Name": awsSshKeyName, "Virtual Machine name": virtualMachineName };
        modifiedParamMap2 = { "Service Instance Name": serviceNameProv, "Public SSH Key Name": awsSshKeyName, "Virtual Machine name": virtualMachineName }
    });


    it('TA - Virtual machine in AWS ---- Verify Summary details and Additional Details are listed in review Order page', function () {
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            //	expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPrice);
            expect(requiredReturnMap["Actual"]["Instance Plan"]).toEqual(requiredReturnMap["Expected"]["Instance Plan"]);
            expect(requiredReturnMap["Actual"]["AWS Region Name"]).toEqual(requiredReturnMap["Expected"]["AWS Region Name"]);
            expect(requiredReturnMap["Actual"]["Cloud Connection Name"]).toEqual(requiredReturnMap["Expected"]["Cloud Connection Name"]);
            expect(requiredReturnMap["Actual"]["VPC Name tag"]).toEqual(requiredReturnMap["Expected"]["VPC Name tag"]);
            expect(requiredReturnMap["Actual"]["Subnet Name"]).toEqual(requiredReturnMap["Expected"]["Subnet Name"]);
            expect(requiredReturnMap["Actual"]["Public SSH Key Name"]).toEqual(requiredReturnMap["Expected"]["Public SSH Key Name"]);
            expect(requiredReturnMap["Actual"]["Public SSH Key"]).toBeDefined();
        });
    });

    if (isProvisioningRequired == "true") {

        it('TA - Virtual machine in AWS --- Verify Retry flow Edit flow for Failed order on order hisotry page...', function () {
            var orderObject = {}
            var modifiedParamMap = {
                "Service Instance Name": serviceName,
                "Subnet Name": SubnetName, "VPC Name tag": vpc
            };
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            var orderNumberval = orderObject.orderNumber;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.orderFailedStatus);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.orderFailedStatus);

            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {

                if (status == messageStrings.orderFailedStatus) {
                    orderHistoryPage.open();
                    orderHistoryPage.searchOrderById(orderObject.orderNumber);
                    util.waitForAngular();
                    orderHistoryPage.clickOnOrderTableDetailsExpandArrow();
                    orderHistoryPage.clickOrdersTableActionIcon();
                    orderHistoryPage.clickOnOrderTableActionsRetryOption();
                    orderHistoryPage.clickOnOrderTableActionsRetryEditButton();
                    orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap2);
                    placeOrderPage.submitOrder();   
                    orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                    expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                    placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                    orderFlowUtil.approveOrder(orderObject);
                    orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
                    expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
                }
            })
            orderHistoryPage.open();
            orderHistoryPage.searchOrderById(orderNumberval);
            util.waitForAngular();
            orderHistoryPage.clickOnOrderTableDetailsExpandArrow();
            orderFlowUtil.waitForOrderStatusChangeInOrderHistory(orderObject, messageStrings.cancelledStatus)
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.cancelledStatus);
        });

        it('TA  : Virtual machine in AWS ---- Verify Delete services-----', function () {
            var orderObject = {};
            orderObject.servicename = serviceNameProv;
            orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
            expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState)
        });

    }
});

