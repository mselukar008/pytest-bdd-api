"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	slSecurityGrpTemplate = require('../../../../../../testData/OrderIntegration/Softlayer/SecurityGroupService.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');

describe('IBM Cloud E2E cases for External Approval False with Standard change', function () {
	var ordersPage, catalogPage, placeOrderPage, snowPage, sampleOrder1, inventoryPage, cartListPage;
	var modifiedParamMap = {};
	var serviceName = "SNOWauto" + util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var secGrpName = "SNOWsecGrp" + util.getRandomString(5);
	var secGrpNameEdit = "SNOWsecGrpEdit" + util.getRandomString(5);

	beforeAll(function () {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		cartListPage = new CartListPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		modifiedParamMap = { "Service Instance Name": serviceName, "Team": "Auto-TEAM1", "Environment": "QA", "Application": "", "Provider Account": "SL-Testing / SL-Testing", "Security Group Name": secGrpName };
	});

	afterAll(function () {
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
	});

	it('Disable SNOW external approver for Enterprise Marketplace', function () {
		expect(snowAPI.disableExternalApprovalSnow()).toBe(snowInstanceTemplate.snowAPIResult);
	});

	it('Set Change Request type to Standard in SNOW', function () {
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});

	if (isProvisioningRequired == "true") {
		it('IBM Cloud: Security Group ---- Verify Provision functionality with Ext App false and Standard change', function () {

			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
			catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = { "orderNumber": sampleOrder1 };

			//Validation on SNOW before approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, slSecurityGrpTemplate.ProvisioningInProgressText, 4);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);

			//Validations on SNOW Request page after approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			//expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);

			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function (sName) {
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName);

				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);

				//Order Completion in SNOW
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				//snowPage.closePostImplementTestTask();
				//snowPage.closeImplementTask();
				/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/

				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.completedOrderStatus);

				//Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();

				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
			});
		});

		it('IBM Cloud: Security Group ---- Verify Edit functionality with Ext App false and Standard change', function () {

			//Place Order for Edit in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			modifiedParamMap = { "Service Instance Name": "", "Team": "", "Environment": "", "Application": "", "Provider Account": "", "Security Group Name": secGrpNameEdit };
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.editService(orderObject);
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

			//Validation on SNOW before approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderType(orderObject)).toBe(slSecurityGrpTemplate.editSOIOrderStatus);
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, slSecurityGrpTemplate.ProvisioningInProgressText, 4);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);

			//Validations on SNOW Request page after approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestEdit);
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			//expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);

			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function (sName) {
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpNameEdit);

				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);

				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				if (isDummyAdapterDisabled == "true") {
					expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
					expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				}
				snowPage.clickUpdateButton();

				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				if (isDummyAdapterDisabled == "true") {
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				}
				snowPage.clickBackButton();

				//Validation on SNOW for Standard change
				snowPage.openRelatedChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
				snowPage.clickBackButton();

				//Order Completion in SNOW
				//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				//snowPage.closePostImplementTestTask();
				//snowPage.closeImplementTask();
				/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/

				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.completedOrderStatus);

				//Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();

				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();

			});

		});

		it('IBM Cloud: Security Group ---- Verify Delete functionality with Ext App false and Standard change', function () {

			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			sampleOrder1 = inventoryPage.getDeleteOrderNumber();

			//Validation on SNOW before approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(slSecurityGrpTemplate.deleteSOIOrderStatus);
			orderFlowUtil.approveDeletedOrder(orderObject);
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, slSecurityGrpTemplate.ProvisioningInProgressText, 4);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);

			//Validations on SNOW Request page after approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			//expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);

			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function (sName) {
				expect(sName).toContain(serviceName);

				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);

				//Order Completion in SNOW
				//snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				//snowPage.closePostImplementTestTask();
				//snowPage.closeImplementTask();
				/*snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/

				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(slSecurityGrpTemplate.completedOrderStatus);

				//Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalContICB);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
				snowPage.clickUpdateButton();

				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();

			});
		});
	}
});



