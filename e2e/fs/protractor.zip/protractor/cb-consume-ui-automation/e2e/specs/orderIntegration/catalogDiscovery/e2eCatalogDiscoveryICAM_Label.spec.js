/********************
  Author : Pushpraj
 ********************/

"use strict";
var CatalogDiscoveryPage   = require('../../../pageObjects/catalogDiscovery.pageObject.js'),
	CatalogPage   		   = require('../../../pageObjects/catalog.pageObject.js'),
	CatalogDetailsPage     = require('../../../pageObjects/catalogdetails.pageObject.js'),
	util                   = require('../../../../helpers/util.js'),
	appUrls 			   = require('../../../../testData/appUrls.json'),
	logGenerator 	       = require("../../../../helpers/logGenerator.js"),
	logger 			       = logGenerator.getApplicationLogger(),
	catalogDiscoveryApi    = require('../../../../helpers/APIs/catalogDiscoveryServicesAPI.js'),
	catalogDiscoveryData   = require('../../../../testData/OrderIntegration/catalogDiscovery/catalogDiscovery_testData.json'),
	icam_json_payload  = require('../../../../testData/OrderIntegration/catalogDiscovery/RegexVsphereSingleVirtualMachine321_PayLoad.json');



describe('Add labels in Draft WIP & Published service state for ICAM - ', function() {
	var catalogDiscoveryObj;	
	var catalogPageObj;
	var catalogDetailsObj;
	var catalogDiscvrydata;
	var icam_payLoad;

	beforeAll(function() {
		catalogPageObj = new CatalogPage();
		catalogDetailsObj = new CatalogDetailsPage();
		catalogDiscoveryObj = new CatalogDiscoveryPage();
		browser.driver.manage().window().maximize();
		catalogDiscvrydata = JSON.parse(JSON.stringify(catalogDiscoveryData));
		icam_payLoad = JSON.parse(JSON.stringify(icam_json_payload));
	});

	beforeEach(function() {
		catalogDiscoveryObj.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogAdminUrl);
	});

	it('retire the Published service and verify service in Retired section', function(){
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceNameICAM);	
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceNameICAM);
		catalogDiscoveryObj.clickOnRetireServiceOption();
		catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
		catalogDiscoveryObj.getAlertNotificationTitle();
		catalogDiscoveryObj.getAlertNotificationSubTitle();
		catalogDiscoveryObj.getAlertNotificationCaption();
		catalogDiscoveryObj.clickOnRetiredSectionLink();
		expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(catalogDiscvrydata.retireSuccessfull);
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceNameICAM);
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceNameICAM);
	});

	it('delete the retired service from Retired section and verify from API', async function(){
		catalogDiscoveryObj.clickOnRetiredSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceNameICAM);	
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceNameICAM);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceNameICAM);
		catalogDiscoveryObj.clickOnDeleteServiceOption();
		catalogDiscoveryObj.clickOnServiceConfirmationOKBtn();
		catalogDiscoveryObj.getAlertNotificationTitle();
		catalogDiscoveryObj.getAlertNotificationSubTitle();
		catalogDiscoveryObj.getAlertNotificationCaption();
		expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(catalogDiscvrydata.successMsg);
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceNameICAM);		
		expect(catalogDiscoveryObj.getNoDataAvailableTextPublishedSection()).toEqual(catalogDiscvrydata.noDataAvailabe);
		catalogDiscoveryObj.getheaderTitleText().then(async function(){
			let msg = await catalogDiscoveryApi.deletePublishedService(catalogDiscvrydata.serviceIdICAM);
			expect(msg).toEqual(catalogDiscvrydata.rows_affected);
		});
	});

	it('start catalog discovery for ICAM from catalog Admin page', function(){
		catalogDiscoveryObj.clickOnStartCatalogDiscoveryBtn();
		catalogDiscoveryObj.clickOnProviderToStartDiscovery(catalogDiscvrydata.serviceCategoryProviderICAM);
		catalogDiscoveryObj.selectVraAccountFromDrpDwn(catalogDiscvrydata.serviceAccountICAM);
		catalogDiscoveryObj.clickOnOKBtnFromDiscoveryPopup();
		expect(catalogDiscoveryObj.getICAMDiscoveryStartedPopupMsg()).toEqual(catalogDiscvrydata.discoveryStartedPopMsg);
		catalogDiscoveryObj.discoveryStartedPopupICAM();
		expect(catalogDiscoveryObj.getICAMDiscoveryStatus()).toMatch(catalogDiscvrydata.discoveryStatusInProgress);
	});

	it('verify ICAM Catalog discovery status', function(){
		catalogDiscoveryObj.waitToCompletDiscoveryStatus();
		logger.info("Current date "+catalogDiscoveryObj.currenDate());
		expect(catalogDiscoveryObj.getICAMDiscoveryStatus()).toMatch(catalogDiscoveryObj.currenDate());
		catalogDiscoveryObj.clickOnICAMHistoryLink();
		expect(catalogDiscoveryObj.getHistoryPageTitleText()).toMatch(catalogDiscvrydata.historyPageTitle);
		expect(catalogDiscoveryObj.getHeaderTextFromHistorySec()).toMatch(catalogDiscoveryObj.currenDate());
		expect(catalogDiscoveryObj.getStatusFromHistorySec()).toEqual(catalogDiscvrydata.discoveryStatusCompleted);
		expect(catalogDiscvrydata.serviceAccountICAM).toContain(catalogDiscoveryObj.getAccountNameFromHistroySec());
	});

	it('Add the label and pricing json in draft state of service', async function(){
		catalogDiscoveryObj.getheaderTitleText().then(async function(){
			await catalogDiscoveryApi.putServiceCallForDraftToWIP(icam_payLoad).then(function(obj){
				expect(200).toEqual(obj["statusCode"]);
				expect("OK").toEqual(obj["status"]);
				expect(catalogDiscvrydata.serviceIdICAM + "_WIP").toEqual(obj["id"]);
			});
		});
		catalogDiscoveryObj.clickOnDraftSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceNameICAM);
		expect(catalogDiscoveryObj.getServiceNameFromDraftSearchSection()).toEqual(catalogDiscvrydata.serviceNameICAM);
		expect(catalogDiscoveryObj.getEditedServiceStatus(catalogDiscvrydata.serviceNameICAM)).toEqual(catalogDiscvrydata.serviceStatusWIP);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceNameICAM);
		catalogDiscoveryObj.clickOnViewDetailsLink()
		expect(catalogDiscoveryObj.getLabelsNameFromViewDetails()).toContain(catalogDiscvrydata.labelsDraft);
		catalogPageObj.open();
		catalogPageObj.selectLabelsFilter(catalogDiscvrydata.labelsDraft);
		catalogPageObj.isDisplayedDetailsButtonBasedOnName(catalogDiscvrydata.serviceNameICAM);
		catalogPageObj.clickDetailsButtonBasedOnName(catalogDiscvrydata.serviceNameICAM);
		expect(catalogDetailsObj.getServiceName()).toEqual(catalogDiscvrydata.serviceNameICAM);
		expect(catalogDetailsObj.getLabelsName()).toEqual(catalogDiscvrydata.labelsDraft);
	});

	it('Add lable in WIP state of service', function(){
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceNameICAM);
		expect(catalogDiscoveryObj.getServiceNameFromDraftSearchSection()).toEqual(catalogDiscvrydata.serviceNameICAM);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceNameICAM);
		catalogDiscoveryObj.clickOnViewDetailsLink();
		catalogDiscoveryObj.clickOnEditButton();
		catalogDiscoveryObj.addLabelInEditServiceConf(catalogDiscvrydata.labelsWIP);
		catalogDiscoveryObj.clickOnSaveBtn();
		expect(catalogDiscoveryObj.getEditedServiceStatus(catalogDiscvrydata.serviceNameICAM)).toEqual(catalogDiscvrydata.serviceStatusWIP);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceNameICAM);
		catalogDiscoveryObj.clickOnViewDetailsLink()
		expect(catalogDiscoveryObj.getLabelsNameFromViewDetails()).toContain(catalogDiscvrydata.labelsWIP);
		catalogPageObj.open();
		catalogPageObj.selectLabelsFilter(catalogDiscvrydata.labelsWIP);
		catalogPageObj.isDisplayedDetailsButtonBasedOnName(catalogDiscvrydata.serviceNameICAM);
		catalogPageObj.clickDetailsButtonBasedOnName(catalogDiscvrydata.serviceNameICAM);
		expect(catalogDetailsObj.getServiceName()).toEqual(catalogDiscvrydata.serviceNameICAM);
		expect(catalogDetailsObj.getLabelsName()).toEqual(catalogDiscvrydata.labelsWIP);
	});

	it('Publish drafted service and validate the service in Published section', function(){
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceNameICAM);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceNameICAM);
		catalogDiscoveryObj.clickOnPublishService();
		catalogDiscoveryObj.getAlertNotificationTitle();
		catalogDiscoveryObj.getAlertNotificationSubTitle();
		catalogDiscoveryObj.getAlertNotificationCaption();
		expect(catalogDiscoveryObj.getAlertNotificationTitle()).toEqual(catalogDiscvrydata.publishSuccessfull);
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceNameICAM);		
		expect(catalogDiscoveryObj.getPublishedSerivceDate()).toMatch(catalogDiscoveryObj.currenDate());
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceNameICAM);
	});


	it('Add lable in published state of service', function(){
		catalogDiscoveryObj.clickOnPublishSectionLink();
		catalogDiscoveryObj.searchServiceOrProviderName(catalogDiscvrydata.serviceNameICAM);
		expect(catalogDiscoveryObj.getServiceNameFromSearchSection()).toEqual(catalogDiscvrydata.serviceNameICAM);
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceNameICAM);
		catalogDiscoveryObj.clickOnViewDetailsLink();
		catalogDiscoveryObj.clickOnEditButton();
		
		catalogDiscoveryObj.addLabelInEditServiceConf(catalogDiscvrydata.labelsPublished);
		catalogDiscoveryObj.clickOnSaveBtn();
		catalogDiscoveryObj.clickOnThreeDotMenuIcon(catalogDiscvrydata.serviceNameICAM);
		catalogDiscoveryObj.clickOnViewDetailsLink()
		expect(catalogDiscoveryObj.getLabelsNameFromViewDetails()).toContain(catalogDiscvrydata.labelsPublished);

		catalogPageObj.open();
		catalogPageObj.selectLabelsFilter(catalogDiscvrydata.labelsPublished);
		catalogPageObj.isDisplayedDetailsButtonBasedOnName(catalogDiscvrydata.serviceNameICAM);
		catalogPageObj.clickDetailsButtonBasedOnName(catalogDiscvrydata.serviceNameICAM);
		expect(catalogDetailsObj.getServiceName()).toEqual(catalogDiscvrydata.serviceNameICAM);
		expect(catalogDetailsObj.getLabelsName()).toContain(catalogDiscvrydata.labelsPublished);
	});

});
