"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	gcpPubSubTemplate = require('../../../../../../testData/OrderIntegration/Google/pubsub.json'),
	gcpComputeEngineTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/gcpComputeEngineSnowV3SpecstoSkipIMI.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');

describe('QS: Google E2E cases for Manual Technical, Auto Financial and External Legal approval with Standard change', function() {
	var ordersPage, catalogPage, placeOrderPage, policyPage, snowPage, gcpComputeEngineobj, sampleOrder1, inventoryPage, cartListPage;
	var modifiedParamMap = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var serviceName = "SNOWQSauto"+util.getRandomString(5);
	var policyName = "SNOWQSautoGooglePolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWQSautoGooglePolicyRule"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var topicName = "autom-" + util.getRandomString(5).toLowerCase();
    var suscrpName = "autom-" + util.getRandomString(5).toLowerCase();
	var orderObjectVm = {};

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["Google"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"","Technical":"Manual Approval","Legal":"External Approval"};
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"","Name": topicName};
		gcpComputeEngineobj = JSON.parse(JSON.stringify(gcpComputeEngineTemplate));
	});

	afterAll(function() {
		//Delete Approval Policy
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);
		  
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});

    it('Set Change Request type to Standard in SNOW', function () {
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Approval Policy for Google with Manual Technical, Auto Financial and External Legal approval and Standard change', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.selectExternalApprovalDropdownSNOW();
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});

    if(isDummyAdapterDisabled == "false"){
		it('GCP: Compute Engine - VM instance creation as part of pre-requisite data with Manual Technical, Auto Financial and External Legal approval with Standard change.', function () {
			serviceName = "SNOWQSGCPauto"+util.getRandomString(5);
			var instanceName = "snow-vm-" + util.getRandomString(3);
			//var modifiedHostName = "GSLSLVM" + util.getRandomString(5);
			modifiedParamMap = {
				"Service Instance Name": serviceName,
				"Instance Name": instanceName.toLowerCase(),
				"Team": "Auto-TEAM1", 
				"Environment": "QA",
				"Application": "",
				"Provider Account": "gcpQA-TEAM1 / gcpQA-TEAM1"
			};
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
			catalogPage.open();
			catalogPage.clickProviderCheckBoxBasedOnName(gcpComputeEngineTemplate.provider);
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(gcpComputeEngineTemplate.Category);
			catalogPage.searchForBluePrint(gcpComputeEngineTemplate.bluePrintName);
			catalogPage.clickConfigureButtonBasedOnName(gcpComputeEngineTemplate.bluePrintName);
			orderObjectVm.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(gcpComputeEngineTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObjectVm.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(gcpComputeEngineTemplate.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            //Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObjectVm);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
			ordersPage.clickCancelButtonOrderApprovalModal();
			//orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			//expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);

            //Validation in Marketplace after approval in MCMP
			expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe("Approval In Progress");

			//Validations on SNOW Request page  after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(gcpComputeEngineTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

            //Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();

            //Validation in Marketplace after approval in SNOW
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			//orderFlowUtil.waitForOrderStatusChange(orderObject,gcpComputeEngineTemplate.provInProgressState);
			expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(gcpComputeEngineTemplate.provInProgressState);

            //Validations on SNOW Request page after approval in SNOW
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(gcpComputeEngineTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);
			expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpComputeEngineTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescComputeEngine);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);

			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDComputeEngine);

			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);

			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("true");

			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function (sName) {
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Region")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Region"));	
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Zone")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Zone"));	
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Instance Name")).toEqual(instanceName);		
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Machine Type Edit Option")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Machine Type Edit Option"));	
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Machine Family")).toEqual("General Purpose (Machine types for common workloads, optimized for cost and flexibility)");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Machine Type Edit Option")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Machine Type Edit Option"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Series")).toEqual("n1");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Machine Type")).toEqual("f1-micro");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Source Image Type")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Source Image Type"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Images")).toEqual("projects/centos-cloud/global/images/centos-7-v20210609");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Disk Name Option")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Disk Name Option"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Disk Type")).toEqual("pd-balanced");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Size (GB)")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Boot Disk Size in GB"));		
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Tags")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Network Tags"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Description")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Description"));		
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAGCPSrvcCompEngItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAGCPSrvcCompEngItem2Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAGCPSrvcCompEngItem3Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAGCPSrvcCompEngItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalCompEng);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAGCPSrvcCompEngItem2Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAGCPSrvcCompEngItem3Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);

				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();

				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();

				expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInCatalogTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
				expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
				expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();

                //Standard change
				snowPage.openRelatedChangeRequest();
				
				//Change Request Short Desc and Desc
			expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescNewOrder);

                //Order Completion in SNOW
				snowPage.checkIfProvisioningTaskClosed();

                //Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(gcpComputeEngineTemplate.completedState);

				//Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				snowPage.getTextCMDBShellCIName();
				expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
				snowPage.getTextCMDBShellCIAssignmentGroup();
				expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
				expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
				expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.gcpProviderAccountID);
				expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.gcpProviderAccount);
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();	

				//Change Task Page Validations 
				snowPage.openRelatedChangeRequest();
				snowPage.clickProvTaskLink();
				expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
				expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
				expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
				expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
				expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
				snowPage.clickClosureInfoInChangeTask();
				expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
				snowPage.clickBackButton();

				//Validation on Catalog Task page after completion
				snowPage.clickBackButton();
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				});
			});

            it('GCP: Compute Engine - Verify VM instance Turn OFF functionality with Manual Technical, Auto Financial and External Legal approval with Standard change.', function () {
				var status = gcpComputeEngineTemplate.powerStateOff;		
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				inventoryPage.open();
				inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
				inventoryPage.clickExpandFirstRow().then(function () {
					browser.executeScript('window.scrollTo(0,0);');
					inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
						inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
							inventoryPage.clickOkForInstanceTurnOFFPermission();
							util.waitForAngular();
						});
					});
				}).then(function () {
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(gcpComputeEngineTemplate.orderSubmittedConfirmationMessage);
					orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					orderObjectVm.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
					inventoryPage.clickOkForCustomOpnOrderButton();	

					//Validation in Marketplace before approval
					expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe("Approval In Progress");

                    //Approve Order in Marketplace
                    orderFlowUtil.approveOrderButtonSNOW(orderObjectVm);
                    ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
                    ordersPage.clickApproveButtonOrderApprovalModal();
                    ordersPage.clickCancelButtonOrderApprovalModal();
                    //orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
                    //expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);

                    //Validation in Marketplace after approval in MCMP
                    expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe("Approval In Progress");

                    //Validations on SNOW Request page  after approval in Marketplace
                    snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
                    snowPage.waitUntilApprovalIsRequestedQS();
                    expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
                    expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                    expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
                    expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
                    expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
					
					expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
					var reqNumber = snowPage.getTextRequestNumberInRequestPage();
					expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

                    expect(snowPage.getTextShortDescription()).toBe(gcpComputeEngineTemplate.bluePrintNameTurnOff);
                    expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
                    expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
					expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

                    //Approve Order in SNOW
                    snowPage.approveTheServiceNowRequestFromSnowPortal();

                    //Validation in Marketplace after approval in SNOW
                    browser.get(consumeLaunchpadUrl);
                    cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
                    //orderFlowUtil.waitForOrderStatusChange(orderObject,gcpComputeEngineTemplate.provInProgressState);
                    expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(gcpComputeEngineTemplate.provInProgressState);

                    //Validations on SNOW Request page after approval
					snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
					snowPage.waitUntilApprovalIsApprovedQS();
					expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
					expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

					expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
					var reqNumber = snowPage.getTextRequestNumberInRequestPage();
					expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

					expect(snowPage.getTextShortDescription()).toBe(gcpComputeEngineTemplate.bluePrintNameTurnOff);
					expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
					expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
					expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

					//Validations on SNOW Requested Item page
					snowPage.clickRequestedItemLink();

					expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
					var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
					expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
					expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
					expect(snowPage.getTextChangeReqNumber()).not.toBe("");
					var changeRequestNumber = snowPage.getTextChangeReqNumber();
					expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
					var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
					expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpComputeEngineTemplate.bluePrintNameTurnOff);					
					//expect((snowPage.getTextReqItemVariableSerOfferDesc()).toLowerCase()).toBe((snowInstanceTemplate.snowReqItemVariablesSerOfferDescOff).toLowerCase());
					snowPage.getTextReqItemVariableSerOfferDesc().then(function(text){
						expect(text.toLowerCase()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOff.toLowerCase());	
					});
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOff);
					expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
					
					expect(snowPage.getTextReqItemVariableConCategory()).toBe("");
					expect(snowPage.getTextMCMPVersionRITMVariable()).toBe('');
					expect(snowPage.getTextLabelsRITMVariable()).toBe("");
					expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
					
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function (sName) {
						expect(sName).toContain(serviceName);
						//expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("stop");
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
						
						// Validate BOM values from Broker config values
						expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

						expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);

						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
						snowPage.clickUpdateButton();

						//Validation on Catalog Task page
						snowPage.clickCatalogTaskLink();

						expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
						expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
						expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
						expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
						snowPage.clickUpdateButton();

                        //Standard change
						snowPage.openRelatedChangeRequest();
						
						//Change Request Short Desc and Desc
						expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
						expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescTurnOffOrder);

                        //Order Completion in SNOW
                        snowPage.checkIfProvisioningTaskClosed();

                        //Validation in Marketplace
						browser.get(consumeLaunchpadUrl);
						cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
						expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(gcpComputeEngineTemplate.completedState);
						inventoryPage.open();
						inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
						var adapterName = "Real";
						var status = gcpComputeEngineTemplate.powerStateOff;
						inventoryPage.clickExpandFirstRow().then(function () {
							inventoryPage.getComponentTags().then(function (text) {
								// if (val == text) {
								// 	status = 'Off';
								// 	adapterName = "dummy";
								// }
								expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObjectVm)).toBe(status);
							});
						});

						//Validations on SNOW Request page after Completion
						snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
						expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
						expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
						expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

						//Validations on SNOW RITM page after Completion
						snowPage.clickRequestedItemLink();
						expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						
						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						snowPage.getTextCMDBShellCIName();
						expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
						expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
						snowPage.getTextCMDBShellCIAssignmentGroup();
						expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
						expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
						expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.gcpProviderAccountID);
						expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.gcpProviderAccount);
						expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
						expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
						expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
						snowPage.clickUpdateButton();	

						//Change Task Page Validations 
						snowPage.openRelatedChangeRequest();
						snowPage.clickProvTaskLink();
						expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
						expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
						expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
						expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
						expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
						expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
						snowPage.clickClosureInfoInChangeTask();
						expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
						snowPage.clickBackButton();

						//Validation on Catalog Task page after completion
						snowPage.clickBackButton();
						snowPage.clickCatalogTaskLink();
						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						snowPage.clickUpdateButton();
					});
				});
			});

            it('GCP: Compute Engine - Verify VM insance Turn ON functionality with Manual Technical, Auto Financial and External Legal approval with Standard change.', function () {			
				var status = gcpComputeEngineTemplate.powerStateOn;		
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				inventoryPage.open();
				browser.waitForAngular();
				inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
				inventoryPage.clickExpandFirstRow().then(function () {
					browser.executeScript('window.scrollTo(0,0);');
					inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
						inventoryPage.clickTurnONButtonOfInstance().then(function () {
							inventoryPage.clickOkForInstanceTurnONPermission();
							util.waitForAngular();
						});
					});
				}).then(function () {
					console.log(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal());
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(gcpComputeEngineTemplate.orderSubmittedConfirmationMessage);
					orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					orderObjectVm.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
					inventoryPage.clickOkForCustomOpnOrderButton();

                    //Approve Order in Marketplace
                    orderFlowUtil.approveOrderButtonSNOW(orderObjectVm);
                    ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
                    ordersPage.clickApproveButtonOrderApprovalModal();
                    ordersPage.clickCancelButtonOrderApprovalModal();
                    //orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
                    //expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);

                    //Validation in Marketplace after approval in MCMP
                    expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe("Approval In Progress");

                    //Validations on SNOW Request page  after approval in Marketplace
                    snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
                    snowPage.waitUntilApprovalIsRequestedQS();
                    expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
                    expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                    expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
                    expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
                    expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
					
					expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
					var reqNumber = snowPage.getTextRequestNumberInRequestPage();
					expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

                    expect(snowPage.getTextShortDescription()).toBe(gcpComputeEngineTemplate.bluePrintNameTurnOn);
                    expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
					expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
					expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

                    //Approve Order in SNOW
                    snowPage.approveTheServiceNowRequestFromSnowPortal();

                    //Validation in Marketplace after approval in SNOW
                    browser.get(consumeLaunchpadUrl);
                    cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
                    //orderFlowUtil.waitForOrderStatusChange(orderObject,gcpComputeEngineTemplate.provInProgressState);
                    expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(gcpComputeEngineTemplate.provInProgressState);

                    //Validations on SNOW Request page after Approval
					snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
					snowPage.waitUntilApprovalIsApprovedQS();
					expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
					expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

					expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
					var reqNumber = snowPage.getTextRequestNumberInRequestPage();
					expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

					expect(snowPage.getTextShortDescription()).toBe(gcpComputeEngineTemplate.bluePrintNameTurnOn);
					expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
					expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
					expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

					//Validations on SNOW Requested Item page
					snowPage.clickRequestedItemLink();

					expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
					var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
					expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
					expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
					expect(snowPage.getTextChangeReqNumber()).not.toBe("");
					var changeRequestNumber = snowPage.getTextChangeReqNumber();
					expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
					var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
					expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpComputeEngineTemplate.bluePrintNameTurnOn);
					//expect((snowPage.getTextReqItemVariableSerOfferDesc()).toLowerCase()).toBe((snowInstanceTemplate.snowReqItemVariablesSerOfferDescOn).toLowerCase());
					snowPage.getTextReqItemVariableSerOfferDesc().then(function(text){
						expect(text.toLowerCase()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOn.toLowerCase());	
					});
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOn);
					expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
					
					expect(snowPage.getTextReqItemVariableConCategory()).toBe("");
					expect(snowPage.getTextMCMPVersionRITMVariable()).toBe('');
					expect(snowPage.getTextLabelsRITMVariable()).toBe("");
					expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");

					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function (sName) {
						expect(sName).toContain(serviceName);
						//expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("start");
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
						
						// Validate BOM values from Broker config values
						expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

						expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);


						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
						snowPage.clickUpdateButton();
				
						//Validation on Catalog Task page
						snowPage.clickCatalogTaskLink();

						expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
						expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
						expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
						expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
						snowPage.clickBackButton();

                        //Standard change
						snowPage.openRelatedChangeRequest();
						
						//Change Request Short Desc and Desc
						expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
						expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescTurnOnOrder);

                        //Order Completion in SNOW
                        snowPage.checkIfProvisioningTaskClosed();

                        //Validation in Marketplace
						browser.get(consumeLaunchpadUrl);
						cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
						expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(gcpComputeEngineTemplate.completedState);
						inventoryPage.open();
						inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
						inventoryPage.clickExpandFirstRow().then(function () {
						expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObjectVm)).toBe('On');
						});
	
						//Validations on SNOW Request page after Completion
						snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
						expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
						expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
						expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
						//Validations on SNOW RITM page after Completion
						snowPage.clickRequestedItemLink();
						expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						snowPage.getTextCMDBShellCIName();
						expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
						expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
						snowPage.getTextCMDBShellCIAssignmentGroup();
						expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
						expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
						expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.gcpProviderAccountID);
						expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.gcpProviderAccount);
						expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
						expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
						expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
						snowPage.clickUpdateButton();	

						//Change Task Page Validations 
						snowPage.openRelatedChangeRequest();
						snowPage.clickProvTaskLink();
						expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
						expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
						expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
						expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
						expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
						expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
						snowPage.clickClosureInfoInChangeTask();
						expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
						snowPage.clickBackButton();

						//Validation on Catalog Task page after completion
						snowPage.clickBackButton();
						snowPage.clickCatalogTaskLink();
						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						snowPage.clickUpdateButton();
					});

				});
			});

            it('GCP: Compute Engine - Verify VM instance Reboot functionality with Manual Technical, Auto Financial and External Legal approval with Standard change.', function () {
				var status = gcpComputeEngineTemplate.powerStateOn;						
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				inventoryPage.open();
				browser.waitForAngular();
				inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
				inventoryPage.clickExpandFirstRow().then(function () {
					inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
						inventoryPage.clickRebootButtonOfInstance().then(function () {
							inventoryPage.clickOkForInstanceRebootPermission();
							util.waitForAngular();
						});
					});
				}).then(function () {
					console.log(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal());
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(gcpComputeEngineTemplate.orderSubmittedConfirmationMessage);
					orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					orderObjectVm.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
					inventoryPage.clickOkForCustomOpnOrderButton();
					//Validation in Marketplace after auto approval
					expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObjectVm)).toBe(gcpComputeEngineTemplate.orderTypeAction);
					//expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(gcpComputeEngineTemplate.provInProgressState);
					expect(placeOrderPage.getServiceNameOfferingText()).toBe(gcpComputeEngineTemplate.bluePrintNameReboot);

                    //Approve Order in Marketplace
                    orderFlowUtil.approveOrderButtonSNOW(orderObjectVm);
                    ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
                    ordersPage.clickApproveButtonOrderApprovalModal();
                    ordersPage.clickCancelButtonOrderApprovalModal();
                    //orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
                    //expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);

                    //Validation in Marketplace after approval in MCMP
                    expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe("Approval In Progress");

                    //Validations on SNOW Request page  after approval in Marketplace
                    snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
                    snowPage.waitUntilApprovalIsRequestedQS();
                    expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
                    expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                    expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
                    expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
                    expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
					
					expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
					var reqNumber = snowPage.getTextRequestNumberInRequestPage();
					expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

                    expect(snowPage.getTextShortDescription()).toBe(gcpComputeEngineTemplate.bluePrintNameReboot);
                    expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
					expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
					expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

                    //Approve Order in SNOW
                    snowPage.approveTheServiceNowRequestFromSnowPortal();

                    //Validation in Marketplace after approval in SNOW
                    browser.get(consumeLaunchpadUrl);
                    cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
                    //orderFlowUtil.waitForOrderStatusChange(orderObject,gcpComputeEngineTemplate.provInProgressState);
                    expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(gcpComputeEngineTemplate.provInProgressState);

                    //Validations on SNOW Request page after approval
					snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
					snowPage.waitUntilApprovalIsApprovedQS();
					expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

					expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
					var reqNumber = snowPage.getTextRequestNumberInRequestPage();
					expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

					expect(snowPage.getTextShortDescription()).toBe(gcpComputeEngineTemplate.bluePrintNameReboot);
					expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
					expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
					expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

					//Validations on SNOW Requested Item page
					snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
					snowPage.clickRequestedItemLink();

					expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
					var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
					expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
					expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
					expect(snowPage.getTextChangeReqNumber()).not.toBe("");
					var changeRequestNumber = snowPage.getTextChangeReqNumber();
					expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
					var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
					expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpComputeEngineTemplate.rebootSvcOfferingName);
					//expect((snowPage.getTextReqItemVariableSerOfferDesc()).toLowerCase()).toBe((snowInstanceTemplate.snowReqItemVariablesSerOfferDescReboot).toLowerCase());
					snowPage.getTextReqItemVariableSerOfferDesc().then(function(text){
						expect(text.toLowerCase()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescRebootGCP.toLowerCase());	
					});
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingReboot);
					expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
					
					expect(snowPage.getTextReqItemVariableConCategory()).toBe("");
					expect(snowPage.getTextMCMPVersionRITMVariable()).toBe('');
					expect(snowPage.getTextLabelsRITMVariable()).toBe("");
					expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
					
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function (sName) {
						expect(sName).toContain(serviceName);					
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("reboot");
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
						
						// Validate BOM values from Broker config values
						expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

						expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);

						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
						snowPage.clickUpdateButton();

						//Validation on Catalog Task page
						snowPage.clickCatalogTaskLink();

						expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
						expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
						expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
						expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
						snowPage.clickUpdateButton();

                        //Standard change
						snowPage.openRelatedChangeRequest();
						
						//Change Request Short Desc and Desc
						expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
						expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescRebootOrder);

                        //Order Completion in SNOW
                        snowPage.checkIfProvisioningTaskClosed();
                        

						//Validation in Marketplace
						browser.get(consumeLaunchpadUrl);
						cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
						expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(gcpComputeEngineTemplate.completedState);
						inventoryPage.open();
						inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
						inventoryPage.clickExpandFirstRow().then(function () {
							expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObjectVm)).toBe('On');
						});

						//Validations on SNOW Request page after Completion
						snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
						expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
						expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
						expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

						//Validations on SNOW RITM page after Completion
						snowPage.clickRequestedItemLink();
						expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						snowPage.getTextCMDBShellCIName();
						expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
						expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
						snowPage.getTextCMDBShellCIAssignmentGroup();
						expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
						expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
						expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.gcpProviderAccountID);
						expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.gcpProviderAccount);
						expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
						expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
						expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
						snowPage.clickUpdateButton();	

						//Change Task Page Validations 
						snowPage.openRelatedChangeRequest();
						snowPage.clickProvTaskLink();
						expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
						expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
						expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
						expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
						expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
						expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
						snowPage.clickClosureInfoInChangeTask();
						expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
						snowPage.clickBackButton();

						//Validation on Catalog Task page after completion
						snowPage.clickBackButton();
						snowPage.clickCatalogTaskLink();
						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						snowPage.clickUpdateButton();
					});
				});	
				
			});

            it('GCP: Compute Engine - Verify Delete functionality with Manual Technical, Auto Financial and External Legal approval and Standard change', function () {
			
				//Place Order for Delete in Marketplace
				var orderObject = {};
				orderObject.servicename = orderObjectVm.servicename;
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
				sampleOrder1 = inventoryPage.getDeleteOrderNumber();

                //Approve Order in Marketplace
                    orderFlowUtil.approveDeleteOrderButtonSNOW(orderObject);
                    ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
                    ordersPage.clickApproveButtonOrderApprovalModal();
                    ordersPage.clickCancelButtonOrderApprovalModal();
                    //orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
                    //expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);

                    //Validation in Marketplace after approval in MCMP
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe("Approval In Progress");

                    //Validations on SNOW Request page  after approval in Marketplace
                    snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
                    snowPage.waitUntilApprovalIsRequestedQS();
                    expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
                    expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                    expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
                    expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
                    expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
					
					expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
					var reqNumber = snowPage.getTextRequestNumberInRequestPage();
					expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

                    expect(snowPage.getTextShortDescription()).toBe(gcpComputeEngineTemplate.bluePrintName);
                    expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
					expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
					expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

                    //Approve Order in SNOW
                    snowPage.approveTheServiceNowRequestFromSnowPortal();

                    //Validation in Marketplace after approval in SNOW
                    browser.get(consumeLaunchpadUrl);
                    cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
                    //orderFlowUtil.waitForOrderStatusChange(orderObject,gcpComputeEngineTemplate.provInProgressState);
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(gcpComputeEngineTemplate.provInProgressState);

                    //Validations on SNOW Request page after auto approval
                    snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
                    snowPage.waitUntilApprovalIsApprovedQS();
                    expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
                    expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                    expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                    expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                    expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
					
					expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
					var reqNumber = snowPage.getTextRequestNumberInRequestPage();
					expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

                    expect(snowPage.getTextShortDescription()).toBe(gcpComputeEngineTemplate.bluePrintName);
                    expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
                    expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
                    expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
                                
                    //Validations on SNOW Requested Item page
					snowPage.clickRequestedItemLink();
					
					expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
					var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
					expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
					expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
					expect(snowPage.getTextChangeReqNumber()).not.toBe("");
					var changeRequestNumber = snowPage.getTextChangeReqNumber();
					expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
					var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

                    expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
                    expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
                    expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
                    expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
                    expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpComputeEngineTemplate.bluePrintName);
                    expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescComputeEngine);
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					
					expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDComputeEngine);

                    expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
                    expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
				   
					expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
					expect(snowPage.getTextLabelsRITMVariable()).toBe("");
					expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
					
					var serName = snowPage.getTextReqItemVariableServiceName();
                    serName.then(function(sName){
					expect(sName).toContain(serviceName);
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Region")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Region"));	
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Zone")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Zone"));	
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Instance Name")).toEqual(instanceName);		
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Machine Type Edit Option")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Machine Type Edit Option"));	
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Machine Family")).toEqual("General Purpose (Machine types for common workloads, optimized for cost and flexibility)");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Machine Type Edit Option")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Machine Type Edit Option"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Series")).toEqual("n1");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Machine Type")).toEqual("f1-micro");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Source Image Type")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Source Image Type"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Images")).toEqual("projects/centos-cloud/global/images/centos-7-v20210609");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Disk Name Option")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Disk Name Option"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Disk Type")).toEqual("pd-balanced");
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Size (GB)")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Boot Disk Size in GB"));		
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Tags")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Network Tags"));
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Description")).toEqual(jsonUtil.getValue(gcpComputeEngineobj, "Description"));
					
					// Validate BOM values from Broker config values
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
                    
                        //Validations on SNOW Configuration Item- Service Instance CIs page
                        snowPage.openConfItemServiceInstanceCIs();
                        expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
                        expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
                        expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
                        snowPage.clickUpdateButton();
                        
                        //Validation on Catalog Task page
						snowPage.clickCatalogTaskLink();
						
						expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
						expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
						expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
						expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

                        expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
                        snowPage.clickBackButton();

                        //Standard change
						snowPage.openRelatedChangeRequest();
						
						//Change Request Short Desc and Desc
						expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
						expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescDeleteOrder);

                        //Order Completion in SNOW
                        snowPage.checkIfProvisioningTaskClosed();

                        //Validation in Marketplace
                        browser.get(consumeLaunchpadUrl);
                        cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
                        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(gcpComputeEngineTemplate.completedState);
                        
                        //Validations on SNOW Request page after Completion
                        snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
                        expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
                        expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
                        expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                        expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
                        expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
                        expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
                        
                        //Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
                        snowPage.clickRequestedItemLink();
                        expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					   
						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						snowPage.getTextCMDBShellCIName();
						expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
						expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
						snowPage.getTextCMDBShellCIAssignmentGroup();
						expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
						expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
						expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.gcpProviderAccountID);
						expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.gcpProviderAccount);
						expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
						expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
						expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
						snowPage.clickUpdateButton();	

						//Change Task Page Validations 
						snowPage.openRelatedChangeRequest();
						snowPage.clickProvTaskLink();
						expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
						expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
						expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
						expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
						expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
						expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
						snowPage.clickClosureInfoInChangeTask();
						expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
						snowPage.clickBackButton();
                        
						//Validation on Catalog Task page after completion
						snowPage.clickBackButton();
                        snowPage.clickCatalogTaskLink();
                        expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
                        snowPage.clickUpdateButton();
                    });		
                });

            }

        
});
