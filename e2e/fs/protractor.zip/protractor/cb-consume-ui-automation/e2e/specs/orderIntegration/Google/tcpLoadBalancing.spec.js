"use strict";

var Orders = require('../../../pageObjects/orders.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    testEnvironment = browser.params.url.includes("cb-qa-2") ? "QA 2" : browser.params.url.includes("customer1") ? "Customer 1" : "QA 4",
    logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    tcpLoadBalancingTemplate = require('../../../../testData/OrderIntegration/Google/gcpTcpLoadBalancing.json');

describe('GCP - TCP Cloud Load Balancing', function () {
    var ordersPage, homePage, catalogPage, placeOrderPage, serviceName;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: 'Google',
        category: 'Network',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
    };

    beforeAll(function () {
        ordersPage = new Orders();
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
        serviceName = "auto-tcp-load-balancing-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName };
    });

    it('TC-C183213 : Google TCP Load Balancing : Verify fields on Main Parameters page are working fine while provisioning a Google Load Balancing', function () {
        catalogPage.clickProviderOrCategoryCheckbox('Network');
        catalogPage.clickConfigureButtonBasedOnName(tcpLoadBalancingTemplate.bluePrintName);
        expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
        placeOrderPage.setServiceNameText(serviceName);
        placeOrderPage.selectProviderAccount(tcpLoadBalancingTemplate.providerAccount);
        expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
    });

    it('TC-C183214 : Google TCP Load Balancing : Verify Service Details are listed in Review Order page', function () {
        var loadBalObj = JSON.parse(JSON.stringify(tcpLoadBalancingTemplate));
        catalogPage.clickProviderOrCategoryCheckbox('Network');
        catalogPage.clickConfigureButtonBasedOnName(tcpLoadBalancingTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetails(tcpLoadBalancingTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(requiredReturnMap["Actual"]["Region"]).toEqual(requiredReturnMap["Expected"]["Region"]);
            expect(requiredReturnMap["Actual"]["Type"]).toEqual(requiredReturnMap["Expected"]["Type"]);
            expect(requiredReturnMap["Actual"]["Load Balancing Traffic"]).toEqual(requiredReturnMap["Expected"]["Load Balancing Traffic"]);
            expect(requiredReturnMap["Actual"]["Health Check"]).toEqual(requiredReturnMap["Expected"]["Health Check"]);
            expect(requiredReturnMap["Actual"]["Protocol"]).toEqual(requiredReturnMap["Expected"]["Protocol"]);
            expect(requiredReturnMap["Actual"]["IP"]).toEqual(requiredReturnMap["Expected"]["IP"]);
            expect(requiredReturnMap["Actual"]["Port"]).toEqual(requiredReturnMap["Expected"]["Port"]);
            if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(tcpLoadBalancingTemplate.TotalCost);
                //BOM Validation as per components of service.
                expect(placeOrderPage.validateBOMOnReviewOrderPage(tcpLoadBalancingTemplate.Pricing)).toBe(true);
            }


        });
    });

    it('TC-C183215 : Google TCP Load Balancing : Verify Order Details once order is submitted from catalog page', function () {

        var orderObject = {};
        var orderAmount;
        global.serviceName = serviceName;
        var loadBalObj = JSON.parse(JSON.stringify(tcpLoadBalancingTemplate));
        catalogPage.clickProviderOrCategoryCheckbox('Network');
        catalogPage.clickConfigureButtonBasedOnName(tcpLoadBalancingTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetails(tcpLoadBalancingTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        expect(util.getCurrentURL()).toMatch('orders');
        ordersPage.searchOrderById(orderObject.orderNumber);
        expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
        ordersPage.getTextFirstAmountOrdersTable().then(function (text) {
            orderAmount = text;
        });
        ordersPage.clickFirstViewDetailsOrdersTable();
        expect(ordersPage.getTextBasedOnLabelName("Service Instance Prefix")).toEqual(serviceName);
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
        expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
        expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
        expect(ordersPage.getTextBasedOnLabelName("Region")).toContain(jsonUtil.getValue(loadBalObj, "Region"));
        expect(ordersPage.getTextBasedOnLabelName("Load Balancing Traffic")).toEqual(jsonUtil.getValue(loadBalObj, "Load Balancing Traffic"));
        expect(ordersPage.getTextBasedOnLabelName("Backends")).toEqual(jsonUtil.getValue(loadBalObj, "Backends"));
        expect(ordersPage.getTextBasedOnLabelName("Health Check")).toEqual(jsonUtil.getValue(loadBalObj, "Health Check"));
        expect(ordersPage.getTextBasedOnLabelName("Multiple regions or single region")).toEqual(jsonUtil.getValue(loadBalObj, "Multiple regions or single region"));
        expect(ordersPage.getTextBasedOnLabelName("Session Affinity")).toEqual(jsonUtil.getValue(loadBalObj, "Session Affinity"));
        expect(ordersPage.getTextBasedOnLabelName("Backup Pool")).toEqual(jsonUtil.getValue(loadBalObj, "Backup Pool"));

        orderFlowUtil.verifyOrderServiceDetails(loadBalObj).then(function (status) {
            expect(status).toEqual(true);
        });
        if (browser.params.defaultCurrency == "USD") {
            ordersPage.clickBillOfMaterialsTabOrderDetails().then(function () {
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(tcpLoadBalancingTemplate.TotalCost);
                ordersPage.clickServiceDetailSliderCloseButton();
            });
        }
    });

    if (isProvisioningRequired == "true") {
        it('TC-C183216 : Google TCP Load Balancing : E2E: Verify Google Load Balancing Order Provisioning is working fine from consume Application', function () {
            var orderObject = {};
            var loadBalObj = JSON.parse(JSON.stringify(tcpLoadBalancingTemplate));
            catalogPage.clickProviderOrCategoryCheckbox('Network');
            catalogPage.clickConfigureButtonBasedOnName(tcpLoadBalancingTemplate.bluePrintName);
            orderObject.servicename = serviceName;
            global.serviceName = serviceName;
            orderFlowUtil.fillOrderDetails(tcpLoadBalancingTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(tcpLoadBalancingTemplate.bluePrintName, "New");
            //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == 'Completed') {
                    //orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                    orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, tcpLoadBalancingTemplate.bluePrintName);
                    expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                    orderFlowUtil.approveDeletedOrder(orderObject);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
                }
            })
        });
    }
});
