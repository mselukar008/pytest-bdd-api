/*
 * @Author: Akash Deep Das
 * @Date: 2019-06-04 12:47:02 
 */


"use strict";


var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    Orders = require('../../../pageObjects/orders.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    vmInAwsTemplate = require('../../../../testData/OrderIntegration/ICAM/OffPremiseVirtualMachineInAWS.json');


describe('E2E Workflow for ICAM-OffPremises Virtual Machines In AWS', function () {
    var catalogPage, placeOrderPage, ordersPage, serviceName, virtualMachineName, awsSshKeyName;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName                     : vmInAwsTemplate.providerName,
        category                         : vmInAwsTemplate.category,
        estimatedPrice                   : vmInAwsTemplate.estimatedPrice,
        providerAccount                  : vmInAwsTemplate.providerAccount,
        completedState                   : vmInAwsTemplate.completedState,
        approvalState                    : vmInAwsTemplate.approvalState,
        orderTypeDel                     : vmInAwsTemplate.orderTypeDel,
        urlOrders                        : vmInAwsTemplate.urlOrders,
        estimatedCost                    : vmInAwsTemplate.estimatedCost,
        orderSubmittedConfirmationMessage: vmInAwsTemplate.orderSubmittedConfirmationMessage,
    };


    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        browser.driver.manage().window().maximize();
    });


    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        serviceName = vmInAwsTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
        virtualMachineName = vmInAwsTemplate.virtualMachineNamePrefix + "-" + util.getRandomString(5);
        awsSshKeyName = vmInAwsTemplate.awsSshKeyNamePrefix + "-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Public SSH Key Name": awsSshKeyName, "Virtual Machine name": virtualMachineName }
    });


    it('ICAM : ICAM-Off Virtual Machine In AWS ---- Verify fields on main parameters page',
        function () {
            catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName)
            expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
            placeOrderPage.setServiceNameTextICAM(vmInAwsTemplate.serviceNamePrefix + "-" + util.getRandomString(4));
            placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
            expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
           // expect(placeOrderPage.getTextEstimatedPrice()).toBe(vmInAwsTemplate.EstimatedPrice);
        });


    it('ICAM : ICAM-Off Virtual Machine In AWS ---- Verify summary details and additional details are listed in review order page',
        function () {
            catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
            orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap).then(function (requiredReturnMap) {
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPrice);
                expect(requiredReturnMap["Actual"]["Department"]).toEqual(requiredReturnMap["Expected"]["Department"]);
                expect(requiredReturnMap["Actual"]["Virtual Machine name"]).toEqual(requiredReturnMap["Expected"]["Virtual Machine name"]);
                expect(requiredReturnMap["Actual"]["Instance Plan"]).toEqual(requiredReturnMap["Expected"]["Instance Plan"]);
                expect(requiredReturnMap["Actual"]["AWS region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
                expect(requiredReturnMap["Actual"]["AWS Cloud Connection Name"]).toEqual(requiredReturnMap["Expected"]["Cloud Connection Name"]);
                expect(requiredReturnMap["Actual"]["VPC Name tag"]).toEqual(requiredReturnMap["Expected"]["VPC Name tag"]);
                expect(requiredReturnMap["Actual"]["Subnet Name"]).toEqual(requiredReturnMap["Expected"]["Subnet Name"]);
                expect(requiredReturnMap["Actual"]["Public SSH Key Name"]).toEqual(requiredReturnMap["Expected"]["Public SSH Key Name"]);
                expect(requiredReturnMap["Actual"]["Public SSH Key"]).toBeDefined();
            });
        });


    it('ICAM : ICAM-Off Virtual Machine In AWS ---- Verify that the order is listed in order details page once it is submitted from catalog page', function () {
        //catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
        orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            var orderId = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            ordersPage.open();
            expect(util.getCurrentURL()).toMatch(messageStrings.urlOrders);
            ordersPage.searchOrderById(orderId);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderId);
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual(messageStrings.approvalState);
            expect(ordersPage.getTextSubmittedByOrderDetails()).toContain(catalogPage.extractUserFirstName());
            expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            expect(ordersPage.isDisplayedDenyButtonOrderDetails()).toEqual(true);
            ordersPage.clickServiceConfigurationsTabOrderDetails();
            expect(ordersPage.getTextBasedOnLabelName("Department")).toEqual((requiredReturnMap["Expected"]["Department"]));
            expect(ordersPage.getTextBasedOnLabelName("Virtual Machine name")).toEqual((requiredReturnMap["Expected"]["Virtual Machine name"]));
            expect(ordersPage.getTextBasedOnLabelName("Instance Plan")).toEqual((requiredReturnMap["Expected"]["Instance Plan"]));
            expect(ordersPage.getTextBasedOnLabelName("AWS region")).toEqual((requiredReturnMap["Expected"]["AWS Region"]));
            expect(ordersPage.getTextBasedOnLabelName("AWS Cloud Connection Name")).toEqual((requiredReturnMap["Expected"]["Cloud Connection Name"]));
            expect(ordersPage.getTextBasedOnLabelName("VPC Name tag")).toEqual((requiredReturnMap["Expected"]["VPC Name tag"]));
            expect(ordersPage.getTextBasedOnLabelName("Subnet Name")).toEqual((requiredReturnMap["Expected"]["Subnet Name"]));
            expect(ordersPage.getSshKeyBasedOnLabelName("Public SSH Key Name")).toEqual((requiredReturnMap["Expected"]["Public SSH Key Name"]));
            expect(ordersPage.getSshKeyBasedOnLabelName("Public SSH Key")).toEqual((requiredReturnMap["Expected"]["Public SSH Key"]));

            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);

        });
    });
    if (isProvisioningRequired == "true") {
        it('ICAM : ICAM-Off Virtual Machine In AWS --- Verify provision and delete services', function () {
            //Provision service
            //catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(vmInAwsTemplate.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetailsICAM(vmInAwsTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {

                //Delete service
                if (status == 'Completed') {
                    orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                    expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
                    orderFlowUtil.approveDeletedOrder(orderObject);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState);
                }
            });
        });
    }
});
