"use strict";
var Orders = require('../../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../../helpers/util.js'),
    jsonUtil = require('../../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../../testData/appUrls.json'),
    imiUtil = require('../../../../../helpers/imiApiUtil.js'),
    shoppingCartTemplate = require('../../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
    imiConfigTemplate = require('../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    imiManageServiceTemplate = require('../../../../../testData/OrderIntegration/Imi/manageService.json'),
    ec2InstanceTemplate = require('../../../../../testData/OrderIntegration/AWS/AWSEC2Instance.json');

describe('IMI-AWS-EC2', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, EC2INSObject, inventoryPage, msgToVerify;
    var adapterName = "Real";
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = ec2InstanceTemplate.componentType;
    
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Compute',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        powerStateOff: "Stopped",
        powerStateOn: "On",
        orderTypeAction: "Action",
        turnOnNegativeWarning: shoppingCartTemplate.turnOnNegativeWarning,
        turnOffNegativeWarning: shoppingCartTemplate.turnOffNegativeWarning,
        rebootNegativeWarning: shoppingCartTemplate.rebootNegativeWarning,
        turnOffNegativeWarningRealAdapter: "Turn OFF action cannot be performed in Stopped status.",
        rebootNegativeWarningrealAdapter: "Reboot action cannot be performed in Stopped status.",
        serviceOfferingTurnOff: "Turn OFF",
        serviceOfferingTurnOn: "Turn ON",
        serviceOfferingReboot: "Reboot",
        instanceName: ec2InstanceTemplate.instanceName,
        componentType: ec2InstanceTemplate.componentType,
        Imageid: ec2InstanceTemplate.Imageid,
        Instancetype: ec2InstanceTemplate.Instancetype,
        Keyname: ec2InstanceTemplate.Keyname,
        Subnetid: ec2InstanceTemplate.Subnetid,
        Architecture: ec2InstanceTemplate.Architecture,
        Vpcid: ec2InstanceTemplate.Vpcid,
        Virtualizationtype: ec2InstanceTemplate.Virtualizationtype,
        bomItem1: "OnDemand Compute Instance t2.small",
        bomItem2: imiConfigTemplate.bomItem2,
        bomItem3: imiConfigTemplate.bomItem3,
        imiOrderSubmitted: "Configure IMI Managed Service",
         customOpsOrderSubmittedMsg: "Order Request Initiated!"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();

    });   
        
//     afterEach(function(){
//         catalogPage.open();
//         browser.navigate().refresh()
//     });

//     beforeEach(function(){
//         catalogPage.open();        
//     });
    
    it('IMI:AWS EC2 - Verify E2E flow for EC2 with IMI Add On', function () {

        var serviceDetailsMap = {};
        serviceName = "aws-auto-ec2-" + util.getRandomString(5);
        var addOnName = "ec2-adOn-" + util.getRandomString(5);
        var groupName = "att-group-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Group Name": groupName, "Add-On Name": addOnName };
        EC2INSObject = JSON.parse(JSON.stringify(ec2InstanceTemplate));
        orderObject.servicename = serviceName;
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);

        //Update ec2 template with IMI template
        delete ec2InstanceTemplate["Order Parameters"]["Configure Add-ons"];
        ec2InstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
        ec2InstanceTemplate["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
        ec2InstanceTemplate["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
        ec2InstanceTemplate["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            ec2InstanceTemplate["Order Parameters"]["Configure Add-ons"] = imiManageServiceTemplate["Configure Add-ons"];
            delete ec2InstanceTemplate["Order Parameters"]["IMI Main Parameters"];
            delete ec2InstanceTemplate["Order Parameters"]["Configure manage service"];
            delete ec2InstanceTemplate["Order Parameters"]["Review IMI Config"];
            util.waitForAngular();
            //Validate IMI configuration on Review Order page
            expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(placeOrderPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(placeOrderPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Provider Account", 1)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Provider Account IMI"));

            //Validate Review Order page with all Service Configuration
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            placeOrderPage.getEstimatedPrice_ReviewOrder().then(function(pricing){
                var actPricing = parseFloat(pricing.replace("USD ", "")).toFixed(2);
                var exPricing = parseFloat((ec2InstanceTemplate.TotalCostWithAddOn).replace("USD ", "")).toFixed(2);
                expect(actPricing).toBe(exPricing);
            });

            //expect((placeOrderPage.getEstimatedPrice_ReviewOrder())).toBe(ec2InstanceTemplate.TotalCostWithAddOn);
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Resource Name"]).toEqual(requiredReturnMap["Expected"]["Resource Name"]);
            expect(requiredReturnMap["Actual"]["Instance Type"]).toEqual(requiredReturnMap["Expected"]["Instance Type"]);
            expect(requiredReturnMap["Actual"]["Architecture"]).toEqual(requiredReturnMap["Expected"]["Architecture"]);
            //expect(requiredReturnMap["Actual"]["Virtualization Type"]).toEqual(requiredReturnMap["Actual"]["Virtualization Type"]);
            //expect(requiredReturnMap["Expected"]["Image Name"]).toContain(requiredReturnMap["Expected"]["Image Name"]);
            expect(requiredReturnMap["Actual"]["Availability Zone"]).toEqual(requiredReturnMap["Expected"]["Availability Zone"]);
            expect(requiredReturnMap["Actual"]["Vpc Creation Mode"]).toEqual(requiredReturnMap["Expected"]["Vpc Creation Mode"]);
            expect(requiredReturnMap["Actual"]["IAM Role"]).toEqual(requiredReturnMap["Expected"]["IAM Role"]);
            expect(requiredReturnMap["Actual"]["Shutdown Behavior"]).toEqual(requiredReturnMap["Expected"]["Shutdown Behavior"]);
            expect(requiredReturnMap["Actual"]["Enable Termination Protection"]).toEqual(requiredReturnMap["Expected"]["Enable Termination Protection"]);
            //expect(requiredReturnMap["Actual"]["Monitoring"]).toEqual(requiredReturnMap["Expected"]["Monitoring"]);
            expect(requiredReturnMap["Actual"]["T2/T3 Unlimited"]).toEqual(requiredReturnMap["Expected"]["T2/T3 Unlimited"]);
            //expect(requiredReturnMap["Actual"]["SSH Key Name"]).toEqual(requiredReturnMap["Expected"]["SSH Key Name"]);
            //expect(requiredReturnMap["Actual"]["SSH Location"]).toEqual(requiredReturnMap["Expected"]["SSH Location"]);
            expect(requiredReturnMap["Actual"]["User Data"]).toEqual(requiredReturnMap["Expected"]["User Data"]);

            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                //Validate Estimated price on approve order page                
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(ec2InstanceTemplate.EstimatedPriceAdOn);
                
            }
            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate Add on on orders page
            expect(ordersPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            //expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
            //expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            util.waitForAngular();
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("Resource Name")).toEqual(jsonUtil.getValue(EC2INSObject, "Resource Name"));
            expect(ordersPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            expect(ordersPage.getTextBasedOnLabelName("Search By")).toEqual(jsonUtil.getValue(EC2INSObject, "Search By"));
            //expect(ordersPage.getTextBasedOnLabelName("Virtualization Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Virtualization Type"));
            expect(ordersPage.getTextBasedOnLabelName("Self Image")).toEqual(jsonUtil.getValue(EC2INSObject, "Self Image"));
            expect(ordersPage.getTextBasedOnLabelName("Availability Zone")).toEqual(jsonUtil.getValue(EC2INSObject, "Availability Zone"));
           // expect(ordersPage.getTextBasedOnLabelName("VPC Creation Mode")).toEqual(jsonUtil.getValue(EC2INSObject, "VPC Creation Mode"));
            //expect(ordersPage.getTextBasedOnLabelName("IAM Role")).toEqual(jsonUtil.getValue(EC2INSObject, "IAM Role"));
            expect(ordersPage.getTextBasedOnLabelName("Shutdown Behavior")).toEqual(jsonUtil.getValue(EC2INSObject, "Shutdown Behavior"));
            expect(ordersPage.getTextBasedOnLabelName("Enable Termination Protection")).toEqual(jsonUtil.getValue(EC2INSObject, "Enable Termination Protection"));
            //expect(ordersPage.getTextBasedOnLabelName("Monitoring")).toEqual(jsonUtil.getValue(EC2INSObject, "Monitoring"));
            expect(ordersPage.getTextBasedOnLabelName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(EC2INSObject, "T2/T3 Unlimited"));
            //expect(ordersPage.getTextBasedOnLabelName("SSH Key Name")).toEqual(jsonUtil.getValue(EC2INSObject, "SSH Key Name"));
           // expect(ordersPage.getTextBasedOnLabelName("SSH Location")).toEqual(jsonUtil.getValue(EC2INSObject, "SSH Location"));
            expect(ordersPage.getTextBasedOnLabelName("User Data")).toEqual(jsonUtil.getValue(EC2INSObject, "User Data"));
            //Validate Add On details
            ordersPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelName("Add-on Name")).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 2)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate estimated cost
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(ec2InstanceTemplate.TotalCostWithAddOn);
            //Validate BOM table on order details
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Compute Instance t2.small": "USD 17.112", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            //Validate Add-On tag
            expect(ordersHistoryPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate Add On Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickExpandArrowForServiceAddOn();
            ordersHistoryPage.getAddOnDetails().then(function (addOnDetails) {
                expect(addOnDetails[1]).toContain(addOnName);
                expect(addOnDetails[3]).toContain(imiConfigTemplate.EstimatedPrice);
                expect(addOnDetails[4]).toContain("Completed");
            })
            //Validate Service Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Resource Name")).toEqual(jsonUtil.getValue(EC2INSObject, "Resource Name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Architecture")).toEqual(jsonUtil.getValue(EC2INSObject, "Architecture"));
           // expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Virtualization Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Virtualization Type"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Image Name")).toEqual(jsonUtil.getValue(EC2INSObject, "Image Name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Availability Zone")).toEqual(jsonUtil.getValue(EC2INSObject, "Availability Zone"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC Creation Mode")).toEqual(jsonUtil.getValue(EC2INSObject, "VPC Creation Mode"));
           // expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("IAM Role")).toEqual(jsonUtil.getValue(EC2INSObject, "IAM Role"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Shutdown Behavior")).toEqual(jsonUtil.getValue(EC2INSObject, "Shutdown Behavior"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Enable Termination Protection")).toEqual(jsonUtil.getValue(EC2INSObject, "Enable Termination Protection"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Monitoring")).toEqual(jsonUtil.getValue(EC2INSObject, "Monitoring"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(EC2INSObject, "T2/T3 Unlimited"));
           // expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("SSH Key Name")).toEqual(jsonUtil.getValue(EC2INSObject, "SSH Key Name"));
            //expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("SSH Location")).toEqual(jsonUtil.getValue(EC2INSObject, "SSH Location"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("User Data")).toEqual(jsonUtil.getValue(EC2INSObject, "User Data"));

            //Validate Add-On Details
            ordersHistoryPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelName("Add-on Name")).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 4)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(ec2InstanceTemplate.TotalCostWithAddOn);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "OnDemand Compute Instance t2.small": ec2InstanceTemplate.TotalCost, "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(ec2InstanceTemplate.TotalCostWithAddOn);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Verify Output parameter in Inventory
            expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            inventoryPage.clickViewAddOnDetails(orderObject);
            //Verify Add On details in Inventory
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Provider Name", 3)).toBe("IMI");
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Instance Status", 2)).toBe("Active");
            expect(inventoryPage.getTextImiMangmntLevl()).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            inventoryPage.getTextBasedOnLabelName("Plan level").then(function(text){
                expect(text).toContain(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            });
            //Verify bom for Add On
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(imiConfigTemplate.TotalCost);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Validate IMI tags
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                var tagList = tags.split(",");
                if(isDummyAdapterDisabled == "true"){
                    expect(tagList[4]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[5]).toContain(imiConfigTemplate.ServiceTierName);
                }else{
                    expect(tagList[2]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[0]).toContain(imiConfigTemplate.ServiceTierName); 
                }                 
                orderFlowUtil.closeHorizontalSliderIfPresent();
            });
        });
    });
    
    if(isDummyAdapterDisabled == "true"){

        it('AWS-EC2-- Verify View Component-Template Output Parameters for the powered ON instance', function () {
            orderObject.servicename = serviceName;            
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickViewComponentofAWSInstance().then(function () {
                        //View Component VM details
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(messageStrings.componentType);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Name")).toEqual(messageStrings.instanceName);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Status")).toEqual(messageStrings.powerStateOn);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);

                        //View Component Template Output Properties
                       expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("InstanceType")).toContain(messageStrings.Instancetype);
                       expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("ImageId")).toContain(messageStrings.Imageid);
                       expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("SubnetId")).toContain(messageStrings.Subnetid);
                       expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Architecture")).toEqual(messageStrings.Architecture);
                       expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("VirtualizationType")).toEqual(messageStrings.Virtualizationtype);
                        orderFlowUtil.closeHorizontalSliderIfPresent();
                    });
                });
            });
        });
    }

    it('AWS EC2 Negative Scenario ---- Turn ON the instance when the VM state is ON', function () {
      
        orderObject.servicename = serviceName;        
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickTurnONButtonOfInstance().then(function () {
                    inventoryPage.placeD2opsOrder();
                    expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOnNegativeWarning);
                    inventoryPage.clickCustomOpsWarningOKButton();
                });
            });
        });
    });

    it('TC-C172385 : AWS EC2 - Verify instance Turn OFF functionality', function () {

        //VM status for real adapter            
        orderObject.servicename = serviceName;       
        var status = messageStrings.powerStateOff;
        if(isDummyAdapterDisabled == "false"){
            status = 'Off';
            adapterName = "dummy";
        };
        var val = JSON.stringify({ "IsUsingDummy": "Yes" });
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            browser.executeScript('window.scrollTo(0,0);');
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                 //  inventoryPage.placeD2opsOrder();
                   inventoryPage.clickOkForInstanceTurnOFFPermission();
                   inventoryPage.fetchD2opsOrderDetails();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provInProgressState);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingTurnOff);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                 expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe(status);
//                 inventoryPage.getComponentTags().then(function (text) {
//                     if (val == text) {
//                         //Status for dummy adapter
//                         status = 'Off';
//                         adapterName = "dummy";
//                     }
//                     //inventoryPage.waitForInstancStateStatusChange(orderObject, status).then(function(){
//                     expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe(status);
//                     //});                
//                 });
            });
        });
    });

    it('AWS EC2 Negative Scenario ---- Turn OFF the instance when the VM state is OFF', function () {

        orderObject.servicename = serviceName;       
        if (adapterName == "Real") {
            msgToVerify = messageStrings.turnOffNegativeWarningRealAdapter;
        } else {
            msgToVerify = messageStrings.turnOffNegativeWarning;
        }
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                    inventoryPage.placeD2opsOrder();
                    expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(msgToVerify);
                    inventoryPage.clickCustomOpsWarningOKButton();
                });
            });
        });
    });

    it('AWS EC2 Negative Scenario ---- Reboot the instance when the VM state is OFF', function () {
        //var orderObject = {};
        orderObject.servicename = serviceName;        
        if (adapterName == "Real") {
            msgToVerify = messageStrings.rebootNegativeWarningrealAdapter;
        } else {
            msgToVerify = messageStrings.rebootNegativeWarning;
        }
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickRebootButtonOfInstance().then(function () {
                    inventoryPage.placeD2opsOrder();
                    expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(msgToVerify);
                    inventoryPage.clickCustomOpsWarningOKButton();
                });
            });
        });
    });

    it('TC-C172384 : AWS EC2 - Verify instance Turn ON functionality', function () {
        orderObject.servicename = serviceName;       
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            browser.executeScript('window.scrollTo(0,0);');
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickTurnONButtonOfInstance().then(function () {
                   // inventoryPage.placeD2opsOrder();
                    inventoryPage.clickOkForInstanceTurnONPermission();
                    inventoryPage.fetchD2opsOrderDetails();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
           // orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provInProgressState);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingTurnOn);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
            });
        });
    });

    it('TC-C172386 : AWS EC2 - Verify instance Reboot functionality', function () {
        orderObject.servicename = serviceName;        
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            browser.executeScript('window.scrollTo(0,0);');
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickRebootButtonOfInstance().then(function () {
                    //inventoryPage.placeD2opsOrder();
                    inventoryPage.clickOkForInstanceRebootPermission();
                    inventoryPage.fetchD2opsOrderDetails(); 
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
           //orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provInProgressState);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingReboot);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
            });
        });

      
    });

    it('AWS EC2 IMI- Configure IMI Manage service having Add On', function () {        
       
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickConfigureImiServicefirst();
                inventoryPage.clickOkButnInConfigrImiPopUp();
            });
        });
         modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
        orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
            //Validate Estimated Cost    
            expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
            //Validate updated BOM table
            var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
            
            //Submit order
            placeOrderPage.submitOrder();
            inventoryPage.fetchD2opsOrderDetails();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.customOpsOrderSubmittedMsg);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            //expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service details
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //Validate BOM on Approve order page
            ordersPage.clickBOMTabImi();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }

            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Approve order            
            orderFlowUtil.approveOrder(orderObject);            
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);

            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
//             ordersHistoryPage.getImiManagedServiceDetails().then(function(imiDetails){
//                expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
//                 expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
//             });

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            
            //Validate Updated BOM on Inventory(AddOn+Manage Service)
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(ec2InstanceTemplate.TotalCostWithAddOn);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            inventoryPage.clickViewServiceClosebutton();

            //Delete Service flow
            orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);            
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
        });
    });


    it('AWS EC2 IMI- Configure Manage service from Inventory', function () {
        var serviceDetailsMap = {};
        serviceName = "aws-auto-ec2-" + util.getRandomString(5);
        var groupName = "att-group-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Group Name": groupName };
        
        EC2INSObject = JSON.parse(JSON.stringify(ec2InstanceTemplate));
        orderObject.servicename = serviceName;
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);    
        catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);
       
        //Fill Order Details
        orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap);
        //Submit Order
        placeOrderPage.submitOrder();        
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);        
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
        //Validate Estimated price on approve order page
        expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(ec2InstanceTemplate.EstimatedPrice); 

        modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                inventoryPage.clickConfigureImiServicefirst();
                inventoryPage.clickOkButnInConfigrImiPopUp();
            });
        });
   
        orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
            //Validate Estimated Cost    
            expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
            //Validate updated BOM table
            var priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
            
            //Submit order
            placeOrderPage.submitOrder();
            inventoryPage.fetchD2opsOrderDetails();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.customOpsOrderSubmittedMsg);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            //expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service details
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //Validate BOM on Approve order page
            ordersPage.clickBOMTabImi();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }

            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Approve order            
            orderFlowUtil.approveOrder(orderObject);            
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);

            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
            
//             ordersHistoryPage.getImiManagedServiceDetails().then(function(imiDetails){
//                expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
//                 expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
//             });

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            
            //Delete Service flow
            orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
            //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
        });
    });
});
