"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	azureLinuxTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/AzureLinuxVMSnow.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('Azure E2E cases for Auto Deny Technical, Auto Financial and External Legal Approval with Standard change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, provOrder, sampleOrder1, inventoryPage, policyPage, cartListPage;
	var modifiedParamMap = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var serviceName = "SNOWauto"+util.getRandomString(5);
	var policyName = "SNOWautoAzurePolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWautoAzurePolicyRule"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var newResourceGroupName = "gslautotc_azureWVM-RG101" + util.getRandomString(4);
	var newVmName = "auto-VM101" + util.getRandomString(4);
	var newNetworkName = "auto-VN101" + util.getRandomString(4);
	var newSubnetName = "auto-SN101" + util.getRandomString(4);
	var newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
	var newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
	var newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
	var newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
	var diskName = "autodisk" + util.getRandomString(4);
    diskName = diskName.toLocaleLowerCase();
	var azureLinuxObj = JSON.parse(JSON.stringify(azureLinuxTemplate.Scenario1));
	
	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["Azure"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
								"Technical":"Auto Deny","Legal":"External Approval"};
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Disk Name": diskName, "Virtual Network Name": newNetworkName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName };
	});
	
	afterAll(function() {

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		policyPage.open();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		policyPage.clickRadioButtonRetiredOption();
		policyPage.clickUpdatePolicyBtn();
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickButtonDeletePolicyText();
		policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});
	
	it('Set Change Request type to Standard in SNOW', function () {
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Approval Policy for Azure with Auto Deny Technical, Auto Financial and External Legal Approval and Standard change', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.selectExternalApprovalDropdownSNOW();
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('Azure: Linux Virtual Machine ---- Verify Provision functionality with Auto Deny Technical, Auto Financial and External Legal Approval and Standard change', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(azureLinuxObj.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(azureLinuxObj.Category);
			catalogPage.clickConfigureButtonBasedOnName(azureLinuxObj.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(azureLinuxTemplate.Scenario1, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(azureLinuxObj.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,azureLinuxObj.rejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(azureLinuxObj.rejectedState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestRejectedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextShortDescription()).toBe(azureLinuxObj.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(azureLinuxObj.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescAzure);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAzure);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Resource Group Required")).toEqual("Yes");
			expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("New Resource Group")).toEqual(newResourceGroupName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Location")).toEqual(jsonUtil.getValue(azureLinuxObj, "Location").toString().toLowerCase().replace(/\s/g,''));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Name")).toEqual(newVmName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Location")).toEqual(jsonUtil.getValue(azureLinuxObj,"Virtual Machine Location"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Username")).toEqual(jsonUtil.getValue(azureLinuxObj,"Username"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Authentication Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Authentication Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Admin Password")).toEqual("XXXXXX");	
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Proximity Placement Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "Proximity Placement Group"));			
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Availability Options")).toEqual("NoInfrastructureRedundancyRequired");			
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Operating System Image")).toEqual("RHEL, 7.4, RedHat");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Vm Generation")).toEqual("V1");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Machine Size")).toEqual("Basic_A0");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("New Virtual Network Required")).toEqual(jsonUtil.getValue(azureLinuxObj,"New Virtual Network Required"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Virtual Network Name")).toEqual(newNetworkName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Address Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Address Prefix"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Name")).toEqual(newSubnetName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subnet Prefix")).toEqual(jsonUtil.getValue(azureLinuxObj, "Subnet Prefix"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Interface Name")).toEqual(newNetworkInterfaceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Required")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Required"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Name")).toEqual(newPublicIpName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Ip Address Sku")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Ip Address Sku"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public IP Address Type")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public IP Address Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("NIC Network Security Group")).toEqual(jsonUtil.getValue(azureLinuxObj, "NIC Network Security Group"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Public Inbound Ports")).toEqual(jsonUtil.getValue(azureLinuxObj, "Public Inbound Ports"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Network Security Group Name")).toEqual(newnetworkSecurityGroupName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Use Load Balancing")).toEqual(jsonUtil.getValue(azureLinuxObj, "Use Load Balancing"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("System Assigned Managed Identity")).toEqual(jsonUtil.getValue(azureLinuxObj, "System Assigned Managed Identity"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Boot Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "Boot Diagnostics"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("OS Guest Diagnostics")).toEqual(jsonUtil.getValue(azureLinuxObj, "OS Guest Diagnostics"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Enable Auto Shutdown")).toEqual(jsonUtil.getValue(azureLinuxObj, "Enable Auto Shutdown"));
			
			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem1Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem2Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem3Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem4Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem5Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem6Value)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem1Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNIAzure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem2Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalVNAzure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem3Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalNSGAzure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem4Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSBA0Azure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem5Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalPublicIPAzure);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAzureSrvcItem6Value)).toBe(snowInstanceTemplate.snowreqItemBOMtotalHDDAzure);
		   });		
		});
	 }
	
});
	
	
	
	