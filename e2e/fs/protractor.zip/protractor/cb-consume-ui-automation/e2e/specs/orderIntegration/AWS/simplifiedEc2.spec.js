"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../testData/appUrls.json'),
    shoppingCartTemplate = require('../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
    imiConfigTemplate = require('../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    ec2InstanceTemplate = require('../../../../testData/OrderIntegration/AWS/simplifiedEC2.json');

describe('AWS - EC2 SimplifiedEc2', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, EC2INSObject, inventoryPage, msgToVerify;
    var adapterName = "Real";
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = ec2InstanceTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Compute',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        powerStateOff: "Stopped",
        powerStateOn: "On",
        orderTypeAction: "Action",
        turnOnNegativeWarning: shoppingCartTemplate.turnOnNegativeWarning,
        turnOffNegativeWarning: shoppingCartTemplate.turnOffNegativeWarning,
        rebootNegativeWarning: shoppingCartTemplate.rebootNegativeWarning,
        turnOffNegativeWarningRealAdapter: "Turn OFF action cannot be performed in Stopped status.",
        rebootNegativeWarningrealAdapter: "Reboot action cannot be performed in Stopped status.",
        serviceOfferingTurnOff: "Turn OFF",
        serviceOfferingTurnOn: "Turn ON",
        serviceOfferingReboot: "Reboot",
        instanceName: ec2InstanceTemplate.instanceName,
        componentType: ec2InstanceTemplate.componentType,
        Imageid: ec2InstanceTemplate.Imageid,
        Instancetype: ec2InstanceTemplate.Instancetype,
        Keyname: ec2InstanceTemplate.Keyname,
        Subnetid: ec2InstanceTemplate.Subnetid,
        Architecture: ec2InstanceTemplate.Architecture,
        Vpcid: ec2InstanceTemplate.Vpcid,
        Virtualizationtype: ec2InstanceTemplate.Virtualizationtype,
        isDummyTagValue: 'Yes',
        systemTagText: "ibm_mcmp_soiid"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-simplified-ec2-" + util.getRandomString(5);
    });

    beforeEach(function () {
        modifiedParamMap = { "Service Instance Name": serviceName };
    });

    it('AWS-SimplifiedEC2 - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        catalogPage.open();
        EC2INSObject = JSON.parse(JSON.stringify(ec2InstanceTemplate));
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(ec2InstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(ec2InstanceTemplate.TotalCost); expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            }
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Instance Type"]).toEqual(requiredReturnMap["Expected"]["Instance Type"]);
            expect(requiredReturnMap["Actual"]["Instance Family"]).toEqual(requiredReturnMap["Expected"]["Instance Family"]);
            expect(requiredReturnMap["Actual"]["Key Pair"]).toEqual(requiredReturnMap["Expected"]["Key Pair"]);

            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                if (browser.params.defaultCurrency == "USD") {
                    //Validate Estimated price on approve order page
                    expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(ec2InstanceTemplate.EstimatedPrice);
                    //Validate pricing on order history page
                    ordersHistoryPage.open();
                    ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                    expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(ec2InstanceTemplate.EstimatedPrice);
                }
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();

            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Family")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Family"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Key Pair")).toEqual(jsonUtil.getValue(EC2INSObject, "Key Pair"));
            if (browser.params.defaultCurrency == "USD") {
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(ec2InstanceTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(ec2InstanceTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
            }
            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("Instance Family")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Family"));
            expect(ordersPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            expect(ordersPage.getTextBasedOnLabelName("Key Pair")).toEqual(jsonUtil.getValue(EC2INSObject, "Key Pair"));
            if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(ec2InstanceTemplate.TotalCost);
                ordersPage.clickServiceDetailSliderCloseButton();
            }
        });
    });

    if (isProvisioningRequired == "true") {
        if (isDummyAdapterDisabled == "true") {
            it('AWS-SimplifiedEC2--Verify View Component-Template Output Parameters for the powered ON instance', function () {

                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                        inventoryPage.clickViewComponentofAWSInstance().then(function () {
                            //View Component VM details
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(messageStrings.componentType);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelName("Name")).toEqual(messageStrings.instanceName);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Status")).toEqual(messageStrings.powerStateOn);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);

                            //View Component Template Output Properties
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("KeyName")).toEqual(messageStrings.Keyname);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("InstanceType")).toContain(messageStrings.Instancetype);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("ImageId")).toContain(messageStrings.Imageid);
                            // expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("SubnetId")).toContain(messageStrings.Subnetid);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Architecture")).toEqual(messageStrings.Architecture);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Vpc")).toEqual(messageStrings.Vpcid);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("VirtualizationType")).toEqual(messageStrings.Virtualizationtype);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("RootDeviceName")).toEqual(ec2InstanceTemplate.RootDeviceName);

                            inventoryPage.closeViewComponent();
                            inventoryPage.clickExpandFirstRow();
                        });
                    });
                });
            });
        };

        it('AWS SimplifiedEC2 - Verify instance Turn OFF functionality', function () {
            //VM status for real adapter            
            orderObject.servicename = serviceName;
            var status = messageStrings.powerStateOff;
            var val = JSON.stringify({ "IsUsingDummy": "Yes" });
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                browser.executeScript('window.scrollTo(0,0);');
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                        inventoryPage.clickOkForInstanceTurnOFFPermission();
                    });
                });
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "TurnOff");
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                //orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provInProgressState);
                orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingTurnOff);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.getComponentTags().then(function (text) {
                        if (val == text) {
                            //Status for dummy adapter
                            status = 'Off';
                            adapterName = "dummy";
                        }
                        //inventoryPage.waitForInstancStateStatusChange(orderObject, status).then(function(){
                        expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe(status);
                        //});                
                    });
                });
            });
        });

        it('AWS SimplifiedEC2 - Verify instance Turn ON functionality', function () {
            orderObject.servicename = serviceName;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                browser.executeScript('window.scrollTo(0,0);');
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickTurnONButtonOfInstance().then(function () {
                        inventoryPage.clickOkForInstanceTurnONPermission();
                    });
                });
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "TurnOn");
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                //orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provInProgressState);
                orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingTurnOn);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
                });
            });
        });

        it('AWS SimplifiedEC2 - Verify instance Reboot functionality', function () {
            orderObject.servicename = serviceName;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                browser.executeScript('window.scrollTo(0,0);');
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickRebootButtonOfInstance().then(function () {
                        inventoryPage.clickOkForInstanceRebootPermission();
                    });
                });
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "Reboot");
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                //orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provInProgressState);
                orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
                expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingReboot);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
                    //   browser.sleep(1000);
                    inventoryPage.clickExpandFirstRow();
                });
            });

        });

        it('AWS SimplifiedEC2 - Validate system tags, Edit and Delete Service', function () {
            //Validate service Tags            
            inventoryPage.open();
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                var tagList = tags.split(",");
                var tagMap = inventoryPage.getServiceTags(tagList);
                var mcmpTag = false;
                if (isDummyAdapterDisabled == "false") {
                    //verifying flags for dummy adapter
                    expect(tagMap["IsUsingDummy"]).toEqual(messageStrings.isDummyTagValue);
                    expect(tagMap["Name"]).toEqual(ec2InstanceTemplate.bluePrintName);
                    expect(tagMap["PhysicalId"]).toContain(serviceName);
                    expect(Object.keys(tagMap).includes("Test")).toBe(true);
                    expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                } else {
                    //verifying a system tag
                    expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                    //verifying some of the service tags
                    expect(tagList.includes(tagList.find(tag => tag.includes("stackId:arn:aws:cloudformation")))).toBe(true);
                    expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:logical-id")))).toBe(true);
                    expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-id")))).toBe(true);
                    expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-name")))).toBe(true);
                    expect(tagMap["serviceInstanceName"].toLowerCase()).toContain(serviceName.toLowerCase());
                }
                orderFlowUtil.closeHorizontalSliderIfPresent();
                if (isDummyAdapterDisabled == "false") {
                    //Edit service flow
                    var modifiedParamMap = { "EditService": true };
                    orderFlowUtil.editService(orderObject);
                    orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap).then(function (reviewOrderExpActParamsMap) {
                        logger.info("Edit parameter details are filled.");
                        if (browser.params.defaultCurrency == "USD") {
                            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(ec2InstanceTemplate.TotalCostPostEdit);
                        }
                        // browser.sleep(5000);
                        //Validate Review order page parameters
                        expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
                    });
                    placeOrderPage.submitOrder();
                    orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "Edit");
                    expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                    placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                    orderFlowUtil.approveOrder(orderObject);
                    orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                    orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                        if (status == 'Completed') {
                            //Verify updated details are reflected on order details page.						
                            ordersPage.clickFirstViewDetailsOrdersTable();
                            expect(ordersPage.getTextBasedOnLabelName("Instance Family")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Instance Family"));
                            expect(ordersPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValueEditParameter(ec2InstanceTemplate, "Instance Type"));
                            if (browser.params.defaultCurrency == "USD") {
                                ordersPage.clickBillOfMaterialsTabOrderDetails();
                                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(ec2InstanceTemplate.TotalCostPostEdit);
                                ordersPage.clickServiceDetailSliderCloseButton();
                            }
                        }
                    });
                }
                //Delete Service flow                    
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, ec2InstanceTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');

            });

        });

    }
});
