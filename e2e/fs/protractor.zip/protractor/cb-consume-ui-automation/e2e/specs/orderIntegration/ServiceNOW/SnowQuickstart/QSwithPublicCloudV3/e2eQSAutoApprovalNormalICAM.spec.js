"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	icamAwsVMtemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/ICAMAWSVirtualMachine321Snow.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
    snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
    
    describe('QS: ICAM E2E cases for Auto Technical, Financial and Legal approval with Normal change', function() {
        var ordersPage, catalogPage, placeOrderPage, policyPage, snowPage, sampleOrder1, provOrder, inventoryPage, cartListPage, publicSSHKeyName;
        var modifiedParamMap = {};
        var modifiedParamMapEdit = {};
        var modifiedParamMapPolicy = {};
        var modifiedParamMapAddRule = {};
		var serviceName = "SNOWQSauto"+util.getRandomString(5);
        var policyName = "SNOWQSautoICAMPolicy"+util.getRandomString(5);
        var policyRuleName = "SNOWQSautoICAMPolicyRule"+util.getRandomString(5);
        var consumeLaunchpadUrl = url + '/launchpad';

    beforeAll(function() {
        snowPage = new SNOWPage();
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        policyPage = new PolicyPage();
        cartListPage = new CartListPage();
        browser.driver.manage().window().maximize();
        
        //Delete policy if exists
		policyPage.open();
		util.waitForAngular();
		policyPage.deletePoliciesIfExist();
    });

    beforeEach(function() {
    	publicSSHKeyName = "snowautokey"+util.getRandomString(5);
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["Terraform Automation"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":""};
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "Provider Account":"Terraform-SNOW-Account / Terraform-SNOW-Account","Public SSH Key Name" : publicSSHKeyName };
		modifiedParamMapEdit = {"Service Instance Name":"", "Team":"", "Environment":"", "Provider Account":"", "Instance Plan":"", "Cloud Connection Name":"", "AWS Region Name":"", "VPC Name tag":"", "Subnet Name":"", 
								"Public SSH Key Name":publicSSHKeyName, "Public SSH Key":""};
    });

    afterAll(function() {
		//Delete Approval Policy
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);
		  
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
    });
    
    it('Set Change Request type to Normal in SNOW', function () {
		expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
    });
    
    it('Create Approval Policy for ICAM with Auto Technical, Financial, Legal approval and Normal change', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
    });
    
    if(isProvisioningRequired == "true") {	
		it('ICAM ---- Verify Provision functionality with Auto Technical, Financial, Legal approval and Normal change', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(icamAwsVMtemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icamAwsVMtemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(icamAwsVMtemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(icamAwsVMtemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icamAwsVMtemplate.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            var orderObject = {"orderNumber":provOrder};	

            //Validation in Marketplace after auto approval
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icamAwsVMtemplate.provisiongstatus);
            
            //Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
            expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
            
            expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(icamAwsVMtemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
            
            //Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
            var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();
            
            expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(icamAwsVMtemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescICAM);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);

			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDICAM);

			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderICAM);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);

			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersionICAM);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
            expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("true");
            
            var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);

            // Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowSrvcItemValueICAM)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowSrvcItemValueICAM)).toBe(snowInstanceTemplate.snowreqItemBOMtotalICAM);
		}).then(function () {

            //Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextCMDBShellCIName()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe("");
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe("");
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
            snowPage.clickUpdateButton();
            
            //Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();

			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
            snowPage.clickBackButton();
            
            //Normal change
			snowPage.openRelatedChangeRequest();

			//Change Task Page Validations 
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickBackButton();
			
			snowPage.enterChangeReqValues();
			snowPage.enterPlanningValues();
			snowPage.enterScheduleValues();
			snowPage.clickCalculateRiskLink();
            snowPage.clickAssessButton();
            
			//Approvals in SNOW
			snowPage.clickRequestApprovalInChangeRequestPage();
			snowPage.approveChangeRequestForEachState();
			snowPage.approveRequestQS();
			snowPage.approveRequestQS();	
			
			//Change Request Short Desc and Desc
			expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescNewOrder);
					
			//Order Completion in SNOW
			snowPage.rightClickOnCMDBCIFormHeader();
			var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
			sysidofChangeRequest.then(function(sysidofChangeRequestValue){
			var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
			setChangeRequesttoImplementState.then(function(statuscode){
			expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			});
			
			//Provisioning Change Task should move to In Progress State once the Change Request is moved to Implement State.
			snowPage.openProvisioningChangeTask();
			expect(snowPage.getTextProvisioningChangeTaskState()).toBe(snowInstanceTemplate.provisioningChangeTaskInProgressState);
			snowPage.clickBackButton();

			snowPage.checkIfProvisioningTaskClosed();
			snowPage.closeNotifySerDeskTask();
			snowPage.closeImplementTask();
			snowPage.clickCloseChangeRequestButton();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icamAwsVMtemplate.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);

			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.icamProviderAccountID);
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.icamProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	

			//Change Task Page Validations 
			snowPage.openRelatedChangeRequest();
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickClosureInfoInChangeTask();
			expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			snowPage.clickBackButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickBackButton();
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
            
            });
		});				
            
        });

        it('ICAM ---- Verify Edit functionality with Auto Technical, Financial, Legal approval and Normal change', function () {
		
			//Place Order for Edit in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			//var modifiedParamMap = {"EditService": true };
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.editService(orderObject);
			orderFlowUtil.fillOrderDetails(icamAwsVMtemplate, modifiedParamMapEdit);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icamAwsVMtemplate.orderSubmittedConfirmationMessage);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            //Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icamAwsVMtemplate.provisiongstatus);
            expect(orderFlowUtil.verifyOrderType(orderObject)).toBe(icamAwsVMtemplate.orderTypeEdit);
            
            //Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(icamAwsVMtemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestEdit);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(icamAwsVMtemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescICAM);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);

			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDICAM);

			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderICAM);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			
			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersionICAM);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("true");

			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
					
			
            // Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowSrvcItemValueICAM)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowSrvcItemValueICAM)).toBe(snowInstanceTemplate.snowreqItemBOMtotalICAM);
		}).then(function(){	

			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextCMDBShellCIName()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.icamProviderAccountID);
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.icamProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();

			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickBackButton();
			
			//Normal change
			snowPage.openRelatedChangeRequest();
			
			//Change Task Page Validations 
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickBackButton();

			snowPage.enterChangeReqValues();
			snowPage.enterPlanningValues();
			snowPage.enterScheduleValues();
			snowPage.clickCalculateRiskLink();
			snowPage.clickAssessButton();
			
			//Approvals in SNOW
			snowPage.clickRequestApprovalInChangeRequestPage();
			snowPage.approveChangeRequestForEachState();
			snowPage.approveRequestQS();
			snowPage.approveRequestQS();
			
			//Change Request Short Desc and Desc
			expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescEditOrder);

			//Order Completion in SNOW
			snowPage.rightClickOnCMDBCIFormHeader();
			var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
			sysidofChangeRequest.then(function(sysidofChangeRequestValue){
			var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
			setChangeRequesttoImplementState.then(function(statuscode){
			expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			});

			//Provisioning Change Task should move to In Progress State once the Change Request is moved to Implement State.
			snowPage.openProvisioningChangeTask();
			expect(snowPage.getTextProvisioningChangeTaskState()).toBe(snowInstanceTemplate.provisioningChangeTaskInProgressState);
			snowPage.clickBackButton();

			snowPage.checkIfProvisioningTaskClosed();
			snowPage.closeNotifySerDeskTask();
			snowPage.closeImplementTask();
			snowPage.clickCloseChangeRequestButton();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icamAwsVMtemplate.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);

			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.icamProviderAccountID);
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.icamProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	

			//Change Task Page Validations 
			snowPage.openRelatedChangeRequest();
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickClosureInfoInChangeTask();
			expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			snowPage.clickBackButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickBackButton();
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();

			});
			
	    });		
            
	});
		

		it('ICAM ---- Verify Stop functionality with Auto Technical, Financial, Legal approval and Normal change', function () {

			//Place order for Turn OFF in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
			orderObject.componentType = icamAwsVMtemplate.componentType;
			orderObject.servicename =  serviceName;
			var val = JSON.stringify({ "IsUsingDummy": "Yes" });
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				util.scrollToTop();
				inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
					inventoryPage.clickTurnOFFButtonOfInstanceIcam();
						inventoryPage.placeD2opsOrder();
						inventoryPage.clickOkForInstanceTurnOFFPermission();
						util.waitForAngular();
				});
			}).then(function () {
				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icamAwsVMtemplate.orderSubmittedConfirmationMessage);
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();	

				//Validation in Marketplace after auto approval
				expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(icamAwsVMtemplate.orderTypeAction);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icamAwsVMtemplate.provisiongstatus);
				expect(placeOrderPage.getServiceNameOfferingText()).toBe(icamAwsVMtemplate.serviceOfferingStop);

				//Validations on SNOW Request page after auto approval
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.waitUntilApprovalIsApprovedQS();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

				expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
				var reqNumber = snowPage.getTextRequestNumberInRequestPage();
				expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

				expect(snowPage.getTextShortDescription()).toBe(icamAwsVMtemplate.serviceOfferingStop);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
				
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();

				expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
				var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
				expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
				expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextChangeReqNumber()).not.toBe("");
				var changeRequestNumber = snowPage.getTextChangeReqNumber();
				expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
				var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(icamAwsVMtemplate.serviceOfferingStop);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe("");
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingstop);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderICAM);
				
				expect(snowPage.getTextReqItemVariableConCategory()).toBe("");
				expect(snowPage.getTextMCMPVersionRITMVariable()).toBe('');
				expect(snowPage.getTextLabelsRITMVariable()).toBe("");
				expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("true");

				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual("aws_instance.orpheus_ubuntu_micro");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceId")).not.toBe("");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("stop_vm_op");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalNA);
				}).then(function(){	

				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				snowPage.getTextCMDBShellCIName();
				expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
				snowPage.getTextCMDBShellCIAssignmentGroup();
				expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
				expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
				expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.icamProviderAccountID);
				expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.icamProviderAccount);
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				
				expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
				expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
				expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Normal change
				snowPage.openRelatedChangeRequest();
				
				//Change Task Page Validations 
				snowPage.clickProvTaskLink();
				expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
				expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
				expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
				expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
				expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
				snowPage.clickBackButton();

				snowPage.enterChangeReqValues();
				snowPage.enterPlanningValues();
				snowPage.enterScheduleValues();
				snowPage.clickCalculateRiskLink();
				snowPage.clickAssessButton();
				
				//Approvals in SNOW
				snowPage.clickRequestApprovalInChangeRequestPage();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveRequestQS();
				snowPage.approveRequestQS();	
				
				//Change Request Short Desc and Desc
				expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescStopOrder);
						
				//Order Completion in SNOW
				snowPage.rightClickOnCMDBCIFormHeader();
				var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
				sysidofChangeRequest.then(function(sysidofChangeRequestValue){
				var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
				setChangeRequesttoImplementState.then(function(statuscode){
				expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
				});
				
				//Provisioning Change Task should move to In Progress State once the Change Request is moved to Implement State.
				snowPage.openProvisioningChangeTask();
				expect(snowPage.getTextProvisioningChangeTaskState()).toBe(snowInstanceTemplate.provisioningChangeTaskInProgressState);
				snowPage.clickBackButton();
				
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.closeNotifySerDeskTask();
				snowPage.closeImplementTask();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icamAwsVMtemplate.completedState);
				inventoryPage.open();
				inventoryPage.searchOrderByServiceName(orderObject.servicename);
				inventoryPage.clickExpandFirstRow().then(function () {
					expect(inventoryPage.getInstancePowerStateStatusAzure(orderObject)).toContain("Off");
				});
				
				//Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	

				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				snowPage.getTextCMDBShellCIName();
				expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
				snowPage.getTextCMDBShellCIAssignmentGroup();
				expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
				expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
				expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.icamProviderAccountID);
				expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.icamProviderAccount);
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();	

				//Change Task Page Validations 
				snowPage.openRelatedChangeRequest();
				snowPage.clickProvTaskLink();
				expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
				expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
				expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
				expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
				expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
				snowPage.clickClosureInfoInChangeTask();
				expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
				snowPage.clickBackButton();
				
				//Validation on Catalog Task page after completion
				snowPage.clickBackButton();
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				});

				});		
			});
		});

		it('ICAM ---- Verify Start functionality with Auto Technical, Financial, Legal approval and Normal change', function () {

			//Place order for Turn ON in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
			orderObject.componentType = icamAwsVMtemplate.componentType;
			orderObject.servicename = serviceName;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				util.scrollToTop();
				inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
					inventoryPage.clickTurnONButtonOfInstanceNegativeIcam();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnONPermission();
				});
			}).then(function () {
				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icamAwsVMtemplate.orderSubmittedConfirmationMessage);
				orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();
				
				//Validation in Marketplace after auto approval
				expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(icamAwsVMtemplate.orderTypeAction);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icamAwsVMtemplate.provisiongstatus);
				expect(placeOrderPage.getServiceNameOfferingText()).toBe(icamAwsVMtemplate.serviceOfferingStart);

				//Validations on SNOW Request page after auto approval
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.waitUntilApprovalIsApprovedQS();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

				expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
				var reqNumber = snowPage.getTextRequestNumberInRequestPage();
				expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

				expect(snowPage.getTextShortDescription()).toBe(icamAwsVMtemplate.serviceOfferingStart);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
				
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();

				expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
				var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
				expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
				expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextChangeReqNumber()).not.toBe("");
				var changeRequestNumber = snowPage.getTextChangeReqNumber();
				expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
				var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(icamAwsVMtemplate.serviceOfferingStart);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe("");
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingstart);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderICAM);

				expect(snowPage.getTextReqItemVariableConCategory()).toBe("");
				expect(snowPage.getTextMCMPVersionRITMVariable()).toBe('');
				expect(snowPage.getTextLabelsRITMVariable()).toBe("");
				expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("true");

				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual("aws_instance.orpheus_ubuntu_micro");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceId")).not.toBe("");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("start_vm_op");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalNA);
			}).then(function(){	

				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextCMDBShellCIName()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
				snowPage.getTextCMDBShellCIAssignmentGroup();
				expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
				expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
				expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.icamProviderAccountID);
				expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.icamProviderAccount);
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();

				expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
				expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
				expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Normal change
				snowPage.openRelatedChangeRequest();
				
				//Change Task Page Validations 
				snowPage.clickProvTaskLink();
				expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
				expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
				expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
				expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
				expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
				snowPage.clickBackButton();
				
				snowPage.enterChangeReqValues();
				snowPage.enterPlanningValues();
				snowPage.enterScheduleValues();
				snowPage.clickCalculateRiskLink();
				snowPage.clickAssessButton();
				
				//Approvals in SNOW
				snowPage.clickRequestApprovalInChangeRequestPage();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveRequestQS();
				snowPage.approveRequestQS();	
				
				//Change Request Short Desc and Desc
				expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescStartOrder);
						
				//Order Completion in SNOW
				snowPage.rightClickOnCMDBCIFormHeader();
				var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
				sysidofChangeRequest.then(function(sysidofChangeRequestValue){
				var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
				setChangeRequesttoImplementState.then(function(statuscode){
				expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
				});

				//Provisioning Change Task should move to In Progress State once the Change Request is moved to Implement State.
				snowPage.openProvisioningChangeTask();
				expect(snowPage.getTextProvisioningChangeTaskState()).toBe(snowInstanceTemplate.provisioningChangeTaskInProgressState);
				snowPage.clickBackButton();

				snowPage.checkIfProvisioningTaskClosed();
				snowPage.closeNotifySerDeskTask();
				snowPage.closeImplementTask();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icamAwsVMtemplate.completedState);
				inventoryPage.open();
				inventoryPage.searchOrderByServiceName(orderObject.servicename);
				inventoryPage.clickExpandFirstRow().then(function () {
					expect(inventoryPage.getInstancePowerStateStatusAzure(orderObject)).toContain("On");
				});
				
				//Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	

				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				snowPage.getTextCMDBShellCIName();
				expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
				snowPage.getTextCMDBShellCIAssignmentGroup();
				expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
				expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
				expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.icamProviderAccountID);
				expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.icamProviderAccount);
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();	

				//Change Task Page Validations 
				snowPage.openRelatedChangeRequest();
				snowPage.clickProvTaskLink();
				expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
				expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
				expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
				expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
				expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
				snowPage.clickClosureInfoInChangeTask();
				expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
				snowPage.clickBackButton();
				
				//Validation on Catalog Task page after completion
				snowPage.clickBackButton();
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				});
						
			});		
		});
		});

		it('ICAM ---- Verify Delete functionality with Auto Technical, Financial, Legal approval and Normal change', function () {
			
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			sampleOrder1 = inventoryPage.getDeleteOrderNumber();

			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(icamAwsVMtemplate.provisiongstatus);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(icamAwsVMtemplate.orderTypeDel);

			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(icamAwsVMtemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(icamAwsVMtemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescICAM);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);

			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDICAM);

			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderICAM);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);

			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersionICAM);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("true");

			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);

            // Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowSrvcItemValueICAM)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowSrvcItemValueICAM)).toBe(snowInstanceTemplate.snowreqItemBOMtotalICAMDel);
			}).then(function(){	

			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.icamProviderAccountID);
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.icamProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			
			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickBackButton();
			
			//Normal change
			snowPage.openRelatedChangeRequest();
			
			//Change Task Page Validations 
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickBackButton();

			snowPage.enterChangeReqValues();
			snowPage.enterPlanningValues();
			snowPage.enterScheduleValues();
			snowPage.clickCalculateRiskLink();
			snowPage.clickAssessButton();
			
			//Approvals in SNOW
			snowPage.clickRequestApprovalInChangeRequestPage();
			snowPage.approveChangeRequestForEachState();
			snowPage.approveRequestQS();
			snowPage.approveRequestQS();
			
			//Change Request Short Desc and Desc
			expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescDeleteOrder);
					
			//Order Completion in SNOW
			snowPage.rightClickOnCMDBCIFormHeader();
			var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
			sysidofChangeRequest.then(function(sysidofChangeRequestValue){
			var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
			setChangeRequesttoImplementState.then(function(statuscode){
			expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			});

			//Provisioning Change Task should move to In Progress State once the Change Request is moved to Implement State.
			snowPage.openProvisioningChangeTask();
			expect(snowPage.getTextProvisioningChangeTaskState()).toBe(snowInstanceTemplate.provisioningChangeTaskInProgressState);
			snowPage.clickBackButton();

			snowPage.checkIfProvisioningTaskClosed();
			snowPage.closeNotifySerDeskTask();
			snowPage.closeImplementTask();
			snowPage.clickCloseChangeRequestButton();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(icamAwsVMtemplate.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);

			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.icamProviderAccountID);
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.icamProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			snowPage.clickUpdateButton();	

			//Change Task Page Validations 
			snowPage.openRelatedChangeRequest();
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickClosureInfoInChangeTask();
			expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			snowPage.clickBackButton();

			
			//Validation on Catalog Task page after completion
			snowPage.clickBackButton();
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
		});
			
			});		

		});

	};


});
