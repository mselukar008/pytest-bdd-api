//Author: Atiksha Batra
"use strict";
var logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    async = require('async'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    DataLakeStorageTemplate = require('../../../../testData/OrderIntegration/Azure/dataLakeStorage.json');

describe('Azure - Azure Data Lake Storage Gen1 Service ', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, servicename, SOIComponents;
    var modifiedParamMap = {};
    var servicename = "AutoDataLakesrv" + util.getRandomString(5);
    var newResourceGroupName = "gslautotc_azureDataLake-RG101" + util.getRandomString(4);
    var dataLakeName = "autoservergrp" + util.getRandomString(4);
    dataLakeName = dataLakeName.toLowerCase();
    var messageStrings = { providerName: 'Azure', category: 'Databases', templateName: 'Data Lake Storage Gen1' };
    SOIComponents = [dataLakeName]
    modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Data Lake Name": dataLakeName };

    beforeAll(function () {
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    afterAll(function () {
        // Delete Azure Data Lake Storage Gen1
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    it('Azure: Verify that for Azure Data Lake Storage Gen1 Service required parameters on Service Details Page are present.', function () {
        var dataLakeObject = JSON.parse(JSON.stringify(DataLakeStorageTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(dataLakeObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(dataLakeObject.bluePrintName);
        if (browser.params.defaultCurrency == "USD") {
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(dataLakeObject.BasePrice);
        }
    });

    it('Azure: Verify Review order and View Order Details for Azure Data Lake Storage Gen1 Service', function () {
        var orderObject = {};
        orderObject.servicename = servicename;
        var dataLakeObject = JSON.parse(JSON.stringify(DataLakeStorageTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(dataLakeObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(dataLakeObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(DataLakeStorageTemplate, modifiedParamMap);
        //Verify input values on Review Order page    
        expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(dataLakeObject, "New Resource Group Required"));
        expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
        expect(placeOrderPage.getTextBasedOnLabelName("Location:")).toEqual(jsonUtil.getValue(dataLakeObject, "Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Resource Location:")).toEqual(jsonUtil.getValue(dataLakeObject, "Resource Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Data Lake Name:")).toEqual(dataLakeName);
        expect(placeOrderPage.getTextBasedOnLabelName("Pricing Package:")).toEqual(jsonUtil.getValue(dataLakeObject, "Pricing Package"));
        expect(placeOrderPage.getTextBasedOnLabelName("Encryption Type:")).toEqual(jsonUtil.getValue(dataLakeObject, "Encryption Type"));
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(orderObject.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(orderObject.servicename);//Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe('Azure');//Checking Provider
        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(dataLakeObject, "New Resource Group Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(dataLakeObject, "Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(newResourceGroupName);
        expect(ordersPage.getTextBasedOnExactLabelName("Resource Location")).toEqual(jsonUtil.getValue(dataLakeObject, "Resource Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("Data Lake Name")).toEqual(dataLakeName);
        expect(ordersPage.getTextBasedOnExactLabelName("Pricing Package")).toEqual(jsonUtil.getValue(dataLakeObject, "Pricing Package"));
        expect(ordersPage.getTextBasedOnExactLabelName("Encryption Type")).toEqual(jsonUtil.getValue(dataLakeObject, "Encryption Type"));
        //Checking Bill Of Material
        if (browser.params.defaultCurrency == "USD") {
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(ordersPage.getEstimatedCost()).toBe(dataLakeObject.TotalCost);
        }
        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
    });

    if (isProvisioningRequired == "true") {
        it('Azure: Verify provisioning of Azure Data Lake Storage Gen1 Service using Consume UI', function () {
            var orderObject = {};
            orderObject.servicename = servicename;
            var dataLakeObject = JSON.parse(JSON.stringify(DataLakeStorageTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(dataLakeObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(dataLakeObject.bluePrintName);
            orderFlowUtil.fillOrderDetails(DataLakeStorageTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
            inventoryPage.clickViewService();
            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(dataLakeObject, "New Resource Group Required"));
            expect(inventoryPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
            expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(dataLakeObject, "Location"));
            expect(inventoryPage.getTextBasedOnLabelName("Data Lake Name:")).toEqual(dataLakeName);
             expect(inventoryPage.getTextBasedOnLabelName("Resource Location:")).toEqual(jsonUtil.getValue(dataLakeObject, "Resource Location"));
             expect(inventoryPage.getTextBasedOnLabelName("Pricing Package:")).toEqual(jsonUtil.getValue(dataLakeObject, "Pricing Package"));
             expect(inventoryPage.getTextBasedOnLabelName("Encryption Type:")).toEqual(jsonUtil.getValue(dataLakeObject, "Encryption Type"));
            inventoryPage.closeViewDetailsTab();
            //Checking SOI Components
            if (isDummyAdapterDisabled == "true") {
                inventoryPage.clickExpandFirstRow().then(function () {
                    browser.executeScript('window.scrollTo(0,0);');
                    var i = 1;
                    async.forEachSeries(SOIComponents, function (component, callback) {
                        inventoryPage.clickOverMenuIcon(i).then(function () {
                            inventoryPage.clickOnViewComponent(i).then(function () {
                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                expect(inventoryPage.getTagsOnInventory()).toContain(dataLakeObject.mcmpTag);
                                expect(inventoryPage.getTagsOnInventory()).toContain(dataLakeObject.bluePrintName);
                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                inventoryPage.closeViewComponent();
                                browser.sleep(10000);
                                i++;
                                return callback();
                            });
                        })
                    }, function (error) {
                        if (error) {
                            logger.info('Unable to Get SOI component')
                        }
                    })
                })
            }
            // check Non-Editable service Message
            inventoryPage.clickNonEditableInstance();
            expect(inventoryPage.getTextForInvalidEditModal()).toEqual(DataLakeStorageTemplate.nonEditableText);
            inventoryPage.clickOnInvalidEditOkModal();
        });
    }
});
