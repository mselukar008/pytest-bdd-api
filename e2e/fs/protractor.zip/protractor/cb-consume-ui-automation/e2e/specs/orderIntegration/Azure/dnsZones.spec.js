/*
Spec_Name: dnsZone.spec.js 
Description: This spec will cover E2E testing of DNS Zone service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../../testData/appUrls.json'),
        util = require('../../../../helpers/util.js'),
        jsonUtil = require('../../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        DZTemplate = require('../../../../testData/OrderIntegration/Azure/DnsZone.json');

describe('Azure - DNS Zone', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage, parentdns;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Network' };
        var servicename = "AutoDNSsrv" + util.getRandomString(5);
        var rgName = "gslautotc_azureDNS-RG101" + util.getRandomString(5);
        var dnsName = "autodns.new" + util.getRandomString(5);
        var recordset = "autorecordsetnew" + util.getRandomString(5);
        parentdns = dnsName + " ( " + rgName + " )";
        var returnObj = {};
        returnObj.parentdns = parentdns;
        returnObj.existingrgName = rgName;
        returnObj.recordset = recordset;
        var SOIComponents;
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "DNS Zone Name": dnsName };

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                catalogDetailsPage = new CatalogDetailsPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
                SOIComponents = [dnsName]
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "DNS Zone Name": dnsName };
        });

        afterAll(function () {
                // Delete DNS Zone
                var returnObj = {};
                returnObj.servicename = servicename;
                returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                orderFlowUtil.approveDeletedOrder(returnObj);
                orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        });

          //Checking parameters on Main Parameters page
          it('Azure: TC-T386494 verify that for DNS Zone Service all parameters on Main Parameters Page are present.', function () {
                var orderObject = JSON.parse(JSON.stringify(DZTemplate.parent));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
                if (browser.params.defaultCurrency == "USD") {
                        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
                }
        });
        //Checking values all parameters on Review Order Page and View Order Details
        it('Azure: TC-T386496 verify that for DNS Zone Service all values on Review Order Page and View Order Details page matches with input.', function () {
                var returnObj = {};
                returnObj.servicename = servicename;
                var orderObject = JSON.parse(JSON.stringify(DZTemplate.parent));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(DZTemplate.parent, modifiedParamMap);
                //Checking Service Details in ReviewOrder
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
                if (browser.params.defaultCurrency == "USD") {
                        expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
                }
                //Checking Additional Details in ReviewOrder
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" DNS Zone Name:")).toEqual(dnsName);
                placeOrderPage.submitOrder();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                ordersPage.open();
                ordersPage.searchOrderById(returnObj.orderNumber);
                ordersPage.clickFirstViewDetailsOrdersTable();
                //Checking Order Details in View order details
                expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
                //Checking Service Configuration Parameters
                ordersPage.clickServiceConfigurationsTabOrderDetails();
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
                expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("DNS Zone Name")).toEqual(dnsName);
                //Checking Bill Of Material
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                if (browser.params.defaultCurrency == "USD") {
                        expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
                }
                ordersPage.clickServiceDetailSliderCloseButton();
        });

        //E2E DNS Zone order Submit, Approve, Delete Service with New Resource Group.
        if (isProvisioningRequired == "true") {
                it('Azure: TC-T386503 Verify if create new DNS Zone with New Resource Group is working fine.', function () {
                        var orderObject = JSON.parse(JSON.stringify(DZTemplate.parent));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};
                        orderFlowUtil.fillOrderDetails(DZTemplate.parent, modifiedParamMap);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Checking Inventory Page Service Configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" DNS Zone Name:")).toEqual(dnsName);
                        inventoryPage.closeViewDetailsTab();
                        //Checking SOI Components
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.viewSOIComponents(SOIComponents,orderObject);
                        }
                     // check Non-Editable service Message
                     inventoryPage.clickNonEditableInstance();
                     expect(inventoryPage.getTextForInvalidEditModal()).toEqual(DZTemplate.parent.nonEditableText);
                     inventoryPage.clickOnInvalidEditOkModal();
                });
        }

        if (isDummyAdapterDisabled == "true") {
                //Verify if Child DNS Zone of an existing zone already hosted in Azure is created successfully.
                it('Azure: Verify if Child DNS Zone of an existing zone already hosted in Azure is created successfully.', function () {
                        var orderObject = JSON.parse(JSON.stringify(DZTemplate.child));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var modifiedParamMap1 = {};
                        var returnObj = {};
                        returnObj.parentdns = parentdns.toLowerCase();
                        logger.info("The parent dns value is: "+returnObj.parentdns)
                        rgName = "gslautotc_azureDNS-RG101" + util.getRandomString(5);
                        modifiedParamMap1 = { "Service Instance Name": servicename, "New Resource Group": rgName, "Parent Zone Name": returnObj.parentdns };
                        orderFlowUtil.fillOrderDetails(DZTemplate.child, modifiedParamMap1);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Checking Inventory Page Service Configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" DNS Zone Name:")).toEqual(dnsName);
                        inventoryPage.closeViewDetailsTab();
                        //Checking SOI Components
                        inventoryPage.viewSOIComponents(SOIComponents);
                });

                //Verify that Record Set Type as Alias record to IPv6 Address is successfully created.
                it('Azure: Verify that Record Set Type as Alias record to IPv6 Address is successfully created.', function () {
                        // modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Parent Zone Name": dnsName };
                        var orderObject = JSON.parse(JSON.stringify(DZTemplate.recordset));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};
                        var modifiedParamMap2 = {};
                        returnObj.existingrgName = rgName;
                        returnObj.parentdns = parentdns.toLowerCase();
                        returnObj.recordset = recordset;
                        returnObj.servicename = servicename;
                        logger.info("The exiting resource group is : " + returnObj.existingrgName);
                        logger.info("The new record set name is : " + returnObj.recordset);
                        modifiedParamMap2 = { "Service Instance Name": returnObj.servicename, "Existing Resource Group": returnObj.existingrgName, "Record Set Name": returnObj.recordset };
                        logger.info("The modifiedParamMap is : " + modifiedParamMap2["Record Set Name"]);
                        orderFlowUtil.fillOrderDetails(DZTemplate.recordset, modifiedParamMap2);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal(); 
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Checking Inventory Page Service Configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" DNS Zone Name:")).toEqual(dnsName);
                        inventoryPage.closeViewDetailsTab();
                        //Checking SOI Components
                        inventoryPage.viewSOIComponents(SOIComponents);
                });
        }

});