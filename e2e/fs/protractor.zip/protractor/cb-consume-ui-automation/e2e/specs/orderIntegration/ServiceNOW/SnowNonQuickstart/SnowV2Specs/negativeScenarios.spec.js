"use strict";

const { browser } = require('protractor');

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	OrderHistoryPage = require('../../../../../pageObjects/ordersHistory.pageObject.js'),
	AccountsPage = require('../../../../../pageObjects/account.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	vRACentOS76Temp = require('../../../../../../testData/OrderIntegration/ServiceNOW/CloneCentOS76Snow.json'),
	awsS3Temp = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSS3Snow.json'),
	gcpPubSubTemplate = require('../../../../../../testData/OrderIntegration/Google/pubsub.json'),
	slSecurityGrpTemplate = require('../../../../../../testData/OrderIntegration/Softlayer/SecurityGroupService.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json'),
	credentialsTemplate = require('../../../../../../testData/credentials.json');
	
describe('Test cases for Negative Scenarios', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, sampleOrder1, instName, provOrder, inventoryPage, orderHistoryPage, accountsPage, cartListPage, serviceName;
	var modifiedParamMap = {};
	var modifiedParamMapRetry = {};
	var modifiedParamMapGoogle = {};
	var modifiedParamMapSL = {};
	var topicName = "autom-" + util.getRandomString(5).toLowerCase();
	var secGrpName = "SNOWsecGrp"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		orderHistoryPage = new OrderHistoryPage();
		accountsPage = new AccountsPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		serviceName = "SNOWauto"+util.getRandomString(5);
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":""};
		modifiedParamMapRetry = { "Service Instance Name": serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "Provider Account":"VRA76Retry / VRA76Retry"};
		modifiedParamMapGoogle = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"","Name": topicName};
		modifiedParamMapSL = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "Provider Account":"SL-Testing / SL-Testing", "Security Group Name":secGrpName};

	});
	
	if(isProvisioningRequired == "true") {
		it('Deny the vRA order approval in Marketplace and verify the status', function () {
			
			//Enable Ext App False with Change Type Normal
			expect(snowAPI.disableExternalApprovalSnow()).toBe(snowInstanceTemplate.snowAPIResult);
			expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			
			//Deny the approval in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.denyOrderFinanciallyAndTechnically(orderObject, "Test");
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.rejectedState);
			
			//Validations on SNOW Request page after denying
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestRejectedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	    });	

		it('Cancel the vRA Order in Marketplace before approval and verify the status', function () {
			
			//Enable Ext App True with Change Type Normal
			expect(snowAPI.enableExternalApprovalSnow()).toBe(snowInstanceTemplate.snowAPIResult);
			expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequested();
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			
			//Cancel the order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderHistoryPage.searchOrderClickCancelOrder(orderObject.orderNumber);
			orderHistoryPage.clickCancelOrderConfirmationButton();
			expect(orderHistoryPage.getTextCancelOrderSuccessFulMsg()).toContain(vRACentOS76Temp.cancelOrderSuccessMsg);
			orderHistoryPage.clickCancelOrderOkButton();
			expect(orderHistoryPage.getTextCancelOrderStatusInOrderHistory()).toContain(vRACentOS76Temp.cancelledStatus);
			
			//Validations on SNOW Request page after cancelling
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestStateCancelled);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.cancelledStatus);
	    });	
		
		it('Reject the vRA order approval in SNOW at Request level and verify the status', function () {
			
			//Enable Ext App True with Change Type Normal
			expect(snowAPI.enableExternalApprovalSnow()).toBe(snowInstanceTemplate.snowAPIResult);
			expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequested();
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			
			//Reject the approval in SNOW
			snowPage.rejectTheServiceNowRequestFromSnowPortal();
			
			//Validations on SNOW Request page after rejecting
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getTextRequestedStateAfterFirstApproval()).toBe(snowInstanceTemplate.snowRequestIncompleteStateQS);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	
			
			//Validate in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.rejectedState);
	    });	
		
		it('Reject the vRA order approval in SNOW at Change Request level and verify the status', function () {
			
			//Enable Ext App True with Change Type Normal
			expect(snowAPI.enableExternalApprovalSnow()).toBe(snowInstanceTemplate.snowAPIResult);
			expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequested();
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			
			//Validations on SNOW Request page after first approval
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			snowPage.waitUntilApprovalIsReqExtAppTrue();
			expect(snowPage.getTextApprovalAfterFirstApproval()).toBe(snowInstanceTemplate.snowReqStateApproved);
			expect(snowPage.getTextRequestedStateAfterFirstApproval()).toBe(snowInstanceTemplate.snowReqStageInProcess);
			expect(snowPage.getTextStageAfterFirstApproval()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			
			//Reject the approval in SNOW
			snowPage.clickRequestedItemLink();
			snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.openRelatedChangeRequest();
			snowPage.rejectChangeRequest();
			//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateNew);
			
			//Validations on SNOW Requested Item page after rejecting
			snowPage.clickBackButton();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	
			
			//Validation on Catalog Task page after rejecting
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickUpdateButton();
			
			//Validations on SNOW Request page after rejecting
			snowPage.clickBackButton();
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);			
			
			//Validate in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(snowInstanceTemplate.snowChangeTaskStateCancelled);
	    });	
		
		it('Place a vRA order by not uploading custom policy for vRA', function () {
			
			//Enable Ext App True with Change Type Normal
			expect(snowAPI.enableExternalApprovalSnow()).toBe(snowInstanceTemplate.snowAPIResult);
			expect(snowAPI.setCustomPolicyForAzureAWSNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			browser.sleep(5000);
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.rejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.rejectedState);
			
			//Verify in SNOW
            snowPage.logInToSnowDropletPortalAndSearchOrderNotExists(provOrder);
			expect(snowPage.getTextOrderNotExists()).toBe(snowInstanceTemplate.orderNotExistsMessage);	 
		});
		
		it('Place a Google order by not uploading custom policy for Google', function () {
			
			//Enable Ext App True with Change Type Normal
			expect(snowAPI.enableExternalApprovalSnow()).toBe(snowInstanceTemplate.snowAPIResult);
			expect(snowAPI.setCustomPolicyForAzureAWSNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(gcpPubSubTemplate.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(gcpPubSubTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(gcpPubSubTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(gcpPubSubTemplate, modifiedParamMapGoogle);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(gcpPubSubTemplate.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":sampleOrder1};	
			browser.sleep(3000);
			orderFlowUtil.waitForOrderStatusChange(orderObject,gcpPubSubTemplate.orderRejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(gcpPubSubTemplate.orderRejectedState);
			
			//Verify in SNOW
            snowPage.logInToSnowDropletPortalAndSearchOrderNotExists(sampleOrder1);
			expect(snowPage.getTextOrderNotExists()).toBe(snowInstanceTemplate.orderNotExistsMessage);	 
		});
		
		it('Place an IBM Cloud order by not uploading custom policy for IBM Cloud', function () {
			
			//Enable Ext App True with Change Type Normal
			expect(snowAPI.enableExternalApprovalSnow()).toBe(snowInstanceTemplate.snowAPIResult);
			expect(snowAPI.setCustomPolicyForAzureAWSNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":sampleOrder1};	
			browser.sleep(3000);
			orderFlowUtil.waitForOrderStatusChange(orderObject,slSecurityGrpTemplate.rejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(slSecurityGrpTemplate.rejectedState);
			
			//Verify in SNOW
            snowPage.logInToSnowDropletPortalAndSearchOrderNotExists(sampleOrder1);
			expect(snowPage.getTextOrderNotExists()).toBe(snowInstanceTemplate.orderNotExistsMessage);	 
		});
		
		it('Fail the VRA order, Retry and when retry fails again cancel the order', function () {
			
			//Enable Ext App True with Change Type Normal
			expect(snowAPI.enableExternalApprovalSnow()).toBe(snowInstanceTemplate.snowAPIResult);
			expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapRetry);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.appInProgressState);
			
			
			//Validations on SNOW Request page
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequested();
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			
			//Validations on SNOW Request page after first approval
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsS3Temp.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			
			//Approvals in SNOW
			snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.openRelatedChangeRequest();
			snowPage.approveChangeRequestForEachState();
			snowPage.approveChangeRequestForEachState();
			
			/*//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsS3Temp.provInProgressState);*/
			
			//Order Completion in SNOW
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsS3Temp.failedState);
			
			//Validations in SNOW after provision failed
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			snowPage.openRelatedChangeRequest();
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextChangeTaskFirstActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);			
			snowPage.openIncident();
			expect(snowPage.getTextIncidentState()).toBe(snowInstanceTemplate.snowIncidentStateInProg);
			expect(snowPage.getTextIncAssignmentGroup()).toBe(snowInstanceTemplate.snowIncidentAssignGrp);
			expect(snowPage.getTextIncShortDesc()).toBe(snowInstanceTemplate.snowChangeTaskActivity);
			expect(snowPage.getTextChangeTaskFirstActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);
			
			//Retry the order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderHistoryPage.searchOrderClickRetry(provOrder);
	        expect(orderHistoryPage.verifyOrderTableActionsRetryModelSuccessMsgVisibility()).toMatch(awsS3Temp.retrySuccessMsg);
	        orderHistoryPage.clickOnOrderTableActionsRetryModelOkButton();
	        orderFlowUtil.waitForOrderStatusChange(orderObject,awsS3Temp.failedState);
	        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsS3Temp.failedState);
	        
	        //Validations in SNOW after provision failed again
	        snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskSecondActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);
			snowPage.openIncident();
			expect(snowPage.getTextChangeTaskSecondActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);
			
			//Cancel the order in Marketplace	
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderHistoryPage.searchOrderClickCancel(provOrder);
			expect(orderHistoryPage.getTextCancelOrderSuccessFulMsg()).toMatch(vRACentOS76Temp.cancelFailedOrderSuccessMsg);
			orderHistoryPage.clickOnOrderTableActionsCancelModelOkButton();
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsS3Temp.cancelledStatus);
			
			//Validations in SNOW after order is cancelled
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			snowPage.openRelatedChangeRequest();
			snowPage.clickChangeTaskTabInChangeRequest();
			snowPage.waitForProvisioningTaskChange(snowInstanceTemplate.snowChangeTaskStateCancelled);
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskState()).toBe(snowInstanceTemplate.snowChangeTaskStateCancelled);
			snowPage.clickBackButton();
			
			//Order Completion in SNOW
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.selectChangeReqState(snowInstanceTemplate.snowChangeRequestStateClose);
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			browser.sleep(5000);
			snowPage.clickBackButton();
			snowPage.clickBackButton();
			
			//Validations in SNOW after order is closed
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickUpdateButton();
			snowPage.openRelatedChangeRequest();
			snowPage.openChangeTask();
			snowPage.openIncident();
			expect(snowPage.getTextIncidentState()).toBe(snowInstanceTemplate.snowIncidentStateResolved);
			expect(snowPage.getTextIncShortDesc()).toBe(snowInstanceTemplate.snowIncidentShortDescCancelled);
			snowPage.clickIncResolutionInfoTab();
			expect(snowPage.getTextIncResCode()).toBe(snowInstanceTemplate.snowIncidentResCodeNotSolved);
			expect(snowPage.getTextIncResNotes()).toBe(snowInstanceTemplate.snowIncidentResNotesNotsolved);
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);		
	    });	
	
		
		it('Place an order in Marketplace from NON-SNOW user and verify the status', function () {
			
			//Enable Ext App True with Change Type Normal
			expect(snowAPI.enableExternalApprovalSnow()).toBe(snowInstanceTemplate.snowAPIResult);
			expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Login with non-snow user
			var orderObject = {};
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(credentialsTemplate.superUserID, credentialsTemplate.superUserPassword);
			
	        //Place an order in Marketplace 
	        catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.rejectedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.rejectedState);
			
			//Verify in SNOW
			snowPage.logInToSnowDropletPortalAndSearchOrderNotExists(provOrder);
			expect(snowPage.getTextOrderNotExists()).toBe(snowInstanceTemplate.orderNotExistsMessage);
			
			//Login with Super user
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			cartListPage.clickUserIcon();
	        cartListPage.clickLogoutButton();
	        //browser.sleep(5000);
	        //cartListPage.loginFromOtherUser(credentialsTemplate.transferCartUser, credentialsTemplate.transferCartPwd);
	    });	
		
		
		it('Place an order in Marketplace from SNOW user without manager- Auto approval and verify the status', function () {
			
			//Enable Ext App True with Change Type Standard
			expect(snowAPI.enableExternalApprovalSnow()).toBe(snowInstanceTemplate.snowAPIResult);
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Login with non-snow user
			var orderObject = {};
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.nonSNOWUser,snowInstanceTemplate.nonSNOWUserPwd);
	        //cartListPage.loginFromOtherUser(credentialsTemplate.snowAutoApproveUser, credentialsTemplate.snowAutoApprovePwd);
	        
	        //Place an order in Marketplace 
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(gcpPubSubTemplate.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(gcpPubSubTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(gcpPubSubTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(gcpPubSubTemplate, modifiedParamMapGoogle);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(gcpPubSubTemplate.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":sampleOrder1};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,gcpPubSubTemplate.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(gcpPubSubTemplate.provInProgressState);
			
			//Validations in SNOW after auto approval
			snowPage.logInToSnowDropletPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.openRelatedChangeRequest();
			expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.clickBackButton();
			
			//Order Completion in SNOW
			snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
			
			//Validations in SNOW after order completion
			snowPage.logInToSnowDropletPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(gcpPubSubTemplate.completedState);
			
			//Login with Super user
			cartListPage.clickUserIcon();
	        cartListPage.clickLogoutButton();
	        //browser.sleep(5000);
	        //cartListPage.loginFromOtherUser(credentialsTemplate.superUserID, credentialsTemplate.superUserPassword);
	    });	
	 }
});
	
	
	
	