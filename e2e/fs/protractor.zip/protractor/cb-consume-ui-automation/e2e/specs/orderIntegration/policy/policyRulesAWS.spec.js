/*************************************************
	AUTHOR: Mahendra
 **************************************************/

"use strict";

var OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	PolicyPage = require('../../../pageObjects/policy.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	budgetaryFlow = require('../../../../helpers/budgetaryFlow.js'),
	budgetDeleteApi = require('../../../../helpers/budgetDeleteApiUtil.js'),
	BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),
	centOs66VRA74Template = require('../../../../testData/OrderIntegration/VRA/CentOs66VRA74.json'),
	policyTemplate = require('../../../../testData/OrderIntegration/policy/policy.json'),
	addRulePolicyTemplate = require('../../../../testData/OrderIntegration/policy/addRulePolicy.json'),
	credentailsTemplate = require('../../../../testData/credentials.json'),
	ec2InstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSEC2Instance.json'),
	snsInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSSNSInstance.json'),
	budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
	budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryAddNewBudgetDetails.json');

describe('Tests for Amazon Policy Rule Validations:', function () {
	var ordersPage, catalogPage, budgetaryUnitCode, placeOrderPage, policyPage, policyName, policyRule1, policyRule2, serviceName1, serviceName2,serviceName3, policyUpdateSuccessMsg, policyDeleteSuccessMsg, cartListPage, budgetryPage, budgetaryName, budgetaryNewBudgetName, topicName1, topicName2;
	var modifiedParamMap = {};
	var modifiedParamMapAddRule = {};
	var modifiedParamMapBudget = {};
	var modifiedNewBudgetParamMap = {};
	var messageStrings = {
		providerName: "Amazon",
		estimatedPrice: ec2InstanceTemplate.estimatedPrice,
		orderSubmittedConfirmationMessage: centOs66VRA74Template.orderSubmittedConfirmationMessage,
		providerAccount: ec2InstanceTemplate.providerAccount,
		calculatedEstAmount: ec2InstanceTemplate.calculatedEstAmount,
		budgetSpendAmmount: ec2InstanceTemplate.budgetSpendAmmount,
		completed: "Completed",
		policyUpdateSuccessMsg: policyTemplate.updatePolicySuccessMsg,
		policyDeleteSuccessMsg: policyTemplate.deletePolicySuccessMsg,
		superUserUsername: credentailsTemplate.superUserID,
		superUserPassword: credentailsTemplate.superUserPassword,
		policyRetiredStatus: policyTemplate.retiredPolicyStatus,
		policyActiveStatus: policyTemplate.policyActiveStatus,
		budgetaryUnitDeletedApiSucessMsg: budgetaryUnitDetailsTemplate.budgetaryUnitDeletedApiSucessMsg,
		budgetDeletedApiSucessMsg: budgetaryUnitDetailsTemplate.budgetDeletedApiSucessMsg,
		budgetaryUnitDeleteSuccessMsg:budgetaryUnitDetailsTemplate.budgetaryUnitDeleteSuccessMsg
	};

	beforeAll(function () {
		ordersPage = new OrdersPage();
		policyPage = new PolicyPage();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		budgetryPage = new BudgetaryPage();
		browser.driver.manage().window().maximize();
		serviceName1 = "awspolicyautoEC2" + util.getRandomString(5);
		serviceName2 = "awspolicyautoSNS" + util.getRandomString(5);
		serviceName3 = "awspolicyautoSNS" + util.getRandomString(5);
		topicName1 = "awsrulePolicytopic-" + util.getRandomString(4);
		topicName2 = "awsrulePolicytopic-" + util.getRandomString(4);
		policyName = "awspolicy" + util.getRandomString(4);
		policyRule1 = "RULE1" + util.getRandomString(4);
		policyRule2 = "RULE2" + util.getRandomString(4);
		modifiedParamMap = { "policy Name": policyName, "Choose Entity": "Team", "Entity Value": "policyTEAM1", "Environment": "awsPolicyEnv", "Application": "awsPolicyApp" };
		modifiedParamMapAddRule = { "Add Rule Name": policyRule1, "Order Type": ["New","Deleted"], "Provider": [messageStrings.providerName], "Total Monthly Cost": "Less than", "Monthly Cost": "40", "Budget Is": "Available", "financial": "Manual Approval" };
		budgetaryName = "awsPolicyBudgetName" + util.getRandomString(8);
		//budgetaryName = "awsPolicyBudgetName9XVJwOnO";		
		budgetaryNewBudgetName = "awsPolicyNewBudgetName" + util.getRandomString(8);
		budgetaryUnitCode = "awsPolicybudgetaryUnitCode" + util.getRandomString(8);
		modifiedParamMapBudget = { "budgetary Name": budgetaryName, "budgetary unit code": budgetaryUnitCode, "Choose Entity": "Team", "Entity Value": "policyTEAM1 (MYORG)", "Application": "awsPolicyApp", "Environment": "awsPolicyEnv" };
	});

	beforeEach(function () {
		//Make sure that super user is logged in
		orderFlowUtil.closeHorizontalSliderIfPresent();
		//catalogPage.open();		
		// catalogPage.getUserID(credentailsTemplate.superUserName).then(function (status) {
		// 	if (status != true) {
		// 		cartListPage.clickUserIcon();
		// 		cartListPage.clickLogoutButton();
		// 		cartListPage.loginFromOtherUser(messageStrings.superUserUsername, messageStrings.superUserPassword);
		// 		catalogPage.open();
		// 		expect(catalogPage.getUserID(credentailsTemplate.superUserName)).toBe(true);
		// 	}
		// });
	});	

	it('Add New Policy with multiple rules', function () {
		//modifiedParamMap = { "policy Name": policyName, "Choose Entity": "Organization", "Entity Value": "MYORG", "Environment": "awsPolicyEnv", "Application": "awsPolicyApp" };
		modifiedParamMap = { "policy Name": policyName, "Choose Entity": "Organization", "Entity Value": "MYORG", "Environment": "awsPolicyEnv", "Application": "awsPolicyApp", "Add Rule":"", "Entity checkBox":"" };
		catalogPage.getUserID(credentailsTemplate.superUserName).then(function (status) {
			if (status != true) {
				cartListPage.clickUserIcon();
				cartListPage.clickLogoutButton();
				cartListPage.loginFromOtherUser(messageStrings.superUserUsername, messageStrings.superUserPassword);
				catalogPage.open();
				expect(catalogPage.getUserID(credentailsTemplate.superUserName)).toBe(true);
			}
		});

		policyPage.open();
		policyPage.clickAddNewPolicyBtn();
		policyPage.selectStartDate();
		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMap);
		policyPage.clickAddNewPolicyRuleBtn();
		//Add Rule 1
		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
		policyPage.clickApplyRulePolicyBtn();
		//Commenting below validation since notification pop up disaperas immidiately. 
		//Will uncomment it once 1defect is resolved.
		//expect(policyPage.getSuccessMsgForRule()).toContain(policyRule + " has been created.");
		var policyRuleNameTextInApprovalPolicy = policyPage.getTextRuleNameInApprovalPolicyPage(policyRule1);
		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRule1);
		//Add Rule 2
		//var rule2 = "RULE2" + util.getRandomString(4);
		modifiedParamMapAddRule = { "Add Rule Name": policyRule2, "Order Type": ["New","Deleted"], "Provider": [messageStrings.providerName], "Total Monthly Cost": "Less than", "Monthly Cost": "60", "Budget Is": "Not Applicable", "financial": "Auto Approve" };
		policyPage.clickAddNewPolicyRuleBtn();
		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
		policyPage.clickApplyRulePolicyBtn();
		//expect(policyPage.getSuccessMsgForRule()).toContain(rule2 + " has been created.");
		browser.sleep(2000);
		
		var policyRuleName2TextInApprovalPolicy = policyPage.getTextRuleNameInApprovalPolicyPage(policyRule2);
		expect(policyRuleName2TextInApprovalPolicy).toEqual(policyRule2);
		policyPage.clickCreatePolicyButton();
		var policyNameInPolicyTable = policyPage.getTextPolicyNameInPolicyTable(policyName);
		expect(policyNameInPolicyTable).toEqual(policyName);
	});

	it('Add new budgetry Unit for E2E budget Flow ', function () {		
		budgetryPage.open();    		
		budgetryPage.clickOnAddNewBudgetryUnitBtn();
		budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMapBudget);
		budgetryPage.clickOnBudgetrySaveBtn();
		budgetryPage.clickOnBudgetryBudgetsLink();
		budgetryPage.clickOnBudgetaryAddBudgetButton();
		var startPeriod = budgetaryFlow.incrementMonth(0); //Zero (0) for current month		
		//modifiedNewBudgetParamMap = { "Name": budgetaryNewBudgetName, "Soft Quota Threshold txt": "70", "Hard Quota Threshold txt": "70", "Start Period": startPeriod };
		modifiedNewBudgetParamMap = { "Name": budgetaryNewBudgetName, "Start Period": startPeriod, "Soft Quota Threshold txt": "70", "Hard Quota Threshold txt": "70","Notify When Soft Quota reached": "policyTEAM1", "Notify When Hard Quota reached": "policyTEAM1" };
		budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);
		budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
		//budgetryPage.clickOnBudgetaryBackBudgetButton();
		//browser.sleep(6000);
		budgetryPage.clickBudgetSliderCloseButton();
	});

	it('Amazon - AWS EC2 - Verify the Policy Auto-Approval/Manual Approval rule', function () {
		var orderObject = {};
		var groupName = "att-group-" + util.getRandomString(5);

		modifiedParamMap = { "Service Instance Name": serviceName1, "Team": "policyTEAM1", "Environment": "awsPolicyEnv", "Application": "awsPolicyApp", "Provider Account": "", "Group Name": groupName };
		// Logout from Super User
		cartListPage.clickUserIcon();
		cartListPage.clickLogoutButton();
		//browser.sleep(5000);
		// Login as User with Buyer role and place order
		cartListPage.loginFromOtherUser(credentailsTemplate.policyBuyerUserID, credentailsTemplate.policyBuyerUserPassword);
		catalogPage.open();
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(ec2InstanceTemplate.Category);
		catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);
		orderObject.servicename = serviceName1;
		//Delete Configure IMI Addon object as its not applicale  for cbadmnauto user
		//delete ec2InstanceTemplate["Order Parameters"]["Configure Add-ons"];
		// Submit order through Buyer role user
		orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap).then(async function (requiredReturnMap) {
			placeOrderPage.submitOrder();
			// Get details from popup after submit
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
			//Verify User and order submitted message
			expect(ordersubmittedBy).toEqual(credentailsTemplate.policyBuyerUser);
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			// Logout from Buyer role user
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			// Login as User with Technical Approver role for which orders
			// are AutoApproved and status moved to Approval In Progress
			cartListPage.loginFromOtherUser(credentailsTemplate.technicalApprovalUserID, credentailsTemplate.technicalApprovalUserPass);
			ordersPage.open();
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe("Approval In Progress");
			// Check budget is not displayed since user has Technical Approver role only
			await expect(ordersPage.checkInvisibilityOfBudgetDetails()).toBe(false, "For technically approval role user Budget details is not present on the Approve order page.");
			// Logout from Technical approver user
			//catalogPage.open();
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			//Login as User with Financial Approver role
			cartListPage.loginFromOtherUser(credentailsTemplate.financialApprovalUserID, credentailsTemplate.financialApprovalUserPass);
			ordersPage.open();						
			ordersPage.searchOrderById(orderObject.orderNumber);
            //select Budgetary Unit                        
			ordersPage.selectBudgetaryUnit(budgetaryName);
			util.waitForAngular();
			//Approve Order Financially
			orderFlowUtil.approveOrderFinancially(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completed).then(function () {
				expect(ordersPage.getBudgetNameAllOrdersText()).toBe("Budgetary Unit - " + budgetaryName);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completed);
			});
			
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			// Login with Super User
			cartListPage.loginFromOtherUser(messageStrings.superUserUsername, messageStrings.superUserPassword).then(function(){
				expect(catalogPage.getUserID(credentailsTemplate.superUserName)).toBe(true);
			});			
			
		});
	});

	it('PolicyRules - AWS SNS -  Verify the Policy Auto-Approval/Manual Approval rule', function () {

		var orderObject = {};
		modifiedParamMap = { "Service Instance Name": serviceName2, "Team": "policyTEAM1", "Environment": "awsPolicyEnv", "Application": "awsPolicyApp", "Provider Account": "", "Topic Name" : topicName1};
		// Logout from Super User
		cartListPage.clickUserIcon();
		cartListPage.clickLogoutButton();
		browser.sleep(5000);
		// Login as User with Buyer role and place order
		cartListPage.loginFromOtherUser(credentailsTemplate.policyBuyerUserID, credentailsTemplate.policyBuyerUserPassword);
		catalogPage.open();
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(snsInstanceTemplate.Category);
		catalogPage.clickConfigureButtonBasedOnName(snsInstanceTemplate.bluePrintName);
		orderObject.servicename = serviceName2;
		orderFlowUtil.fillOrderDetails(snsInstanceTemplate, modifiedParamMap).then(async function (requiredReturnMap) {
			placeOrderPage.submitOrder();
			// Get details from popup after submit
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
			//Verify User and order submitted message
			expect(ordersubmittedBy).toEqual(credentailsTemplate.policyBuyerUser);
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			// Logout from Buyer role user
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			// Login as User with Technical Approver role for which orders
			// are AutoApproved and status moved to Approval In Progress
			cartListPage.loginFromOtherUser(credentailsTemplate.technicalApprovalUserID, credentailsTemplate.technicalApprovalUserPass);
			ordersPage.open();
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe("Approval In Progress");
			// Check budget is not displayed since user has Technical Approver role only
			await expect(ordersPage.checkInvisibilityOfBudgetDetails()).toBe(false, "For technically approval role user Budget details is not present on the Approve order page.");
			// Logout from Technical approver user
			//catalogPage.open();
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			//Login as User with Financial Approver role
			cartListPage.loginFromOtherUser(credentailsTemplate.financialApprovalUserID, credentailsTemplate.financialApprovalUserPass);
			ordersPage.open();
			//Approve Order Financially			
			//select Budgetary Unit
			ordersPage.searchOrderById(orderObject.orderNumber);
            //select Budgetary Unit                        
			ordersPage.selectBudgetaryUnit(budgetaryName);
			util.waitForAngular();
			orderFlowUtil.approveOrderFinancially(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completed).then(function () {
				expect(ordersPage.getBudgetNameAllOrdersText()).toBe("Budgetary Unit - " + budgetaryName);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completed);
			});
			
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			
			cartListPage.loginFromOtherUser(messageStrings.superUserUsername, messageStrings.superUserPassword).then(function(){
				expect(catalogPage.getUserID(credentailsTemplate.superUserName)).toBe(true);
			});
		});
	});

	it('Change Ranking of Rules in Policy', function () {
		
		ordersPage.open();
		catalogPage.getUserID(credentailsTemplate.superUserName).then(function (status) {
			if (status != true) {
				cartListPage.clickUserIcon();
				cartListPage.clickLogoutButton();				
				cartListPage.loginFromOtherUser(messageStrings.superUserUsername, messageStrings.superUserPassword);
				catalogPage.open();
				expect(catalogPage.getUserID(credentailsTemplate.superUserName)).toBe(true);
			}
		});
		policyPage.open();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		policyPage.clickRankingDropdown();		
		policyPage.clickUpdatePolicyBtn();
		//Verify Sucees message
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.policyUpdateSuccessMsg + " " + policyName + " successfully");
		policyPage.searchPolicyInPolicyTextbox(policyName);		
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		//Validate sequence of rule has been changed
		expect(policyPage.getRuleNameFromRankingTable()).toEqual(policyRule1);
	});

	it('PolicyRules - AWS SNS -  Verify the Policy Auto-Approval/Auto Approval rule', function () {
		var orderObject = {};
		modifiedParamMap = { "Service Instance Name": serviceName3, "Team": "policyTEAM1", "Environment": "awsPolicyEnv", "Application": "awsPolicyApp", "Provider Account": "", "Topic Name" : topicName2};
		//modifiedParamMap = { "Service Instance Name": serviceName3, "Team": "policyTEAM1", "Environment": "awsPolicyEnv", "Application": "awsPolicyApp", "Provider Account": "" };
		// Logout from Super User
		//catalogPage.open();
		ordersPage.open();
		cartListPage.clickUserIcon();
		cartListPage.clickLogoutButton();
		browser.sleep(5000);
		// Login as User with Buyer role and place order
		cartListPage.loginFromOtherUser(credentailsTemplate.policyBuyerUserID, credentailsTemplate.policyBuyerUserPassword);
		catalogPage.open();
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(snsInstanceTemplate.Category);
		catalogPage.clickConfigureButtonBasedOnName(snsInstanceTemplate.bluePrintName);
		orderObject.servicename = serviceName3;

		orderFlowUtil.fillOrderDetails(snsInstanceTemplate, modifiedParamMap).then(async function (requiredReturnMap) {
			placeOrderPage.submitOrder();
			// Get details from popup after submit
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
			//Verify User and order submitted message
			expect(ordersubmittedBy).toEqual(credentailsTemplate.policyBuyerUser);
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			// Logout from Buyer role user
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			// Login as User with Technical Approver role for which orders
			// are AutoApproved and status moved to Provisioning In Progress/Completed
			cartListPage.loginFromOtherUser(credentailsTemplate.technicalApprovalUserID, credentailsTemplate.technicalApprovalUserPass);
			ordersPage.open();
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completed);//.then(async function () {
				// Check budget is not displayed since user has Technical Approver role only
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completed);
				await expect(ordersPage.checkInvisibilityOfBudgetDetails()).toBe(false, "For technically approval role user Budget details is not present on the Approve order page.");
				
			//});

			// Logout from Technical approver user
			//catalogPage.open();			
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			//Login as User with Financial Approver role
			cartListPage.loginFromOtherUser(credentailsTemplate.financialApprovalUserID, credentailsTemplate.financialApprovalUserPass);
			ordersPage.open();
			//Verify Order status is completed as per RULE 2			
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completed).then(function () {
				//Budget should be displayed
				expect(ordersPage.getBudgetNameAllOrdersText()).toBe("Budgetary Unit - " + budgetaryName);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completed);
			});
			
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			// Login with Super User			
			cartListPage.loginFromOtherUser(messageStrings.superUserUsername, messageStrings.superUserPassword).then(function(){
				expect(catalogPage.getUserID(credentailsTemplate.superUserName)).toBe(true);
			});
		});
	});

	it('Delete the created policy', function () {
		catalogPage.getUserID(credentailsTemplate.superUserName).then(function (status) {
			if (status != true) {
				cartListPage.clickUserIcon();
				cartListPage.clickLogoutButton();
				cartListPage.loginFromOtherUser(messageStrings.superUserUsername, messageStrings.superUserPassword);
				catalogPage.open();
				expect(catalogPage.getUserID(credentailsTemplate.superUserName)).toBe(true);
			}
		});
		policyPage.open();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		policyPage.clickRadioButtonRetiredOption();
		policyPage.clickUpdatePolicyBtn();
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.policyUpdateSuccessMsg + " " + policyName + " successfully");
		var policyStatusInPolicy = policyPage.getTextPolicyStatusInPolicyTable(policyName);
		expect(policyStatusInPolicy).toEqual(messageStrings.policyRetiredStatus);
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickButtonDeletePolicyText();
		policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		util.waitForAngular();
		policyPage.clickNotificationCloseButton();
		browser.sleep(2000);
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.policyDeleteSuccessMsg + " " + policyName + " successfully");
	});


	it('PolicyRules - Delete All Services', function () {

		var orderObject = {};
		let PromiseArray = [];	
		
		for (var i = 1; i <=3; i++){
		
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();	
			// Login as User with Buyer role
			cartListPage.loginFromOtherUser(credentailsTemplate.policyBuyerUserID, credentailsTemplate.policyBuyerUserPassword);
			// Place deleteOrder from Buyer role user
			if(i == 1){
				orderObject.servicename = serviceName1;
			}else if(i == 2){
				orderObject.servicename = serviceName2;					
			}else if(i == 3){
				orderObject.servicename = serviceName3;
			}			
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			// Logout from Buyer role user
			catalogPage.open();
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			// Login as User with Financial Approver role to approve deleteOrder
			cartListPage.loginFromOtherUser(credentailsTemplate.financialApprovalUserID, credentailsTemplate.financialApprovalUserPass);
			//orderFlowUtil.approveDeletedOrderFinancially(orderObject);
			//Here order will be provisioned as per rule 2
			ordersPage.open();
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completed);
			// Logout from Financial approver role user
			//browser.ignoreSynchronization = false;
			cartListPage.clickUserIcon();
			cartListPage.clickLogoutButton();
			// Login with Super User
			cartListPage.loginFromOtherUser(messageStrings.superUserUsername, messageStrings.superUserPassword);
			catalogPage.open();
			expect(catalogPage.getUserID(credentailsTemplate.superUserName)).toBe(true);
			PromiseArray.push(true);
		}
	});
		
	

	afterAll(async function () {
		
		catalogPage.getUserID(credentailsTemplate.superUserName).then(function (status) {
			if (status != true) {
				orderFlowUtil.closeHorizontalSliderIfPresent();
				cartListPage.clickUserIcon();				
				cartListPage.clickLogoutButton();
				cartListPage.loginFromOtherUser(messageStrings.superUserUsername, messageStrings.superUserPassword);
				catalogPage.open();
				expect(catalogPage.getUserID(credentailsTemplate.superUserName)).toBe(true);
			}
		});	
		
		budgetryPage.deleteBudget(budgetaryName);

		// budgetryPage.selectCheckBoxBasedOnName(budgetaryName);
		// budgetryPage.clickonDeleteBtnForSelectedItem();
		// budgetryPage.clickOnDeleteConfirmationBtn(3);
		// expect(budgetryPage.getNotificationMsg()).toContain(messageStrings.budgetaryUnitDeleteSuccessMsg);
	});

});		
