"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	OrderHistoryPage = require('../../../../../pageObjects/ordersHistory.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	vRACentOS76Temp = require('../../../../../../testData/OrderIntegration/ServiceNOW/CloneCentOS76Snow.json'),
	shoppingCartTemplate   = require('../../../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json');
	
describe('QS: E2E cases for Homo Cart with two VRA services and Auto, Auto, External approval with Normal change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, provOrder, cartListPage, orderHistoryPage, policyPage;
	var modifiedParamMapVRA = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var orderObject = {};
	var serviceName1 = "SNOWQSauto"+util.getRandomString(5);
	var serviceName2 = "SNOWQSauto"+util.getRandomString(5);
	var policyName = "SNOWQSautoVRAPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWQSautoVRAPolicyRule"+util.getRandomString(5);
	var cartName = "SNOWQSautoCart" + util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var vraCentOSObj = JSON.parse(JSON.stringify(vRACentOS76Temp));

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		orderHistoryPage = new OrderHistoryPage();
		policyPage = new PolicyPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New"],"Provider":["VRA"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
								 "Legal":"External Approval"};
		modifiedParamMapVRA1 = {"Service Instance Name":serviceName1, "Cart Name":cartName, "Cart Service":"checkbox-useShoppingCart", "New Shopping Cart":"newCart", "Team":"Auto-TEAM1", "Environment":"QA", "Application":""};
		modifiedParamMapVRA2 = {"Service Instance Name":serviceName2,"Cart Name": "","Cart Service": "","Team":"","Environment":"","Application":""};
	});
	
	afterAll(function() {
		browser.get(consumeLaunchpadUrl);
		policyPage.open();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		policyPage.clickRadioButtonRetiredOption();
		policyPage.clickUpdatePolicyBtn();
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickButtonDeletePolicyText();
		policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);

	});
	
	it('Set Change Request type to Normal in SNOW', function () {
		expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Auto, Auto, External Approval Policy for VRA provider', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.selectExternalApprovalDropdownSNOW();
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('Place an order for Homo Cart with two VRA services and Auto, Auto, External approval with Normal change', function () {
			
			//Add first VRA service to cart
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName1;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapVRA1);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
			
	        //Add second VRA service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName2;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapVRA2);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
			
			//Submit Order
			cartListPage.submitOrder(0);
	    	orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
	    	orderObject.submittedBy = cartListPage.getTextSubmittedByOrderSubmittedModal
	        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(shoppingCartTemplate.orderSubmittedConfirmationMessage);
	    	provOrder = cartListPage.getTextOrderNumberOrderSubmittedModal();
	        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
	        orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.appInProgressState); 
		
			//Validations on SNOW Request page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
			expect(snowPage.getTextShortDescription()).toBe(cartName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
			expect(snowPage.getCountOfRITMlinks()).toBe(parseInt("2"));
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.provInProgressState);
			
			//Validations on SNOW Request page after approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);
		});
		
		it('Verify the First RITM for Provision functionality with Normal change', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var service = snowPage.getTextReqItemVariableServiceName();
			service.then(function(serviceName) {
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual(jsonUtil.getValue(vraCentOSObj, "Memory (MB)"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual(jsonUtil.getValue(vraCentOSObj, "CPUs"));
				expect(snowPage.getTextReqItemBOMTotalVRA()).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRA);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Normal change
				snowPage.openRelatedChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
				snowPage.enterChangeReqValues();
				snowPage.enterPlanningValues();
				snowPage.enterScheduleValues();
				snowPage.clickCalculateRiskLink();
				snowPage.clickAssessButton();
				
				//Approvals in SNOW
				snowPage.clickRequestApprovalInChangeRequestPage();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveRequestQS();
				snowPage.approveRequestQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				snowPage.rightClickOnCMDBCIFormHeader();
				var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
				sysidofChangeRequest.then(function(sysidofChangeRequestValue){
				var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
				setChangeRequesttoImplementState.then(function(statuscode){
				expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
				});
			});

				snowPage.checkIfProvisioningTaskClosed();
				snowPage.closeNotifySerDeskTask();
				snowPage.closeImplementTask();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(vRACentOS76Temp.completedState);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(vRACentOS76Temp.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickBackButton();
	    });
	
		it('Verify the Second RITM for Provision functionality with Normal change', function () {
		
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			var service = snowPage.getTextReqItemVariableServiceName();
			service.then(function(serviceName) {
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Memory (MB)")).toEqual(jsonUtil.getValue(vraCentOSObj, "Memory (MB)"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Storage (GB)")).toEqual("5");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("CPUs")).toEqual(jsonUtil.getValue(vraCentOSObj, "CPUs"));
				expect(snowPage.getTextReqItemBOMTotalVRA()).toBe(snowInstanceTemplate.snowreqItemBOMtotalVRA);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Normal change
				snowPage.openRelatedChangeRequest();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
				snowPage.enterChangeReqValues();
				snowPage.enterPlanningValues();
				snowPage.enterScheduleValues();
				snowPage.clickCalculateRiskLink();
				snowPage.clickAssessButton();
				
				//Approvals in SNOW
				snowPage.clickRequestApprovalInChangeRequestPage();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveRequestQS();
				snowPage.approveRequestQS();
				expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);			
						
				//Order Completion in SNOW
				snowPage.rightClickOnCMDBCIFormHeader();
				var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
				sysidofChangeRequest.then(function(sysidofChangeRequestValue){
				var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
				setChangeRequesttoImplementState.then(function(statuscode){
				expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
				});
			});
			
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.closeNotifySerDeskTask();
				snowPage.closeImplementTask();
				snowPage.clickCloseChangeRequestButton();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(vRACentOS76Temp.completedState);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(vRACentOS76Temp.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickBackButton();
			
			//Validations on SNOW Request page after Completion of all RITM's
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
	    });
	 }
	
});
	
	
	
	