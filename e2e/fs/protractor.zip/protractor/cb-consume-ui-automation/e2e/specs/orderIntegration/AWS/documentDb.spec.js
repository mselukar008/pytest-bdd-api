"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    documentDbTemplate = require('../../../../testData/OrderIntegration/AWS/documentDb.json');

describe('AWS - DocumentDb', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, cluster, dbInstance, serviceName, documntObj, inventoryPage;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = documentDbTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Databases',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        systemTagText: "ibm_mcmp_soiid"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-documentDb-" + util.getRandomString(5);
        dbInstance = "attDbInstance" + util.getRandomString(5);
        cluster = "attClu" + util.getRandomString(5);
        cluster = cluster.toLowerCase();
        dbInstance = dbInstance.toLowerCase();
        documntObj = JSON.parse(JSON.stringify(documentDbTemplate));
    });

    beforeEach(function () {
        modifiedParamMap = { "Service Instance Name": serviceName, "Instance identifier": dbInstance, "Cluster identifier": cluster };
    });

    it('AWS-DocumentDb - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        catalogPage.open();
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(documentDbTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(documentDbTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(documentDbTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(documentDbTemplate.TotalCost); expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Cluster identifier"]).toEqual(cluster);
            expect(requiredReturnMap["Actual"]["Instance identifier"]).toEqual(dbInstance);
            expect(requiredReturnMap["Actual"]["Instance class"]).toEqual(requiredReturnMap["Expected"]["Instance class"]);
            expect(requiredReturnMap["Actual"]["Master username"]).toEqual(requiredReturnMap["Expected"]["Master username"]);
            expect(requiredReturnMap["Actual"]["VPC"]).toEqual(requiredReturnMap["Expected"]["VPC"]);
            expect(requiredReturnMap["Actual"]["VPC security groups"]).toEqual(requiredReturnMap["Expected"]["VPC security groups"]);
            expect(requiredReturnMap["Actual"]["Select encryption"]).toEqual(requiredReturnMap["Expected"]["Select encryption"]);
            expect(requiredReturnMap["Actual"]["Master key"]).toEqual(requiredReturnMap["Expected"]["Master key"]);
            expect(requiredReturnMap["Actual"]["Port"]).toEqual(requiredReturnMap["Expected"]["Port"]);
            expect(requiredReturnMap["Actual"]["Backup retention period"]).toEqual(requiredReturnMap["Expected"]["Backup retention period"]);
            expect(requiredReturnMap["Actual"]["Backup window"]).toEqual(requiredReturnMap["Expected"]["Backup window"]);
            expect(requiredReturnMap["Actual"]["Maintenance window"]).toEqual(requiredReturnMap["Expected"]["Maintenance window"]);
            expect(requiredReturnMap["Actual"]["Enable deletion protection"]).toEqual(requiredReturnMap["Expected"]["Enable deletion protection"]);

            //Submit Order
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(documentDbTemplate.bluePrintName, "New");
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            //orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 5000);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(documentDbTemplate.EstimatedPrice);
                //Validate pricing on order history page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(documentDbTemplate.EstimatedPrice);
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(documntObj, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Cluster identifier")).toEqual(cluster);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance identifier")).toEqual(dbInstance);
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance class")).toEqual(jsonUtil.getValue(documntObj, "Instance class"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Master username")).toEqual(jsonUtil.getValue(documntObj, "Master username"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("VPC")).toEqual(jsonUtil.getValue(documntObj, "VPC"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC security groups")).toEqual(jsonUtil.getValue(documntObj, "VPC security groups"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Select encryption")).toEqual(jsonUtil.getValue(documntObj, "Select encryption"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Master key")).toEqual(jsonUtil.getValue(documntObj, "Master key"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Port")).toEqual(jsonUtil.getValue(documntObj, "Port"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValue(documntObj, "Backup retention period"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Backup window")).toEqual(jsonUtil.getValue(documntObj, "Backup window"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Maintenance window")).toEqual(jsonUtil.getValue(documntObj, "Maintenance window"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Enable deletion protection")).toEqual(jsonUtil.getValue(documntObj, "Enable deletion protection"));

            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(documentDbTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(documentDbTemplate.TotalCost);
            ordersHistoryPage.closeServiceDetailsSlider();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.clickAllOrdersUnderOrdersSection();
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(documntObj, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("Cluster identifier")).toEqual(cluster);
            expect(ordersPage.getTextBasedOnLabelName("Instance identifier")).toEqual(dbInstance);
            expect(ordersPage.getTextBasedOnLabelName("Instance class")).toEqual(jsonUtil.getValue(documntObj, "Instance class"));
            expect(ordersPage.getTextBasedOnLabelName("Master username")).toEqual(jsonUtil.getValue(documntObj, "Master username"));
            expect(ordersPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(documntObj, "VPC"));
            expect(ordersPage.getTextBasedOnLabelName("VPC security groups")).toEqual(jsonUtil.getValue(documntObj, "VPC security groups"));
            expect(ordersPage.getTextBasedOnLabelName("Select encryption")).toEqual(jsonUtil.getValue(documntObj, "Select encryption"));
            expect(ordersPage.getTextBasedOnLabelName("Master key")).toEqual(jsonUtil.getValue(documntObj, "Master key"));
            expect(ordersPage.getTextBasedOnLabelName("Port")).toEqual(jsonUtil.getValue(documntObj, "Port"));
            expect(ordersPage.getTextBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValue(documntObj, "Backup retention period"));
            expect(ordersPage.getTextBasedOnLabelName("Backup window")).toEqual(jsonUtil.getValue(documntObj, "Backup window"));
            expect(ordersPage.getTextBasedOnLabelName("Maintenance window")).toEqual(jsonUtil.getValue(documntObj, "Maintenance window"));
            expect(ordersPage.getTextBasedOnLabelName("Enable deletion protection")).toEqual(jsonUtil.getValue(documntObj, "Enable deletion protection"));
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(documentDbTemplate.TotalCost);
            ordersPage.clickServiceDetailSliderCloseButton();
        });
    });

    it('AWS DocumentDb - Validate system tags, Edit and Delete Service', function () {       
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            if (isDummyAdapterDisabled == "true") {
                orderObject.componentType = documentDbTemplate.componentType1;
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(documentDbTemplate.componentType1).then(function (index) {
                    inventoryPage.clickViewComponentBasedOnIndex(index - 1).then(function () {
                        //View Component VM details
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(documentDbTemplate.componentType1);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Resource Id")).toEqual(cluster);
                        //View Component Template Output Properties
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("BackupRetentionPeriod")).toEqual(jsonUtil.getValue(documntObj, "Backup retention period"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DBClusterIdentifier")).toEqual(cluster);
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Port")).toEqual(jsonUtil.getValue(documntObj, "Port"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("MasterUsername")).toEqual(jsonUtil.getValue(documntObj, "Master username"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("PreferredBackupWindow")).toEqual(jsonUtil.getValue(documntObj, "Backup window"));
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("PreferredMaintenanceWindow")).toEqual(jsonUtil.getValue(documntObj, "Maintenance window").toLowerCase());
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DeletionProtection")).toEqual(jsonUtil.getValue(documntObj, "Enable deletion protection").toLowerCase());
                    });
                    inventoryPage.getTagsOnInventory().then(function (tags) {
                        var tagList = tags.split(",");
                        var tagMap = inventoryPage.getServiceTags(tagList);
                        var mcmpTag = false;
                        //verifying a system tag
                        expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                        //verifying some of the service tags  
                        expect(tagList.includes(tagList.find(tag => tag.includes("stackId:arn:aws:cloudformation:")))).toBe(true);           
                        expect(tagList.includes(tagList.find(tag => tag.includes("DBClusterIdentifier:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("DBInstanceIdentifier:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("stackId:arn:aws:cloudformation:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("ibm_mcmp_soiid:")))).toBe(true);
                        expect(tagMap["serviceInstanceName"].toLowerCase()).toContain(serviceName.toLowerCase());
                        orderFlowUtil.closeHorizontalSliderIfPresent();
                    });

                    inventoryPage.clickOverflowACtionBtnBasedOnComponent(documentDbTemplate.componentType2).then(function (index) {
                        inventoryPage.clickViewComponentBasedOnIndex(index - 1).then(function () {
                            //View Component VM details
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(documentDbTemplate.componentType2);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Resource Id")).toEqual(dbInstance);
                            //View Component Template Output Properties
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DBInstanceClass")).toEqual(jsonUtil.getValue(documntObj, "Instance class"));
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("DBInstanceIdentifier")).toEqual(dbInstance);
                        });
                    });
                    inventoryPage.getTagsOnInventory().then(function (tags) {
                        var tagList = tags.split(",");
                        var tagMap = inventoryPage.getServiceTags(tagList);
                        var mcmpTag = false;
                        //verifying a system tag
                        expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                        //verifying some of the service tags  
                        expect(tagList.includes(tagList.find(tag => tag.includes("stackId:arn:aws:cloudformation:")))).toBe(true);           
                        expect(tagList.includes(tagList.find(tag => tag.includes("DBClusterIdentifier:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("DBInstanceIdentifier:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("stackId:arn:aws:cloudformation:")))).toBe(true);
                        expect(tagList.includes(tagList.find(tag => tag.includes("ibm_mcmp_soiid:")))).toBe(true);
                        expect(tagMap["serviceInstanceName"].toLowerCase()).toContain(serviceName.toLowerCase());
                        
                    });
                });
            } else {
                inventoryPage.clickOverflowACtionBtnBasedOnComponent();
                inventoryPage.clickViewComponentofAWSInstance();
                inventoryPage.getTagsOnInventory().then(function (tags) {
                    var tagList = tags.split(",");
                    var tagMap = inventoryPage.getServiceTags(tagList);
                    //verifying flags for dummy adapter
                    expect(tagMap["IsUsingDummy"]).toEqual("Yes");
                    expect(tagMap["Name"]).toEqual(documentDbTemplate.bluePrintName);
                    expect(tagMap["PhysicalId"]).toContain(serviceName);
                    expect(Object.keys(tagMap).includes("Test")).toBe(true);
                    expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                });
            }
            orderFlowUtil.closeHorizontalSliderIfPresent();
        });

        //Edit service flow
        var dbInstanceEdit = "oracleNew"+ util.getRandomString(5);
        var dbClusterEdit = "oracluster"+ util.getRandomString(5);  
        var modifiedParamMapEdit = { "EditService": true, "Instance identifier":dbInstanceEdit, "Cluster identifier": dbClusterEdit};       
        orderFlowUtil.editService(orderObject);
        orderFlowUtil.fillOrderDetails(documentDbTemplate, modifiedParamMapEdit).then(function (reviewOrderExpActParamsMap) {
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(documentDbTemplate.TotalCostPostEdit);
            
            //Delete password key as its encrypted on UI.
            delete reviewOrderExpActParamsMap["Actual"]["Master password"];
            delete reviewOrderExpActParamsMap["Expected"]["Master password"];
            //Validate Review order page parameters
            expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
        });
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(documentDbTemplate.bluePrintName, "Edit");
       // orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 5000);
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == 'Completed') {
                //Verify updated details are reflected on order details page.						
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnLabelName("Cluster identifier")).toEqual(dbClusterEdit);
                expect(ordersPage.getTextBasedOnLabelName("Instance identifier")).toEqual(dbInstanceEdit);
                expect(ordersPage.getTextBasedOnLabelName("Instance class")).toEqual(jsonUtil.getValueEditParameter(documntObj, "Instance class"));
                expect(ordersPage.getTextBasedOnLabelName("Port")).toEqual(jsonUtil.getValueEditParameter(documntObj, "Port"));
                expect(ordersPage.getTextBasedOnLabelName("Backup retention period")).toEqual(jsonUtil.getValueEditParameter(documntObj, "Backup retention period"));
                expect(ordersPage.getTextBasedOnLabelName("Maintenance window")).toEqual(jsonUtil.getValueEditParameter(documntObj, "Maintenance window"));
                expect(ordersPage.getTextBasedOnLabelName("Enable deletion protection")).toEqual(jsonUtil.getValueEditParameter(documntObj, "Enable deletion protection"));
                expect(ordersPage.getTextBasedOnLabelName("Key")).toEqual(jsonUtil.getValueEditParameter(documntObj, "Key"));
                expect(ordersPage.getTextBasedOnLabelName("Value")).toEqual(jsonUtil.getValueEditParameter(documntObj, "Value"));
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(documentDbTemplate.TotalCostPostEdit);
                ordersPage.clickServiceDetailSliderCloseButton();
                //Delete Service flow
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, documentDbTemplate.bluePrintName);
               // orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 5000);
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            }
        });
    });
});
