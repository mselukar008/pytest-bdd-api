/*
Spec_Name: virtualNetwork.spec.js 
Description: This spec will cover E2E testing of Virtual Network service order submit, approve, edit and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../../testData/appUrls.json'),
        util = require('../../../../helpers/util.js'),
        jsonUtil = require('../../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        VNTemplate = require('../../../../testData/OrderIntegration/Azure/VN.json');

describe('Azure - Virtual Network', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, cartListPage, catalogDetailsPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Network', disabledState: VNTemplate.disabledState };
        var modifiedParamMapedit = {};
        var servicename = "AutoVNsrv" + util.getRandomString(5);
        var rgName, vnName, subName, SOIComponents;

        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                cartListPage = new CartListPage();
                catalogDetailsPage = new CatalogDetailsPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                rgName = "gslautotc_azure_vnRG" + util.getRandomString(5);
                vnName = "autovn" + util.getRandomString(5);
                subName = "autosub" + util.getRandomString(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Virtual Network Name": vnName, "Subnet Name": subName };
                SOIComponents = [subName, vnName]
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        });

        afterAll(function () {
                //Delete Virtual Network
                var returnObj = {};
                returnObj.servicename = servicename;
                returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                orderFlowUtil.approveDeletedOrder(returnObj);
                orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
        });

        //E2E ExpressRoute Virtual Network order Submit, Approve, Edit and Delete Service with New Resource Group.
        if(isProvisioningRequired == "true") {
                it('Azure: TC-T475422 Verify that for Virtual Network, create new Virtual Network with New Resource Group is working fine', function () {
                        var orderObject = JSON.parse(JSON.stringify(VNTemplate));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};
                        var returnObj1 = {};
                        orderFlowUtil.fillOrderDetails(VNTemplate, modifiedParamMap);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Checking Inventory Page Service Configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Virtual Network Name:")).toEqual(vnName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Virtual Network Location:")).toEqual(jsonUtil.getValue(orderObject, "Virtual Network Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" IPv4 Address Space:")).toEqual(jsonUtil.getValue(orderObject, "IPv4 Address Space"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Subnet Name:")).toEqual(subName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Subnet Address Range:")).toEqual(jsonUtil.getValue(orderObject, "Subnet Address Range"));
                        expect(inventoryPage.getTextBasedOnLabelName(" DDoS Protection:")).toEqual(jsonUtil.getValue(orderObject, "DDoS Protection"));
                        inventoryPage.closeViewDetailsTab();
                        //Checking SOI Components
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.clickExpandFirstRow().then(function () {
                                        browser.executeScript('window.scrollTo(0,0);');
                                        var i = 1;
                                        async.forEachSeries(SOIComponents, function (component, callback) {
                                                inventoryPage.clickOverMenuIcon(i).then(function () {
                                                        inventoryPage.clickOnViewComponent(i).then(function () {
                                                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                                                inventoryPage.closeViewComponent();
                                                                browser.sleep(10000);
                                                                i++;
                                                                return callback();
                                                        });
                                                })
                                        }, function (error) {
                                                if (error) {
                                                        logger.info('Unable to Get SOI component')
                                                }
                                        })
                                })
                        }
                        //Editing Virtual Network Service
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                        inventoryPage.clickEditServiceIcon();
                        // Validate if main parameters are disabled during edit service
                        expect(cartListPage.isEnabledInstancePrefixTextbox()).toMatch(messageStrings.disabledState);
                        expect(cartListPage.isDisplayedEnvDropdown()).toBe(false);
                        expect(cartListPage.isDisplayedAppDropdown()).toBe(false);
                        expect(cartListPage.isDisplayedTeamRadioButton()).toBe(false);
                        expect(cartListPage.isDisabledProviderAccount()).toBe(true);
                        modifiedParamMapedit = { "Service Instance Name": servicename, "EditService": true };
                        orderFlowUtil.fillOrderDetails(VNTemplate, modifiedParamMapedit);
                        placeOrderPage.submitOrder();
                        returnObj1.servicename = servicename;
                        returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        //Get details on pop up after submit
                        var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        var orderprice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                        var ordernumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        //Open Order page and Approve Order 
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj1);
                        orderFlowUtil.waitForOrderStatusChange(returnObj1, "Completed", 50);
                });
        }

        //Checking parameters on Main Parameters page
        it('Azure: TC-T466501 verify that for Virtual Network Service all parameters on Main Parameters Page are present.', function () {
                var orderObject = JSON.parse(JSON.stringify(VNTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
                if (browser.params.defaultCurrency == "USD") {
                expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
                }
        });

        //Checking values all parameters on Review Order Page and View Order Details
        it('Azure: TC-T466503 verify that for Virtual Network Service all values on Review Order Page and View Order Details page matches with input.', function () {
                var returnObj = {};
                returnObj.servicename = servicename;
                var orderObject = JSON.parse(JSON.stringify(VNTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(VNTemplate, modifiedParamMap);
                //Checking Service Details in ReviewOrder
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
                if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
                }
                //Checking Additional Details in ReviewOrder
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Virtual Network Name:")).toEqual(vnName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Virtual Network Location:")).toEqual(jsonUtil.getValue(orderObject, "Virtual Network Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" IPv4 Address Space:")).toEqual(jsonUtil.getValue(orderObject, "IPv4 Address Space"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Subnet Name:")).toEqual(subName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Subnet Address Range:")).toEqual(jsonUtil.getValue(orderObject, "Subnet Address Range"));
                expect(placeOrderPage.getTextBasedOnLabelName(" DDoS Protection:")).toEqual(jsonUtil.getValue(orderObject, "DDoS Protection"));
                placeOrderPage.submitOrder();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                ordersPage.open();
                ordersPage.searchOrderById(returnObj.orderNumber);
                ordersPage.clickFirstViewDetailsOrdersTable();
                //Checking Order Details in View order details
                expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
                //Checking Service Configuration Parameters
                expect(ordersPage.getTextBasedOnLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
                expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(ordersPage.getTextBasedOnLabelName("Virtual Network Name")).toEqual(vnName);
                expect(ordersPage.getTextBasedOnLabelName("Virtual Network Location")).toEqual(jsonUtil.getValue(orderObject, "Virtual Network Location"));
                expect(ordersPage.getTextBasedOnLabelName("IPv4 Address Space")).toEqual(jsonUtil.getValue(orderObject, "IPv4 Address Space"));
                expect(ordersPage.getTextBasedOnLabelName("Subnet Name")).toEqual(subName);
                expect(ordersPage.getTextBasedOnLabelName("Subnet Address Range")).toEqual(jsonUtil.getValue(orderObject, "Subnet Address Range"));
                expect(ordersPage.getTextBasedOnLabelName("DDoS Protection")).toEqual(jsonUtil.getValue(orderObject, "DDoS Protection"));
                //Checking Bill Of Material
                if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
                }
                ordersPage.clickServiceDetailSliderCloseButton();
        });
});
