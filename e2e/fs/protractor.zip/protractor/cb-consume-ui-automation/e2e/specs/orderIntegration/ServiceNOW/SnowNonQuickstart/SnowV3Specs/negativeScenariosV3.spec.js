"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	OrderHistoryPage = require('../../../../../pageObjects/ordersHistory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	vRACentOS76Temp = require('../../../../../../testData/OrderIntegration/ServiceNOW/CloneCentOS76Snow.json'),
	azureLinuxTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/AzureLinuxVMSnow.json'),
	awsEC2template = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSEC2InstanceSnow.json'),
	awsS3Temp = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSS3Snow.json'),
	slSecurityGrpTemplate = require('../../../../../../testData/OrderIntegration/Softlayer/SecurityGroupService.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('Test cases for V3 Negative Scenarios', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, sampleOrder1, provOrder, instName, orderHistoryPage, policyPage, serviceName, policyName, policyRuleName, groupName, cartListPage;
	var modifiedParamMapVRA = {};
	var modifiedParamMapAzure = {};
	var modifiedParamMapAWS = {};
	var modifiedParamMapSL = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule1 = {};
	var modifiedParamMapAddRule2 = {}; 
	var modifiedParamMapAddRule3 = {}; 
	var modifiedParamMapAddRule4 = {};
	var modifiedParamMapRetry = {};
	var consumeLaunchpadUrl = url + '/launchpad';
	var vraCentOSObj = JSON.parse(JSON.stringify(vRACentOS76Temp));
	var newResourceGroupName = "gslautotc_azureWVM-RG101" + util.getRandomString(4);
	var newVmName = "auto-VM101" + util.getRandomString(4);
	var newNetworkName = "auto-VN101" + util.getRandomString(4);
	var newSubnetName = "auto-SN101" + util.getRandomString(4);
	var newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
	var newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
	var newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
	var newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
	var diskName = "autodisk" + util.getRandomString(4);
    diskName = diskName.toLocaleLowerCase();
    var secGrpName = "SNOWsecGrp"+util.getRandomString(5);
	var azureLinuxObj = JSON.parse(JSON.stringify(azureLinuxTemplate.Scenario1));
	
	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		orderHistoryPage = new OrderHistoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		groupName = "att-group-" + util.getRandomString(5);
		serviceName = "SNOWauto"+util.getRandomString(5);
		policyName = "SNOWautoPolicy"+util.getRandomString(5);
		policyRuleName = "SNOWautoPolicyRule"+util.getRandomString(5);
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule1 = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["VRA","IBM Cloud"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
								   "Technical":"Manual Approval","Financial":"Manual Approval","Legal":"External Approval"};
		modifiedParamMapAddRule2 = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["Azure"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
				                   "Technical":"Manual Approval","Legal":"External Approval"};
		modifiedParamMapAddRule3 = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["Amazon"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
				  				   "Technical":"Manual Approval","Financial":"External Approval"};
		modifiedParamMapAddRule4 = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["IBM Cloud"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
				   				   "Technical":"Manual Approval","Financial":"External Approval"};
		modifiedParamMapVRA = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "Provider Account":"VRA76 / VRA76"};
		modifiedParamMapRetry = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"","Provider Account":"VRARetry / VRARetry"};
		modifiedParamMapAzure = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Virtual Network Name": newNetworkName, "Disk Name": diskName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName };
		modifiedParamMapAWS = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "Provider Account":"AWS-SNOW / AWS-SNOW", "Group Name": groupName};
		modifiedParamMapSL = {"Service Instance Name":serviceName,"Team":"Auto-TEAM1", "Environment":"QA", "Application":"","Provider Account":"SL-Testing / SL-Testing","Security Group Name":secGrpName};

	});
	
	if(isProvisioningRequired == "true") {
		it('Approve all three fields in consume and verify for Manual, Manual and External Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Financial and External Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place order
	  		var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":sampleOrder1};	

			//Check if order is requested
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsRequested();
			
			//Approve all three fields in Marketplace and validate error
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickFinancialApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickLegalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
			expect(ordersPage.getTextApprovalErrorMsgSNOW()).toBe(vRACentOS76Temp.approvalErrorMsg);
			
			//Delete Manual Technical, Financial and External Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	
		});
	
		it('Deny IBM Cloud order in Consume and verify the status for Manual, Manual and External Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			//expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Financial and External Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place order
	  		var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":sampleOrder1};	
			
			//Check if order is requested
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsRequested();
			
			//Deny Order in Consume
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.denyOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.rejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.rejectedState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestRejectedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			
			//Delete Manual Technical, Financial and External Legal policy
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});
	
		it('Deny SL order in Consume after approving in SNOW and verify the status for Manual, Auto and External Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			//expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Financial and External Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place order
	  		var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.appInProgressState);
			
			//Approve Order in SNOW
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequested();
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Deny Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.denyOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.rejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.rejectedState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestRejectedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			
			//Delete Manual Technical, Auto Financial and External Legal policy
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});
		
		it('Reject AWS order in SNOW at Request level for Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			//expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule3);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place a AWS order
	  		var orderObject = {};
	  		catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(awsEC2template.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(awsEC2template.Category);
			catalogPage.clickConfigureButtonBasedOnName(awsEC2template.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(awsEC2template, modifiedParamMapAWS);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
			ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);		
			
			//Reject the approval in SNOW
			snowPage.rejectTheServiceNowRequestFromSnowPortal();
			
			//Validations on SNOW Request page after rejecting
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getTextApprovalAfterFirstApproval()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	
			
			//Validate in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.rejectedState);
			
			//Delete Manual Technical, External Financial and Auto Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});
		
		it('Cancel IBMCLOUD order in Consume and verify the status for Manual, Auto and External Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			//expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Financial and External Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place order
	  		var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(azureLinuxObj.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			
			//Cancel the order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderHistoryPage.searchOrderClickCancelOrder(orderObject.orderNumber);
			orderHistoryPage.clickCancelOrderConfirmationButton();
			expect(orderHistoryPage.getTextCancelOrderSuccessFulMsg()).toContain(vRACentOS76Temp.cancelOrderSuccessMsg);
			orderHistoryPage.clickCancelOrderOkButton();
			expect(orderHistoryPage.getTextCancelOrderStatusInOrderHistory()).toContain(vRACentOS76Temp.cancelledStatus);
			
			//Validations on SNOW Request page after cancelling
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestStateCancelled);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.cancelledStatus);
			
			//Delete Manual Technical, Auto Financial and External Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});
		
		it('Cancel IBM Cloud order in Consume after approving in SNOW and verify the status for Manual, Manual and External Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			//expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Financial and External Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place order
	  		var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":sampleOrder1};	
			
			//Approve Order in SNOW
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsRequested();
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Cancel the order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderHistoryPage.searchOrderClickCancelOrder(orderObject.orderNumber);
			orderHistoryPage.clickCancelOrderConfirmationButton();
			expect(orderHistoryPage.getTextCancelOrderSuccessFulMsg()).toContain(vRACentOS76Temp.cancelOrderSuccessMsg);
			orderHistoryPage.clickCancelOrderOkButton();
			expect(orderHistoryPage.getTextCancelOrderStatusInOrderHistory()).toContain(vRACentOS76Temp.cancelledStatus);
			
			//Validations on SNOW Request page after cancelling
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestStateCancelled);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.cancelledStatus);
			
			//Delete Manual Technical, Financial and External Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});
		
		it('Cancel IBM Cloud order in Consume after approving in Consume for Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Financial and External Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place order
	  		var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":sampleOrder1};	
			
			//Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
		    ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Cancel the order in Marketplace
			orderHistoryPage.searchOrderClickCancelOrder(orderObject.orderNumber);
			orderHistoryPage.clickCancelOrderConfirmationButton();
			expect(orderHistoryPage.getTextCancelOrderSuccessFulMsg()).toContain(vRACentOS76Temp.cancelOrderSuccessMsg);
			orderHistoryPage.clickCancelOrderOkButton();
			expect(orderHistoryPage.getTextCancelOrderStatusInOrderHistory()).toContain(vRACentOS76Temp.cancelledStatus);
			
			//Validations on SNOW Request page after cancelling
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestStateCancelled);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.cancelledStatus);
			
			//Delete Manual Technical, External Financial and Auto Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});
		
		it('Reject IBM Cloud order approval in SNOW at Change Request level for Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule4);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place Order in Marketplace
	  		var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":sampleOrder1};	
			
			//Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
		    ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Reject the approval in SNOW
			snowPage.clickRequestedItemLink();
			snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.openRelatedChangeRequest();
			snowPage.rejectChangeRequest();
			
			//Validations on SNOW Requested Item page after rejecting
			snowPage.clickBackButton();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	
			
			//Validation on Catalog Task page after rejecting
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickBackButton();
			
			//Validations on SNOW Request page after rejecting
			snowPage.clickBackButton();
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);			
			
			//Validate in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.cancelledStatus);
			
			//Delete Manual Technical, External Financial and Auto Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
	    });	
		
		it('Place an IBM Cloud order by not uploading custom policy for IBM Cloud for Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Normal in SNOW
			expect(snowAPI.setCustomPolicyForAzureAWSNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule4);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":sampleOrder1};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,slSecurityGrpTemplate.rejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(slSecurityGrpTemplate.rejectedState);
			
			//Verify in SNOW
            snowPage.logInToSnowDevPortalAndSearchOrderNotExists(sampleOrder1);
			expect(snowPage.getTextOrderNotExists()).toBe(snowInstanceTemplate.orderNotExistsMessage);
			
			//Delete Manual Technical, External Financial and Auto Legal policy
			browser.get(consumeLaunchpadUrl);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	
		});
		
		it('Fail the VRA order, Retry and when retry fails again cancel the order for Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Manual Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider.toUpperCase());
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapRetry);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.appInProgressState);
			
			//Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickFinancialApprovalCheckBoxOrderApprovalModal();
		    ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Order Completion in SNOW
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsS3Temp.failedState);
			
			//Validations in SNOW after provision failed
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			snowPage.openRelatedChangeRequest();
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextChangeTaskFirstActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);			
			snowPage.openIncident();
			expect(snowPage.getTextIncidentState()).toBe(snowInstanceTemplate.snowIncidentStateInProg);
			expect(snowPage.getTextIncAssignmentGroup()).toBe(snowInstanceTemplate.snowIncidentAssignGrp);
			expect(snowPage.getTextIncShortDesc()).toBe(snowInstanceTemplate.snowChangeTaskActivity);
			snowPage.clickNotesTab();
			expect(snowPage.getTextChangeTaskFirstActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);
			
			//Retry the order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderHistoryPage.searchOrderClickRetry(provOrder);
	        expect(orderHistoryPage.verifyOrderTableActionsRetryModelSuccessMsgVisibility()).toMatch(awsS3Temp.retrySuccessMsg);
	        orderHistoryPage.clickOnOrderTableActionsRetryModelOkButton();
	        orderFlowUtil.waitForOrderStatusChange(orderObject,awsS3Temp.failedState);
	        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsS3Temp.failedState);
	        
	        //Validations in SNOW after provision failed again
	        snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskSecondActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);
			snowPage.openIncident();
			snowPage.clickNotesTab();
			expect(snowPage.getTextChangeTaskSecondActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);
						
			//Cancel the order in Marketplace	
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderHistoryPage.searchOrderClickCancel(provOrder);
			//expect(orderHistoryPage.verifyOrderTableActionsCancelModelSuccessMsgVisibility()).toMatch(awsS3Temp.cancelSuccessMsg);
			orderHistoryPage.clickOnOrderTableActionsCancelModelOkButton();
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsS3Temp.cancelledStatus);
			
			//Validations in SNOW after order is cancelled
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.openRelatedChangeRequest();
			snowPage.clickChangeTaskTabInChangeRequest();
			snowPage.waitForProvisioningTaskChange(snowInstanceTemplate.snowChangeTaskStateCancelled);
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskState()).toBe(snowInstanceTemplate.snowChangeTaskStateCancelled);
			snowPage.clickBackButton();
			
			//Order Completion in SNOW
			snowPage.clickBackButton();
			snowPage.clickBackButton();
			
			//Validations in SNOW after order is closed
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickBackButton();
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickBackButton();
			snowPage.openRelatedChangeRequest();
			snowPage.openChangeTask();
			snowPage.openIncident();
			snowPage.clickNotesTab();
			expect(snowPage.getTextIncidentState()).toBe(snowInstanceTemplate.snowIncidentStateResolved);
			expect(snowPage.getTextIncShortDesc()).toBe(snowInstanceTemplate.snowIncidentShortDescCancelled);
			snowPage.clickIncResolutionInfoTab();
			expect(snowPage.getTextIncResCode()).toBe(snowInstanceTemplate.snowIncidentResCodeNotSolved);
			expect(snowPage.getTextIncResNotes()).toBe(snowInstanceTemplate.snowIncidentResNotesNotsolved);
			
			//Delete Manual Technical, External Financial and Auto Legal policy
			browser.get(consumeLaunchpadUrl);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);		
	    });	
		
		it('Fail the vRA order, Retry and verify the status after retry is successful for Manual, Manual and Auto Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Manual Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapRetry);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.appInProgressState);
			
			//Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickFinancialApprovalCheckBoxOrderApprovalModal();
		    ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Order Completion in SNOW
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.failedState);
			
			//Validations in SNOW after provision failed
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			snowPage.clickBackButton();
			snowPage.openRelatedChangeRequest();
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextChangeTaskFirstActivity()).toContain(snowInstanceTemplate.snowChangeTaskActivityVRA);			
			snowPage.openIncident();
			expect(snowPage.getTextIncidentState()).toBe(snowInstanceTemplate.snowIncidentStateInProg);
			expect(snowPage.getTextIncAssignmentGroup()).toBe(snowInstanceTemplate.snowIncidentAssignGrp);
			expect(snowPage.getTextIncShortDesc()).toContain(snowInstanceTemplate.snowChangeTaskActivityVRA);
			snowPage.clickNotesTab();
			expect(snowPage.getTextChangeTaskFirstActivity()).toContain(snowInstanceTemplate.snowChangeTaskActivityVRA);
			
			//Retry the order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			accountsPage.editAccountDetails(vRACentOS76Temp.retryProviderAcct);
		    accountsPage.enterEndpointUrlVRATextbox(vRACentOS76Temp.validEndpointUrl);
		    accountsPage.clickSaveAccountDetailsButton();
		    expect(accountsPage.getEditSuccessMsgText()).toMatch(vRACentOS76Temp.editSuccessMsg);
			orderHistoryPage.searchOrderClickRetry(provOrder);
	        expect(orderHistoryPage.verifyOrderTableActionsRetryModelSuccessMsgVisibility()).toMatch(vRACentOS76Temp.retrySuccessMsg);
	        orderHistoryPage.clickOnOrderTableActionsRetryModelOkButton();
	        orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
	        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.provInProgressState);
	        
	        //Provisioning task close in SNOW
	        snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			snowPage.clickChangeTaskTabInChangeRequest();
			snowPage.waitForProvisioningTaskChange(snowInstanceTemplate.snowChangeRequestStateClose);
			
			//Validation in SNOW after task is closed
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskState()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextChangeTaskFirstActivity()).toContain(snowInstanceTemplate.snowChangeTaskActivityProvComp);
			snowPage.openIncident();
			expect(snowPage.getTextIncidentState()).toBe(snowInstanceTemplate.snowIncidentStateInProg);
			expect(snowPage.getTextIncShortDesc()).toBe(snowInstanceTemplate.snowChangeTaskActivityProvComp);
			snowPage.clickNotesTab();
			expect(snowPage.getTextChangeTaskFirstActivity()).toContain(snowInstanceTemplate.snowChangeTaskActivityProvComp);
			snowPage.clickBackButton();
			snowPage.clickBackButton();
			
			//Order completion in SNOW
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.selectChangeReqState(snowInstanceTemplate.snowChangeRequestStateClose);
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			browser.sleep(5000);
			snowPage.openChangeTask();
			snowPage.openIncident();
			expect(snowPage.getTextIncidentState()).toBe(snowInstanceTemplate.snowIncidentStateResolved);
			snowPage.clickIncResolutionInfoTab();
			expect(snowPage.getTextIncResCode()).toBe(snowInstanceTemplate.snowIncidentResCodeSolved);
			expect(snowPage.getTextIncResNotes()).toBe(snowInstanceTemplate.snowIncidentResNotesResolved);
			
			//Validations in SNOW after order is closed
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();		
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickBackButton();
			
			//Validation in Marketplace after order is completed
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
			
			accountsPage.editAccountDetails(vRACentOS76Temp.retryProviderAcct);
		    accountsPage.enterEndpointUrlVRATextbox(vRACentOS76Temp.invalidEndpointUrl);
		    accountsPage.clickSaveAccountDetailsButton();
		    expect(accountsPage.getEditSuccessMsgText()).toMatch(vRACentOS76Temp.editSuccessMsg);	
		    
		    //Delete Manual Technical, External Financial and Auto Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);		
	    });	
		
		it('Cancel change IBM Cloud order for Normal type at Change request level and verify the status for Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Normal in SNOW
			expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule4);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place a SL order
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);	
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":sampleOrder1};	
			
			//Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
		    ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
		
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Cancel Change
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
			snowPage.cancelChangeWithReason();
			snowPage.enterCancelChangeReason();
			snowPage.clickOkCancelChangeRequest();
			expect(snowPage.getTextChangeReqClosedMsg()).toContain(snowInstanceTemplate.snowChangeRequestCancelledMsg);
						
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.cancelledStatus);
			
			//Validation in SNOW after cancelling the change
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickBackButton();
			snowPage.openRelatedChangeRequest();
			expect(snowPage.getTextChangeReqState()).toContain(snowInstanceTemplate.snowChangeTaskStateCancelled);
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskState()).toBe(snowInstanceTemplate.snowChangeTaskStateCancelled);	
			
			//Delete Manual Technical, External Financial and Auto Legal policy
			browser.get(consumeLaunchpadUrl);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);		
		});

		it('Verify if Cancel Change option for IBM Cloud order is displayed until Scheduled state and not displayed at Implement state for Normal type', function () {
			
			//Set Change Request type to Normal in SNOW
			expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule4);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place a SL order
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);	
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":sampleOrder1};	
			
			//Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
		    ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Verify Cancel Change option at New state
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
			snowPage.rightClickNavbarTitle();
			expect(snowPage.isPresentCancelChange()).toBe(true);
			snowPage.clickUpdateButton();

			//Assess state
			snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.openRelatedChangeRequest();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.rightClickNavbarTitle();
			expect(snowPage.isPresentCancelChange()).toBe(true);
			
			//Authorize state
			snowPage.approveChangeRequestForEachState();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateAuthorize);
			snowPage.rightClickNavbarTitle();
			expect(snowPage.isPresentCancelChange()).toBe(true);
			
			//Scheduled state
			snowPage.approveChangeRequestForEachState();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.rightClickNavbarTitle();
			expect(snowPage.isPresentCancelChange()).toBe(true);
			snowPage.clickUpdateButton();
			
			//Implement state
			snowPage.openRelatedChangeRequest();
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.rightClickNavbarTitle();
			expect(snowPage.isPresentCancelChange()).toBe(false);		
			
			//Delete Manual Technical, External Financial and Auto Legal policy
			browser.get(consumeLaunchpadUrl);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);
		});
     }
});
	
	
	
	