
"use strict";
var Orders = require('../../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../../helpers/util.js'),
    jsonUtil = require('../../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    appUrls = require('../../../../../testData/appUrls.json'),
    imiUtil = require('../../../../../helpers/imiApiUtil.js'),
    shoppingCartTemplate = require('../../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
    imiConfigTemplate = require('../../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    imiManageServiceTemplate = require('../../../../../testData/OrderIntegration/Imi/manageService.json'),
    gcpComputeInsTemplate = require('../../../../../testData/OrderIntegration/Google/gcpComputeIns.json');


describe('IMI-GCP-Compute Engine', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, EC2INSObject, inventoryPage, msgToVerify;
    var adapterName = "Real";
    var instanceName;
    var modifiedParamMap = {};
    var orderObject = {};
    var messageStrings = {
        providerName: 'Google',
        category: 'Compute',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        powerStateOff: "Off",
        powerStateOn: "On",
        orderTypeAction: "Action",
        turnOnNegativeWarning: gcpComputeInsTemplate.turnOnNegativeWarning,
        turnOffNegativeWarning: gcpComputeInsTemplate.turnOffNegativeWarning,
        rebootNegativeWarning: gcpComputeInsTemplate.rebootNegativeWarning,
        turnOffNegativeWarningRealAdapter: "Turn OFF action cannot be performed in Off status.",
        rebootNegativeWarningrealAdapter: "Reboot action cannot be performed in Off status.",
        serviceOfferingTurnOff: "Turn OFF",
        serviceOfferingTurnOn: "Turn ON",
        serviceOfferingReboot: "Reboot",
        instanceName: gcpComputeInsTemplate.instanceName,
        componentType: gcpComputeInsTemplate.componentType,
        Imageid: gcpComputeInsTemplate.Imageid,
        Instancetype: gcpComputeInsTemplate.Instancetype,
        Keyname: gcpComputeInsTemplate.Keyname,
        Subnetid: gcpComputeInsTemplate.Subnetid,
        Architecture: gcpComputeInsTemplate.Architecture,
        Vpcid: gcpComputeInsTemplate.Vpcid,
        Virtualizationtype: gcpComputeInsTemplate.Virtualizationtype,
        bomItem1: "OnDemand Compute Instance t2.small",
        bomItem2: imiConfigTemplate.bomItem2,
        bomItem3: imiConfigTemplate.bomItem3,
        imiOrderSubmitted: "Configure IMI Managed Service",
        customOpsOrderSubmittedMsg: "Order Request Initiated!"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        browser.driver.manage().window().maximize();
        instanceName = "att-vm-" + util.getRandomString(3);
    });  
    
//     afterEach(function(){
//         catalogPage.open();
//         browser.navigate().refresh()
//     });

//     beforeEach(function(){
//         catalogPage.open();        
//     });
      
    it('IMI-Compute Engine- Verify E2E flow for Compute Engine with IMI Add On', function () {

        var serviceDetailsMap = {};
        serviceName = "gcp-compute-" + util.getRandomString(5);
        var addOnName = "compute-adon-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Quantity": "1", "Instance Name": instanceName.toLowerCase(), "Add-On Name": addOnName };
        var ComputeINSObject = JSON.parse(JSON.stringify(gcpComputeInsTemplate));
        orderObject.servicename = serviceName;
        orderObject.instanceName = instanceName.toLowerCase();
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(gcpComputeInsTemplate.bluePrintName);

        //Update ec2 template with IMI template
        delete gcpComputeInsTemplate["Order Parameters"]["Configure Add-ons"];
        gcpComputeInsTemplate["Order Parameters"]["Configure Add-ons"] = imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
        gcpComputeInsTemplate["Order Parameters"]["IMI Main Parameters"] = imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
        gcpComputeInsTemplate["Order Parameters"]["Configure manage service"] = imiConfigTemplate["Order Parameters"]["Configure manage service"];
        gcpComputeInsTemplate["Order Parameters"]["Review IMI Config"] = imiConfigTemplate["Order Parameters"]["Review IMI Config"];

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(gcpComputeInsTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            //Restore template with default data	
            gcpComputeInsTemplate["Order Parameters"]["Configure Add-ons"] = imiManageServiceTemplate["Configure Add-ons"];
            delete gcpComputeInsTemplate["Order Parameters"]["IMI Main Parameters"];
            delete gcpComputeInsTemplate["Order Parameters"]["Configure manage service"];
            delete gcpComputeInsTemplate["Order Parameters"]["Review IMI Config"];
            serviceDetailsMap = requiredReturnMap;
            util.waitForAngular();
            //Validate IMI configuration on Review Order page
            expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Service Instance Prefix", 1)).toEqual(addOnName);
            expect(placeOrderPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(placeOrderPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //expect(placeOrderPage.getTextBasedOnLabelNameandIndex("Provider Account", 1)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Provider Account IMI"));

            //Validate Review Order page with all Service Configuration
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(gcpComputeInsTemplate.TotalCostWithAddOn);

            expect(requiredReturnMap["Actual"]["Region"]).toContain(requiredReturnMap["Expected"]["Region"]);
            expect(requiredReturnMap["Actual"]["Machine Type Edit Option"]).toEqual(requiredReturnMap["Expected"]["Machine Type Edit Option"]);
            expect(requiredReturnMap["Actual"]["Zone"]).toEqual(requiredReturnMap["Expected"]["Zone"]);
            // expect(requiredReturnMap["Actual"]["Instance Name"]).toEqual(requiredReturnMap["Expected"]["Instance Name"]);
            expect(requiredReturnMap["Actual"]["Machine type"]).toEqual(requiredReturnMap["Expected"]["Machine type"]);
            expect(requiredReturnMap["Actual"]["Network Tags"]).toEqual(requiredReturnMap["Expected"]["Network Tags"]);
            expect(requiredReturnMap["Actual"]["Encryption"]).toEqual(requiredReturnMap["Expected"]["Encryption"]);
            expect(requiredReturnMap["Actual"]["Encryption"]).toEqual(requiredReturnMap["Expected"]["Encryption"]);
            expect(requiredReturnMap["Actual"]["Source Image Type"]).toEqual(requiredReturnMap["Expected"]["Source Image Type"]);
            expect(requiredReturnMap["Actual"]["Boot Disk Type"]).toEqual(requiredReturnMap["Expected"]["Boot Disk Type"]);
            expect(requiredReturnMap["Actual"]["Boot Disk Size in GB"]).toEqual(requiredReturnMap["Expected"]["Boot Disk Size in GB"]);

            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpComputeInsTemplate.bluePrintName, "New-AddOn");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate Add on on orders page
            expect(ordersPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual("Approval In Progress");
            expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
            util.waitForAngular();
            expect(ordersPage.getTextBasedOnLabelName("Region")).toContain(jsonUtil.getValue(ComputeINSObject, "Region"));
            expect(ordersPage.getTextBasedOnLabelName("Machine type")).toEqual(jsonUtil.getValue(ComputeINSObject, "Machine type"));
            expect(ordersPage.getTextBasedOnLabelName("Zone")).toEqual(jsonUtil.getValue(ComputeINSObject, "Zone"));
            expect(ordersPage.getTextBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(ComputeINSObject, "Encryption"));
            expect(ordersPage.getTextBasedOnLabelName("Source Image Type")).toEqual(jsonUtil.getValue(ComputeINSObject, "Source Image Type"));
            expect(ordersPage.getTextBasedOnLabelName("Boot Disk Type")).toEqual(jsonUtil.getValue(ComputeINSObject, "Boot Disk Type"));
            expect(ordersPage.getTextBasedOnLabelName("Boot Disk Size in GB")).toEqual(jsonUtil.getValue(ComputeINSObject, "Boot Disk Size in GB"));
            expect(ordersPage.getTextBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(ComputeINSObject, "Encryption"));
            //Validate Add On details
            ordersPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelName("Add-on Name")).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 2)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelName("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelName("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate estimated cost
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(gcpComputeInsTemplate.TotalCostWithAddOn);
            //Validate BOM table on order details
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "Small Instance with 1 VCPU running in APAC": "USD 22.32", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }

            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersPage.closeServiceDetailsSlider();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                //Validate Estimated price on approve order page                
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(gcpComputeInsTemplate.TotalEstimatedCostWithAddOn);
            }

            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            //Validate Add-On tag
            expect(ordersHistoryPage.getTextImiAddOn()).toEqual("Add-on");
            //Validate Add On Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickExpandArrowForServiceAddOn();
            ordersHistoryPage.getAddOnDetails().then(function (addOnDetails) {
                expect(addOnDetails[1]).toContain(addOnName);
                expect(addOnDetails[3]).toContain(imiConfigTemplate.TotalCost);
                expect(addOnDetails[4]).toContain("Completed");
            })
            //Validate Service Details
            ordersHistoryPage.clickOnOrderTableDetailsExpandArrow();
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Region")).toContain(jsonUtil.getValue(ComputeINSObject, "Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Machine type")).toEqual(jsonUtil.getValue(ComputeINSObject, "Machine type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Zone")).toContain(jsonUtil.getValue(ComputeINSObject, "Zone"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(ComputeINSObject, "Encryption"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Source Image Type")).toEqual(jsonUtil.getValue(ComputeINSObject, "Source Image Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Boot Disk Type")).toEqual(jsonUtil.getValue(ComputeINSObject, "Boot Disk Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Boot Disk Size in GB")).toEqual(jsonUtil.getValue(ComputeINSObject, "Boot Disk Size in GB"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Encryption")).toEqual(jsonUtil.getValue(ComputeINSObject, "Encryption"));
            //Validate Add-On Details
            ordersHistoryPage.clickAddOnDetails();
            expect(ordersPage.getTextBasedOnLabelName("Add-on Name")).toEqual(addOnName);
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Provider", 4)).toEqual("IMI");
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(gcpComputeInsTemplate.TotalCostWithAddOn);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "Small Instance with 1 VCPU running in APAC": "USD 22.32", "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(gcpComputeInsTemplate.TotalCostWithAddOn);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            //Verify Output parameter in Inventory
            expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            inventoryPage.clickViewAddOnDetails(orderObject);
            //Verify Add On details in Inventory
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Provider Name", 3)).toBe("IMI");
            expect(inventoryPage.getTextBasedOnLabelNameandIndex("Instance Status", 2)).toBe("Active");
            expect(inventoryPage.getTextImiMangmntLevl()).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            //expect(inventoryPage.getTextBasedOnLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(inventoryPage.getTextBasedOnLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //verify bom for Add On
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(imiConfigTemplate.TotalCost);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            inventoryPage.clickViewServiceClosebutton();
            //Validate IMI tags
            inventoryPage.getImiTags(orderObject).then(function (tags) {
                var tagList = tags.split(",");
                if(isDummyAdapterDisabled == "true"){
                   var plan = imiConfigTemplate.BillingPlanName;                    
                   expect(tagList[1]).toContain(plan.toLowerCase());
                  // expect(tagList[1]).toContain(imiConfigTemplate.BillingPlanName);
                   expect(tagList[2]).toContain(imiConfigTemplate.ServiceTierName);  
                }else{
                    expect(tagList[2]).toContain(imiConfigTemplate.BillingPlanName);
                    expect(tagList[0]).toContain(imiConfigTemplate.ServiceTierName);  
                } 
                
                orderFlowUtil.closeHorizontalSliderIfPresent();
            });
        });
    });
    
    if(isDummyAdapterDisabled == "true") {
        
        it('IMI-Compute Engine-- Verify View Component-Template Output Parameters for the powered ON instance', function () {
            var vmName = orderObject.instanceName;
            vmName = vmName.toLowerCase();
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                    inventoryPage.clickViewComponentofAWSInstance().then(function () {
                        //View Component VM details                    
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(messageStrings.componentType);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Name")).toContain(vmName);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Status")).toEqual(messageStrings.powerStateOn);
                        expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);

                        //View Component Template Output Properties
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("name")).toContain(vmName);
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("machineType")).toContain(gcpComputeInsTemplate.machineType);
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("zone")).toContain(gcpComputeInsTemplate.zone);
                        expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("deletionProtection")).toEqual(gcpComputeInsTemplate.Deletionprotection);

                        inventoryPage.closeViewComponent();
                    });
                });
            });
        });
    }
    
    it('IMI-Compute Engine-Negative Scenario ---- Turn ON the instance when the VM state is ON', function () {
        var orderObject = {};
        orderObject.servicename = serviceName;
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickTurnONButtonOfInstance().then(function () {
                    inventoryPage.placeD2opsOrder();
                    expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(messageStrings.turnOnNegativeWarning);
                    inventoryPage.clickCustomOpsWarningOKButton();
                });
            });
        });
    });

    it('IMI-Compute Engine- Verify instance Turn OFF functionality', function () {

        //VM status for real adapter            
        orderObject.servicename = serviceName;
        var status = messageStrings.powerStateOff;
        var val = JSON.stringify({ "IsUsingDummy": "Yes" });
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            browser.executeScript('window.scrollTo(0,0);');
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                   // inventoryPage.placeD2opsOrder();
                    inventoryPage.clickOkForInstanceTurnOFFPermission();
                    inventoryPage.fetchD2opsOrderDetails();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
           orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpComputeInsTemplate.bluePrintName, "TurnOff");
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            //orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provInProgressState);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingTurnOff);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.getComponentTags().then(function (text) {
                    if (val == text) {
                        //Status for dummy adapter
                        status = 'Off';
                        adapterName = "dummy";
                    }
                    //inventoryPage.waitForInstancStateStatusChange(orderObject, status).then(function(){
                    expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe(status);
                    //});                
                });
            });
        });
    });

    it('IMI-Compute Engine-Turn OFF the instance when the VM state is OFF', function () {

        orderObject.servicename = serviceName;
        if (adapterName == "Real") {
            msgToVerify = messageStrings.turnOffNegativeWarningRealAdapter;
        } else {
            msgToVerify = messageStrings.turnOffNegativeWarning;
        }
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                    inventoryPage.placeD2opsOrder();
                    expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(msgToVerify);
                    inventoryPage.clickCustomOpsWarningOKButton();
                });
            });
        });
    });

    it('IMI-Compute Engine-Reboot the instance when the VM state is OFF', function () {
        //var orderObject = {};
        orderObject.servicename = serviceName;
        if (adapterName == "Real") {
            msgToVerify = messageStrings.rebootNegativeWarningrealAdapter;
        } else {
            msgToVerify = messageStrings.rebootNegativeWarning;
        }
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickRebootButtonOfInstance().then(function () {
                    inventoryPage.placeD2opsOrder();
                    expect(inventoryPage.getCustomOpsWarningPopupText()).toBe(msgToVerify);
                    inventoryPage.clickCustomOpsWarningOKButton();
                });
            });
        });
    });

    it('IMI-Compute Engine-Verify instance Turn ON functionality', function () {
        orderObject.servicename = serviceName;
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            browser.executeScript('window.scrollTo(0,0);');
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickTurnONButtonOfInstance().then(function () {
                  //  inventoryPage.placeD2opsOrder();
                    inventoryPage.clickOkForInstanceTurnONPermission();
                    inventoryPage.fetchD2opsOrderDetails(); 
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpComputeInsTemplate.bluePrintName, "TurnOn");
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            //orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provInProgressState);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingTurnOn);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
            });
        });
    });

    it('IMI-Compute Engine-Verify instance Reboot functionality', function () {
        orderObject.servicename = serviceName;
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            browser.executeScript('window.scrollTo(0,0);');
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickRebootButtonOfInstance().then(function () {
                  //  inventoryPage.placeD2opsOrder();
                    inventoryPage.clickOkForInstanceRebootPermission();
                    inventoryPage.fetchD2opsOrderDetails();
                });
            });
        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpComputeInsTemplate.bluePrintName, "Reboot");
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
           // orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.provInProgressState);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(messageStrings.orderTypeAction);
            expect(placeOrderPage.getServiceNameOfferingText()).toBe(messageStrings.serviceOfferingReboot);
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
            });
        });
       
    });

    it('IMI-Compute Engine-Configure IMI Manage service having AddOn', function () {
        
        modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickConfigureImiService();
                inventoryPage.clickOkButnInConfigrImiPopUp();
            });
        });
    
        orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
            //Validate Estimated Cost    
            expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
            //Validate updated BOM table
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
            //Submit order
            placeOrderPage.submitOrder();
            inventoryPage.fetchD2opsOrderDetails();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.customOpsOrderSubmittedMsg);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpComputeInsTemplate.bluePrintName, "ManageServiceAddOn");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();            
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service details
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //Validate BOM on Approve order page
            ordersPage.clickBOMTabImi();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Approve order            
            orderFlowUtil.approveOrder(orderObject);            
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
            
//             ordersHistoryPage.getImiManagedServiceDetails().then(function(imiDetails){
//                expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
//                 expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
//             });

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();

            //Validate Updated BOM on Inventory(AddOn+Manage Service)
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();
            inventoryPage.clickBillOfMaterialsTabOrderDetails();
            //verify estimated cost for Add On
            expect(inventoryPage.getTextEstimatedCost()).toEqual(gcpComputeInsTemplate.TotalCostWithAddOn);
            inventoryPage.clickMoreLinkinBom();
            //Validate BOM table for Add on
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            inventoryPage.clickViewServiceClosebutton();
                       
            //Delete Service flow
            orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, gcpComputeInsTemplate.bluePrintName);
            //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
        });
    });


    it('IMI-Compute Engine-Configure Manage service from Inventory', function () {

        var serviceDetailsMap = {};
        serviceName = "gcp-compute-" + util.getRandomString(5);
        var instanceName = "gcp-intsnace-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Instance Name": instanceName.toLowerCase() };

        orderObject.servicename = serviceName;
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(gcpComputeInsTemplate.bluePrintName);
        //Fill Order Details
        orderFlowUtil.fillOrderDetails(gcpComputeInsTemplate, modifiedParamMap);
        //Submit Order
        placeOrderPage.submitOrder();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpComputeInsTemplate.bluePrintName, "New-ManageServiceInv");
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
        //Validate Estimated price on approve order page
        expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(gcpComputeInsTemplate.EstimatedPriceSingleInstance);

        modifiedParamMap = { "skipRevierOrderValidation": true, "UpdateMainParamObject": false };
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
                inventoryPage.clickConfigureImiService();
                inventoryPage.clickOkButnInConfigrImiPopUp();
            });
        });

        // Delete parameters
//         delete imiConfigTemplate["Order Parameters"]["Configure Add-ons"];
//         delete imiConfigTemplate["Order Parameters"]["IMI Main Parameters"];
//         delete imiConfigTemplate["Order Parameters"]["Review IMI Config"];
        orderFlowUtil.fillOrderDetails(imiManageServiceTemplate, modifiedParamMap).then(function () {
            //Validate Estimated Cost    
            expect(inventoryPage.getTextUpdatedCostConfigureImiManagedService()).toContain(imiConfigTemplate.TotalCost);
            //Validate updated BOM table
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsManagedService(priceMap)).toBe(true);
            //Submit order
            placeOrderPage.submitOrder();
            inventoryPage.fetchD2opsOrderDetails();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.customOpsOrderSubmittedMsg);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(gcpComputeInsTemplate.bluePrintName, "New-ManageServiceInv");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            ordersPage.open();
            //expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service details
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Management level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Management level"));
            expect(ordersPage.getTextBasedOnLabelNameandIndex("Plan level", 0)).toEqual(jsonUtil.getValue(imiConfigTemplate, "Plan level"));
            //Validate BOM on Approve order page
            ordersPage.clickBOMTabImi();
            expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(imiConfigTemplate.TotalCost);
            ordersPage.clickMoreLinkBom();
            var priceMap = {};
            priceMap = { "Managed Cloud Lite (This is the maximum estimated amount)": imiConfigTemplate.ManagedCloudLiteCost, "Monthly billing (This is the maximum estimated amount)": imiConfigTemplate.MonthlyCost }
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();
            //Approve order            
            orderFlowUtil.approveOrder(orderObject);            
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
            //Validate Estimated price on approve order page
            expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(imiConfigTemplate.EstimatedPrice);

            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);

            //Validate Service Details
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Plan level")).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnExactLabelName("Management level")).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
//             ordersHistoryPage.getImiManagedServiceDetails().then(function(imiDetails){
//                expect(imiDetails[0]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.managementLevelKey));
//                 expect(imiDetails[1]).toEqual(jsonUtil.getValue(imiConfigTemplate, imiConfigTemplate.planLevelKey));
//             });

            //Validate Estimated cost on order history page
            ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);

            //Validate BOM table on order history page
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            ordersHistoryPage.closeServiceDetailsSlider();
            //Validate BOM link on order history
            ordersHistoryPage.clickBillOfMaterials();
            expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(imiConfigTemplate.TotalCost);
            ordersHistoryPage.clickMoreLinkBom();
            expect(ordersPage.validateBOMDetailsWithImiAddOn(priceMap)).toBe(true);
            orderFlowUtil.closeHorizontalSliderIfPresent();            

            //Delete Service flow
            orderFlowUtil.deleteService(orderObject).then(async function(orderNo){
             	orderObject.deleteOrderNumber = orderNo;
            	await util.saveOrderId(gcpComputeInsTemplate.bluePrintName, "DeleteManageService", orderNo);
                 orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            });           
           
        });
    });
});
