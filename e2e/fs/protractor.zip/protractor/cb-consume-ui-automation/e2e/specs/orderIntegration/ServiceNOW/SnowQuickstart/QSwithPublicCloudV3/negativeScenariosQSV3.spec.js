"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	OrderHistoryPage = require('../../../../../pageObjects/ordersHistory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	AccountsPage = require('../../../../../pageObjects/account.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	vRACentOS76Temp = require('../../../../../../testData/OrderIntegration/ServiceNOW/CloneCentOS76Snow.json'),
	azureLinuxTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/AzureLinuxVMSnowV3SpecstoSkipIMI.json'),
	awsEC2template = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSEC2InstanceSnowV3SpecstoSkipIMI.json'),
	awsS3Temp = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSS3Snow.json'),
	slSecurityGrpTemplate = require('../../../../../../testData/OrderIntegration/Softlayer/SecurityGroupService.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');

describe('QS: Test cases for V3 Negative Scenarios', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, sampleOrder1, provOrder, instName, orderHistoryPage, policyPage, serviceName, policyName, policyRuleName, groupName, cartListPage, inventoryPage, accountsPage;
	var modifiedParamMapVRA = {};
	var modifiedParamMapAzure = {};
	var modifiedParamMapAWS = {};
	var modifiedParamMapSL = {};
	var modifiedParamMapRetry = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule1 = {};
	var modifiedParamMapAddRule2 = {}; 
	var modifiedParamMapAddRule3 = {}; 
	var modifiedParamMapAddRule4 = {};
	var modifiedParamMapAutoDenyAddRule = {};
	var consumeLaunchpadUrl = url + '/launchpad';
	var vraCentOSObj = JSON.parse(JSON.stringify(vRACentOS76Temp));
	var newResourceGroupName = "gslautotc_azureWVM-RG101" + util.getRandomString(4);
	var newVmName = "auto-VM101" + util.getRandomString(4);
	var newNetworkName = "auto-VN101" + util.getRandomString(4);
	var newSubnetName = "auto-SN101" + util.getRandomString(4);
	var newnetworkSecurityGroupName = "AutoWVM-RG101" + util.getRandomString(4);
	var newNetworkInterfaceName = "auto-NIN101" + util.getRandomString(4);
	var newPublicIpName = "auto-pIPaN101" + util.getRandomString(4);
	var newAvailabilitySetName = "AutoWVM-RG101" + util.getRandomString(4);
	var diskName = "autodisk" + util.getRandomString(4);
    diskName = diskName.toLocaleLowerCase();
    var secGrpName = "SNOWsecGrp"+util.getRandomString(5);
	var azureLinuxObj = JSON.parse(JSON.stringify(azureLinuxTemplate.Scenario1));
	
	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		orderHistoryPage = new OrderHistoryPage();
		accountsPage = new AccountsPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		inventoryPage = new InventoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		groupName = "att-group-" + util.getRandomString(5);
		serviceName = "SNOWQSauto"+util.getRandomString(5);
		policyName = "SNOWQSautoPolicy"+util.getRandomString(5);
		policyRuleName = "SNOWQSautoPolicyRule"+util.getRandomString(5);
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule1 = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["VRA"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
								   "Technical":"Manual Approval","Financial":"Manual Approval","Legal":"External Approval"};
		modifiedParamMapAddRule2 = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["Azure"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
				                   "Technical":"Manual Approval","Legal":"External Approval"};
		modifiedParamMapAddRule3 = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["Amazon"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
				  				   "Technical":"Manual Approval","Financial":"External Approval"};
		modifiedParamMapAddRule4 = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["IBM Cloud"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
				   				   "Technical":"Manual Approval","Financial":"External Approval"};
		modifiedParamMapVRA = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":""};
		modifiedParamMapAzure = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "New Resource Group": newResourceGroupName, "Virtual Machine Name": newVmName, "Virtual Network Name": newNetworkName, "Disk Name": diskName, "Subnet Name": newSubnetName, "Network Interface Name": newNetworkInterfaceName, "Network Security Group Name": newnetworkSecurityGroupName, "Public IP Address Name": newPublicIpName, "Availability Set Name": newAvailabilitySetName };
		modifiedParamMapAWS = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "Provider Account":"AWS-SNOW / AWS-SNOW", "Group Name": groupName};
		modifiedParamMapSL = {"Service Instance Name":serviceName,"Team":"Auto-TEAM1", "Environment":"QA", "Application":"","Provider Account":"SL-Testing / SL-Testing","Security Group Name":secGrpName};
		modifiedParamMapRetry = { "Service Instance Name": serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "Provider Account":"VRA76Retry / VRA76Retry"};
		modifiedParamMapAutoDenyAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["IBM Cloud"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
								"Technical":"Auto Deny","Legal":"External Approval"};

	});
	
	if(isProvisioningRequired == "true") {
		it('Approve all three fields in consume and verify for Manual, Manual and External Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Financial and External Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place a vRA order
	  		var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapVRA);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			
			//Check if order is requested
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			
			//Approve all three fields in Marketplace and validate error
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickFinancialApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickLegalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
			expect(ordersPage.getTextApprovalErrorMsgSNOW()).toBe(vRACentOS76Temp.approvalErrorMsg);
			
			//Delete Manual Technical, Financial and External Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	
		});
	
		it('Deny vRA order in Consume and verify the status for Manual, Manual and External Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Financial and External Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place a vRA order
	  		var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapVRA);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			
			//Check if order is requested
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			
			//Deny Order in Consume
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.denyOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.rejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.rejectedState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestRejectedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteStateQS);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
			
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			
			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).toBe("");
			expect(snowPage.getTextShellCIInRITMPage()).toBe("")
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
		
			//Delete Manual Technical, Financial and External Legal policy
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});
	
		it('Deny VRA order in Consume after approving in SNOW and verify the status for Manual, Auto and External Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Auto Financial and External Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
			//Place a vRA order
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapVRA);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.appInProgressState);
			
			
			//Approve Order in SNOW
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Deny Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.denyOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.rejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.rejectedState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			snowPage.clickBackButton();
			snowPage.clickRequestNumberLink();
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestRejectedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteStateQS);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
			
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).toBe("");
			expect(snowPage.getTextShellCIInRITMPage()).toBe("")
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			
			//Delete Manual Technical, Auto Financial and External Legal policy
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});
		
		it('Reject AWS order in SNOW at Request level after approving in Consume for Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule3);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place a AWS order
	  		var orderObject = {};
	  		catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(awsEC2template.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(awsEC2template.Category);
			catalogPage.clickConfigureButtonBasedOnName(awsEC2template.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(awsEC2template, modifiedParamMapAWS);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
			ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);	
			
			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
			
			//Reject the approval in SNOW
			snowPage.rejectTheServiceNowRequestFromSnowPortal();
			
			//Validations on SNOW Request page after rejecting
			snowPage.clickBackButton();
			snowPage.clickRequestNumberLink();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteStateQS);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).toBe("");
			expect(snowPage.getTextShellCIInRITMPage()).toBe("")
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem)
			
			//Validate in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.rejectedState);
			
			//Delete Manual Technical, External Financial and Auto Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});
		
		it('Cancel VRA order in Consume and verify the status for Manual, Auto and External Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Auto Financial and External Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place a vRA order
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapVRA);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
			
			//Cancel the order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderHistoryPage.searchOrderClickCancelOrder(orderObject.orderNumber);
			orderHistoryPage.clickCancelOrderConfirmationButton();
			expect(orderHistoryPage.getTextCancelOrderSuccessFulMsg()).toContain(vRACentOS76Temp.cancelOrderSuccessMsg);
			orderHistoryPage.clickCancelOrderOkButton();
			expect(orderHistoryPage.getTextCancelOrderStatusInOrderHistory()).toContain(vRACentOS76Temp.cancelledStatus);
			
			//Validations on SNOW Request page after cancelling
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestStateCancelled);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteStateQS);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).toBe("");
			expect(snowPage.getTextShellCIInRITMPage()).toBe("")
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem)
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.cancelledStatus);
			
			//Delete Manual Technical, Auto Financial and External Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});
		
		it('Cancel vRA order in Consume after approving in SNOW and verify the status for Manual, Manual and External Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Financial and External Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place a vRA order
	  		var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapVRA);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			
			//Approve Order in SNOW
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Cancel the order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderHistoryPage.searchOrderClickCancelOrder(orderObject.orderNumber);
			orderHistoryPage.clickCancelOrderConfirmationButton();
			expect(orderHistoryPage.getTextCancelOrderSuccessFulMsg()).toContain(vRACentOS76Temp.cancelOrderSuccessMsg);
			orderHistoryPage.clickCancelOrderOkButton();
			expect(orderHistoryPage.getTextCancelOrderStatusInOrderHistory()).toContain(vRACentOS76Temp.cancelledStatus);
			
			//Validations on SNOW Request page after cancelling
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestStateCancelled);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteStateQS);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).toBe("");
			expect(snowPage.getTextShellCIInRITMPage()).toBe("")
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem)
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.cancelledStatus);
			
			//Delete Manual Technical, Financial and External Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});
		
		it('Cancel AWS order in Consume after approving in Consume for Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule3);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place a AWS order
	  		var orderObject = {};
	  		catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(awsEC2template.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(awsEC2template.Category);
			catalogPage.clickConfigureButtonBasedOnName(awsEC2template.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(awsEC2template, modifiedParamMapAWS);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			
			//Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
		    ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Cancel the order in Marketplace
			orderHistoryPage.searchOrderClickCancelOrder(orderObject.orderNumber);
			orderHistoryPage.clickCancelOrderConfirmationButton();
			expect(orderHistoryPage.getTextCancelOrderSuccessFulMsg()).toContain(vRACentOS76Temp.cancelOrderSuccessMsg);
			orderHistoryPage.clickCancelOrderOkButton();
			expect(orderHistoryPage.getTextCancelOrderStatusInOrderHistory()).toContain(vRACentOS76Temp.cancelledStatus);
			
			//Validations on SNOW Request page after cancelling
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestStateCancelled);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteStateQS);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).toBe("");
			expect(snowPage.getTextShellCIInRITMPage()).toBe("")
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem)
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.cancelledStatus);
			
			//Delete Manual Technical, External Financial and Auto Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});	
		
		it('Reject the vRA order approval in SNOW at Change Request level for Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapVRA);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			
			//Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickFinancialApprovalCheckBoxOrderApprovalModal();
		    ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Reject the approval in SNOW
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			snowPage.enterChangeReqValues();
			snowPage.enterPlanningValues();
			snowPage.enterScheduleValues();
			snowPage.clickCalculateRiskLink();
			snowPage.clickAssessButton();
			snowPage.rejectChangeRequest();
			
			//Validations on SNOW Requested Item page after rejecting
			snowPage.clickBackButton();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	
			
			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			//Validation on Catalog Task page after rejecting
			snowPage.clickCatalogTaskLink();

			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickBackButton();
			
			//Validations on SNOW Request page after rejecting
			snowPage.clickBackButton();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteStateQS);			
			
			//Validate in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.cancelledStatus);
			
			//Delete Manual Technical, External Financial and Auto Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
	    });	
		
		it('Provision a vRA service and place an order for turn off without running discovery in SNOW for Manual, External and Auto Policy', function () {
			

			//Enable Discovery Property flag
			snowPage.loginToSnowQSICDSPortal();
			snowPage.setQSflag(snowInstanceTemplate.snowDiscoveryProperty,snowInstanceTemplate.snowPropertyValueTrue);
			expect(snowPage.getTextValuePropertyQS()).toBe(snowInstanceTemplate.snowPropertyValueTrue);
			snowPage.clickUpdateButton();
				
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place an order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapVRA);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			
			//Validations on SNOW Request page before approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalNotRequested);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickFinancialApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickApproveButtonOrderApprovalModal();
			ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.appInProgressState);			
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Order Completion in SNOW
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			//snowPage.clickImplementButtonQS();
			snowPage.checkIfProvisioningTaskClosed();
			//snowPage.clickBackButton();
			//snowPage.openRelatedChangeRequest();
			//snowPage.clickCloseChangeRequestButton();
			//snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
			
			//Place an order for Turn Off in Marketplace
			inventoryPage.open();
			orderObject.servicename = serviceName;
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA(vRACentOS76Temp.componentType).then(function () {
	                inventoryPage.clickTurnOFFButtonOfInstanceSNOW().then(function () {
	                    inventoryPage.clickOkForInstanceTurnOFFPermission();
	                });
	            });
	        }).then(function () {
	            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
	            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
	            sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	            inventoryPage.clickOkForCustomOpnOrderButton();
	            orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.rejectedState);
	            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.rejectedState);
	        });
	        
	        //Verify in SNOW
            snowPage.logInToSnowQuickstartPortalAndSearchOrderNotExists(sampleOrder1);
			expect(snowPage.getTextOrderNotExists()).toBe(snowInstanceTemplate.orderNotExistsMessage);	  
			
			//Delete Manual Technical, External Financial and Auto Legal policy
			browser.get(consumeLaunchpadUrl);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
			expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	 
			  

			//Disable Discovery Property flag
			snowPage.loginToSnowQSICDSPortal();
			snowPage.setQSflag(snowInstanceTemplate.snowDiscoveryProperty,snowInstanceTemplate.snowPropertyValueFalse);
			expect(snowPage.getTextValuePropertyQS()).toBe(snowInstanceTemplate.snowPropertyValueFalse);
			snowPage.clickUpdateButton();
		});

		
		it('Place a vRA order by not uploading custom policy for vRA for Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Normal in SNOW
			expect(snowAPI.setCustomPolicyForAzureAWSNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapVRA);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.rejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(vRACentOS76Temp.rejectedState);
			
			//Verify in SNOW
            snowPage.logInToSnowQuickstartPortalAndSearchOrderNotExists(provOrder);
			expect(snowPage.getTextOrderNotExists()).toBe(snowInstanceTemplate.orderNotExistsMessage);	 
			
			//Delete Manual Technical, External Financial and Auto Legal policy
			browser.get(consumeLaunchpadUrl);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	 
		});
		
		it('Place an IBM Cloud order by not uploading custom policy for IBM Cloud for Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Normal in SNOW
			expect(snowAPI.setCustomPolicyForAzureAWSNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule4);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":sampleOrder1};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,slSecurityGrpTemplate.rejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(slSecurityGrpTemplate.rejectedState);
			
			//Verify in SNOW
            snowPage.logInToSnowQuickstartPortalAndSearchOrderNotExists(sampleOrder1);
			expect(snowPage.getTextOrderNotExists()).toBe(snowInstanceTemplate.orderNotExistsMessage);
			
			//Delete Manual Technical, External Financial and Auto Legal policy
			browser.get(consumeLaunchpadUrl);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	
		});
		
		it('Fail the VRA order, Retry and when retry fails again cancel the order for Manual, External and Auto Policy', function () {
			
		//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
			catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapRetry);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.appInProgressState);
			
			//Validations on SNOW Request page before approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);

			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickFinancialApprovalCheckBoxOrderApprovalModal();
		    ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();

			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsS3Temp.failedState);

			//Validations in SNOW after provision failed
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);	
			
			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			//Order Completion in SNOW
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextChangeTaskFirstActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);

			snowPage.openIncident();
			expect(snowPage.getTextIncidentNumber()).not.toBe("");
			var incidentNumber = snowPage.getTextIncidentNumber();
			expect(snowPage.getTextIncidentState()).toBe(snowInstanceTemplate.snowIncidentStateInProg);
			expect(snowPage.getTextIncAssignmentGroup()).toBe(snowInstanceTemplate.snowIncidentAssignGrp);
			expect(snowPage.getTextShellCIInIncidentPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextIncShortDesc()).toMatch(snowInstanceTemplate.snowChangeTaskActivity);
			snowPage.clickNotesTab();
			expect(snowPage.getTextChangeTaskFirstActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);
			
			//Retry the order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderHistoryPage.searchOrderClickRetry(provOrder);
	        expect(orderHistoryPage.verifyOrderTableActionsRetryModelSuccessMsgVisibility()).toMatch(awsS3Temp.retrySuccessMsg);
	        orderHistoryPage.clickOnOrderTableActionsRetryModelOkButton();
	        orderFlowUtil.waitForOrderStatusChange(orderObject,awsS3Temp.failedState);
	        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsS3Temp.failedState);
	        
	        //Validations in SNOW after provision failed again
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				
			snowPage.openRelatedChangeRequest();

			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextChangeTaskSecondActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);

			snowPage.openIncident();
			snowPage.clickNotesTab();
			expect(snowPage.getTextChangeTaskSecondActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);
						
			//Cancel the order in Marketplace	
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderHistoryPage.searchOrderClickCancel(provOrder);
			expect(orderHistoryPage.getTextCancelOrderSuccessFulMsg()).toMatch(vRACentOS76Temp.cancelFailedOrderSuccessMsg);
			orderHistoryPage.clickOnOrderTableActionsCancelModelOkButton();
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsS3Temp.cancelledStatus);
	
			
			//Validations in SNOW after order is closed
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteStateQS);

			expect(snowPage.getTextRequestNumberInRequestPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);

			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).toEqual(ritmNumber);
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).toEqual(changeRequestNumber);
			expect(snowPage.getTextShellCIInRITMPage()).toEqual(cmdbShellCIName);

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toContain(snowInstanceTemplate.snowReqItemVariablesSerOfferDescVRA);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);

			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDVRACentOS76);

			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderVRA);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			
			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
			expect(snowPage.getTextLabelsRITMVariable()).not.toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe("");
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe("");
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();

			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			
			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickBackButton();

			snowPage.openRelatedChangeRequest();
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.snowChangeTaskStateCancelled);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);	

			snowPage.openIncident();
			expect(snowPage.getTextIncidentNumber()).toBe(incidentNumber);
			expect(snowPage.getTextShellCIInIncidentPage()).toEqual(cmdbShellCIName);
			snowPage.clickNotesTab();
			expect(snowPage.getTextIncidentState()).toBe(snowInstanceTemplate.snowIncidentStateResolved);
			expect(snowPage.getTextIncShortDesc()).toBe(snowInstanceTemplate.snowIncidentShortDescCancelled);
			snowPage.clickIncResolutionInfoTab();
			expect(snowPage.getTextIncResCode()).toBe(snowInstanceTemplate.snowIncidentResCodeNotSolved);
			expect(snowPage.getTextIncResNotes()).toBe(snowInstanceTemplate.snowIncidentResNotesNotsolved);
			
			//Delete Manual Technical, External Financial and Auto Legal policy
			browser.get(consumeLaunchpadUrl);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);		
	    });	
		
		it('Fail the vRA order, Retry and verify the status after retry is successful for Manual, Manual and Auto Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, Manual Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule1);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place Order in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(vRACentOS76Temp.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(vRACentOS76Temp.Category);
			catalogPage.clickConfigureButtonBasedOnName(vRACentOS76Temp.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(vRACentOS76Temp, modifiedParamMapRetry);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vRACentOS76Temp.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":provOrder};	
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.appInProgressState);
			
			//Approve Order in Marketplace
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
			ordersPage.clickFinancialApprovalCheckBoxOrderApprovalModal();
		    ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(vRACentOS76Temp.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();
			
			//Order Completion in SNOW
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);	
			
			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.failedState);
			
			//Validations in SNOW after provision failed
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);

			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);	
			
			expect(snowPage.getTextRITMNumberInRITMPage()).toBe(ritmNumber);
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).toBe(changeRequestNumber);
			expect(snowPage.getTextShellCIInRITMPage()).toBe(cmdbShellCIName);
	
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			snowPage.clickBackButton();

			snowPage.openRelatedChangeRequest();
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextChangeTaskFirstActivity()).toBe(snowInstanceTemplate.snowChangeTaskActivity);
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskState()).toBe(snowInstanceTemplate.snowRequestedItemStatePending);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			expect(snowPage.getTextChangeTaskFirstActivity()).toContain(snowInstanceTemplate.snowChangeTaskActivity);			
			
			snowPage.openIncident();
			expect(snowPage.getTextIncidentNumber()).not.toBe("");
			var incidentNumber = snowPage.getTextIncidentNumber();
			expect(snowPage.getTextIncidentState()).toBe(snowInstanceTemplate.snowIncidentStateInProg);
			expect(snowPage.getTextIncAssignmentGroup()).toBe(snowInstanceTemplate.snowIncidentAssignGrp);
			expect(snowPage.getTextShellCIInIncidentPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextIncShortDesc()).toContain(snowInstanceTemplate.snowChangeTaskActivity);
			snowPage.clickNotesTab();
			expect(snowPage.getTextChangeTaskFirstActivity()).toContain(snowInstanceTemplate.snowChangeTaskActivity);
			
			//Retry the order in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			accountsPage.editAccountDetails(vRACentOS76Temp.retryProviderAcct);
		    accountsPage.enterEndpointUrlVRATextbox(vRACentOS76Temp.validEndpointUrl);
		    accountsPage.clickSaveAccountDetailsButton();
		    expect(accountsPage.getEditSuccessMsgText()).toMatch(vRACentOS76Temp.editSuccessMsg);
			orderHistoryPage.searchOrderClickRetry(provOrder);
	        expect(orderHistoryPage.verifyOrderTableActionsRetryModelSuccessMsgVisibility()).toMatch(vRACentOS76Temp.retrySuccessMsg);
	        orderHistoryPage.clickOnOrderTableActionsRetryModelOkButton();
	        orderFlowUtil.waitForOrderStatusChange(orderObject,vRACentOS76Temp.provInProgressState);
	        expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.provInProgressState);
	        
	        //Provisioning task close in SNOW
	        snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			snowPage.openRelatedChangeRequest();
			snowPage.clickChangeTaskTabInChangeRequest();
			snowPage.waitForProvisioningTaskChange(snowInstanceTemplate.snowChangeRequestStateClose);
			
			//Validation in SNOW after task is closed
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickClosureInfoInChangeTask();
			expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			expect(snowPage.getTextChangeTaskFirstActivity()).toContain(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			
			snowPage.openIncident();
			expect(snowPage.getTextIncidentNumber()).toBe(incidentNumber);
			expect(snowPage.getTextIncidentState()).toBe(snowInstanceTemplate.snowIncidentStateResolved);
			expect(snowPage.getTextShellCIInIncidentPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextIncShortDesc()).toContain(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			snowPage.clickNotesTab();
			expect(snowPage.getTextChangeTaskFirstActivity()).toContain(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			snowPage.clickBackButton();
			snowPage.clickBackButton();
			
			//Order completion in SNOW
			snowPage.openRelatedChangeRequest();
			snowPage.openChangeTask();
			snowPage.openIncident();
			expect(snowPage.getTextIncidentState()).toBe(snowInstanceTemplate.snowIncidentStateResolved);
			snowPage.clickIncResolutionInfoTab();
			expect(snowPage.getTextIncResCode()).toBe(snowInstanceTemplate.snowIncidentResCodeSolved);
			expect(snowPage.getTextIncResNotes()).toBe(snowInstanceTemplate.snowIncidentResNotesResolved);
			
			//Validations in SNOW after order is closed
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe("");
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe("");
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();		
			
			snowPage.clickCatalogTaskLink();
			
			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickBackButton();
			
			//Validation in Marketplace after order is completed
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.completedState);
			
			accountsPage.editAccountDetails(vRACentOS76Temp.retryProviderAcct);
		    accountsPage.enterEndpointUrlVRATextbox(vRACentOS76Temp.invalidEndpointUrl);
		    accountsPage.clickSaveAccountDetailsButton();
		    expect(accountsPage.getEditSuccessMsgText()).toMatch(vRACentOS76Temp.editSuccessMsg);	
		    
		    //Delete Manual Technical, External Financial and Auto Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);		
	    });	
		
		it('Cancel change IBM Cloud order for Normal type at Change request level and verify the status for Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Normal in SNOW
			expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule4);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place a SL order
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);	
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":sampleOrder1};	

			//Validations on SNOW Request page before approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
		    ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
		

			//Validations on SNOW Request page before approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();

			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.provInProgressState);

			//Validations on SNOW Request page before approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
			
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			
			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("")
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);

			//Cancel Change
			snowPage.openRelatedChangeRequest();
			snowPage.enterChangeReqValues();
			snowPage.enterPlanningValues();
			snowPage.enterScheduleValues();
			snowPage.clickCalculateRiskLink();
			snowPage.cancelChangeWithReason();
			snowPage.clickNotesTab();
			snowPage.enterAdditionalCommentsText();
			snowPage.cancelChangeWithReason();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.cancelledStatus);
			
			//Validation in SNOW after cancelling the change
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteStateQS);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			snowPage.clickBackButton();
			snowPage.openRelatedChangeRequest();
			expect(snowPage.getTextChangeReqStateQS()).toContain(snowInstanceTemplate.snowChangeTaskStateCancelled);
			snowPage.openChangeTask();
			expect(snowPage.getTextChangeTaskState()).toBe(snowInstanceTemplate.snowChangeTaskStateCancelled);	
			
			//Delete Manual Technical, External Financial and Auto Legal policy
			browser.get(consumeLaunchpadUrl);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);
		});
		
		it('Verify if Cancel Change option for IBM Cloud order is displayed until Scheduled state and not displayed at Implement state for Normal type', function () {
			
			//Set Change Request type to Normal in SNOW
			expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule4);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
			
			//Place a SL order
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);	
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":sampleOrder1};	
			
			//Validations on SNOW Request page before approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
			
			//Approve Order in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.approveOrderButtonSNOW(orderObject);
			ordersPage.clickTechnicalApprovalCheckBoxOrderApprovalModal();
		    ordersPage.clickApproveButtonOrderApprovalModal();
		    ordersPage.clickCancelButtonOrderApprovalModal();
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			//Validations on SNOW Request page after approval in Marketplace
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			
			//Approve Order in SNOW
			snowPage.approveTheServiceNowRequestFromSnowPortal();

			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(vRACentOS76Temp.provInProgressState);
			
			//Validations on SNOW Request page before approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);

			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			
			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("")
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);

			//Verify Cancel Change option at New state
			snowPage.openRelatedChangeRequest();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateNew);
			snowPage.rightClickNavbarTitle();
			expect(snowPage.isPresentCancelChange()).toBe(true);
			snowPage.clickChangeRequestCurrentStateQS();
			
			//Assess state
			snowPage.enterChangeReqValues();
			snowPage.enterPlanningValues();
			snowPage.enterScheduleValues();
			snowPage.clickCalculateRiskLink();
			snowPage.clickAssessButton();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.rightClickNavbarTitle();
			expect(snowPage.isPresentCancelChange()).toBe(true);
			
			//Authorize state
			snowPage.clickRequestApprovalInChangeRequestPage();
			snowPage.approveChangeRequestForEachState();
			snowPage.approveRequestQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateAuthorize);
			snowPage.rightClickNavbarTitle();
			expect(snowPage.isPresentCancelChange()).toBe(true);
			
			//Scheduled state
			snowPage.approveRequestQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.rightClickNavbarTitle();
			expect(snowPage.isPresentCancelChange()).toBe(true);
			
			//Implement state
			snowPage.rightClickOnCMDBCIFormHeader();
			var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
			sysidofChangeRequest.then(function(sysidofChangeRequestValue){
			var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
			setChangeRequesttoImplementState.then(function(statuscode){
			expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			});

			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.rightClickNavbarTitle();
			expect(snowPage.isPresentCancelChange()).toBe(false);	
			
			//Delete Manual Technical, External Financial and Auto Legal policy
			browser.get(consumeLaunchpadUrl);
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);
		});
	});

		it('Reject IBMCLOUD order in SNOW at Request level Manual, External and Auto Policy', function () {
			
			//Set Change Request type to Standard in SNOW
			expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			
			//Create Manual Technical, External Financial and Auto Legal policy
			policyPage.open();
	  		policyPage.clickAddNewPolicyBtn();
	  		policyPage.selectStartDate();
	  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
	  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule4);
	  		policyPage.selectExternalApprovalDropdownSNOW();
	  		policyPage.clickApplyRulePolicyBtn();
	  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
	  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
	  		policyPage.clickCreatePolicyButton();
	  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
	  		policyPage.clickNotificationCloseButton();
	  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
	  		expect(policyNameInPolicyTable).toEqual(policyName);
	  		
	  		//Place a SL order
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);	
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
			catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":sampleOrder1};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,awsEC2template.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(awsEC2template.appInProgressState);
			
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(true);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestAfterFirstApproval);	

			//Reject the approval in SNOW
			snowPage.rejectTheServiceNowRequestFromSnowPortal();

			//Validations on SNOW Request page after rejecting
			snowPage.clickBackButton();
			snowPage.clickRequestNumberLink();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteStateQS);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);	

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).toBe("");
			expect(snowPage.getTextShellCIInRITMPage()).toBe("")
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem)
			
			//Validate in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.rejectedState);
			
			//Delete Manual Technical, External Financial and Auto Legal policy
		  	policyPage.open();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickPolicyViewDetailButton();
		  	policyPage.clickRadioButtonRetiredOption();
		  	policyPage.clickUpdatePolicyBtn();
		  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	policyPage.clickPolicyDetailIcon();
		  	policyPage.clickButtonDeletePolicyText();
		  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		  	util.waitForAngular();
		  	policyPage.searchPolicyInPolicyTextbox(policyName);
		  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);	  		
		});
		
		it('IBMCLOUD E2E cases for Auto Deny Technical, Auto Financial and External Legal Approval with Standard change', function () {
		
		//Set Change Request type to Standard in SNOW
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));

		//Create Approval Policy for IBMCLOUD with Auto Deny Technical, Auto Financial and External Legal Approval and Standard change'
			policyPage.open();
			policyPage.clickAddNewPolicyBtn();
			policyPage.selectStartDate();
			policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
			policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAutoDenyAddRule);
			policyPage.selectExternalApprovalDropdownSNOW();
			policyPage.clickApplyRulePolicyBtn();
			var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
			expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
			policyPage.clickCreatePolicyButton();
			expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
			policyPage.clickNotificationCloseButton();
			var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
			expect(policyNameInPolicyTable).toEqual(policyName);

	
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMapSL);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderObject = {"orderNumber":sampleOrder1};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,slSecurityGrpTemplate.rejectedState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(slSecurityGrpTemplate.rejectedState);
				
			//Validations on SNOW Request page
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestRejectedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalRejected);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestIncompleteStateQS);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLocV3QS);

			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStageCancelled);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestIncompleteState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			

		 //Delete Approval Policy for IBMCLOUD with Auto Deny Technical, Auto Financial and External Legal Approval and Normal change
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			  policyPage.open();
			  util.waitForAngular();
			  policyPage.searchPolicyInPolicyTextbox(policyName);
			  policyPage.clickPolicyDetailIcon();
			  policyPage.clickPolicyViewDetailButton();
			  policyPage.clickRadioButtonRetiredOption();
			  policyPage.clickUpdatePolicyBtn();
			  expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
			  var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
			  expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
			  policyPage.searchPolicyInPolicyTextbox(policyName);
			  policyPage.clickPolicyDetailIcon();
			  policyPage.clickButtonDeletePolicyText();
			  policyPage.clickDeleteConfirmationPopUpPolicyBtn();
			  util.waitForAngular();
			  policyPage.searchPolicyInPolicyTextbox(policyName);
			  expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

		});

	}
});
	
	
	
