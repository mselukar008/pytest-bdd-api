/*
Spec_Name: eventHub.spec.js 
Description: This spec will cover E2E testing of Event Hub service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
        async = require('async'),
        logGenerator = require("../../../../helpers/logGenerator.js"),
        logger = logGenerator.getApplicationLogger(),
        CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
        CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
        PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
        InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
        CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
        isProvisioningRequired = browser.params.isProvisioningRequired,
        isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
        appUrls = require('../../../../testData/appUrls.json'),
        util = require('../../../../helpers/util.js'),
        jsonUtil = require('../../../../helpers/jsonUtil.js'),
        orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
        EHTemplate = require('../../../../testData/OrderIntegration/Azure/eh.json');

describe('Azure - Event Hub', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, cartListPage, catalogDetailsPage;
        var modifiedParamMap = {};
        var modifiedParamMapedit = {};
        var messageStrings = { providerName: 'Azure', category: 'Other Services' , disabledState: EHTemplate.disabledState };
        var modifiedParamMap = {};
        var servicename = "AutoEHsrv" + util.getRandomString(5);
        var rgName = "gslautotc_azureEHRG101" + util.getRandomString(5);
        var ehName = "autoEH" + util.getRandomString(5);
        var SOIComponents;
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Event Hub Namespace Name": ehName };
        beforeAll(function () {
                ordersPage = new Orders();
                catalogPage = new CatalogPage();
                placeOrderPage = new PlaceOrderPage();
                inventoryPage = new InventoryPage();
                cartListPage = new CartListPage();
                catalogDetailsPage = new CatalogDetailsPage();
                browser.driver.manage().window().maximize();
        });

        beforeEach(function () {
                catalogPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
                catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
                rgName = "gslautotc_azureEHRG101" + util.getRandomString(5);
                ehName = "autoEH" + util.getRandomString(5);
                modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": rgName, "Event Hub Namespace Name": ehName };
                SOIComponents = [ehName]
        });
        afterAll(function () {
                // Delete Event Hub
                  var returnObj = {};
                  returnObj.servicename = servicename;
                  returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
                  orderFlowUtil.approveDeletedOrder(returnObj);
                  orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
                  expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
          });

        //E2E Event Hub order Submit, Approve, Delete Service with New Resource Group.
        if (isProvisioningRequired == "true") {
                it('Azure: TC-T395401 Verify if Event Hub with new resource group, Standard pricing tier, valid throughput units, enabled auto-inflate and valid specify_upper_limit is created successfully', function () {
                        var orderObject = JSON.parse(JSON.stringify(EHTemplate));
                        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                        catalogPage.searchForBluePrint(orderObject.bluePrintName);
                        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                        var returnObj = {};
                        var returnObj1 = {};
                        orderFlowUtil.fillOrderDetails(EHTemplate, modifiedParamMap);
                        placeOrderPage.submitOrder();
                        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        returnObj.servicename = servicename;
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj);
                        orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed');
                        inventoryPage.open();
                        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
                        inventoryPage.searchOrderByServiceName(returnObj.servicename);
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
                        inventoryPage.clickViewService();
                        //Checking Inventory Page Service Configuration
                        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));                       
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Event Hub Namespace Name:")).toEqual(ehName);
                        expect(inventoryPage.getTextBasedOnLabelName(" Event Hub Namespace Location:")).toEqual(jsonUtil.getValue(orderObject, "Event Hub Namespace Location"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Pricing Tier:")).toEqual(jsonUtil.getValue(orderObject, "Pricing Tier"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Throughput Units:")).toEqual(jsonUtil.getValue(orderObject, "Throughput Units"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Enable Auto Inflate:")).toEqual(jsonUtil.getValue(orderObject, "Enable Auto Inflate"));
                        expect(inventoryPage.getTextBasedOnLabelName(" Specify Upper Limit:")).toEqual(jsonUtil.getValue(orderObject, "Specify Upper Limit"));
                        inventoryPage.closeViewDetailsTab();
                        //Checking SOI Components
                        if (isDummyAdapterDisabled == "true") {
                                inventoryPage.clickExpandFirstRow().then(function () {
                                        browser.executeScript('window.scrollTo(0,0);');
                                        var i = 1;
                                        async.forEachSeries(SOIComponents, function (component, callback) {
                                                inventoryPage.clickOverMenuIcon(i).then(function () {
                                                        inventoryPage.clickOnViewComponent(i).then(function () {
                                                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.mcmpTag);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(orderObject.bluePrintName);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                                                expect(inventoryPage.getTagsOnInventory()).toContain(rgName);
                                                                inventoryPage.closeViewComponent();
                                                                browser.sleep(10000);
                                                                i++;
                                                                return callback();
                                                        });
                                                })
                                        }, function (error) {
                                                if (error) {
                                                        logger.info('Unable to Get SOI component')
                                                }
                                        })
                                })
                        }
                        //Edit order flow
                        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click();
                        inventoryPage.clickEditServiceIcon();
                        util.waitForAngular();
                        // Validate if main parameters are disabled during edit service
                        expect(cartListPage.isEnabledInstancePrefixTextbox()).toMatch(messageStrings.disabledState);
                        expect(cartListPage.isDisplayedEnvDropdown()).toBe(false);
                        expect(cartListPage.isDisplayedAppDropdown()).toBe(false);
                        expect(cartListPage.isDisplayedTeamRadioButton()).toBe(false);
                        expect(cartListPage.isDisabledProviderAccount()).toBe(true);
                        modifiedParamMapedit = { "Service Instance Name": servicename, "EditService": true };
                        orderFlowUtil.fillOrderDetails(EHTemplate, modifiedParamMapedit);
                        placeOrderPage.submitOrder();
                        returnObj1.servicename = servicename;
                        returnObj1.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                        returnObj1.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
                        //Open Order page and Approve Order 
                        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
                        orderFlowUtil.approveOrder(returnObj1);
                        orderFlowUtil.waitForOrderStatusChange(returnObj1, 'Completed', 50);
                });
        }

        //Checking parameters on Main Parameters page
        it('Azure: TC-T383471 verify that for Event Hub Service all parameters on Main Parameters Page are present.', function () {
                var orderObject = JSON.parse(JSON.stringify(EHTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.searchForBluePrint(orderObject.bluePrintName);
                catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
                if (browser.params.defaultCurrency == "USD") {
                expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
                }

        });

      //Checking values all parameters on Review Order Page and View Order Details
        it('Azure: TC-T383495 verify that for Event Hub Service all values on Review Order Page and View Order Details page matches with input.', function () {
                var returnObj = {};
                returnObj.servicename = servicename;
                var orderObject = JSON.parse(JSON.stringify(EHTemplate));
                catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
                catalogPage.searchForBluePrint(orderObject.bluePrintName);
                catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
                orderFlowUtil.fillOrderDetails(EHTemplate, modifiedParamMap);
                //Checking Service Details in ReviewOrder
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
                if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
                }
                //Checking Additional Details in ReviewOrder
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Event Hub Namespace Name:")).toEqual(ehName);
                expect(placeOrderPage.getTextBasedOnLabelName(" Event Hub Namespace Location:")).toEqual(jsonUtil.getValue(orderObject, "Event Hub Namespace Location"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Pricing Tier:")).toEqual(jsonUtil.getValue(orderObject, "Pricing Tier"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Throughput Units:")).toEqual(jsonUtil.getValue(orderObject, "Throughput Units"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Enable Auto Inflate:")).toEqual(jsonUtil.getValue(orderObject, "Enable Auto Inflate"));
                expect(placeOrderPage.getTextBasedOnLabelName(" Specify Upper Limit:")).toEqual(jsonUtil.getValue(orderObject, "Specify Upper Limit"));
                placeOrderPage.submitOrder();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                ordersPage.open();
                ordersPage.searchOrderById(returnObj.orderNumber);
                ordersPage.clickFirstViewDetailsOrdersTable();
                //Checking Order Details in View order details
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
                //Checking Service Configuration Parameters
                ordersPage.clickServiceConfigurationsTabOrderDetails();
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
                expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName);
                expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Event Hub Namespace Name")).toEqual(ehName);
                expect(ordersPage.getTextBasedOnExactLabelName("Event Hub Namespace Location")).toEqual(jsonUtil.getValue(orderObject, "Event Hub Namespace Location"));
                expect(ordersPage.getTextBasedOnExactLabelName("Pricing Tier")).toEqual(jsonUtil.getValue(orderObject, "Pricing Tier"));
                expect(ordersPage.getTextBasedOnExactLabelName("Throughput Units")).toEqual(jsonUtil.getValue(orderObject, "Throughput Units"));
                expect(ordersPage.getTextBasedOnExactLabelName("Enable Auto Inflate")).toEqual(jsonUtil.getValue(orderObject, "Enable Auto Inflate"));
                expect(ordersPage.getTextBasedOnExactLabelName("Specify Upper Limit")).toEqual(jsonUtil.getValue(orderObject, "Specify Upper Limit"));
                //Checking Bill Of Material
                if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
                }
                ordersPage.clickServiceDetailSliderCloseButton();
        });
});
