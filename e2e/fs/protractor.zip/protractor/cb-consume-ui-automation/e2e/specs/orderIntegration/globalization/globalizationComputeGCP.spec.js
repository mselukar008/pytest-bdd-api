"use strict";

var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    logGenerator = require("../../../../helpers/logGenerator.js"),
    BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),
    PolicyPage = require('../../../pageObjects/policy.pageObject.js'),
    OperationsPolicy = require('../../../pageObjects/operationsPolicy.pageObject.js'),
    UserAccsmangmntPage = require('../../../pageObjects/userAccessManagement.pageObject.js'),
    logger = logGenerator.getApplicationLogger(),
    gcpComputeInsTemplate = require('../../../../testData/OrderIntegration/Google/gcpComputeIns.json');
    

describe('GCP - Compute Engine', function () {
    var ordersPage,catalogPage, placeOrderPage, inventoryPage, serviceName,currencyConversionPage,budgetryPage,policyPage,operationPolicyPage,userAccsMangmntPage;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName:       gcpComputeInsTemplate.provider,
        mainParameterPage:  gcpComputeInsTemplate.mainParameterPage,
       	submitOrderPage:    gcpComputeInsTemplate.submitOrderPage,
       	approveOrderPage:   gcpComputeInsTemplate.approveOrderPage,
       	orderSubmittedPopUp:gcpComputeInsTemplate.orderSubmittedPopUp,
   		orderHistoryPage:   gcpComputeInsTemplate.orderHistoryPage,
       	inventoryPage:      gcpComputeInsTemplate.inventoryPage,
       	catalogPage:        gcpComputeInsTemplate.catalogPage,
       	budgetaryPage:      gcpComputeInsTemplate.budgetaryPage,
        completedStatus:    gcpComputeInsTemplate.completedStatus,
        approvePolicyPage:  gcpComputeInsTemplate.approvePolicyPage,
        operationPolicyPage:gcpComputeInsTemplate.operationPolicyPage,
        userAccessMgm_organizationTab:gcpComputeInsTemplate.userAccessMgm_organizationTab,
        userAccessMgm_TeamTab:gcpComputeInsTemplate.userAccessMgm_TeamTab
    };	       		
      
        var orderObjectVm = {};
        beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        budgetryPage = new BudgetaryPage();
        policyPage = new PolicyPage();
        operationPolicyPage = new OperationsPolicy();
        userAccsMangmntPage = new UserAccsmangmntPage();
        browser.driver.manage().window().maximize();       
        
    });

        beforeEach(function () {
        catalogPage.open();
        util.getPageSource(messageStrings.catalogPage);
        serviceName = "att-compute-engine-" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName};        
    });
        

   it('GCP Compute Service- Dump html content for every page in a specific directory ', function () {
        
    	orderObjectVm.servicename = serviceName;
    	var orderObject = {};
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickConfigureButtonBasedOnName(gcpComputeInsTemplate.bluePrintName);
        util.getAllWebElements();
        util.getPageSource(messageStrings.mainParameterPage);
     	orderObjectVm.servicename = serviceName;
        orderFlowUtil.fillOrderDetails(gcpComputeInsTemplate, modifiedParamMap).then(function (requiredReturnMap) {
        util.getAllWebElements();
        util.getPageSource(messageStrings.submitOrderPage);
	    });
        placeOrderPage.submitOrder();
        util.getAllWebElements();
        util.getPageSource(messageStrings.approveOrderPage);
        orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        util.getAllWebElements();
        util.getPageSource(messageStrings.orderSubmittedPopUp);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObjectVm);
        util.getAllWebElements();
        util.getPageSource(messageStrings.orderHistoryPage);
        orderFlowUtil.getCompletedColorStatus(orderObjectVm, messageStrings.completedStatus); 
        orderObjectVm.deleteOrderNumber = orderFlowUtil.deleteServiceFromInventory(orderObjectVm);
        util.getPageSource(messageStrings.inventoryPage);
        orderFlowUtil.approveDeletedOrder(orderObjectVm);
        budgetryPage.open();
        util.getPageSource(messageStrings.budgetaryPage);
        policyPage.open();
        util.getPageSource(messageStrings.approvePolicyPage);
        operationPolicyPage.open();
        util.getPageSource(messageStrings.operationPolicyPage);
        userAccsMangmntPage.open();
        util.getPageSource(messageStrings.userAccessMgm_organizationTab);
       // userAccsMangmntPage.clickTeamsLink();
       // util.getPageSource(messageStrings.userAccessMgm_TeamTab);
     });
})      

