"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	gcpPubSubTemplate = require('../../../../../../testData/OrderIntegration/Google/pubsub.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('QS: Google E2E cases for Auto Technical, Financial and Legal approval with Standard change', function() {
	var ordersPage, catalogPage, placeOrderPage, policyPage, snowPage, sampleOrder1, inventoryPage, cartListPage;
	var modifiedParamMap = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var serviceName = "SNOWQSauto"+util.getRandomString(5);
	var policyName = "SNOWQSautoGooglePolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWQSautoGooglePolicyRule"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var topicName = "autom-" + util.getRandomString(5).toLowerCase();
    var suscrpName = "autom-" + util.getRandomString(5).toLowerCase();

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted"],"Provider":["Google"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":""};
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"","Name": topicName};
	});

	afterAll(function() {
		//Delete Approval Policy
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);
		  
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});
	
	it('Set Change Request type to Standard in SNOW', function () {
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Approval Policy for Google with Auto Technical, Financial, Legal approval and Standard change', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('Google: Pub/Sub ---- Verify Provision functionality with Auto Technical, Financial, Legal approval and Standard change', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(gcpPubSubTemplate.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(gcpPubSubTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(gcpPubSubTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(gcpPubSubTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(gcpPubSubTemplate.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":sampleOrder1};	
			
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(gcpPubSubTemplate.provInProgressState);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			}
			expect(snowPage.getTextShortDescription()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			}
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			}
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();
			//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
					
			//Order Completion in SNOW
			//snowPage.clickImplementButtonQS();
			snowPage.checkIfProvisioningTaskClosed();
			/*snowPage.clickBackButton();
			snowPage.openRelatedChangeRequest();
			snowPage.clickCloseChangeRequestButton();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(gcpPubSubTemplate.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			
		  });		
	    });
	
		it('Google: Pub/Sub ---- Verify Edit functionality with Auto Technical, Financial, Legal approval and Standard change', function () {
		
			//Place Order for Edit in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			modifiedParamMap = {"Service Instance Name":"","Team":"","Environment":"","Application":"","Provider Account":"","Name":"","Add Subscription": "click", "Subscription Name": suscrpName, "Delivery Type": "Pull" };
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.editService(orderObject);
			orderFlowUtil.fillOrderDetails(gcpPubSubTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(gcpPubSubTemplate.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(gcpPubSubTemplate.provInProgressState);
			expect(orderFlowUtil.verifyOrderType(orderObject)).toBe(gcpPubSubTemplate.orderTypeEdit);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			}
			expect(snowPage.getTextShortDescription()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestEdit);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			}
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Subscription name")).toEqual(suscrpName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Delivery Type")).toEqual("Pull");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Acknowledgment Deadline")).toEqual(gcpPubSubTemplate.ackEdit);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			}
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();
			//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
					
			//Order Completion in SNOW
			//snowPage.clickImplementButtonQS();
			snowPage.checkIfProvisioningTaskClosed();
			/*snowPage.clickBackButton();
			snowPage.openRelatedChangeRequest();
			snowPage.clickCloseChangeRequestButton();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(gcpPubSubTemplate.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			});		
		});
	
		it('Google: Pub/Sub ---- Verify Delete functionality with Auto Technical, Financial, Legal approval and Standard change', function () {
		
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			sampleOrder1 = inventoryPage.getDeleteOrderNumber();
			
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(gcpPubSubTemplate.provInProgressState);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(gcpPubSubTemplate.orderTypeDel);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			}
			expect(snowPage.getTextShortDescription()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			}
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			}
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();
			//expect(snowPage.getTextChangeRequestCurrentState()).toBe(snowInstanceTemplate.snowChangeRequestStateScheduled);			
					
			//Order Completion in SNOW
			//snowPage.clickImplementButtonQS();
			snowPage.checkIfProvisioningTaskClosed();
			/*snowPage.clickBackButton();
			snowPage.openRelatedChangeRequest();
			snowPage.clickCloseChangeRequestButton();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);*/
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(gcpPubSubTemplate.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			});		
		});
	 }
		 
});
	
	
	
	