"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	icdsRhel7x = require('../../../../../../testData/OrderIntegration/ServiceNOW/ICDSRhel7x.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('ICDS E2E cases for Auto Approval', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, provOrder, inventoryPage, policyPage, cartListPage;
	var modifiedParamMap = {};
	var serviceName = "SNOWauto"+util.getRandomString(5);
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var policyName = "SNOWQSAutoExtICDSPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWQSAutoExtICDSPolicyRule"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var icdsRhel7xObj = JSON.parse(JSON.stringify(icdsRhel7x));

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
		
		//Delete policy if exists
		policyPage.open();
		util.waitForAngular();
		policyPage.deletePoliciesIfExist();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"TestSnowTeam (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["VRA"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":"",
		"Financial":"External Approval", "Legal":""};
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"TestSnowTeam", "Environment":"QA", "Application":""};
	});
	
	afterAll(function() {
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);
		  
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});

	it('Create Approval Policy for ICDS with Auto Technical and External Financial approval', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
		policyPage.selectExternalApprovalDropdownSNOW();
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
		  expect(policyNameInPolicyTable).toEqual(policyName);
	});	
	
	if(isProvisioningRequired == "true") {	
		it('ICDS: RHEL7.x ---- Verify Provision functionality for Auto approval', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsRhel7x.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsRhel7x.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsRhel7x.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(icdsRhel7x, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsRhel7x.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsRhel7x.appInProgressState);
			
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsRhel7x.bluePrintName);

			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);

			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsRhel7x.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsRhel7x.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSRITMItemLinux);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDescLinux);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Customer")).toBe(jsonUtil.getValue(icdsRhel7xObj, "Customer"));
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Service Collection")).toBe(jsonUtil.getValue(icdsRhel7xObj, "Servicecollection"));
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsRhel7xObj, "Environment"));
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Active Directory Domain")).toBe(snowInstanceTemplate.snowQSReqItemVarADDomain);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Number of CPU Cores")).toBe(jsonUtil.getValue(icdsRhel7xObj, "CPUs"));
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Memory Size (GB)")).toBe(jsonUtil.getValue(icdsRhel7xObj, "Memory (MB)"));
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Disk 0 (System) Size (GB)")).toBe(snowInstanceTemplate.snowQSReqItemVarDisk0Size);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Disk 0 (System) Name")).toBe(snowInstanceTemplate.snowQSReqItemVarDisk0Name);

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.rightClickOnCMDBCIFormHeader();
			var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
			sysidofChangeRequest.then(function(sysidofChangeRequestValue){
			var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
			setChangeRequesttoImplementState.then(function(statuscode){
			expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			});
			snowPage.checkIfAllEightChangeTasksClosed();
			browser.sleep(5000);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsRhel7x.completedState);
			
			//Validation on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
		 });
		});
		
		it('ICDS: RHEL7.x ---- Verify Turn Off functionality for Auto approval', function () {
			
			//Place order for Turn OFF in Marketplace 
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA(icdsRhel7x.componentType).then(function () {
	                inventoryPage.clickTurnOFFButtonOfInstanceICDS().then(function () {
	                    inventoryPage.clickOkForInstanceTurnOFFPermission();
	                });
	            });
	        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsRhel7x.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsRhel7x.appInProgressState);

            //Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsRhel7x.serviceOfferingTurnOff);

			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);

			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsRhel7x.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsRhel7x.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSRITItemMDay2OpsLin);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDescDay2OpsLin);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsRhel7xObj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.rightClickOnCMDBCIFormHeader();
			var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
			sysidofChangeRequest.then(function(sysidofChangeRequestValue){
			var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
			setChangeRequesttoImplementState.then(function(statuscode){
			expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			});
			snowPage.checkIfAllTwoChangeTasksClosed();	
			browser.sleep(5000);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsRhel7x.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickReqItemVarTabQS();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
		   });
		});
		});
		
		it('ICDS: RHEL7.x ---- Verify Turn On functionality for Auto approval', function () {
			
			//Place order for Turn ON in Marketplace 
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA(icdsRhel7x.componentType).then(function () {
	                inventoryPage.clickTurnONButtonOfInstanceICDS().then(function () {
	                    inventoryPage.clickOkForInstanceTurnONPermission();
	                });
	            });
	        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsRhel7x.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsRhel7x.appInProgressState);

            //Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsRhel7x.serviceOfferingTurnOn);

			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);

			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsRhel7x.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsRhel7x.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSRITItemMDay2OpsLin);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDescDay2OpsLin);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsRhel7xObj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.rightClickOnCMDBCIFormHeader();
			var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
			sysidofChangeRequest.then(function(sysidofChangeRequestValue){
			var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
			setChangeRequesttoImplementState.then(function(statuscode){
			expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			});
			snowPage.checkIfAllTwoChangeTasksClosed();
			browser.sleep(5000);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsRhel7x.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickReqItemVarTabQS();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
	       });
		});
	});
		
		it('ICDS: RHEL7.x ---- Verify Reboot functionality for Auto approval', function () {
			
			//Place order for Reboot in Marketplace 
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA(icdsRhel7x.componentType).then(function () {
	                inventoryPage.clickRebootButtonOfInstanceICDS().then(function () {
	                    inventoryPage.clickOkForInstanceRebootPermission();
	                });
	            });
	        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsRhel7x.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsRhel7x.appInProgressState);

            //Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsRhel7x.serviceOfferingReboot);

			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsRhel7x.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsRhel7x.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSRITItemMDay2OpsLin);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDescDay2OpsLin);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsRhel7xObj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.rightClickOnCMDBCIFormHeader();
			var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
			sysidofChangeRequest.then(function(sysidofChangeRequestValue){
			var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
			setChangeRequesttoImplementState.then(function(statuscode){
			expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			});
			snowPage.checkIfAllTwoChangeTasksClosed();
			browser.sleep(5000);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsRhel7x.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickReqItemVarTabQS();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
	       });
		});
	});
		
		it('ICDS: RHEL7.x ---- Verify Delete functionality for Auto approval', function () {
			
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename =  serviceName;
			browser.get(consumeLaunchpadUrl);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			provOrder = inventoryPage.getDeleteOrderNumber();
			
		
			//Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsRhel7x.bluePrintName);

			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(icdsRhel7x.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSRITMItemDeleteLin);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDescDelLin);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsRhel7xObj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.rightClickOnCMDBCIFormHeader();
			var sysidofChangeRequest = snowPage.clickOnCopySysIDChangeRequest();
			sysidofChangeRequest.then(function(sysidofChangeRequestValue){
			var setChangeRequesttoImplementState = snowAPI.moveChangeRequesttoImplementState(sysidofChangeRequestValue);
			setChangeRequesttoImplementState.then(function(statuscode){
			expect(statuscode).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
			});
			snowPage.checkIfAllTwelveChangeTasksClosed();	
			browser.sleep(5000);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(icdsRhel7x.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);	
		});		
		 });
	 }
});
	
	
	
	