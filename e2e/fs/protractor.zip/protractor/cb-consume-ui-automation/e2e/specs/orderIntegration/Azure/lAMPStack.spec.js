//Author: Atiksha Batra
"use strict";
var logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    async = require('async'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    LAMPTemplate = require('../../../../testData/OrderIntegration/Azure/AzLAMPStack.json');

describe('Azure - Azure LAMP Stack Service ', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, servicename, SOIComponents;
    var modifiedParamMap = {};
    var servicename = "AutoLAMPsrv" + util.getRandomString(5);
    var newResourceGroupName = "gslautotc_azureLAMP-RG101" + util.getRandomString(4);
    var dnsPrefix = "autodnsprefix" + util.getRandomString(4);
    dnsPrefix = dnsPrefix.toLowerCase();
    var storageAccountName = "autosa" + util.getRandomString(4);
    storageAccountName = storageAccountName.toLowerCase();
    var messageStrings = { providerName: 'Azure', category: 'Containers', templateName: 'Azure LAMP Stack' };

    beforeAll(function () {
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    afterAll(function () {
        // Delete Azure LAMP Stack Service 
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        SOIComponents = [storageAccountName, LAMPTemplate.lampStackComp1, LAMPTemplate.lampStackComp2, LAMPTemplate.lampStackComp3, LAMPTemplate.lampStackComp4, LAMPTemplate.lampStackComp5]
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "DNS Label Prefix": dnsPrefix, "Storage Account Name": storageAccountName, "UpdateMainParamObject": false };
    });

    it('Azure: Verify that for Azure LAMP Stack Service required parameters on Service Details Page are present.', function () {
        var lampStackObject = JSON.parse(JSON.stringify(LAMPTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(lampStackObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(lampStackObject.bluePrintName);
        if (browser.params.defaultCurrency == "USD") {
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(lampStackObject.BasePrice);
        }
    });

    it('Azure: Verify Review order and View Order Details for Azure LAMP Stack Service', function () {
        var orderObject = {};
        orderObject.servicename = servicename;
        var lampStackObject = JSON.parse(JSON.stringify(LAMPTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(lampStackObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(lampStackObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(LAMPTemplate, modifiedParamMap);
        //Verify input values on Review Order page            
        expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(lampStackObject, "New Resource Group Required"));
        expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(newResourceGroupName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(lampStackObject, "Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Resource Location:")).toEqual(jsonUtil.getValue(lampStackObject, "Resource Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Ubuntu OS Version:")).toEqual(jsonUtil.getValue(lampStackObject, "Ubuntu OS Version"));
        expect(placeOrderPage.getTextBasedOnLabelName("Admin Username:")).toEqual(jsonUtil.getValue(lampStackObject, "Admin Username"));
        expect(placeOrderPage.getTextBasedOnLabelName("DNS Label Prefix:")).toEqual(dnsPrefix);
        expect(placeOrderPage.getTextBasedOnLabelName("Storage Account Name:")).toEqual(storageAccountName);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(orderObject.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(orderObject.servicename);//Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe('Azure');//Checking Provider
        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(lampStackObject, "New Resource Group Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(lampStackObject, "Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(newResourceGroupName);
        expect(ordersPage.getTextBasedOnExactLabelName("Resource Location")).toEqual(jsonUtil.getValue(lampStackObject, "Resource Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("Ubuntu OS Version")).toEqual(jsonUtil.getValue(lampStackObject, "Ubuntu OS Version"));
        expect(ordersPage.getTextBasedOnExactLabelName("Admin Username")).toEqual(jsonUtil.getValue(lampStackObject, "Admin Username"));
        expect(ordersPage.getTextBasedOnExactLabelName("DNS Label Prefix")).toEqual(dnsPrefix);
        expect(ordersPage.getTextBasedOnExactLabelName("Storage Account Name")).toEqual(storageAccountName);
        //Checking Bill Of Material
        if (browser.params.defaultCurrency == "USD") {
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(ordersPage.getEstimatedCost()).toBe(lampStackObject.TotalCost);
        }
        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
});

if (isProvisioningRequired == "true") {
    it('Azure: Verify provisioning of Azure LAMP Stack using Consume UI', function () {
        var orderObject = {};
        orderObject.servicename = servicename;
        var lampStackObject = JSON.parse(JSON.stringify(LAMPTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(lampStackObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(lampStackObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(LAMPTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
        inventoryPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
        inventoryPage.clickViewService();
        //Checking Inventory Page Service Configuration
        expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(lampStackObject, "New Resource Group Required"));
        expect(inventoryPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(newResourceGroupName);
        expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(lampStackObject, "Location"));
        expect(inventoryPage.getTextBasedOnLabelName("Resource Location:")).toEqual(jsonUtil.getValue(lampStackObject, "Resource Location"));
        expect(inventoryPage.getTextBasedOnLabelName("Ubuntu OS Version:")).toEqual(jsonUtil.getValue(lampStackObject, "Ubuntu OS Version"));
        expect(inventoryPage.getTextBasedOnLabelName("Admin Username:")).toEqual(jsonUtil.getValue(lampStackObject, "Admin Username"));
        expect(inventoryPage.getTextBasedOnLabelName("DNS Label Prefix:")).toEqual(dnsPrefix);
        expect(inventoryPage.getTextBasedOnLabelName("Storage Account Name:")).toEqual(storageAccountName);
        inventoryPage.closeViewDetailsTab();
        //Checking SOI Components
        if (isDummyAdapterDisabled == "true") {
            inventoryPage.clickExpandFirstRow().then(function () {
                browser.executeScript('window.scrollTo(0,0);');
                var i = 1;
                async.forEachSeries(SOIComponents, function (component, callback) {
                    console.log("SOIComponents: " +SOIComponents);
                    inventoryPage.clickOverMenuIcon(i).then(function () {
                        inventoryPage.clickOnViewComponent(i).then(function () {
                            expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                            expect(inventoryPage.getTagsOnInventory()).toContain(lampStackObject.mcmpTag);
                            expect(inventoryPage.getTagsOnInventory()).toContain(lampStackObject.bluePrintName);
                            expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                            inventoryPage.closeViewComponent();
                            browser.sleep(10000);
                            i++;
                            return callback();
                        });
                    })
                }, function (error) {
                    if (error) {
                        logger.info('Unable to Get SOI component')
                    }
                })
            })
        }
        // check Non-Editable service Message
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickNonEditableInstance();
        expect(inventoryPage.getTextForInvalidEditModal()).toEqual(LAMPTemplate.nonEditableText);
        inventoryPage.clickOnInvalidEditOkModal();
    });
}
});
