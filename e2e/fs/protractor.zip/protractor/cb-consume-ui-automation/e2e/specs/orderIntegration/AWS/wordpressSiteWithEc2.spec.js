"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    logGenerator = require("../../../../helpers/logGenerator.js"),
    appUrls = require('../../../../testData/appUrls.json'),
    shoppingCartTemplate = require('../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
    imiConfigTemplate = require('../../../../testData/OrderIntegration/Imi/imiConfiguration.json'),
    ec2InstanceTemplate = require('../../../../testData/OrderIntegration/AWS/wordpressSiteWithEC2.json');

describe('AWS - Wordpress Site With Single EC2', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, EC2INSObject, inventoryPage, msgToVerify;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = ec2InstanceTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-wordpressec2-" + util.getRandomString(5);
        EC2INSObject = JSON.parse(JSON.stringify(ec2InstanceTemplate));
    });

    beforeEach(function () {
        modifiedParamMap = { "Service Instance Name": serviceName };
    });

    it('AWS-Wordpress Site With Ec2 - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        catalogPage.open();
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(ec2InstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(ec2InstanceTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(ec2InstanceTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(ec2InstanceTemplate.TotalCost); expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            }
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Instance Type"]).toEqual(requiredReturnMap["Expected"]["Instance Type"]);
            expect(requiredReturnMap["Actual"]["VPC"]).toEqual(requiredReturnMap["Expected"]["VPC"]);
            expect(requiredReturnMap["Actual"]["Key Pair"]).toEqual(requiredReturnMap["Expected"]["Key Pair"]);
            expect(requiredReturnMap["Actual"]["SSH Location"]).toEqual(requiredReturnMap["Expected"]["SSH Location"]);
            expect(requiredReturnMap["Actual"]["Database name"]).toEqual(requiredReturnMap["Expected"]["Database name"]);
            expect(requiredReturnMap["Actual"]["DB engine version"]).toEqual(requiredReturnMap["Expected"]["DB engine version"]);
            expect(requiredReturnMap["Actual"]["DB instance class"]).toEqual(requiredReturnMap["Expected"]["DB instance class"]);
            expect(requiredReturnMap["Actual"]["Allocated storage (GB)"]).toEqual(requiredReturnMap["Expected"]["Allocated storage (GB)"]);
            expect(requiredReturnMap["Actual"]["Provisioned IOPS"]).toEqual(requiredReturnMap["Expected"]["Provisioned IOPS"]);
            expect(requiredReturnMap["Actual"]["Database username"]).toEqual(requiredReturnMap["Expected"]["Database username"]);
            expect(requiredReturnMap["Actual"]["Key"]).toEqual(requiredReturnMap["Expected"]["Key"]);
            expect(requiredReturnMap["Actual"]["Value"]).toEqual(requiredReturnMap["Expected"]["Value"]);
            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(ec2InstanceTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                if (browser.params.defaultCurrency == "USD") {
                    //Validate Estimated price on approve order page
                    expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(ec2InstanceTemplate.EstimatedPrice);
                    //Validate pricing on order history page
                    ordersHistoryPage.open();
                    ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                    expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(ec2InstanceTemplate.EstimatedPrice);
                }
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();

            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Key Pair")).toEqual(jsonUtil.getValue(EC2INSObject, "Key Pair"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("SSH Location")).toEqual(jsonUtil.getValue(EC2INSObject, "SSH Location"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(EC2INSObject, "VPC"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Database name")).toEqual(jsonUtil.getValue(EC2INSObject, "Database name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(EC2INSObject, "DB engine version"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(EC2INSObject, "DB instance class"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Allocated storage (GB)")).toEqual(jsonUtil.getValue(EC2INSObject, "Allocated storage (GB)"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Provisioned IOPS")).toEqual(jsonUtil.getValue(EC2INSObject, "Provisioned IOPS"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Database username")).toEqual(jsonUtil.getValue(EC2INSObject, "Database username"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Key")).toEqual(jsonUtil.getValue(EC2INSObject, "Key"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Value")).toEqual(jsonUtil.getValue(EC2INSObject, "Value"));
            if (browser.params.defaultCurrency == "USD") {
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(ec2InstanceTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(ec2InstanceTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
            }

            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(ordersPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            expect(ordersPage.getTextBasedOnLabelName("Key Pair")).toEqual(jsonUtil.getValue(EC2INSObject, "Key Pair"));
            expect(ordersPage.getTextBasedOnLabelName("SSH Location")).toEqual(jsonUtil.getValue(EC2INSObject, "SSH Location"));
            expect(ordersPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(EC2INSObject, "VPC"));
            expect(ordersPage.getTextBasedOnLabelName("Database name")).toEqual(jsonUtil.getValue(EC2INSObject, "Database name"));
            expect(ordersPage.getTextBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(EC2INSObject, "DB engine version"));
            expect(ordersPage.getTextBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(EC2INSObject, "DB instance class"));
            expect(ordersPage.getTextBasedOnLabelName("Allocated storage (GB)")).toEqual(jsonUtil.getValue(EC2INSObject, "Allocated storage (GB)"));
            expect(ordersPage.getTextBasedOnLabelName("Provisioned IOPS")).toEqual(jsonUtil.getValue(EC2INSObject, "Provisioned IOPS"));
            expect(ordersPage.getTextBasedOnLabelName("Database username")).toEqual(jsonUtil.getValue(EC2INSObject, "Database username"));
            expect(ordersPage.getTextBasedOnExactLabelName("Key")).toEqual(jsonUtil.getValue(EC2INSObject, "Key"));
            expect(ordersPage.getTextBasedOnLabelName("Value")).toEqual(jsonUtil.getValue(EC2INSObject, "Value"));
            if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(ec2InstanceTemplate.TotalCost);
                ordersPage.clickServiceDetailSliderCloseButton();
            }
        });
    });

    it('AWS-Wordpress Site With EC2-Verify Website URL', function () {
        if (isDummyAdapterDisabled == "true") {
            //Validate Service Details on Inventory Page            
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();
            expect(inventoryPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(EC2INSObject, "AWS Region"));
            expect(inventoryPage.getTextBasedOnLabelName("instance Type")).toEqual(jsonUtil.getValue(EC2INSObject, "Instance Type"));
            expect(inventoryPage.getTextBasedOnLabelName("Key Pair")).toEqual(jsonUtil.getValue(EC2INSObject, "Key Pair"));
            expect(inventoryPage.getTextBasedOnLabelName("SSH Location")).toEqual(jsonUtil.getValue(EC2INSObject, "SSH Location"));
            expect(inventoryPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(EC2INSObject, "VPC"));
            expect(inventoryPage.getTextBasedOnLabelName("Database name")).toEqual(jsonUtil.getValue(EC2INSObject, "Database name"));
            expect(inventoryPage.getTextBasedOnLabelName("DB engine version")).toEqual(jsonUtil.getValue(EC2INSObject, "DB engine version"));
            expect(inventoryPage.getTextBasedOnLabelName("DB instance class")).toEqual(jsonUtil.getValue(EC2INSObject, "DB instance class"));
            expect(inventoryPage.getTextBasedOnLabelName("Allocated storage (GB)")).toEqual(jsonUtil.getValue(EC2INSObject, "Allocated storage (GB)"));
            expect(inventoryPage.getTextBasedOnLabelName("Provisioned IOPS")).toEqual(jsonUtil.getValue(EC2INSObject, "Provisioned IOPS"));
            expect(inventoryPage.getTextBasedOnLabelName("Database username")).toEqual(jsonUtil.getValue(EC2INSObject, "Database username"));
            expect(inventoryPage.getTextBasedOnLabelName("Key")).toEqual(jsonUtil.getValue(EC2INSObject, "Key"));
            expect(inventoryPage.getTextBasedOnLabelName("Value")).toEqual(jsonUtil.getValue(EC2INSObject, "Value"));

            inventoryPage.getWebSiteUrl("WebsiteURL").then(function (webUrl) {
                //open url in new tab and check if website is displaying
                browser.executeScript("window.open()");
                return browser.getAllWindowHandles().then(function (handles) {
                    const newWindowHandle = handles[1];
                    browser.switchTo().window(newWindowHandle);
                    browser.get(webUrl).then(function () {
                        util.waitForAngular();
                        expect(inventoryPage.getLanguageCount()).toBe(true);
                        browser.close();
                        util.switchToParentWindow();
                        //util.switchToChildWindow();
                        util.switchToFrame();
                    });
                });
            });
            if (browser.params.defaultCurrency == "USD") {
                // Validate BOM (Inventory Page)
                inventoryPage.clickBomTab();
                expect(inventoryPage.getTextEstimatedCost()).toEqual(ec2InstanceTemplate.TotalCost);
                //Validate order history tab
                inventoryPage.clickOrderHistorTab();
                //expect(inventoryPage.getTextOrderIdOnOrderHistory()).toEqual(orderObject.orderNumber);
                expect(inventoryPage.getTextNewOperationType()).toEqual(ec2InstanceTemplate.newOrderType);
                expect(inventoryPage.getTextOrderStatus()).toEqual(messageStrings.completedState)
                expect(inventoryPage.getTextEstimatedCostOnOrderHistory()).toEqual(ec2InstanceTemplate.TotalCost);
                inventoryPage.closeViewComponent();
            }
            //Delete Service flow                    
            orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, ec2InstanceTemplate.bluePrintName);
            //expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
        }
    });

});
