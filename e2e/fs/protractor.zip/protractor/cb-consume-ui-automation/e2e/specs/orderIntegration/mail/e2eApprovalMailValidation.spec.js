/**
 * @author Akash Deep Das
 * @email akadas30@in.ibm.com
 * @create date 2019-12-19 13:51:28
 * @modify date 2019-12-19 13:51:28
 */

"use strict";

var CatalogPage            = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage         = require('../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage          = require('../../../pageObjects/inventory.pageObject.js'),
	util                   = require('../../../../helpers/util.js'),
	orderFlowUtil          = require('../../../../helpers/orderFlowUtil.js'),
	appUrls                = require('../../../../testData/appUrls.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	centOs70VRA76Template  = require('../../../../testData/OrderIntegration/VRA/CentOs70VRA76.json'),
	mailVaildationAPIFlow = require("../../../../helpers/APIs/gmailAPIValidationFlow.js");
const {newMailDataFilePath,editSOIMailDataFilePath,deleteMailDataFilePath} = require('../../../../testData/mailValidationData/filePaths.json');

    
describe('E2E Test cases for validating the approval mails using CentOS70_VRA7.6 service', function() {
	var catalogPage, placeOrderPage,inventoryPage,serviceName;
	var serviceNameProv = "TestAutomation" + util.getRandomString(5);
	var modifiedParamMap = {};
    var messageStrings = {
			providerName                      : centOs70VRA76Template.provider,
			orderSubmittedConfirmationMessage : centOs70VRA76Template.orderSubmittedConfirmationMessage,
			category                          :	centOs70VRA76Template.Category,
			completedState                    : centOs70VRA76Template.completedState,
			orderTypeEdit                     : centOs70VRA76Template.orderTypeEdit,
			orderTypeDel                      : centOs70VRA76Template.orderTypeDel,
     };
    
  	beforeAll(function() {
    	catalogPage = new CatalogPage();
    	placeOrderPage = new PlaceOrderPage();
    	inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });
    
  	beforeEach(function() {
    	catalogPage.open();
    	expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
    	catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    	serviceName = "TestAutomation"+util.getRandomString(5);
		modifiedParamMap = {"Service Instance Name":serviceName,"CentOS76 disk":""};
    });
  
	if(isProvisioningRequired == "true") {
		it('Mail Validation : CentOS70 7.6 --- Verify that approval mails are received with proper data on Create and Edit flow',async  function() {
			var orderObject = {};		
			//Provision service
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.clickConfigureButtonBasedOnName(centOs70VRA76Template.bluePrintName);
			orderObject.servicename = serviceNameProv;
			modifiedParamMap = {"Service Instance Name":serviceNameProv,"CentOS76 disk":""};
			orderFlowUtil.fillOrderDetails(centOs70VRA76Template, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			/**
			 * Fetching order data from the UI and updating the test data json file
			 */
			var testDataMailNewOrder;
			var filePath;
        	placeOrderPage.getTextOrderedDateOrderSubmittedModal().then(async function(orderDate) {
				filePath = await mailVaildationAPIFlow.getAbsoluteFilePath(newMailDataFilePath);
				testDataMailNewOrder = await mailVaildationAPIFlow.readJson(filePath);	
				testDataMailNewOrder.orderedDate = mailVaildationAPIFlow.dateFormatToUTC(orderDate);
				testDataMailNewOrder.placedBy = browser.params.username;
	
        	});
        	placeOrderPage.getTextOrderNumberOrderSubmittedModal().then(async function(orderNumber) {
				orderObject.orderNumber = orderNumber;
				testDataMailNewOrder.orderId = orderNumber;
				await mailVaildationAPIFlow.jsonWriter(filePath,testDataMailNewOrder);

				/**
				 * Fetching order mail data from gmail api.
				 */
				let messageID = await mailVaildationAPIFlow.getMessageIdWithRetries(orderNumber);
				let messageBody = await mailVaildationAPIFlow.getMessageBody(messageID);
				let mailResponseObj = await mailVaildationAPIFlow.parseTextTojson(messageBody);
				/**
				 * Validating details for approval mail for new orders
				 */
				expect(testDataMailNewOrder.userName).toEqual(mailResponseObj.userName)
				expect(testDataMailNewOrder.orderId).toEqual(mailResponseObj['Order ID'])
				expect(testDataMailNewOrder.orderStatus).toEqual(mailResponseObj['Order Status'])
				expect(testDataMailNewOrder.orderType).toEqual(mailResponseObj['Order Type'])
				expect(testDataMailNewOrder.orderedDate).toEqual(mailResponseObj['Ordered Date'])
				expect(mailResponseObj['Placed By']).toContain(testDataMailNewOrder.placedBy)
				expect(testDataMailNewOrder.reviewMessageHeader).toEqual(mailResponseObj.reviewMessageHeader)
				expect(testDataMailNewOrder.detailsMessage).toEqual(mailResponseObj.detailsMessage)
				expect(testDataMailNewOrder.thankyouMessage).toEqual(mailResponseObj.thankyouMessage)
				expect(testDataMailNewOrder.approvalLink).toEqual(mailResponseObj.approvalLink);
        	})
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject,messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState); 
			orderFlowUtil.verifyOrderStatus(orderObject).then(async function(status){		
				//Edit service
				if(status == 'Completed'){
					modifiedParamMap = {"Service Instance Name":"","Team":"","Environment":"","Application":"","Provider Account":"","CPUs":"2","Memory (MB)":"1024","CentOS76 disks":"","Capacity":"","Label":"","User Created":"","Volume ID":"","CentOS76 disk":""};
					orderFlowUtil.editService(orderObject);
					orderFlowUtil.fillOrderDetails(centOs70VRA76Template,modifiedParamMap);
					placeOrderPage.submitOrder();
					placeOrderPage.getTextOrderNumberOrderSubmittedModal().then(async function(ordNumber){
						orderObject.orderNumber =  ordNumber;

						/**
						 * Fetching order data from the UI and updating the json file
						 */
						var filePath = await mailVaildationAPIFlow.getAbsoluteFilePath(editSOIMailDataFilePath);
						var testDataMailEditOrder = await mailVaildationAPIFlow.readJson(filePath);
						testDataMailEditOrder.orderId = ordNumber;
						testDataMailEditOrder.placedBy = browser.params.username;
						await mailVaildationAPIFlow.jsonWriter(filePath,testDataMailEditOrder);

						/**
						 * Fetching order mail data from gmail api.
						 */
						let messageID = await mailVaildationAPIFlow.getMessageIdWithRetries(ordNumber);
						let messageBody = await mailVaildationAPIFlow.getMessageBody(messageID);
						let mailResponseObj = await mailVaildationAPIFlow.parseTextTojson(messageBody);

						/**
						 * Validating details for approval mail of order for EditSOI.
						 */
						expect(testDataMailEditOrder.userName).toEqual(mailResponseObj.userName)
						expect(testDataMailEditOrder.orderId).toEqual(mailResponseObj['Order ID'])
						expect(testDataMailEditOrder.orderStatus).toEqual(mailResponseObj['Order Status'])
						expect(testDataMailEditOrder.orderType).toEqual(mailResponseObj['Order Type'])
						expect(mailResponseObj['Ordered Date']).toBeDefined();
						expect(mailResponseObj['Placed By']).toContain(testDataMailEditOrder.placedBy)
						expect(testDataMailEditOrder.reviewMessageHeader).toEqual(mailResponseObj.reviewMessageHeader)
						expect(testDataMailEditOrder.detailsMessage).toEqual(mailResponseObj.detailsMessage)
						expect(testDataMailEditOrder.thankyouMessage).toEqual(mailResponseObj.thankyouMessage)
						expect(testDataMailEditOrder.approvalLink).toEqual(mailResponseObj.approvalLink);

    					orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
						placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
						expect(orderFlowUtil.verifyOrderType(orderObject)).toBe(messageStrings.orderTypeEdit);
						orderFlowUtil.approveOrder(orderObject);
						orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
						expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
					})
					
				}
			});
		});
		
		
		it('Mail Validation : CentOS70 7.6 --- Verify that approval mails are received with proper data on Delete flow',async function() {
			var orderObject = {};
			var mailResponseObj={};
			orderObject.servicename = serviceNameProv;
			inventoryPage.open();
			browser.waitForAngular();
			inventoryPage.searchOrderByServiceName(orderObject.servicename);

			orderFlowUtil.deleteService(orderObject).then(async function(odNum){
				orderObject.deleteOrderNumber = odNum;
				expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
				orderFlowUtil.approveDeletedOrder(orderObject);
				orderFlowUtil.waitForDeleteOrderStatusChange(orderObject,messageStrings.completedState,50);
				expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState);
				/**
				 * Fetching order data from the UI and updating the json file
				 */
				var filePath = await mailVaildationAPIFlow.getAbsoluteFilePath(deleteMailDataFilePath);
				var testDataMailDeleteOrder = await mailVaildationAPIFlow.readJson(filePath)
				testDataMailDeleteOrder.orderId = odNum;
				testDataMailDeleteOrder.placedBy = browser.params.username;


				
				await mailVaildationAPIFlow.jsonWriter(filePath,testDataMailDeleteOrder);

				/**
				 * Fetching order mail data from gmail api.
				 */
				let messageID = await mailVaildationAPIFlow.getMessageIdWithRetries(odNum);
				let messageBody = await mailVaildationAPIFlow.getMessageBody(messageID);
				mailResponseObj = await mailVaildationAPIFlow.parseTextTojson(messageBody);

				/**
				 * Validating details for approval mail for Delete Order.
				 */
				expect(testDataMailDeleteOrder.userName).toEqual(mailResponseObj.userName)
				expect(testDataMailDeleteOrder.orderId).toEqual(mailResponseObj['Order ID'])
				expect(testDataMailDeleteOrder.orderStatus).toEqual(mailResponseObj['Order Status'])
				expect(testDataMailDeleteOrder.orderType).toEqual(mailResponseObj['Order Type'])
				expect(mailResponseObj['Ordered Date']).toBeDefined()
				expect(mailResponseObj['Placed By']).toContain(testDataMailDeleteOrder.placedBy)
				expect(testDataMailDeleteOrder.reviewMessageHeader).toEqual(mailResponseObj.reviewMessageHeader)
				expect(testDataMailDeleteOrder.detailsMessage).toEqual(mailResponseObj.detailsMessage)
				expect(testDataMailDeleteOrder.thankyouMessage).toEqual(mailResponseObj.thankyouMessage)
				expect(testDataMailDeleteOrder.approvalLink).toEqual(mailResponseObj.approvalLink);	
			})
		})	
     }
  });
