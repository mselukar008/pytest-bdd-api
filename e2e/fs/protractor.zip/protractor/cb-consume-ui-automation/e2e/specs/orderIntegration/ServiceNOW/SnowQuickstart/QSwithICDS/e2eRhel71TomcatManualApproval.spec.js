"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	icdsRhel71 = require('../../../../../../testData/OrderIntegration/ServiceNOW/ICDSRhel71Tomcat.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('ICDS E2E cases for Manual Approval', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, sampleOrder1, provOrder, instName, inventoryPage;
	var modifiedParamMap = {};
	var serviceName = "SNOWauto"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var icdsRhel71Obj = JSON.parse(JSON.stringify(icdsRhel71));

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"TestSnowTeam", "Environment":"QA", "Application":""};
	});
	
	afterAll(function() {
		browser.get(consumeLaunchpadUrl);
	});
	
	it('Enable Manual approval in SNOW QS', function () {
		snowPage.loginToSnowQSICDSPortal();
		snowPage.enableManualApprovalQS(snowInstanceTemplate.snowReqGrpApprovalProperty);
	});
	
	if(isProvisioningRequired == "true") {	
		it('ICDS: RHEL 7.1 With Tomcat ---- Verify Provision functionality for Manual approval', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(icdsRhel71.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(icdsRhel71.Category);
			catalogPage.clickConfigureButtonBasedOnName(icdsRhel71.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(icdsRhel71, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsRhel71.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsRhel71.appInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsRhel71.appInProgressState);
			
			//Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsRhel71.bluePrintName);
			
			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsRhel71.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsRhel71.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSReqItemLinuxTomcat);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemLinuxTomcat);
			
			//First Approval in SNOW at RITM level
			snowPage.approveRequestFromSnowAtRITMQS();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			
			//Second Approval in SNOW at RITM level
			snowPage.approveRequestFromSnowAtRITMQS();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			
			//Validation of Variables
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Customer")).toBe(jsonUtil.getValue(icdsRhel71Obj, "Customer"));
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Service Collection")).toBe(jsonUtil.getValue(icdsRhel71Obj, "Servicecollection"));
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsRhel71Obj, "Environment"));
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Active Directory Domain")).toBe(snowInstanceTemplate.snowQSReqItemVarADDomain);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Number of CPU Cores")).toBe(jsonUtil.getValue(icdsRhel71Obj, "CPUs"));
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Memory Size (GB)")).toBe(jsonUtil.getValue(icdsRhel71Obj, "Memory (MB)"));
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Disk 0 (System) Size (GB)")).toBe(snowInstanceTemplate.snowQSReqItemVarDisk0Size);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Disk 0 (System) Name")).toBe(snowInstanceTemplate.snowQSReqItemVarDisk0Name);

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.clickImplementButtonQS();
			snowPage.clickBackButton();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);			
			snowPage.checkIfAllSevenChangeTasksClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsRhel71.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
		 });
		
		it('ICDS: RHEL 7.1 With Tomcat ---- Verify Turn Off functionality for Manual approval', function () {
			
			//Place order for Turn OFF in Marketplace 
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA().then(function () {
	                inventoryPage.clickTurnOFFButtonOfInstanceICDS().then(function () {
	                    inventoryPage.clickOkForInstanceTurnOFFPermission();
	                });
	            });
	        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsRhel71.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();

            //Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsRhel71.serviceOfferingTurnOff);
			
			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsRhel71.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsRhel71.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSReqItemDay2OpsLin);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDay2OpsLin);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsRhel71Obj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.clickImplementButtonQS();
			snowPage.clickBackButton();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.checkIfAllTwoChangeTasksClosed();	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsRhel71.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickReqItemVarTabQS();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
	       });
		});
		
		it('ICDS: RHEL 7.1 With Tomcat ---- Verify Turn On functionality for Manual approval', function () {
			
			//Place order for Turn ON in Marketplace 
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA().then(function () {
	                inventoryPage.clickTurnONButtonOfInstanceICDS().then(function () {
	                    inventoryPage.clickOkForInstanceTurnONPermission();
	                });
	            });
	        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsRhel71.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();

            //Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsRhel71.serviceOfferingTurnOn);
			
			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsRhel71.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsRhel71.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSReqItemDay2OpsLin);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDay2OpsLin);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsRhel71Obj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.clickImplementButtonQS();
			snowPage.clickBackButton();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.checkIfAllTwoChangeTasksClosed();	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsRhel71.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickReqItemVarTabQS();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
	       });
		});
		
		it('ICDS: RHEL 7.1 With Tomcat ---- Verify Reboot functionality for Manual approval', function () {
			
			//Place order for Reboot in Marketplace 
			var orderObject = {};
			browser.get(consumeLaunchpadUrl);
	        orderObject.servicename = serviceName;
	        inventoryPage.open();
	        inventoryPage.searchOrderByServiceName(orderObject.servicename);
	        inventoryPage.clickExpandFirstRow().then(function () {
	            util.scrollToTop();
	            inventoryPage.clickOverflowActionButtonVRA().then(function () {
	                inventoryPage.clickRebootButtonOfInstanceICDS().then(function () {
	                    inventoryPage.clickOkForInstanceRebootPermission();
	                });
	            });
	        }).then(function () {
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(icdsRhel71.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
            provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            inventoryPage.clickOkForCustomOpnOrderButton();

            //Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsRhel71.serviceOfferingReboot);
			
			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			orderFlowUtil.waitForOrderStatusChange(orderObject,icdsRhel71.provInProgressState);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toBe(icdsRhel71.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSReqItemDay2OpsLin);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemDay2OpsLin);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsRhel71Obj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.clickImplementButtonQS();
			snowPage.clickBackButton();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.checkIfAllTwoChangeTasksClosed();	
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(icdsRhel71.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickReqItemVarTabQS();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
	       });
		});
		
		it('ICDS: RHEL 7.1 With Tomcat ---- Verify Delete functionality for Manual approval', function () {
			
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			provOrder = inventoryPage.getDeleteOrderNumber();

            //Validations on SNOW Request page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsRequestedQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestPendingState);
			expect(snowPage.getTextAssignmentGrpQS()).toBe(snowInstanceTemplate.snowQSRequestAssignGrp);
			expect(snowPage.getTextCorrelationIdQS()).toBe(provOrder);
			expect(snowPage.getTextShortDescription()).toBe(icdsRhel71.bluePrintName);
			
			//Validations on SNOW Request page after approval
			snowPage.approveRequestFromSnowQS();
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(icdsRhel71.provInProgressState);
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowQSReqItemLinDel);
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowRequestStageFulfiled);
			expect(snowPage.getTextReqItemApprovalQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowQSReqItemWIPState);
			expect(snowPage.getTextReqItemDescriptionQS()).toContain(snowInstanceTemplate.snowQSReqItemLinDel);
			snowPage.clickReqItemVarTabQS();
			expect(snowPage.getTextReqItemVarSearchTextboxBasedOnNameQS("Requested For")).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Change Type")).toBe(snowInstanceTemplate.snowQSReqItemVarChangeType);
			expect(snowPage.getTextReqItemVarTextboxBasedOnNameQS("Correlation ID")).toContain(provOrder);
			expect(snowPage.getTextReqItemVarDropdownBasedOnNameQS("Environment")).toBe(jsonUtil.getValue(icdsRhel71Obj, "Environment"));

			//Order Completion in SNOW
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateScheduled);
			snowPage.clickImplementButtonQS();
			snowPage.clickBackButton();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.checkIfAllElevenChangeTasksClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(icdsRhel71.completedState);
			
			//Validations on SNOW after Completion
			snowPage.logInToSnowQSICDSPortalAndSearchOrder(provOrder);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextItemStage()).toBe(snowInstanceTemplate.snowChangeRequestStateClose);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickReqItemVarTabQS();
			snowPage.clickChangeRequestLinkQS();
			expect(snowPage.getTextChangeRequestCurrentStateQS()).toContain(snowInstanceTemplate.snowChangeRequestStateClose);
	     });
	 }
});
	
	
	
	