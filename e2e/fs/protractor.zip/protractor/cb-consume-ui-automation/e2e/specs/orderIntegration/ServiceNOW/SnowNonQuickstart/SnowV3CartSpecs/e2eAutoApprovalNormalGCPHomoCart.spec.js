"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	OrderHistoryPage = require('../../../../../pageObjects/ordersHistory.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	gcpPubSubTemplate = require('../../../../../../testData/OrderIntegration/Google/pubsub.json'),
	shoppingCartTemplate   = require('../../../../../../testData/OrderIntegration/VRA/ShoppingCartData.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json');
	
describe('E2E cases for Homo cart with three GCP services and Auto approval with Normal change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, provOrder, cartListPage, orderHistoryPage, policyPage;
	var modifiedParamMapGoogle1 = {};
	var modifiedParamMapGoogle2 = {};
	var modifiedParamMapGoogle3 = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var orderObject = {};
	var serviceName1 = "SNOWauto"+util.getRandomString(5);
	var serviceName2 = "SNOWauto"+util.getRandomString(5);
	var serviceName3 = "SNOWauto"+util.getRandomString(5);
	var policyName = "SNOWautoGCPPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWautoGCPPolicyRule"+util.getRandomString(5);
	var cartName = "SNOWautoCart" + util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var topicName1 = "autom-" + util.getRandomString(5).toLowerCase();
	var topicName2 = "autom-" + util.getRandomString(5).toLowerCase();
	var topicName3 = "autom-" + util.getRandomString(5).toLowerCase();

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		orderHistoryPage = new OrderHistoryPage();
		policyPage = new PolicyPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New"],"Provider":["Google"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":""};
		modifiedParamMapGoogle1 = {"Service Instance Name":serviceName1, "Cart Name":cartName, "Cart Service":"checkbox-useShoppingCart", "New Shopping Cart":"newCart", "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "Name": topicName1};
		modifiedParamMapGoogle2 = {"Service Instance Name":serviceName2,"Cart Name": "","Cart Service": "","Team":"","Environment":"","Application":"","Name": topicName2};
		modifiedParamMapGoogle3 = {"Service Instance Name":serviceName3,"Cart Name": "","Cart Service": "","Team":"","Environment":"","Application":"","Name": topicName3};

	});
	
	afterAll(function() {
		browser.get(consumeLaunchpadUrl);
		policyPage.open();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		policyPage.clickRadioButtonRetiredOption();
		policyPage.clickUpdatePolicyBtn();
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickButtonDeletePolicyText();
		policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);

	});
	
	it('Set Change Request type to Normal in SNOW', function () {
		expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Auto Approval Policy for GCP provider', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('Place an order for Homo cart with three GCP services and Auto approval with Normal change', function () {
			
			//Add first GCP service to cart
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(gcpPubSubTemplate.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(gcpPubSubTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(gcpPubSubTemplate.bluePrintName);
			orderObject.servicename = serviceName1;
			orderFlowUtil.fillOrderDetails(gcpPubSubTemplate, modifiedParamMapGoogle1);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
	        
	        //Add second GCP service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(gcpPubSubTemplate.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(gcpPubSubTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(gcpPubSubTemplate.bluePrintName);
			orderObject.servicename = serviceName2;
			orderFlowUtil.fillOrderDetails(gcpPubSubTemplate, modifiedParamMapGoogle2);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
	        //cartListPage.continueShopping();
			catalogPage.open();
	        
	        //Add third GCP service to cart
	        catalogPage.clickResetProviderLink();
	        catalogPage.clickProviderCheckBoxBasedOnName(gcpPubSubTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(gcpPubSubTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(gcpPubSubTemplate.bluePrintName);
			orderObject.servicename = serviceName3;
			orderFlowUtil.fillOrderDetails(gcpPubSubTemplate, modifiedParamMapGoogle3);
			placeOrderPage.addToShoppingCart();
			expect(cartListPage.getServiceSuccessfullyAddedToCart()).toBe(shoppingCartTemplate.cartSuccessfullyAddedMessage);
			
			//Submit Order
			cartListPage.submitOrder(0);
	    	orderObject.orderNumber = cartListPage.getTextOrderNumberOrderSubmittedModal();
	    	orderObject.submittedBy = cartListPage.getTextSubmittedByOrderSubmittedModal
	        expect(cartListPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(shoppingCartTemplate.orderSubmittedConfirmationMessage);
	    	provOrder = cartListPage.getTextOrderNumberOrderSubmittedModal();
	        cartListPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
	        orderObject = {"orderNumber":provOrder};	
		
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(gcpPubSubTemplate.provInProgressState);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			expect(snowPage.getTextShortDescription()).toBe(cartName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
			expect(snowPage.getCountOfRITMlinks()).toBe(parseInt("3"));
		});
		
		it('Verify the First RITM for Provision functionality with Normal change', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
			var service = snowPage.getTextReqItemVariableServiceName();
			service.then(function(serviceName) {
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName1);
				}
				else if(serviceName.includes(serviceName2)) {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName2);
				}
				else {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName3);
				}
				
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(serviceName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(serviceName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				//Approvals in SNOW
				snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
				snowPage.openRelatedChangeRequest();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveChangeRequestForEachState();			
						
				//Order Completion in SNOW
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(gcpPubSubTemplate.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(gcpPubSubTemplate.completedState);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(gcpPubSubTemplate.completedState);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(gcpPubSubTemplate.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickFirstRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
	    });
	
		it('Verify the Second RITM for Provision functionality with Normal change', function () {
		
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
			var service = snowPage.getTextReqItemVariableServiceName();
			service.then(function(serviceName) {
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName1);
				}
				else if(serviceName.includes(serviceName2)) {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName2);
				}
				else {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName3);
				}
				
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(serviceName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(serviceName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				//Approvals in SNOW
				snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
				snowPage.openRelatedChangeRequest();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveChangeRequestForEachState();			
						
				//Order Completion in SNOW
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(gcpPubSubTemplate.provInProgressState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(gcpPubSubTemplate.completedState);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(gcpPubSubTemplate.completedState);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(gcpPubSubTemplate.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickSecondRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
	    });
		
		it('Verify the Third RITM for Provision functionality with Normal change', function () {
			
			//Validations on SNOW Requested Item page
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickThirdRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(gcpPubSubTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemvariablesSerOfferDescGoogle);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderGoogle);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryApp);
			var service = snowPage.getTextReqItemVariableServiceName();
			service.then(function(serviceName) {
				if(serviceName.includes(serviceName1)) {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName1);
				}
				else if(serviceName.includes(serviceName2)) {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName2);
				}
				else {
					expect(snowPage.getTextReqItemConfigValuesBasedOnName("Name")).toEqual(topicName3);
				}
				
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(serviceName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(serviceName,snowInstanceTemplate.snowGCPSrvcItemValuePubSub)).toBe(snowInstanceTemplate.snowreqItemBOMtotalGoogle);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				//Approvals in SNOW
				snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
				snowPage.openRelatedChangeRequest();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveChangeRequestForEachState();			
						
				//Order Completion in SNOW
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(gcpPubSubTemplate.completedState);
				orderHistoryPage.searchOrder(orderObject.orderNumber);
				if(serviceName.includes(serviceName1)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName1);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName1)).toBe(gcpPubSubTemplate.completedState);
				}
				else if(serviceName.includes(serviceName2)) {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName2);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName2)).toBe(gcpPubSubTemplate.completedState);
				}
				else {
					orderHistoryPage.clickArrowIconBasedOnServiceName(serviceName3);
					expect(orderHistoryPage.getTextOrderStatusBasedOnServiceName(serviceName3)).toBe(gcpPubSubTemplate.completedState);
				}
			})
				
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			snowPage.clickThirdRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			
			//Validations on SNOW Request page after Completion of all RITM's
			snowPage.logInToSnowDevPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestApprovalCont);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	    });
	 }

});
	
	
	
	