/*************************************************
	AUTHOR: Nikitha
 **************************************************/

"use strict";

var OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
HomePage = require('../../../pageObjects/home.pageObject.js'),
DashBoard = require('../../../pageObjects/dashBoard.pageObject.js'),
CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
PolicyPage = require('../../../pageObjects/policy.pageObject.js'),
util = require('../../../../helpers/util.js'),
CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
jsonUtil = require('../../../../helpers/jsonUtil.js'),
appUrls = require('../../../../testData/appUrls.json'),
isProvisioningRequired = browser.params.isProvisioningRequired,
centOs66VRA74Template = require('../../../../testData/OrderIntegration/VRA/CentOs66VRA74.json'),
policyTemplate = require('../../../../testData/OrderIntegration/policy/policy.json'),
addRulePolicyTemplate = require('../../../../testData/OrderIntegration/policy/addRulePolicy.json'),
credentailsTemplate = require('../../../../testData/credentials.json')

describe('Tests for policy tab - ', function() {
		var ordersPage, homePage, dashBoard, catalogPage, placeOrderPage, policyPage, policyName, policyRule, serviceName, policyUpdateSuccessMsg, policyDeleteSuccessMsg, cartListPage;
		var modifiedParamMap = {};
		var modifiedParamMapAddRule = {};
		var messageStrings = {
	 
		updatePolicySuccessMsg:            policyTemplate.updatePolicySuccessMsg, 
		deletePolicySuccessMsg:            policyTemplate.deletePolicySuccessMsg,
		retiredPolicyStatus:               policyTemplate.retiredPolicyStatus,
		activePolicyStatus:                policyTemplate.activePolicyStatus,
        providerNameAddRulePage:           addRulePolicyTemplate.providerNameAddRulePage, 
	    totalMonthlyCostAddRulePage:       addRulePolicyTemplate.totalMonthlyCostAddRulePage,
	    budgetStatusAddRulePage:           addRulePolicyTemplate.budgetStatusAddRulePage,
	    technicalApprovalStatusAddRulePage:addRulePolicyTemplate.technicalApprovalStatusAddRulePage,
	    financialApprovalStatusAddRulePage:addRulePolicyTemplate.financialApprovalStatusAddRulePage
	};
	
	beforeAll(function() {
		ordersPage = new OrdersPage();
		policyPage = new PolicyPage();
		homePage = new HomePage(); 
		dashBoard = new DashBoard();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
		serviceName = "policyauto" + util.getRandomString(5);
		policyName = "policy"+util.getRandomString(4);
		policyRule = "rulePolicy"+util.getRandomString(4);
		modifiedParamMap = {"policy Name":policyName};
		modifiedParamMapAddRule = {"Add Rule Name":policyRule};
		
	});

	beforeEach(function() {

	});

	it('Add Policy under Policy Tab', function () {
		policyPage.open();
		policyPage.clickAddNewPolicyBtn();
		policyPage.selectStartDate();
		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMap);
		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
		policyPage.clickApplyRulePolicyBtn();
		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRule);
		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRule);
		browser.sleep(2000);
		policyPage.clickCreatePolicyButton();
		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
		expect(policyNameInPolicyTable).toEqual(policyName);
		var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		expect(policyStatusInPolicy).toEqual(messageStrings.activePolicyStatus);
	});
	
	
	it('Validate Add Rule Policy Page', function () {
		policyPage.open();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
		expect(policyNameInPolicyTable).toEqual(policyName);
		var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		expect(policyStatusInPolicy).toEqual(messageStrings.activePolicyStatus);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		util.scrollToBottom();
		util.scrollToBottom();
		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRule);
		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRule);
		policyPage.clickActionIconApprovalPolicyBtn();
		policyPage.clickViewDetailApprovalPolicyBtn();
		util.waitForAngular();
		expect(policyPage.getTextProviderName()).toEqual(messageStrings.providerNameAddRulePage);
	    expect(policyPage.getTextTotalMonthlyCost()).toEqual(messageStrings.totalMonthlyCostAddRulePage);
        expect(policyPage.getTextBudgetStatus()).toEqual(messageStrings.budgetStatusAddRulePage);
        expect(policyPage.getTextTechnicalApproval()).toEqual(messageStrings.technicalApprovalStatusAddRulePage);
        expect(policyPage.getTextFinacialApproval()).toEqual(messageStrings.financialApprovalStatusAddRulePage);
        policyPage.clickAddRulePolicyCloseButton();
        util.waitForAngular();
        browser.sleep(2000);
        policyPage.clickCancelApprovePolicyBtn();
     	});
	
	
	it('Delete the created policy', function () {
		policyPage.open();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		policyPage.clickRadioButtonRetiredOption();
		policyPage.clickUpdatePolicyBtn();
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.updatePolicySuccessMsg+" "+policyName+" successfully");
		var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		expect(policyStatusInPolicy).toEqual(messageStrings.retiredPolicyStatus);
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickButtonDeletePolicyText();
		policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		util.waitForAngular();
		//policyPage.clickNotificationCloseButton();
		browser.sleep(2000);
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(messageStrings.deletePolicySuccessMsg+" "+policyName+" successfully");
	});
	
});
