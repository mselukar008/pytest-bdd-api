//Author: Atiksha Batra
"use strict";
var logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    async = require('async'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    WordPressTemplate = require('../../../../testData/OrderIntegration/Azure/wordPress.json');

describe('Azure - WordPress Service ', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, servicename, SOIComponents;
    var modifiedParamMap = {};
    var servicename = "AutoWordPresssrv" + util.getRandomString(5);
    var newResourceGroupName = "gslautotc_azureWordPress-RG101" + util.getRandomString(4);
    var storageAccountName = "autosa" + util.getRandomString(4);
    storageAccountName = storageAccountName.toLowerCase();
    var wordPressSiteName = "autoWordPress" + util.getRandomString(4);
    wordPressSiteName = wordPressSiteName.toLowerCase();
    var messageStrings = { providerName: 'Azure', category: 'Containers', templateName: 'WordPress' };

    beforeAll(function () {
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    afterAll(function () {
        // Delete WordPress Service 
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        SOIComponents = [WordPressTemplate.wordPressComponent1,WordPressTemplate.wordPressComponent2,storageAccountName]
        modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Storage Account Name": storageAccountName, "WordPress Site Name": wordPressSiteName };
    });

    it('Azure: Verify that for Azure WordPress Service required parameters on Service Details Page are present.', function () {
        var wordPressObject = JSON.parse(JSON.stringify(WordPressTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(wordPressObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(wordPressObject.bluePrintName);
        if (browser.params.defaultCurrency == "USD") {
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(wordPressObject.BasePrice);
        }
    });

    it('Azure: Verify Review order and View Order Details for Azure WordPress Service', function () {
        var orderObject = {};
        orderObject.servicename = servicename;
        var wordPressObject = JSON.parse(JSON.stringify(WordPressTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(wordPressObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(wordPressObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(WordPressTemplate, modifiedParamMap);
        //Verify input values on Review Order page    
        expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(wordPressObject, "New Resource Group Required"));
        expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(newResourceGroupName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(wordPressObject, "Location"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Server Location:")).toEqual(jsonUtil.getValue(wordPressObject, "Server Location"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Storage Account Name:")).toEqual(storageAccountName);
        expect(placeOrderPage.getTextBasedOnLabelName(" Storage Account Type:")).toEqual(jsonUtil.getValue(wordPressObject, "Storage Account Type"));
        expect(placeOrderPage.getTextBasedOnLabelName(" WordPress Site Name:")).toEqual(wordPressSiteName);
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(orderObject.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(orderObject.servicename);//Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe('Azure');//Checking Provider
        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(wordPressObject, "New Resource Group Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(wordPressObject, "Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(newResourceGroupName);
        expect(ordersPage.getTextBasedOnExactLabelName("Server Location")).toEqual(jsonUtil.getValue(wordPressObject, "Server Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("Storage Account Name")).toEqual(storageAccountName);
        expect(ordersPage.getTextBasedOnExactLabelName("Storage Account Type")).toEqual(jsonUtil.getValue(wordPressObject, "Storage Account Type"));
        expect(ordersPage.getTextBasedOnExactLabelName("WordPress Site Name")).toEqual(wordPressSiteName);
        //Checking Bill Of Material
        if (browser.params.defaultCurrency == "USD") {
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(ordersPage.getEstimatedCost()).toBe(wordPressObject.TotalCost);
        }
        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
    });

    if (isProvisioningRequired == "true") {
        it('Azure: Verify provisioning of Azure WordPress using Consume UI', function () {
            var orderObject = {};
            orderObject.servicename = servicename;
            var wordPressObject = JSON.parse(JSON.stringify(WordPressTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(wordPressObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(wordPressObject.bluePrintName);
            orderFlowUtil.fillOrderDetails(WordPressTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
            inventoryPage.clickViewService();
            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(wordPressObject, "New Resource Group Required"));
            expect(inventoryPage.getTextBasedOnLabelName("New Resource Group")).toEqual(newResourceGroupName);
            expect(inventoryPage.getTextBasedOnLabelName("Location")).toEqual(jsonUtil.getValue(wordPressObject, "Location"));
            expect(inventoryPage.getTextBasedOnLabelName("Server Location")).toEqual(jsonUtil.getValue(wordPressObject, "Server Location"));
            expect(inventoryPage.getTextBasedOnLabelName("Storage Account Name")).toEqual(storageAccountName);
            expect(inventoryPage.getTextBasedOnLabelName("Storage Account Type")).toEqual(jsonUtil.getValue(wordPressObject, "Storage Account Type"));
            expect(inventoryPage.getTextBasedOnLabelName("WordPress Site Name")).toEqual(wordPressSiteName);
            inventoryPage.closeViewDetailsTab();
            //Checking SOI Components
            if (isDummyAdapterDisabled == "true") {
                inventoryPage.clickExpandFirstRow().then(function () {
                    browser.executeScript('window.scrollTo(0,0);');
                    var i = 1;
                    async.forEachSeries(SOIComponents, function (component, callback) {
                        inventoryPage.clickOverMenuIcon(i).then(function () {
                            inventoryPage.clickOnViewComponent(i).then(function () {
                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                expect(inventoryPage.getTagsOnInventory()).toContain(wordPressObject.mcmpTag);
                                expect(inventoryPage.getTagsOnInventory()).toContain(wordPressObject.bluePrintName);
                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                inventoryPage.closeViewComponent();
                                browser.sleep(10000);
                                i++;
                                return callback();
                            });
                        })
                    }, function (error) {
                        if (error) {
                            logger.info('Unable to Get SOI component')
                        }
                    })
                })
            }
            // check Non-Editable service Message
            inventoryPage.clickNonEditableInstance();
            expect(inventoryPage.getTextForInvalidEditModal()).toEqual(WordPressTemplate.nonEditableText);
            inventoryPage.clickOnInvalidEditOkModal();
        });
    }
});
