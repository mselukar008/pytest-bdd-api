//Author: Atiksha Batra
"use strict";
var logGenerator = require("../../../../helpers/logGenerator.js"),
    logger = logGenerator.getApplicationLogger(),
    async = require('async'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    MariaDBTemplate = require('../../../../testData/OrderIntegration/Azure/mariaDBServers.json');

describe('Azure - Azure Database for MariaDB servers Service ', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, servicename, SOIComponents;
    var modifiedParamMap = {};
    var servicename = "AutoMariaDbsrv" + util.getRandomString(5);
    var newResourceGroupName = "gslautotc_azureMariaDb-RG101" + util.getRandomString(4);
    var serverName = "autoserver" + util.getRandomString(4);
    serverName = serverName.toLowerCase();
    var messageStrings = { providerName: 'Azure', category: 'Databases', templateName: 'WorAzure Database for MariaDB serversdPress' };
    SOIComponents = [serverName]
    modifiedParamMap = { "Service Instance Name": servicename, "New Resource Group": newResourceGroupName, "Server Name": serverName };

    beforeAll(function () {
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    afterAll(function () {
        // Delete WorAzure Database for MariaDB serversdPress Service 
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    beforeEach(function () {
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    it('Azure: Verify that for Azure Database for MariaDB servers required parameters on Service Details Page are present.', function () {
        var mariaDBObject = JSON.parse(JSON.stringify(MariaDBTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(mariaDBObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(mariaDBObject.bluePrintName);
        if (browser.params.defaultCurrency == "USD") {
        expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(mariaDBObject.BasePrice);
        }
    });

    it('Azure: Verify Review order and View Order Details for Azure Database for MariaDB servers', function () {
        var orderObject = {};
        orderObject.servicename = servicename;
        var mariaDBObject = JSON.parse(JSON.stringify(MariaDBTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(mariaDBObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(mariaDBObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(MariaDBTemplate, modifiedParamMap);
        //Verify input values on Review Order page    
        expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(mariaDBObject, "New Resource Group Required"));
        expect(placeOrderPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
        expect(placeOrderPage.getTextBasedOnLabelName("Location:")).toEqual(jsonUtil.getValue(mariaDBObject, "Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Server Name:")).toEqual(serverName);
        expect(placeOrderPage.getTextBasedOnLabelName("Data Source:")).toEqual(jsonUtil.getValue(mariaDBObject, "Data Source"));
        expect(placeOrderPage.getTextBasedOnLabelName("Server Location:")).toEqual(jsonUtil.getValue(mariaDBObject, "Server Location"));
        expect(placeOrderPage.getTextBasedOnLabelName("Version:")).toEqual(jsonUtil.getValue(mariaDBObject, "Version"));
        expect(placeOrderPage.getTextBasedOnLabelName("Compute + storage:")).toEqual(jsonUtil.getValue(mariaDBObject, "Compute + storage"));
        expect(placeOrderPage.getTextBasedOnLabelName("VCore:")).toEqual(jsonUtil.getValue(mariaDBObject, "VCore"));
        expect(placeOrderPage.getTextBasedOnLabelName("Storage:")).toEqual(jsonUtil.getValue(mariaDBObject, "Storage"));
        expect(placeOrderPage.getTextBasedOnLabelName("Storage-auto-growth:")).toEqual(jsonUtil.getValue(mariaDBObject, "Storage-auto-growth"));
        expect(placeOrderPage.getTextBasedOnLabelName("Backup Retention Period:")).toEqual(jsonUtil.getValue(mariaDBObject, "Backup Retention Period"));
        expect(placeOrderPage.getTextBasedOnLabelName("Backup Redundancy Options:")).toEqual(jsonUtil.getValue(mariaDBObject, "Backup Redundancy Options"));
        expect(placeOrderPage.getTextBasedOnLabelName("Admin Username:")).toEqual(jsonUtil.getValue(mariaDBObject, "Admin Username"));
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(orderObject.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();
        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(orderObject.servicename);//Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe('Azure');//Checking Provider
        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(mariaDBObject, "New Resource Group Required"));
        expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(mariaDBObject, "Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(newResourceGroupName);
        expect(ordersPage.getTextBasedOnExactLabelName("Server Name")).toEqual(serverName);
        expect(ordersPage.getTextBasedOnExactLabelName("Data Source")).toEqual(jsonUtil.getValue(mariaDBObject, "Data Source"));
        expect(ordersPage.getTextBasedOnExactLabelName("Server Location")).toEqual(jsonUtil.getValue(mariaDBObject, "Server Location"));
        expect(ordersPage.getTextBasedOnExactLabelName("Version")).toEqual(jsonUtil.getValue(mariaDBObject, "Version"));
        expect(ordersPage.getTextBasedOnExactLabelName("Compute + storage")).toEqual(jsonUtil.getValue(mariaDBObject, "Compute + storage"));
        expect(ordersPage.getTextBasedOnExactLabelName("VCore")).toEqual(jsonUtil.getValue(mariaDBObject, "VCore"));
        expect(ordersPage.getTextBasedOnExactLabelName("Storage")).toEqual(jsonUtil.getValue(mariaDBObject, "Storage"));
        expect(ordersPage.getTextBasedOnExactLabelName("Storage-auto-growth")).toEqual(jsonUtil.getValue(mariaDBObject, "Storage-auto-growth"));
        expect(ordersPage.getTextBasedOnExactLabelName("Backup Retention Period")).toEqual(jsonUtil.getValue(mariaDBObject, "Backup Retention Period"));
        expect(ordersPage.getTextBasedOnExactLabelName("Backup Redundancy Options")).toEqual(jsonUtil.getValue(mariaDBObject, "Backup Redundancy Options"));
        expect(ordersPage.getTextBasedOnExactLabelName("Admin Username")).toEqual(jsonUtil.getValue(mariaDBObject, "Admin Username"));
        //Checking Bill Of Material
        if (browser.params.defaultCurrency == "USD") {
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(ordersPage.getEstimatedCost()).toBe(mariaDBObject.TotalCost);
        }
        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
    });

    if (isProvisioningRequired == "true") {
        it('Azure: Verify provisioning of Azure Database for MariaDB servers using Consume UI', function () {
            var orderObject = {};
            orderObject.servicename = servicename;
            var mariaDBObject = JSON.parse(JSON.stringify(MariaDBTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(mariaDBObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(mariaDBObject.bluePrintName);
            orderFlowUtil.fillOrderDetails(MariaDBTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            element.all(by.css(inventoryPage.instanceTableActionIconCss)).first().click()
            inventoryPage.clickViewService();
            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName("New Resource Group Required:")).toEqual(jsonUtil.getValue(mariaDBObject, "New Resource Group Required"));
            expect(inventoryPage.getTextBasedOnLabelName("New Resource Group:")).toEqual(newResourceGroupName);
            expect(inventoryPage.getTextBasedOnExactLabelName("Location:")).toEqual(jsonUtil.getValue(mariaDBObject, "Location"));
            expect(inventoryPage.getTextBasedOnLabelName("Server Name:")).toEqual(serverName);
            expect(inventoryPage.getTextBasedOnLabelName("Data Source:")).toEqual(jsonUtil.getValue(mariaDBObject, "Data Source"));
            expect(inventoryPage.getTextBasedOnLabelName("Server Location:")).toEqual(jsonUtil.getValue(mariaDBObject, "Server Location"));
            expect(inventoryPage.getTextBasedOnLabelName("Version:")).toEqual(jsonUtil.getValue(mariaDBObject, "Version"));
            expect(inventoryPage.getTextBasedOnLabelName("Compute + storage:")).toEqual(jsonUtil.getValue(mariaDBObject, "Compute + storage"));
            expect(inventoryPage.getTextBasedOnLabelName("Storage:")).toEqual(jsonUtil.getValue(mariaDBObject, "Storage"));
            expect(inventoryPage.getTextBasedOnLabelName("Storage-auto-growth:")).toEqual(jsonUtil.getValue(mariaDBObject, "Storage-auto-growth"));
            expect(inventoryPage.getTextBasedOnLabelName("Backup Retention Period:")).toEqual(jsonUtil.getValue(mariaDBObject, "Backup Retention Period"));
            expect(inventoryPage.getTextBasedOnLabelName("Backup Redundancy Options:")).toEqual(jsonUtil.getValue(mariaDBObject, "Backup Redundancy Options"));
            expect(inventoryPage.getTextBasedOnLabelName("Admin Username:")).toEqual(jsonUtil.getValue(mariaDBObject, "Admin Username"));
            inventoryPage.closeViewDetailsTab();
            //Checking SOI Components
            if (isDummyAdapterDisabled == "true") {
                inventoryPage.clickExpandFirstRow().then(function () {
                    browser.executeScript('window.scrollTo(0,0);');
                    var i = 1;
                    async.forEachSeries(SOIComponents, function (component, callback) {
                        inventoryPage.clickOverMenuIcon(i).then(function () {
                            inventoryPage.clickOnViewComponent(i).then(function () {
                                expect(inventoryPage.getComponentName(SOIComponents)).toBe(true);
                                expect(inventoryPage.getTagsOnInventory()).toContain(mariaDBObject.mcmpTag);
                                expect(inventoryPage.getTagsOnInventory()).toContain(mariaDBObject.bluePrintName);
                                expect(inventoryPage.getTagsOnInventory()).toContain(servicename);
                                inventoryPage.closeViewComponent();
                                browser.sleep(10000);
                                i++;
                                return callback();
                            });
                        })
                    }, function (error) {
                        if (error) {
                            logger.info('Unable to Get SOI component')
                        }
                    })

                })
            }
            //check Non-Editable service Message
            inventoryPage.clickNonEditableInstance();
            expect(inventoryPage.getTextForInvalidEditModal()).toEqual(MariaDBTemplate.nonEditableText);
            inventoryPage.clickOnInvalidEditOkModal();
        });
    }
});
