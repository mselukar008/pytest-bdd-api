"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	slSecurityGrpTemplate = require('../../../../../../testData/OrderIntegration/Softlayer/SecurityGroupService.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	vmInstanceTemplate = require('../../../../../../testData/OrderIntegration/Softlayer/VirtualMachine.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('QS: IBM Cloud E2E cases for Auto Technical, Financial and Legal approval with Standard change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, sampleOrder1, inventoryPage, policyPage, cartListPage;
	var modifiedParamMap = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var serviceName = "SNOWQSauto"+util.getRandomString(5);
	var policyName = "SNOWQSautoSLPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWQSautoSLPolicyRule"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var secGrpName = "SNOWsecGrp"+util.getRandomString(5);
	var secGrpNameEdit = "SNOWsecGrpEdit"+util.getRandomString(5);
	var orderObjectVm = {};

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["IBM Cloud"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":""};
		modifiedParamMap = {"Service Instance Name":serviceName,"Team":"Auto-TEAM1", "Environment":"QA", "Application":"","Provider Account":"SL-Testing / SL-Testing","Security Group Name":secGrpName};
	});
	
	afterAll(function() {
		//Delete Approval Policy
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});
	
	it('Set Change Request type to Standard in SNOW', function () {
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Approval Policy for IBM Cloud with Auto Technical, Financial, Legal approval and Standard change', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('IBM Cloud: Security Group ---- Verify Provision functionality with Auto Technical, Financial, Legal approval and Standard change', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":sampleOrder1};	
			
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);

			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDSecurityGroup);

			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
			
			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
			
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName);

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			}
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			
			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();

			//Change Request Short Desc and Desc
			expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescNewOrder);
					
			//Order Completion in SNOW
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.completedOrderStatus);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.ibmcloudProviderAccountID);
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.ibmcloudProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	

			//Change Task Page Validations 
			snowPage.openRelatedChangeRequest();
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickClosureInfoInChangeTask();
			expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			snowPage.clickBackButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickBackButton();
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();			
			});	
		});
	
		it('IBM Cloud: Security Group ---- Verify Edit functionality with Auto Technical, Financial, Legal approval and Standard change', function () {
			
			//Place Order for Edit in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			modifiedParamMap = {"Service Instance Name":"","Team":"","Environment":"","Application":"","Provider Account":"","Security Group Name":secGrpNameEdit};
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.editService(orderObject);
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);
			expect(orderFlowUtil.verifyOrderType(orderObject)).toBe(slSecurityGrpTemplate.editSOIOrderStatus);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			
			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestEdit);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			
			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDSecurityGroup);
			
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
			
			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");

			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpNameEdit);

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			}
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			
			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);

			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();
			
			//Change Request Short Desc and Desc
			expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescEditOrder);
					
			//Order Completion in SNOW
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.completedOrderStatus);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.ibmcloudProviderAccountID);
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.ibmcloudProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	

			//Change Task Page Validations 
			snowPage.openRelatedChangeRequest();
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickClosureInfoInChangeTask();
			expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			snowPage.clickBackButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickBackButton();
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();			
			});			
		});
	
		it('IBM Cloud: Security Group ---- Verify Delete functionality with Auto Technical, Financial, Legal approval and Standard change', function () {
			
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			sampleOrder1 = inventoryPage.getDeleteOrderNumber();
			
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(slSecurityGrpTemplate.deleteSOIOrderStatus);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
			
			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDSecurityGroup);
			
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
			
			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
			
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			}
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();

			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();
			
			//Change Request Short Desc and Desc
			expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescDeleteOrder);
					
			//Order Completion in SNOW
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(slSecurityGrpTemplate.completedOrderStatus);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.ibmcloudProviderAccountID);
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.ibmcloudProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			snowPage.clickUpdateButton();	

			//Change Task Page Validations 
			snowPage.openRelatedChangeRequest();
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickClosureInfoInChangeTask();
			expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			snowPage.clickBackButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickBackButton();
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			});		
		}); 


		if(isDummyAdapterDisabled == "false"){
			it('IBM CLoud: Virtual Server - VM instance creation as part of pre-requisite data with Auto Technical, Financial and Legal approval with Standard change.', function () {
				serviceName = "GSLSLTestAutomation" + util.getRandomString(5);
				var modifiedHostName = "GSLSLVM" + util.getRandomString(5);
				modifiedParamMap = {
					"Service Instance Name": serviceName,
					"Hostname": modifiedHostName,
					"Team": "Auto-TEAM1", 
					"Environment": "QA",
					"Application": "",
					"Provider Account": "SL-Testing / SL-Testing"
				};
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				catalogPage.open();
				catalogPage.clickProviderCheckBoxBasedOnName(vmInstanceTemplate.provider);
				catalogPage.clickFirstCategoryCheckBoxBasedOnName(vmInstanceTemplate.Category);
				catalogPage.searchForBluePrint(vmInstanceTemplate.bluePrintName);
				catalogPage.clickConfigureButtonBasedOnName(vmInstanceTemplate.bluePrintName);
				orderObjectVm.servicename = serviceName;
				orderFlowUtil.fillOrderDetails(vmInstanceTemplate, modifiedParamMap);
				placeOrderPage.submitOrder();
				orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObjectVm.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vmInstanceTemplate.orderSubmittedConfirmationMessage);
				placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

				//Validation in Marketplace after auto approval
				expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe("Provisioning in Progress");


				//Validations on SNOW Request page after auto approval
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
				snowPage.waitUntilApprovalIsApprovedQS();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

				expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
				var reqNumber = snowPage.getTextRequestNumberInRequestPage();
				expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

				expect(snowPage.getTextShortDescription()).toBe(vmInstanceTemplate.bluePrintName);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);
				expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();

				expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
				var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
				expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
				expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextChangeReqNumber()).not.toBe("");
				var changeRequestNumber = snowPage.getTextChangeReqNumber();
				expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
				var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vmInstanceTemplate.bluePrintName);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescIbm);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);

				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDVirtualMachine);

				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
				expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
				
				expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
				expect(snowPage.getTextLabelsRITMVariable()).toBe("");
				expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
				
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function (sName) {
					expect(sName).toContain(serviceName);

					// Validate BOM values from Broker config values
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem1ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem2ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem3ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem4ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem5ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem6ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem7ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem8ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem9ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem10ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem11ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem12ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem1ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalIbmVirSer1);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem2ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalIbmVirSer2);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem3ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem4ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem5ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem6ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem7ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem8ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalIbmVirSer8);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem9ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem10ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem11ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem12ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);

					//Validations on SNOW Configuration Item- Service Instance CIs page
					snowPage.switchToDefaultContent();
					snowPage.switchToParentFrame();
					snowPage.openConfItemServiceInstanceCIs();
					expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
					expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
					expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
					snowPage.clickUpdateButton();

					//Validation on Catalog Task page
					snowPage.clickCatalogTaskLink();

					expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
					expect(snowPage.getTextShellCIInCatalogTaskPage()).toEqual(cmdbShellCIName);
					expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
					expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
					expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
					snowPage.clickUpdateButton();

					//Standard change
					snowPage.openRelatedChangeRequest();

					//Change Request Short Desc and Desc
					expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
					expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescNewOrder);

					//Order Completion in SNOW
					snowPage.checkIfProvisioningTaskClosed();

					//Validation in Marketplace
					browser.get(consumeLaunchpadUrl);
					cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
					expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.completedState);

					//Validations on SNOW Request page after Completion
					snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
					expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

					//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
					snowPage.clickRequestedItemLink();
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					
					//Validations on SNOW Configuration Item- Service Instance CIs page
					snowPage.switchToDefaultContent();
					snowPage.switchToParentFrame();
					snowPage.openConfItemServiceInstanceCIs();
					snowPage.getTextCMDBShellCIName();
					expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
					expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
					snowPage.getTextCMDBShellCIAssignmentGroup();
					expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
					expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
					expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.ibmcloudProviderAccountID);
					expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.ibmcloudProviderAccount);
					expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
					expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
					expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
					snowPage.clickUpdateButton();	

					//Change Task Page Validations 
					snowPage.openRelatedChangeRequest();
					snowPage.clickProvTaskLink();
					expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
					expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
					expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
					expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
					expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
					expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
					expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
					snowPage.clickClosureInfoInChangeTask();
					expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
					snowPage.clickBackButton();
					

					//Validation on Catalog Task page after completion
					snowPage.clickBackButton();
					snowPage.clickCatalogTaskLink();
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					snowPage.clickUpdateButton();
				});
			});

			it('IBM CLoud: Virtual Server - Verify VM instance Turn OFF functionality with Auto Technical, Financial and Legal approval with Standard change.', function () {
				var status = vmInstanceTemplate.powerStateOff;		
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				inventoryPage.open();
				inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
				inventoryPage.clickExpandFirstRow().then(function () {
					browser.executeScript('window.scrollTo(0,0);');
					inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
						inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
							inventoryPage.clickOkForInstanceTurnOFFPermission();
							util.waitForAngular();
						});
					});
				}).then(function () {
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vmInstanceTemplate.orderSubmittedConfirmationMessage);
					orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					orderObjectVm.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
					inventoryPage.clickOkForCustomOpnOrderButton();	

					//Validation in Marketplace after auto approval
					expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObjectVm)).toBe(vmInstanceTemplate.orderTypeAction);
					expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.provInProgressState);
					expect(placeOrderPage.getServiceNameOfferingText()).toBe(vmInstanceTemplate.turnOffSvcOfferingName);

					//Validations on SNOW Request page after auto approval
					snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
					snowPage.waitUntilApprovalIsApprovedQS();
					expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

					expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
					var reqNumber = snowPage.getTextRequestNumberInRequestPage();
					expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

					expect(snowPage.getTextShortDescription()).toBe(vmInstanceTemplate.turnOffSvcOfferingName);
					expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
					expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
					expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

					//Validations on SNOW Requested Item page
					snowPage.clickRequestedItemLink();

					expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
					var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
					expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
					expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
					expect(snowPage.getTextChangeReqNumber()).not.toBe("");
					var changeRequestNumber = snowPage.getTextChangeReqNumber();
					expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
					var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vmInstanceTemplate.turnOffSvcOfferingName);					
					//expect((snowPage.getTextReqItemVariableSerOfferDesc()).toLowerCase()).toBe((snowInstanceTemplate.snowReqItemVariablesSerOfferDescOff).toLowerCase());
					snowPage.getTextReqItemVariableSerOfferDesc().then(function(text){
						expect(text.toLowerCase()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOff.toLowerCase());	
					});
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOff);
					expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
					
					expect(snowPage.getTextReqItemVariableConCategory()).toBe("");
					expect(snowPage.getTextMCMPVersionRITMVariable()).toBe('');
					expect(snowPage.getTextLabelsRITMVariable()).toBe("");
					expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");

					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function (sName) {
						expect(sName).toContain(serviceName);
						//expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("stop");
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
						
						// Validate BOM values from Broker config values
						expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

						expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);

						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
						snowPage.clickUpdateButton();

						//Validation on Catalog Task page
						snowPage.clickCatalogTaskLink();

						expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
						expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
						expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
						expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						snowPage.clickUpdateButton();

						//Standard change
						snowPage.openRelatedChangeRequest();

						//Change Request Short Desc and Desc
						expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
						expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescTurnOffOrder);

						//Order Completion in SNOW
						snowPage.checkIfProvisioningTaskClosed();

						//Validation in Marketplace
						browser.get(consumeLaunchpadUrl);
						cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
						expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.completedState);
						inventoryPage.open();
						inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
						var adapterName = "Real";
						var status = vmInstanceTemplate.powerStateOff;
						inventoryPage.clickExpandFirstRow().then(function () {
							inventoryPage.getComponentTags().then(function (text) {
								// if (val == text) {
								// 	status = 'Off';
								// 	adapterName = "dummy";
								// }
								expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObjectVm)).toBe(status);
							});
						});

						//Validations on SNOW Request page after Completion
						snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
						expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
						expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
						expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

						//Validations on SNOW RITM page after Completion
						snowPage.clickRequestedItemLink();
						expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						
						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						snowPage.getTextCMDBShellCIName();
						expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
						expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
						snowPage.getTextCMDBShellCIAssignmentGroup();
						expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
						expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
						expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.ibmcloudProviderAccountID);
						expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.ibmcloudProviderAccount);
						expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
						expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
						expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
						snowPage.clickUpdateButton();	

						//Change Task Page Validations 
						snowPage.openRelatedChangeRequest();
						snowPage.clickProvTaskLink();
						expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
						expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
						expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
						expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
						expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
						expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
						snowPage.clickClosureInfoInChangeTask();
						expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
						snowPage.clickBackButton();


						//Validation on Catalog Task page after completion
						snowPage.clickBackButton();
						snowPage.clickCatalogTaskLink();
						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						snowPage.clickUpdateButton();
					});
				});
			});


			it('IBM CLoud: Virtual Server - Verify VM insance Turn ON functionality with Auto Technical, Financial and Legal approval with Standard change.', function () {			
				var status = vmInstanceTemplate.powerStateOn;
				// var orderObjectvm = {};
				// orderObjectvm.servicename = serviceName;			
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				inventoryPage.open();
				browser.waitForAngular();
				inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
				inventoryPage.clickExpandFirstRow().then(function () {
					browser.executeScript('window.scrollTo(0,0);');
					inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
						inventoryPage.clickTurnONButtonOfInstance().then(function () {
							inventoryPage.clickOkForInstanceTurnONPermission();
							util.waitForAngular();
						});
					});
				}).then(function () {
					console.log(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal());
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vmInstanceTemplate.orderSubmittedConfirmationMessage);
					orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					orderObjectVm.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
					inventoryPage.clickOkForCustomOpnOrderButton();

					//Validation in Marketplace after auto approval
					expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObjectVm)).toBe(vmInstanceTemplate.orderTypeAction);
					expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.provInProgressState);
					expect(placeOrderPage.getServiceNameOfferingText()).toBe(vmInstanceTemplate.turnOnSvcOfferingName);

					//Validations on SNOW Request page after auto approval
					snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
					snowPage.waitUntilApprovalIsApprovedQS();
					expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

					expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
					var reqNumber = snowPage.getTextRequestNumberInRequestPage();
					expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

					expect(snowPage.getTextShortDescription()).toBe(vmInstanceTemplate.turnOnSvcOfferingName);
					expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
					expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
					expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

					//Validations on SNOW Requested Item page
					snowPage.clickRequestedItemLink();

					expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
					var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
					expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
					expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
					expect(snowPage.getTextChangeReqNumber()).not.toBe("");
					var changeRequestNumber = snowPage.getTextChangeReqNumber();
					expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
					var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vmInstanceTemplate.turnOnSvcOfferingName);
					//expect((snowPage.getTextReqItemVariableSerOfferDesc()).toLowerCase()).toBe((snowInstanceTemplate.snowReqItemVariablesSerOfferDescOn).toLowerCase());
					snowPage.getTextReqItemVariableSerOfferDesc().then(function(text){
						expect(text.toLowerCase()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOn.toLowerCase());	
					});
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOn);
					expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
					
					expect(snowPage.getTextReqItemVariableConCategory()).toBe("");
					expect(snowPage.getTextMCMPVersionRITMVariable()).toBe('');
					expect(snowPage.getTextLabelsRITMVariable()).toBe("");
					expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
					
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function (sName) {
						expect(sName).toContain(serviceName);
						//expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("start");
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
						
						// Validate BOM values from Broker config values
						expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

						expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);


						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
						snowPage.clickUpdateButton();
				
						//Validation on Catalog Task page
						snowPage.clickCatalogTaskLink();

						expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
						expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
						expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
						expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						snowPage.clickBackButton();

						//Standard change
						snowPage.openRelatedChangeRequest();
			
						//Change Request Short Desc and Desc
						expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
						expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescTurnOnOrder);
					
						//Order Completion in SNOW
						snowPage.checkIfProvisioningTaskClosed();

						//Validation in Marketplace
						browser.get(consumeLaunchpadUrl);
						cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
						expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.completedState);
						inventoryPage.open();
						inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
						inventoryPage.clickExpandFirstRow().then(function () {
						expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObjectVm)).toBe('On');
						});
	
						//Validations on SNOW Request page after Completion
						snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
						expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
						expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
						expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
						//Validations on SNOW RITM page after Completion
						snowPage.clickRequestedItemLink();
						expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						snowPage.getTextCMDBShellCIName();
						expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
						expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
						snowPage.getTextCMDBShellCIAssignmentGroup();
						expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
						expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
						expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.ibmcloudProviderAccountID);
						expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.ibmcloudProviderAccount);
						expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
						expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
						expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
						snowPage.clickUpdateButton();	

						//Change Task Page Validations 
						snowPage.openRelatedChangeRequest();
						snowPage.clickProvTaskLink();
						expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
						expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
						expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
						expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
						expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
						expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
						snowPage.clickClosureInfoInChangeTask();
						expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
						snowPage.clickBackButton();

						//Validation on Catalog Task page after completion
						snowPage.clickBackButton();
						snowPage.clickCatalogTaskLink();
						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						snowPage.clickUpdateButton();
					});

				});
			});

			it('IBM CLoud: Virtual Server - Verify VM instance Reboot functionality with Auto Technical, Financial and Legal approval with Standard change.', function () {
				var status = vmInstanceTemplate.powerStateOn;						
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				inventoryPage.open();
				browser.waitForAngular();
				inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
				inventoryPage.clickExpandFirstRow().then(function () {
					inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
						inventoryPage.clickRebootButtonOfInstance().then(function () {
							inventoryPage.clickOkForInstanceRebootPermission();
							util.waitForAngular();
						});
					});
				}).then(function () {
					console.log(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal());
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vmInstanceTemplate.orderSubmittedConfirmationMessage);
					orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					orderObjectVm.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
					inventoryPage.clickOkForCustomOpnOrderButton();
					//Validation in Marketplace after auto approval
					expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObjectVm)).toBe(vmInstanceTemplate.orderTypeAction);
					expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.provInProgressState);
					expect(placeOrderPage.getServiceNameOfferingText()).toBe(vmInstanceTemplate.rebootSvcOfferingName);

					//Validations on SNOW Request page after auto approval
					snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
					snowPage.waitUntilApprovalIsApprovedQS();
					expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

					expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
					var reqNumber = snowPage.getTextRequestNumberInRequestPage();
					expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

					expect(snowPage.getTextShortDescription()).toBe(vmInstanceTemplate.rebootSvcOfferingName);
					expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
					expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
					expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");

					//Validations on SNOW Requested Item page
					snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
					snowPage.clickRequestedItemLink();
					
					expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
					var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
					expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
					expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
					expect(snowPage.getTextChangeReqNumber()).not.toBe("");
					var changeRequestNumber = snowPage.getTextChangeReqNumber();
					expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
					var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vmInstanceTemplate.rebootSvcOfferingName);
					//expect((snowPage.getTextReqItemVariableSerOfferDesc()).toLowerCase()).toBe((snowInstanceTemplate.snowReqItemVariablesSerOfferDescReboot).toLowerCase());
					snowPage.getTextReqItemVariableSerOfferDesc().then(function(text){
						expect(text.toLowerCase()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescReboot.toLowerCase());	
					});
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
					expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingReboot);
					expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
					
					expect(snowPage.getTextReqItemVariableConCategory()).toBe("");
					expect(snowPage.getTextMCMPVersionRITMVariable()).toBe('');
					expect(snowPage.getTextLabelsRITMVariable()).toBe("");
					expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
					
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function (sName) {
						expect(sName).toContain(serviceName);					
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("reboot");
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
						
						// Validate BOM values from Broker config values
						expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

						expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);

						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
						snowPage.clickUpdateButton();

						//Validation on Catalog Task page
						snowPage.clickCatalogTaskLink();

						expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
						expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
						expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
						expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						snowPage.clickUpdateButton();

						//Standard change
						snowPage.openRelatedChangeRequest();

						//Change Request Short Desc and Desc
						expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
						expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescRebootOrder);
												
						//Order Completion in SNOW
						snowPage.checkIfProvisioningTaskClosed();
						
						//Validation in Marketplace
						browser.get(consumeLaunchpadUrl);
						cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
						expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.completedState);
						inventoryPage.open();
						inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
						inventoryPage.clickExpandFirstRow().then(function () {
							expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObjectVm)).toBe('On');
						});

						//Validations on SNOW Request page after Completion
						snowPage.logInToSnowQuickstartPortalAndSearchOrder(orderObjectVm.orderNumber);
						expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
						expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
						expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);

						//Validations on SNOW RITM page after Completion
						snowPage.clickRequestedItemLink();
						expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						snowPage.getTextCMDBShellCIName();
						expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
						expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
						snowPage.getTextCMDBShellCIAssignmentGroup();
						expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
						expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
						expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.ibmcloudProviderAccountID);
						expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.ibmcloudProviderAccount);
						expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
						expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
						expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
						snowPage.clickUpdateButton();	

						//Change Task Page Validations 
						snowPage.openRelatedChangeRequest();
						snowPage.clickProvTaskLink();
						expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
						expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
						expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
						expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
						expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
						expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
						expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
						snowPage.clickClosureInfoInChangeTask();
						expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
						snowPage.clickBackButton();

						//Validation on Catalog Task page after completion
						snowPage.clickBackButton();
						snowPage.clickCatalogTaskLink();
						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						snowPage.clickUpdateButton();
					});
				});	
				
			});

			it('IBM Cloud: Virtual Server - Verify Delete functionality with Auto Technical, Financial and Legal approval with Standard change', function () {
			
				//Place Order for Delete in Marketplace
				var orderObject = {};
				orderObject.servicename = orderObjectVm.servicename;
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
				sampleOrder1 = inventoryPage.getDeleteOrderNumber();
				
				//Validation in Marketplace after auto approval
				expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);


				//Validations on SNOW Request page after auto approval
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.waitUntilApprovalIsApprovedQS();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

				expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
				var reqNumber = snowPage.getTextRequestNumberInRequestPage();
				expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

				expect(snowPage.getTextShortDescription()).toBe(vmInstanceTemplate.bluePrintName);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
							
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();

				expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
				var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
				expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
				expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextChangeReqNumber()).not.toBe("");
				var changeRequestNumber = snowPage.getTextChangeReqNumber();
				expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
				var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vmInstanceTemplate.bluePrintName);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescIbm);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
				
				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDVirtualMachine);
				
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
				expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
				
				expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
				expect(snowPage.getTextLabelsRITMVariable()).toBe("");
				expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
					
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(sName).toContain(serviceName);

				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem1ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem2ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem3ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem4ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem5ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem6ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem7ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem8ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem9ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem10ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem11ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem12ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem1ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalIbmVirSerDel1);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem2ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalIbmVirSerDel2);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem3ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem4ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem5ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem6ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem7ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem8ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalIbmVirSerDel8);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem9ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem10ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem11ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem12ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				
					//Validations on SNOW Configuration Item- Service Instance CIs page
					snowPage.openConfItemServiceInstanceCIs();
					expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
					expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
					expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
					snowPage.clickUpdateButton();
					
					//Validation on Catalog Task page
					snowPage.clickCatalogTaskLink();

					expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
					expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
					expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
					expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
					expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					snowPage.clickBackButton();

					//Standard change
					snowPage.openRelatedChangeRequest();
						
					//Change Request Short Desc and Desc
					expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
					expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescDeleteOrder);
					
					//Order Completion in SNOW
					snowPage.checkIfProvisioningTaskClosed();

					//Validation in Marketplace
					browser.get(consumeLaunchpadUrl);
					cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
					expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(slSecurityGrpTemplate.completedOrderStatus);
					
					//Validations on SNOW Request page after Completion
					snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
					expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
					
					//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
					snowPage.clickRequestedItemLink();
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					
					//Validations on SNOW Configuration Item- Service Instance CIs page
					snowPage.switchToDefaultContent();
					snowPage.switchToParentFrame();
					snowPage.openConfItemServiceInstanceCIs();
					snowPage.getTextCMDBShellCIName();
					expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
					expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
					snowPage.getTextCMDBShellCIAssignmentGroup();
					expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
					expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
					expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.ibmcloudProviderAccountID);
					expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.ibmcloudProviderAccount);
					expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
					expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
					expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
					snowPage.clickUpdateButton();	

					//Change Task Page Validations 
					snowPage.openRelatedChangeRequest();
					snowPage.clickProvTaskLink();
					expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
					expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
					expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
					expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
					expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
					expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
					expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
					snowPage.clickClosureInfoInChangeTask();
					expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
					snowPage.clickBackButton();
					
					//Validation on Catalog Task page after completion
					snowPage.clickBackButton();
					snowPage.clickCatalogTaskLink();
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					snowPage.clickUpdateButton();
				});		
			});

		}
	
	}

});
	
	
	
	