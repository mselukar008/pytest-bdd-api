"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    msKafkaTemplate = require('../../../../testData/OrderIntegration/AWS/mskKafka.json');

describe('AWS - MSK-Kafka', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, cluster, dbInstance, serviceName, kafkaObj, inventoryPage;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = msKafkaTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Databases',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        systemTagText: "ibm_mcmp_soiid"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-kafka-" + util.getRandomString(5);
        cluster = "attClu" + util.getRandomString(5)
        kafkaObj = JSON.parse(JSON.stringify(msKafkaTemplate));
    });

    beforeEach(function () {
        modifiedParamMap = { "Service Instance Name": serviceName, "Cluster name": cluster };
    });

    if (isDummyAdapterDisabled == "false") {
        it('AWS-MSK - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
            var serviceDetailsMap = {};
            catalogPage.open();
            orderObject.servicename = serviceName;
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
            catalogPage.clickProviderOrCategoryCheckbox(msKafkaTemplate.Category);
            catalogPage.clickConfigureButtonBasedOnName(msKafkaTemplate.bluePrintName);

            //Fill Order Details
            orderFlowUtil.fillOrderDetails(msKafkaTemplate, modifiedParamMap).then(function (requiredReturnMap) {
                serviceDetailsMap = requiredReturnMap;
                expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(msKafkaTemplate.TotalCost); expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
                expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
                expect(requiredReturnMap["Actual"]["Cluster name"]).toEqual(cluster);
                expect(requiredReturnMap["Actual"]["Apache kafka version"]).toEqual(requiredReturnMap["Expected"]["Apache kafka version"]);
                expect(requiredReturnMap["Actual"]["VPC"]).toEqual(requiredReturnMap["Expected"]["VPC"]);
                expect(requiredReturnMap["Actual"]["Availability zones"]).toEqual(requiredReturnMap["Expected"]["Availability zones"]);
                expect(requiredReturnMap["Actual"]["First Availability Zone"]).toEqual(requiredReturnMap["Expected"]["First Availability Zone"]);
                expect(requiredReturnMap["Actual"]["First Subnet"]).toEqual(requiredReturnMap["Expected"]["First Subnet"]);
                expect(requiredReturnMap["Actual"]["Second Availability Zone"]).toEqual(requiredReturnMap["Expected"]["Second Availability Zone"]);
                expect(requiredReturnMap["Actual"]["Broker instance type"]).toEqual(requiredReturnMap["Expected"]["Broker instance type"]);
                expect(requiredReturnMap["Actual"]["Number of broker nodes"]).toEqual(requiredReturnMap["Expected"]["Number of broker nodes"]);
                expect(requiredReturnMap["Actual"]["EBS storage volume per broker"]).toEqual(requiredReturnMap["Expected"]["EBS storage volume per broker"]);
                expect(requiredReturnMap["Actual"]["Enable encryption within the cluster"]).toEqual(requiredReturnMap["Expected"]["Enable encryption within the cluster"]);
                expect(requiredReturnMap["Actual"]["Between clients and brokers"]).toEqual(requiredReturnMap["Expected"]["Between clients and brokers"]);
                expect(requiredReturnMap["Actual"]["Use customer managed CMK"]).toEqual(requiredReturnMap["Expected"]["Use customer managed CMK"]);
                expect(requiredReturnMap["Actual"]["Amazon CloudWatch metrics for this cluster"]).toEqual(requiredReturnMap["Expected"]["Amazon CloudWatch metrics for this cluster"]);
                expect(requiredReturnMap["Actual"]["Deliver to Amazon CloudWatch Logs"]).toEqual(requiredReturnMap["Expected"]["Deliver to Amazon CloudWatch Logs"]);
                expect(requiredReturnMap["Actual"]["Deliver to Amazon S3"]).toEqual(requiredReturnMap["Expected"]["Deliver to Amazon S3"]);
                expect(requiredReturnMap["Actual"]["Deliver to Amazon Kinesis Data Firehose"]).toEqual(requiredReturnMap["Expected"]["Deliver to Amazon Kinesis Data Firehose"]);
                expect(requiredReturnMap["Actual"]["Cluster settings"]).toEqual(requiredReturnMap["Expected"]["Cluster settings"]);
                //Submit Order
                placeOrderPage.submitOrder();
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(msKafkaTemplate.bluePrintName, "New");
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                //Aprrove Order
                if (isProvisioningRequired == "true") {
                    orderFlowUtil.approveOrder(orderObject);
                    orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 5000);
                    expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                    //Validate Estimated price on approve order page
                    expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(msKafkaTemplate.EstimatedPrice);
                    //Validate pricing on order history page
                    ordersHistoryPage.open();
                    ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                    expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(msKafkaTemplate.EstimatedPrice);
                    ////Verify Output parameter
                    expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
                }
                //Service details on Order History page
                ordersHistoryPage.open();
                ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                ordersHistoryPage.clickServiceDetailsLink();
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(kafkaObj, "AWS Region"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Cluster name")).toEqual(cluster);
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Apache kafka version")).toEqual(jsonUtil.getValue(kafkaObj, "Apache kafka version"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(kafkaObj, "VPC"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Availability zones")).toEqual(jsonUtil.getValue(kafkaObj, "Availability zones"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("First Availability Zone")).toEqual(jsonUtil.getValue(kafkaObj, "First Availability Zone"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("First Subnet")).toEqual(jsonUtil.getValue(kafkaObj, "First Subnet"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Second Availability Zone")).toEqual(jsonUtil.getValue(kafkaObj, "Second Availability Zone"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Broker instance type")).toEqual(jsonUtil.getValue(kafkaObj, "Broker instance type"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Number of broker nodes")).toEqual(jsonUtil.getValue(kafkaObj, "Number of broker nodes"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("EBS storage volume per broker")).toEqual(jsonUtil.getValue(kafkaObj, "EBS storage volume per broker"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Enable encryption within the cluster")).toEqual(jsonUtil.getValue(kafkaObj, "Enable encryption within the cluster"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Between clients and brokers")).toEqual(jsonUtil.getValue(kafkaObj, "Between clients and brokers"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Use customer managed CMK")).toEqual(jsonUtil.getValue(kafkaObj, "Use customer managed CMK"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Amazon CloudWatch metrics for this cluster")).toEqual(jsonUtil.getValue(kafkaObj, "Amazon CloudWatch metrics for this cluster"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Deliver to Amazon CloudWatch Logs")).toEqual(jsonUtil.getValue(kafkaObj, "Deliver to Amazon CloudWatch Logs"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Deliver to Amazon S3")).toEqual(jsonUtil.getValue(kafkaObj, "Deliver to Amazon S3"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Deliver to Amazon Kinesis Data Firehose")).toEqual(jsonUtil.getValue(kafkaObj, "Deliver to Amazon Kinesis Data Firehose"));
                expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Cluster settings")).toEqual(jsonUtil.getValue(kafkaObj, "Cluster settings"));

                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(msKafkaTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(msKafkaTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();

                ordersPage.open();
                expect(util.getCurrentURL()).toMatch('orders');
                ordersPage.clickAllOrdersUnderOrdersSection();
                ordersPage.searchOrderById(orderObject.orderNumber);
                expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
                //Validate service parameters on Approve order page
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
                expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
                expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(kafkaObj, "AWS Region"));
                expect(ordersPage.getTextBasedOnLabelName("Cluster name")).toEqual(cluster);
                expect(ordersPage.getTextBasedOnLabelName("Apache kafka version")).toEqual(jsonUtil.getValue(kafkaObj, "Apache kafka version"));
                expect(ordersPage.getTextBasedOnLabelName("VPC")).toEqual(jsonUtil.getValue(kafkaObj, "VPC"));
                expect(ordersPage.getTextBasedOnLabelName("Availability zones")).toEqual(jsonUtil.getValue(kafkaObj, "Availability zones"));
                expect(ordersPage.getTextBasedOnLabelName("First Availability Zone")).toEqual(jsonUtil.getValue(kafkaObj, "First Availability Zone"));
                expect(ordersPage.getTextBasedOnLabelName("First Subnet")).toEqual(jsonUtil.getValue(kafkaObj, "First Subnet"));
                expect(ordersPage.getTextBasedOnLabelName("Second Availability Zone")).toEqual(jsonUtil.getValue(kafkaObj, "Second Availability Zone"));
                expect(ordersPage.getTextBasedOnLabelName("Broker instance type")).toEqual(jsonUtil.getValue(kafkaObj, "Broker instance type"));
                expect(ordersPage.getTextBasedOnLabelName("Number of broker nodes")).toEqual(jsonUtil.getValue(kafkaObj, "Number of broker nodes"));
                expect(ordersPage.getTextBasedOnLabelName("EBS storage volume per broker")).toEqual(jsonUtil.getValue(kafkaObj, "EBS storage volume per broker"));
                expect(ordersPage.getTextBasedOnLabelName("Enable encryption within the cluster")).toEqual(jsonUtil.getValue(kafkaObj, "Enable encryption within the cluster"));
                expect(ordersPage.getTextBasedOnLabelName("Between clients and brokers")).toEqual(jsonUtil.getValue(kafkaObj, "Between clients and brokers"));
                expect(ordersPage.getTextBasedOnLabelName("Use customer managed CMK")).toEqual(jsonUtil.getValue(kafkaObj, "Use customer managed CMK"));
                expect(ordersPage.getTextBasedOnLabelName("Amazon CloudWatch metrics for this cluster")).toEqual(jsonUtil.getValue(kafkaObj, "Amazon CloudWatch metrics for this cluster"));
                expect(ordersPage.getTextBasedOnLabelName("Deliver to Amazon CloudWatch Logs")).toEqual(jsonUtil.getValue(kafkaObj, "Deliver to Amazon CloudWatch Logs"));
                expect(ordersPage.getTextBasedOnLabelName("Deliver to Amazon S3")).toEqual(jsonUtil.getValue(kafkaObj, "Deliver to Amazon S3"));
                expect(ordersPage.getTextBasedOnLabelName("Deliver to Amazon Kinesis Data Firehose")).toEqual(jsonUtil.getValue(kafkaObj, "Deliver to Amazon Kinesis Data Firehose"));
                expect(ordersPage.getTextBasedOnLabelName("Cluster settings")).toEqual(jsonUtil.getValue(kafkaObj, "Cluster settings"));

                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(msKafkaTemplate.TotalCost);
                ordersPage.clickServiceDetailSliderCloseButton();
            });
        });

        it('AWS MSK - Validate system tags, Edit and Delete Service', function () {
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                if (isDummyAdapterDisabled == "true") {
                    orderObject.componentType = msKafkaTemplate.componentType1;
                    inventoryPage.clickOverflowACtionBtnBasedOnComponent(msKafkaTemplate.componentType1).then(function (index) {
                        inventoryPage.clickViewComponentBasedOnIndex(index - 1).then(function () {
                            //View Component VM details
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(msKafkaTemplate.componentType1);
                            expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);

                            //View Component Template Output Properties
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("ClusterName")).toEqual(cluster);
                            expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("NumberOfBrokerNodes")).toEqual(jsonUtil.getValueEditParameter(kafkaObj, "Number of broker nodes"));

                        });
                        inventoryPage.getTagsOnInventory().then(function (tags) {
                            var tagList = tags.split(",");
                            var tagMap = inventoryPage.getServiceTags(tagList);
                            var mcmpTag = false;
                            //verifying a system tag
                            expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                            //verifying some of the service tags  
                            expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:logical-id:")))).toBe(true);
                            expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-id:")))).toBe(true);
                            expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-name:")))).toBe(true);
                            expect(tagList.includes(tagList.find(tag => tag.includes("stackId:arn:aws:cloudformation:")))).toBe(true);
                            expect(tagList.includes(tagList.find(tag => tag.includes("ibm_mcmp_soiid:")))).toBe(true);
                            expect(tagMap["serviceInstanceName"].toLowerCase()).toContain(serviceName.toLowerCase());
                        });
                    });
                } else {
                    inventoryPage.clickOverflowActionButtonForPowerStates();
                    inventoryPage.clickViewComponentofAWSInstance();
                    inventoryPage.getTagsOnInventory().then(function (tags) {
                        var tagList = tags.split(",");
                        var tagMap = inventoryPage.getServiceTags(tagList);
                        //verifying flags for dummy adapter
                        expect(tagMap["IsUsingDummy"]).toEqual("Yes");
                        expect(tagMap["Name"]).toEqual(msKafkaTemplate.bluePrintName);
                        expect(tagMap["PhysicalId"]).toContain(serviceName);
                        expect(Object.keys(tagMap).includes("Test")).toBe(true);
                        expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
                    });
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("AWS Region")).toEqual(jsonUtil.getValue(kafkaObj, "AWS Region"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Cluster name")).toEqual(cluster);
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Apache kafka version")).toEqual(jsonUtil.getValue(kafkaObj, "Apache kafka version"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("VPC")).toEqual(jsonUtil.getValue(kafkaObj, "VPC"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Availability zones")).toEqual(jsonUtil.getValue(kafkaObj, "Availability zones"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("First Availability Zone")).toEqual(jsonUtil.getValue(kafkaObj, "First Availability Zone"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("First Subnet")).toEqual(jsonUtil.getValue(kafkaObj, "First Subnet"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Second Availability Zone")).toEqual(jsonUtil.getValue(kafkaObj, "Second Availability Zone"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Broker instance type")).toEqual(jsonUtil.getValue(kafkaObj, "Broker instance type"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Number of broker nodes")).toEqual(jsonUtil.getValue(kafkaObj, "Number of broker nodes"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("EBS storage volume per broker")).toEqual(jsonUtil.getValue(kafkaObj, "EBS storage volume per broker"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Enable encryption within the cluster")).toEqual(jsonUtil.getValue(kafkaObj, "Enable encryption within the cluster"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Between clients and brokers")).toEqual(jsonUtil.getValue(kafkaObj, "Between clients and brokers"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Use customer managed CMK")).toEqual(jsonUtil.getValue(kafkaObj, "Use customer managed CMK"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Amazon CloudWatch metrics for this cluster")).toEqual(jsonUtil.getValue(kafkaObj, "Amazon CloudWatch metrics for this cluster"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Deliver to Amazon CloudWatch Logs")).toEqual(jsonUtil.getValue(kafkaObj, "Deliver to Amazon CloudWatch Logs"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Deliver to Amazon S3")).toEqual(jsonUtil.getValue(kafkaObj, "Deliver to Amazon S3"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Deliver to Amazon Kinesis Data Firehose")).toEqual(jsonUtil.getValue(kafkaObj, "Deliver to Amazon Kinesis Data Firehose"));
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("Cluster settings")).toEqual(jsonUtil.getValue(kafkaObj, "Cluster settings"));

                }
                orderFlowUtil.closeHorizontalSliderIfPresent();
            });

            //Edit service flow       
            var dbClusterEdit = "newcluster" + util.getRandomString(5);
            var modifiedParamMapEdit = { "EditService": true, "Cluster name": dbClusterEdit };
            orderFlowUtil.editService(orderObject);
            orderFlowUtil.fillOrderDetails(msKafkaTemplate, modifiedParamMapEdit).then(function (reviewOrderExpActParamsMap) {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(msKafkaTemplate.TotalCostPostEdit);

                //Validate Review order page parameters
                expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
            });
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(msKafkaTemplate.bluePrintName, "Edit");
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 5000);
            orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
                if (status == 'Completed') {
                    //Verify updated details are reflected on order details page.						
                    ordersPage.clickFirstViewDetailsOrdersTable();
                    expect(ordersPage.getTextBasedOnLabelName("Cluster name")).toEqual(dbClusterEdit);
                    // expect(ordersPage.getTextBasedOnLabelName("Number of broker nodes")).toEqual(jsonUtil.getValueEditParameter(kafkaObj, "Number of broker nodes"));
                    expect(ordersPage.getTextBasedOnLabelName("EBS storage volume per broker")).toEqual(jsonUtil.getValueEditParameter(kafkaObj, "EBS storage volume per broker"));

                    ordersPage.clickBillOfMaterialsTabOrderDetails();
                    expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(msKafkaTemplate.TotalCostPostEdit);
                    ordersPage.clickServiceDetailSliderCloseButton();
                    //Delete Service flow                    
                    orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, msKafkaTemplate.bluePrintName);
                    orderFlowUtil.approveDeletedOrder(orderObject);
                    orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed', 5000);
                    expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
                }
            });
        });
    }

});
