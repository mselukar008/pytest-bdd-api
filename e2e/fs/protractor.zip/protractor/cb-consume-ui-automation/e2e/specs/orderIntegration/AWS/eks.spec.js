"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    eksTemplate = require('../../../../testData/OrderIntegration/AWS/eks.json');

describe('AWS - EKS', function () {
    var ordersPage, catalogPage, placeOrderPage, ordersHistoryPage, serviceName, tableName, keySpaceName, eksObj, inventoryPage, msgToVerify;
    var modifiedParamMap = {};
    var orderObject = {};
    orderObject.componentType = eksTemplate.componentType;
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Containers',
        catalogPageTitle: 'Search, Select and Configure',
        inputServiceNameWarning: "Parameter Warning:",
        orderSubmittedConfirmationMessage: 'Order Submitted !',
        provInProgressState: "Provisioning in Progress",
        completedState: "Completed",
        systemTagText: "ibm_mcmp_soiid"
    };

    beforeAll(function () {
        ordersPage = new Orders();
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        inventoryPage = new InventoryPage();
        ordersHistoryPage = new OrderHistoryPage();
        serviceName = "aws-auto-eks-" + util.getRandomString(5);
        eksObj = JSON.parse(JSON.stringify(eksTemplate));
    });

    beforeEach(function () {
        modifiedParamMap = { "Service Instance Name": serviceName };
    });

    it('AWS-EKS - Verify Main Parameters page, Summary and Additional Details are listed in Review/Approve/OrderHistory page and Provisioning is working fine', function () {
        var serviceDetailsMap = {};
        catalogPage.open();
        orderObject.servicename = serviceName;
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(eksTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(eksTemplate.bluePrintName);

        //Fill Order Details
        orderFlowUtil.fillOrderDetails(eksTemplate, modifiedParamMap).then(function (requiredReturnMap) {
            serviceDetailsMap = requiredReturnMap;
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
            if (browser.params.defaultCurrency == "USD") {
                expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(eksTemplate.TotalCost); expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            }
            expect(requiredReturnMap["Actual"]["AWS Region"]).toEqual(requiredReturnMap["Expected"]["AWS Region"]);
            expect(requiredReturnMap["Actual"]["Name"]).toEqual(requiredReturnMap["Expected"]["Name"]);
            expect(requiredReturnMap["Actual"]["Kubernetes Version"]).toEqual(requiredReturnMap["Expected"]["Kubernetes Version"]);
            expect(requiredReturnMap["Actual"]["Cluster Role ARN"]).toEqual(requiredReturnMap["Expected"]["Cluster Role ARN"]);
            expect(requiredReturnMap["Actual"]["Node Role ARN"]).toEqual(requiredReturnMap["Expected"]["Node Role ARN"]);
            expect(requiredReturnMap["Actual"]["VPC Block"]).toEqual(requiredReturnMap["Expected"]["VPC Block"]);
            expect(requiredReturnMap["Actual"]["Subnet01Block"]).toEqual(requiredReturnMap["Expected"]["Subnet01Block"]);
            expect(requiredReturnMap["Actual"]["Subnet02Block"]).toEqual(requiredReturnMap["Expected"]["Subnet02Block"]);
            expect(requiredReturnMap["Actual"]["AMI Type"]).toEqual(requiredReturnMap["Expected"]["AMI Type"]);
            expect(requiredReturnMap["Actual"]["Instance Type"]).toEqual(requiredReturnMap["Expected"]["Instance Type"]);
            expect(requiredReturnMap["Actual"]["Disk Size (in GiB)"]).toEqual(requiredReturnMap["Expected"]["Disk Size (in GiB)"]);
            expect(requiredReturnMap["Actual"]["Desired Size"]).toEqual(requiredReturnMap["Expected"]["Desired Size"]);
            expect(requiredReturnMap["Actual"]["Min Size"]).toEqual(requiredReturnMap["Expected"]["Min Size"]);
            expect(requiredReturnMap["Actual"]["Max Size"]).toEqual(requiredReturnMap["Expected"]["Max Size"]);
            expect(requiredReturnMap["Actual"]["Key Pair"]).toEqual(requiredReturnMap["Expected"]["Key Pair"]);


            //Submit Order
            placeOrderPage.submitOrder();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(eksTemplate.bluePrintName, "New");
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            //Aprrove Order
            if (isProvisioningRequired == "true") {
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed', 800);
                expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe('Completed');
                //Validate Estimated price on approve order page
                expect(ordersPage.getTextFirstAmountOrdersTable()).toBe(eksTemplate.EstimatedPrice);
                if (browser.params.defaultCurrency == "USD") {
                    //Validate pricing on order history page
                    ordersHistoryPage.open();
                    ordersHistoryPage.searchOrderById(orderObject.orderNumber);
                    expect(ordersHistoryPage.getTextEstimatedCostOrderHistory()).toBe(eksTemplate.EstimatedPrice);
                }
                ////Verify Output parameter
                expect(inventoryPage.verifyOutputParams(serviceDetailsMap, orderObject)).toBe(true);
            }
            //Service details on Order History page
            ordersHistoryPage.open();
            ordersHistoryPage.searchOrderById(orderObject.orderNumber);
            ordersHistoryPage.clickServiceDetailsLink();
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(eksObj, "AWS Region"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Name")).toEqual(jsonUtil.getValue(eksObj, "Name"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Kubernetes Version")).toEqual(jsonUtil.getValue(eksObj, "Kubernetes Version"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Cluster Role ARN")).toEqual(jsonUtil.getValue(eksObj, "Cluster Role ARN"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Node Role ARN")).toEqual(jsonUtil.getValue(eksObj, "Node Role ARN"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("VPC Block")).toEqual(jsonUtil.getValue(eksObj, "VPC Block"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Subnet01Block")).toEqual(jsonUtil.getValue(eksObj, "Subnet01Block"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Subnet02Block")).toEqual(jsonUtil.getValue(eksObj, "Subnet02Block"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("AMI Type")).toEqual(jsonUtil.getValue(eksObj, "AMI Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(eksObj, "Instance Type"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Disk Size (in GiB)")).toEqual(jsonUtil.getValue(eksObj, "Disk Size (in GiB)"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Desired Size")).toEqual(jsonUtil.getValue(eksObj, "Desired Size"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Min Size")).toEqual(jsonUtil.getValue(eksObj, "Min Size"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Max Size")).toEqual(jsonUtil.getValue(eksObj, "Max Size"));
            expect(ordersHistoryPage.getTextServiceDetailsBasedOnLabelName("Key Pair")).toEqual(jsonUtil.getValue(eksObj, "Key Pair"));
            if (browser.params.defaultCurrency == "USD") {
                ordersHistoryPage.clickBillOfMaterialsTabInServiceDetails();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(eksTemplate.TotalCost);
                ordersHistoryPage.closeServiceDetailsSlider();
                ordersHistoryPage.clickBillOfMaterials();
                expect(ordersHistoryPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(eksTemplate.TotalCost);
            }
            ordersHistoryPage.closeServiceDetailsSlider();
            ordersPage.open();
            expect(util.getCurrentURL()).toMatch('orders');
            ordersPage.clickAllOrdersUnderOrdersSection();
            ordersPage.searchOrderById(orderObject.orderNumber);
            expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderObject.orderNumber);
            //Validate service parameters on Approve order page
            ordersPage.clickFirstViewDetailsOrdersTable();
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toEqual(messageStrings.providerName);
            expect(ordersPage.getTextBasedOnLabelName("AWS Region")).toEqual(jsonUtil.getValue(eksObj, "AWS Region"));
            expect(ordersPage.getTextBasedOnExactLabelName("Name")).toEqual(jsonUtil.getValue(eksObj, "Name"));
            expect(ordersPage.getTextBasedOnLabelName("Kubernetes Version")).toEqual(jsonUtil.getValue(eksObj, "Kubernetes Version"));
            expect(ordersPage.getTextBasedOnLabelName("Cluster Role ARN")).toEqual(jsonUtil.getValue(eksObj, "Cluster Role ARN"));
            expect(ordersPage.getTextBasedOnLabelName("Node Role ARN")).toEqual(jsonUtil.getValue(eksObj, "Node Role ARN"));
            expect(ordersPage.getTextBasedOnLabelName("VPC Block")).toEqual(jsonUtil.getValue(eksObj, "VPC Block"));
            expect(ordersPage.getTextBasedOnLabelName("Subnet01Block")).toEqual(jsonUtil.getValue(eksObj, "Subnet01Block"));
            expect(ordersPage.getTextBasedOnLabelName("Subnet02Block")).toEqual(jsonUtil.getValue(eksObj, "Subnet02Block"));
            expect(ordersPage.getTextBasedOnLabelName("AMI Type")).toEqual(jsonUtil.getValue(eksObj, "AMI Type"));
            expect(ordersPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValue(eksObj, "Instance Type"));
            expect(ordersPage.getTextBasedOnLabelName("Disk Size (in GiB)")).toEqual(jsonUtil.getValue(eksObj, "Disk Size (in GiB)"));
            expect(ordersPage.getTextBasedOnLabelName("Desired Size")).toEqual(jsonUtil.getValue(eksObj, "Desired Size"));
            expect(ordersPage.getTextBasedOnLabelName("Min Size")).toEqual(jsonUtil.getValue(eksObj, "Min Size"));
            expect(ordersPage.getTextBasedOnLabelName("Max Size")).toEqual(jsonUtil.getValue(eksObj, "Max Size"));
            expect(ordersPage.getTextBasedOnLabelName("Key Pair")).toEqual(jsonUtil.getValue(eksObj, "Key Pair"));
            if (browser.params.defaultCurrency == "USD") {
                ordersPage.clickBillOfMaterialsTabOrderDetails();
                expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(eksTemplate.TotalCost);
            }
            ordersPage.clickServiceDetailSliderCloseButton();

        });
    });

    it('AWS EKS - Validate system tags, Edit and Delete Service', function () {

        orderObject.componentType = eksTemplate.componentType1;
        inventoryPage.open();
        inventoryPage.searchOrderByServiceName(orderObject.servicename);
        inventoryPage.clickExpandFirstRow().then(function () {
            inventoryPage.clickOverflowACtionBtnBasedOnComponent(eksTemplate.componentType1).then(function () {
                inventoryPage.clickViewComponentBasedOnIndex(5).then(function () {
                    //View Component VM details
                    expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(eksTemplate.componentType1);
                    expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);
                    expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Resource Id")).toEqual(eksTemplate.ResourceId);

                    //View Component Template Output Properties
                    expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("CidrBlock")).toEqual(eksTemplate.cidr);

                });
            });
        });
        //Validate service Tags       
        inventoryPage.getTagsOnInventory().then(function (tags) {
            var tagList = tags.split(",");
            var tagMap = inventoryPage.getServiceTags(tagList);
            var mcmpTag = false;
            if (isDummyAdapterDisabled == "false") {
                //verifying flags for dummy adapter
                expect(tagMap["IsUsingDummy"]).toEqual(messageStrings.isDummyTagValue);
                expect(tagMap["Name"]).toEqual(eksTemplate.bluePrintName);
                expect(tagMap["PhysicalId"]).toContain(serviceName);
                expect(Object.keys(tagMap).includes("Test")).toBe(true);
                expect(Object.keys(tagMap).includes("TrackingId")).toBe(true);
            } else {
                //verifying a system tag
                expect(Object.keys(tagMap).includes(messageStrings.systemTagText)).toBe(true);
                //verifying some of the service tags             
                expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:logical-id")))).toBe(true);
                expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-id")))).toBe(true);
                expect(tagList.includes(tagList.find(tag => tag.includes("aws:cloudformation:stack-name")))).toBe(true);
                expect(tagList.includes(tagList.find(tag => tag.includes("kubernetes.io/cluster/att-cluster")))).toBe(true);
                expect(tagList.includes(tagList.find(tag => tag.includes("kubernetes.io/role/elb")))).toBe(true);
                expect(tagMap["serviceInstanceName"].toLowerCase()).toContain(serviceName.toLowerCase());
            }
            orderFlowUtil.closeHorizontalSliderIfPresent();
            inventoryPage.clickExpandFirstRow();
        });

        //Edit service flow
        var modifiedParamMap = { "EditService": true };
        orderFlowUtil.editService(orderObject);
        orderFlowUtil.fillOrderDetails(eksTemplate, modifiedParamMap).then(function (reviewOrderExpActParamsMap) {
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(eksTemplate.TotalCostPostEdit);
            //Validate Review order page parameters
            expect(placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
        });
        placeOrderPage.submitOrder();
        orderObject.orderNumber = placeOrderPage.getAndSaveOrderId(eksTemplate.bluePrintName, "Edit");
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
        placeOrderPage.clickgoToInventoryButtonOrderSubmittedModal();
        orderFlowUtil.approveOrder(orderObject);
        orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed');
        orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
            if (status == 'Completed') {
                //Verify updated details are reflected on order details page.						
                ordersPage.clickFirstViewDetailsOrdersTable();
                expect(ordersPage.getTextBasedOnExactLabelName("Name")).toEqual(jsonUtil.getValueEditParameter(eksTemplate, "Name"));
                expect(ordersPage.getTextBasedOnLabelName("Instance Type")).toEqual(jsonUtil.getValueEditParameter(eksTemplate, "Instance Type"));
                expect(ordersPage.getTextBasedOnLabelName("AMI Type")).toEqual(jsonUtil.getValueEditParameter(eksTemplate, "AMI Type"));
                if (browser.params.defaultCurrency == "USD") {
                    ordersPage.clickBillOfMaterialsTabOrderDetails();
                    expect(ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(eksTemplate.TotalCostPostEdit);
                }
                ordersPage.clickServiceDetailSliderCloseButton();
                //Delete Service flow                    
                orderObject.deleteOrderNumber = orderFlowUtil.deleteServiceAndSaveOrderId(orderObject, eksTemplate.bluePrintName);
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');
            }
        });
    });
});
