/*
Spec_Name: createImageFromVM.spec.js 
Description: This spec will cover E2E testing of Create Image From VM service order submit, approve and delete.
             Verify all parameters of "Main Parameters", "Review Order" and "View Order Details".   
Author: Atiksha Batra 
*/

"use strict";
var Orders = require('../../../pageObjects/orders.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
    appUrls = require('../../../../testData/appUrls.json'),
    util = require('../../../../helpers/util.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    IVMTemplate = require('../../../../testData/OrderIntegration/Azure/ImageFromVM.json');

if (isDummyAdapterDisabled == "true") {
    describe('Azure - Image From VM', function () {
        var ordersPage, catalogPage, inventoryPage, placeOrderPage, catalogDetailsPage;
        var modifiedParamMap = {};
        var messageStrings = { providerName: 'Azure', category: 'Storage' };
        var modifiedParamMap = {};
        var modifiedParamMap1 = {};
        var servicename = "AutoIVMsrv" + util.getRandomString(5);
        var rgName = "gslautotc_azure_IFVMRG" + util.getRandomString(5);
        var vnName = "autovn" + util.getRandomString(5);
        var storageacc = "autost" + util.getRandomNumber(5);
        var publicIPName = "testip" + util.getRandomString(5);
        var virtualMachineNameorder = "gslautoVM" + util.getRandomString(3);
        var virtualMachineName = virtualMachineNameorder;
        var rgName1, imageName;
        modifiedParamMap = { "Service Instance Name": servicename, "Virtual Network Name": vnName, "Diagnostics Storage Account Name": storageacc, "New Resource Group": rgName, "Public IP Address Name": publicIPName, "Virtual Machine Name": virtualMachineNameorder }
        var returnObj = {};

        beforeAll(function () {
            ordersPage = new Orders();
            catalogPage = new CatalogPage();
            placeOrderPage = new PlaceOrderPage();
            inventoryPage = new InventoryPage();
            catalogDetailsPage = new CatalogDetailsPage();
            browser.driver.manage().window().maximize();
        });

        afterAll(function () {
            returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
            orderFlowUtil.approveDeletedOrder(returnObj);
            orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Provisioning in Progress');
        });

        beforeEach(function () {
            rgName1 = "gslautotc_azure_imageRG" + util.getRandomString(5);
            imageName = "testimage" + util.getRandomString(5);
            modifiedParamMap1 = { "Service Instance Name": servicename, "New Resource Group": rgName1, "Image Name": imageName, "Resource Group For VM": rgName, "List Virtual Machines": virtualMachineName }
            catalogPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
            catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        });

        //Prerequisites: We need to create a Windows VM which can be used by Create Image.
        it('Azure: create a Windows VM', function () {
            var orderObject1 = JSON.parse(JSON.stringify(IVMTemplate.createWindowsVM));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject1.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject1.bluePrintName);
            orderFlowUtil.fillOrderDetails(IVMTemplate.createWindowsVM, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, 'Completed', 100);
        })

        //Checking parameters on Main Parameters page
        it('Azure: TC-C178715 Verify that for Image from VM Service all parameters on Main Parameters Page are present.', function () {
            var orderObject = JSON.parse(JSON.stringify(IVMTemplate.createImageFromVMRGNO));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);
            if (browser.params.defaultCurrency == "USD") {
            expect(catalogDetailsPage.getTextEstimatedPrice()).toBe(orderObject.BasePrice);
            }
        });

        //Checking values of all parameters on Review Order Page and View Order Details
        it('Azure: TC-C178717 Verify that for Image from VM Service all values on Review Order Details and View Order Details page matches with input.', function () {
            var returnObj = {};
            returnObj.servicename = servicename;
            var orderObject = JSON.parse(JSON.stringify(IVMTemplate.createImageFromVMRGNO));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            orderFlowUtil.fillOrderDetails(IVMTemplate.createImageFromVMRGNO, modifiedParamMap1);
            //Checking Service Details in ReviewOrder
            expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(returnObj.servicename);
            if (browser.params.defaultCurrency == "USD") {
            expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(orderObject.TotalCost);
            }
            //Checking Additional Details in ReviewOrder
            expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group Required:")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
            expect(placeOrderPage.getTextBasedOnLabelName(" New Resource Group:")).toEqual(rgName1);
            expect(placeOrderPage.getTextBasedOnLabelName(" Location:")).toEqual(jsonUtil.getValue(orderObject, "Location"));
            expect(placeOrderPage.getTextBasedOnLabelName(" Resource Group For VM:")).toEqual(rgName);
            expect(placeOrderPage.getTextBasedOnLabelName(" List Virtual Machines:")).toEqual(virtualMachineName);
            expect(placeOrderPage.getTextBasedOnLabelName(" Virtual Machine Location:")).toEqual(jsonUtil.getValue(orderObject, "Virtual Machine Location"));
            expect(placeOrderPage.getTextBasedOnLabelName(" Delete VM After Image Creation:")).toEqual(jsonUtil.getValue(orderObject, "Delete VM After Image Creation"));
            expect(placeOrderPage.getTextBasedOnLabelName(" Image Name:")).toEqual(imageName);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            ordersPage.open();
            ordersPage.searchOrderById(returnObj.orderNumber);
            ordersPage.clickFirstViewDetailsOrdersTable();
            //Checking Order Details in View order details
            expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename);//Checking Service Name
            expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider);//Checking Provider
            //Checking Service Configuration Parameters
            ordersPage.clickServiceConfigurationsTabOrderDetails();
            expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group Required")).toEqual(jsonUtil.getValue(orderObject, "New Resource Group Required"));
            expect(ordersPage.getTextBasedOnExactLabelName("New Resource Group")).toEqual(rgName1);
            expect(ordersPage.getTextBasedOnExactLabelName("Location")).toEqual(jsonUtil.getValue(orderObject, "Location"));
            expect(ordersPage.getTextBasedOnExactLabelName("Resource Group For VM")).toEqual(rgName);
            expect(ordersPage.getTextBasedOnExactLabelName("List Virtual Machines")).toEqual(virtualMachineName);
            expect(ordersPage.getTextBasedOnExactLabelName("Virtual Machine Location")).toEqual(jsonUtil.getValue(orderObject, "Virtual Machine Location"));
            expect(ordersPage.getTextBasedOnExactLabelName("Delete VM After Image Creation")).toEqual(jsonUtil.getValue(orderObject, "Delete VM After Image Creation"));
            expect(ordersPage.getTextBasedOnExactLabelName("Image Name")).toEqual(imageName);
            //Checking Bill Of Material
            if (browser.params.defaultCurrency == "USD") {
            ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(ordersPage.getEstimatedCost()).toBe(orderObject.TotalCost);
            }
            ordersPage.clickServiceDetailSliderCloseButton();
        });
    });
}