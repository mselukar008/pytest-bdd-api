/*
Spec_Name:MultipleUser.spec.js 
Description: This spec will cover E2E testing of Service service order submit, approve and delete.
             Verify all parameters of Budget with single Users.   
Author: Atiksha Batra
*/
"use strict";

var logGenerator = require("../../../../helpers/logGenerator.js"),
    Logger = logGenerator.getApplicationLogger(),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
    HomePage = require('../../../pageObjects/home.pageObject'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    superUserUsername = browser.params.username,
    superUserPassword = browser.params.password,
    budgetaryFlow           = require('../../../../helpers/budgetaryFlow.js'),
    multiUserBudgetTemplate = require('../../../../testData/OrderIntegration/Azure/multiUserBudgetService.json'),
    budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
    budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryAddNewBudgetDetails.json'),
    BudgetaryPage    = require('../../../pageObjects/budget.pageObject.js');
    


describe('Azure - Multi user Budget with Multiple Budget', function () {
    var catalogPage, placeOrderPage, ordersPage, serviceName, cartListPage,rgName,sbName,budgetaryNameOne, budgetaryNameTwo, budgetaryUnitCodeOne, budgetaryUnitCodeTwo, budgetaryNewBudgetNameOne, budgetaryNewBudgetNameTwo,budgetryPage, homePage;
    var modifiedParamMap = {};
    var messageStrings = { providerName: 'Azure', category: 'Other Services' ,budgetaryUnitDeletedApiSucessMsg: budgetaryUnitDetailsTemplate.budgetaryUnitDeletedApiSucessMsg,
    budgetDeletedApiSucessMsg: budgetaryUnitDetailsTemplate.budgetDeletedApiSucessMsg,};
    var modifiedParamMapBudget = {};
    var modifiedNewBudgetParamMap = {};
    var multiUserBudgetObject = JSON.parse(JSON.stringify(multiUserBudgetTemplate));

    beforeAll(function () {
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        cartListPage = new CartListPage();
        budgetryPage = new BudgetaryPage();
        homePage = new HomePage();
        browser.driver.manage().window().maximize();
        budgetaryNameOne = "MaabudgetaryName" + util.getRandomString(8);
        budgetaryNameTwo = "MaabudgetaryName" + util.getRandomString(8);
        budgetaryNewBudgetNameOne = "aabudgetaryNewBudgetName" + util.getRandomString(8);
        budgetaryNewBudgetNameTwo = "aabudgetaryNewBudgetName" + util.getRandomString(8);
        budgetaryUnitCodeOne = "budgetaryUnitCodeOne" + util.getRandomString(8);
        budgetaryUnitCodeTwo = "budgetaryUnitCodeTwo" + util.getRandomString(8);
        modifiedParamMapBudget = { "budgetary Name": budgetaryNameOne, "budgetary unit code": budgetaryUnitCodeOne, "Choose Entity": "Organization", "Entity Value":"budgetORG", "Environment": "azureENV", "Application": "azureAPP" };
        var startPeriod = budgetaryFlow.incrementMonth(0);
        modifiedNewBudgetParamMap = { "Name": budgetaryNewBudgetNameOne, "Start Period": startPeriod, "Budget Amount": "1000.00" };
        homePage.open();
    });
    beforeEach(function () {
       
        catalogPage.open();
        serviceName = "AzureTestAutomation" + util.getRandomString(5);
        rgName = "gslautotc_azure_sbRG" + util.getRandomString(5);
        sbName = "AutoSB101" + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "New Resource Group": rgName, "Service Bus Name": sbName }
        budgetryPage.closeBudgetSliderIfPresent();       
    });

    it('Add one budgetry Unit for E2E flow ', function () {
        budgetryPage.closeBudgetSliderIfPresent();
        //catalogPage.checkCurrentUser(credentialJson.superUserName);
        modifiedParamMapBudget = { "budgetary Name": budgetaryNameOne, "budgetary unit code": budgetaryUnitCodeOne, "Choose Entity": "Organization", "Entity Value":"budgetORG", "Environment": "azureENV", "Application": "azureAPP" };
        budgetryPage.open();
        util.waitForAngular();
        budgetryPage.clickOnAddNewBudgetryUnitBtn();
        budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMapBudget);
        budgetryPage.clickOnBudgetrySaveBtn();
        budgetryPage.clickOnBudgetryBudgetsLink();
        budgetryPage.clickOnBudgetaryAddBudgetButton();
        budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);
        budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
        budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
        // budgetryPage.clickOnBudgetaryBackBudgetButton();
        budgetryPage.clickBudgetSliderCloseButton();

    });
    it('Add Sceond budgetry Unit for E2E budget Flow ', function () {
        modifiedParamMapBudget = { "budgetary Name": budgetaryNameTwo, "budgetary unit code": budgetaryUnitCodeTwo, "Choose Entity": "Organization", "Entity Value":"budgetORG", "Environment": "azureENV", "Application": "azureAPP" };
        budgetryPage.open();
        util.waitForAngular();
        budgetryPage.clickOnAddNewBudgetryUnitBtn();
        budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMapBudget);
        budgetryPage.clickOnBudgetrySaveBtn();
        budgetryPage.clickOnBudgetryBudgetsLink();
        budgetryPage.clickOnBudgetaryAddBudgetButton();
        var startPeriod = budgetaryFlow.incrementMonth(0); // Zero (0) for current
        // month
        modifiedNewBudgetParamMap = { "Name": budgetaryNewBudgetNameTwo, "Start Period": startPeriod, "Budget Amount": "1000.00" };
        budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);
        budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
        budgetryPage.clickOnBudgetaryEditUpdateSuccessCloseButton();
        // budgetryPage.clickOnBudgetaryBackBudgetButton();
        budgetryPage.closeBudgetSliderIfPresent();

    });

    if (isProvisioningRequired == "true") {


        it('Service Bus Verify the budget for Service Bus', async function () {
            var orderObject = {};
            var multiUserBudgetObject = JSON.parse(JSON.stringify(multiUserBudgetTemplate));

            // Logout from the super user
            // await cartListPage.clickUserIcon();
            // await cartListPage.clickLogoutButton();

            //login with the buyer role user and place order
            await cartListPage.loginFromOtherUser(multiUserBudgetObject.buyerUserID, multiUserBudgetObject.buyerUserPassword);
            catalogPage.open();
            catalogPage.clickProviderOrCategoryCheckbox(messageStrings.providerName);
            catalogPage.clickProviderOrCategoryCheckbox(multiUserBudgetObject.Category);
            catalogPage.searchForBluePrint(multiUserBudgetObject.bluePrintName);
            catalogPage.clickConfigureButtonBasedOnName(multiUserBudgetTemplate.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetailsICAM(multiUserBudgetTemplate, modifiedParamMap);
                //Submit order through the buyer role user
                placeOrderPage.submitOrder();
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();


                //Get details on pop up after submit
                var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();

                expect(ordersubmittedBy).toEqual(multiUserBudgetTemplate.buyerUserName);
               
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(multiUserBudgetTemplate.orderSubmitted);
                placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
                //catalogPage.open();
                util.waitForAngular();
                // Logout from the buyer role user
                // cartListPage.clickUserIcon();
                // cartListPage.clickLogoutButton();

                //Login with technical approval role user to approve the order technically
                await cartListPage.loginFromOtherUser(multiUserBudgetObject.technicalApprovalUserID, multiUserBudgetObject.technicalApprovalUserPass);
                expect(catalogPage.getUserID(multiUserBudgetObject.technicalApprovalUser)).toBe(true); 

                orderFlowUtil.approveOrderTechnically(orderObject);
                // catalogPage.open();
                // //log out from the technically approval role user
                // cartListPage.clickUserIcon();
                // cartListPage.clickLogoutButton();


                //login from the financially approval role user
                await cartListPage.loginFromOtherUser(multiUserBudgetObject.financialApprovalUserID, multiUserBudgetObject.financialApprovalUserPass);
                expect(catalogPage.getUserID(multiUserBudgetObject.financialApprovalUser)).toBe(true); 
                ordersPage.open();
                ordersPage.searchOrderById(orderObject.orderNumber);
                
                ordersPage.selectBudgetaryUnit(budgetaryNameOne).then(async function (ttt) {
                util.waitForAngular();
                util.waitForAngular()
               await  orderFlowUtil.approveOrderFinancially(orderObject);
               await   orderFlowUtil.waitForOrderStatusChange(orderObject,multiUserBudgetObject.completedStatus);
                });
                // util.waitForAngular();
               
                // browser.ignoreSynchronization = false;
                // ordersPage.open();

                //Logout from the financial approval user roles
                // cartListPage.clickUserIcon();
                // cartListPage.clickLogoutButton();

                //Login from the buyer role user 
                await cartListPage.loginFromOtherUser(multiUserBudgetObject.buyerUserID, multiUserBudgetObject.buyerUserPassword);
                expect(catalogPage.getUserID(multiUserBudgetObject.buyerUserName)).toBe(true); 
                //Place the deleteorder from the buyer role
               // catalogPage.open();
                orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                // expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                //catalogPage.open();
                //Logout from the buyer role user
                // cartListPage.clickUserIcon();
                // cartListPage.clickLogoutButton();
                //Login from the technically approval role user
                await cartListPage.loginFromOtherUser(multiUserBudgetObject.technicalApprovalUserID, multiUserBudgetObject.technicalApprovalUserPass);
                expect(catalogPage.getUserID(multiUserBudgetObject.technicalApprovalUser)).toBe(true);
                orderFlowUtil.approveDeletedOrderTechnically(orderObject);
                //Logout from the technically approval role user
                // catalogPage.open();
                // cartListPage.clickUserIcon();
                // cartListPage.clickLogoutButton();
                //Login from the financially approval role user
                await cartListPage.loginFromOtherUser(multiUserBudgetObject.financialApprovalUserID, multiUserBudgetObject.financialApprovalUserPass);
                expect(catalogPage.getUserID(multiUserBudgetObject.financialApprovalUser)).toBe(true);


                // catalogPage.open();
                orderFlowUtil.approveDeletedOrderFinancially(orderObject);
                expect(ordersPage.getBudgetNameAllOrdersText()).toContain(budgetaryNameOne);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, multiUserBudgetObject.completedStatus)
        });
    }
   

    afterAll(async function () {
        budgetryPage.closeBudgetSliderIfPresent();
         //Logout from the financially approval role user
        //  cartListPage.clickUserIcon();
        //  cartListPage.clickLogoutButton();
         //Login with super user
        await cartListPage.loginFromOtherUser(superUserUsername, superUserPassword);
         expect(catalogPage.getUserID(multiUserBudgetObject.superUserName)).toBe(true);

        //Inactivate Budgetary Unit One
        budgetryPage.open();
    	budgetryPage.searchBudegtaryUnit(budgetaryNameOne);
        budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryNameOne);
        budgetryPage.clickOnBudgetryBudgetsLink();
        budgetryPage.selectCheckBoxBasedOnName(budgetaryNewBudgetNameOne);
        budgetryPage.clickonDeactivateBtnForSelectedItem();
        budgetryPage.clickOnDeactivateConfirmationBtn();
        budgetryPage.clickOnBudgetryDetailsLink();
        budgetryPage.clickOnEditBudgetaryButton();
        budgetryPage.clickBudgetStatustoglBtn();
        budgetryPage.clickOnBudgetrySaveBtn();
        budgetryPage.clickBudgetSliderCloseButton();
        budgetryPage.closeBudgetSliderIfPresent();	

        //deleted budgetary unit Two
        budgetryPage.open();
    	budgetryPage.searchBudegtaryUnit(budgetaryNameTwo);
        budgetryPage.clickOnEditIconAndViewDetailsForBudgetaryUnit(budgetaryNameTwo);
        budgetryPage.clickOnDeleteBtnFromBudgetaryDetailsPage();
        budgetryPage.clickOnDeleteConfirmationBtn(1);
        budgetryPage.closeBudgetSliderIfPresent();
    });


});