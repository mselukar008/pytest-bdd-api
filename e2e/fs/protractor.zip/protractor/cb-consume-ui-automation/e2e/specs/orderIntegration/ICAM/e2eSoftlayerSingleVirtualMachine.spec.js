
/*	
Spec_Name:e2eSoftlayerVirtualMachine.spec.js
Description: It covers e2e flow of provisioning of softlayer service.	
Author: Sarika Bothe
//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.

*/


"use strict";

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	Orders = require('../../../pageObjects/orders.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
	vmInSoftlayerTemplate = require('../../../../testData/OrderIntegration/ICAM/SoftlayerVirtualMachine.json');
	

describe('TA - E2E Virtual machine in Softlayer service', function () {

	var catalogPage, placeOrderPage, ordersPage, serviceName,inventoryPage, virtualMachineName, softlayerSshKeyName,softlayerSshKeyValue;
	var modifiedParamMap = {};
	var messageStrings = {
		providerName				     : vmInSoftlayerTemplate.providerName,
		category					   	 : vmInSoftlayerTemplate.category,
		estimatedPrice				   	 : vmInSoftlayerTemplate.estimatedPrice,
		providerAccount				   	 : vmInSoftlayerTemplate.providerAccount,
		completedState				   	 : vmInSoftlayerTemplate.completedState,
		approvalState				   	 : vmInSoftlayerTemplate.approvalState,
		orderTypeDel				   	 : vmInSoftlayerTemplate.orderTypeDel,
		urlOrders					   	 : vmInSoftlayerTemplate.urlOrders,
		estimatedCost				   	 : vmInSoftlayerTemplate.estimatedCost,
		orderSubmittedConfirmationMessage: vmInSoftlayerTemplate.orderSubmittedConfirmationMessage,
		SoftlayerSshKeyPrefix			 :vmInSoftlayerTemplate.SoftlayerSshKeyPrefix,
		SoftlayerSshKeySuffix			 :vmInSoftlayerTemplate.SoftlayerSshKeySuffix

	};
	
	beforeAll(function () {
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		serviceName = vmInSoftlayerTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
		softlayerSshKeyValue =vmInSoftlayerTemplate.SoftlayerSshKeyPrefix+" "+util.getRandomString(8)+""+vmInSoftlayerTemplate.SoftlayerSshKeySuffix;
		modifiedParamMap = { "Service Instance Name": serviceName,"Public SSH Key": softlayerSshKeyValue}
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		virtualMachineName = vmInSoftlayerTemplate.virtualMachineNamePrefix + "-" + util.getRandomString(5);
		softlayerSshKeyName = vmInSoftlayerTemplate.softlayerSshKeyNamePrefix + "-" + util.getRandomString(5);
		
	});

	it('TA - Virtual machine in Softlayer ---- Verify fields on Main Parameters page', function () {

		catalogPage.searchForBluePrint(vmInSoftlayerTemplate.bluePrintName);
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);	
		catalogPage.clickConfigureButtonBasedOnName(vmInSoftlayerTemplate.bluePrintName);
		expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
        placeOrderPage.setServiceNameTextICAM(vmInSoftlayerTemplate.serviceNamePrefix + "-" + util.getRandomString(4));
		placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
		expect(placeOrderPage.isNextButtonEnabled()).toBe(true); 

	});

	it('TA - Virtual machine in Softlayer ---- Verify Summary details and Additional Details are listed in review Order page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.clickConfigureButtonBasedOnName(vmInSoftlayerTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetailsICAM(vmInSoftlayerTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
			//expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPrice);
			expect(requiredReturnMap["Actual"]["Instance Plan"]).toEqual(requiredReturnMap["Expected"]["Instance Plan"]);
		
		});
	});

	it('TA - Virtual machine in Softlayer ---- Verify Order is listed in Orders details page once it is submitted from catalog page', function () {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.clickConfigureButtonBasedOnName(vmInSoftlayerTemplate.bluePrintName);
		orderFlowUtil.fillOrderDetailsICAM(vmInSoftlayerTemplate, modifiedParamMap).then(function (requiredReturnMap) {
			placeOrderPage.submitOrder();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			var orderId = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

			ordersPage.open();
			expect(util.getCurrentURL()).toMatch(messageStrings.urlOrders);
			ordersPage.searchOrderById(orderId);
			expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderId);
			ordersPage.clickFirstViewDetailsOrdersTable();
			expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
			expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual(messageStrings.approvalState);
		//	expect(ordersPage.getTextSubmittedByOrderDetails()).toContain(catalogPage.extractUserFirstName());
			expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
			expect(ordersPage.isDisplayedDenyButtonOrderDetails()).toEqual(true);
			ordersPage.clickServiceConfigurationsTabOrderDetails();
			expect(ordersPage.getTextBasedOnLabelName("Instance Plan")).toEqual((requiredReturnMap["Expected"]["Instance Plan"]));

            ordersPage.clickBillOfMaterialsTabOrderDetails();
		//	expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);

			

		});
	});

	if (isProvisioningRequired == "true") {
		it('TA - Virtual machine in Softlayer --- Verify Provision and Delete services', function () {
			var orderObject = {} 
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.clickConfigureButtonBasedOnName(vmInSoftlayerTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetailsICAM(vmInSoftlayerTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
		//	orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObject);
			orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
			orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {

			});
		});
		
		it('TA - softlayer Machine 2 - Verify for Start Virtual machine, Taint operation is successful or not', function () {


            catalogPage.open();
            var orderObject = {};
			orderObject.serviceName = serviceName;
            var returnObj = {
                servicename: serviceName
            };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
                    inventoryPage.clickTaintONButtonOfInstanceIcam()
                        inventoryPage.clickOkForInstanceTurnOFFPermission();

                        util.waitForAngular();
                  
                });
            }).then(function () {
				var orderObject = JSON.parse(JSON.stringify(vmInSoftlayerTemplate));
				
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                
            });
		});


		it('TA - softlayer Machine 3 - Verify for Start Virtual machine, UnTaint operation is successful or not', function () {


            catalogPage.open();
            var orderObject = {};
			orderObject.serviceName = serviceName;
            var returnObj = {
                servicename: serviceName
            };
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                inventoryPage.clickOverflowActionButtonForPowerStatesoperationIcam().then(function () {
                    inventoryPage.clickUntaintONButtonOfInstanceIcam()
                        inventoryPage.clickOkForInstanceTurnOFFPermission();

                        util.waitForAngular();
                  
                });
            }).then(function () {
                var orderObject = JSON.parse(JSON.stringify(vmInSoftlayerTemplate));

                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                returnObj.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
                orderFlowUtil.approveOrder(orderObject);
                orderFlowUtil.waitForOrderStatusChange(returnObj, messageStrings.completedState);
                expect(orderFlowUtil.verifyOrderStatus(returnObj)).toBe(messageStrings.completedState);
                inventoryPage.open();
                inventoryPage.searchOrderByServiceName(returnObj.servicename);
                
            });
		});

		it('TA - Vsphere Virtual Machine 4 -- Verify delete services', function () {

            var orderObject = {} ;
            orderObject.serviceName = serviceName;

            var returnObj = { servicename:serviceName};
            orderObject.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
            expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState)
        });


	}
});