/*************************************************
DESCRIPTION: The test script verifies the Key Management Service Service functionality    
**************************************************/

"use strict";
var async = require('async'),
    HomePage = require('../../../pageObjects/home.pageObject.js'),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    isProvisioningRequired = browser.params.isProvisioningRequired,
    KMSTemplate = require('../../../../testData/OrderIntegration/Alibaba/KeyManagementService.json')

describe('Alibaba: Test cases for Key Management Service', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, homePage;
    var modifiedParamMap = {};
    var messageStrings = {
        providerName: 'Alibaba Cloud',
        category: 'Other Services'
    };
    var servicename = "Gsl-Auto-KMS" + util.getRandomString(5);

    beforeAll(function () {
        homePage = new HomePage();
        catalogPage = new CatalogPage();
        catalogDetailsPage = new CatalogDetailsPage();
        placeOrderPage = new PlaceOrderPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        browser.driver.manage().window().maximize();
    });

    beforeEach(function () {
        modifiedParamMap = {
            "Service Instance Name": servicename,
        };
        catalogPage.open();
        expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
    });

    afterAll(function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        returnObj.deleteOrderNumber = orderFlowUtil.deleteService(returnObj);
        orderFlowUtil.approveDeletedOrder(returnObj);
        orderFlowUtil.waitForDeleteOrderStatusChange(returnObj, 'Completed');
        expect(orderFlowUtil.verifyOrderStatusDeletedOrder(returnObj)).toBe('Completed');
    });

    it('Aalibaba: TC-1 verify that for Key Management Service all parameters on Main Parameters Page are present.', function () {
        var orderObject = JSON.parse(JSON.stringify(KMSTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickDetailsButtonBasedOnName(orderObject.bluePrintName);

        expect(catalogDetailsPage.getServiceName()).toBe(orderObject.bluePrintName)
        expect(catalogDetailsPage.isDisplayedConfigureButtonOnDetails()).toBe(true);
        expect(catalogDetailsPage.isPresentLinkToProviderSite()).toBe(true);
        expect(catalogDetailsPage.isPresentFeaturesLabel()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsLabel()).toBe(true);
        expect(catalogDetailsPage.getTextFeaturesLabel()).toBe(orderObject.FeaturesLabel);
        expect(catalogDetailsPage.getTextDetailsLabel()).toBe(orderObject.DetailsLabel);
        expect(catalogDetailsPage.isPresentFeaturesInfo()).toBe(true);
        expect(catalogDetailsPage.isPresentDetailsInfo()).toBe(true);
        homePage.open();
    });

    it('Aalibaba: TC-2 verify that for Key Management Service all parameters on Review Order page matches with input.', function () {
        var orderObject = JSON.parse(JSON.stringify(KMSTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderObject.servicename = servicename;
        orderFlowUtil.fillOrderDetails(KMSTemplate, modifiedParamMap);

        //Checking Service Details in ReviewOrder
        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(orderObject.servicename);
        
        //Checking Additional Details in ReviewOrder
        expect(placeOrderPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Key Spec:")).toEqual(jsonUtil.getValue(orderObject, "Key Spec"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Purpose:")).toEqual(jsonUtil.getValue(orderObject, "Purpose"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Alias Name:")).toEqual(jsonUtil.getValue(orderObject, "Alias Name"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Protection Level:")).toEqual(jsonUtil.getValue(orderObject, "Protection Level"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Description:")).toEqual(jsonUtil.getValue(orderObject, "Description"));
        expect(placeOrderPage.getTextBasedOnLabelName(" Automatic Rotation:")).toEqual(jsonUtil.getValue(orderObject, "Automatic Rotation"));
        homePage.open();
    });

    it('Aalibaba: TC-3 verify that for Key Management Service all values on View Order Details page matches with input.', function () {
        var returnObj = {};
        returnObj.servicename = servicename;
        var orderObject = JSON.parse(JSON.stringify(KMSTemplate));
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
        catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
        orderFlowUtil.fillOrderDetails(KMSTemplate, modifiedParamMap);
        placeOrderPage.submitOrder();
        returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
        expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
        placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        ordersPage.open();
        ordersPage.searchOrderById(returnObj.orderNumber);
        ordersPage.clickFirstViewDetailsOrdersTable();

        //Checking Order Details in View order details
        expect(ordersPage.getTextOrderServiceNameOrderDetails()).toBe(returnObj.servicename); //Checking Service Name
        expect(ordersPage.getTextOrderProviderNameOrderDetails()).toBe(orderObject.provider); //Checking Provider

        //Checking Service Configuration Parameters
        ordersPage.clickServiceConfigurationsTabOrderDetails();
        expect(ordersPage.getTextBasedOnExactLabelName("Region")).toEqual(jsonUtil.getValue(orderObject, "Region"));
        expect(ordersPage.getTextBasedOnExactLabelName("Key Spec")).toEqual(jsonUtil.getValue(orderObject, "Key Spec"));
        expect(ordersPage.getTextBasedOnExactLabelName("Purpose")).toEqual(jsonUtil.getValue(orderObject, "Purpose"));
        expect(ordersPage.getTextBasedOnExactLabelName("Alias Name")).toEqual(jsonUtil.getValue(orderObject, "Alias Name"));
        expect(ordersPage.getTextBasedOnExactLabelName("Protection Level")).toEqual(jsonUtil.getValue(orderObject, "Protection Level"));
        expect(ordersPage.getTextBasedOnExactLabelName("Description")).toEqual(jsonUtil.getValue(orderObject, "Description"));
        expect(ordersPage.getTextBasedOnExactLabelName("Automatic Rotation")).toEqual(jsonUtil.getValue(orderObject, "Automatic Rotation"));

        //Checking Bill Of Material
        ordersPage.clickBillOfMaterialsTabOrderDetails();
        expect(placeOrderPage.getTotalCost()).toBe(orderObject.Totalcost);

        //Deny Order
        ordersPage.clickServiceDetailSliderCloseButton();
        orderFlowUtil.denyOrder(returnObj);
    });

    if (isProvisioningRequired == "true") {
        it('Aalibaba: TC -4 Verify that for Key Management Service provision with correct paramaters', function () {
            var orderObject = JSON.parse(JSON.stringify(KMSTemplate));
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(orderObject.Category);
            catalogPage.clickConfigureButtonBasedOnName(orderObject.bluePrintName);
            var returnObj = {};
            orderFlowUtil.fillOrderDetails(KMSTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            returnObj.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            returnObj.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            returnObj.servicename = servicename;
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(orderObject.SubmitOrder);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(returnObj);
            orderFlowUtil.waitForOrderStatusChange(returnObj, orderObject.OrderStatus);

            //checking order on Inventory Page 
            inventoryPage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
            inventoryPage.searchOrderByServiceName(returnObj.servicename);
            inventoryPage.clickOnInstanceTableActionIcon();
            inventoryPage.clickViewService();

            //Checking Inventory Page Service Configuration
            expect(inventoryPage.getTextInventorySOIName()).toEqual(inventoryPage.getTextServiceInstanceName("Service Instance Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Region:")).toEqual(jsonUtil.getValue(orderObject, "Region"));
            expect(inventoryPage.getTextBasedOnLabelName(" Key Spec:")).toEqual(jsonUtil.getValue(orderObject, "Key Spec"));
            expect(inventoryPage.getTextBasedOnLabelName(" Purpose:")).toEqual(jsonUtil.getValue(orderObject, "Purpose"));
            expect(inventoryPage.getTextBasedOnLabelName(" Alias Name:")).toEqual(jsonUtil.getValue(orderObject, "Alias Name"));
            expect(inventoryPage.getTextBasedOnLabelName(" Protection Level:")).toEqual(jsonUtil.getValue(orderObject, "Protection Level"));
            expect(inventoryPage.getTextBasedOnLabelName(" Description:")).toEqual(jsonUtil.getValue(orderObject, "Description"));
            expect(inventoryPage.getTextBasedOnLabelName(" Automatic Rotation:")).toEqual(jsonUtil.getValue(orderObject, "Automatic Rotation"));
            inventoryPage.closeViewDetailsTab();
        });
    }
});