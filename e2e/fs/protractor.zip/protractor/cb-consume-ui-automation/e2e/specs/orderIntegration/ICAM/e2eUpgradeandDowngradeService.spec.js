/*	
Spec_Name:e2eUpgradeandDowngradeService.spec.js
Description: It covers Upgrade and downgrade scenario.	
Author: Swaroop Kotme
//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.

*/

"use strict";

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	Orders = require('../../../pageObjects/orders.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	jsonUtil = require('../../../../helpers/jsonUtil.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
	InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
	vmInUpgradeDowngradeTemplate = require('../../../../testData/OrderIntegration/ICAM/UpgradeDowngradeService.json');

describe('TA - E2E Upgrade and downgrade service', function () {

	var catalogPage, catalogDetailsPage, inventoryPage, placeOrderPage, ordersPage, orderHistoryPage, SubnetName, vpc, serviceName, virtualMachineName, awsSshKeyName, UpgradeOrder, VsphereAwsEditsoiObject;
	var modifiedParamMap = {};
	var orderObjectpreorder = {};
	var orderObjectupgradeorder = {};
	serviceName = vmInUpgradeDowngradeTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
	var messageStrings = {
		providerName: vmInUpgradeDowngradeTemplate.providerName,
		category: vmInUpgradeDowngradeTemplate.category,
		providerAccount: vmInUpgradeDowngradeTemplate.providerAccount,
		completedState: vmInUpgradeDowngradeTemplate.completedState,
		approvalState: vmInUpgradeDowngradeTemplate.approvalState,
		orderTypeDel: vmInUpgradeDowngradeTemplate.orderTypeDel,
		urlOrders: vmInUpgradeDowngradeTemplate.urlOrders,
		provisiongstatus: vmInUpgradeDowngradeTemplate.provisiongstatus,
		orderSubmittedConfirmationMessage: vmInUpgradeDowngradeTemplate.orderSubmittedConfirmationMessage,
		orderFailedStatus: vmInUpgradeDowngradeTemplate.failedState,
		SameVersionValidationMsg: vmInUpgradeDowngradeTemplate.SameVersionValidationMsg,
		PopUpMsgone : vmInUpgradeDowngradeTemplate.PopUpMsgone,
		PopUpMsgtwo : vmInUpgradeDowngradeTemplate.PopUpMsgtwo,
		cancelledStatus : vmInUpgradeDowngradeTemplate.cancelledStatus
	};

	beforeAll(function () {
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		orderHistoryPage = new OrderHistoryPage();
		catalogDetailsPage = new CatalogDetailsPage();
		inventoryPage = new InventoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		SubnetName = vmInUpgradeDowngradeTemplate.subnetnamePrefix + "-" + util.getRandomString(5);
		vpc = vmInUpgradeDowngradeTemplate.vpcPrefix + "-" + util.getRandomString(5);
		virtualMachineName = vmInUpgradeDowngradeTemplate.virtualMachineNamePrefix + "-" + util.getRandomString(5);
		awsSshKeyName = vmInUpgradeDowngradeTemplate.awsSshKeyNamePrefix + "-" + util.getRandomString(5);
		modifiedParamMap = { "Service Instance Name": serviceName, "Public SSH Key Name": awsSshKeyName, "Virtual Machine name": virtualMachineName }
	});

	if (isProvisioningRequired == "true") {
		it('TA - Upgrading sevice from V1 to V2 --- Verify Provision', function () {
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.clickConfigureButtonBasedOnName(vmInUpgradeDowngradeTemplate.bluePrintName);
			orderObjectpreorder.servicename = serviceName;
			orderFlowUtil.fillOrderDetailsICAM(vmInUpgradeDowngradeTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObjectpreorder.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObjectpreorder);
			orderFlowUtil.waitForOrderStatusChange(orderObjectpreorder, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObjectpreorder)).toBe(messageStrings.completedState);
			orderFlowUtil.verifyOrderStatus(orderObjectpreorder).then(function (status) {
				if (status == 'Completed') {
					orderObjectupgradeorder = { servicename: serviceName };
					//Upgrade flow
					var modifiedParamMapupgrade = { "EditService": true, "Public SSH Key Name": awsSshKeyName };
					orderFlowUtil.UpgradeServiceforICAM(orderObjectpreorder);
					browser.sleep(9000);
					catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
					inventoryPage.clickEditServiceNextButton();
					orderFlowUtil.fillOrderDetails(vmInUpgradeDowngradeTemplate, modifiedParamMapupgrade).then(function () {
						browser.sleep(5000);
					});
					placeOrderPage.submitOrder();
					orderObjectupgradeorder.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
					placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
					orderFlowUtil.approveOrder(orderObjectupgradeorder);
					orderFlowUtil.waitForOrderStatusChange(orderObjectupgradeorder, messageStrings.completedState);
					expect(orderFlowUtil.verifyOrderStatus(orderObjectupgradeorder)).toBe(messageStrings.completedState);
					orderFlowUtil.verifyOrderStatus(orderObjectupgradeorder).then(function (status) {
						if (status == 'Completed') {
							//Verify updated details are reflected on order details page or not.						
							ordersPage.clickFirstViewDetailsOrdersTable();
							expect(ordersPage.getTextBasedOnLabelName("Azureconnection")).toEqual(jsonUtil.getValueEditParameter(vmInUpgradeDowngradeTemplate, "Azureconnection"));
							expect(ordersPage.getTextBasedOnLabelName("Admin User Password")).toEqual(jsonUtil.getValueEditParameter(vmInUpgradeDowngradeTemplate, "Admin User Password"));
							expect(ordersPage.getTextBasedOnLabelName("MCMP Version")).toEqual("2.0.0.0");
							ordersPage.clickServiceDetailSliderCloseButton();
						}
					});
				}
			});

		});

		it ('TA - Validate change version is not allowed when any d2 operation is in progress',function(){
			orderObjectpreorder.servicename = serviceName;
			orderObjectpreorder.componentType = vmInUpgradeDowngradeTemplate.componentType
			inventoryPage.open();
			browser.waitForAngular();
			inventoryPage.searchOrderByServiceName(orderObjectpreorder.servicename);
			inventoryPage.clickExpandFirstRow().then(function () {
				inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObjectpreorder.componentType).then(function () {
					inventoryPage.icamClickTaintButtonOfIcamUpgrade_DowngradeInstance();
					inventoryPage.placeD2opsOrder();
					inventoryPage.clickOkForInstanceTurnOFFPermission();
					util.waitForAngular();
				})
			}).then(function () {
				var taintorderObject = JSON.parse(JSON.stringify(vmInUpgradeDowngradeTemplate));

				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
				taintorderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObjectpreorder.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
				inventoryPage.clickOkForCustomOpnOrderButton();

				inventoryPage.clickOnInstanceTableActionIcon();
				inventoryPage.clickAvailableVersionIcon();
				util.waitForAngular();
				taintorderObject.orderNumber.then(function (orderNumberValue) {
					var warningMsgString = messageStrings.PopUpMsgone + " " + orderNumberValue + "." // + messageStrings.PopUpMsgtwo;
				util.waitForAngular();
				expect(inventoryPage.getTextOfToastMessageIcam()).toContain(warningMsgString);
				}).then(function () {
					orderHistoryPage.searchOrderClickCancelOrder(taintorderObject.orderNumber)
					orderHistoryPage.clickOnOrderTableActionsCancelYesButton();
					orderHistoryPage.getTextCancelOrderSuccessFulMsg();
					orderHistoryPage.clickCancelOrderOkButton();
					inventoryPage.open(); //random click
					orderFlowUtil.waitForOrderStatusChangeInOrderHistory(taintorderObject, messageStrings.cancelledStatus)
					expect(orderFlowUtil.verifyOrderStatus(taintorderObject)).toBe("Canceled");
				});
			});
		});
		
		it('TA - Check validation for Upgrading sevice to a same version ', function () {
			orderFlowUtil.waitForOrderStatusChange(orderObjectupgradeorder, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObjectupgradeorder)).toBe(messageStrings.completedState);
			orderFlowUtil.verifyOrderStatus(orderObjectupgradeorder).then(function (status) {
				if (status == 'Completed') {
					//Validation message for upgrade/downgrade to same version..
					inventoryPage.open();
					inventoryPage.searchOrderByServiceName(orderObjectupgradeorder.servicename);
					util.waitForAngular();
					inventoryPage.clickOnInstanceTableActionIcon();
					inventoryPage.clickAvailableVersionIcon();
					util.waitForAngular();
					catalogDetailsPage.isDisplayedConfigureButtonOnDetails();
					catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
					util.waitForAngular();
					expect(catalogDetailsPage.getTextSameVersionValidationMsg()).toEqual(messageStrings.SameVersionValidationMsg);
				}
			});

		});

		it('TA - Upgrading sevice from V2 to V1 --- Verify Provision and then delete a service', function () {
			orderFlowUtil.waitForOrderStatusChange(orderObjectupgradeorder, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObjectupgradeorder)).toBe(messageStrings.completedState);
			orderFlowUtil.verifyOrderStatus(orderObjectupgradeorder).then(function (status) {
				if (status == 'Completed') {
					var orderObjectdowngradeorder = {}
					//Downgrade flow
					orderFlowUtil.DowngradeServiceforICAM(orderObjectpreorder);
					browser.sleep(9000);
					catalogDetailsPage.isDisplayedConfigureButtonOnDetails();
					catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
					inventoryPage.clickEditServiceNextButton();
					inventoryPage.clickEditServiceNextAdditionalParamsButton();
					util.waitForAngular();
					inventoryPage.clickEditServiceNextAdditionalParamsButton();
					placeOrderPage.submitOrder();
					orderObjectdowngradeorder.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
					placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
					orderFlowUtil.approveOrder(orderObjectdowngradeorder);
					orderFlowUtil.waitForOrderStatusChange(orderObjectdowngradeorder, messageStrings.completedState);
					expect(orderFlowUtil.verifyOrderStatus(orderObjectdowngradeorder)).toBe(messageStrings.completedState);
					orderFlowUtil.verifyOrderStatus(orderObjectdowngradeorder).then(function (status) {
						if (status == 'Completed') {
							//Verify updated details are reflected on order details page.						
							ordersPage.clickFirstViewDetailsOrdersTable();
							expect(ordersPage.getTextBasedOnLabelName("Awsconnection")).toEqual(jsonUtil.getValue(vmInUpgradeDowngradeTemplate, "Awsconnection"))
							expect(ordersPage.getTextBasedOnLabelName("Virtual Private Cloud")).toEqual(jsonUtil.getValue(vmInUpgradeDowngradeTemplate, "Virtual Private Cloud"));
							expect(ordersPage.getTextBasedOnLabelName("Subnet Name")).toEqual(jsonUtil.getValue(vmInUpgradeDowngradeTemplate, "Subnet Name"));
							expect(ordersPage.getTextBasedOnLabelName("AWS Region Name")).toEqual(jsonUtil.getValue(vmInUpgradeDowngradeTemplate, "AWS Region Name"));
							expect(ordersPage.getTextBasedOnLabelName("MCMP Version")).toEqual("1.0.0.0");
							ordersPage.clickServiceDetailSliderCloseButton();
						}
						// Delete Service flow                    
						orderObjectpreorder.deleteOrderNumber = orderFlowUtil.deleteService(orderObjectpreorder);
						orderFlowUtil.approveDeletedOrder(orderObjectpreorder);
						orderFlowUtil.waitForDeleteOrderStatusChange(orderObjectpreorder, 'Completed');
						expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObjectpreorder)).toBe('Completed');
					});
				}
			});
		});
	}
});