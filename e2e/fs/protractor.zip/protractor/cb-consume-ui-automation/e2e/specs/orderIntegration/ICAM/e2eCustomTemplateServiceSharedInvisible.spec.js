/*
	
Spec_Name: e2eCustomTemplateServiceSharedInvisible.spec.js
	
Description: It covers order provision  and deprovision flow for Custom template service with shared and invisible param service.  
	
Author: Swaroop Kotme
	
*/

//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.
"use strict";

const { browser } = require('protractor');

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	Orders = require('../../../pageObjects/orders.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	OrderHistoryPage = require('../../../pageObjects/ordersHistory.pageObject.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	SharedInvisibleTemplate = require('../../../../testData/OrderIntegration/ICAM/CustomTemplateServiceSharedandInvisible.json'),
	CatalogDiscoveryPage   = require('../../../pageObjects/catalogDiscovery.pageObject.js');
	

describe('TA - E2E Custom template service with shared and invisible param service', function () {

	var catalogPage, placeOrderPage, ordersPage,orderHistoryPage, serviceName,inventoryPage,catalogDiscoveryObj,regexparam;
    var modifiedParamMap = {};
    var modifiedParamMap2 = {};
    var orderObject = {};
    serviceName = SharedInvisibleTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
    var regexparamPrefix2 = regexparamPrefix2;
	var messageStrings = {
		providerName				     : SharedInvisibleTemplate.providerName,
		category					   	 : SharedInvisibleTemplate.category,
		estimatedPrice				   	 : SharedInvisibleTemplate.estimatedPrice,
		providerAccount				   	 : SharedInvisibleTemplate.providerAccount,
		completedState				   	 : SharedInvisibleTemplate.completedState,
		approvalState				   	 : SharedInvisibleTemplate.approvalState,
		orderTypeDel				   	 : SharedInvisibleTemplate.orderTypeDel,
		urlOrders					   	 : SharedInvisibleTemplate.urlOrders,
		estimatedCost				   	 : SharedInvisibleTemplate.estimatedCost,
		cancelOrderSuccessMsg            : SharedInvisibleTemplate.cancelOrderSuccessMsg,
		cancelledStatus                  : SharedInvisibleTemplate.cancelledStatus,
		provisiongstatus                 : SharedInvisibleTemplate.provisiongstatus,
		Cancelingstatus			         : SharedInvisibleTemplate.Cancelingstatus,
		orderSubmittedConfirmationMessage: SharedInvisibleTemplate.orderSubmittedConfirmationMessage,
		orderFailedStatus                : SharedInvisibleTemplate.failedState,
		deletedStatus                    : SharedInvisibleTemplate.deletedStatus,
		failedLogsText                   : SharedInvisibleTemplate.failedLogsText,
		SuccessLogMsg                    : SharedInvisibleTemplate.SuccessLogMsg,
		RegxErrorMsg                     : SharedInvisibleTemplate.RegxErrorMsg,
        SuccessLogMsg                    : SharedInvisibleTemplate.SuccessLogMsg,
        regexparamPrefix2                : SharedInvisibleTemplate.regexparamPrefix2

	};
	
	beforeAll(function () {
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		orderHistoryPage = new OrderHistoryPage();
		inventoryPage = new InventoryPage();
		catalogDiscoveryObj = new CatalogDiscoveryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		regexparam = SharedInvisibleTemplate.regexparamPrefix + util.getRandomString(5);
        modifiedParamMap = { "Service Instance Name": serviceName, "Regex param": regexparam };
        modifiedParamMap2 = { "dynamicValidation": true, "Service Instance Name": serviceName, "Regex param": regexparamPrefix2 };
	});

    if (isProvisioningRequired == "true") {
        it('TA - TC-1 Custom template service with shared and invisible param service --- Verify Provision services', function () {
            catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
            catalogPage.clickConfigureButtonBasedOnName(SharedInvisibleTemplate.bluePrintName);
            orderObject.servicename = serviceName;
            orderFlowUtil.fillOrderDetailsICAM(SharedInvisibleTemplate, modifiedParamMap);
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            //orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);

        });

        it('TA  : TC-2 Custom template service with shared and invisible param service ---- Verify Delete services', function () {
            orderObject.servicename = serviceName;
            orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
            expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(messageStrings.orderTypeDel);
            orderFlowUtil.approveDeletedOrder(orderObject);
            orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, messageStrings.completedState);
            expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(messageStrings.completedState)
        });

}

    it('TA : TC-3 Custom template service with shared and invisible param serviceS ---- Verify that for Regex Custom template dynamic validation is working or not', function () {
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(SharedInvisibleTemplate.bluePrintName);
        placeOrderPage.setServiceNameTextICAM("TA-automation-Regex-" + util.getRandomString(4));
        placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
        placeOrderPage.clickNextButton();
        orderFlowUtil.fillOrderDetails(SharedInvisibleTemplate, modifiedParamMap2);
        placeOrderPage.setCustomTemplateRegexValueText(messageStrings.regexparamPrefix2);
        expect(placeOrderPage.getTextregexparamcustomtemplate()).toContain(messageStrings.RegxErrorMsg);
    });

    it('TA : TC-4 Custom template service with shared and invisible param serviceS ---- Verify that Invisible param should not be present/visible in additional param page', function () {
        catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
        catalogPage.clickConfigureButtonBasedOnName(SharedInvisibleTemplate.bluePrintName);
        placeOrderPage.setServiceNameTextICAM("TA-automation-invisibleparam-" + util.getRandomString(4));
        placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
        placeOrderPage.clickNextButton();
        orderFlowUtil.fillOrderDetails(SharedInvisibleTemplate, modifiedParamMap2);
        expect(placeOrderPage.checkIfsharedparam()).toBe(false);
        expect(placeOrderPage.checkIfSampleHiddenparam()).toBe(false);
        expect(placeOrderPage.checkIfUserPasswordparam()).toBe(false);

    });

});
