"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	slSecurityGrpTemplate = require('../../../../../../testData/OrderIntegration/Softlayer/SecurityGroupService.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	vmInstanceTemplate = require('../../../../../../testData/OrderIntegration/Softlayer/VirtualMachine.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('IBM Cloud E2E cases for Auto Technical, Financial and Legal approval with Normal change', function() {
	var ordersPage, catalogPage, placeOrderPage, snowPage, sampleOrder1, inventoryPage, policyPage, cartListPage;
	var modifiedParamMap = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var serviceName = "SNOWauto"+util.getRandomString(5);
	var policyName = "SNOWautoSLPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWautoSLPolicyRule"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';
	var secGrpName = "SNOWsecGrp"+util.getRandomString(5);
	var secGrpNameEdit = "SNOWsecGrpEdit"+util.getRandomString(5);
	var orderObjectVm = {};
	
	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
		
		//Delete policy if exists
		policyPage.open();
		util.waitForAngular();
		policyPage.deletePoliciesIfExist();
	});

	beforeEach(function() {
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["IBM Cloud"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":""};
		modifiedParamMap = {"Service Instance Name":serviceName,"Team":"Auto-TEAM1", "Environment":"QA", "Application":"","Provider Account":"SL-Testing / SL-Testing","Security Group Name":secGrpName};
	});
	
	afterAll(function() {

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
		policyPage.open();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickPolicyViewDetailButton();
		policyPage.clickRadioButtonRetiredOption();
		policyPage.clickUpdatePolicyBtn();
		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
		var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
		expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
		policyPage.searchPolicyInPolicyTextbox(policyName);
		policyPage.clickPolicyDetailIcon();
		policyPage.clickButtonDeletePolicyText();
		policyPage.clickDeleteConfirmationPopUpPolicyBtn();
		util.waitForAngular();
		policyPage.searchPolicyInPolicyTextbox(policyName);
		expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});
	
	it('Set Change Request type to Normal in SNOW', function () {
		expect(snowAPI.setChangeRequestToNormal()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Approval Policy for IBM Cloud with Auto Technical, Financial, Legal approval and Normal change', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('IBM Cloud: Security Group ---- Verify Provision functionality with Auto Technical, Financial, Legal approval and Normal change', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(slSecurityGrpTemplate.providerName);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(slSecurityGrpTemplate.Category);
			catalogPage.clickConfigureButtonBasedOnName(slSecurityGrpTemplate.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":sampleOrder1};	
			
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApproved();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpName);

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickUpdateButton();
			
			//Approvals in SNOW
			snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.openRelatedChangeRequest();
			snowPage.approveChangeRequestForEachState();
			snowPage.approveChangeRequestForEachState();
			
			//Order Completion in SNOW
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.completedOrderStatus);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();			
			});	
		});
	
		it('IBM Cloud: Security Group ---- Verify Edit functionality with Auto Technical, Financial, Legal approval and Normal change', function () {
			
			//Place Order for Edit in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			modifiedParamMap = {"Service Instance Name":"","Team":"","Environment":"","Application":"","Provider Account":"","Security Group Name":secGrpNameEdit};
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.editService(orderObject);
			orderFlowUtil.fillOrderDetails(slSecurityGrpTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(slSecurityGrpTemplate.orderSubmittedText);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApproved();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestEdit);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Security Group Name")).toEqual(secGrpNameEdit);

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickUpdateButton();
			
			//Approvals in SNOW
			snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.openRelatedChangeRequest();
			snowPage.approveChangeRequestForEachState();
			snowPage.approveChangeRequestForEachState();
			
			//Order Completion in SNOW
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(slSecurityGrpTemplate.completedOrderStatus);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();			
			});			
		});
	
		it('IBM Cloud: Security Group ---- Verify Delete functionality with Auto Technical, Financial, Legal approval and Normal change', function () {
			
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			sampleOrder1 = inventoryPage.getDeleteOrderNumber();
			
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApproved();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
			expect(snowPage.getTextShortDescription()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(slSecurityGrpTemplate.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescSL);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategorySec);
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItemValueSecGrp)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickUpdateButton();
			
			//Approvals in SNOW
			snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
			snowPage.openRelatedChangeRequest();
			snowPage.approveChangeRequestForEachState();
			snowPage.approveChangeRequestForEachState();
			
			//Order Completion in SNOW
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
			snowPage.openRelatedChangeRequest();
			snowPage.checkIfProvisioningTaskClosed();
			snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
			snowPage.openRelatedChangeRequest();
			snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
			//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(slSecurityGrpTemplate.completedOrderStatus);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.openConfItemServiceInstanceCIs();
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			snowPage.clickUpdateButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			});		
		});

		if(isDummyAdapterDisabled == "false"){
			it('IBM CLoud: Virtual Server - VM instance creation as part of pre-requisite data.', function () {
				serviceName = "GSLSLTestAutomation" + util.getRandomString(5);
				var modifiedHostName = "GSLSLVM" + util.getRandomString(5);
				modifiedParamMap = {
					"Service Instance Name": serviceName,
					"Hostname": modifiedHostName,
					"Team": "Auto-TEAM1", 
					"Environment": "QA",
					"Application": "",
					"Provider Account": "SL-Testing / SL-Testing"
				};
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				catalogPage.open();
				catalogPage.clickProviderCheckBoxBasedOnName(vmInstanceTemplate.provider);
				catalogPage.clickFirstCategoryCheckBoxBasedOnName(vmInstanceTemplate.Category);
				catalogPage.searchForBluePrint(vmInstanceTemplate.bluePrintName);
				catalogPage.clickConfigureButtonBasedOnName(vmInstanceTemplate.bluePrintName);
				orderObjectVm.servicename = serviceName;
				orderFlowUtil.fillOrderDetails(vmInstanceTemplate, modifiedParamMap);
				placeOrderPage.submitOrder();
				orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
				orderObjectVm.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
				expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vmInstanceTemplate.orderSubmittedConfirmationMessage);
				placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
				//Validation in Marketplace after auto approval
				expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe("Provisioning in Progress");
				//Validations on SNOW Request page after auto approval
				snowPage.logInToSnowDevPortalAndSearchOrder(orderObjectVm.orderNumber);
				snowPage.waitUntilApprovalIsApproved();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
				expect(snowPage.getTextShortDescription()).toBe(vmInstanceTemplate.bluePrintName);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);
				expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
				expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
	
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vmInstanceTemplate.bluePrintName);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescIbm);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
				expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function (sName) {
					expect(sName).toContain(serviceName);							
					
					// Validate BOM values from Broker config values
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem1ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem2ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem3ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem4ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem5ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem6ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem7ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem8ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem9ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem10ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem11ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
					expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem12ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem1ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalIbmVirSer1);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem2ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalIbmVirSer2);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem3ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem4ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem5ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem6ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem7ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem8ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalIbmVirSer8);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem9ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem10ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem11ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
					expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem12ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
	
					//Validations on SNOW Configuration Item- Service Instance CIs page
					snowPage.switchToDefaultContent();
					snowPage.switchToParentFrame();
					snowPage.openConfItemServiceInstanceCIs();
					expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
					expect(snowPage.getTextSerInstanceCIsObjectId()).toBe("");
					expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
					snowPage.clickUpdateButton();
	
					//Validation on Catalog Task page
					snowPage.clickCatalogTaskLink();
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
					snowPage.clickUpdateButton();
	
					//Approvals in SNOW
					snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
					snowPage.openRelatedChangeRequest();
					snowPage.approveChangeRequestForEachState();
					snowPage.approveChangeRequestForEachState();
	
					//Order Completion in SNOW
					snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
					snowPage.openRelatedChangeRequest();
					snowPage.checkIfProvisioningTaskClosed();
					snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
					snowPage.openRelatedChangeRequest();
					snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
					//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
	
					//Validation in Marketplace
					browser.get(consumeLaunchpadUrl);
					cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
					expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.completedState);
	
					//Validations on SNOW Request page after Completion
					snowPage.logInToSnowDevPortalAndSearchOrder(orderObjectVm.orderNumber);
					expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
					//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
					snowPage.clickRequestedItemLink();
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					snowPage.openConfItemServiceInstanceCIs();
					expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
					expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
					snowPage.clickUpdateButton();
	
					//Validation on Catalog Task page after completion
					snowPage.clickCatalogTaskLink();
					expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
					snowPage.clickUpdateButton();
				});
			});
	
			it('IBM CLoud: Virtual Server - Verify VM instance Turn OFF functionality.', function () {
				var status = vmInstanceTemplate.powerStateOff;
				//var orderObjectvm = {};
				//orderObjectVm.servicename = serviceName;			
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				inventoryPage.open();
				inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
				inventoryPage.clickExpandFirstRow().then(function () {
					browser.executeScript('window.scrollTo(0,0);');
					inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
						inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
							inventoryPage.clickOkForInstanceTurnOFFPermission();
							util.waitForAngular();
						});
					});
				}).then(function () {
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vmInstanceTemplate.orderSubmittedConfirmationMessage);
					orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					orderObjectVm.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
					inventoryPage.clickOkForCustomOpnOrderButton();			
	
					//Validation in Marketplace after auto approval
					expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObjectVm)).toBe(vmInstanceTemplate.orderTypeAction);
					expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.provInProgressState);
					expect(placeOrderPage.getServiceNameOfferingText()).toBe(vmInstanceTemplate.turnOffSvcOfferingName);
	
					//orderObjectVm.orderNumber = "9CSASE1ZRN";
					//Validations on SNOW Request page after auto approval
					snowPage.logInToSnowDevPortalAndSearchOrder(orderObjectVm.orderNumber);
					snowPage.waitUntilApprovalIsApproved();
					expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
					expect(snowPage.getTextShortDescription()).toBe(vmInstanceTemplate.turnOffSvcOfferingName);
					expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
					expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
					expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
	
					//Validations on SNOW Requested Item page
					snowPage.clickRequestedItemLink();
					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
					expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vmInstanceTemplate.turnOffSvcOfferingName);					
					//expect((snowPage.getTextReqItemVariableSerOfferDesc()).toLowerCase()).toBe((snowInstanceTemplate.snowReqItemVariablesSerOfferDescOff).toLowerCase());
					snowPage.getTextReqItemVariableSerOfferDesc().then(function(text){
						expect(text.toLowerCase()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOff.toLowerCase());	
					});
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
					expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOff);
					expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function (sName) {
						expect(sName).toContain(serviceName);
						//expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("stop");
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
						
						// Validate BOM values from Broker config values
						expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

						expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
	
						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
						snowPage.clickUpdateButton();
	
						//Validation on Catalog Task page
						snowPage.clickCatalogTaskLink();
						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
						snowPage.clickUpdateButton();
	
						//Approvals in SNOW
						snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
						snowPage.openRelatedChangeRequest();
						snowPage.approveChangeRequestForEachState();
						snowPage.approveChangeRequestForEachState();
	
						//Order Completion in SNOW
						snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
						snowPage.openRelatedChangeRequest();
						snowPage.checkIfProvisioningTaskClosed();
						snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
						snowPage.openRelatedChangeRequest();
						snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
						//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
	
						//Validation in Marketplace
						browser.get(consumeLaunchpadUrl);
						cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
						expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.completedState);
						inventoryPage.open();
						inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
						var adapterName = "Real";
						var status = vmInstanceTemplate.powerStateOff;
						inventoryPage.clickExpandFirstRow().then(function () {
							inventoryPage.getComponentTags().then(function (text) {
								// if (val == text) {
								// 	status = 'Off';
								// 	adapterName = "dummy";
								// }
								expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObjectVm)).toBe(status);
							});
						});
	
						//Validations on SNOW Request page after Completion
						snowPage.logInToSnowDevPortalAndSearchOrder(orderObjectVm.orderNumber);
						expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
						expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
						expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
						//Validations on SNOW RITM page after Completion
						snowPage.clickRequestedItemLink();
						expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
						//Validation on Catalog Task page after completion
						snowPage.clickCatalogTaskLink();
						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						snowPage.clickUpdateButton();
					});
				});
			});
	
			it('IBM CLoud: Virtual Server - Verify VM insance Turn ON functionality.', function () {			var status = vmInstanceTemplate.powerStateOn;
				// var orderObjectvm = {};
				// orderObjectvm.servicename = serviceName;			
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				inventoryPage.open();
				browser.waitForAngular();
				inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
				inventoryPage.clickExpandFirstRow().then(function () {
					browser.executeScript('window.scrollTo(0,0);');
					inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
						inventoryPage.clickTurnONButtonOfInstance().then(function () {
							inventoryPage.clickOkForInstanceTurnONPermission();
							util.waitForAngular();
						});
					});
				}).then(function () {
					console.log(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal());
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vmInstanceTemplate.orderSubmittedConfirmationMessage);
					orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					orderObjectVm.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
					inventoryPage.clickOkForCustomOpnOrderButton();
					
					//Validation in Marketplace after auto approval
					expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObjectVm)).toBe(vmInstanceTemplate.orderTypeAction);
					expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.provInProgressState);
					expect(placeOrderPage.getServiceNameOfferingText()).toBe(vmInstanceTemplate.turnOnSvcOfferingName);
	
					//Validations on SNOW Request page after auto approval
					snowPage.logInToSnowDevPortalAndSearchOrder(orderObjectVm.orderNumber);
					snowPage.waitUntilApprovalIsApproved();
					expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
					expect(snowPage.getTextShortDescription()).toBe(vmInstanceTemplate.turnOnSvcOfferingName);
					expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
					expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
					expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
	
					//Validations on SNOW Requested Item page
					snowPage.clickRequestedItemLink();
					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
					expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vmInstanceTemplate.turnOnSvcOfferingName);
					//expect((snowPage.getTextReqItemVariableSerOfferDesc()).toLowerCase()).toBe((snowInstanceTemplate.snowReqItemVariablesSerOfferDescOn).toLowerCase());
					snowPage.getTextReqItemVariableSerOfferDesc().then(function(text){
						expect(text.toLowerCase()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOn.toLowerCase());	
					});
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
					expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOn);
					expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function (sName) {
						expect(sName).toContain(serviceName);
						//expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("start");
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
						
						// Validate BOM values from Broker config values
						expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

						expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
	
						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
						snowPage.clickUpdateButton();
	
						//Validation on Catalog Task page
						snowPage.clickCatalogTaskLink();
						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
						snowPage.clickUpdateButton();
	
						//Approvals in SNOW
						snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
						snowPage.openRelatedChangeRequest();
						snowPage.approveChangeRequestForEachState();
						snowPage.approveChangeRequestForEachState();
	
						//Order Completion in SNOW
						snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
						snowPage.openRelatedChangeRequest();
						snowPage.checkIfProvisioningTaskClosed();
						snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
						snowPage.openRelatedChangeRequest();
						snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
						//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
	
						//Validation in Marketplace
						browser.get(consumeLaunchpadUrl);
						cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
						expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.completedState);
						inventoryPage.open();
						inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
						inventoryPage.clickExpandFirstRow().then(function () {
							expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObjectVm)).toBe('On');
						});
	
						//Validations on SNOW Request page after Completion
						snowPage.logInToSnowDevPortalAndSearchOrder(orderObjectVm.orderNumber);
						expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
						expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
						expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
						//Validations on SNOW RITM page after Completion
						snowPage.clickRequestedItemLink();
						expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
						//Validation on Catalog Task page after completion
						snowPage.clickCatalogTaskLink();
						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						snowPage.clickUpdateButton();
					});
				});
			});
	
			it('IBM CLoud: Virtual Server - Verify VM instance Reboot functionality.', function () {
				var status = vmInstanceTemplate.powerStateOn;						
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
				inventoryPage.open();
				browser.waitForAngular();
				inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
				inventoryPage.clickExpandFirstRow().then(function () {
					inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
						inventoryPage.clickRebootButtonOfInstance().then(function () {
							inventoryPage.clickOkForInstanceRebootPermission();
							util.waitForAngular();
						});
					});
				}).then(function () {
					console.log(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal());
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(vmInstanceTemplate.orderSubmittedConfirmationMessage);
					orderObjectVm.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					orderObjectVm.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
					inventoryPage.clickOkForCustomOpnOrderButton();
					//Validation in Marketplace after auto approval
					expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObjectVm)).toBe(vmInstanceTemplate.orderTypeAction);
					expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.provInProgressState);
					expect(placeOrderPage.getServiceNameOfferingText()).toBe(vmInstanceTemplate.rebootSvcOfferingName);
	
					//Validations on SNOW Request page after auto approval
					snowPage.logInToSnowDevPortalAndSearchOrder(orderObjectVm.orderNumber);
					snowPage.waitUntilApprovalIsApproved();
					expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
					expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
					expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
					expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
					expect(snowPage.getTextShortDescription()).toBe(vmInstanceTemplate.rebootSvcOfferingName);
					expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);
					expect(snowPage.getOrderNumberText()).toBe(orderObjectVm.orderNumber);
					expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
	
					//Validations on SNOW Requested Item page
					snowPage.logInToSnowDevPortalAndSearchOrder(orderObjectVm.orderNumber);
					snowPage.clickRequestedItemLink();
					expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
					expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
					expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
					expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vmInstanceTemplate.rebootSvcOfferingName);
					//expect((snowPage.getTextReqItemVariableSerOfferDesc()).toLowerCase()).toBe((snowInstanceTemplate.snowReqItemVariablesSerOfferDescReboot).toLowerCase());
					snowPage.getTextReqItemVariableSerOfferDesc().then(function(text){
						expect(text.toLowerCase()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescReboot.toLowerCase());	
					});
					expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
					expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingReboot);
					expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
					var serName = snowPage.getTextReqItemVariableServiceName();
					serName.then(function (sName) {
						expect(sName).toContain(serviceName);					
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("reboot");
						expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
						
						// Validate BOM values from Broker config values
						expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

						expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
	
						//Validations on SNOW Configuration Item- Service Instance CIs page
						snowPage.switchToDefaultContent();
						snowPage.switchToParentFrame();
						snowPage.openConfItemServiceInstanceCIs();
						expect(snowPage.getTextSerInstanceCIsStatusDisc()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
						snowPage.clickUpdateButton();
	
						//Validation on Catalog Task page
						snowPage.clickCatalogTaskLink();
						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
						snowPage.clickUpdateButton();
	
						//Approvals in SNOW
						snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
						snowPage.openRelatedChangeRequest();
						snowPage.approveChangeRequestForEachState();
						snowPage.approveChangeRequestForEachState();
	
						//Order Completion in SNOW
						snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
						snowPage.openRelatedChangeRequest();
						snowPage.checkIfProvisioningTaskClosed();
						snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
						snowPage.openRelatedChangeRequest();
						snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
						//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
	
						//Validation in Marketplace
						browser.get(consumeLaunchpadUrl);
						cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser, snowInstanceTemplate.consumeUserPwd);
						expect(orderFlowUtil.verifyOrderStatus(orderObjectVm)).toBe(vmInstanceTemplate.completedState);
						inventoryPage.open();
						inventoryPage.searchOrderByServiceName(orderObjectVm.servicename);
						inventoryPage.clickExpandFirstRow().then(function () {
							expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObjectVm)).toBe('On');
						});
	
						//Validations on SNOW Request page after Completion
						snowPage.logInToSnowDevPortalAndSearchOrder(orderObjectVm.orderNumber);
						expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
						expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
						expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
						expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
						//Validations on SNOW RITM page after Completion
						snowPage.clickRequestedItemLink();
						expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
	
						//Validation on Catalog Task page after completion
						snowPage.clickCatalogTaskLink();
						expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
						snowPage.clickUpdateButton();
					});
				});	
				
			});
			
			it('IBM Cloud: Virtual Server - Verify Delete functionality with Auto Technical, Financial, Legal approval and Normal change', function () {
			
				//Place Order for Delete in Marketplace
				var orderObject = {};
				orderObject.servicename = orderObjectVm.servicename;
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
				sampleOrder1 = inventoryPage.getDeleteOrderNumber();
				
				//Validation in Marketplace after auto approval
				expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(slSecurityGrpTemplate.ProvisioningInProgressText);
				
				//Validations on SNOW Request page after auto approval
				snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
				snowPage.waitUntilApprovalIsApproved();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestApprovalState);
				expect(snowPage.getTextShortDescription()).toBe(vmInstanceTemplate.bluePrintName);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).toBe(snowInstanceTemplate.snowRequestCldBrokerLoc);
							
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(vmInstanceTemplate.bluePrintName);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescIbm);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeType);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderSL);
				expect(snowPage.getTextReqItemVariableConCategory()).toBe(vmInstanceTemplate.Category);
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(sName).toContain(serviceName);

				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem1ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem2ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem3ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem4ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem5ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem6ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem7ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem8ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem9ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem10ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem11ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem12ValueVirSer)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem1ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalIbmVirSerDel1);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem2ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalIbmVirSerDel2);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem3ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem4ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem5ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem6ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem7ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem8ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalIbmVirSerDel8);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem9ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem10ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem11ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowIBMCLOUDSrvcItem12ValueVirSer)).toBe(snowInstanceTemplate.snowreqItemBOMtotalSL);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusPending);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickUpdateButton();
				
				//Approvals in SNOW
				snowPage.selectChangeReqStatesWithAssignGrpAndUpdate(snowInstanceTemplate.snowChangeRequestStateAssess);
				snowPage.openRelatedChangeRequest();
				snowPage.approveChangeRequestForEachState();
				snowPage.approveChangeRequestForEachState();
				
				//Order Completion in SNOW
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateImplement);
				snowPage.openRelatedChangeRequest();
				snowPage.checkIfProvisioningTaskClosed();
				snowPage.selectChangeReqStatesAndUpdate(snowInstanceTemplate.snowChangeRequestStateReview);
				snowPage.openRelatedChangeRequest();
				snowPage.closeChangeRequest(snowInstanceTemplate.snowChangeRequestCloseCode);
				//expect(snowPage.getTextChangeReqClosedMsg()).toBe(snowInstanceTemplate.snowChangeRequestClosedMsg);
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(slSecurityGrpTemplate.completedOrderStatus);
				
				//Validations on SNOW Request page after Completion
				snowPage.logInToSnowDevPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getApprovalText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
				snowPage.clickUpdateButton();
				
				//Validation on Catalog Task page after completion
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				});		
			});	
		}
	}
		
});
