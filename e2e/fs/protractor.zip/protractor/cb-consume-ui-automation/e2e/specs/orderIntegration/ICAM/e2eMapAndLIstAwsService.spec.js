/*	
Spec_Name:e2eMapAndLIstAwsService.spec.js
Description: It covers Map and List based Provision, Deprovision,Upgrade and downgrade scenario and Edit service also.
Author: Swaroop Kotme
//commenting pricing validation line because of CON-34016 story.Once this story will get complete I will revert the comments.
*/
"use strict";

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
	Orders = require('../../../pageObjects/orders.pageObject.js'),
	util = require('../../../../helpers/util.js'),
	jsonUtil = require('../../../../helpers/jsonUtil.js'),
	orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../../testData/appUrls.json'),
	isProvisioningRequired = browser.params.isProvisioningRequired,
	InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
	CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
	MapListTemplate = require('../../../../testData/OrderIntegration/ICAM/AWSMapAndListService.json'),
    UpgradeDowngradeMapListTemplate = require('../../../../testData/OrderIntegration/ICAM/UpgradeDowngradeAWSMapAndListService.json');


describe('TA - MAP and LIST based service (includes U/D,prov,edit SOI,deprov)', function () {

	var catalogPage, catalogDetailsPage, placeOrderPage, ordersPage, serviceName, awsSshKeyName, awsSshKeyNameUD,inventoryPage;
	serviceName = MapListTemplate.serviceNamePrefix + "-" + util.getRandomString(5);
	var modifiedParamMap = {};
	var modifiedParamMapupgrade = {};
	var modifiedParamMapdowngrade = {};
	var orderObject = {};
	var orderObjectupgradeorder = {};
	var orderObjectdowngradeorder = {}
	var orderObjectpreorder = {};

	var messageStrings = {
		providerName: MapListTemplate.providerName,
		category: MapListTemplate.category,
		//estimatedPrice: MapListTemplate.estimatedPrice,
		providerAccount: MapListTemplate.providerAccount,
		completedState: MapListTemplate.completedState,
		approvalState: MapListTemplate.approvalState,
		urlOrders: MapListTemplate.urlOrders,
		//estimatedCost: MapListTemplate.estimatedCost,
		provisiongstatus: MapListTemplate.provisiongstatus,
		orderTypeDel : UpgradeDowngradeMapListTemplate.orderTypeDel,
		orderSubmittedConfirmationMessage: MapListTemplate.orderSubmittedConfirmationMessage,
	};

	beforeAll(function () {
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		catalogDetailsPage = new CatalogDetailsPage();
		inventoryPage = new InventoryPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
		awsSshKeyName = MapListTemplate.awsSshKeyNamePrefix + "-" + util.getRandomString(5);
		awsSshKeyNameUD = MapListTemplate.awsSshKeyNamePrefix + "-" + util.getRandomString(6);
	    modifiedParamMap = { "Service Instance Name": serviceName, "Public SSH Key Name": awsSshKeyName }
	});

	it('TA : MAP and LIST based service --- Verify fields on Main Parameters page', function(){
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);	
		catalogPage.clickConfigureButtonBasedOnName(MapListTemplate.bluePrintName);
		expect(util.getCurrentURL()).toMatch(appUrls.placeOrderMainParamtersPageUrl);
		placeOrderPage.setServiceNameTextICAM("icam-automation-vm-" + util.getRandomString(4));
		placeOrderPage.selectProviderAccount(messageStrings.providerAccount);
		expect(placeOrderPage.isNextButtonEnabled()).toBe(true);
	});

	it('TA : MAP and LIST based service --- Verify Summary details and Additional Details are listed in review Order page', function() {
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
		catalogPage.searchForBluePrint(MapListTemplate.bluePrintName);
	    catalogPage.clickConfigureButtonBasedOnName(MapListTemplate.bluePrintName);
	    orderFlowUtil.fillOrderDetailsICAM(MapListTemplate, modifiedParamMap).then(function (requiredReturnMap) {
	        expect(placeOrderPage.getTextServiceName_ReviewOrder()).toBe(serviceName);
			//	expect(placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(messageStrings.estimatedPrice);
			expect(requiredReturnMap["Actual"]["Instance Plan"]).toEqual(requiredReturnMap["Expected"]["Instance Plan"]);
			expect(requiredReturnMap["Actual"]["AWS Region Name"]).toEqual(requiredReturnMap["Expected"]["AWS Region Name"]);
			expect(requiredReturnMap["Actual"]["Cloud Connection Name"]).toEqual(requiredReturnMap["Expected"]["Cloud Connection Name"]);
			expect(requiredReturnMap["Actual"]["VPC Name tag"]).toEqual(requiredReturnMap["Expected"]["VPC Name tag"]);
			expect(requiredReturnMap["Actual"]["Subnet Name"]).toEqual(requiredReturnMap["Expected"]["Subnet Name"]);
			expect(requiredReturnMap["Actual"]["Public SSH Key Name"]).toEqual(requiredReturnMap["Expected"]["Public SSH Key Name"]);
			expect(requiredReturnMap["Actual"]["List Parameter 2"]).toEqual(requiredReturnMap["Expected"]["List Parameter 2"]);
			expect(requiredReturnMap["Actual"]["Key"]).toEqual(requiredReturnMap["Expected"]["Key"]);
			expect(requiredReturnMap["Actual"]["Value"]).toEqual(requiredReturnMap["Expected"]["Value"]);
	    });
	});

	it('TA : MAP and LIST based service ---- Verify Order is listed in Orders details page once it is submitted from catalog page',function(){
		catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
	    catalogPage.clickConfigureButtonBasedOnName(MapListTemplate.bluePrintName);
	    orderFlowUtil.fillOrderDetailsICAM(MapListTemplate, modifiedParamMap).then(function(requiredReturnMap){
	    placeOrderPage.submitOrder();
	    expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
	    var orderId = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
	    placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
	    ordersPage.open();
	    expect(util.getCurrentURL()).toMatch(messageStrings.urlOrders);
	    ordersPage.searchOrderById(orderId);
	    expect(ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderId);
	    ordersPage.clickFirstViewDetailsOrdersTable();
	    expect(ordersPage.getTextOrderServiceNameOrderDetails()).toEqual(serviceName);
	    expect(ordersPage.getTextFirstOrderStatusOrdersTable()).toEqual(messageStrings.approvalState);
	    expect(ordersPage.isDisplayedApproveButtonOrderDetails()).toEqual(true);
	    expect(ordersPage.isDisplayedDenyButtonOrderDetails()).toEqual(true);
	    ordersPage.clickServiceConfigurationsTabOrderDetails();
		expect(requiredReturnMap["Actual"]["Instance Plan"]).toEqual(requiredReturnMap["Expected"]["Instance Plan"]);
			expect(requiredReturnMap["Actual"]["AWS Region Name"]).toEqual(requiredReturnMap["Expected"]["AWS Region Name"]);
			expect(requiredReturnMap["Actual"]["Cloud Connection Name"]).toEqual(requiredReturnMap["Expected"]["Cloud Connection Name"]);
			expect(requiredReturnMap["Actual"]["VPC Name tag"]).toEqual(requiredReturnMap["Expected"]["VPC Name tag"]);
			expect(requiredReturnMap["Actual"]["Subnet Name"]).toEqual(requiredReturnMap["Expected"]["Subnet Name"]);
			expect(requiredReturnMap["Actual"]["Public SSH Key Name"]).toEqual(requiredReturnMap["Expected"]["Public SSH Key Name"]);
			//expect(requiredReturnMap["Actual"]["Public SSH Key"]).toBeDefined();
			expect(requiredReturnMap["Actual"]["List Parameter 2"]).toEqual(requiredReturnMap["Expected"]["List Parameter 2"]);
			expect(requiredReturnMap["Actual"]["Key"]).toEqual(requiredReturnMap["Expected"]["Key"]);
			expect(requiredReturnMap["Actual"]["Value"]).toEqual(requiredReturnMap["Expected"]["Value"]);
			ordersPage.clickBillOfMaterialsTabOrderDetails();
		//	expect(ordersPage.getEstimatedCostFromBillOfMaterialsTab()).toEqual(messageStrings.estimatedCost);
	    }); 
	});

	if (isProvisioningRequired == "true") {
		it('TA : Upgrading MAP and LIST based sevice from V1 to V2 --- Verify Provision and Upgrade service version', function () {
			catalogPage.clickFirstCategoryCheckBoxBasedOnName(messageStrings.category);
			catalogPage.clickConfigureButtonBasedOnName(MapListTemplate.bluePrintName);
			orderObjectpreorder.servicename = serviceName;
			orderFlowUtil.fillOrderDetailsICAM(MapListTemplate, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObjectpreorder.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			orderFlowUtil.approveOrder(orderObjectpreorder);
			orderFlowUtil.waitForOrderStatusChange(orderObjectpreorder, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObjectpreorder)).toBe(messageStrings.completedState);

			orderFlowUtil.verifyOrderStatus(orderObjectpreorder).then(function (status) {
				if (status == 'Completed') {
					orderObjectpreorder = { servicename: serviceName };
					//Upgrade flow
					modifiedParamMapupgrade = { "EditService": true, "Public SSH Key Name": awsSshKeyNameUD };
					orderFlowUtil.UpgradeServiceforICAM(orderObjectpreorder);
					browser.sleep(5000);
					catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
					orderFlowUtil.fillOrderDetails(MapListTemplate, modifiedParamMapupgrade).then(function () {
						browser.sleep(5000);
					});
					placeOrderPage.submitOrder();
					orderObjectupgradeorder.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
					placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
					orderFlowUtil.approveOrder(orderObjectupgradeorder);
					orderFlowUtil.waitForOrderStatusChange(orderObjectupgradeorder, messageStrings.completedState);
					expect(orderFlowUtil.verifyOrderStatus(orderObjectupgradeorder)).toBe(messageStrings.completedState);
					orderFlowUtil.verifyOrderStatus(orderObjectupgradeorder).then(function (status) {
						if (status == 'Completed') {
							//Verify updated details are reflected on order details page or not.						
							ordersPage.clickFirstViewDetailsOrdersTable();
							expect(ordersPage.getTextBasedOnLabelName("Cloud Connection Name")).toEqual(jsonUtil.getValueEditParameter(MapListTemplate, "Cloud Connection Name"))
							expect(ordersPage.getTextBasedOnLabelName("VPC Name tag")).toEqual(jsonUtil.getValueEditParameter(MapListTemplate, "VPC Name tag"));
							expect(ordersPage.getTextBasedOnLabelName("Subnet Name")).toEqual(jsonUtil.getValueEditParameter(MapListTemplate, "Subnet Name"));
							expect(ordersPage.getTextBasedOnLabelName("AWS Region Name")).toEqual(jsonUtil.getValueEditParameter(MapListTemplate, "AWS Region Name"));
							expect(ordersPage.getTextBasedOnLabelName("MCMP Version")).toEqual("2.0.0.0");
							ordersPage.clickServiceDetailSliderCloseButton();
						}
					});
				}
			});
		});

		it('TA : MAP and list Downgrade sevice from V2 to V1 --- Verify Downgrade service version', function () {
			orderFlowUtil.waitForOrderStatusChange(orderObjectupgradeorder, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatus(orderObjectupgradeorder)).toBe(messageStrings.completedState);
			orderFlowUtil.verifyOrderStatus(orderObjectupgradeorder).then(function (status) {
				if (status == 'Completed') {
					modifiedParamMapdowngrade = { "EditService": true,"Public SSH Key Name": awsSshKeyName  };
					//Downgrade flow
					orderFlowUtil.DowngradeServiceforICAM(orderObjectpreorder);
					browser.sleep(5000);
					catalogDetailsPage.clickConfigureButtonCatalogDetailsPage();
					orderFlowUtil.fillOrderDetails(UpgradeDowngradeMapListTemplate, modifiedParamMapdowngrade).then(function () {
						browser.sleep(5000);
					});
					placeOrderPage.submitOrder();
					orderObjectdowngradeorder.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
					placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
					orderFlowUtil.approveOrder(orderObjectdowngradeorder);
					orderFlowUtil.waitForOrderStatusChange(orderObjectdowngradeorder, messageStrings.completedState);
					expect(orderFlowUtil.verifyOrderStatus(orderObjectdowngradeorder)).toBe(messageStrings.completedState);
					orderFlowUtil.verifyOrderStatus(orderObjectdowngradeorder).then(function (status) {
						if (status == 'Completed') {
							//Verify updated details are reflected on order details page or not.						
							ordersPage.clickFirstViewDetailsOrdersTable();
							expect(ordersPage.getTextBasedOnLabelName("Cloud Connection Name")).toEqual(jsonUtil.getValueEditParameter(UpgradeDowngradeMapListTemplate, "Cloud Connection Name"))
							expect(ordersPage.getTextBasedOnLabelName("VPC Name tag")).toEqual(jsonUtil.getValueEditParameter(UpgradeDowngradeMapListTemplate, "VPC Name tag"));
							expect(ordersPage.getTextBasedOnLabelName("Subnet Name")).toEqual(jsonUtil.getValueEditParameter(UpgradeDowngradeMapListTemplate, "Subnet Name"));
							expect(ordersPage.getTextBasedOnLabelName("AWS Region Name")).toEqual(jsonUtil.getValueEditParameter(UpgradeDowngradeMapListTemplate, "AWS Region Name"));
							expect(ordersPage.getTextBasedOnLabelName("MCMP Version")).toEqual("1.0.0.0");
							ordersPage.clickServiceDetailSliderCloseButton();
						}
					});
				}
			});
		});

		it('TA : MAP and LIST based service --- Verify Edit service', function () {
			expect(orderFlowUtil.verifyOrderStatus(orderObjectdowngradeorder)).toBe(messageStrings.completedState);
			orderFlowUtil.verifyOrderStatus(orderObjectdowngradeorder).then(function (status) {
				//Edit flow 
				if (status == 'Completed') {
					modifiedParamMapupgrade = { "EditService": true,"Public SSH Key Name": awsSshKeyName };
					orderFlowUtil.editService(orderObjectpreorder);
					orderFlowUtil.fillOrderDetails(MapListTemplate, modifiedParamMapupgrade).then(function () {
						browser.sleep(5000);
					});
					placeOrderPage.submitOrder();
					orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
					expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(messageStrings.orderSubmittedConfirmationMessage);
					placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
					orderFlowUtil.approveOrder(orderObject);
					orderFlowUtil.waitForOrderStatusChange(orderObject, messageStrings.completedState);
					expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(messageStrings.completedState);
					orderFlowUtil.verifyOrderStatus(orderObject).then(function (status) {
						if (status == 'Completed') {
							//Verify updated details are reflected on order details page.						
							ordersPage.clickFirstViewDetailsOrdersTable();
							expect(ordersPage.getTextBasedOnLabelName("AWS Region Name")).toEqual(jsonUtil.getValueEditParameter(MapListTemplate, "AWS Region Name"));
							expect(ordersPage.getTextBasedOnLabelName("VPC Name tag")).toEqual(jsonUtil.getValueEditParameter(MapListTemplate, "VPC Name tag"));
							expect(ordersPage.getTextBasedOnLabelName("Subnet Name")).toEqual(jsonUtil.getValueEditParameter(MapListTemplate, "Subnet Name"));
							ordersPage.clickServiceDetailSliderCloseButton();
						}
					});
				}
			});
		});

		it('TA : MAP and LIST based service --- Verify delete services', function () {
			//Delete Service flow  
			orderObjectpreorder.servicename = serviceName;
			inventoryPage.open();
			inventoryPage.searchOrderByServiceName(orderObjectpreorder.servicename);
			orderObjectpreorder.deleteOrderNumber = orderFlowUtil.deleteService(orderObjectpreorder);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObjectpreorder)).toBe(messageStrings.orderTypeDel);
			orderFlowUtil.approveDeletedOrder(orderObjectpreorder);
			orderFlowUtil.waitForDeleteOrderStatusChange(orderObjectpreorder, messageStrings.completedState);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObjectpreorder)).toBe(messageStrings.completedState);
		});
	}
});
