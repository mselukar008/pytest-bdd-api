
"use strict";

var logGenerator = require("../../../../helpers/logGenerator.js"),
    Logger = logGenerator.getApplicationLogger(),
    CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
    CatalogDetailsPage = require('../../../pageObjects/catalogdetails.pageObject.js'),
    jsonUtil = require('../../../../helpers/jsonUtil.js'),
    PlaceOrderPage = require('../../../pageObjects/placeOrder.pageObject.js'),
    OrdersPage = require('../../../pageObjects/orders.pageObject.js'),
    InventoryPage = require('../../../pageObjects/inventory.pageObject.js'),
    BudgetaryPage = require('../../../pageObjects/budget.pageObject.js'),
    CartListPage = require('../../../pageObjects/cartList.pageObject.js'),
    budgetaryFlow = require('../../../../helpers/budgetaryFlow.js'),
    budgetDeleteApi = require('../../../../helpers/budgetDeleteApiUtil.js'),
    util = require('../../../../helpers/util.js'),
    orderFlowUtil = require('../../../../helpers/orderFlowUtil.js'),
    appUrls = require('../../../../testData/appUrls.json'),
    EC = protractor.ExpectedConditions,
    isProvisioningRequired = browser.params.isProvisioningRequired,
    credentailsTemplate = require('../../../../testData/credentials.json'),
    kmsInstanceTemplate = require('../../../../testData/OrderIntegration/AWS/AWSKMSInstance.json'),    
    budgetaryUnitDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryUnitDetails.json'),
    budgetaryAddNewBudgetDetailsTemplate = require('../../../../testData/OrderIntegration/budget/budgetaryAddNewBudgetDetails.json');


describe('AWS : Budget for Single User', function () {
    var catalogPage, placeOrderPage, ordersPage, inventoryPage, catalogDetailsPage, cartListPage, aliasKms, serviceName, budgetryPage, budgetaryName,
        budgetaryNewBudgetName, budgetaryUnitCode;
    var modifiedParamMap = {};
    var modifiedParamMapBudget = {};
    var modifiedNewBudgetParamMap = {};
    var messageStrings = {
        providerName: 'Amazon',
        category: 'Compute',
        superUserUsername: credentailsTemplate.superUserID,
        superUserPassword: credentailsTemplate.superUserPassword,
        budgetaryUnitDeleteSuccessMsg:budgetaryUnitDetailsTemplate.budgetaryUnitDeleteSuccessMsg
    };
    

    beforeAll(function () {
        catalogPage = new CatalogPage();
        placeOrderPage = new PlaceOrderPage();
        catalogDetailsPage = new CatalogDetailsPage();
        ordersPage = new OrdersPage();
        inventoryPage = new InventoryPage();
        budgetryPage = new BudgetaryPage();
        cartListPage = new CartListPage();
        browser.driver.manage().window().maximize();
        budgetaryName = "awsAut" + util.getRandomString(8);
        budgetaryNewBudgetName = "newAwsAut" + util.getRandomString(8);
        budgetaryUnitCode = "AwsCode" + util.getRandomString(8);
        serviceName = "aws-singleUserBudget-" + util.getRandomString(5);
        aliasKms = "aliaskms" + util.getRandomString(5);
        aliasKms = aliasKms.toLowerCase();        
        modifiedParamMap = { "Service Instance Name": serviceName, "Team": "budgetTEAM2", "Environment": "awsEnv", "Application": "awsApp", "Provider Account": "", "Alias": aliasKms };
        modifiedParamMapBudget = { "budgetary Name": budgetaryName, "budgetary unit code": budgetaryUnitCode, "Choose Entity": "Organization", "Entity Value": "budgetORG", "Environment": "awsEnv", "Application": "awsApp" };

    });

    beforeEach(function () {
	orderFlowUtil.closeHorizontalSliderIfPresent();
        catalogPage.open();
    });   
   

    it('AWS-SingleUserBudget-Add new budgetry Unit for E2E budget Flow ', function () {
        
        budgetryPage.open();
        //util.waitForAngular();
        budgetryPage.clickOnAddNewBudgetryUnitBtn();
        budgetryPage.fillOrderDetails(budgetaryUnitDetailsTemplate, modifiedParamMapBudget);
        budgetryPage.clickOnBudgetrySaveBtn();
        budgetryPage.clickOnBudgetryBudgetsLink();
        budgetryPage.clickOnBudgetaryAddBudgetButton();
        var startPeriod = budgetaryFlow.incrementMonth(0);
        modifiedNewBudgetParamMap = { "Name": budgetaryNewBudgetName, "Start Period": startPeriod, "Notify When Soft Quota reached": "budgetTEAM2", "Notify When Hard Quota reached": "budgetTEAM2" };
        budgetryPage.fillOrderDetails(budgetaryAddNewBudgetDetailsTemplate, modifiedNewBudgetParamMap);
        budgetryPage.clickOnBudgetaryCreateNewBudgetButton();
        budgetryPage.clickOnNotificationCloseButton();
       // budgetryPage.clickOnBudgetaryBackBudgetButton();
        budgetryPage.clickBudgetSliderCloseButton();
    });


    it('AWS-SingleUserBudget - Verify the budget for EC2', function () {
        var orderObject = {};
        var availBudgetProvCompleted, afterProvCommittedAmnt, beforePovisioningAvailBudget, calculatedEstAmtOnBudgetPage, afterPovisioningAvailBudgetOnBudgetPage, afterProvCommittedAmntOnBudgetPage;
        var kmsInsObject = JSON.parse(JSON.stringify(kmsInstanceTemplate));

        var budgetAmount = kmsInstanceTemplate.budgetAmount;
        var zerobudgetAmount = kmsInstanceTemplate.zerobudgetAmount;
	//orderFlowUtil.closeHorizontalSliderIfPresent();
	//catalogPage.open();
        catalogPage.clickProviderCheckBoxBasedOnName(messageStrings.providerName);
        catalogPage.clickProviderOrCategoryCheckbox(kmsInstanceTemplate.Category);
        catalogPage.clickConfigureButtonBasedOnName(kmsInstanceTemplate.bluePrintName);

        orderObject.servicename = serviceName;

        orderFlowUtil.fillOrderDetails(kmsInstanceTemplate, modifiedParamMap).then(async function (ttt) {

            //Submit order
            placeOrderPage.submitOrder();
            orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
            orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();

            //Get details on pop up after submit
            var orderprice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
            var ordersubmittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();

            // Open Order page and Approve Order 
            expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Submitted !');
            placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();

            //Open Approve order page
            ordersPage.open();
            //Search by Order ID and verify the parameters on View order page
            ordersPage.searchOrderById(orderObject.orderNumber);

            //select Budgetary Unit
            ordersPage.selectBudgetaryUnit(budgetaryName);
            util.waitForAngular();

            /*************  Order Submitted *************/
            expect(ordersPage.getTextBudgetAmmount()).toEqual(kmsInstanceTemplate.BudgetAmount);

            //Fetch the Available budget and committed Amount after order is submitted for further calculation
            var beforePovisioningCommittedAmount = await ordersPage.getTextBudgetaryCommittedAmmount();

            //Other orders awaiting approval amount should be equal to the estimated Amount  
            //This will pass if no other user are using this budget and the initial amount for this is equal to USD 0.00

            var calculatedEstAmount = ordersPage.calculateBudgetaryEstimatedAmmountforOrder(kmsInstanceTemplate.budgetDuration, kmsInstanceTemplate.TotalCost);
            beforePovisioningAvailBudget = await ordersPage.getTextAvailableBudget();
            var costOtherOrdersAwaitingApprovalBeforeProvision = await ordersPage.getTextOtherOrdersAwaitingApproval();
            //expect(costOtherOrdersAwaitingApprovalBeforeProvision).toContain(calculatedEstAmount);

            //As the spend amount is always zero 
            expect(ordersPage.getTextBudgetarySpendAmmount()).toEqual("USD 0.00");
            expect(ordersPage.getTextBudgetaryEstimatedAmmountforOrder()).toContain(calculatedEstAmount);

            /*********Approve the order ********************/
            orderFlowUtil.approveOrder(orderObject);
            orderFlowUtil.waitForOrderStatusChange(orderObject, 'Completed').then(function () {

                /********** Order provisioning completed **********/
                //order status completed 
                availBudgetProvCompleted = ordersPage.calculateAvailableBudgetAfterProvCompleted(beforePovisioningAvailBudget, calculatedEstAmount);
                expect(ordersPage.getTextAvailableBudget()).toContain(availBudgetProvCompleted);

                //once the provisioning completed Other total amount will be equal to ( Other total amount before provision - calculated Est Amount)
                var actualOrdersAwaitingApprovalAmout = ordersPage.calculateAfterProvOtherOrderAwaitingApprovalAmount(costOtherOrdersAwaitingApprovalBeforeProvision, calculatedEstAmount);
                expect(ordersPage.getTextOtherOrdersAwaitingApproval()).toEqual(actualOrdersAwaitingApprovalAmout);

                afterProvCommittedAmnt = ordersPage.calculateCommittedAmountAfterProvCompleted(beforePovisioningCommittedAmount, calculatedEstAmount);
                expect(ordersPage.getTextBudgetaryCommittedAmmount()).toContain(afterProvCommittedAmnt);
                expect(ordersPage.getTextBudgetarySpendAmmount()).toEqual("USD 0.00");

                /**************************Check Budget Details on Budget Page after Provisioning**************************************/

                calculatedEstAmtOnBudgetPage = budgetryPage.calculateEstimatedAmmountforOrder(kmsInstanceTemplate.budgetDuration, kmsInstanceTemplate.TotalCost);
                afterProvCommittedAmntOnBudgetPage = budgetryPage.calculateCommittedAmountAfterProvCompletedOnBudgetPage(beforePovisioningCommittedAmount, calculatedEstAmtOnBudgetPage);
                afterPovisioningAvailBudgetOnBudgetPage = budgetryPage.calculateAvailableBudgetAfterProvCompletedOnBudgetPage(beforePovisioningAvailBudget, calculatedEstAmtOnBudgetPage);
                budgetryPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.budgetaryUrl);
                util.waitForAngular();
                budgetryPage.isPresentbudgetryUnitsText();
                budgetryPage.isPresentAddNewBudgetryUnitBtn();
                budgetryPage.isPresentBudgetryUnitsTable();
                budgetryPage.selectbudgetaryPaginationDropDown();
                budgetryPage.checkBudgetaryNameInBudgetaryUnitTable(budgetaryName)

                var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
                expect(status).toEqual(kmsInstanceTemplate.budgetActiveStatusInBudgetaryUnitTable);
                budgetryPage.clickOnViewDetailsForBudgetaryUnit(budgetaryName, budgetaryNewBudgetName);
                expect(budgetryPage.getValueBasedOnLabelName("Budget Amount")).toEqual("USD " + budgetAmount);
                expect(budgetryPage.getValueBasedOnLabelName("Available Amount")).toContain(parseInt(afterPovisioningAvailBudgetOnBudgetPage));
                expect(budgetryPage.getValueBasedOnLabelName("Committed Amount")).toContain(parseInt(afterProvCommittedAmntOnBudgetPage));
                expect(budgetryPage.getValueBasedOnLabelName("Under Approval Amount")).toEqual("USD " + zerobudgetAmount);
                budgetryPage.clickBudgetSliderCloseButton();
                budgetryPage.clickBudgetSliderCloseButton();
		catalogPage.open();
                orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
                expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe('Delete');
                orderFlowUtil.approveDeletedOrder(orderObject);
                orderFlowUtil.waitForDeleteOrderStatusChange(orderObject, 'Completed');
                expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe('Completed');

                /********** Delete order status completed **********/
                var estCostAfterDeleting1MonthOrder = ordersPage.calculateEstCostAfterDeleting1MonthOrder(calculatedEstAmount, kmsInstanceTemplate.TotalCost);
                expect(estCostAfterDeleting1MonthOrder).toContain(ordersPage.getTextBudgetaryEstimatedAmmountforOrder());

                var deletedCommittedAmnt = ordersPage.calculateDeleteCommittedAmount(afterProvCommittedAmnt, estCostAfterDeleting1MonthOrder);
                expect(deletedCommittedAmnt).toContain(ordersPage.getTextBudgetaryCommittedAmmount());

                var deletedAvailableBudget = ordersPage.calculateAfterDeletingAvailBudget(availBudgetProvCompleted, estCostAfterDeleting1MonthOrder);
                expect(deletedAvailableBudget).toContain(ordersPage.getTextAvailableBudget());

                /************************** Check Budget Details on Budget Page after Deletion **************************************/
                var estCostAfterDeleting1MonthOrderOnBudgetPage = budgetryPage.calculateEstCostAfterDeleting1MonthOrderOnBudgetPage(calculatedEstAmtOnBudgetPage, kmsInstanceTemplate.TotalCost);
                var deletedCommittedAmntOnBudgetPage = budgetryPage.calculateDeleteCommittedAmountOnBudgetPage(afterProvCommittedAmntOnBudgetPage, estCostAfterDeleting1MonthOrderOnBudgetPage);
                var deletedAvailableBudgetOnBudgetPage = budgetryPage.calculateAfterDeletingAvailBudgetOnBudgetPage(afterPovisioningAvailBudgetOnBudgetPage, estCostAfterDeleting1MonthOrderOnBudgetPage);
                budgetryPage.open();
                expect(util.getCurrentURL()).toMatch(appUrls.budgetaryUrl);
                util.waitForAngular();
                budgetryPage.isPresentbudgetryUnitsText();
                budgetryPage.isPresentAddNewBudgetryUnitBtn();
                budgetryPage.isPresentBudgetryUnitsTable();
                budgetryPage.selectbudgetaryPaginationDropDown();
                var status = budgetryPage.checkBudgetaryStausInBudgetaryUnitTable(budgetaryName);
                expect(status).toEqual("Active");
                budgetryPage.clickOnViewDetailsForBudgetaryUnit(budgetaryName, budgetaryNewBudgetName);
                expect(budgetryPage.getValueBasedOnLabelName("Budget Amount")).toEqual("USD " + budgetAmount);
                expect(budgetryPage.getValueBasedOnLabelName("Available Amount")).toContain(parseInt(deletedAvailableBudgetOnBudgetPage));
                expect(budgetryPage.getValueBasedOnLabelName("Committed Amount")).toContain(parseInt(deletedCommittedAmntOnBudgetPage));
                expect(budgetryPage.getValueBasedOnLabelName("Under Approval Amount")).toEqual("USD " + zerobudgetAmount);
                budgetryPage.clickBudgetSliderCloseButton();
                budgetryPage.clickBudgetSliderCloseButton();
            });
        });
    });

    afterAll(function () {
        orderFlowUtil.closeHorizontalSliderIfPresent();	
	catalogPage.open();    
// 	catalogPage.getUserID(credentailsTemplate.superUserName).then(function (status) {
// 		if (status != true) {
// 			orderFlowUtil.closeHorizontalSliderIfPresent();
// 			cartListPage.clickUserIcon();				
// 			cartListPage.clickLogoutButton();
// 			cartListPage.loginFromOtherUser(messageStrings.superUserUsername, messageStrings.superUserPassword);
// 			catalogPage.open();
// 			expect(catalogPage.getUserID(credentailsTemplate.superUserName)).toBe(true);
// 		}
// 	});		
	budgetryPage.deleteBudget(budgetaryName); 
	//expect(budgetryPage.getNotificationMsg()).toContain(messageStrings.budgetaryUnitDeleteSuccessMsg);
    });

});
