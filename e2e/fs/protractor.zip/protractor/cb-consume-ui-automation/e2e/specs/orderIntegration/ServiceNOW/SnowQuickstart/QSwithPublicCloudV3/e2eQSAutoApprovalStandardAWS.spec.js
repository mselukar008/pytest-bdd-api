"use strict";

var Orders = require('../../../../../pageObjects/orders.pageObject.js'),
	CatalogPage = require('../../../../../pageObjects/catalog.pageObject.js'),
	PlaceOrderPage = require('../../../../../pageObjects/placeOrder.pageObject.js'),
	InventoryPage = require('../../../../../pageObjects/inventory.pageObject.js'),
	CartListPage = require('../../../../../pageObjects/cartList.pageObject.js'),
	util = require('../../../../../../helpers/util.js'),
	orderFlowUtil = require('../../../../../../helpers/orderFlowUtil.js'),
	jsonUtil = require('../../../../../../helpers/jsonUtil.js'),
	appUrls = require('../../../../../../testData/appUrls.json'),
	snowAPI = require('../../../../../../helpers/snowApiRequests.js'),
	SNOWPage = require('../../../../../pageObjects/snow.pageObject.js'),
	url = browser.params.url,
	isProvisioningRequired = browser.params.isProvisioningRequired,
	runSnowDiscovery = browser.params.runSnowDiscovery,
	isDummyAdapterDisabled = browser.params.isDummyAdapterDisabled,
	awsEC2template = require('../../../../../../testData/OrderIntegration/ServiceNOW/AWSEC2InstanceSnowV3SpecstoSkipIMI.json'),
	PolicyPage = require('../../../../../pageObjects/policy.pageObject.js'),
	policyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicy.json'),
	addRulePolicyTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWApprovalPolicyRule.json'),
	snowInstanceTemplate = require('../../../../../../testData/OrderIntegration/ServiceNOW/SNOWInstanceData.json');
	
describe('QS: AWS E2E cases for Auto Technical, Financial and Legal approval with Standard change', function() {
	var ordersPage, catalogPage, placeOrderPage, policyPage, snowPage, sampleOrder1, provOrder, inventoryPage, awsEC2obj, bucketPolicyEditor, groupName, cartListPage;
	var modifiedParamMap = {};
	var modifiedParamMapPolicy = {};
	var modifiedParamMapAddRule = {};
	var serviceName = "SNOWQSauto"+util.getRandomString(5);
	var policyName = "SNOWQSautoAWSPolicy"+util.getRandomString(5);
	var policyRuleName = "SNOWQSautoAWSPolicyRule"+util.getRandomString(5);
	var consumeLaunchpadUrl = url + '/launchpad';

	beforeAll(function() {
		snowPage = new SNOWPage();
		ordersPage = new Orders();
		catalogPage = new CatalogPage();
		placeOrderPage = new PlaceOrderPage();
		inventoryPage = new InventoryPage();
		policyPage = new PolicyPage();
		cartListPage = new CartListPage();
		browser.driver.manage().window().maximize();
		
		//Delete policy if exists
		policyPage.open();
		util.waitForAngular();
		policyPage.deletePoliciesIfExist();
	});

	beforeEach(function() {
		groupName = "att-group-" + util.getRandomString(5);
		awsEC2obj = JSON.parse(JSON.stringify(awsEC2template));
		modifiedParamMapPolicy = {"policy Name":policyName, "Values":"Auto-TEAM1 (my_org)"};
		modifiedParamMapAddRule = {"Add Rule Name":policyRuleName,"Order Type": ["New","Edited","Deleted","ServiceAction"],"Provider":["Amazon"],"Total Monthly Cost":"","Monthly Cost":"","Budget Is":""};
		modifiedParamMap = {"Service Instance Name":serviceName, "Team":"Auto-TEAM1", "Environment":"QA", "Application":"", "Provider Account":"AWS-SNOW / AWS-SNOW", "Group Name": groupName};
	});
	
	afterAll(function() {
		//Delete Approval Policy
		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	  	policyPage.open();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickPolicyViewDetailButton();
	  	policyPage.clickRadioButtonRetiredOption();
	  	policyPage.clickUpdatePolicyBtn();
	  	expect(policyPage.getTextSuccessfulToastPolicyNotification()).toEqual(policyTemplate.updatePolicySuccessMsg+" "+policyName+" successfully");
	  	var policyStatusInPolicy=policyPage.getTextPolicyStatusInPolicyTable(policyName);
	  	expect(policyStatusInPolicy).toEqual(policyTemplate.retiredPolicyStatus);
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	policyPage.clickPolicyDetailIcon();
	  	policyPage.clickButtonDeletePolicyText();
	  	policyPage.clickDeleteConfirmationPopUpPolicyBtn();
	  	util.waitForAngular();
	  	policyPage.searchPolicyInPolicyTextbox(policyName);
	  	expect(policyPage.getTextPolicyNoData()).toBe(policyTemplate.policyNoData);

		browser.get(consumeLaunchpadUrl);
		cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
	});
	
	it('Set Change Request type to Standard in SNOW', function () {
		expect(snowAPI.setChangeRequestToStandard()).toBe(parseInt(snowInstanceTemplate.snowAPIstatusCode));
	});
	
	it('Create Approval Policy for AWS with Auto Technical, Financial, Legal approval and Standard change', function () {
		policyPage.open();
  		policyPage.clickAddNewPolicyBtn();
  		policyPage.selectStartDate();
  		policyPage.fillPolicyDetails(policyTemplate, modifiedParamMapPolicy);
  		policyPage.fillPolicyDetails(addRulePolicyTemplate, modifiedParamMapAddRule);
  		policyPage.clickApplyRulePolicyBtn();
  		var policyRuleNameTextInApprovalPolicy=policyPage.getTextRuleNameInApprovalPolicyPage(policyRuleName);
  		expect(policyRuleNameTextInApprovalPolicy).toEqual(policyRuleName);
  		policyPage.clickCreatePolicyButton();
  		expect(policyPage.getTextSuccessfulToastPolicyNotification()).toBe(policyTemplate.policyCreateSuccessMsg);
  		policyPage.clickNotificationCloseButton();
  		var policyNameInPolicyTable=policyPage.getTextPolicyNameInPolicyTable(policyName);
  		expect(policyNameInPolicyTable).toEqual(policyName);
	});
	
	if(isProvisioningRequired == "true") {	
		it('AWS EC2 ---- Verify Provision functionality with Auto Technical, Financial, Legal approval and Standard change', function () {
			
			//Place Order for Provision in Marketplace
			var orderObject = {};
			catalogPage.open();
			expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
	        catalogPage.clickProviderCheckBoxBasedOnName(awsEC2template.provider);
	        catalogPage.clickFirstCategoryCheckBoxBasedOnName(awsEC2template.Category);
			catalogPage.clickConfigureButtonBasedOnName(awsEC2template.bluePrintName);
			orderObject.servicename = serviceName;
			orderFlowUtil.fillOrderDetails(awsEC2template, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			provOrder = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			var orderObject = {"orderNumber":provOrder};	
			
			//Validation in Marketplace after auto approval
			//Commenting this validation, sometimes state change happens so quickly and it leads to false failure
			//expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
		
			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestProv);		
			expect(snowPage.getOrderNumberText()).toBe(provOrder);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toEqual(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);

			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDEC2);

			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);

			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");

			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValue(awsEC2obj, "Resource Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("Subnet")).toEqual("subnet-a68b538d");
			expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("VPC")).toEqual("vpc-8eadd1eb");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValue(awsEC2obj, "Shutdown Behavior"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("T2/T3 Unlimited")).toEqual(jsonUtil.getValue(awsEC2obj, "T2/T3 Unlimited"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValue(awsEC2obj, "User Data"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));	

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWS);
			
			//Validation on Catalog Task page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.clickCatalogTaskLink();
			
			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();

			//Change Request Short Desc and Desc
			expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescNewOrder);
							
			//Order Completion in SNOW
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);

			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.awsProviderAccountID);
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.awsProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	

			//Change Task Page Validations 
			snowPage.openRelatedChangeRequest();
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickClosureInfoInChangeTask();
			expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			snowPage.clickBackButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickBackButton();
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			
		  });		
	    });
	
		it('AWS EC2 ---- Verify Edit functionality with Auto Technical, Financial, Legal approval and Standard change', function () {
		
			//Place Order for Edit in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			var modifiedParamMap = {"EditService": true };
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderFlowUtil.editService(orderObject);
			orderFlowUtil.fillOrderDetails(awsEC2template, modifiedParamMap);
			placeOrderPage.submitOrder();
			orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			orderObject.totalPrice = placeOrderPage.getTextTotalPriceOrderSubmittedModal();
			sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
			expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
			placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
			
			//Validation in Marketplace after auto approval
			//Commenting this validation, since state change happens so quickly & it leads to false failure 
			//expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.provInProgressState);
			expect(orderFlowUtil.verifyOrderType(orderObject)).toBe(awsEC2template.orderTypeEdit);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			if(isDummyAdapterDisabled== "true") {
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);
			}

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestEdit);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItem);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);

			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDEC2);

			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);

			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");

			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Instance Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("Subnet")).toEqual("subnet-a68b538d");
			expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("VPC")).toEqual("vpc-8eadd1eb");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Shutdown Behavior"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("unlimited Instance Type")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Unlimited Instance Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "User Data"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Assign a security group")).toEqual(jsonUtil.getValue(awsEC2obj,"Assign a security group"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("device Name")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Device Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("volume Size")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Volume Size"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("volume Type")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Volume Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));	

			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2Edit1)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2Edit2)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2Edit3)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2Edit1)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWSEC2Edit1);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2Edit2)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWSEC2Edit2);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2Edit3)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWSEC2Edit3);
			
			//Validation on Catalog Task page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.clickCatalogTaskLink();
			
			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();

			//Change Request Short Desc and Desc
			expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDesc);
			expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescEditOrder);
						
			//Order Completion in SNOW
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);

			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.awsProviderAccountID);
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.awsProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
			snowPage.clickUpdateButton();	

			//Change Task Page Validations 
			snowPage.openRelatedChangeRequest();
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickClosureInfoInChangeTask();
			expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			snowPage.clickBackButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickBackButton();
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			
	       });		
	    });
		
		if(runSnowDiscovery == "true") {
			it('AWS EC2 ---- Run Discovery for AWS before Turn OFF and verify the state of VM in SNOW', function () {
				snowPage.openDiscoverySchedulesQS();
				snowPage.runDiscoveryForAWS();
				expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
				snowPage.clickRequestedItemLink();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
				expect(snowPage.isPresentVMInstanceInCI()).toBe(true);
				snowPage.clickVMInstanceInCILink();
				expect(snowPage.getTextVMInstanceState()).toBe(snowInstanceTemplate.instanceStateOn);			
			});
		};
		
		it('AWS EC2 ---- Verify Turn OFF functionality with Auto Technical, Financial, Legal approval and Standard change', function () {

            //Place order for Turn OFF in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
			orderObject.componentType = awsEC2template.componentType;
            orderObject.servicename = serviceName;
            var val = JSON.stringify({ "IsUsingDummy": "Yes" });
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                util.scrollToTop();
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickTurnOFFButtonOfInstance().then(function () {
                        inventoryPage.clickOkForInstanceTurnOFFPermission();
                    });
                });
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();	

                //Validation in Marketplace after auto approval
                expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(awsEC2template.orderTypeAction);
				expect(placeOrderPage.getServiceNameOfferingText()).toBe(awsEC2template.serviceOfferingTurnOff);
				
				//Validations on SNOW Request page after auto approval
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.waitUntilApprovalIsApprovedQS();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

				expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
				var reqNumber = snowPage.getTextRequestNumberInRequestPage();
				expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

				expect(snowPage.getTextShortDescription()).toBe(awsEC2template.serviceOfferingTurnOff);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
				
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();

				expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
				var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
				expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
				expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextChangeReqNumber()).not.toBe("");
				var changeRequestNumber = snowPage.getTextChangeReqNumber();
				expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
				var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();
			
				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.serviceOfferingTurnOff);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOff);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOff);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
				
				expect(snowPage.getTextReqItemVariableConCategory()).toBe("");
				expect(snowPage.getTextMCMPVersionRITMVariable()).toBe('');
				expect(snowPage.getTextLabelsRITMVariable()).toBe("");
				expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
				
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("stop");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalNA);
				
				//Validation on Catalog Task page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.clickCatalogTaskLink();
				
				expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
				expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
				expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();
				
				//Change Request Short Desc and Desc
				expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescTurnOffOrder);
				
				//Order Completion in SNOW
				snowPage.checkIfProvisioningTaskClosed();
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);
				inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                var adapterName = "Real";
                var status = awsEC2template.stopStatus;
                inventoryPage.clickExpandFirstRow().then(function () {
                    inventoryPage.getComponentTags().then(function (text) {
                        if (val == text) {
                            status = 'Off';
                            adapterName = "dummy";
                        }
                        expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe(status);              
                    });
                });
				
                //Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				snowPage.getTextCMDBShellCIName();
				expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
				snowPage.getTextCMDBShellCIAssignmentGroup();
				expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
				expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
				expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.awsProviderAccountID);
				expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.awsProviderAccount);
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();	

				//Change Task Page Validations 
				snowPage.openRelatedChangeRequest();
				snowPage.clickProvTaskLink();
				expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
				expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
				expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
				expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
				expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
				snowPage.clickClosureInfoInChangeTask();
				expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
				snowPage.clickBackButton();


				//Validation on Catalog Task page after completion
				snowPage.clickBackButton();
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				
				});		
            });
		});
		
		if(runSnowDiscovery == "true") {
			it('AWS EC2 ---- Run Discovery for AWS after Turn OFF and verify the state of VM in SNOW', function () {
				snowPage.openDiscoverySchedulesQS();
				snowPage.runDiscoveryForAWS();
				expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
				snowPage.clickRequestedItemLink();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
				expect(snowPage.isPresentVMInstanceInCI()).toBe(true);
				snowPage.clickVMInstanceInCILink();
				expect(snowPage.getTextVMInstanceState()).toBe(snowInstanceTemplate.instanceStateOff);			
			});
		};
		
		it('AWS EC2 ---- Verify Turn ON functionality with Auto Technical, Financial, Legal approval and Standard change', function () {

            //Place order for Turn ON in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
			orderObject.componentType = awsEC2template.componentType;
            orderObject.servicename = serviceName;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                util.scrollToTop();
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickTurnONButtonOfInstance().then(function () {
                        inventoryPage.clickOkForInstanceTurnONPermission();
                    });
                });
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();
			 	
                //Validation in Marketplace after auto approval
	            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(awsEC2template.orderTypeAction);
				expect(placeOrderPage.getServiceNameOfferingText()).toBe(awsEC2template.serviceOfferingTurnOn);
				
				//Validations on SNOW Request page after auto approval
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.waitUntilApprovalIsApprovedQS();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

				expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
				var reqNumber = snowPage.getTextRequestNumberInRequestPage();
				expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

				expect(snowPage.getTextShortDescription()).toBe(awsEC2template.serviceOfferingTurnOn);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
				
				//Validations on SNOW Requested Item page
				snowPage.clickRequestedItemLink();

				expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
				var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
				expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
				expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextChangeReqNumber()).not.toBe("");
				var changeRequestNumber = snowPage.getTextChangeReqNumber();
				expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
				var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.serviceOfferingTurnOn);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescOn);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingOn);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
				
				expect(snowPage.getTextReqItemVariableConCategory()).toBe("");
				expect(snowPage.getTextMCMPVersionRITMVariable()).toBe('');
				expect(snowPage.getTextLabelsRITMVariable()).toBe("");
				expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
				
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("start");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalNA);
						
				//Validation on Catalog Task page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.clickCatalogTaskLink();

				expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
				expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
				expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();
				
				//Change Request Short Desc and Desc
				expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescTurnOnOrder);
				
				//Order Completion in SNOW
				snowPage.checkIfProvisioningTaskClosed();
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);
				inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
                });
				
                //Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);	
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				snowPage.getTextCMDBShellCIName();
				expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
				snowPage.getTextCMDBShellCIAssignmentGroup();
				expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
				expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
				expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.awsProviderAccountID);
				expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.awsProviderAccount);
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();	

				//Change Task Page Validations 
				snowPage.openRelatedChangeRequest();
				snowPage.clickProvTaskLink();
				expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
				expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
				expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
				expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
				expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
				snowPage.clickClosureInfoInChangeTask();
				expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
				snowPage.clickBackButton();

				//Validation on Catalog Task page after completion
				snowPage.clickBackButton();
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				});		
            });
		});
		
		if(runSnowDiscovery == "true") {
			it('AWS EC2 ---- Run Discovery for AWS after Turn ON and verify the state of VM in SNOW', function () {
				snowPage.openDiscoverySchedulesQS();
				snowPage.runDiscoveryForAWS();
				expect(snowPage.getTextDiscoveryState()).toBe(snowInstanceTemplate.discoveryStateComp);
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(provOrder);
				snowPage.clickRequestedItemLink();
				snowPage.openConfItemServiceInstanceCIs();
				expect(snowPage.getTextIfResourceMappingIsChecked()).toBe(snowInstanceTemplate.resourceMappingChecked);
				expect(snowPage.isPresentVMInstanceInCI()).toBe(true);
				snowPage.clickVMInstanceInCILink();
				expect(snowPage.getTextVMInstanceState()).toBe(snowInstanceTemplate.instanceStateOn);			
			});
		};
		
		it('AWS EC2 ---- Verify Reboot functionality with Auto Technical, Financial, Legal approval and Standard change', function () {

            //Place order for Reboot in Marketplace 
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			var orderObject = {};
			orderObject.componentType = awsEC2template.componentType;
            orderObject.servicename = serviceName;
            inventoryPage.open();
            inventoryPage.searchOrderByServiceName(orderObject.servicename);
            inventoryPage.clickExpandFirstRow().then(function () {
                util.scrollToTop();
                inventoryPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function () {
                    inventoryPage.clickRebootButtonOfInstance().then(function () {
                        inventoryPage.clickOkForInstanceRebootPermission();
                    });
                });
            }).then(function () {
                expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(awsEC2template.orderSubmittedConfirmationMessage);
                orderObject.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                orderObject.submittedBy = placeOrderPage.getTextSubmittedByOrderSubmittedModal();
                sampleOrder1 = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
                inventoryPage.clickOkForCustomOpnOrderButton();         
		
                //Validation in Marketplace after auto approval
	            expect(orderFlowUtil.verifyOrderTypeCustomOps(orderObject)).toBe(awsEC2template.orderTypeAction);
				expect(placeOrderPage.getServiceNameOfferingText()).toBe(awsEC2template.serviceOfferingReboot);
				
				//Validations on SNOW Request page after auto approval
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.waitUntilApprovalIsApprovedQS();
				expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

				expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
				var reqNumber = snowPage.getTextRequestNumberInRequestPage();
				expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

				expect(snowPage.getTextShortDescription()).toBe(awsEC2template.serviceOfferingReboot);
				expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDay2Ops);		
				expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
				expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
				
				//Validations on SNOW Requested Item page
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				snowPage.clickRequestedItemLink();

				expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
				var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
				expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
				expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextChangeReqNumber()).not.toBe("");
				var changeRequestNumber = snowPage.getTextChangeReqNumber();
				expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
				var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

				expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.serviceOfferingReboot);
				expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariablesSerOfferDescReboot);
				expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);
				expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferingReboot);
				expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
				
				expect(snowPage.getTextReqItemVariableConCategory()).toBe("");
				expect(snowPage.getTextMCMPVersionRITMVariable()).toBe('');
				expect(snowPage.getTextLabelsRITMVariable()).toBe("");
				expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
				
				var serName = snowPage.getTextReqItemVariableServiceName();
				serName.then(function(sName){
				expect(sName).toContain(serviceName);
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("resourceName")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("operationName")).toEqual("reboot");
				expect(snowPage.getTextReqItemConfigValuesBasedOnName("Requested For")).toEqual(snowInstanceTemplate.consumeUser);
				
				// Validate BOM values from Broker config values
				expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

				expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, "")).toBe(snowInstanceTemplate.snowreqItemBOMtotalNA);
			
				//Validation on Catalog Task page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.clickCatalogTaskLink();

				expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
				expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
				expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
				snowPage.clickBackButton();
				
				//Standard change
				snowPage.openRelatedChangeRequest();

				//Change Request Short Desc and Desc
				expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemDay2Ops);
				expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescRebootOrder);
						
				//Order Completion in SNOW
				snowPage.checkIfProvisioningTaskClosed();
				
				//Validation in Marketplace
				browser.get(consumeLaunchpadUrl);
				cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
				expect(orderFlowUtil.verifyOrderStatus(orderObject)).toBe(awsEC2template.completedState);
				inventoryPage.open();
                inventoryPage.searchOrderByServiceName(orderObject.servicename);
                inventoryPage.clickExpandFirstRow().then(function () {
                    expect(orderFlowUtil.verifyInstancePowerStateStatus(orderObject)).toBe('On');
                });
				
                //Validations on SNOW Request page after Completion
				snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
				expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
				expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
				expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
				
				//Validations on SNOW RITM page after Completion
				snowPage.clickRequestedItemLink();
				expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				
				//Validations on SNOW Configuration Item- Service Instance CIs page
				snowPage.switchToDefaultContent();
				snowPage.switchToParentFrame();
				snowPage.openConfItemServiceInstanceCIs();
				snowPage.getTextCMDBShellCIName();
				expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
				expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
				snowPage.getTextCMDBShellCIAssignmentGroup();
				expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.cmdbShellCIOperationalStatus);
				expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
				expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.awsProviderAccountID);
				expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.awsProviderAccount);
				expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
				expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
				expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusInstalled);
				snowPage.clickUpdateButton();	

				//Change Task Page Validations 
				snowPage.openRelatedChangeRequest();
				snowPage.clickProvTaskLink();
				expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
				expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
				expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
				expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
				expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
				expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
				expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
				snowPage.clickClosureInfoInChangeTask();
				expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
				snowPage.clickBackButton();

				//Validation on Catalog Task page after completion
				snowPage.clickBackButton();
				snowPage.clickCatalogTaskLink();
				expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
				snowPage.clickUpdateButton();
				
				});		
            });
		});
		
	
		it('AWS EC2 ---- Verify Delete functionality with Auto Technical, Financial, Legal approval and Standard change', function () {
		
			//Place Order for Delete in Marketplace
			var orderObject = {};
			orderObject.servicename = serviceName;
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			orderObject.deleteOrderNumber = orderFlowUtil.deleteService(orderObject);
			sampleOrder1 = inventoryPage.getDeleteOrderNumber();
			
			//Validation in Marketplace after auto approval
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(awsEC2template.provInProgressState);
			expect(orderFlowUtil.verifyOrderTypeDeletedOrder(orderObject)).toBe(awsEC2template.orderTypeDel);
			
			//Validations on SNOW Request page after auto approval
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			snowPage.waitUntilApprovalIsApprovedQS();
			expect(snowPage.isCheckedRequestApprovalHold()).toBe(false);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestStageFulfilled);

			expect(snowPage.getTextRequestNumberInRequestPage()).not.toBe("");
			var reqNumber = snowPage.getTextRequestNumberInRequestPage();
			expect(snowPage.getTextRequestedForInRequestPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);

			expect(snowPage.getTextShortDescription()).toBe(awsEC2template.bluePrintName);
			expect(snowPage.getBrokerRequestTypeText()).toBe(snowInstanceTemplate.snowBrokerRequestDelete);		
			expect(snowPage.getOrderNumberText()).toBe(sampleOrder1);
			expect(snowPage.getTextCloudBrokerLocation()).not.toBe("");
						
			//Validations on SNOW Requested Item page
			snowPage.clickRequestedItemLink();

			expect(snowPage.getTextRITMNumberInRITMPage()).not.toBe("");
			var ritmNumber = snowPage.getTextRITMNumberInRITMPage();
			expect(snowPage.getTextRequestNumberInRITMPage()).toBe(reqNumber);
			expect(snowPage.getTextRequestedForInRITMPage()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextChangeReqNumber()).not.toBe("");
			var changeRequestNumber = snowPage.getTextChangeReqNumber();
			expect(snowPage.getTextShellCIInRITMPage()).not.toBe("");
			var cmdbShellCIName = snowPage.getTextShellCIInRITMPage();

			expect(snowPage.getTextRequestedItem()).toBe(snowInstanceTemplate.snowRequestedItemDelete);
			expect(snowPage.getTextRequestedItemStage()).toBe(snowInstanceTemplate.snowRequestedItemStage);
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			expect(snowPage.getTextRequestedItemShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextReqItemVariableSerOfferName()).toBe(awsEC2template.bluePrintName);
			expect(snowPage.getTextReqItemVariableSerOfferDesc()).toBe(snowInstanceTemplate.snowReqItemVariableSerOfferDescAWS);
			expect(snowPage.getTextReqItemVariableChangeType()).toBe(snowInstanceTemplate.snowReqItemVariableChangeTypeStd);

			expect(snowPage.getTextReqItemVariableSerOfferingID()).toBe(snowInstanceTemplate.serviceOfferingIDEC2);

			expect(snowPage.getTextReqItemVariableSOProvider()).toBe(snowInstanceTemplate.snowReqItemVariableSOProviderAWS);
			expect(snowPage.getTextReqItemVariableConCategory()).toBe(snowInstanceTemplate.snowReqItemVariableConCategoryComp);
			
			expect(snowPage.getTextMCMPVersionRITMVariable()).toBe(snowInstanceTemplate.mcmpVersion);
			expect(snowPage.getTextLabelsRITMVariable()).toBe("");
			expect(snowPage.getTextChangeRequiredRITMVariable()).toBe("false");
			
			var serName = snowPage.getTextReqItemVariableServiceName();
			serName.then(function(sName){
			expect(sName).toContain(serviceName);

			expect(snowPage.getTextReqItemConfigValuesBasedOnName("AWS Region")).toEqual("us-east-1");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("resource Name")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Resource Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Family")).toEqual(jsonUtil.getValue(awsEC2obj, "Instance Family"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("instance Type")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Instance Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("search By")).toEqual(jsonUtil.getValue(awsEC2obj,"Search By"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("self Image")).toContain("ami");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("availability Zone")).toEqual(jsonUtil.getValue(awsEC2obj,"Availability Zone"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("VPC Creation Mode")).toEqual(jsonUtil.getValue(awsEC2obj,"VPC Creation Mode"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnNameAz("Subnet")).toEqual("subnet-a68b538d");
			expect(snowPage.getTextReqItemConfigValuesBasedOnNameAzII("VPC")).toEqual("vpc-8eadd1eb");
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("shutdown Behavior")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Shutdown Behavior"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("enable Termination Protection")).toEqual(jsonUtil.getValue(awsEC2obj, "Enable Termination Protection"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("unlimited Instance Type")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Unlimited Instance Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("user Data")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "User Data"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Assign a security group")).toEqual(jsonUtil.getValue(awsEC2obj,"Assign a security group"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("device Name")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Device Name"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("volume Size")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Volume Size"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("volume Type")).toEqual(jsonUtil.getValueEditParameter(awsEC2obj, "Volume Type"));
			expect(snowPage.getTextReqItemConfigValuesBasedOnName("Key Pair")).toEqual(jsonUtil.getValue(awsEC2obj, "Key Pair"));			
		
			// Validate BOM values from Broker config values
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2Edit1)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2Edit2)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);
			expect(snowPage.getTextReqItemBOMCurrencyBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2Edit3)).toBe(snowInstanceTemplate.snowReqItemBOMcurrency);

			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2Edit1)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWSEC2Del1);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2Edit2)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWSEC2Del2);
			expect(snowPage.getTextReqItemBOMTotalBasedServiceName(sName, snowInstanceTemplate.snowAWSSrvcItemValueEC2Edit3)).toBe(snowInstanceTemplate.snowreqItemBOMtotalAWSEC2Del3);
			
			//Validation on Catalog Task page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.clickCatalogTaskLink();
			
			expect(snowPage.getTextCatalogTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInCatalogTaskPage()).toBe(cmdbShellCIName);
			expect(snowPage.getTextRITMNumberInCatalogTaskPage()).toBe(ritmNumber);
			expect(snowPage.getTextCatalogTaskShortDec()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextCatalogTaskAssignmentGroup()).not.toBe("");

			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestedItemState);
			snowPage.clickBackButton();
			
			//Standard change
			snowPage.openRelatedChangeRequest();
			
			//Change Request Short Desc and Desc
			expect(snowPage.getTextChangeReqShortDesc()).toBe(snowInstanceTemplate.snowRequestedItemShortDescDelete);
			expect(snowPage.getTextChangeReqDesc()).toContain(snowInstanceTemplate.changeReqDescDeleteOrder);
			
			//Order Completion in SNOW
			snowPage.checkIfProvisioningTaskClosed();
			
			//Validation in Marketplace
			browser.get(consumeLaunchpadUrl);
			cartListPage.loginFromUserSNOW(snowInstanceTemplate.consumeUser,snowInstanceTemplate.consumeUserPwd);
			expect(orderFlowUtil.verifyOrderStatusDeletedOrder(orderObject)).toBe(awsEC2template.completedState);
			
			//Validations on SNOW Request page after Completion
			snowPage.logInToSnowQuickstartPortalAndSearchOrder(sampleOrder1);
			expect(snowPage.getApprovalControllerText()).toBe(snowInstanceTemplate.snowRequestExternalApproval);
			expect(snowPage.getTextApprovalStateQS()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getRequestedStateText()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			expect(snowPage.getTextExternalApproval()).toBe(snowInstanceTemplate.snowRequestApprovalStateApproved);
			expect(snowPage.getTextStage()).toBe(snowInstanceTemplate.snowRequestCompletedStateQS);
			
			//Validations on SNOW RITM and Configuration Item- Service Instance CIs page after Completion
			snowPage.clickRequestedItemLink();
			expect(snowPage.getTextRequestedItemState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			
			//Validations on SNOW Configuration Item- Service Instance CIs page
			snowPage.switchToDefaultContent();
			snowPage.switchToParentFrame();
			snowPage.openConfItemServiceInstanceCIs();
			snowPage.getTextCMDBShellCIName();
			expect(snowPage.getTextCMDBShellCIAssignedTo()).toBe(snowInstanceTemplate.snowQSReqItemReqFor);
			expect(snowPage.getTextCMDBShellCIInstanceID()).toContain(serviceName);
			snowPage.getTextCMDBShellCIAssignmentGroup();
			expect(snowPage.getTextCMDBShellCIOperationalStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			expect(snowPage.getTextCMDBShellCICorrelationID()).not.toBe("");
			expect(snowPage.getTextCMDBShellCIAccountID()).toBe(snowInstanceTemplate.awsProviderAccountID);
			expect(snowPage.getTextCMDBShellCIAccountName()).toBe(snowInstanceTemplate.awsProviderAccount);
			expect(snowPage.getTextSerInstanceCIsResourceId()).toBe("");
			expect(snowPage.getTextSerInstanceCIsObjectId()).not.toBe("");
			expect(snowPage.getTextSerInstanceCIsStatus()).toBe(snowInstanceTemplate.snowSerInstanceCIsStatusRetired);
			snowPage.clickUpdateButton();	

			//Change Task Page Validations 
			snowPage.openRelatedChangeRequest();
			snowPage.clickProvTaskLink();
			expect(snowPage.getTextChangeTaskNumber()).not.toBe("");
			expect(snowPage.getTextShellCIInChangeTaskPage()).toEqual(cmdbShellCIName);
			expect(snowPage.getTextChangeRequestNumberInChangeTaskPage()).toEqual(changeRequestNumber);
			expect(snowPage.getTextChangeTaskShortDesc()).toEqual(snowInstanceTemplate.provisioningChangeTaskShortDesc);
			expect(snowPage.getTextProvisioningChangeTaskReadOnlyState()).toBe(snowInstanceTemplate.provisioningChangeTaskClosedState);
			expect(snowPage.getTextAssignmentGroupChangeTask()).toBe(snowInstanceTemplate.changeTaskAssignGroup);
			expect(snowPage.getTextAssignedToChangeTask()).toBe(snowInstanceTemplate.snowQSRequestAssignedTo);
			snowPage.clickClosureInfoInChangeTask();
			expect(snowPage.getTextProvisioningSuccesfulChangeTaskMsg()).toBe(snowInstanceTemplate.provisioningChangeTaskClosureMsg);
			snowPage.clickBackButton();
			
			//Validation on Catalog Task page after completion
			snowPage.clickBackButton();
			snowPage.clickCatalogTaskLink();
			expect(snowPage.getTextCatalogTaskState()).toBe(snowInstanceTemplate.snowRequestCompletedState);
			snowPage.clickUpdateButton();
			});		
		}); 
	}
		
	
});
	
	
	
	