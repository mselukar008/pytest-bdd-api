"use strict";

/*
Spec_Name: e2eproviderAccount.spec.js
Description: This spec covers flow for creating provider account,create credetials and verify success messgae and delete account.
Author: Sarika Bothe
*/

var CatalogPage = require('../../../pageObjects/catalog.pageObject.js'),
  HomePage = require('../../../pageObjects/home.pageObject.js'),
  AccountsPage = require('../../../pageObjects/account.pageObject.js'),
  util = require('../../../../helpers/util.js'),
  appUrls = require('../../../../testData/appUrls.json'),
  serviceVersiondetail = require('../../../../testData/OrderIntegration/ICAM/ServiceGroupAndVersion.json'),
  CatalogDiscoveryPage = require('../../../pageObjects/catalogDiscovery.pageObject.js'),
  providerAcountTemplate = require('../../../../testData/OrderIntegration/ICAM/providerAccount.json');

const { browser } = require('protractor');

describe('TA -E2E Provider account scenarios....', function () {
  var catalogPage, homePage, accountsPage, catalogDiscoveryObj;

  beforeAll(function () {
    catalogPage = new CatalogPage();
    homePage = new HomePage();
    accountsPage = new AccountsPage();
    browser.driver.manage().window().maximize();
    homePage.open();
    catalogPage.clickHamburgerCatalog();
    catalogDiscoveryObj = new CatalogDiscoveryPage();
    catalogPage.clickLeftNavButtonBasedOnName(providerAcountTemplate.leftNavButtonAdmin);
    catalogPage.clickLeftNavButtonBasedOnName(providerAcountTemplate.leftNavButtonSettings);
    catalogPage.clickLeftNavButtonBasedOnName(providerAcountTemplate.leftNavButtonStore);
    catalogPage.clickHamburgerCatalog();
    browser.driver.manage().window().maximize();

  });

  beforeEach(function () {
    //catalogPage.open();
    browser.switchTo().defaultContent();
  });

  it('TA- Create Provider account and verify account created successfully...', function () {
    var providerAccountName = providerAcountTemplate.ProviderAccountName + util.getRandomString(3);
    catalogPage.clickHamburgerCatalog();
    catalogPage.checkIfleftNavAdminExpanded();
    catalogPage.clickLeftNavLinkBasedOnName(providerAcountTemplate.leftNavLinkProviderAccount);
    expect(accountsPage.getTextPageHeader()).toBe(providerAcountTemplate.accountsPageHeader);
    accountsPage.clickAssetAccountsLink();
    accountsPage.clickButtonAddAccountIcam();
    accountsPage.clickOnIcamAccount();
    accountsPage.enterProviderAccountName(providerAccountName);
    accountsPage.enterproviderAccountTeam(providerAcountTemplate.CloudPakMCMTeam);
    accountsPage.enterProviderAccountIcamEndpoint(providerAcountTemplate.ProviderAccountIcamEndpointIcam);
    accountsPage.enterproviderAccountIcpEndpoint(providerAcountTemplate.CloudPakMCMEndpointURL);
    accountsPage.enterproviderAccountTenantId(providerAcountTemplate.providerAccountTenantIdIcam);
    accountsPage.enterProviderAccountProxy(providerAcountTemplate.ProviderAccountProxyIcam);
    accountsPage.enterProviderAccountDesription(providerAcountTemplate.ProviderAccountDesription);
    accountsPage.clickOnCreateAssetAccountButton();
    expect(accountsPage.getTextSuccessAssetAccount()).toEqual(providerAcountTemplate.successNotification);
    accountsPage.clickOnAddCredentials();
    accountsPage.enterCredAccountName(providerAcountTemplate.CredAccountNameIcam);
    accountsPage.clickOnCredAccountPurpose();
    accountsPage.clickOnProvision();
    accountsPage.clickOnCatalogIngetionPurpose();
    accountsPage.enterCredAccountUserName(providerAcountTemplate.CredAccountUserName);
    accountsPage.clickCreateNewUpdateCredentialinVault(providerAcountTemplate.newCredentialRefIdName);
    accountsPage.enterCredAccountPassword(providerAcountTemplate.CredAccountPassword);
    accountsPage.clickTeamOrgCheckbox();
    accountsPage.clickChooseBusinessEntityTeam();
    accountsPage.clickSelectEntityTeam();
    accountsPage.clickTeamValues();
    accountsPage.enterTeamValueIcam(providerAcountTemplate.TeamValueIcam);
    accountsPage.clickAddCreds();
    expect(accountsPage.getTextSuccessAssetAccount()).toEqual(providerAcountTemplate.successNotification);
    accountsPage.openaccountsPage();
    expect(accountsPage.getTextPageHeader()).toBe(providerAcountTemplate.accountsPageHeader);
  });

  it('TA-Initiate catalog discovery with wrong creds provider account...', function () {
    catalogDiscoveryObj.open();
    catalogDiscoveryObj.clickOnStartCatalogDiscoveryBtn();
    catalogDiscoveryObj.clickOkImportService();
    catalogDiscoveryObj.clickOnProviderToStartDiscovery(serviceVersiondetail.serviceCategoryProviderICAM);
    expect(catalogDiscoveryObj.getMultipleAccountsDetectedText()).toMatch(serviceVersiondetail.Multipleaccountsdetected);
    catalogDiscoveryObj.selectIcamAccountFromDrpDwn(providerAcountTemplate.ProviderAccount);
    catalogDiscoveryObj.clickOnOKBtnFromDiscoveryPopup();
    expect(catalogDiscoveryObj.getDiscoveryStartedText()).toMatch(serviceVersiondetail.TADiscoveryStartedText);
    catalogDiscoveryObj.clickOnokButtonIbmDiscoverryStarted();
    catalogDiscoveryObj.open();
    catalogDiscoveryObj.clickOnProvidersToggleBtn();
    catalogDiscoveryObj.searchProviderByName(serviceVersiondetail.serviceCategoryProviderICAM);
  });

  it('TA - verify Icam Catalog discovery status and verify failure reason...', function () {
    browser.waitForAngularEnabled(false);
    catalogDiscoveryObj.open();
    catalogDiscoveryObj.waitToCompletDiscoveryStatusTA();
    catalogDiscoveryObj.clickOnICAMHistoryLink();
    expect(catalogDiscoveryObj.getcatalogDiscoveryStatusText()).toMatch(serviceVersiondetail.DiscoveryFailedStatus);    
    catalogDiscoveryObj.ClickViewDiscoveryFailure();
    expect(catalogDiscoveryObj.VerifyDiscoveryFailure()).toEqual(providerAcountTemplate.DiscoveryFailureReason);
  });

  it('TA - Delete provider account ...  ', function () {
    catalogPage.clickHamburgerCatalog();
    catalogPage.checkIfleftNavAdminExpanded();
    catalogPage.clickLeftNavLinkBasedOnName(providerAcountTemplate.leftNavLinkProviderAccount);
    expect(accountsPage.getTextPageHeader()).toBe(providerAcountTemplate.accountsPageHeader);
    accountsPage.clickAssetAccountsLink();
    accountsPage.clickThreeDotProviderAccountName();
    accountsPage.clickDeleteButton();
    accountsPage.clickDeleteConfirmButton();
    expect(accountsPage.getTextSuccessAssetAccount()).toEqual(providerAcountTemplate.successNotification);

  });

});