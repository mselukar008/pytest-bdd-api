"use strict";

var CatalogPage = require('../../pageObjects/catalog.pageObject.js'),
	HomePage = require('../../pageObjects/home.pageObject.js'),
	PlaceOrderPage = require('../../pageObjects/placeOrder.pageObject.js'),
	CartListPage = require('../../pageObjects/cartList.pageObject.js'),
	OrdersPage = require('../../pageObjects/orders.pageObject.js'),
	util = require('../../../helpers/util.js'),
	orderFlowUtil = require('../../../helpers/orderFlowUtil.js'),
	appUrls = require('../../../testData/appUrls.json'),
	mcmpUIDataTemplate = require('../../../testData/mcmp/mcmpUIData.json'),
	slShopBagTemplate = require('../../../testData/OrderIntegration/Softlayer/SoftlayerShoppingCart.json');

describe('Right nav-bar tasks menu button and tasks links:', function () {
	var catalogPage, homePage, placeOrderPage, cartListPage,ordersPage;

	var secGrpName = "gslslSecGrpshopBag" + util.getRandomString(5);
	var cartName = "AutoSLCart" + util.getRandomString(5);
	var serviceName1 = "GSLSLSecGrpShopBagnewServ" + util.getRandomString(5);
	var modifiedParamMap = { "Service Instance Name": serviceName1, "Cart Name": cartName, "Cart Service": "Click", "New Shopping Cart": "newCart", "Security Group Name": secGrpName, "UpdateMainParamObject": false };

	beforeAll(function () {
		catalogPage = new CatalogPage();
		homePage = new HomePage();
		placeOrderPage = new PlaceOrderPage();
		cartListPage = new CartListPage();
		ordersPage = new OrdersPage();
		browser.driver.manage().window().maximize();
	});

	beforeEach(function () {
		catalogPage.open();
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);

	});

	it('Verify clicking on tasks button should open right nav-bar and closing nav-bar', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonAdmin,mcmpUIDataTemplate.rightNavButtonConsumption);
		expect(catalogPage.isRightNavBarOpened()).toBe(true);
		expect(catalogPage.getTasksHeaderName()).toBe(mcmpUIDataTemplate.tasksHeaderName);
		catalogPage.clickCloseTasksMenuButton();
		expect(catalogPage.isRightNavBarClosed()).toBe(true);
	});

	it('Verify clicking on Manage budget link navigates to Budget Management page', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonAdmin);
		catalogPage.clickRightNavButtonBasedOnName(mcmpUIDataTemplate.rightNavButtonAdmin);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkManageBudget);
		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.budgetPageHeader);
		expect(util.getCurrentURL()).toMatch(appUrls.budgetaryUrl);
	});

	it('Verify clicking on Manage user access link navigates to User Access Management page', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonAdmin);
		//catalogPage.clickRightNavButtonBasedOnName(mcmpUIDataTemplate.rightNavButtonAdmin);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkManageUserAccess);
		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.userAccessPageHeader);
		expect(util.getCurrentURL()).toMatch(appUrls.adminUrl);
	});

	it('Verify clicking on Manage provider accounts link navigates to Account Management page', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonAdmin);
		//catalogPage.clickRightNavButtonBasedOnName(mcmpUIDataTemplate.rightNavButtonAdmin);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkManageProviderAccounts);
		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.accountsPageHeader);
		expect(util.getCurrentURL()).toMatch(appUrls.accountsUrl);
	});

	it('Verify clicking on Manage currency conversion link navigates to Currency Conversion page', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonAdmin);
		//catalogPage.clickRightNavButtonBasedOnName(mcmpUIDataTemplate.rightNavButtonAdmin);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkManageCurrencyConversion);
		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.currencyPageHeader);
		expect(util.getCurrentURL()).toMatch(appUrls.currencyUrl);
	});

	it('Verify clicking on View audit logs link navigates to Audits page', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonAdmin);
		//catalogPage.clickRightNavButtonBasedOnName(mcmpUIDataTemplate.rightNavButtonAdmin);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkViewAuditLogs);
		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.auditPageHeader);
		expect(util.getCurrentURL()).toMatch(appUrls.auditUrl);
	});

	it('Verify clicking on Archive audit logs link navigates to Audits page', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonAdmin);
		//catalogPage.clickRightNavButtonBasedOnName(mcmpUIDataTemplate.rightNavButtonAdmin);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkArchiveAuditLogs);
		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.auditPageHeader);
		expect(util.getCurrentURL()).toMatch(appUrls.auditUrl);
	});

	it('Verify clicking on Order new services link navigates to Catalog page', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonConsumption);
		catalogPage.clickRightNavButtonBasedOnName(mcmpUIDataTemplate.rightNavButtonConsumption);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkOrderNewServices);
		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		homePage.switchToFrame();
		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.catalogPageHeader);
	});

	it('Verify clicking on Review current cart link navigates to Cart-list page', function () {
		var orderObj = {};
		var secgrpObj = JSON.parse(JSON.stringify(slShopBagTemplate.secgrp));
		catalogPage.open();
		catalogPage.clickProviderOrCategoryCheckbox(secgrpObj.providerName);
		catalogPage.clickProviderOrCategoryCheckbox(secgrpObj.Category);
		catalogPage.clickConfigureButtonBasedOnName(secgrpObj.bluePrintName);
		orderObj.servicename = serviceName1;
		orderFlowUtil.fillOrderDetails(secgrpObj, modifiedParamMap);
		placeOrderPage.addToShoppingCart();
		expect(cartListPage.isPresentSuccessfullyAddedToCart()).toBe(true);
		catalogPage.open();
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonConsumption);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkReviewCurrentCart);
		homePage.switchToFrame();
		expect(util.getCurrentURL()).toMatch(appUrls.currentCartListUrl);
		expect(cartListPage.getCartHeaderName()).toBe(mcmpUIDataTemplate.cartPageHeader);
		cartListPage.clickMenuIcon(0);
		//Delete the cart.
		cartListPage.deleteCart(0);
		catalogPage.open();

	});

	it('Verify clicking on View inventory link navigates to Service Inventory page', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonConsumption);
		//catalogPage.clickRightNavButtonBasedOnName(mcmpUIDataTemplate.rightNavButtonConsumption);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkViewInventory, mcmpUIDataTemplate.rightNavLinkViewInventoryInsight);
		expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
		homePage.switchToFrame();
		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.inventoryPageHeader);
	});

	it('Verify clicking on Review pending orders link navigates to Orders page', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonConsumption);
		//catalogPage.clickRightNavButtonBasedOnName(mcmpUIDataTemplate.rightNavButtonConsumption);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkReviewPendingOrders);
		expect(util.getCurrentURL()).toMatch(appUrls.approveOrdersUrl);
		homePage.switchToFrame();
		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.ordersPageHeader);
	});

	it('Verify clicking on Manage catalog link navigates to Catalog Admin page', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonConsumption);
		//catalogPage.clickRightNavButtonBasedOnName(mcmpUIDataTemplate.rightNavButtonConsumption);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkManageCatalog);
		expect(util.getCurrentURL()).toMatch(appUrls.catalogAdminUrl);
		homePage.switchToFrame();
		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.catalogAdminPageHeader);
	});

	it('Verify clicking on Manage approval policies link navigates to Approval Policies page', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonConsumption);
		//catalogPage.clickRightNavButtonBasedOnName(mcmpUIDataTemplate.rightNavButtonConsumption);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkManageApprovalPolicies);
		expect(util.getCurrentURL()).toMatch(appUrls.policyApprovalUrl);
		homePage.switchToFrame();
		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.approvalPolicyPageHeader);
	});

	it('Verify clicking on Track order status link navigates to Order History page', function () {
		catalogPage.clickTasksMenuButton(mcmpUIDataTemplate.rightNavButtonConsumption);
		//catalogPage.clickRightNavButtonBasedOnName(mcmpUIDataTemplate.rightNavButtonConsumption);
		catalogPage.clickRightNavLinkBasedOnName(mcmpUIDataTemplate.rightNavLinkTrackOrderStatus);
		expect(util.getCurrentURL()).toMatch(appUrls.ordersPageUrl);
		homePage.switchToFrame();
		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.orderHistoryPageHeader);
	});


	// help link item Automation for IBM Knowledge Center pages
	it('Verify clicking on Catalog link navigates to IBM Knowledge Center page', function () {
		catalogPage.clickOnHelpButton();
		catalogPage.clickHelpLinkBasedOnName(mcmpUIDataTemplate.rightNavButtonCatlog);
		catalogPage.navigateToNewTab().then(function (parentGUID) {
			//expect(util.getCurrentURL()).toMatch(appUrls.catalogMgmtPageUrl);
			//expect(catalogPage.getHelpCatalogItemsPageHeader(mcmpUIDataTemplate.headerCalatogID)).toBe(mcmpUIDataTemplate.catalogMgmtPageHeader);
			catalogPage.closeCurrentTabNavigateToParentTab(parentGUID);
		});
	});

	it('Verify clicking on Enterprise Marketplace link navigates to IBM Knowledge Center page', function () {
		catalogPage.clickOnHelpButton();
		catalogPage.clickHelpLinkBasedOnName(mcmpUIDataTemplate.rightNavEnterprizeMarket);
		catalogPage.navigateToNewTab().then(function (parentGUID) {
			//expect(util.getCurrentURL()).toMatch(appUrls.enterpriseMarketPageURL);
			//expect(catalogPage.getHelpItemsPageHeader()).toBe(mcmpUIDataTemplate.enterpriseMarketPageHeader);
			catalogPage.closeCurrentTabNavigateToParentTab(parentGUID);
		});
	});

	it('Verify clicking on Multicloud Management Platform link navigates to IBM Knowledge Center page', function () {
		catalogPage.clickOnHelpButton();
		catalogPage.clickHelpLinkBasedOnName(mcmpUIDataTemplate.rightNavMulticloudMgmtPlatform);
		catalogPage.navigateToNewTab().then(function (parentGUID) {
			//expect(util.getCurrentURL()).toMatch(appUrls.muticloudManagementPlatformURL);
			//expect(catalogPage.getHelpItemsPageHeader()).toBe(mcmpUIDataTemplate.multicloudMgmtPlatformPageHeader);
			catalogPage.closeCurrentTabNavigateToParentTab(parentGUID);
		});
	});

	it("Verify Common tasks Header's Tab Name Text on MCMP Launcpad",function(){
		homePage.open();
		homePage.clickOnShowMoreLink();
		 homePage.getMcmpHeadersTabText().then(function(McmpHearderList){
			 expect(McmpHearderList[0]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkManageUserAccess);
			 expect(McmpHearderList[1]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkManageProviderAccounts);
			 expect(McmpHearderList[2]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkManageProvider);
			 expect(McmpHearderList[3]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkManageCurrencyConversion);
			 expect(McmpHearderList[4]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkViewAuditLogs);
			 expect(McmpHearderList[5]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkArchiveAuditLogs);
			 expect(McmpHearderList[6]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkManageBudget);
			 expect(McmpHearderList[7]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkOrderNewServices);
			 expect(McmpHearderList[8]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkReviewCurrentCart);
			 expect(McmpHearderList[9]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkTrackOrderStatus);
			 expect(McmpHearderList[10]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkViewInventory);
			 expect(McmpHearderList[11]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkReviewPendingOrders);
			 expect(McmpHearderList[12]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkManageCatalog);
			 expect(McmpHearderList[13]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkManageApprovalPolicies);
			 expect(McmpHearderList[14]).toEqual(mcmpUIDataTemplate.launchpadHeaderLinkManageOperationPolicies);
		 })
		
		
	});
});