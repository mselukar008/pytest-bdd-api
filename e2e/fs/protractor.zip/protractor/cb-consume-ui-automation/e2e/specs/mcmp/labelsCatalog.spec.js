"use strict";

var CatalogPage            = require('../../pageObjects/catalog.pageObject.js'),
	CatalogDetailsPage     = require('../../pageObjects/catalogdetails.pageObject.js'),
	util                   = require('../../../helpers/util.js'),
	appUrls                = require('../../../testData/appUrls.json'),
	mcmpUIDataTemplate     = require('../../../testData/mcmp/mcmpUIData.json');	
    
describe('Test cases for Labels in Catalog page', function() {
	var catalogPage, catalogDetailsPage, homePage, accountsPage;
	
	beforeAll(function() {
    	catalogPage = new CatalogPage();
    	catalogDetailsPage = new CatalogDetailsPage();
        browser.driver.manage().window().maximize();
    });
    
  	beforeEach(function() {
    	catalogPage.open();
    	expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
    });
  	
  	it('Verify labels section is available in Catalog page', function(){
  		expect(catalogPage.getTextLabelsHeader()).toBe(mcmpUIDataTemplate.labelsHeader);
  		expect(catalogPage.getTextLabelsDropdown()).toBe(mcmpUIDataTemplate.labelsDropdownText);
  	});
  	
   	it('Verify count of labels dropdown options before and after clicking Load More', function(){
  		catalogPage.clickLabelsDropdown();
		var labelCount = catalogPage.getTextLabelsDropdownOptionsCount()
		expect(labelCount).toBeGreaterThan(0)
		if (labelCount >= 0){
			catalogPage.clickLoadMoreLabelsLinkIfPresent();
			expect(catalogPage.getTextLabelsDropdownOptionsCount()).toBeGreaterThanOrEqual(9)

		}
		catalogPage.clickLabelsDropdown()
	});
  	
  	it('Verify on selecting a single label displays the labelled templates only', function(){
  		catalogPage.clickLabelsBasedOnName(mcmpUIDataTemplate.labelVra);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.label3Tier);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelXaaS);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelIaaS81Windows);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelCentOS);
  		catalogPage.clickCloseLabelsIcon();
  		catalogPage.clickLabelsDropdown();
  	});
  	
  	it('Verify on selecting two labels display the labelled templates only', function(){
  		catalogPage.clickLabelsBasedOnName(mcmpUIDataTemplate.labelVraIaaSC);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.label3Tier);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelXaaS);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelIaaS81Windows);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelCentOS);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelIaaS81VM);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelIaaS82VM);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelIaaS82CentOS);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelIaaS82Windows);
  		catalogPage.clickCloseLabelsIcon();
  		catalogPage.clickLabelsDropdown();
  	});
  	
  	it('Verify the count of labels selected', function(){
  		catalogPage.clickLabelsBasedOnName(mcmpUIDataTemplate.labelVraIaaSC);
  		expect(catalogPage.getTextLabelsSelectedCount()).toBe(mcmpUIDataTemplate.labelsSelectedCount);
  		catalogPage.clickCloseLabelsIcon();
  		catalogPage.clickLabelsDropdown();
  	});
  	
  	it('Verify searching and selecting a label', function(){
  		catalogPage.clickLabelsDropdown();
  		catalogPage.searchLabelText(mcmpUIDataTemplate.labelVra);
  		catalogPage.selectOptionsFromLabelsDropdown(mcmpUIDataTemplate.labelVra);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.label3Tier);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelXaaS);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelIaaS81Windows);
  		expect(catalogPage.getAllBluePrintHeaderName()).toContain(mcmpUIDataTemplate.labelCentOS);
  		catalogPage.clickCloseLabelsIcon();
  		catalogPage.clickLabelsDropdown(); 		
  	});
  	
  	it('Verify on Catalog Details if label is displayed for XaaS_CentOS VRA82 service', function(){
  		catalogPage.clickLabelsBasedOnName(mcmpUIDataTemplate.labelVra);
  		catalogPage.clickDetailsButtonBasedOnName(mcmpUIDataTemplate.labelXaaSBPname);
  		expect(catalogDetailsPage.getTextServiceLabel()).toContain(mcmpUIDataTemplate.labelVra);
  	});
  	
  	it('Verify on Catalog Details if labels are displayed for [IaaSC-8.1] Composite VMs - VM service', function(){
  		catalogPage.clickLabelsBasedOnName(mcmpUIDataTemplate.labelVraIaaSC);
  		catalogPage.clickDetailsButtonBasedOnName(mcmpUIDataTemplate.labelCompositeVMBPname);
  		expect(catalogDetailsPage.getTextServiceLabel()).toContain(mcmpUIDataTemplate.labelVra);
  		expect(catalogDetailsPage.getTextServiceLabel()).toContain(mcmpUIDataTemplate.labelIaaSC);
  	});
  	
});