"use strict";

var CatalogPage            = require('../../pageObjects/catalog.pageObject.js'),
	HomePage               = require('../../pageObjects/home.pageObject.js'),
	AccountsPage           = require('../../pageObjects/account.pageObject.js'),
	util                   = require('../../../helpers/util.js'),
	appUrls                = require('../../../testData/appUrls.json'),
	mcmpUIDataTemplate     = require('../../../testData/mcmp/mcmpUIData.json');	
    
describe('Test cases for hamburger and left navigation links', function() {
	var catalogPage, homePage, accountsPage;
	
	beforeAll(function() {
    	catalogPage = new CatalogPage();
    	homePage = new HomePage();
    	accountsPage = new AccountsPage();
        browser.driver.manage().window().maximize();
	//Commenting below lines as fix is added at function level
        // homePage.open();
        // catalogPage.clickHamburgerCatalog();
        // catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonAdmin);
        // catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonSettings);
        // catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
        // catalogPage.clickHamburgerCatalog();
    });
    
  	beforeEach(function() {    	
		homePage.open();
		browser.switchTo().defaultContent();
		//expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
		catalogPage.clickHamburgerCatalog();
    });
  	
  	it('Verify clicking on hamburger button should open left navigation bar', function(){
  		expect(catalogPage.checkLeftNavBarOpened()).toContain(mcmpUIDataTemplate.leftNavBarClass);
  		catalogPage.clickHamburgerCatalog();
  	});
  	
  	it('Verify clicking on pin button should keep the left navigation bar open', function(){
  		catalogPage.clickPinLeftNavBar();
  		expect(catalogPage.checkLeftNavBarOpened()).toContain(mcmpUIDataTemplate.leftNavBarPinnedClass);
  		catalogPage.clickHamburgerCatalog();
  	});
  	
  	it('Verify clicking on arrow button should close the left navigation bar', function(){
  		catalogPage.clickPinLeftNavBar();
  		catalogPage.clickArrowLeftNavBar();
  		expect(catalogPage.checkLeftNavBarOpened()).toContain(mcmpUIDataTemplate.leftNavBarArrowClass);
  	});
  	
  	it('Verify clicking on Portal link navigates to launchpad', function(){
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkPortal);
  		expect(util.getCurrentURL()).toMatch(appUrls.launchpadUrl);
  		expect(homePage.getTextHeaderUser()).toContain(mcmpUIDataTemplate.launchpadHeader);
  	});
  	
  	it('Verify clicking on User Access link navigates to admin page', function(){
  		catalogPage.checkIfleftNavAdminExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkUserAccess);
  		expect(util.getCurrentURL()).toMatch(appUrls.adminUrl);	
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.userAccessPageHeader);
  	});
  	
  	it('Verify clicking on Context Type link navigates to contexttypes page', function(){
  		catalogPage.checkIfleftNavAdminExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkContexttype);
  		expect(util.getCurrentURL()).toMatch(appUrls.adminUrl);	
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.leftNavLinkContexttype);
  	});
  	
  	it('Verify clicking on Provider Account link navigates to accounts page', function(){
  		catalogPage.checkIfleftNavAdminExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkProviderAccount);
  		expect(util.getCurrentURL()).toMatch(appUrls.accountsUrl);	
  		expect(accountsPage.getTextPageHeader()).toBe(mcmpUIDataTemplate.accountsPageHeader);
  	});
  	
  	it('Verify clicking on Budget link navigates to budget page', function(){
  		catalogPage.checkIfleftNavAdminExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkBudget);
  		expect(util.getCurrentURL()).toMatch(appUrls.budgetaryUrl);
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.budgetPageHeader);
  	});
  	
  	it('Verify clicking on Currency Conversion link navigates to currency page', function(){
  		catalogPage.checkIfleftNavAdminExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkCurrency);
  		expect(util.getCurrentURL()).toMatch(appUrls.currencyUrl);
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.currencyPageHeader);
  	});
  	
  	it('Verify clicking on Audit Log link navigates to audit page', function(){
  		catalogPage.checkIfleftNavAdminExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkAuditLog);
  		expect(util.getCurrentURL()).toMatch(appUrls.auditUrl);
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.auditPageHeader);
  	});
  	
  	it('Verify clicking on Portal Settings link navigates to settings page', function(){
  		catalogPage.checkIfleftNavAdminExpanded();
  		catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonSettings);
  		catalogPage.checkIfleftNavSettingsExpanded();
  		catalogPage.clickLeftNavAdminPortalLink();
  		expect(util.getCurrentURL()).toMatch(appUrls.settingsUrl);
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.portalSettingsPageHeader);
  	});
  	
  	it('Verify clicking on System link navigates to customization page', function(){
  		catalogPage.checkIfleftNavAdminExpanded();
  		catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonSettings);
  		catalogPage.checkIfleftNavSettingsExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkSystem);
  		expect(util.getCurrentURL()).toMatch(appUrls.systemUrl);
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.systemSettingsPageHeader);
  	});
  	
  	it('Verify clicking on Approve Orders link navigates to approver page', function(){
  		catalogPage.checkIfleftNavStoreExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkApproveOrders);
  		expect(util.getCurrentURL()).toMatch(appUrls.approveOrdersUrl);
  		homePage.switchToFrame();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.ordersPageHeader);
  	});
  	
  	it('Verify clicking on Order History link navigates to my-orders page', function(){
  		catalogPage.checkIfleftNavStoreExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkOrderHistory);
  		expect(util.getCurrentURL()).toMatch(appUrls.ordersPageUrl);
  		homePage.switchToFrame();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.orderHistoryPageHeader);
  	});
  	
  	it('Verify clicking on Catalog link navigates to main page', function(){
  		catalogPage.checkIfleftNavStoreExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkCatalog);
  		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
  		homePage.switchToFrame();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.catalogPageHeader);
  	});
  	
  	it('Verify clicking on Inventory link navigates to inventory page', function(){
  		catalogPage.checkIfleftNavStoreExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkInventory);
  		expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
  		homePage.switchToFrame();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.inventoryPageHeader);
  	});
  	
  	it('Verify clicking on Catalog Admin link navigates to catalogAdmin page', function(){
  		catalogPage.checkIfleftNavStoreExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkCatalogAdmin);
  		expect(util.getCurrentURL()).toMatch(appUrls.catalogAdminUrl);
  		homePage.switchToFrame();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.catalogAdminPageHeader);
  	});
  	
  	it('Verify clicking on Policy Approvals link navigates to policies page', function(){
  		catalogPage.checkIfleftNavStoreExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkPolicyApprovals);
  		expect(util.getCurrentURL()).toMatch(appUrls.policyApprovalUrl);
  		homePage.switchToFrame();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.approvalPolicyPageHeader);
  	});
  	
  	it('Verify clicking on Operation Policies link navigates to operationPolicies page', function(){
  		catalogPage.checkIfleftNavStoreExpanded();
  		catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkOperationPolicies);
  		expect(util.getCurrentURL()).toMatch(appUrls.operationPolicyUrl);
  		homePage.switchToFrame();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.operationPolicyPageHeader);
  	});	
  	
  	it('Verify clicking on X button should close the left navigation bar', function(){
  		catalogPage.clickHamburgerCatalog();
  		expect(catalogPage.checkLeftNavBarOpened()).toContain(mcmpUIDataTemplate.leftNavBarArrowClass);
  	});
});
