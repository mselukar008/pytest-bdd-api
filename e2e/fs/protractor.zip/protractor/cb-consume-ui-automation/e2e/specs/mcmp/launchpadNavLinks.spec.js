"use strict";

var CartListPage           = require('../../pageObjects/cartList.pageObject.js'),
    HomePage               = require('../../pageObjects/home.pageObject.js'),
	util                   = require('../../../helpers/util.js'),
	appUrls                = require('../../../testData/appUrls.json'),
	mcmpUIDataTemplate     = require('../../../testData/mcmp/mcmpUIData.json');	
    
describe('Test cases for launchpad navigation links', function() {
	var cartListPage, homePage;
	
	beforeAll(function() {
    	cartListPage = new CartListPage();
    	homePage = new HomePage();
        browser.driver.manage().window().maximize();
    });
    
  	beforeEach(function() {
    	homePage.open();
    	expect(util.getCurrentURL()).toMatch(appUrls.launchpadUrl);
    });
  	
  	it('Verify user can see all the common tasks by clicking Show all tasks on the home page', function(){
  		expect(homePage.getCountMcmpTiles()).toBe(parseInt(mcmpUIDataTemplate.lauchpadTilesCount));
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getCountMcmpTiles()).toBeGreaterThan(parseInt(mcmpUIDataTemplate.lauchpadTilesCount));
  	});
  	
  	it('Verify few common tasks are hidden by clicking Show less tasks on the home page', function(){
  		homePage.clickShowLessTasksLink();
  		expect(homePage.getCountMcmpTiles()).toBe(parseInt(mcmpUIDataTemplate.lauchpadTilesCount));
  	});
  	
  	it('Verify clicking on Manage budget tile navigates to budget page', function(){
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadBudgetLink)).toBe(mcmpUIDataTemplate.leftNavButtonAdmin);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadBudgetLink);
  		expect(util.getCurrentURL()).toMatch(appUrls.budgetaryUrl);
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.budgetPageHeader);
  	});
  	
  	it('Verify clicking on Order new services tile navigates to catalog page', function(){
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadNewServices)).toBe(mcmpUIDataTemplate.leftNavButtonStore);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadNewServices);
  		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
  		browser.sleep(2000);
  		homePage.switchToFrame();
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.catalogPageHeader);
  	});
  	
  	it('Verify clicking on Review current cart tile navigates to cartList page', function(){
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadReviewCart)).toBe(mcmpUIDataTemplate.leftNavButtonStore);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadReviewCart);
  		expect(util.getCurrentURL()).toMatch(appUrls.currentCartListUrl);
  		cartListPage.switchToFrame();
  		util.waitForAngular();
  		expect(cartListPage.getTextCartNotAvailableMsg()).toContain(mcmpUIDataTemplate.cartNotAvailableMsg);
  		cartListPage.clickEmptyCartGoToCatalogLink();
  		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.catalogPageHeader);
  	});
  	
  	it('Verify clicking on Track order status tile navigates to order history page', function(){
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadTrackOrder)).toBe(mcmpUIDataTemplate.leftNavButtonStore);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadTrackOrder);
  		expect(util.getCurrentURL()).toMatch(appUrls.ordersPageUrl);
  		homePage.switchToFrame();
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.orderHistoryPageHeader);
  	});
  	
  	it('Verify clicking on View inventory tile navigates to inventory page', function(){
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadInventory)).toBe(mcmpUIDataTemplate.leftNavButtonStore);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadInventory);
  		expect(util.getCurrentURL()).toMatch(appUrls.inventoryPageUrl);
  		homePage.switchToFrame();
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.inventoryPageHeader);
  	});
  	
  	it('Verify clicking on Review pending orders tile navigates to approve orders page', function(){
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadReviewOrders)).toBe(mcmpUIDataTemplate.leftNavButtonStore);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadReviewOrders);
  		expect(util.getCurrentURL()).toMatch(appUrls.approveOrdersUrl);
  		homePage.switchToFrame();
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.ordersPageHeader);
  	});
  	
  	it('Verify clicking on Manage services publishing tile navigates to catalog admin page', function(){
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadManageServices)).toBe(mcmpUIDataTemplate.leftNavButtonStore);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadManageServices);
  		expect(util.getCurrentURL()).toMatch(appUrls.catalogAdminUrl);
  		homePage.switchToFrame();
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.catalogAdminPageHeader);
  	});
  	
  	it('Verify clicking on Manage policies approval tile navigates to approval policies page', function(){
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadManagePolicies)).toBe(mcmpUIDataTemplate.leftNavButtonStore);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadManagePolicies);
  		expect(util.getCurrentURL()).toMatch(appUrls.policyApprovalUrl);
  		homePage.switchToFrame();
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.approvalPolicyPageHeader);
  	});
  	
  	it('Verify clicking on Manage user access tile navigates to admin page', function(){
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadManageUser)).toBe(mcmpUIDataTemplate.leftNavButtonAdmin);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadManageUser);
  		expect(util.getCurrentURL()).toMatch(appUrls.adminUrl);
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.userAccessPageHeader);
  	});
  	
  	it('Verify clicking on Manage currency conversion tile navigates to currency page', function(){
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadManageCurrency)).toBe(mcmpUIDataTemplate.leftNavButtonAdmin);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadManageCurrency);
  		expect(util.getCurrentURL()).toMatch(appUrls.currencyUrl);
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.currencyPageHeader);
  	});
  	
  	it('Verify clicking on View audit logs tile navigates to audit page', function(){
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadViewAudit)).toBe(mcmpUIDataTemplate.leftNavButtonAdmin);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadViewAudit);
  		expect(util.getCurrentURL()).toMatch(appUrls.auditUrl);
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.auditPageHeader);
  	});
  	
  	it('Verify clicking on Archive audit logs tile navigates to audit page', function(){
  		homePage.clickShowAllTasksLink();
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadArchiveAudit)).toBe(mcmpUIDataTemplate.leftNavButtonAdmin);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadArchiveAudit);
  		expect(util.getCurrentURL()).toMatch(appUrls.auditUrl);
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.auditPageHeader);
  	});
  	
  	it('Verify user icon and by clicking on Admin Console button navigates to admin page', function(){
  		expect(homePage.isPresentAdminConsoleUserIcon()).toBe(true);
  		homePage.clickAdminConsoleButton();
  		expect(util.getCurrentURL()).toMatch(appUrls.adminUrl);
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.userAccessPageHeader);
  	});
  	
  	it('Verify clicking on Enterprise Marketplace link navigates to catalog page', function(){
  		homePage.clickStoreLink();
  		expect(util.getCurrentURL()).toMatch(appUrls.catalogPageUrl);
  		homePage.switchToFrame();
  		util.waitForAngular();
  		expect(homePage.getTextPageHeader()).toBe(mcmpUIDataTemplate.catalogPageHeader);
  	});
  	
  	it('Verify clicking on Knowledge center tile navigates to mcmp introduction page', function(){
  		expect(homePage.getTextCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadKnowledgeCenter)).toBe(mcmpUIDataTemplate.launchpadKnowledgeCenterDesc);
  		homePage.clickCommonTasksTileBasedOnName(mcmpUIDataTemplate.launchpadKnowledgeCenter);
  		util.waitForAngular();
  		expect(homePage.getTextKnowledgeCenterHeader()).toBe(mcmpUIDataTemplate.knowledgeCenterHeader);
  	});
  	
  	it('Verify clicking on Privacy Policy link navigates to IBM Privacy Statement page', function(){
  		homePage.clickPrivacyPolicyLink();
  		expect(homePage.getTextPrivacyPolicyHeader()).toBe(mcmpUIDataTemplate.privacyStatementHeader);
  	});
  	
  	it('Verify Build ID on launchpad', function(){
  		expect(homePage.getTextBuildID()).toContain(mcmpUIDataTemplate.buildID);
  	}) 	
  	
});