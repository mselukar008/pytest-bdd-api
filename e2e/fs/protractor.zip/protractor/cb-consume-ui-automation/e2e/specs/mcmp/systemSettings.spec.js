"use strict";

var CatalogPage            = require('../../pageObjects/catalog.pageObject.js'),
	HomePage               = require('../../pageObjects/home.pageObject.js'),
	util                   = require('../../../helpers/util.js'),
	appUrls                = require('../../../testData/appUrls.json'),
    mcmpUIDataTemplate     = require('../../../testData/mcmp/mcmpUIData.json');

    describe('System settings of Launchpad page:', function() {
        var catalogPage, homePage;
        
        beforeAll(function() {
            catalogPage = new CatalogPage();
            homePage = new HomePage();
            browser.driver.manage().window().maximize();

            catalogPage.clickHamburgerCatalog();
            catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonAdmin);
            catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonSettings);
            catalogPage.clickHamburgerCatalog();
        });
        
        beforeEach(function() {
            homePage.open();
            expect(util.getCurrentURL()).toMatch(appUrls.launchpadUrl);
            catalogPage.clickHamburgerCatalog();
            catalogPage.checkIfleftNavAdminExpanded();
            catalogPage.checkIfleftNavSettingsExpanded();    
        });

        it('Verify color coding of lauchpad header after changing theme system settings', function(){
            catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkSystem);
            expect(homePage.getTextSysPageHeader()).toBe(mcmpUIDataTemplate.systemSettingsPageHeader);
 	        expect(util.getCurrentURL()).toMatch(appUrls.systemUrl);
            homePage.clickOnThemeLink();
            homePage.changePageHeaderColor(mcmpUIDataTemplate.newthemecolor);
            homePage.clickSaveThemeBtn();
            homePage.open();
            expect(homePage.getPageHeaderColor()).toBe(mcmpUIDataTemplate.changedColorCode);      
        });

        it('Verify color coding of lauchpad header after reverting to default settings', function(){
            catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkSystem);
            expect(util.getCurrentURL()).toMatch(appUrls.systemUrl);
            expect(homePage.getTextSysPageHeader()).toBe(mcmpUIDataTemplate.systemSettingsPageHeader);
            homePage.clickOnThemeLink();
            homePage.clickRestoreDefaultThemeSettings();
            homePage.open();
            expect(homePage.getPageHeaderColor()).toBe(mcmpUIDataTemplate.defaultColorCode);
        });

        afterAll(function() {
            homePage.open();
            expect(homePage.getPageHeaderColor()).toBe(mcmpUIDataTemplate.defaultColorCode);
        });
    });