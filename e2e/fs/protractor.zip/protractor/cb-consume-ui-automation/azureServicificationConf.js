var jasmineReporters = require('jasmine-reporters');

exports.config = {

  //   seleniumAddress: 'http://localhost:4444/wd/hub',
    allScriptsTimeout: 7200000,
    useAllAngular2AppRoots: true,

    /**
     * usage example:
     * protractor protractor.conf.js --specs=e2e/home.spec.js
     */
    suites: {
         
        'e2eAzure_StorageAccount101':'e2e/specs/azureServicificationSpec/101storageAccount.spec.js',
        'e2eAzure_AvailabilitySet101':'e2e/specs/azureServicificationSpec/101availabilitySetCreate3FD20UD.spec.js',
        'e2eAzure_VmSimpleWindows101': 'e2e/specs/azureServicificationSpec/101vmSimpleWindows.spec.js',
        'e2eAzure_VmSimpleRhel101': 'e2e/specs/azureServicificationSpec/101vmSimpleRhel.spec.js',
        'e2eAzure_VmSimpleLinux101': 'e2e/specs/azureServicificationSpec/101vmSimpleLinux.spec.js',
        'e2eAzure_AzureFirewallCreate101' : 'e2e/specs/azureServicificationSpec/101azureFirewallCreate.spec.js',
        'e2eAzure_LinuxContainerWithPublicIP':'e2e/specs/azureServicificationSpec/101aciLinuxContainerPublicIp.spec.js',
        'e2eAzure_ContainerRegistry':'e2e/specs/azureServicificationSpec/101containerRegistry.spec.js',
        'e2eAzure_LoadBalancerWithMultivip':'e2e/specs/azureServicificationSpec/101loadBalancerWithMultivip.spec.js',
        'e2eAzure_NetworkInterfaceInVirtualNetworkWithPublicIPAddress':'e2e/specs/azureServicificationSpec/101nicPublicIpDnsVnet.spec.js'

    },
    capabilities:
    {
        'browserName': 'chrome',
         chromeOptions: {
          args:["--headless",
                'disable-extensions',
                "--window-size=1920,1080"
               ]  
        } 
    },

    framework: 'jasmine2',
    jasmineNodeOpts: {
        onComplete: null,
        isVerbose: false,
        showColors: true,
        includeStackTrace: true,
        defaultTimeoutInterval : 50000000,
        allScriptsTimeout: 20000000,
        useAllAngular2AppRoots: true
    },

    params: {
        //url:      'https://cb-qa-1.gravitant.net',
        //url:      'https://cb-qa-2.gravitant.net',
        //url:      'https://cb-qa-3.gravitant.net',
        //url:      'https://cb-qa-4.gravitant.net',
        //url:      'https://cb-qa-6.gravitant.net',
        //url:      'https://cb-qa-2-release.gravitant.net',
        //url:      'https://cb-qa-3-release.gravitant.net',
        //url:      'https://cb-qa-4-release.gravitant.net',
        //url:      'https://cb-customer1.gravitant.net',
        //url:      'https://cb-customer1-cleaninstall.gravitant.net',
        //url:      'https://cb-qa-orders.gravitant.net',
        //username: 'cbadmn@outlook.com',
        //	password: 'Gravitant123$',
        isProvisioningRequired : 'true' 
    },

    onPrepare: async function () {
        require('./helpers/onPrepare.js');
        ensureConsumeHome(); 
        jasmine.getEnv().addReporter(new jasmineReporters.JUnitXmlReporter({
            savePath: 'testreports',
            consolidate: true,
            useDotNotation: true
        }));

    }
};
