"use strict";
var extend = require('extend');
var locatorsConfig = {

}

export const homePage = class home{
    constructor(page) {
        this.page = page;
        extend(this, locatorsConfig);
    };

    async open() {
        var self = this;
        await self.clickHamburgerCatalog();
        await self.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
        await self.checkIfleftNavStoreExpanded();
        await self.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkCatalog);
        // browser.sleep(5000);
        // util.switchToFrame();			
        // util.waitForAngular();		
        await self.clickResetProviderLink();
        await self.clickCloseLabelsIcon();
    };

    async clickHamburgerCatalog() {

    };

    async clickLeftNavButtonBasedOnName() {

    };

    async checkIfleftNavStoreExpanded() {

    };

    async clickLeftNavLinkBasedOnName() {

    };

    async clickResetProviderLink() {

    };

    async clickCloseLabelsIcon() {

    };

    
    

    

}