

exports.placeOrder = class placeOrder{
        constructor(Page) {
        this.page = Page;
    }; 

    async clickNextButton(){         
        await this.page.frame({
            name: 'mcmp-iframe'
        }).click("button[title='Next']")
        console.log("Place Order Page", "Info", "Clicked on Next button");
    };

    async submitOrder(){         
        await this.page.frame({
            name: 'mcmp-iframe'
        }).click("button[id$='primary-btn-review-order']")
        console.log("Submit Order", "Info", "Clicked on Submit Order button");
    };

    async getTextOrderSubmittedHeaderOrderSubmittedModal() {       
        await this.page.frame({
            name: 'mcmp-iframe'
        }).waitForSelector('h3.bx--modal-header__heading', {timeout:10000});

        var text = await this.page.frame({
            name: 'mcmp-iframe'
        }).innerText('h3.bx--modal-header__heading');
        console.log("Order submission modal header - " + text);
        return text;
    };

    async getTextOrderNumberOrderSubmittedModal() {
        await this.page.frame({
            name: 'mcmp-iframe'
        }).waitForSelector('#order-number', {timeout:10000});

        var text = await this.page.frame({
            name: 'mcmp-iframe'
        }).innerText('#order-number');
        console.log("Order Number - " + text);
        return text;
    };

    async clickgoToServiceCatalogButtonOrderSubmittedModal() {
        await this.page.frame({
            name: 'mcmp-iframe'
        }).click('#order-submitted-modal_carbon-button');
        console.log("Clicked on Go to Service Catalog button");
    }

    async validateReviewOrderPageParams (reviewOrderExpActParamsMap) {
        var expctdParams = Object.keys(reviewOrderExpActParamsMap["Expected"]);
        var expValue, actValue;
        for (var i = 0; i < expctdParams.length; i++) {
            if(reviewOrderExpActParamsMap["Actual"][expctdParams[i]] != undefined){
                expValue = reviewOrderExpActParamsMap["Expected"][expctdParams[i]];
                actValue = reviewOrderExpActParamsMap["Actual"][expctdParams[i]].replace("\nUpdated", "").replace("\nNew", "")
        
                if (actValue.includes("... more")) {
                    actValue = actValue.split("... more")[0];
                }
                if (expValue == actValue) {
                    console.log("Review Order page parametr -> " + expctdParams[i] + " = " + actValue);
                } else if (expValue.includes(actValue)) {
                    console.log("Review Order page parametr -> " + expctdParams[i] + " = " + actValue);
                }
                else {
                    console.log("Review Order page parametr - Actual --> " + expctdParams[i] + " = " + actValue + " | Expected --> " + expctdParams[i] + " = " + expValue);
                    return false;
                }
            }            
        }
        return true;
    };

    async getAndSaveOrderId (serviceName, orderType) {
        browser.wait(EC.visibilityOf(element(by.css(this.orderSubmittedModalOrderNumberTextCss))), 190000);
        return element(by.css(this.orderSubmittedModalOrderNumberTextCss)).getText().then(async function (text) {
            logger.info("Order number : " + text);
            await util.saveOrderId(serviceName, orderType, text);
            return text;
        });
    };




}    