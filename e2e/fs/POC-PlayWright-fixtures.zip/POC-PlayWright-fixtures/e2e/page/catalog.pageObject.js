"use strict";
var mcmpUIDataTemplate = require('../../testData/mcmpUI.json')
var locatorsConfig = {
    hamburgerCatalogCss: 'ibm-hamburger button',
	leftNavBarCss: 'ibm-sidenav',
	pinLeftNavBarCss: 'ibm-icon-pin svg',
	arrowLeftNavBarCss: 'ibm-icon-arrow-left svg',
	textLeftNavLinkCss: 'a.bx--side-nav__link span',
	textLeftNavButtonCss: '.bx--side-nav__submenu-title',
	buttonLeftNavSubMenu: '.bx--side-nav__submenu',
	linkResetProviderText: 'RESET',
	linkCatalogMainParamText: 'Catalog',    
};


exports.catalog = class catalog{
    constructor(Page) {
        this.page = Page;        
    };

    async open() {
        var self = this;
        await self.clickHamburgerCatalog();
        await self.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
        //await self.checkIfleftNavStoreExpanded();
        await self.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkCatalog);
        // browser.sleep(5000);
        // util.switchToFrame();			
        // util.waitForAngular();		
        // await self.clickResetProviderLink();
        // await self.clickCloseLabelsIcon();
    };

    async clickHamburgerCatalog() {
        //await this.page.wait
        await this.page.click(locatorsConfig.hamburgerCatalogCss);
    };

    async clickLeftNavButtonBasedOnName(navLinkName) {
       // await this.page.click(locatorsConfig.textLeftNavButtonCss);
        await this.page.click('button:has-text("Enterprise Marketplace")');
    };

    // async checkIfleftNavStoreExpanded() {

    // };

    async clickLeftNavLinkBasedOnName() {
        //await this.page.click(locatorsConfig.textLeftNavButtonCss);
        await this.page.click('a[role="menuitem"]:has-text("Catalog")');
    };

    // async clickResetProviderLink() {

    // };

    // async clickCloseLabelsIcon() {

    // };

    async clickCategory(category) {        
        await this.page.frame({
            name: 'mcmp-iframe'
        }).click("text=" + category);   
         // click(".cb--selectable-list li :text('" + category + "')");          
    };

    async clickProvider(provider) {        
       await this.page.frame({
        name: 'mcmp-iframe'
      }).click("text="+provider);    
    };

    async clickOnserviceName(serviceName){
        await this.page.frame({
            name: 'mcmp-iframe'
        }).click('text=' + serviceName);
    };
    
    async clickConfigureBtn(){
        await this.page.frame({
            name: 'mcmp-iframe'
        }).click('#configure-service');
    };
    
}