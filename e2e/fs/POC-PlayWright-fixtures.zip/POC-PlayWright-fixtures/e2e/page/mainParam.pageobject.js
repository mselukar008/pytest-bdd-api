"use strict"
var util = require("../../helpers/util");

exports.mainParam = class mainParam{
    constructor(Page) {
        this.page = Page;
    }; 
        
    async fillMainParameterPageDetails(configDetails){
        //Switch to main frame
        this.page = util.getFrame(this.page);
        await this.setServiceName(configDetails["serviceName"]);
        await this.selectTeam(configDetails["Team"]);
        await this.selectContexts(configDetails["Env"], configDetails["App"]);
        await this.selectProviderAccount(configDetails["providerAccount"]);
    }

    // async setServiceName(serviceName){
    //     await this.page.frame({
    //         name: 'mcmp-iframe'
    //     }).fill('[placeholder="Please insert Service Instance Prefix"]', serviceName);
    //     console.log("Test", "Info", "Entered Service name");
    // };

    // async selectTeam(team){        
    //     await this.page.frame({
    //         name: 'mcmp-iframe'
    //     }).click('label[for="radio-button-team_' + team + '"]')
    //     console.log("Test", "Info", "Selected team");          
    // };

    // async selectContexts(env,app){       
    //     await Promise.all([
    //         this.page.frame({
    //             name: 'mcmp-iframe'
    //         }).click('//*[@id="env"]/div//div'),
            
    //         this.page.frame({
    //             name: 'mcmp-iframe'
    //         }).click("text="+env)           
    //     ]);
    //     console.log("Test", "Info", "Selected Environment");
    //     await Promise.all([
    //         this.page.frame({
    //             name: 'mcmp-iframe'
    //         }).click('//*[@id="app"]/div//div'),

    //         this.page.frame({
    //             name: 'mcmp-iframe'
    //         }).click("text="+ app)                            
    //     ]);
    //     console.log("Test", "error", "Selected App");
    // };

    // async selectProviderAccount(providerAcc){
    //     await this.page.frame({
    //         name: 'mcmp-iframe'
    //      }).click('text=gcpQA-TEAM1 / gcpQA-TEAM1 gcp-TEAM1 / gcp-TEAM1 >> span');
    //      console.log("Test", "Info", "Selected Provider Account"); 
    // };

    async setServiceName(serviceName){
        await this.page.fill('[placeholder="Please insert Service Instance Prefix"]', serviceName);
        console.log("Test", "Info", "Entered Service name");
    };

    async selectTeam(team){        
        await this.page.click('label[for="radio-button-team_' + team + '"]')
        console.log("Test", "Info", "Selected team");          
    };

    async selectContexts(env,app){       
        await Promise.all([
            this.page.click('//*[@id="env"]/div//div'),            
            this.page.click("text="+env),
            console.log("Test", "Info", "Selected Environment")           
        ]);
        
        await Promise.all([
            this.page.click('//*[@id="app"]/div//div'),
            this.page.click("text="+ app),
            console.log("Test", "error", "Selected App")                            
        ]);        
    };

    async selectProviderAccount(providerAcc){
        await this.page.click('text=gcpQA-TEAM1 / gcpQA-TEAM1 gcp-TEAM1 / gcp-TEAM1 >> span');
        console.log("Test", "Info", "Selected Provider Account"); 
    };



    

}