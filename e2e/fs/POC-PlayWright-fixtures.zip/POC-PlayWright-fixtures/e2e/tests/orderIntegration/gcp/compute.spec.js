//const { skipImiConfig } = require('../../../../playwright.config');
const { test, expect } = require('./../../../../fixtures/testFixture');
// const { catalog } = require('./../../../page/catalog.pageObject');
// const { mainParam } = require('./../../../page/mainParam.pageobject');
// const { placeOrder } = require('../../../page/placeOrder.pageObject');
// const { orderFlowUtil } = require('../../../../helpers/orderFlowUtil.js');
var util = require("../../../../helpers/util.js");
//var catalogPage, mainParamPage, placeOrderPage;
let modifiedParametersMap = { "serviceName": "MyAutoTest", "Team": "Auto-TEAM1", "Env": "NONE", "App": "NONE", "providerAccount": "gcpQA-TEAM1" };
var pubSubTemplate = require('../../../../testData/orderIntegration/Google/pubsub.json');

var modifiedParams = {}, serviceName = "pubsub1", topicName="testTopic", orderFlow;
//var page;

modifiedParams = { "Service Instance Name": serviceName, "Name": topicName };

// test.describe("GCP Pubsub", () =>{
//     test.beforeAll(async({ logIn, Page }) => { 
//         //page = await browser.newPage();
//         page = Page;
//         catalogPage = new catalog(page);
//         mainParamPage = new mainParam(page);
//         placeOrderPage = new placeOrder(page);
//         orderFlow = new orderFlowUtil(page);
//     })

// });

// test('PubSub - Validate Details on Main Parameter page', async ({ loggedIn, page }) => {
//     catalogPage = new catalog(page);
//     mainParamPage = new mainParam(page);
//     placeOrderPage = new placeOrder(page);
//     orderFlow = new orderFlowUtil(page);
    

//     await catalogPage.open(page);
//     await catalogPage.clickProvider(pubSubTemplate.provider);
//     await catalogPage.clickCategory(pubSubTemplate.Category);
//     await catalogPage.clickOnserviceName(pubSubTemplate.bluePrintName);
//     await catalogPage.clickConfigureBtn();
//     var requiredReturnMap = await orderFlow.fillOrderDetails(pubSubTemplate, modifiedParams);    
//     //Validate all review order page parameters are as per input service configuration 
//     expect(await placeOrderPage.validateReviewOrderPageParams(requiredReturnMap)).toEqual(true);   
//     //await mainParamPage.fillMainParameterPageDetails(modifiedParametersMap);
//     //Submit order
//     await placeOrderPage.submitOrder();
//     expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual("Order Submitted !");
//     //Get order id
//     var orderNumber = await placeOrderPage.getTextOrderNumberOrderSubmittedModal();
//     await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
   
// });
    //test.use({ storageState: 'state.json' });

    // test('PubSub - Validate Details on Review order page', async ({loggedIn, page}) => {        
    //     catalogPage = new catalog(page);
    //     await catalogPage.open(page);
    //     await catalogPage.clickProvider("Google");
    //     await catalogPage.clickCategory("Compute");
    //     await catalogPage.clickOnserviceName("Compute Engine");
    //     await catalogPage.clickConfigureBtn();
    // });

//});  

// test('basic test', async ({ page }) => {
//   await page.goto('https://playwright.dev/');
//   const name = await page.innerText('.navbar__title');
//   expect(name).toBe('Playwright');
// });

test('PubSub - Validate Details on Main Parameter page', async ({ loggedIn, catalogPage, placeOrderPage, orderFlowUtils }) => {
    await catalogPage.open();
    await catalogPage.clickProvider(pubSubTemplate.provider);
    await catalogPage.clickCategory(pubSubTemplate.Category);
    await catalogPage.clickOnserviceName(pubSubTemplate.bluePrintName);
    await catalogPage.clickConfigureBtn();
    var requiredReturnMap = await orderFlowUtils.fillOrderDetails(pubSubTemplate, modifiedParams);    
    //Validate all review order page parameters are as per input service configuration 
    expect(await placeOrderPage.validateReviewOrderPageParams(requiredReturnMap)).toEqual(true);   
    //await mainParamPage.fillMainParameterPageDetails(modifiedParametersMap);
    //Submit order
    await placeOrderPage.submitOrder();
    expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual("Order Submitted !");
    //Get order id
    var orderNumber = await placeOrderPage.getTextOrderNumberOrderSubmittedModal();
    await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();   
});

test('PubSub - Validate Details on Main Parameter page', async ({ loggedIn, catalogPage, mainParamPage }) => {
    await catalogPage.open();
    await catalogPage.clickProvider(pubSubTemplate.provider);
    await catalogPage.clickCategory(pubSubTemplate.Category);
    await catalogPage.clickOnserviceName(pubSubTemplate.bluePrintName);
    await catalogPage.clickConfigureBtn();      
    await mainParamPage.fillMainParameterPageDetails(modifiedParametersMap);    
});