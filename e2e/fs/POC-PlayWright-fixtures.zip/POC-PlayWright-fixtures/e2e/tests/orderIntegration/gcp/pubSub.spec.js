const { test, expect } = require('./../../../../fixtures/testFixture');
var util = require("../../../../helpers/util.js");
let modifiedParametersMap = { "serviceName": "MyAutoTest", "Team": "Auto-TEAM1", "Env": "NONE", "App": "NONE", "providerAccount": "gcpQA-TEAM1" };
var pubSubTemplate = require('../../../../testData/orderIntegration/Google/pubsub.json');
var modifiedParams = {}, serviceName = "pubsub1", topicName="testTopic", orderFlow;
//var mainParam, catalog, placeOrder, orderflow;

modifiedParams = { "Service Instance Name": serviceName, "Name": topicName };

// test.describe("GCP PubSub", () => {
//     test.beforeAll(async ({ mainParamPage, catalogPage, placeOrderPage, orderFlowUtils }) =>{
//         mainParam = mainParamPage;
//         catalog = catalogPage;
//         placeOrder = placeOrderPage;
//         orderflow = orderFlowUtils;    
//     });

//     test('PubSub - Validate Details on Main Parameter page', async ({ loggedIn }) => {
//         await catalog.open();
//         await catalog.clickProvider(pubSubTemplate.provider);
//         await catalog.clickCategory(pubSubTemplate.Category);
//         await catalog.clickOnserviceName(pubSubTemplate.bluePrintName);
//         await catalog.clickConfigureBtn();
//         var requiredReturnMap = await orderflow.fillOrderDetails(pubSubTemplate, modifiedParams);    
//         //Validate all review order page parameters are as per input service configuration 
//         expect(await placeOrder.validateReviewOrderPageParams(requiredReturnMap)).toEqual(true);   
//         //await mainParamPage.fillMainParameterPageDetails(modifiedParametersMap);
//         //Submit order
//         await placeOrder.submitOrder();
//         expect(await placeOrder.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual("Order Submitted !");
//         //Get order id
//         var orderNumber = await placeOrder.getTextOrderNumberOrderSubmittedModal();
//         await placeOrder.clickgoToServiceCatalogButtonOrderSubmittedModal();   
//     });
    
//     test('PubSub - Validate Details on Main Parameter page', async ({ loggedIn }) => {
//         await catalog.open();
//         await catalog.clickProvider(pubSubTemplate.provider);
//         await catalog.clickCategory(pubSubTemplate.Category);
//         await catalog.clickOnserviceName(pubSubTemplate.bluePrintName);
//         await catalog.clickConfigureBtn();      
//         await mainParam.fillMainParameterPageDetails(modifiedParametersMap);    
//     });
// });


test('PubSub - Validate Details on Main Parameter page', async ({ loggedIn, catalogPage, placeOrderPage, orderFlowUtils }) => {
    await catalogPage.open();
    await catalogPage.clickProvider(pubSubTemplate.provider);
    await catalogPage.clickCategory(pubSubTemplate.Category);
    await catalogPage.clickOnserviceName(pubSubTemplate.bluePrintName);
    await catalogPage.clickConfigureBtn();
    var requiredReturnMap = await orderFlowUtils.fillOrderDetails(pubSubTemplate, modifiedParams);    
    //Validate all review order page parameters are as per input service configuration 
    expect(await placeOrderPage.validateReviewOrderPageParams(requiredReturnMap)).toEqual(true);   
    //await mainParamPage.fillMainParameterPageDetails(modifiedParametersMap);
    //Submit order
    await placeOrderPage.submitOrder();
    expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual("Order Submitted !");
    //Get order id
    var orderNumber = await placeOrderPage.getTextOrderNumberOrderSubmittedModal();
    await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();   
});

test('PubSub - Validate Details on Main Parameter page', async ({ loggedIn, catalogPage, mainParamPage }) => {
    await catalogPage.open();
    await catalogPage.clickProvider(pubSubTemplate.provider);
    await catalogPage.clickCategory(pubSubTemplate.Category);
    await catalogPage.clickOnserviceName(pubSubTemplate.bluePrintName);
    await catalogPage.clickConfigureBtn();      
    await mainParamPage.fillMainParameterPageDetails(modifiedParametersMap);    
});
