const{chromium} = require("playwright");

(async () => {
    const browser = await chromium.launch(
        {
            headless:false
        });
    // Create pages, interact with UI elements, assert values
    const page = await browser.newPage();

    // await page.goto("https://mcmp-stagedal-master-autoui.multicloud-ibm.com");
    // await page.screenshot({path:'test.png'});

    //const { test, expect } = require('@playwright/test');

// test('test', async ({ page }) => {

  // Go to https://mcmp-stagedal-master-autoui.multicloud-ibm.com/
  await page.goto('https://mcmp-dev2fra-release-autoui.multicloud-ibm.com');   

  // Fill input[type="text"]
  await page.fill('input[type="text"]', 'uiautomcmpuser@outlook.com');

  // Click text=Continue
  await page.click('text=Continue');

  // Fill input[type="password"]
  await page.fill('input[type="password"]', 'Automcmpuser@00');

  // Click button:has-text("Log in")
  await page.click('button:has-text("Log in")');
  //expect(page.url()).toBe('https://mcmp-stagedal-master-autoui.multicloud-ibm.com/launchpad');

  // Go to https://mcmp-stagedal-master-autoui.multicloud-ibm.com/
  //await page.goto('https://mcmp-stagedal-master-autoui.multicloud-ibm.com/');

  // Go to https://mcmp-stagedal-master-autoui.multicloud-ibm.com/privacy
  //await page.goto('https://mcmp-stagedal-master-autoui.multicloud-ibm.com/privacy');

  // Click text=I Accept
  await Promise.all([
    page.waitForNavigation(/*{ url: 'https://mcmp-stagedal-master-autoui.multicloud-ibm.com/launchpad' }*/),
    page.click('text=I Accept')
  ]);

  // Click [aria-label="Open menu"]
  await page.click('[aria-label="Open menu"]');

  // Click button:has-text("Enterprise Marketplace")
  await page.click('button:has-text("Enterprise Marketplace")');

  // Click a[role="menuitem"]:has-text("Catalog")
  await page.click('a[role="menuitem"]:has-text("Catalog")');
  //expect(page.url()).toBe('https://mcmp-stagedal-master-autoui.multicloud-ibm.com/lite/consume/storeFront');

  // Click text=Google
  await page.frame({
    name: 'mcmp-iframe'
  }).click('text=Google');

  // Click text=Applications
  await page.frame({
    name: 'mcmp-iframe'
  }).click('text=Applications');

  // Click text=Pub/Sub
  await page.frame({
    name: 'mcmp-iframe'
  }).click('text=Pub/Sub');
  //expect(page.url()).toBe('https://mcmp-stagedal-master-autoui.multicloud-ibm.com/lite/consume/storeFront/service-details/gcp/CB_GCP_DEPMGR_PUB_SUB_S00');

  // Click text=Configure v1.0.0.0
  await page.frame({
    name: 'mcmp-iframe'
  }).click('text=Configure v1.0.0.0');
  //expect(page.url()).toBe('https://mcmp-stagedal-master-autoui.multicloud-ibm.com/lite/consume/storeFront/place-order/main-parameters/gcp/CB_GCP_DEPMGR_PUB_SUB_S00');
  
  // Fill [placeholder="Please insert Service Instance Prefix"]
  await page.frame({
    name: 'mcmp-iframe'
  }).fill('[placeholder="Please insert Service Instance Prefix"]', 'attpubSub');

  // Click carbon-radio-button:has-text("Auto-TEAM1")
  await page.frame({
    name: 'mcmp-iframe'
  }).click('carbon-radio-button:has-text("Auto-TEAM1")');  
  
  // Click text=NONE
  await page.frame({
    name: 'mcmp-iframe'
  }).click('text=NONE');

  // Click [aria-label="Search for ez33ypyhw"] >> text=NONE
  await page.frame({
    name: 'mcmp-iframe'
  }).click('[aria-label="Search for ez33ypyhw"] >> text=NONE');

  // Click #app >> text=NONE
  await page.frame({
    name: 'mcmp-iframe'
  }).click('#app >> text=NONE');

  // Click [aria-label="Search for ihfx3hp63"] >> text=NONE
  await page.frame({
    name: 'mcmp-iframe'
  }).click('[aria-label="Search for ihfx3hp63"] >> text=NONE');

   // Click text=gcpQA-TEAM1 / gcpQA-TEAM1 gcp-TEAM1 / gcp-TEAM1 >> span
  await page.frame({
    name: 'mcmp-iframe'
  }).click('text=gcpQA-TEAM1 / gcpQA-TEAM1 gcp-TEAM1 / gcp-TEAM1 >> span');

  // Click text=Next
  await page.frame({
    name: 'mcmp-iframe'
  }).click('text=Next');
  //expect(page.url()).toBe('https://mcmp-stagedal-master-autoui.multicloud-ibm.com/lite/consume/storeFront/place-order/additional-parameters/gcp/CB_GCP_DEPMGR_PUB_SUB_S00');
  
  // Fill [placeholder="Please Insert"]
  await page.frame({
    name: 'mcmp-iframe'
  }).fill('[placeholder="Please Insert"]', 'attsub123');

  // Click text=Next
  await page.frame({
    name: 'mcmp-iframe'
  }).click('text=Next');

  // Click text=Next
  await Promise.all([
    page.waitForNavigation(/*{ url: 'https://mcmp-stagedal-master-autoui.multicloud-ibm.com/lite/consume/storeFront/place-order/review-order/gcp/CB_GCP_DEPMGR_PUB_SUB_S00' }*/),
    page.frame({
      name: 'mcmp-iframe'
    }).click('text=Next')
  ]);

  // Click text=Submit Order
  await page.frame({
    name: 'mcmp-iframe'
  }).click('text=Submit Order'); 

  // Click text=Go to Service Catalog
  await page.frame({
    name: 'mcmp-iframe'
  }).click('text=Go to Service Catalog');
  //expect(page.url()).toBe('https://mcmp-stagedal-master-autoui.multicloud-ibm.com/lite/consume/storeFront/main');

  // Click [aria-label="Open menu"]
  await page.click('[aria-label="Open menu"]');

  // Click text=Approve Orders
  await page.click('text=Approve Orders');
  //expect(page.url()).toBe('https://mcmp-stagedal-master-autoui.multicloud-ibm.com/lite/consume/orders');

  // Click text=All orders
  await page.frame({
    name: 'mcmp-iframe'
  }).click('text=All orders');

  // Click text=Pending approval
  await page.frame({
    name: 'mcmp-iframe'
  }).click('text=Pending approval');

  
    await browser.close();
  })();
