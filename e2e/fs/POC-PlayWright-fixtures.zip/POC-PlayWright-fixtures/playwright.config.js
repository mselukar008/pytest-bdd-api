module.exports = {
    workers:1,
    use: {
      // Browser options
      headless: false,
      
      //slowMo: 50,
  
      // Context options
      viewport: { width: 1280, height: 720 },
      ignoreHTTPSErrors: true,
  
      // Artifacts
      screenshot: 'only-on-failure',
      video: 'retry-with-video',
      logger: {
        isEnabled: (name, severity) => name === 'browser',
        log: (name, severity, message, args) => console.log(`${name} ${message}`)
      }
    },
    testDir:'e2e/tests/orderIntegration/gcp',
    //reporter
    //globalSetup: './helpers/globalSetup.js',
    timeout: 1000000,
    userName:"",
    password:"",
    isDummyAdapterEnabled:"",
    isProvisioningRequired:"true",
    defaultCurrency:"USD",
    skipImiConfig:false,

  };