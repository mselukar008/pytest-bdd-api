const {PlaywrightEnv } = require('@playwright/test');

class MyEnv extends PlaywrightEnv {
  //async beforeEach(testInfo: TestInfo) {
  //   // Get all default arguments, including Page.
  //   const result = await super.beforeEach(testInfo);
  //   // Create your POM.
  //   const indexPage = new IndexPage(result.page, baseURL);
  //   // Return default arguments and new POM.
  //   return { ...result, indexPage };
  // }
}