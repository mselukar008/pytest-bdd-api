const { test } = require('@playwright/test');
const { Page } = require('playwright');

//=============================================
const { catalog } = require('../e2e/page/catalog.pageObject');
const { mainParam } = require('../e2e/page/mainParam.pageobject');
const { placeOrder } = require('../e2e/page/placeOrder.pageObject');
// var Orders = require('../e2e/page/orders.pageObject');
// var OrderHistory = require('../e2e/page/orderHistory.pageObject');  
// var OrderedServices = require('../e2e/page/orderedServices.pageObject');
const { orderFlowUtil } = require('../helpers/orderFlowUtil'); 
//===================================================
// const it = test.extend({

//     loggedIn: async ({ page }, use) => {
//         //const todoPage = new TodoPage(page);
//         page.setDefaultTimeout(180000);
//         await page.goto('https://mcmp-stagedal-master-autoui.multicloud-ibm.com/');
      
//         // Fill input[type="text"]
//         await page.fill('input[type="text"]', 'uiautomcmpuser@outlook.com');

//         // Click text=Continue
//         await page.click('text=Continue');

//         // Fill input[type="password"]
//         await page.fill('input[type="password"]', 'Automcmpuser@00');

//         // Click button:has-text("Log in")
//         await page.click('button:has-text("Log in")');

//         // Click text=I Accept
//         await Promise.all([            
//             //page.waitForNavigation(/*{ url: 'https://mcmp-stagedal-master-autoui.multicloud-ibm.com/launchpad' }*/),
//             //page.waitForLoadState('networkidle'),
//             page.click('text=I Accept')
//         ]);
//         //Dont need anything in calling function, so dont return anything from use method
//         //await use(loggedIn);
//         await page.context().storageState({ path: 'state.json' });
//         await use();
        
//     }
// });

///===============New Fixture ================
const it = test.extend({
    pageObject: async ({ page }, use) => {
        const pageObject = page;
        await use(pageObject);
    },
    mainParamPage: async ({ pageObject }, use) => {
        const mainParamPage = new mainParam(pageObject);
        await use(mainParamPage);
    },
    catalogPage: async ({ pageObject }, use) => {
        const catalogPage = new catalog(pageObject);
        await use(catalogPage);
    },
    placeOrderPage: async ({ pageObject }, use) => {
        const placeOrderPage = new placeOrder(pageObject);
        await use(placeOrderPage);
    },
    orderFlowUtils: async ({ pageObject }, use) => {
        const orderFlowUtils = new orderFlowUtil(pageObject);
        await use(orderFlowUtils);
    },
    loggedIn: async ({ pageObject }, use) => {
            //const todoPage = new TodoPage(page);
            pageObject.setDefaultTimeout(180000);
            await pageObject.goto('https://mcmp-stagedal-master-autoui.multicloud-ibm.com/');
            
            // Fill input[type="text"]
            await pageObject.fill('input[type="text"]', 'uiautomcmpuser@outlook.com');
    
            // Click text=Continue
            await pageObject.click('text=Continue');
    
            // Fill input[type="password"]
            await pageObject.fill('input[type="password"]', 'Automcmpuser@00');
    
            // Click button:has-text("Log in")
            await pageObject.click('button:has-text("Log in")');
    
            // Click text=I Accept
            await Promise.all([
                pageObject.click('text=I Accept')
            ]);
            //Dont need anything in calling function, so dont return anything from use method
            //await use(loggedIn);
            await pageObject.context().storageState({ path: 'state.json' });
            await use();

    }       

});

module.exports = {
    test : it,
    expect : test.expect
}




