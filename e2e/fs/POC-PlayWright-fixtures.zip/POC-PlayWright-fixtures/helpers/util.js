function getFrame(page){
    var pageWithFrame;
    pageWithFrame = page.frame({
        name: 'mcmp-iframe'
    });
    return pageWithFrame;

};

module.exports = {
    getFrame : getFrame 
}