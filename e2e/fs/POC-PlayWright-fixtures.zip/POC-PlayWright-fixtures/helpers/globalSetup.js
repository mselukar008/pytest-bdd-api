

// global.loginToConsume = async function () {    
    
//     page.goTo(browser.params.url).then(function () {
//         logger.info("Launched browser and navigated to URL: " + browser.params.url);
//         browser.sleep(5000);
// 	    //Hybrid Authentication
//         element(by.xpath(btnSampAppXpath)).isPresent().then(function (status) {
//             if (status) {
//                 element(by.xpath(btnSampAppXpath)).click().then(function () {
//                     logger.info("Clicked on Authentication using SAML type button");
//                 });

//                 browser.wait(EC.visibilityOf(element(by.css(txtBoxEmailCss))), 60000).then(function () {
//                     element(by.css(txtBoxEmailCss)).sendKeys(browser.params.username).then(function () {
//                         logger.info("Entered username - " + browser.params.username);
//                         browser.wait(EC.elementToBeClickable(element(by.css(btnNextCss))), 60000).then(function () {
//                             element(by.css(btnNextCss)).click().then(function () {
//                                 logger.info("Clicked on Next button");
//                                 browser.wait(EC.visibilityOf(element(by.css(txtBoxPwdCss))), 60000).then(function () {
//                                     element(by.css(txtBoxPwdCss)).sendKeys(browser.params.password).then(function () {
//                                         logger.info("Entered password ");
//                                         browser.wait(EC.elementToBeClickable(element(by.css(btnSignInCss))), 60000).then(function () {
//                                             element(by.css(btnSignInCss)).click().then(function () {
//                                                 logger.info("Clicked on Sign In button");
//                                             });
//                                             element(by.css(btnStatySignInNoCss)).click().then(function () {
//                                                 logger.info("Clicked on Staty Sign in - No button");
//                                             });
//                                         });
//                                     });
//                                 });

//                             });
//                         });
//                     });
//                 });
//             }
//         });    
//         element(by.xpath(w3IdLinkXpath)).isPresent().then(function (w3) {
//             // For Tenant with w3id
//             if (w3 == true) {
//                 browser.wait(EC.visibilityOf(element(by.xpath(w3IdLinkXpath))), 60000).then(function () {
//                     element(by.xpath(w3IdLinkXpath)).click().then(function () {
//                         logger.info("Clicked on w3id MFA link..");
//                     })
//                 })
//             }
//             // For Tenant with IBM/NON-IBM id
//             else {
//                 element(by.css(usernameId)).isPresent().then(function (res) {
//                     if (res == false) {
//                         browser.wait(EC.visibilityOf(element(by.css(username))), 90000).then(function () {
//                             logger.info("Waited till Username text box is visible on the page");
//                             element(by.css(username)).clear().then(function () {
//                                 logger.info("Cleared Username input box");
//                                 element(by.css(username)).sendKeys(browser.params.username).then(function () {
//                                     logger.info("Entered " + browser.params.username + " in Username input box");
//                                     browser.wait(EC.visibilityOf(element(by.css(continueBtn))), 10000).then(function () {
//                                         logger.info("Waited till Continue button is visible on login page");
//                                         element(by.css(continueBtn)).click().then(function () {
//                                             logger.info("Clicked on Continue button");
//                                             browser.sleep(5000);
//                                         });
//                                     });
//                                 });
//                             });
//                         }).catch(function (err) {
//                             logger.info("Username field is not displayed");
//                         });
//                     }
//                 });
//                 if ((browser.params.username).toString().includes("ibm.com")) {
//                     browser.sleep(5000);
//                     element(by.xpath(w3IdLinkXpath)).isPresent().then(function (w3) {
//                         if (w3 == true) {
//                             browser.wait(EC.visibilityOf(element(by.xpath(w3IdLinkXpath))), 60000).then(function () {
//                                 element(by.xpath(w3IdLinkXpath)).click().then(function () {
//                                     logger.info("Clicked on w3id MFA link..");
//                                 })
//                             })
//                         }
//                     });
//                 }
//             }
//         });

//         // For IBM id
//         if ((browser.params.username).toString().includes("ibm.com")) {
//             browser.wait(EC.visibilityOf(element(by.css(w3idUsernameCss))), 60000).then(function () {
//                 logger.info("Waited till Username text box is visible on the page");
//                 element(by.css(w3idUsernameCss)).clear().then(function () {
//                     logger.info("Cleared Username input box");
//                     element(by.css(w3idUsernameCss)).sendKeys(browser.params.username).then(function () {
//                         logger.info("Entered " + browser.params.username + " in Username input box");
//                         browser.wait(EC.visibilityOf(element(by.css(w3idPasswordCss))), 30000).then(function () {
//                             logger.info("Waited till Password input box is visible on login page");
//                             element(by.css(w3idPasswordCss)).sendKeys(browser.params.password).then(function () {
//                                 logger.info("Entered password input box");
//                                 element(by.css(w3idSignBtnCss)).click().then(function () {
//                                     logger.info("Clicked on Sign In button");
//                                     browser.sleep(5000);
//                                 });
//                             });
//                         });
//                     });
//                 });
//             });
//         }
//         // For NON-IBM id
//         else {
//             element(by.css(password)).isPresent().then(function (value) {
//                 if (value) {
//                     browser.wait(EC.visibilityOf(element(by.css(password))), 10000).then(function () {
//                         logger.info("Waited till Password input box is visible on login page");
//                         element(by.css(password)).sendKeys(browser.params.password).then(function () {
//                             logger.info("Entered password input box");
//                             element(by.css(loginBtn)).click().then(function () {
//                                 logger.info("Clicked on Log In button");
//                                 browser.sleep(5000);
//                             });
//                         });
//                     });
//                 }
//                 else {
//                     browser.wait(EC.visibilityOf(element(by.css(username))), 30000).then(function () {
//                         logger.info("Waited till Username text box is visible on the page");
//                         element(by.css(username)).clear().then(function () {
//                             logger.info("Cleared Username input box");
//                             element(by.css(username)).sendKeys(browser.params.username).then(function () {
//                                 logger.info("Entered " + browser.params.username + " in Username input box");
//                                 browser.wait(EC.visibilityOf(element(by.css(password))), 30000).then(function () {
//                                     logger.info("Waited till Password input box is visible on login page");
//                                     element(by.css(password)).sendKeys(browser.params.password).then(function () {
//                                         logger.info("Entered password input box");
//                                         element(by.css(signinbutton)).click().then(function () {
//                                             logger.info("Clicked on Sign In button");
//                                             browser.sleep(5000);
//                                         });
//                                     });
//                                 });
//                             });
//                         });
//                     }).catch(function (err) {
//                             logger.info("Username field is not displayed");
//                     });
//                 }
//         	});
//         }

		
// 	});
		
//     browser.wait(EC.visibilityOf(element(by.css(w3idOtpTextBoxCss))), 30000).then(async function (){
// 		logger.info("Navigated to Authorize this device page");
//         var passCode = await apiUtil.getGoogleAuthPassCode(secretKey);
//         logger.info("Generated passcode : ", passCode);
//         browser.wait(EC.visibilityOf(element(by.css(w3idOtpTextBoxCss))), 60000);
//         element(by.css(w3idOtpTextBoxCss)).sendKeys(passCode).then(function(){
//             element(by.css(w3idOtpSubmitBtnCss)).click().then(function(){
//                 logger.info("Clicked on submit button");
//             });
//         });
// 	}).catch(function(){
// 		logger.info("Authorization page is not displayed");
// 	});
    		 
// 	browser.wait(EC.urlContains("/privacy"), 60000).then(function () {
// 		logger.info("Navigated to privacy page...");
// 		browser.wait(EC.visibilityOf(element(by.css(noticeHeaderCss))), 60000).then(function (){
// 			element(by.css(noticeHeaderCss)).isDisplayed().then(function (result) {
// 				if (result  == true) {
// 					logger.info("Privacy policies page displayed...");							
// 					element(by.css(privacyPolicyAcceptBtnCss)).click().then(function(){
// 						logger.info("Clicked on I accept button in the Privacy statement page...")
// 					});	
// 				}
// 			});
// 		});
// 	});

// 	browser.wait(EC.urlContains("/launchpad"), 60000).then(function () {
//         	logger.info("Waited till browser url contains /launchpad");               
//     	}).catch(function(err){//Handle timeout exception as further handling is available in catalog.open function for other test
//         	logger.info("Launchpad page is not displayed");
//     });
// }

module.exports = async ({}) => {
    const { chromium } = require('playwright');
    const browser = await chromium.launch(); 
    const page = await browser.newPage();
    await page.goto('https://mcmp-stagedal-master-autoui.multicloud-ibm.com/');

    // Fill input[type="text"]
    await page.fill('input[type="text"]', 'uiautomcmpuser@outlook.com');

    // Click text=Continue
    await page.click('text=Continue');

    // Fill input[type="password"]
    await page.fill('input[type="password"]', 'Automcmpuser@00');

    // Click button:has-text("Log in")
    await page.click('button:has-text("Log in")');
   
    // Click text=I Accept
    await Promise.all([
        page.waitForNavigation(/*{ url: 'https://mcmp-stagedal-master-autoui.multicloud-ibm.com/launchpad' }*/),
        page.click('text=I Accept')
    ]);

};