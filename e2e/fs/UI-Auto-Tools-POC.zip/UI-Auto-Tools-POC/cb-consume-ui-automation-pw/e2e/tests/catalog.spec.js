describe("Kyndryl Bridge-Catalog", () => {   

    it('Catalog - Validate Service Details and count on Catalog page', async () => {
        const [title, subtitle] = await catalogPage.getPageDetails()
        expect(title).toEqual(genericTestData.catalogPageTitle)
        expect(subtitle[0]).toEqual(genericTestData.catalogPageSubTitle1)
        expect(subtitle[1]).toEqual(genericTestData.catalogPageSubTitle2)
        await catalogPage.verifyServiceCount()
    })

    it('Catalog - Search Service and Validate its visible', async () => {
        await catalogPage.searchService(genericTestData.searchService)
        await catalogPage.verifyServiceCount()
        const services = await catalogPage.getDisplayedServices()
        expect(services[0]).toEqual(genericTestData.searchService)
    })

    it('Catalog - Apply Category filter and verify applied filter', async () => {
        await catalogPage.applyCategogy(genericTestData.filter)
        await catalogPage.verifyServiceCount()
        const filters = await catalogPage.getAppliedFilterName()
        expect(filters[1]).toEqual(genericTestData.filter)        
    })

    it('Catalog - Apply Delivery Method filter and verify applied filter', async () => {
        await catalogPage.applyDeliveryMethod(genericTestData.deliveryMethod)
        await catalogPage.verifyServiceCount()
        const filters = await catalogPage.getAppliedFilterName()
        expect(filters[1]).toEqual(genericTestData.deliveryMethod)        
    })
})