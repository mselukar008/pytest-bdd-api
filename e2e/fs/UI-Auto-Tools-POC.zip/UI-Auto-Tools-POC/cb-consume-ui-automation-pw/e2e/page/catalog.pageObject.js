"use strict";

var locatorsConfig = {
    pageTitleCss : "h2",
    pageSubtitleCss : "h6",
    totalServicesCountCss: "[class*='kd-text filterSummary_item_count_label']",
    totalServicesCardsCss: "[class*='kCard_catalogContent'] span[class*='Card_title']",
    searchServicesCss: "input[name='search_textbox']",
    categoryDropdownCss: "[class='categoryDataDiv'] span",
    checkBoxCss: "input[name='%s']",
    filetrNameCss:"[class*='filterListContainer']",
    filterDropDownXpath:"//*[text()='%s']/../../preceding-sibling::div/span",

};

exports.catalog = class catalog {
    constructor(Page) {
        this.page = Page;
    }; 
    
    async getPageDetails(){
        const title = await commonUiMethods.getText(locatorsConfig.pageTitleCss, "Main Title")
        const subtitle = await commonUiMethods.getTextArray(locatorsConfig.pageSubtitleCss, "Catalog Page Subtitle")
        return [title, subtitle]
    }

    async getViewingCount(){
        let count =  await commonUiMethods.getText(locatorsConfig.totalServicesCountCss, "Services Viewing Count")
        return count.split(" ")[1]
    }

    async getCountOfDisplayedServices(){
        let serviceCardsCount = await commonUiMethods.getTextArray(locatorsConfig.totalServicesCardsCss, "Service Cards Count");
        return serviceCardsCount.length
    }

    async getDisplayedServices(){
        return await commonUiMethods.getTextArray(locatorsConfig.totalServicesCardsCss, "Service Cards Count");       
    }

    async searchService(serviceName){
        await commonUiMethods.sendKeysEnter(locatorsConfig.searchServicesCss, "Search Any Service", serviceName)
        await commonUiMethods.sleep(1000)
    }

    async applyCategogy(category){
        await commonUiMethods.click(locatorsConfig.filterDropDownXpath.replace("%s", "Category"), "Category Dropdown")
        await commonUiMethods.click(locatorsConfig.checkBoxCss.replace("%s", category), category)
    }

    async applyDeliveryMethod(dm){
        await commonUiMethods.click(locatorsConfig.filterDropDownXpath.replace("%s", "Delivery Method"), "Delivery Method")
        await commonUiMethods.click(locatorsConfig.checkBoxCss.replace("%s", dm), dm)
    }

    async applyCustomerReview(customerReview){
        await commonUiMethods.click(locatorsConfig.filterDropDownXpath.replace("%s", "Customer Reviews"), "Customer Reviews")
        await commonUiMethods.click(locatorsConfig.checkBoxCss.replace("%s", customerReview), customerReview)
    }

    async verifyServiceCount(){
        const viewingCount = await this.getViewingCount()
        const serviceCardsCount = await this.getCountOfDisplayedServices()
        expect(parseInt(viewingCount)).toEqual(serviceCardsCount)
    }

    async getAppliedFilterName(){
        await this.page.waitForSelector(locatorsConfig.filetrNameCss)
        return await commonUiMethods.getTextArray(locatorsConfig.filetrNameCss, "Applied Filter");
    }


}