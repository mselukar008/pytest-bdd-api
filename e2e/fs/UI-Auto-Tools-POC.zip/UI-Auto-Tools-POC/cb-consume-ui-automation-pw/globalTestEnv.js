
const { catalog } = require('./e2e/page/catalog.pageObject');
const { commonMethods } = require('./helpers/commonMethods');
const { customReporter } = require('./helpers/customReporter');
const genericTestData  = require('./testData/genericData.json');
const timeOuts = require('./testData/timeouts.json');
const loginUtil = require('./helpers/globalLogin');
const testConfig = require('./jest-playwright.config');

beforeEach(async() => {
    await page.goto(testConfig.environment)    
})

beforeAll(async () => {
    //Login to Applications
    await loginStore(testConfig.environment, testConfig.userName, testConfig.password);
    
    //Defining global Objects to be used across each test suite
    global.catalogPage = new catalog(page);    
    global.commonUiMethods = new commonMethods(page);
    global.Reporter = new customReporter(page);  
    
    //Generic Test Data file that can be used across all tests for common verification
    global.genericTestData = genericTestData;
    global.timeOuts = timeOuts;
    global.testConfig = testConfig;    
        
});
