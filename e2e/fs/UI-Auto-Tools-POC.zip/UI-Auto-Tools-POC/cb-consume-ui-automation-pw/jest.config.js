const util = require('./helpers/util.js');
var plConfig = require('./jest-playwright.config.js');
var testPath = util.generateRuntimeSpecString(plConfig.testSuitList);

module.exports = {
  verbose: true,
  collectCoverage: false,
  rootDir: './',
  globalSetup: '<rootDir>/helpers/setup.js',
  //globalTeardown:'<rootDir>helpers/globalTearDown.js',
  testMatch: testPath,
  testEnvironment: "<rootDir>customEnvironment.js",
  testRunner: "jest-circus/runner",  
  setupFilesAfterEnv: [
    "<rootDir>globalTestEnv.js",
    "<rootDir>helpers/jest.setup.js",        
  ],
  preset: 'jest-playwright-preset', 
  reporters: [
    "default",
    ["jest-html-reporters", {
      "publicPath": "./Reports/htmlReports",
      "filename": "Test Execution Summary.html",
      "expand": true,
      "openReport": false
    }],
    ["jest-junit", {
      "suiteName": "Automation Suite",
      "outputDirectory": "./Reports/Junit/",
      "outputName": "junit.xml",
    }],
    ["jest-stare", {
      "resultDir": "./Reports/jest-stare/",
      "reportTitle": "jest-stare!",
      "additionalResultsProcessors": [
        "jest-junit"
      ],
      "coverageLink": "../../coverage/lcov-report/index.html",
      "jestStareConfigJson": "jest-stare.json",
      "jestGlobalConfigJson": "globalStuff.json",
      "watchPathIgnorePatterns": [
        ".*jest-stare.*\\.js"
      ]
    }],

  ]

}

