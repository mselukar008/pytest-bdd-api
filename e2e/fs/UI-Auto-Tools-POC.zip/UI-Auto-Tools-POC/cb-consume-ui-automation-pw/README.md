# cb-consume-ui-automation-pw

# Installation

--All Dev depndencies are available in package.json. After cloning repo, do npm install in project root folder

# IDE

--Any JS friendly IDE you can use for development, recommended is visual studio code.

# Test Run Configuration - 
Please update jest-playwright.config.js file for your test configuration. Below are the parameters.
--browsers = chromium | firefox | webkit
--channel = chrome,ms-edge ; applicable for chromium browsres only
--environment:test environment url,
--userName:username for login,
--password:password for login,
--isDummyAdapterDisabled:"true" for Real and "false" for dummy,
--isProvisioningRequired:"true" for e2e flows and "false" for sanity flows ,
--defaultCurrency:"USD", change it for non-usd tenants like GBP,EURO
--skipImiConfig:set as "false" if imi configurations are onboarded, "true" if environment dont have imi configuration
--postSlack:"false",
--postSlackWebhookURL:"slack webhook url",
--buildURL:"",
--testSuitList:"Name of test suites to run,should be comma separated in case of multiple suites" 

# Global Objects for tests -
All page objects are declared and initialised globally once before each test specification file. This is done inside global beforeAll hook, implementation can be found in ./globalTestEnv.js file located at root folder.
 mainParamPage,catalogPage,placeOrderPage,ordersPage,orderHistoryPage,orderedServicesPage,commonUiMethods,poCommonMethods,orderflow,Reporter,mcmpIframe,
 genericTestData,timeOuts, pwConfig

--commonUiMethods -->Contains implementations of web native events(click,select,sendkey etc) methods. All synchronisation and element handlings are done at element level.
--mainParamPage-->Page object having methods of elements on main parameter page
--catalogPage-->Page object having methods of elements on catalogPage page
--placeOrderPage-->Page object having methods of elements on placeOrderPage page
--ordersPage-->Page object having methods of elements on ordersPage page
--orderHistoryPage-->Page object having methods of elements on orderHistoryPage page
--orderHistoryPage-->Page object having methods of elements on orderedServicesPage page
--poCommonMethods -->Some elements are common accross all pages, implementation for those elemnts is under this file.
--orderflow -->Generic function for handling additional parameter pages and filling order details.
--Reporter -->This is mapped to custom reporting file that has implementation for printing logs on console and reporting the steps to allure report.
--mcmpIframe -->Iframe of application
--genericTestData -->Test data file that contains data common to all services like order status, validation strings. etc
--timeOuts -->File with timeouts specific to element, navigations and other custom flows.
--pwConfig -->Playwright configuration as defined in jest-playwright.config.js

# Sequential Test Execution
In package.json under scripts, use "test": "jest -i -c jest.config.js && nyc report --reporter=lcovonly"
# Parallel Test Execution 
In package.json under scripts, use "test": "jest -c jest.config.js && nyc report --reporter=lcovonly"

For running test, open terminal and hit npm run test command. Make sure to update jest-playwright.config.js file before running tests.

# Test Development

-Test file needs only import of test data file.
-Make use of global page objects for creating test cases. Page objects element implementaion can be done using commonUiMethods and then these methods needs to be called inside tests.
-jest hooks and annotations are used for writing tests.
-For writing validations use expect from jest.

# Reports
-Test Execution output can be viewed under ./Reports folder.
-It contains html/xml reports, video recordings, har, trace etc files.
