// jest-playwright.config.js

module.exports = {   
      
    exitOnPageError: false,     
    browsers: ["chromium"],
    
    launchType: "LAUNCH", 
    launchOptions: {
        channel:'chrome', //This is supported for chromium. Options are 'chrome' or 'msedge', 'chrome-beta', 'msedge-beta', 'msedge-dev', etc.
        headless: true
    },
    contextOptions: {
        ignoreHTTPSErrors: true,        
        viewport:null
    },       
                   
    // Local Test Configuration Parameters   
    environment:"https://portal-ui-story-test-playwright-canary.devtest-lb-bridge.kyndryl.com/platform/catalog",        
    userName:"teamkp",
    password:"kpwownow1978",
    testSuitList:"catalog" 
    
}
