
const plConfig = require('../jest-playwright.config');
const logGenerator = require('./logGenerator');
const logger = logGenerator.getApplicationLogger();

module.exports = async () => {
    
    logger.info("=====================Test Execution started ======================================");
    logger.info("Environment : " + plConfig.environment);
    logger.info("UserName : " + plConfig.userName);
    logger.info("Password : " + plConfig.password);    
    logger.info("testSuitList : " + plConfig.testSuitList); 
    logger.info("=====================================================================================");   
  }