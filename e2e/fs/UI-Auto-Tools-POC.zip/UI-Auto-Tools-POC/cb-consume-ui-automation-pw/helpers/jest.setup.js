//Set jest All script timeout on top of playwright's 30s timeout
//This is maximum time a particular test case will take to run.
jest.setTimeout(500 * 1000);
//Set Retry count for Jest in case of failed tests
jest.retryTimes(1);