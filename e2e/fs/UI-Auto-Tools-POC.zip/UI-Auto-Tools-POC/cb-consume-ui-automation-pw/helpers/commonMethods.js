"use strict";

exports.commonMethods = class commonMethods{

    constructor(Page) {
        this.page = Page;
    };

    //Static wait
    async sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    };
        
    //Click on elemnt
    async click(elmLocator, elemName){
        await Promise.all([
            this.sleep(1000),                 
            this.page.locator(elmLocator).click(),
            this.page.waitForLoadState(),
            Reporter.info("Clicked on " + elemName)
        ])
    }
    //type value in textbox and hit enter button
    async sendKeysEnter(elmLocator, elemName, value) { 
        await Promise.all([
            this.syncWithUi(),        
            this.page.waitForSelector(elmLocator),
            this.page.locator(elmLocator).fill(value),        
            this.page.locator(elmLocator).press("Enter"),       
            Reporter.info("Entered value : " + value + " in textbox : " + elemName)
        ])       
               
    }
    //Entering text in textbox
    async sendKeys(elmLocator, value, elemName) {
        await Promise.all([
            this.syncWithUi(),
            this.page.waitForSelector(elmLocator),
            this.page.locator(elmLocator).fill(value),
            this.waitForLoaderToComplete(),       
            Reporter.info("Entered value : " + value + " in textbox : " + elemName)
        ])        
    }
    
    //For Selecting RadioButtons and checkbox
    async check(elemLocator, elemName, value){
        await Promise.all([
            this.syncWithUi(),
            this.page.waitForSelector(elemLocator),
            this.page.locator(elemLocator).check(elemLocator),             
            Reporter.info("Checked " + elemName)
        ])        
    }
    
    //Get text of element
    async getText(elmLocator, elmName){         
        await this.page.waitForSelector(elmLocator);
        var elem = await this.page.$(elmLocator);
        var txt = await elem.innerText();
        if(elmName != undefined){
            await Reporter.info(elmName  + " : " + txt);
        }        
        return txt;
    }

    //Return all matching elements collection based on locator
    async getElementsList(elmLocator){
        //Wait till page loads completely
        await this.syncWithUi();        
        await this.page.waitForSelector(elmLocator);
        return await this.page.$$(elmLocator);
    }

    //Get specific attribute of webelement
    async getAttribute(elemLocator, attrbtName) {        
        await this.page.waitForSelector(elemLocator);
        return await this.page.getAttribute(elemLocator, attrbtName);
    }

    //Must be called before performing any native event
    //event : load, domcontentloaded,framattached,framedetached,framenavigated etc.Refer documentation
    async waitForEvent(event) {
        if(event != undefined){
            await this.page.waiForEvent(event); 
        }else{//Wait until the page is completely loaded within 3 mins
            await this.page.waiForEvent("load");
        }
        
    }
    //Must be called after performing native event
    //Options are load by default and domcontentloaded, networkidle
    async waitForLoadState() {
        await this.page.waitForLoadState("networkidle")
    }
   
    async syncWithUi (){
        //Wait till spinner loading completes
        await Promise.all([           
            this.page.waitForLoadState()           
        ])        
    }
    //Returns an array of text matching locator
    async getTextArray(elemLocator){
        var elemList = await this.getElementsList(elemLocator);        
        var textArray = await Promise.all((elemList.map(async (elem, index) => {        
            return await elem.innerText()
        })))
        return textArray;
    }

    async getPageTitle(){
        return await this.page.title();
    }

}