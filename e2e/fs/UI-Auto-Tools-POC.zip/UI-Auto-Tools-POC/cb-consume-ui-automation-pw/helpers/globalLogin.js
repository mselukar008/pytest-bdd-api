var logGenarator = require('../helpers/logGenerator'),
logger = logGenarator.getApplicationLogger();

global.loginStore = async function(url, userName, pwd) {    
    context = await browser.newContext({
        httpCredentials: {
            username: userName,
            password: pwd
        }
    })    
    page = await context.newPage()
    //Close original browser    
    await browser.contexts()[0].close();
    await page.goto(url);     
    logger.info("Navigated to " + url);
    await page.setViewportSize({width: 1280, height: 650});   
};







