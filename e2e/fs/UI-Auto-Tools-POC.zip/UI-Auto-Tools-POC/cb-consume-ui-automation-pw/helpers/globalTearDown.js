const util = require('./util');

module.exports = async function globalTeardown(){    
    //delete cookies file
    await util.deleteFile('./Cookies/state.json');    
}