/// <reference types="Cypress"/>
import LoginPage from '../page-objects/LoginPage'
import LaunchpadPage from '../page-objects/LaunchpadPage'
import CatalogPage from '../page-objects/catalogPage'
import CatalogManagement from '../page-objects/catalogManagement'
import ApproveOrderPage from '../page-objects/approveOrderPage'
import OrderHistoryPage from '../page-objects/orderHistoryPage'
import UserAccessPage from '../page-objects/userAccessPage'
var launchpadTestData = require('../fixtures/launchpadTestData.json')

describe('Login to MCMP and Navigate to launchpad links', function(){
	var launchpadPage = new LaunchpadPage()
	var catalogPage = new CatalogPage()
	var catalogManagement = new CatalogManagement()
	var approveOrderPage = new ApproveOrderPage()
	var orderHistoryPage = new OrderHistoryPage()
	var userAccessPage = new UserAccessPage()
	var arrayObj = null
	before(function() {
		//cy.recordHar();
        cy.fixture('loginDetails').then(function(data){
			arrayObj = data
        }).then(function(){
			cy.loginToMCMP(arrayObj.username, arrayObj.password)
		})
    })

	after(function(){
		cy.logoutFromMCMP()
		//cy.saveHar();
	})

	it('Verify MCMP Page header', () => {
		cy.title().should('include', 'IBM')
		launchpadPage.clickOnMCMPHeaderPage()
		launchpadPage.getMCMPHeaderPageText().should('include', 'Multicloud Management')
  	})

	it('Verify able to click on Catalog Management Link from left navigation', () => {
		launchpadPage.clickOnMCMPHeaderPage()
		launchpadPage.getMCMPHeaderPageText().should('include', 'Multicloud Management')
		launchpadPage.clickOnHamburgerMenu(launchpadTestData.leftNavigationExpanded)		
		launchpadPage.clickOnleftNavigationMenuBasedOnName(launchpadTestData.enterpriseMarketplaceBtn)
        launchpadPage.clickLeftNavLinkBasedOnName(launchpadTestData.catalogManagement)
		catalogManagement.getPageHeaderTitle().should('include', 'Catalog Management')
  	})
	
	it('Verify able to click on Order History Link from left navigation', () => {
		launchpadPage.clickOnMCMPHeaderPage()
		launchpadPage.getMCMPHeaderPageText().should('include', 'Multicloud Management')
		launchpadPage.clickOnHamburgerMenu(launchpadTestData.leftNavigationExpanded)		
		launchpadPage.clickOnleftNavigationMenuBasedOnName(launchpadTestData.enterpriseMarketplaceBtn)
        launchpadPage.clickLeftNavLinkBasedOnName(launchpadTestData.orderHistory)
		orderHistoryPage.getPageHeaderTitle().should('include', 'Order History')
  	})
	
	it('Verify able to click on Approve Orders Link from left navigation', () => {
		launchpadPage.clickOnMCMPHeaderPage()
		launchpadPage.getMCMPHeaderPageText().should('include', 'Multicloud Management')
		launchpadPage.clickOnHamburgerMenu(launchpadTestData.leftNavigationExpanded)		
		launchpadPage.clickOnleftNavigationMenuBasedOnName(launchpadTestData.enterpriseMarketplaceBtn)
        launchpadPage.clickLeftNavLinkBasedOnName(launchpadTestData.approveOrder)
		approveOrderPage.getPageHeaderTitle().should('include', 'Orders')
  	})
	
	it('Verify able to click on Catalog Link from left navigation', () => {
		launchpadPage.clickOnMCMPHeaderPage()
		launchpadPage.getMCMPHeaderPageText().should('include', 'Multicloud Management')
		launchpadPage.clickOnHamburgerMenu(launchpadTestData.leftNavigationExpanded)		
		launchpadPage.clickOnleftNavigationMenuBasedOnName(launchpadTestData.enterpriseMarketplaceBtn)
        launchpadPage.clickLeftNavLinkBasedOnName(launchpadTestData.catalogLink)
		catalogPage.getPageHeaderTitle().should('include', 'Catalog')
  	})
	
})