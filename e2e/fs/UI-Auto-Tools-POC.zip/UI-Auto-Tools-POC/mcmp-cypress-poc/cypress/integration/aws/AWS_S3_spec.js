/// <reference types="Cypress"/>
import LaunchpadPage from '../../page-objects/LaunchpadPage'
import CatalogPage from '../../page-objects/catalogPage'
import CatalogManagement from '../../page-objects/catalogManagement'
import ApproveOrderPage from '../../page-objects/approveOrderPage'
import OrderHistoryPage from '../../page-objects/orderHistoryPage'
import UserAccessPage from '../../page-objects/userAccessPage'
var launchpadTestData = require('../../fixtures/launchpadTestData.json')
var awsS3TestData = require('../../fixtures/aws/AWSS3Instance.json')

describe('e2e S3 Service Instance', function(){
	var launchpadPage = new LaunchpadPage()
	var catalogPage = new CatalogPage()
	var catalogManagement = new CatalogManagement()
	var approveOrderPage = new ApproveOrderPage()
	var orderHistoryPage = new OrderHistoryPage()
	var userAccessPage = new UserAccessPage()
	var arrayObj = null
	before(function() {
        cy.fixture('loginDetails').then(function(data){
			arrayObj = data
        }).then(function(){
			cy.loginToMCMP(arrayObj.username, arrayObj.password)
		})
    })

	after(function(){
		cy.logoutFromMCMP()
	})

	it('Verify able to select S3 service from Catalog page', function(){
		launchpadPage.clickOnMCMPHeaderPage()
		launchpadPage.getMCMPHeaderPageText().should('include', 'Multicloud Management')
		launchpadPage.clickOnHamburgerMenu(launchpadTestData.leftNavigationExpanded)		
		launchpadPage.clickOnleftNavigationMenuBasedOnName(launchpadTestData.enterpriseMarketplaceBtn)
        launchpadPage.clickLeftNavLinkBasedOnName(launchpadTestData.catalogLink)
		catalogPage.getPageHeaderTitle().should('include', 'Catalog')
        catalogPage.clickOnProviderCheckBox(awsS3TestData.provider)
        catalogPage.searchServiceInstanceName(awsS3TestData.bluePrintName)
        catalogPage.clickOnServiceInstanceName(awsS3TestData.bluePrintName)
        catalogPage.clickOnConfigureButton()
  	})

	it('Verify able to submit S3 service order', function(){
		launchpadPage.clickOnMCMPHeaderPage()
		launchpadPage.getMCMPHeaderPageText().should('include', 'Multicloud Management')
		launchpadPage.clickOnHamburgerMenu(launchpadTestData.leftNavigationExpanded)		
		launchpadPage.clickOnleftNavigationMenuBasedOnName(launchpadTestData.enterpriseMarketplaceBtn)
        launchpadPage.clickLeftNavLinkBasedOnName(launchpadTestData.catalogLink)
		catalogPage.getPageHeaderTitle().should('include', 'Catalog')
        catalogPage.clickOnProviderCheckBox(awsS3TestData.provider)
        catalogPage.searchServiceInstanceName(awsS3TestData.bluePrintName)
        catalogPage.clickOnServiceInstanceName(awsS3TestData.bluePrintName)
        catalogPage.clickOnConfigureButton()
        catalogPage.fillOrderDetails(awsS3TestData)
		catalogPage.clickOnSubmitOrderBtn()
		catalogPage.getOrderNumer()
		catalogPage.clickOnGoToCatalogBtn()
  	})
	
})