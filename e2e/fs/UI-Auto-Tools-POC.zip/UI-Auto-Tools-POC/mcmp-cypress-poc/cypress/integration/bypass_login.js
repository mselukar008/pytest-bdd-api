describe('By pass login', () => {
  it('By pass Login to MCMP Page', () => {
		cy.request({
			//url: "https://mcmp-stagedal-master-autoui.multicloud-ibm.com/api/iam/v4/identity",
			url: "https://login.ibm.com/v1/mgmt/idaas/user/identitysources",
			method: 'POST',
			body: {
				//user: 'uiautomcmpuser@outlook.com',
				//password: 'Automcmpuser@00'
				user: "uiautomcmpuser@outlook.com", 
				oidcUrl: true
			}
		}).then(res => cy.log(res))
	})
})