// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

import LoginPage from '../page-objects/LoginPage'
import LaunchpadPage from '../page-objects/LaunchpadPage'
var loginPage = new LoginPage()
var launchpadPage = new LaunchpadPage()
Cypress.Commands.add('loginToMCMP', (username, password) => {
    cy.visit('/')
    cy.title().should('include', 'IBM')
    loginPage.sendUserName(username)
    loginPage.clickOnContinueButton()
    loginPage.sendPassword(password)
    loginPage.clickOnSignInButton()
    loginPage.clickOnIAcceptButton()
})

Cypress.Commands.add('logoutFromMCMP', ()=> {
    launchpadPage.clickOnMCMPHeaderPage()
    launchpadPage.clickOnUserIBMIcon()
    launchpadPage.clickOnLogoutIcon()
    //launchpadPage.getLogoutText().should('include', 'successfully logged out')
})