var extend = require('extend');
import utils from '../utils/util'
var defaultConfig = {
    headerTitleCss : ".ibm--page-header__title"
};	

function catalogManagement(selectorConfig) {
    if (!(this instanceof catalogManagement)) {
        return new catalogManagement(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

catalogManagement.prototype.getPageHeaderTitle = function(){
    utils.loadFrame()
    return cy.iframe().find(this.headerTitleCss).then(function(element){
        return element.text()
    })
}

module.exports = catalogManagement;