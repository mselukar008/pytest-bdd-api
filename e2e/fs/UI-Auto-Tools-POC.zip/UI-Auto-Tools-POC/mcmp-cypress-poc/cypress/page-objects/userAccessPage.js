var extend = require('extend');
import utils from '../utils/util'
var defaultConfig = {
    headerTitleCss : ".ibm--page-header__title"
};	

function userAccessPage(selectorConfig) {
    if (!(this instanceof userAccessPage)) {
        return new userAccessPage(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

userAccessPage.prototype.getPageHeaderTitle = function(){
    utils.loadFrame()
    return cy.iframe().find(this.headerTitleCss).then(function(element){
        return element.text()
    })
}

module.exports = userAccessPage;