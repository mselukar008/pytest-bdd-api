var extend = require('extend');
var launchpadTestData = require('../fixtures/launchpadTestData.json');
var defaultConfig = {
    mcmpHeaderCss : '.bx--header__name__title',
    hamburgerLinkCss: "ibm-hamburger svg",
    userIconCss : 'ibm-icon-user-avatar.ibm-icon svg',
    logoutBtnCss : 'button[ibmbutton="primary"]',
    loggedOutTextCss : 'logout h1',
	loginBtn : 'button[ibmbutton="primary"]',
    leftNavBarCss : 'sidebar ibm-sidenav',
    crossSymbolCss:	"ibm-hamburger svg[ibmIcon='close']",
    textLeftNavLinkCss: 'a.bx--side-nav__link span',
    leftBtnSubmenuCss: '.bx--side-nav__submenu-title',
    leftBtnSubmenuParentCss: 'button.bx--side-nav__submenu'
};	

function LaunchpadPage(selectorConfig) {
    if (!(this instanceof LaunchpadPage)) {
        return new LaunchpadPage(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

LaunchpadPage.prototype.clickOnMCMPHeaderPage = function(){
	cy.wait(1000)
    return cy.get(this.mcmpHeaderCss).click({ force: true }).then(function(){
		cy.wait(2000)
	})
}

LaunchpadPage.prototype.getMCMPHeaderPageText = function(){
    return cy.get(this.mcmpHeaderCss).then(function(element){
        return element.text()
    })
}

LaunchpadPage.prototype.clickOnUserIBMIcon = function(){
    return cy.get(this.userIconCss).click({ force: true })
}

LaunchpadPage.prototype.clickOnLogoutIcon = function(){
    return cy.get(this.logoutBtnCss).click({ force: true })
}

LaunchpadPage.prototype.getLogoutText = function(){
	cy.wait(1000)
    return cy.get(this.loggedOutTextCss).invoke('attr', 'innerText').then(function(innerText){
        return innerText
    })
}

LaunchpadPage.prototype.clickOnHamburgerMenu = function(actionPerform){
	var self= this;
	return self.getHamburgerNavigationStatus().then(function(status){
		if(actionPerform == status){
		}else if(actionPerform != status){
			return cy.get(self.hamburgerLinkCss).click({ force: true })
		}
	});
};


LaunchpadPage.prototype.getHamburgerNavigationStatus = function(){
	var self= this;
    var status;
	return cy.get(self.leftNavBarCss).invoke('attr', 'class').then(function(res){
		console.log("res : ", res)
		if(res.includes(launchpadTestData.leftNavigationExpanded)) {
			status = launchpadTestData.leftNavigationExpanded;
			console.log("Status : ", status)
		}
		else if(res.includes(launchpadTestData.leftNavigationPinned)) {
			status = launchpadTestData.leftNavigationPinned;
			console.log("Status : ", status)
		}
		else {
			status = launchpadTestData.leftNavigationHidden;
			console.log("Status : ", status)
		}			
	    return status;
	});
};


LaunchpadPage.prototype.clickLeftNavLinkBasedOnName = function(linkName){
    var self= this;
	return cy.get(self.textLeftNavLinkCss).then(function(links){
		for(var i=0; i<links.length; i++) {			
			if(links.get(i).innerText.trim() == linkName) {
				cy.log("links["+i+"].innerText", links.get(i).innerText)
				return links.get(i).click({ force: true })
			}			
		}		
	});
};


LaunchpadPage.prototype.clickToExpandLeftNavButton = function(navBtn){
    var self= this;
	return cy.get(self.leftBtnSubmenuCss).then(function(btns){
		for(var i=0; i<btns.length; i++) {	
			if(btns.get(i).innerText==navBtn) {
				cy.log("btns["+i+"].invoke('text')", btns.get(i).innerText)
				return cy.get(btns[i]).click({ force: true })			
			}		
		}
	});
};


LaunchpadPage.prototype.clickOnleftNavigationMenuBasedOnName = function(navBtn){
	var self = this;
	return cy.get(self.leftBtnSubmenuCss).then(function(btns) {
		for(var i=0;i<btns.length;i++) {
			if(btns.get(i).innerText==navBtn) {
				cy.get(self.leftBtnSubmenuParentCss).eq(i).invoke('attr', 'aria-Expanded').then(function(res){
					cy.log("res:::::", res)
					if(res=="false" || res=="null" || res==null || res == undefined){
						cy.log("From if block")
						return self.clickToExpandLeftNavButton(navBtn)
					}									
				});
			}
		}
	});
};


module.exports = LaunchpadPage;