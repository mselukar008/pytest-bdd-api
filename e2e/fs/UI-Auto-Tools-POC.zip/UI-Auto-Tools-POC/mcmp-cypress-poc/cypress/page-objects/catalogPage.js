var extend = require('extend');
import utils from '../utils/util'
import orderFlowUtil from '../utils/orderFlowUtil'
var defaultConfig = {
    headerTitleCss : ".ibm--page-header__title",
    searchServiceNameCss : "#search__input-store-catalog-search-id",
    serviceTitleCss : ".card-service-title",
    configureBtnCss : "#configure-service",
    submitOrderBtnCss : "#primary-btn-review-order",
    orderNumberDetailsCss : "#order-number",
    goToServiceCatalogBtnCss : "#order-submitted-modal_carbon-button"
};	

function catalogPage(selectorConfig) {
    if (!(this instanceof catalogPage)) {
        return new catalogPage(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

catalogPage.prototype.getPageHeaderTitle = function(){
    utils.loadFrame()
    return cy.iframe().find(this.headerTitleCss).then(function(element){
        return element.text()
    })
}

catalogPage.prototype.clickOnProviderCheckBox = function(providerCheckBoxName){
    cy.wait(2000)
    utils.loadFrame()
    return cy.iframe().find("[name='"+providerCheckBoxName+"']").scrollIntoView().click({ force: true })
}

catalogPage.prototype.searchServiceInstanceName = function(serviceNameInstance){
    cy.wait(2000)
    utils.loadFrame()
    return cy.iframe().find(this.searchServiceNameCss).type(serviceNameInstance)
}

catalogPage.prototype.clickOnServiceInstanceName = function(serviceNameInstance){
    cy.wait(2000)
    utils.loadFrame()    
    return cy.iframe().find(this.serviceTitleCss).then(function($serviceName){
        for(var i=0; i<$serviceName.length; i++) {			
            console.log("$serviceName.get(i).innerText.trim()", $serviceName.get(i).innerText.trim())
			if($serviceName.get(i).innerText.trim() == serviceNameInstance) {
				return $serviceName.get(i).click({ force: true })
			}			
		}
    })
}

catalogPage.prototype.clickOnConfigureButton = function(){
    cy.wait(2000)
    utils.loadFrame()
    return cy.iframe().find(this.configureBtnCss).click({ force: true })
}

catalogPage.prototype.clickOnSubmitOrderBtn = function(){
    cy.wait(2000)
    utils.loadFrame()
    return cy.iframe().find(this.submitOrderBtnCss).click({force : true})
}

catalogPage.prototype.getOrderNumer = function(){
    cy.wait(2000)
    utils.loadFrame()
    cy.log('order number :: ', cy.iframe().find(this.orderNumberDetailsCss).invoke('text'))
    var orderNumber = ""
    cy.iframe().find(this.orderNumberDetailsCss).invoke('text').then(function(ObjectValues){
        var json = JSON.stringify(ObjectValues);
        var obj = JSON.parse(json);
        for(var keys in obj){
            cy.log("key ", keys, "Values ", obj[keys])
            orderNumber = orderNumber + obj[keys]
        }
        cy.log("orderNumber ::: ",orderNumber)
    })
    return orderNumber.trim()
}

catalogPage.prototype.clickOnGoToCatalogBtn = function(){
    cy.wait(2000)
    utils.loadFrame()
    return cy.iframe().find(this.goToServiceCatalogBtnCss).click({force : true})
}

catalogPage.prototype.fillOrderDetails = function(orderDetailsTestData){
    orderFlowUtil.fillMainParameterDetails(orderDetailsTestData.Main_Parameters)
    orderFlowUtil.fillAdditionalParameterDetails(orderDetailsTestData.Additional_Parameter)  
}

module.exports = catalogPage;