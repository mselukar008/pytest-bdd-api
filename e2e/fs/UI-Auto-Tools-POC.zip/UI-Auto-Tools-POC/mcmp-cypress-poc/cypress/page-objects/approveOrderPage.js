var extend = require('extend');
import utils from '../utils/util'
var defaultConfig = {
    headerTitleCss : ".ibm--page-header__title"
};	

function approveOrderPage(selectorConfig) {
    if (!(this instanceof approveOrderPage)) {
        return new approveOrderPage(selectorConfig);
    }
    extend(this, defaultConfig);

    if (selectorConfig) {
        extend(this, selectorConfig);
    }
}

approveOrderPage.prototype.getPageHeaderTitle = function(){
    utils.loadFrame()
    return cy.iframe().find(this.headerTitleCss).then(function(element){
        return element.text()
    })
}

module.exports = approveOrderPage;