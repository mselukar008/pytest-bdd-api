
/**
 * Created by : Pushpraj
 * created on : 22/06/2021
 */

 "use strict";
 var extend = require('extend');

 var defaultConfig = {
    usernameCss : '#username',
    continueBtnCss : '#continue-button',
    passwordCss : '#password',
    signInBtnCss : '#signinbutton',
    iAcceptPrivacyCss : 'button#privacy-accept'
 };	
 
 
 function LoginPage(selectorConfig) {
     if (!(this instanceof LoginPage)) {
         return new LoginPage(selectorConfig);
     }
     extend(this, defaultConfig);
 
     if (selectorConfig) {
         extend(this, selectorConfig);
     }
 }
 
 LoginPage.prototype.sendUserName = function(username){
     return cy.get(this.usernameCss).type(username)
 }
 
 LoginPage.prototype.clickOnContinueButton = function(){
     return cy.get(this.continueBtnCss).click()
 }
 
 LoginPage.prototype.sendPassword = function(password){
     return cy.get(this.passwordCss).type(password)
 }
 
 LoginPage.prototype.clickOnSignInButton = function(){
     return cy.get(this.signInBtnCss).click()
 }
 
 LoginPage.prototype.clickOnIAcceptButton = function(){
     return cy.get(this.iAcceptPrivacyCss).click()
 }
 
 
 module.exports = LoginPage;