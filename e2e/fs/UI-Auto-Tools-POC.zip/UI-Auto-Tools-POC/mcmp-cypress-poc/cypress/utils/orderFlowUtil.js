/// <reference types="Cypress"/>
import utils from '../utils/util'

function fillMainParameterDetails(parameterType){
    cy.log("Fill main parameter order details")
    var keys = Object.keys(parameterType)
    var values = Object.values(parameterType)
    cy.log("keys.length ", keys.length)    
    for(var i = 0; i < keys.length; i++){
        cy.log("values[i] ", values[i])
        var json = JSON.stringify(values[i]);
        var obj = JSON.parse(json);
        this.fillOrderDetails(obj.type, obj.css, obj.value)
    }
    this.clickOnNextButton()
}

function fillAdditionalParameterDetails(parameterType){
    cy.log("Fill additional parameter order details")
    var keys = Object.keys(parameterType)
    var values = Object.values(parameterType)
    cy.log("keys.length ", keys.length)    
    for(var i = 0; i < keys.length; i++){
        for(var subKeys in values[i]){
            var json = JSON.stringify(values[i][subKeys]);
            var obj = JSON.parse(json);
            this.fillOrderDetails(obj.type, obj.css, JSON.stringify(obj.value))
        }
        this.clickOnNextButton()
    }
}

function fillOrderDetails(elementType, locator, jsonValue){
    var parameterValue = jsonValue.replace(/\"/g, "")
    cy.log("elementType :: "+ elementType, "locator :: "+ locator, "parameterValue :: "+ parameterValue)
    utils.loadFrame()
    if(elementType == "Textbox"){
        cy.wait(2000)
        cy.iframe().find(locator).click({force: true})
        return cy.iframe().find(locator).type(parameterValue)
    }
    if(elementType == "RadioButton"){
        cy.wait(2000)
        return cy.iframe().find(locator).scrollIntoView().click({ force: true })
    }
    if(elementType == "InputOptions"){
        cy.wait(2000)
        cy.iframe().find(locator +" .bx--dropdown-text").scrollIntoView().click({ force: true }).then(function(){
            return cy.iframe().find(locator +" .bx--search-input").type(parameterValue).then(function(){
                cy.wait(1500)
                return cy.iframe().find(locator +" .bx--search-dropdown").click({force: true})
            })
        })
    }
    if(elementType == "Dropdown"){
        cy.wait(2000)
        return cy.iframe().find(locator +" .bx--dropdown-text").scrollIntoView().click({ force: true }).then(function(){
            cy.iframe().find('[placeholder="Enter search text"]').clear()
            cy.wait(1500)
            return cy.iframe().find('[placeholder="Enter search text"]').type(parameterValue).then(function(){
                cy.wait(1500)
                return cy.iframe().find(locator + " .bx--dropdown-link").click({force: true})
            })
        })
    }
    if(elementType == "Button"){
        cy.wait(2000)
        cy.iframe().find(locator).click({force: true})
    }
}

function clickOnNextButton(){
    utils.loadFrame()
    return cy.iframe().find("button[title='Next']").scrollIntoView().should('be.visible').then(function(){
        return cy.iframe().find("button[title='Next']").click({force: true})
    })
}

module.exports = {
    fillOrderDetails: fillOrderDetails,
    fillMainParameterDetails : fillMainParameterDetails,
    fillAdditionalParameterDetails : fillAdditionalParameterDetails,
    clickOnNextButton : clickOnNextButton
}