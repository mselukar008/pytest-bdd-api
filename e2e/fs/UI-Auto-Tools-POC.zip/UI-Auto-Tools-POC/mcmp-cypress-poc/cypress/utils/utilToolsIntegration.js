var httpRequest = require('request-promise');
const fs = require('fs');
var mochawesome = require('../../mochawesome.json')

function postToSlack(){
    return new Promise((resolve,reject)=>{
        var boolValue = (true);
        console.log("post-to-slack? "+boolValue);
        if (boolValue){
            console.log("Initiating consolidation of test results....");            
            var testExecutiontitle = "UI Automation Test results:\n Environment URL: \n Build URL: "
            console.log("Consume UI Automation Test results:\n URL: ");
            var totalCount = mochawesome.stats.tests;
            console.log("Total Test Suite Count: "+ totalCount);
            var totalPassed = mochawesome.stats.passes;
            var totalFailed = mochawesome.stats.failures;
            var totalSkipped = mochawesome.stats.skipped;
            var body = "testExecutiontitle \ntotalCount \ntotalPassed \ntotalFailed \ntotalSkipped";

            body = body.replace("testExecutiontitle", testExecutiontitle.toString()+"\n");
            body = body.replace("totalCount", "Total TestCases Executed : " +totalCount.toString());
            body = body.replace("totalPassed", "Passed : " +totalPassed.toString());
            body = body.replace("totalFailed", "Failed : " +totalFailed.toString());
            body = body.replace("totalSkipped", "Skipped : " +totalSkipped.toString()+"\n");
            console.log("Test Summary: \n"+body)
            console.log('Posting test summary to slack....');
            var reqOptions={
                method: 'POST',
                //url:"https://hooks.slack.com/services/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",
                url:"https://hooks.slack.com/services/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",
                body:{"text": body
                },
                json:true
            };

            httpRequest(reqOptions).then( function(httpResponse) {
                console.log('Response after posting to slack: \n' + httpResponse.toString());
                resolve(httpResponse.toString());
            })
            .catch(function (err) {
                console.error('Error during posting to slack: \n'+err.toString());
                reject(err);
                return;
            }); 
    
        }else {
            console.warn("Skipped posting to Slack.")
        }
    });
};

module.exports = {
    postToSlack : postToSlack
};



