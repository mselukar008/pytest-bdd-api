///<reference types="Cypress"/>
///<reference types="Cypress-iframe"/>
import 'cypress-iframe';

function loadFrame(){
    cy.frameLoaded("#mcmp-iframe")
}

module.exports = {
    loadFrame : loadFrame
}