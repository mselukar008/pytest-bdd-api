package com.autoui.fwk.enums;

/**
 * This ENUM defines the differenet error codes thrown by the framework
 *
 * @author rama.bisht
 */
public enum ErrorCode {
    INVALID_PARAMETER_VALUE;
}
