package com.autoui.fwk.core;

public interface IPageObject {

}
