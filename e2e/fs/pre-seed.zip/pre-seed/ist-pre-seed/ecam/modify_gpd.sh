#!/bin/bash
# arg #1 new period in format YYYY-MM
# arg #2 choose options to rename the dates in csv files
#   - YYYY-MM    # keep the original day of the period
#   - YYYY-MM-DD # replace the ordignal day for 1st day and 2nd day of the period
# example 1: ./tools/ecam_gpd_modify_date.sh.sh '2020-09' 'YYYY-MM'
# example 2: ./tools/ecam_gpd_modify_date.sh.sh '2020-10' 'YYYY-MM-DD'
#

readonly NEW_PERIOD=$1
readonly NEW_PERIOD2=${NEW_PERIOD//-}
readonly BASE_DIR=$3
readonly INPUT_DIR="${BASE_DIR}gpd"
readonly OUTPUT_DIR="${BASE_DIR}gpd_artifacts_${NEW_PERIOD}"


#clean gpd out folder
echo 'Cleaning gpd outdir'
rm -R -f $OUTPUT_DIR
mkdir $OUTPUT_DIR

#copy gpd files
echo 'Coping original gpd'
cp -R $INPUT_DIR/* $OUTPUT_DIR

#changes period dates
cd $OUTPUT_DIR
if [ $2 == "YYYY-MM" ]
then
    echo 'Editing csv, format: YYYY-MM'
    find . -type f -name '*.csv' | xargs sed -ie "s+20[1-2][0-9]-[0-9][0-9]-+${NEW_PERIOD}-+g"
    find . -type f -name '*.csve' -delete
    find . -type f -name '*.csv' | xargs sed -ie "s+20[1-2][0-9]-[0-9]-+${NEW_PERIOD}-+g"
    find . -type f -name '*.csve' -delete
    find . -type f -name '*.csv' | xargs sed -ie "s+20[1-2][0-9][0-9][0-9]+${NEW_PERIOD2}+g"
    find . -type f -name '*.csve' -delete
elif [ $2 == "YYYY-MM-DD" ]
then
    echo 'Editing csv, format: YYYY-MM-DD'
    find . -type f -name '*.csv' | xargs sed -ie "s+20[1-2][0-9]-[0-9][0-9]-[0-9][0-9]+${NEW_PERIOD}-01+g"
    find . -type f -name '*.csve' -delete
    find . -type f -name '*.csv' | xargs sed -ie "s+20[1-2][0-9]-[0-9]-[0-9][0-9]+${NEW_PERIOD}-01+g"
    find . -type f -name '*.csve' -delete
    find . -type f -name '*.csv' | xargs sed -ie "s+20[1-2][0-9][0-9][0-9]+${NEW_PERIOD2}+g"
    find . -type f -name '*.csve' -delete
    find . -type f  -name "C_*.csv" | while read F
    do
        awk -F ',' "{gsub(\"${NEW_PERIOD}-01\",\"${NEW_PERIOD}-02\",\$5); print}" OFS="," ${F} > tmp && mv tmp ${F}
        awk -F ',' "{gsub(\"${NEW_PERIOD}-01\",\"${NEW_PERIOD}-02\",\$7); print}" OFS="," ${F} > tmp && mv tmp ${F}
    done
    find . -type f -name '*.csve' -delete
    find . -type f -name '*.tmp' -delete
else
    echo '#### BAD OPTION OR MISSING #####'
fi


#rename files
echo 'Renaming csv files'
for f in $(find . -type f -name '*.csv'); do mv "$f" "${f/_20[1-2][0-9][0-9][0-9]/_${NEW_PERIOD2}}"; done

#rename folders
echo 'Renaming period folders'
for f in $(find . -type d -name '20[1-2][0-9][0-9][0-9]'); do mv "$f" "${f/20[1-2][0-9][0-9][0-9]/${NEW_PERIOD2}}"; done

echo 'Renaming gpd folders'
for f in $(find . -type f -name '.DS_Store'); do rm "${f}"; done
for f in $(ls); do mv "$f" "${f}_${NEW_PERIOD}_1000"; done


#zip folders
echo 'Zipping gpd files'
for f in $(ls | grep -v ".zip"); do zip -q -r "${f}.zip" "${f}"; done

#remove folders
echo 'Removing gpd directories'
for f in $(ls | grep -v ".zip"); do rm -r "${f}"; done