from core.payload_helper import ProviderCode


class GPDStatus:
    VALID = 'VALID'
    VALIDATING = 'VALIDATING'
    WAITING = ['UPLOADED', 'PROCESSING']


class JobStatus:
    COMPLETED = 'Completed'
    INITIALIZEERROR = 'InitializeError'
    PARTIALLY_COMPLETED = 'PartiallyCompleted'


class ProviderMetadataCategory:
    LOCATIONS = 'locations'
    SERVICE_CATEGORIES = 'service_categories'


def report_builder(expression, scope="", vtags=None):
    return {
        "append": True,
        "description": "",
        "scope": scope,
        "type": "v1",
        "vtags": [
            vtags
        ],
        "expr": expression
    }


def gpd_cleanup_builder(gpd_upload_ref_id):
    return {"GPDUploadRefId": gpd_upload_ref_id}


def policy_builder(policy_name, threshold, status):
    return {
        "policyName": policy_name,
        "threshold": threshold,
        "policyStatus": status
    }

def dashboard_builder(id_, date):
    return [
        {
            "_id": id_,
            "reports": [
                {

                    "reference": "cm_app.json",
                    "chartType": "GeomapChart",
                    "title": "Application GeomapChart",
                    "description": "this chart shows the cost for team spent ",
                    "size": 5,
                    "order": 1,
                    "filter": [
                        {
                            "period": date
                        }
                    ],
                    "stackBy": "period",
                    "groupBy": "category",
                    "accumulate": "cost"
                }
            ]
        }
    ]


def provider_ingestion(aws=False, azure=False, gcp=False, ibmcloud=False, **custom_providers):
    payload = {'providers': []}
    if aws:
        payload['providers'].append(ProviderCode.AWS)
    if azure:
        payload['providers'].append(ProviderCode.AZURE)
    if gcp:
        payload['providers'].append(ProviderCode.GOOGLE)
    if ibmcloud:
        payload['providers'].append(ProviderCode.SOFTLAYER)
    for key, value in custom_providers.items():
        if value is True:
            payload['providers'].append(key)
    return payload


def drg_builder(id_, type, expression, context, budgetary_unit=None,):
    if budgetary_unit:
        return {
            "_id": id_,
            "type": type,
            "vattributes": [],
            "budgetaryUnitCode": budgetary_unit,
            "expr": expression,
            "context": context
        }
    else:
        return {
            "_id": id_,
            "type": type,
            "version": "1",
            "expr": expression,
            "context": context
        }
