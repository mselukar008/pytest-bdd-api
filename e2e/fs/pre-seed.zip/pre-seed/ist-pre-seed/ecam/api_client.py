from copy import deepcopy
import math
import os
import time

from core.api_client import CoreApiClient
from utils.api_client_base import Route
from utils import read_in_chunks


CHUNK_SIZE = 1048576  # 1MB


class EcamApiClient(CoreApiClient):
    def get_insights_dashboard(self, id_):
        return self.get(Route('insights/v1/dashboard-management/dashboards/{id}', {'id': id_}))

    def get_insights_job_status(self, id_):
        return self.get(Route('insights/v1/jobs/{id}/status', {'id': id_}))

    def retry_insights_job(self, id_):
        return self.patch(Route('insights/v1/jobs/retry', query_parameters={'id': id_}), {})

    def fail_insights_job(self, id_):
        return self.put(Route('insights/v1/jobs/{id}/status', {'id': id_}), {})

    def get_policies(self):
        return self.get(Route('insights/v1/policies/policy'))

    def update_policy(self, payload):
        return self.put(Route('insights/v1/policies/policy'), payload)

    def get_insights_report_models(self):
        return self.get(Route('insights/v1/reportmodels/all'))

    def get_insights_report_model(self, id_):
        return self.get(Route('insights/v1/reportmodels/{id}/run', {'id': id_}))

    def download_report_model(self, id_, format_, file_name, client_time, template_params=None):
        return self.get(Route('insights/v1/reportmodels/{id}/download',
            {'id': id_},
            query_parameters={'templateParams': template_params, 'format': format_, 'file_name': file_name, 'clientTime': client_time})
        )

    def get_report_model(self, id_, tempalate_params=None, override=None):
        return self.get(Route('api/ecam/v1/reportModels/{id}', {'id': id_}, query_parameters={'override': override, 'templateParams': tempalate_params}))

    def get_report_models(self, size=None, search_text=None):
        return self.get(Route('api/ecam/v1/reportModels', query_parameters={'size': size, 'searchText': search_text}))

    def get_report_model_execution(self, id_, template_params=None, pid=None, limit=None, sort=None, order=None, operator=None, report=None):
        return self.get(Route('api/ecam/v1/reportModels/{id}/execution',
            {'id': id_},
            query_parameters={'templateParams': template_params, 'pid': pid, 'limit': limit, 'sort': sort, 'order': order, 'operator': operator, 'report': report})
        )

    def delete_report_model(self, id_):
        return self.delete(Route('api/ecam/v1/reportModels/{id}', {'id': id_}))

    def get_report_query(self, id_):
        return self.get(Route('api/report/query/{id}', {'id': id_}))

    def create_report_model(self, id_, template_id, save_output, payload):
        return self.post(Route(
            'api/ecam/v1/reportModels/{id}',
            {'id': id_},
            query_parameters={'templateId': template_id, 'saveOutput': save_output}),
            payload
        )

    def update_report_model(self, id_, payload):
        return self.put(Route(
            'api/ecam/v1/reportModels/{id}',
            {'id': id_}),
            payload
        )

    def patch_report_model(self, id_, payload):
        return self.put(Route(
            'api/ecam/v1/reportModels/{id}',
            {'id': id_}),
            payload
        )

    def get_costs_date(self, team='cam_admin_team'):
        return self.get(Route('costs/get/default/date/', query_parameters={'team': team}))

    def get_costs_in_month(self, month, page="1", order_by=None, sort_order=None, filters=None, team='cam_admin_team'):
        return self.get(Route(
            'costs/in/month/{month}',
            {'month': month},
            query_parameters={'page': page, 'orderBy': order_by, 'sortOrder': sort_order, 'filters': filters, 'team': team})
        )

    def get_assets_date(self, team='cam_admin_team'):
        return self.get(Route('assets/get/default/date/', query_parameters={'team': team}))

    def create_dashboard(self, payload):
        return self.post(Route('api/ecam/v1/dashboard'), payload)

    def update_dashboard(self, payload):
        return self.put(Route('api/ecam/v1/dashboard'), payload)

    def get_dashboards(self):
        return self.get(Route('api/ecam/v1/dashboard'))

    def delete_dashboard(self, id_):
        return self.get(Route('api/ecam/v1/dashboard/{id}', {'id': id_}))

    def get_enrichment_jobs(self, page=1, size=10, most_recent=None):
        return self.get(Route(
            'api/ecam/v1/enrichmentController/jobs',
            query_parameters={'pageNo': page, 'size': size, 'mostRecent': most_recent})
        )

    def get_enrichment_job(self, id_):
        return self.get(Route('api/ecam/v1/enrichmentController/jobs', query_parameters={'jobId': id_}))

    def get_enrichment_providers(self):
        return self.get(Route('api/ecam/v1/enrichmentController/providers'))

    def enrichment_ingestion(self, payload):
        return self.post(Route('api/ecam/v1/enrichmentController/ingestion'), payload)

    def get_enrichment_last_updated(self):
        return self.get(Route('api/ecam/v1/enrichmentController/lastUpdatedDate'))

    def do_house_keeping(self):
        return self.post(Route('orc/ecam/v1/housekeeping'), {})

    def create_provider_metadata(self, mapping_category, provider_name, payload):
        return self.post(Route(
            'api/ecam/v1/providermetadata/{mapping_category}',
            {'mapping_category': mapping_category},
            query_parameters={'providername': provider_name}),
            payload
        )

    def get_provider_metadata(self, mapping_category, provider_name, payload):
        return self.get(Route(
            'api/ecam/v1/providermetadata/{mapping_category}',
            {'mapping_category': mapping_category},
            query_parameters={'providername': provider_name}),
            payload
        )

    def update_provider_metadata(self, mapping_category, provider_name, payload):
        return self.patch(Route(
            'api/ecam/v1/providermetadata/{mapping_category}',
            {'mapping_category': mapping_category},
            query_parameters={'providername': provider_name}),
            payload
        )

    def create_gpd_enrich(self, payload):
        return self.post(Route('api/ecam/v1/gpd/enrich'), payload)

    def cleanup_gpd(self, provider_name, payload):
        return self.post(Route('api/ecam/v1/gpd/cleanup', query_parameters={'providername': provider_name}), payload)

    def upload_gpd(self, provider_name, files):
        return self.upload(Route('api/ecam/v1/gpd', query_parameters={'providername': provider_name}), files=files)

    def upload_gpd_chunks(self, provider_name, file_path):
        status_code, response_body = None, None
        with open(file_path, 'rb') as f:
            content_path = os.path.abspath(file_path)
            content_size = os.stat(content_path).st_size
            num_chunks = math.ceil(content_size / CHUNK_SIZE)
            identifier = int(round(time.time() * 1000))
            for i, chunk in enumerate(read_in_chunks(f, CHUNK_SIZE)):
                self.temp_headers = deepcopy(self._headers)
                self.temp_headers.pop('Content-Type', None)
                self.temp_headers['Accept'] = '*/*'
                self.temp_headers['Accept-Encoding'] = 'gzip, deflate, br'
                status_code, response_body = self.upload(Route('api/ecam/v1/gpd/chunks', query_parameters={
                    'providername': provider_name,
                    'resumableChunkNumber': i+1,
                    'resumableChunkSize': CHUNK_SIZE,
                    'resumableCurrentChunkSize': len(chunk),
                    'resumableTotalSize': content_size,
                    'resumableType': 'application/zip',
                    'resumableIdentifier': identifier,
                    'resumableFilename': os.path.basename(file_path),
                    'resumableRelativePath': file_path,
                    'resumableTotalChunks': num_chunks
                }), files={"file": chunk})
        return status_code, response_body

    def get_providers_gdp(self, provider_name):
        return self.get(Route('api/ecam/v1/gpd', query_parameters={'providername': provider_name}))

    def get_collection(self, name):
        return self.get(Route('api/ecam/v1/query/collections/{name}', {'name': name}))

    def get_key_collection(self, name, key):
        return self.get(Route('api/ecam/v1/query/collections/{name}/keys/{key}', {'name': name, 'key': key}))

    def create_drg(self, payload):
        return self.post(Route('api/ecam/v1/dynamicResourceGroups'), payload)

    def get_drgs(self):
        return self.get(Route('api/ecam/v1/dynamicResourceGroups'))

    def update_drg(self, payload):
        return self.put(Route('api/ecam/v1/dynamicResourceGroups'), payload)

    def patch_drg(self, payload):
        return self.put(Route('api/ecam/v1/dynamicResourceGroups'), payload)

    def delete_drg(self, id_):
        return self.delete(Route('api/ecam/v1/dynamicResourceGroups/{id}', {'id': id_}))
