#!/usr/bin/env python3
import argparse
import concurrent.futures
import os
from multiprocessing import Process
from random import random
import shutil
import subprocess
import time

from requests import codes

from ecam.payload_helper import GPDStatus
from ecam import enrichment_helper as EnrichmentHelper
from utils import create_logger
from utils.object_storage_client import us_east


global_ecam_data_dir = 'ecam-data'
global_gpd_base_dir = 'gpd'
global_bucket_name = 'long-ist-gpd'
global_max_valid_wait = 1800 #30 minutes
global_md_check_interval = 360 #6 minutes
global_sm_check_interval = 120 #2 minutes
global_not_option = ['n', 'N']


def get_template_files(filenames, secret_key, logger):
    shutil.rmtree(global_ecam_data_dir, ignore_errors=True)
    for filename in filenames:
        if not os.path.exists(global_ecam_data_dir):
            os.mkdir(global_ecam_data_dir)
        file_path = os.path.join(global_ecam_data_dir, filename)
        client = us_east(secret_key, logger)
        logger.info(f'Getting GPD zip file {str(filename)}')
        if client.get_zip_object(global_bucket_name, filename, file_path)[0] == codes.OK:
            logger.info(f'Unzipping file {str(filename)}')
            unzip_file_downloaded(filename, logger)
        else:
            raise Exception(f'Error getting {str(filename)} from {str(global_bucket_name)}')


def unzip_file_downloaded(filename, logger):
    try:
        bash_command = f'cd {global_ecam_data_dir} && unzip -q ' + str(filename)
        logger.debug(bash_command)
        output_bash_command = subprocess.check_call(bash_command,shell=True)
    except Exception as ex:
        logger.error(f'Error unziping {str(filename)}. Ex: {str(ex)}')
    try:
        base_filename = filename.replace(".zip","")
        bash_command = f'cd {global_ecam_data_dir} && mkdir -p {global_gpd_base_dir} && mv {str(base_filename)} {os.path.join(global_gpd_base_dir, base_filename)}'
        logger.debug(bash_command)
        output_bash_command = subprocess.check_call(bash_command,shell=True)
    except Exception as ex:
        logger.error(f'Error renaming directory to gpd. Ex: {str(ex)}')


def create_gpd_periods(periods, logger):
    jobs = []
    logger.info('Creating GPD zip files per period')
    for period in periods:
        job = Process(target=execute_modify_script, args=(period, logger))
        jobs.append(job)
        job.start()

    for job in jobs:
        job.join()

    for job in jobs:
        job.terminate()


def execute_modify_script(period, logger, format='YYYY-MM', directory=global_ecam_data_dir):
    bash_command = f"./{os.path.join('ecam','modify_gpd.sh')} {str(period)} {str(format)} {os.path.join(directory, '')}"
    logger.debug(bash_command)
    output_bash_command = subprocess.check_call(bash_command,shell=True)


def get_gpd_file_path(provider, period):
    gpd_files_path = os.path.abspath(os.path.join(global_ecam_data_dir, f'gpd_artifacts_{str(period)}', ''))
    current_file = ''
    for f in os.listdir(gpd_files_path):
        if provider in f and period in f:
            current_file = os.path.join(gpd_files_path, f)
            break
    return current_file


def upload_gpd_to_tenant(client, provider, period, logger):
    result = None
    try:
        gpd_file_path = get_gpd_file_path(provider, period)
        logger.debug(f'Uploading file {str(os.path.basename(gpd_file_path))}')
        response = client.upload_gpd_chunks(provider, gpd_file_path)
        if response[0] == 200:
            result = response[1]['translateParameters'][0]
    except Exception as ex:
        logger.error(f'Error on upload_gpd_to_tenant. Ex: {str(ex)}')
    return result


def check_current_gpd_file_valid(client, provider, gpd_file_id, logger):
    if gpd_file_id is not None:
        total_waiting_time = 0
        gpd_filename = None
        try:
            file_validated = False
            while not file_validated:
                response = client.get_providers_gdp(provider)
                if response[0] == 200:
                    gpd_files = response[1]['response']
                    for gpd_file in gpd_files:
                        if str(gpd_file['GPDUploadRefId']) == str(gpd_file_id):
                            gpd_file_status = str(gpd_file['status']).upper()
                            gpd_filename = str(gpd_file['filename'])
                            if gpd_file_status == GPDStatus.VALID:
                                logger.info(f'File {str(gpd_filename)} is in {str(gpd_file_status)} status')
                                file_validated = True
                            elif gpd_file_status in GPDStatus.WAITING and total_waiting_time < global_max_valid_wait:
                                new_waiting_time = global_md_check_interval - ((random() * 2) * 60)
                                total_waiting_time = total_waiting_time + new_waiting_time
                                logger.info(f'File {str(gpd_filename)} is in {str(gpd_file_status)} status. Waiting +{"{:.2f}".format(new_waiting_time / 60)} minutes')
                                time.sleep(new_waiting_time)
                            elif gpd_file_status in GPDStatus.VALIDATING and total_waiting_time < global_max_valid_wait:
                                new_waiting_time = global_sm_check_interval - (random() * 60)
                                total_waiting_time = total_waiting_time + new_waiting_time
                                logger.info(f'File {str(gpd_filename)} is in {str(gpd_file_status)} status. Waiting +{"{:.2f}".format(new_waiting_time / 60)} minutes')
                                time.sleep(new_waiting_time)
                            else:
                                raise Exception(f'File {str(gpd_filename)} blocked with status {str(gpd_file_status).upper()}')
                            break
        except Exception as ex:
            logger.error(f'Error on check_current_gpd_file_valid. Ex: {str(ex)}')
        logger.debug(f'Waited time for file {str(gpd_filename)} was {"{:.2f}".format(total_waiting_time / 60)} minutes')


def process_tenant(client, tenant, providers, periods, logger):
    tenant_results = {tenant: {}}
    for provider in providers:
        provider_result = []
        logger.info(f'Uploading provider {str(provider)}')
        for i, period in enumerate(periods):
            gpd_file_id_assigned = upload_gpd_to_tenant(client, provider, period, logger)
            provider_result.append(gpd_file_id_assigned)
            if gpd_file_id_assigned is not None:
                check_current_gpd_file_valid(client, provider, gpd_file_id_assigned, logger)
            else:
                logger.error(f'Error uploading on {str(provider)} gpd file for period {str(period)} in tenant {str(tenant)}')
        tenant_results[tenant][provider] = provider_result
    return tenant_results


def main(gpd_args):
    logger = create_logger('provision_ecam')
    exit_code = 0
    try:
        run(gpd_args.filenames, gpd_args.providers, gpd_args.periods, gpd_args.tenants, gpd_args.userids,
            gpd_args.apikeys, gpd_args.start_enrichment, gpd_args.concurrent_processes, gpd_args.secret, logger)
    except Exception as ex:
        logger.error(f'Failed to execute the run function. Ex: {ex}')
        exit_code = 1
    return exit_code


def run(filenames, providers, periods, tenants, userids, apikeys, start_enrichment, concurrent_processes, secret, logger):
    process_tenant_results = {}
    clients = EnrichmentHelper.create_clients(tenants, userids, apikeys, logger)
    get_template_files(filenames, secret, logger)
    create_gpd_periods(periods, logger)
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrent_processes) as executorUpload:
        future_results = []
        for tenant in clients.keys():
            api_client = clients[tenant]
            future_results.append(executorUpload.submit(process_tenant, api_client, tenant, providers, periods, logger))

        for future_result in concurrent.futures.as_completed(future_results):
            try:
                process_tenant_results.update(future_result.result())
            except Exception as ex:
                logger.error(f'Failed to add results to process_tenant_results. Ex: {ex}')
    if start_enrichment:
        EnrichmentHelper.run(providers, tenants, userids, apikeys, logger, concurrent_processes)


if __name__ == "__main__":
    """
    python3 ecam/provision_helper.py -f ***_**K.zip --providers ***
        --periods YYYY-MM -t *** --userids *** --apikeys *** --concurrent-processes *** (-se|)
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--filenames', nargs='+',
        help='Filename in bucket', required=True)
    parser.add_argument('--providers', nargs='+',
        help='Providers to upload their GPD', required=True)
    parser.add_argument('--periods', nargs='+',
        help='Periods for GPDs to be generated', required=True)
    parser.add_argument('-t', '--tenants', nargs='+',
        help='Targets to upload GPD', required=True)
    parser.add_argument('-cp', '--concurrent-processes', type=int,
        help='How many concurrent tenants', default=1)
    parser.add_argument('--userids', nargs='+',
        help='User IDs to upload GPD to each tenant', required=True)
    parser.add_argument('--apikeys', nargs='+',
        help='API Keys to upload GPD to each tenant', required=True)
    parser.add_argument('-se', '--start-enrichment', action='store_true',
        help='Start Enrichment after upload file', default=False)
    parser.add_argument('-s', '--secret', type=str,
        help='Secret key to be used for encryption',
        default=os.getenv('MCMP_API_AUTOMATION_SECRET'))

    exit(main(parser.parse_args()))
