from requests import codes

from ecam.api_client import EcamApiClient
from ecam import payload_helper
from utils.entities_base import (
    EntityBase,
    EntitiesBase
)


class Entities(EntitiesBase):
    def __init__(self, api_client, data, logger=None):
        super().__init__(api_client, data, logger)
        self.ProviderMetadata = ProviderMetadata(api_client, logger)
        self.ResourceGroup = ResourceGroup(api_client, logger)
        self.Enrichment = Encrichment(api_client, logger)

    @staticmethod
    def create_instance(host: str, user: str, apikey: str, logger, authorization: str):
        headers = EcamApiClient.create_headers(user, apikey, authorization)
        return Entities(
            EcamApiClient(host, headers,
                        logger,
                        {},
                        max_round_trip=300,
                        json_indent=4),
            {},
            logger
        )


class Encrichment(EntityBase):
    def start_public_provider_ingestion(self, payload):
        self.logger.info(f'Starting ingestion for {payload["providers"]}')
        self.request_handler(self.api_client.enrichment_ingestion, payload)
        return self.status_code == codes.OK

    def upload_gpd(self, provider, files):
        self.logger.info('Uploading GPD')
        self.request_handler(self.api_client.upload_gpd, provider, files)
        return self.status_code == codes.ACCEPTED

    def start_custom_provider_ingestion(self, payload):
        self.logger.info(f'Starting ingestion for {payload["providers"]}')
        self.request_handler(self.api_client.create_gpd_enrich, payload)
        return self.status_code == codes.OK

    def wait_for_completed(self, job_id, wait_time=60*90):
        all_good = False
        self.logger.info(f'Waiting for ingestion job {job_id} to be Completed')
        def wait_for_all(status_code, response_body):
            nonlocal all_good
            all_good = status_code == codes.OK and all(x['status'] == payload_helper.JobStatus.COMPLETED or x['status'] == JobStatus.INITIALIZEERROR
                                                       or x['status'] == payload_helper.JobStatus.PARTIALLY_COMPLETED for x in response_body['jobList'])
            return all_good

        self.poll_handler(
            wait_time,
            wait_for_all,
            self.api_client.get_enrichment_job,
            job_id
        )
        return all_good


class ProviderMetadata(EntityBase):
    def create_provider_metadata_service_categories(self, provider_name, payload):
        self.logger.info(f'Creating Provider Metadata Service Categories to {provider_name}')
        self.request_handler(self.api_client.create_provider_metadata,
                             payload_helper.ProviderMetadataCategory.SERVICE_CATEGORIES, provider_name, payload)
        return self.status_code == codes.OK

    def create_provider_metadata_locations(self, provider_name, payload):
        self.logger.info(f'Creating Provider Metadata Locations to {provider_name}')
        self.request_handler(self.api_client.create_provider_metadata,
                             payload_helper.ProviderMetadataCategory.LOCATIONS, provider_name, payload)
        return self.status_code == codes.OK


class ResourceGroup(EntityBase):
    def create_drg(self, payload):
        self.logger.info(f'Creating Dynamic Resource Group {payload["_id"]}')
        self.request_handler(self.api_client.create_drg, payload)
        return self.status_code == codes.OK

    def update_drg(self, payload):
        self.logger.info(f'Updating Dynamic Resource Group {payload["_id"]}')
        self.request_handler(self.api_client.update_drg, payload)
        return self.status_code == codes.OK

    def create_or_update_drg(self, payload):
        ok = self.create_drg(payload)
        if not ok and self.response_body.get("translateCode") == "ECAM400_TAG_EXISTS":
            ok = self.update_drg(payload)
        return ok
