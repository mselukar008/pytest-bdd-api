from core.payload_helper import ProviderCode
from core.pre_seed import CoreData
from ecam import enrichment_helper
from utils import all_helper
from utils.pre_seed_base import PreSeedBase


class ECamPreSeed(PreSeedBase):
    keys = [
        'DRGs',
        'provider_locations',
        'provider_service_categories'
    ]

    def create_data(self):
        return CoreData({})

    def run_script(self, entities) -> list:
        self.error_list.clear()
        self._create_or_update_provider_service_categories(entities)
        self._create_or_update_provider_location(entities)
        self._create_or_update_dynamic_resource_group(entities)
        # TODO: Commenting out for now until we understand how we want this implemented better
        # self._gpd_ingestion(entities)
        return self.error_list

    def _create_or_update_provider_service_categories(self, entities):
        if 'provider_service_categories' in self.data:
            try:
                for provide_code, service_categories in self.data['provider_service_categories'].items():
                    result = entities.ProviderMetadata.create_provider_metadata_service_categories(
                        provide_code, service_categories)
                    if not result:
                        self._log_error(entities.logger,
                            f'Failed to create service categories to {provide_code}'
                        )
            except:
                self._log_exception(entities.logger,
                    'Encountered an exception when creating provider medata: service_categories')

    def _create_or_update_provider_location(self, entities):
        if 'provider_locations' in self.data:
            try:
                for provide_code, locations in self.data['provider_locations'].items():
                    result = entities.ProviderMetadata.create_provider_metadata_locations(
                        provide_code, locations)
                    if not result:
                        self._log_error(entities.logger,
                            f'Failed to create location to {provide_code}'
                        )
            except:
                self._log_exception(entities.logger,
                    'Encountered an exception when creating provider medata: locations')

    def _create_or_update_dynamic_resource_group(self, entities):
        if 'DRGs' in self.data:
            try:
                for drg in self.data['DRGs']:
                    result = entities.ResourceGroup.create_or_update_drg(
                        drg)
                    if not result:
                        self._log_error(entities.logger, f'Failed to create DRG {drg["_id"]}')
            except:
                self._log_exception(entities.logger,
                    'Encountered an exception when creating dynamic resource group')

    def _gpd_ingestion(self, entities):
        if 'provider_locations' in self.data:
            providers = [k for k in self.data['provider_locations'].keys()]
            enrichment_helper.start_tenant_enrichment(entities.api_client, entities.api_client.end_point, providers, entities.logger)
