#!/usr/bin/env python3
import argparse
import concurrent.futures
import time

from ecam.api_client import EcamApiClient
from utils.api_client_base import create_headers
from utils import create_logger


def start_tenant_enrichment(client, tenant, providers, logger):
    try:
        payload = {
            "provider": providers,
            "retry": "true"
        }
        logger.info(f'Starting enrichment for {str(providers)} on tenant {str(tenant)}')
        start_time = time.time()
        response = client.create_gpd_enrich(payload)
        end_time = time.time()
        if response[0] == 200:
            logger.info(f'Enrichment response on tenant {str(tenant)}. {str(response[1])}')
        else:
            logger.error(f'Error on tenant {str(tenant)}. {str(response[1])}')
        logger.debug(f'Response time from tenant {str(tenant)}: {"{:.2f}".format(end_time - start_time)} seconds ({"{:.2f}".format((end_time - start_time) / 60)} min)')
    except Exception as ex:
        logger.error(f'Error on start_tenant_enrichment. Ex: {str(ex)}')


def create_clients(tenants, userids, apikeys, logger):
    client_dict = {}
    try:
        for index, tenant in enumerate(tenants):
            user_id = userids[index]
            api_key = apikeys[index]
            api_client = EcamApiClient(tenant, create_headers((user_id, api_key)), logger)
            client_dict[tenant] = api_client
    except Exception as ex:
        logger.error(f'Error on create_clients. Ex: {str(ex)}')
        raise Exception(f'Error creating clients for tenants {str(tenants)}')
    return client_dict


def main(args):
    logger = create_logger('enrich_ecam')
    run(args.providers, args.tenants, args.userids, args.apikeys, logger, args.concurrent_processes)
    return 0


def run(providers, tenants, userids, apikeys, logger, concurrent_processes=1):
    clients = create_clients(tenants, userids, apikeys, logger)
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrent_processes) as executorEnrich:
            for tenant in clients.keys():
                api_client = clients[tenant]
                executorEnrich.submit(start_tenant_enrichment, api_client, tenant, providers, logger)


if __name__ == "__main__":
    """
    python3 ecam/tools/enrichment_helper.py --providers ***
        -t *** --userids *** --apikeys *** --concurrent-processes *** (-se|)
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--providers', nargs='+',
        help='Providers to start their enrichment', required=True)
    parser.add_argument('-t', '--tenants', nargs='+',
        help='Targets to start enrichment', required=True)
    parser.add_argument('--userids', nargs='+',
        help='User IDs to start enrichment on each tenant', required=True)
    parser.add_argument('--apikeys', nargs='+',
        help='API Keys to start enrichment on each tenant', required=True)
    parser.add_argument('-cp', '--concurrent-processes', type=int,
        help='How many concurrent tenants', default=1)

    exit(main(parser.parse_args()))
