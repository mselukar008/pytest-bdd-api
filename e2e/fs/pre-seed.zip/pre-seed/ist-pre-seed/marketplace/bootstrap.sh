#!/bin/bash
set -o errexit


host=${host:+}
admin_user=${admin_user:+}
apikey=${apikey:+}
multitenant=${multitenant:-true}
encrypted=${encrypted:-true}
templates_version=${templates_version:-master}
setup_properties=${setup_properties:-$(pwd)/marketplace/setup_properties.json}
config=${config:-$(pwd)/ist_provider_creds.conf}
secret=${secret:-$MCMP_API_AUTOMATION_SECRET}
only_update_content=${only_update_content:-false}
aws=${aws:+}
azure=${azure:+}
gcp=${gcp:+}
ibmcloud=${ibmcloud:+}
test=${test:+}
imi=${imi:+}
while [ $# -gt 0 ]; do
    if [[ $1 == *"--"* ]]; then
        param="${1/--/}"
        declare $param="$2"
    fi
    shift
done

update_setup_properties () {
    for index in "${configs[@]}"; do
        KEY="${index%%::*}"
        VALUE="${index##*::}"
        if [[ "$(uname -s)" == "Darwin" ]]; then
            sed -E 's|("'"$KEY"'":)[^,]+(,*)|\1 '"$VALUE"'\2|' $CONSUME_SETUP_PROPERTIES > tmp_prop && mv tmp_prop $CONSUME_SETUP_PROPERTIES
        else
            sed -r 's|("'"$KEY"'":)[^,]+(,*)|\1 '"$VALUE"'\2|' $CONSUME_SETUP_PROPERTIES > tmp_prop && mv tmp_prop $CONSUME_SETUP_PROPERTIES
        fi
    done
}

if [ "$encrypted" = "true" ]; then
    python3 marketplace/encrypt_properties.py --secret $secret --config $config -d
fi
export CONSUME_SETUP_PROPERTIES=$setup_properties

rm -rf cb-consume-bootstrap
git clone git@github.kyndryl.net:MCMP-Integrations/cb-consume-bootstrap.git
cd cb-consume-bootstrap

configs=(
    'host::"'$host'"'
    'admin_user::"'$admin_user'"'
    'apikey::"'$apikey'"'
    'multitenant::"'$multitenant'"'
    'cb_provisioning_template_branch::"'$templates_version'"'
    'load_vra::"true"'
)
if [ "$multitenant" == "true" ]; then
    configs+=('app_user::"'$admin_user'"')
# To get the userid
#     app_user_id=$(curl -s "$host/authorization/v2/users/user/basicinfo" -H "Content-Type:application/json" -H "username:$admin_user" -H "apikey:$apikey" | \
#     python3 -c "import sys, json; response=json.load(sys.stdin)
# if response['usertype'] == 'portal_user':
#     print(response['emails'][0])
# else:
#     print('$admin_user')")
#     configs+=('app_user::"'$app_user_id'"')
fi

if [ -n "$aws" ]; then
    configs+=('load_aws:: "true"')
    configs+=('aws_offering_subset::"'$aws'"')
else
    configs+=('load_aws:: "false"')
fi

if [ -n "$azure" ]; then
    configs+=('load_azure:: "true"')
    configs+=('azure_offering_subset::"'$azure'"')
else
    configs+=('load_azure:: "false"')
fi

if [ -n "$gcp" ]; then
    configs+=('load_gcp:: "true"')
    configs+=('gcp_offering_subet::"'$gcp'"')
else
    configs+=('load_gcp:: "false"')
fi

if [ -n "$ibmcloud" ]; then
    configs+=('load_ibmcloud:: "true"')
    configs+=('ibmcloud_offering_subset::"'$ibmcloud'"')
else
    configs+=('load_ibmcloud:: "false"')
fi

if [ -n "$test" ]; then
    configs+=('load_test:: "true"')
    # todo
    #configs+=('test_offering_subset::"'$test'"')
else
    configs+=('load_test:: "false"')
fi

if [ -n "$imi" ]; then
    configs+=('load_imi:: "true"')
    # todo
    #configs+=('imi_offering_subset::"'$imi'"')
else
    configs+=('load_imi:: "false"')
fi

if [ "$only_update_content" == "false" ]; then
    update_setup_properties
    yes | ./setup.sh -n $CONSUME_SETUP_PROPERTIES -v true 2>&1 | tee ../bootstrap_log.log

    configs=(
        'load_aws::"false"'
        'load_azure::"false"'
        'load_ibmcloud::"false"'
        'load_gcp::"false"'
        'load_vra::"false"'
    )
fi

update_setup_properties
cd ../marketplace
./load_content.sh 2>&1 | tee load_content.log

cd ..
python3 marketplace/encrypt_properties.py --secret $secret

echo $(curl --silent -k -H "Content-Type: application/json" -H "Accept: application/json" -H "username:$admin_user" -H "apikey:$apikey" -X PATCH "$host/catalog/v3/admin/configs/visibilitymodes/4/turnon")

for type in billing asset; do
    for provider in aws azure gcp ibmcloud; do
        account_id=$(curl --silent -k "$host/cb-credential-service/api/v2.0/search?userType=$type&page=1&size=10&searchText=bootstrap_e2esvtapi_&serviceProviderCode%5B%5D=$provider" -H "Content-Type:application/json" -H "username:$admin_user" -H "apikey:$apikey" | \
        python3 -c "import sys, json; data=json.load(sys.stdin)
if len(data) > 1:
    print(data[1]['accountId'])
else:
    print()")
        if [ "$account_id" != "" ]; then
            echo "Deleting $provider $type account"
            echo $(curl -X DELETE "$host/cb-credential-service/api/v2.0/accounts/$account_id" -H "username:$admin_user" -H "apikey:$apikey")
        fi
    done
done