#!/bin/bash

CURRENT=`pwd`
host=$1
apikey_username=$2
apikey=$3

pushd "$CURRENT"/servicedef/azure > /dev/null

service_url=$host/managedservices/imi/providers/azure/servicedefinition
arr=( $(find . -name '*.json') )
echo "$(date)  number of files got as :"${#arr[@]}

for i in ${arr[@]}
do
    filepath=${i//\\//}

    IFS='/' read -ra ADDR <<< "$filepath"

    lastIndexOfFilepath=$(expr ${#ADDR[@]} - 1)
    filename=${ADDR[$lastIndexOfFilepath]}
    echo "Uploading file: " $filename
    command1=$(curl --silent -k -H "Content-Type: application/json" -H "Accept: application/json" -H "username:$apikey_username" -H "apikey:$apikey" -X POST -d  @"$filename" "$service_url")
    echo "$(date)  the response got from server is:: $command1"
done

popd > /dev/null
