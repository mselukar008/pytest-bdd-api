#!/bin/bash

host=$1
apikey_username=$2
apikey=$3

declare -a reslist

providers=(
    "aws::aws"
    "azure::azure"
    "google::gcp"
)

aws_pricing=(
    "AWS::CloudFront::StreamingDistribution"
    "AWS::DynamoDB::Table"
    "AWS::EC2::Instance"
    "AWS::EC2::VPC"
    "AWS::EC2::Volume"
    "AWS::ElastiCache::CacheCluster"
    "AWS::ElasticLoadBalancing::LoadBalancer"
    "AWS::ElasticLoadBalancingV2::LoadBalancer"
    "AWS::Glacier::Vault"
    "AWS::KMS::Key"
    "AWS::Lambda::Function"
    "AWS::RDS::DBInstance"
    "AWS::Redshift::Cluster"
    "AWS::S3::Bucket"
    "AWS::SQS::Queue"
)

azure_pricing=(
    "Microsoft.Network/networkSecurityGroups"
    "Microsoft.Compute/virtualMachines"
    "Microsoft.Compute/disks"
    "Microsoft.Network/virtualNetworks"
    "Microsoft.Network/loadBalancers"
    "Microsoft.Compute/availabilitySets"
    "Microsoft.Network/applicationSecurityGroups"
    "Microsoft.Network/expressRouteCircuits"
    "Microsoft.DBforMySQL/servers"
    "Microsoft.Sql/servers"
    "Microsoft.Network/routeTables"
    "Microsoft.Storage/storageAccounts"
    "Microsoft.Network/dnsZones"
    "Microsoft.DBforPostgreSQL/servers"
    "Microsoft.Cache/Redis"
    "Microsoft.RecoveryServices/vaults"
    "Microsoft.KeyVault/vaults"
    "Microsoft.NotificationHubs/namespaces"
    "Microsoft.NotificationHubs/namespaces/notificationHubs"
    "Microsoft.DocumentDB/databaseAccounts"
    "Microsoft.ContainerRegistry/registries"
    "Microsoft.Relay/Namespaces"
    "Microsoft.Sql/servers/databases"
    "Microsoft.Batch/batchAccounts"
    "Microsoft.Web/serverfarms"
    "Microsoft.Web/sites"
)

google_pricing=(
    "compute.v1.instance"
    "compute.v1.disk"
)

service_defs () {
    CURRENT=`pwd`

    pushd "$CURRENT"/servicedef/$1 > /dev/null

    service_url=$host/managedservices/imi/providers/$2/servicedefinition
    arr=( $(find . -name '*.json') )
    echo "$(date)  number of files: "${#arr[@]}

    for i in ${arr[@]}
    do
        filepath=${i//\\//}

        IFS='/' read -ra ADDR <<< "$filepath"

        lastIndexOfFilepath=$(expr ${#ADDR[@]} - 1)
        filename=${ADDR[$lastIndexOfFilepath]}
        echo "Uploading file: "$filename
        command=$(curl --silent -k -H "Content-Type: application/json" -H "Accept: application/json" -H "username:$apikey_username" -H "apikey:$apikey" -X POST -d  @"$filename" "$service_url")
        echo "$(date) the response got from server is:: $command"
        if [ "$(uname -s)" == "Darwin" ]; then
            reslist+=("$(sed -nE 's/.+'"$2"'\|(.+)"/\1/p' "$filename")") # Mac OSX
        else
            reslist+=("$(sed -nr 's/.+'"$2"'\|(.+)"/\1/p' "$filename")") # Linux
        fi
    done

    popd > /dev/null
}

pricing () {
    CURRENT=`pwd`

    pushd "$CURRENT" > /dev/null

    service_url="$host/managedservices/imi/providers/$1/ratecard?ignorestatus=true&servicetype=operationoffering&resourcetype="

    for res in "${reslist[@]}"; do
        echo "Uploading price for: "$res
        command=$(curl --silent -k -H "Content-Type: application/json" -H "Accept: application/json" -H "username:$apikey_username" -H "apikey:$apikey" -X PUT -d  @"pricing.json" "$service_url$res")
        echo "$(date) the response got from server is:: $command"
    done

    popd > /dev/null
}

for index in "${providers[@]}"; do
    provider="${index%%::*}"
    folder="${index##*::}"
    service_defs $folder $provider
    pricing $provider
    unset reslist
done