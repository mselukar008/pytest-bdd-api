from datetime import (
    datetime,
    timedelta
)
from pytz import timezone
from time import time

from core.payload_helper import ProviderCode
import utils


class PolicyStatus:
    ACTIVE = 'active'
    DRAFT = 'draft'
    RETIRED = 'retired'


class ProviderOfferingType:
    MAIN = 'iaas'
    ADD_ON = 'asp'


class PermissionCode:
    FINANCIAL_APPROVAL = 'FINANCIAL_APPROVAL'
    LEGAL_APPROVAL = 'LEGAL_APPROVAL'
    TECHNICAL_APPROVAL = 'TECHNICAL_APPROVAL'


class Role:
    BUYER = 'Buyer'
    FINANCIAL_APPROVER = 'Financial Approver'
    LEGAL_APPROVER = 'Legal Approver'
    OPERATOR = 'Operator'
    PURCHASER = 'Purchaser'
    TECHNICAL_APPROVER = 'Technical Approver'
    @staticmethod
    def to_permission(role):
        return {
            Role.FINANCIAL_APPROVER: PermissionCode.FINANCIAL_APPROVAL,
            Role.LEGAL_APPROVER: PermissionCode.LEGAL_APPROVAL,
            Role.TECHNICAL_APPROVER: PermissionCode.TECHNICAL_APPROVAL
        }[role]


class RuleOutcome:
    MANUAL = 'manual'
    AUTO_APPROVE = 'auto_approve'
    AUTO_DENY = 'auto_deny'
    EXTERNAL = 'external'


def gcs_provider_adapter_url(provider_code):
    return f'http://localhost:5000/genericcontentserver/v1/providers/{provider_code}'


def context_builder(**kwargs):
    return [{
        'tagType': key,
        'tagValueCode': value
    } for key, value in kwargs.items()]


def context_codes_builder(**kwargs):
    return [{
        'tagType': key,
        'tagValueCodes': value if isinstance(value, list) else [value]
    } for key, value in kwargs.items()]


def context_soi_builder(data, **kwargs):
    context = []
    for key, value in kwargs.items():
        items = {
            'tagValue': '',
            'values': [value],
            'tagType': key
        }
        if key == 'team':
            items['name'] = 'Team'
        elif key == 'org':
            for org in data['organizations']:
                if value == org['id']:
                    items['name'] = org['name']
                    break
        else:
            try:
                items['name'] = data.get_internal_context(key)['type_name']
            except:
                items['name'] = data.get_external_context(key)['type_name']
        context.append(items)
    return context


def provider_type_builder(provider_code, provider_types=None):
    provider_types = provider_types or ['iaas', 'asp']
    return {
        'adapter': '',
        'provider': ProviderCode.to_provider(provider_code),
        'providerCode': provider_code,
        'discoverContent': False,
        'providerType:': provider_types
    }


def provider_adapters_builder(provider_codes, provider_types=None):
    provider_types = provider_types or [None for _ in range(len(provider_codes))]
    if len(provider_codes) != len(provider_types):
        raise Exception('Length of provider_codes & provider_types need to match')
    return {
        'provider_adapters': [provider_type_builder(provider_types[i], provider_types[i]) for i in range(len(provider_codes))]
    }


def find_service_add_on_builder(categories, status, search_text='', providers=None):
    return {
        "providers": providers or ['imi'],
        "categories": categories,
        "status": [
            status
        ],
        "searchText": search_text
    }


def order_approve(order_id, approval_type=None, user_id="", team_id=""):
    return {
        "orderId": order_id,
        "approvalType": approval_type if approval_type is not None else ["technical", "financial"],
        "userId": user_id,
        "teamId": team_id
    }


def order_deny(order_id, rejection=None, user_id="", team_id=""):
    return {
        "orderId": order_id,
        "reject": rejection if rejection is not None else [
            {"approvalType": "technical", "comment": "technical reasons"},
            {"approvalType": "financial", "comment": "financial reasons"}
        ],
        "userId": user_id,
        "teamId": team_id
    }


def apply_budget_to_order(budgetary_unit_code, step_id=""):
    return {
        "budgetaryunit": budgetary_unit_code,
        "stepId": step_id
    }


def external_approval_state(enable, provider_code='test', routing_key='test', version='v2'):
    return {
        "EXTERNAL_APPROVAL_PROVIDER_CODE": provider_code,
        "EXTERNAL_APPROVAL_ENABLE": enable,
        "EXTERNAL_APPROVAL_ROUTINGKEY": routing_key,
        "EXTERNAL_APPROVAL_MESSAGE_VERSION": version
    }


def external_approval_state_v3(name='test', routing_key='test', version='3.0'):
    return {
        "externalApprovalSystems": [{
            "name": name,
            "routingKey": routing_key,
            "messageVersion": version
        }]
    }


def external_approval(request_number, status='Approved', approved_by=''):
    return {
        "requestNumber": request_number,
        "approvalStatus": status,
        "approvedBy": approved_by
    }


def do_operation(operation_id, service_inventory_id, instance_name, resource_id):
    return {
        "serviceInventoryId": service_inventory_id,
        "resourceId": [resource_id],
        "resourceName": instance_name,
        "operationDefinitionId": operation_id,
        "operationConfigParams": {
            "systemParams": "",
            "customParams": []
        },
        "requestorAdditionalInfo": {}
    }


def standard_action_operation(operation, name, provider_code):
    return [{
        "id": operation,
        "name": name,
        "description": f'Performing action {operation}',
        "providerCode": provider_code,
        "apiDocVersion": "v3",
        "provider": {
            "name": provider_code
        },
        "version": "1.0.0",
        "isOrderRequired": False,
        "isOrderLifeCycleRequired": False,
        "serviceType": "ServiceOperation",
        "isPricingEnabled": False,
        "isConfigurationEnabled": False,
        "associatedTo": {
            "type": "SOC",
            "providerSOCTypeIds": ["Virtual Machine"]
        },
        "routing_key": provider_code,
        "context": {
            "organization": ["org_all"]
        },
        "status": "PUBLISHED",
        "isCustom": False,
        "operationTimeout": 0,
        "operationCode": operation
    }]


def standard_action_template(service_inventory_id, reference_id, description):
    return {
        "serviceId": service_inventory_id,
        "refId": reference_id,
        "description": description
    }


def catalog_label_builder(provider_code, services_labels):
    """
    services_labels: [{'SOI': ['labels']}]
    """
    return {
        "providerCode": provider_code,
        "serviceOfferings": [{
            "serviceDefinition": {
                "serviceOfferingId": soi,
                "serviceCategory": [{
                    "id": "compute"
                }],
                "labels": labels
            }
        } for soi, labels in services_labels.items()]
    }


def catalog_serviceofferings_versions_builder(soid_key_value_pair):
    """
    soid_key_value_pair: {'provider code': ['service offering ids']}
    """
    return [
    {
        "providerCode": provider_code,
        "serviceOfferingIds": serviceOfferingIds
    } for provider_code, serviceOfferingIds in soid_key_value_pair.items()
            ]


def inventory_create_tag_builder(provider_code, tag_key_value_pair):
    payload = inventory_update_tag_builder(tag_key_value_pair)
    payload['providerCode'] = provider_code
    return payload


def inventory_update_tag_builder(tag_key_value_pair):
    return {"tags": [{
            "tagKey": k,
            "tagValue": v,
            "tagType": "managed",
            "additionalProperties": {
                "subSOCTag": False,
                "subSOCType": ""
            }
        } for k, v in tag_key_value_pair.items()]
    }

def g11n_operations_definition_builder(operations_providercode_list):
    return {"operations": [{
            "providerCode": provider,
            "g11n_description": operation + " Operation",
            "isConfigurationEnabled": False,
            "g11n_operationDisplayLabel": "Local " + operation,
            "operationDefinitionId": operation
        } for provider, operation in operations_providercode_list.items()]
    }


def templateOutputParams_builder(tracking_info):
    return {"serviceInstanceInfo": {
            "additionalInfo": None,
            "trackingInfo": tracking_info
        }
    }


def order_workflow_builder(approval_steps):
    """
    Order workflow v3 builder
    :param approval_steps: list of lists. Order of list specifies the approval step sequence.
        0 - name, 1 - role, 2 - budget unit required, 3 (if exists) - budget_unit_context
    :return: order workflow payload
    """
    payload = {
        'allowed_approvals': [],
        'approvals': [],
        "externalApprovalSystems": [
            {
                "messageVersion": "v3",
                "name": "test",
                "routingKey": "test"
            }
        ]
    }
    step_count = 1
    for step in approval_steps:
        permission = Role.to_permission(step[1])
        payload['allowed_approvals'].append({
            "displayName": step[0],
            "name": step[0],
            "permission": permission,
            "role": step[1]
        })
        payload['approvals'].append({
            "approvalStep": step_count,
            "budget_unit_required": step[2],
            "displayName": step[0],
            "name": step[0],
            "permission": permission,
            "role": step[1]
        })
        if len(step) == 4:
            payload['approvals'][-1]['budget_unit_context'] = [{'contextKey': x} for x in step[3]]
        step_count += 1
    return payload


def cart_builder(name, description='', **kwargs):
    return {
        'name': name,
        'description': description,
        'contexts': context_builder(**kwargs)
    }


def cart_and_items_builder(name, bag_items, **context):
    cart_items = cart_builder(name, **context)
    cart_items['bagItems'] = bag_items
    return cart_items


def create_configurations_callback(dependency_id, parent_configs):
    configurations_callback = _create_parent_configs(parent_configs)
    configurations_callback['dependentConfigId'] = dependency_id
    return configurations_callback


def create_configurations_search(config_id, parent_configs, search_info):
    configurations_search = _create_parent_configs(parent_configs)
    configurations_search['configId'] = config_id
    configurations_search['searchInfo'] = {"text": search_info}
    return configurations_search


class ConfigurationValidationBuilder(dict):
    def __init__(self, contexts: list):
        super().__init__()
        self.update({
            "configGroup": [],
            "contexts": contexts
        })

    def _create_values(self, id_: str, values: list, previous_values: list = None):
        previous_values_ = previous_values if previous_values else [(None, None)]
        return {
            "configId": id_,
            "selectedValues": [{
                "label": x[0],
                "value": x[0],
                "valueId": x[1]
            } for x in values],
            "prevSelectedValues": [{
                "label": x[0],
                "value": x[0],
                "valueId": x[1]
            } for x in previous_values_]
        }

    def add_group(self, name: str, code: str, sequence: int):
        self['configGroup'].append({
            "configGroupName": name,
            "configGroupCode": code,
            "configGroupSequence": sequence,
            "sections": [],
            "configs": []
        })
        return self

    def add_config(self, id_: str, values: list, previous_values: list = None, index: int = -1):
        self['configGroup'][index]['configs'].append(self._create_values(id_, values, previous_values))
        return self

    def add_section(self, code, index=-1):
        self['configGroup'][index]['sections'].append({'sectionCode': code, 'configs': []})
        return self

    def add_section_config(self, id_: str, values: list, previous_values: list, group_index=-1, section_index=-1):
        self['configGroup'][group_index]['sections'][section_index]['configs'].append(self._create_values(id_, values, previous_values))
        return self


class ConfigurationPricingBuilder(dict):
    def __init__(self, contexts: list, quantity: int = 1, currency_code: str = None):
        super().__init__()
        self.empty_values = [("", "")]
        str_quantity = str(quantity)
        self.update({
            "configs": [self._create_config_values('multiquantity', [(str_quantity, str_quantity)])],
            "sections": [],
            "contexts": contexts,
            "oldPrices": [],
            "currencyCode": currency_code
        })

    def _create_config_values(self, id_: str, values: list, previous_values: list = None):
        config_values = {
            "configId": id_,
            "selectedValues": [{
                "label": x[0],
                "value": x[0],
                "valueId": x[1]
            } for x in (values or self.empty_values)]
        }
        if previous_values is not None:
            config_values['prevSelectedValues'] = [{
                "label": x[0],
                "value": x[0],
                "valueId": x[1]
            } for x in previous_values]
        return config_values

    def add_config(self, id_: str, selected_values: list, previous_values: list = None):
        self['configs'].append(self._create_config_values(id_, selected_values, previous_values))
        return self

    def add_section(self, id_: str, name: str, sequence: str):
        self['sections'].append({
            'section': {
                'sectionCode': id_,
                'sectionName': name,
                'sectionSequence': sequence,
                'configs': []
            }
        })
        return self

    def add_section_config(self, config_id: str, selected_values: str, previous_values: list = None, index: int = -1):
        self['sections'][-1]['section']['configs'].append(self._create_config_values(config_id, selected_values, previous_values))
        return self


class EditConfigurationPricingBuilder(ConfigurationPricingBuilder):
    def __init__(self, contexts: list, currency_code: str, old_prices: list, tracking_info: dict):
        super().__init__(contexts, quantity=1, currency_code=currency_code)
        undefined = 'undefined'
        self["configs"][0]['prevSelectedValues'] = [{
                "label": undefined,
                "value": undefined,
                "valueId": undefined
        }]
        self['oldPrices'] = old_prices
        self['trackingInfo'] = tracking_info


class NewConfigurationBuilder(dict):
    def __init__(self, provider_code: str, service_offering_id: str, instance_prefix, provider_asset_id: str, provider_cred_id: str, quantity: int = 1, context: list = None):
        super().__init__()
        self.update({
            "providerCode": provider_code,
            "serviceOfferingId": service_offering_id,
            "serviceInstancePrefix": instance_prefix,
            "quantity": quantity,
            "providerAccountRefId": provider_asset_id,
            "providerCredentialRefId": provider_cred_id,
            "configGroups": []
        })
        if context:
            self['context'] = context

    def _create_config_values(self, id_: str, values: list):
        return {
            "configId": id_,
            "selectedValues": [{
                "label": x[0],
                "valueId": x[1]
            } for x in (values or [("", "")])]
        }

    def add_group(self, code: str):
        self['configGroups'].append({
            "configGroupCode": code,
            "sections": [],
            "configs": []
        })
        return self

    def add_config(self, id_: str, values: list, group_index: int = -1):
        self['configGroups'][group_index]['configs'].append(
            self._create_config_values(id_, values)
        )
        return self

    def add_section(self, code: str, group_index: int = -1):
        self['configGroups'][group_index]['sections'].append({
            "sectionCode": code,
            "sectionItems": []
        })
        return self

    def add_section_item(self, group_index: int = -1, section_index: int = -1):
        self['configGroups'][group_index]['sections'][section_index]['sectionItems'].append({
            "configs": []
        })
        return self

    def add_section_config(self, id_: str, values: list, group_index: int = -1, section_index: int = -1, section_item_index: int = -1):
        self['configGroups'][group_index]['sections'][section_index]['sectionItems'][section_item_index]['configs'].append(
            self._create_config_values(id_, values)
        )
        return self


class EditConfigurationBuilder(dict):
    def __init__(self, provider_asset_id: str, provider_cred_id: str, new_offering_id: str = None):
        super().__init__()
        self.update({
            "providerAccountRefId": provider_asset_id,
            "providerCredentialRefId": provider_cred_id,
            "configInfo": {
                "sections": [],
                "configs": []
            }
        })
        if new_offering_id:
            self['newServiceOfferingId'] = new_offering_id

    def _create_values(self, id_: str, values: list, impact_type: str):
        return [{
                "value": x[0],
                "valueId": str(x[1]),
                "binding": id_
            } for x in values] if impact_type in ["NEW", "DELETE"] else [{"valueId": str(x[1])} for x in values]
    
    def _make_config_values(self, id_: str, values: list, impact_type: str):
        self['configInfo']['configs'].append({
            "ConfigImpactType": impact_type,
            "ConfigID": id_,
            "Values": self._create_values(id_, values, impact_type)
        })

    def _make_section(self, code: str, sequence: int, impact_type: str):
        self['configInfo']['sections'].append({
            "SectionCode": code,
            "InstanceSequence": sequence,
            "SectionImpactType": "NEW",
            "Configs": []
        })

    def _make_section_config_values(self, id_: str, values: list, impact_type: str, index: int = -1):
        self['configInfo']['sections'][index]['Configs'].append({
            'ConfigID': id_,
            "Values": self._create_values(id_, values, impact_type)
        })

    def update_config(self, id_: str, values: list):
        self._make_config_values(id_, values, "UPDATE")
        return self

    def add_config(self, id_: str, values: list):
        self._make_config_values(id_, values, "NEW")
        return self

    def delete_config(self, id_: str, values: list):
        self._make_config_values(id_, values, "DELETE")
        return self

    def add_section(self, code: str, sequence: int):
        self._make_section(code, sequence, "NEW")
        return self

    def delete_section(self, code: str, sequence: int):
        self._make_section(code, sequence, "DELETE")
        return self

    def add_section_config_values(self, id_: str, values: list, index: int = -1):
        self._make_section_config_values(id_, values, "NEW")
        return self

    def update_section_config_values(self, id_: str, values: list, index: int = -1):
        self._make_section_config_values(id_, values, "UPDATE")
        return self

    def remove_section_config_values(self, id_: str, values: list, index: int = -1):
        self._make_section_config_values(id_, values, "DELETE")
        return self


class ImportConfigurationBuilder(dict):
    def __init__(self, provider_code: str, service_offering_id: str, name: str, user: str, asset_name: str, cred_name: str,  tracking_info: dict, provider_sid: str = None, context: list = None):
        super().__init__()
        self.update({
            "serviceInstanceName": name,
            "serviceOfferingID": service_offering_id,
            "providerCode": provider_code,
            "providerSID": provider_sid or utils.add_custom_prefix_to(str(int(time()))),
            "providerAccount": asset_name,
            "provisionDate": utils.datetime_to_str(datetime.now() - timedelta(days=1)),
            "owner": user,
            "currency": "USD",
            "credentialsName": cred_name,
            "context": context,
            "trackingInfo": tracking_info,
            "configInfo": {
                "sections": [],
                "configs": []
            },
        })
        self['team'] = get_team_code_from_payload(self)

    def _create_values(self, id_: str, values: list):
        return [{
            "binding": id_,
            "value": v[0],
            "valueId": v[1]
        } for v in values or [("", "")]]

    def _create_config(self, id_: str, name: str, values: list):
        return {
            "configId": id_,
            "name": name,
            "description": "",
            "type": "string",
            "uom": "",
            "isChange": "",
            "values": self._create_values(id_, values)
        }

    def add_group(self, name: str):
        self['configInfo']['configs'].append({
            "configGroup": name,
                "config": []
        })
        return self

    def add_config(self, id_: str, name: str, values: list, index: int = -1):
        self['configInfo']['configs'][index]['config'].append(self._create_config(id_, name, values))
        self._create_config(id_, name, values)
        return self

    def add_section(self, code: str, name: str, sequence: int):
        self['configInfo']['sections'].append({
            "sectionCode": code,
            "sectionName": name,
            "sectionSequence": str(sequence),
            "configs": []
        })
        return self

    def add_section_item(self, group_name: str, index: int = -1):
        self['configInfo']['sections'][index]['configs'].append({
            "configGroup": group_name,
            "config": []
        })
        return self

    def add_section_item_config(self, id_: str, name: str, values: list, section_index: int = -1, section_item_index: int = -1):
        self['configInfo']['sections'][section_index]['configs'][section_item_index]['config'].append(self._create_config(id_, name, values))
        return self


def _create_parent_configs(parent_configs):
    return {
        "parentConfigs": [
            {
                "parentConfigId": k,
                "values": v
            }
            for k, v in parent_configs.items()
        ]
    }


def create_pricing_payload(order):
    """
    Creates pricing dictionary for a new order
    :param order: The order dictionary
    :return: pricing dictionary
    """
    pricing_payload = {
        'configs': [],
        'sections': [],
        'oldPrices': [],
        'currencyCode': None,
        'contexts': order['context']
    }

    sections = []
    for config_group in order['configGroups']:
        for config in config_group['configs']:
            pricing_payload['configs'].append({
                'configId': config['configId'],
                'selectedValues': [{
                    'label': config['selectedValues'][0]['label'],
                    'value': config['selectedValues'][0]['valueId'],
                    'valueId': config['selectedValues'][0]['valueId']
                }]
            })
        for section in config_group['sections']:
            sections.append({
                'section': {
                    "sectionCode": section['sectionCode'],
                    "sectionName": section['sectionCode'],
                    "sectionSequence": "1",
                    "configs": []
                }
            })
            for section_item in section['sectionItems']:
                for config in section_item['configs']:
                    sections[-1]['section']['configs'].append({
                        'configId': config['configId'],
                        'selectedValues': [{
                            'label': config['selectedValues'][0]['label'],
                            'value': config['selectedValues'][0]['valueId'],
                            'valueId': config['selectedValues'][0]['valueId']
                        }]
                    })
    if sections:
        pricing_payload['sections'] = sections

    quantity = str(order['quantity'])
    pricing_payload['configs'].append({
        'configId': 'multiquantity',
        'selectedValues': [{
            'label': quantity,
            'value': quantity,
            'valueId': quantity
        }]
    })
    return pricing_payload


def create_edit_soi_pricing_payload(edit_order, soi_properties_response):
    """
    Creates pricing dictionary for an EditSOI order
    :param edit_order: The EditSOI order dictionary
    :param soi_properties_response: Response payload from the SOI properties api
    :return: pricing dictionary
    """
    pricing_payload = {
        'configs': [],
        'oldPrices': soi_properties_response['billOfMaterialsFromSOI'],
        'currencyCode': 'USD',
        'trackingInfo': soi_properties_response['trackingInfo'],
        'contexts': [context_builder(**{context['tagType']: context['values'][0] for context in edit_order['context']})]
    }
    sections = []
    for config_group in edit_order['configInfo']:
        values_config = []
        for config in config_group['config']:
            values_config.append({
               'configId': config['configId'],
               'prevSelectedValues': [{
                   'label': config['values'][0]['oldValue'],
                   'value': config['values'][0]['oldValue'],
                   'valueId': config['values'][0]['oldValueId']
               }],
               'selectedValues': [{
                   'label': config['values'][0]['value'],
                   'value': config['values'][0]['value'],
                   'valueId': config['values'][0]['valueId']
               }]
            })
        if config_group['sectionCode']:
            sections.append({
                'section': {
                    "sectionCode": config_group['sectionCode'],
                    "sectionName": config_group['sectionName'],
                    "sectionSequence": "1",
                    "configs": values_config
                }
            })
        else:
            pricing_payload['configs'] += values_config

    if sections:
        pricing_payload['sections'] = sections
    qty = str(edit_order['qty'])
    pricing_payload['configs'].append({
        'configId': 'multiquantity',
        'prevSelectedValues': [{
            'label': 'undefined',
            'value': 'undefined',
            'valueId': 'undefined'
        }],
        'selectedValues': [{
            'label': qty,
            'value': qty,
            'valueId': qty
        }]
    })
    return pricing_payload


def condition_builder(order_types=None, provider_codes=None, monthly_cost=None, one_time_charge=None, budget_status=None, integration_type=None):
    conditions = []
    if order_types is not None:
        order_types = order_types.split() if isinstance(order_types, str) else order_types
        conditions.append(f"orderType in {order_types}".replace('[', '(').replace(']', ')'))
    if provider_codes is not None:
        provider_codes = provider_codes.split() if isinstance(provider_codes, str) else provider_codes
        conditions.append(f"providerCode in {provider_codes}".replace('[', '(').replace(']', ')'))
    if monthly_cost is not None:
        value = f"in {str(monthly_cost).replace(' ','')}" if isinstance(monthly_cost, list) else str(monthly_cost)
        conditions.append(f"price {value}")
    if one_time_charge is not None:
        conditions.append(f"includeOneTimeCharge == {str(one_time_charge).lower()}")
    if budget_status is not None:
        conditions.append(f"budget_status == {budget_status}")
    if integration_type is not None:
        conditions.append(f"integrationType == '{integration_type}'")
    return conditions


def outcome_builder(approval_steps):
    outcomes = []
    for step in approval_steps:
        outcomes.append({
            'stepId': step[0],
            'outcome': step[1],
            'externalConfigName': 'null' if len(step) <= 2 else step[2]
        })
    return outcomes


def fulfillment_outcome_builder(routing_key='test'):
    return [{
        'routingKey': routing_key
    }]


def rule_builder(name, rank, condition, outcome):
    return {
        "rule_name": name,
        "priority": rank,
        "condition": condition,
        "outcome": outcome
    }


def policy_builder(name, rules, start_date=None, end_date=None, status=PolicyStatus.DRAFT, **kwargs):
    start_date_ = utils.datetime_to_str(start_date) if start_date else utils.datetime_now_str()
    policy = {
        "name": name,
        "status": status,
        "startDate": start_date_,
        "context": context_codes_builder(**kwargs),
        "rules": [rules] if not isinstance(rules, list) else rules
    }
    if end_date:
        policy['endDate'] = utils.datetime_to_str(end_date)
    return policy


def fulfillment_policy_builder(name, rules, start_date=None, end_date=None, status=PolicyStatus.DRAFT, **kwargs):
    start_date = start_date if start_date else datetime.now(timezone('America/Chicago'))
    end_date = end_date if end_date else start_date + timedelta(days=2)
    policy = policy_builder(name, rules, start_date, end_date, status, **kwargs)
    policy['policyType'] = 'fulfillments'
    return policy


def get_team_code_from_payload(payload):
    return get_team_code_from_context(payload.get('context', payload.get('contexts', {})))


def get_team_code_from_context(context):
    for con in context:
        if con['tagType'] == 'team':
            return con.get('tagValueCode', con.get('values', [None])[0])


def update_provider_account_ids(data, body, team_code=None):
    if team_code is None:
        team_code = get_team_code_from_payload(body)
    (body["providerAccountRefId"],
     body["providerCredentialRefId"]) = data.get_provider_asset_account_ids(body['providerCode'], team_code)


def _custom_name():
    return utils.add_custom_prefix_to(utils.random_string(8), separator='-')


def add_cart_item_main_parameters(data, payload, cart_payload, service_name=None, quantity=1):
    payload['serviceInstancePrefix'] = service_name if service_name else _custom_name()
    if payload['quantity']:
        payload['quantity'] = quantity
    team_code = get_team_code_from_payload(cart_payload)
    update_provider_account_ids(data, payload, team_code)
    if 'context' in payload:
        del payload['context']


def add_quick_purchase_main_parameters(data, new_payload, service_name=None, quantity=1, **kwargs):
    new_payload['serviceInstancePrefix'] = service_name if service_name else _custom_name()
    new_payload['quantity'] = quantity
    new_payload['context'] = context_builder(**kwargs)
    update_provider_account_ids(data, new_payload)


def add_add_on_main_parameters(data, add_on, team_code, service_name=None):
    add_on['serviceInstancePrefix'] = service_name if service_name else _custom_name()
    try:
        update_provider_account_ids(data, add_on, team_code)
    except:
        pass  # provider accounts are optional for addons


def add_add_ons(data, new_payload, add_ons):
    new_payload['additionalServices'] = []
    for add_on in add_ons:
        add_add_on_main_parameters(data, add_on, get_team_code_from_payload(new_payload))
        new_payload['additionalServices'].append(add_on)


def add_add_ons_to_cart_item(data, cart_item_payload, cart_payload, add_ons):
    cart_item_payload['additionalServices'] = []
    for add_on in add_ons:
        team_code = get_team_code_from_payload(cart_payload)
        add_add_on_main_parameters(data, add_on, team_code)
        cart_item_payload['additionalServices'].append(add_on)


def add_edit_soi_main_parameters(edit_payload, new_payload, soi_id=None):
    edit_payload["providerAccountRefId"] = new_payload['providerAccountRefId']
    edit_payload["providerCredentialRefId"] = new_payload['providerCredentialRefId']
    if soi_id is not None:
        edit_payload["serviceInventoryId"] = soi_id


def add_import_soi_main_parameters(data, soi_payload, owner, service_name=None, **kwargs):
    soi_payload['serviceInstanceName'] = service_name if service_name else _custom_name()
    soi_payload['owner'] = owner
    soi_payload['team'] = kwargs['team']
    soi_payload['provisionDate'] = utils.datetime_to_str(datetime.now() - timedelta(days=1))
    (soi_payload['providerAccount'],
     soi_payload['credentialsName']) = data.get_provider_account_names(soi_payload['providerCode'], kwargs['team'])
    soi_payload['context'] = context_soi_builder(data, **kwargs)


def add_custom_operations_main_parameters(service_id, resource_id, payload):
    payload["serviceInventoryId"] = service_id
    payload["resourceId"][0] = resource_id


def empty_new_order_main_parameters(new_order_payload):
    new_order_payload['serviceInstancePrefix'] = ''
    new_order_payload["providerAccountRefId"] = ''
    new_order_payload["providerCredentialRefId"] = ''
    if 'context' in new_order_payload:
        del new_order_payload['context']


def empty_edit_soi_main_parameters(edit_soi_payload):
    edit_soi_payload['providerAccountRefId'] = ''
    edit_soi_payload['providerCredentialRefId'] = ''


def empty_import_soi_main_parameters(import_soi_payload):
    import_soi_payload['serviceInstanceName'] = ''
    import_soi_payload['providerSID'] = ''
    import_soi_payload['providerAccount'] = ''
    import_soi_payload['provisionDate'] = ''
    import_soi_payload['owner'] = ''
    import_soi_payload['team'] = ''
    import_soi_payload['credentialsName'] = ''
    import_soi_payload['context'] = []


def get_new_config_values(payload, config_ids):
    values = []
    config_ids = config_ids if isinstance(config_ids, list) else [config_ids]
    for group in payload['configGroups']:
        for config in group['configs']:
            if config['configId'] in config_ids:
                values.append(config['selectedValues'][0]['valueId'])
    return values[0] if len(values) == 1 else values


def get_edit_config_values(payload, config_ids):
    values = []
    config_ids = config_ids if isinstance(config_ids, list) else [config_ids]
    for config in payload['configInfo']['configs']:
        if config['ConfigID'] in config_ids:
            values.append(config['Values'][0]['valueId'])
    return values[0] if len(values) == 1 else values


def build_provider_adapter(provider_code, provider_name=None, adapter_url='', type_=ProviderOfferingType.MAIN):
    return {
        "providers_adapters": [
            {
                "provider": provider_name or provider_code,
                "providerCode": provider_code,
                "adapter": adapter_url or gcs_provider_adapter_url(provider_code),
                "discoverContent": False,
                "providerOfferingTypes": [
                    type_
                ]
            }
        ]
    }


def build_get_catalog_offerings(provider_codes=None, categories=None, status=None, labels=None, search_text=None, service_offering_group_ids=None):
    payload = {
        "providers": provider_codes or [],
        "categories": categories or [],
        "status": status or [],
        "labels": labels or [],
        "serviceOfferingGroupIds": service_offering_group_ids or []
    }
    if search_text:
        payload['searchText'] = search_text
    return payload


def build_catalog_personalization_policy(name, contexts, includes, active=True, description=None):
    """
    includes: [None or ("ProviderCode", None or ["SOI's"], None or ["labels"])]
    """
    if description == None:
        description = name

    include_map = {
        0: 'providerCode',
        1: 'serviceOfferingIds',
        2: 'labels'
    }
    include_list = []
    for single_include in includes:
        tmp_list = [single_include]
        include_list.append(
            {include_map[i]: include[i] for include in tmp_list for i in range(len(include)) if include[i]})

    return {
        "name": name,
        "description": description,
        "active": active,
        "contextSets": [{"contexts": context_codes_builder(**context)} for context in contexts],
        "includes": include_list,
    }


def operation_group_builder(group_name, operations_list):
    return {
        "groupName": group_name,
        "operations": operations_list if isinstance(operations_list, list) else [operations_list]
    }

def operation_policy_builder(policy_name, group_code, context, status="Active"):
    return {
      "policyName": policy_name,
      "associatedOperationGroups": group_code if isinstance(group_code, list) else [group_code],
      "associatedEntities": context,
      "unAssociatedEntities": [],
      "status": status
    }

def build_so_service_category(cat_id, name, description='description'):
    return {"serviceCategory": [
             {
                 "id": cat_id,
                 "name": name,
                 "description": description
             }]
        }

def build_catalog_category(cat_id, name, description='description'):
    return {
                 "id": cat_id,
                 "name": name,
                 "description": description
        }

def build_catalog_category_create_payload(categories):
    return { "categories" : categories }

def build_so_base_price(oneTimeCharge, usage_charge_value, description='description'):
    return { "basePrice": {
                 "oneTimeCharge": oneTimeCharge,
                 "currencyCode": "USD",
                 "description": description,
                 "usageCharge": {
                     "frequency": {
                         "code": "MONTH",
                         "value": 1
                     },
                     "uom": {
                         "code": "GB",
                         "value": 1
                     },
                     "value": usage_charge_value
                 }
             }
        }

def build_service_offering(name, service_category, base_price,  description='description'):
    return { "name": name,
             "description" : description,
             "serviceCategory": service_category,
             "basePrice": base_price
           }

def build_service_offering_create(name, service_category, base_price,  multi_quantity, is_editable,
                                  service_type, so_id, status, resource_types, description='description',
                                  sog_id=None):
    return {    "name": name,
                "description" : description,
                "status": status,
                "multiQuantity" : multi_quantity,
                "isEditable": is_editable,
                "serviceCategory": service_category,
                "basePrice": base_price,
                "serviceType": service_type,
                "serviceOfferingId": so_id,
                "resourceTypes": resource_types,
                "docType": "serviceOffering",
                "apiDocVersion": None,
                "serviceOfferingGroupId" : sog_id,
                "icbVersion": {
                    "id": "1.0.0.0",
                    "label": "1.0.0.0"
                }
           }


def build_service_offering_create_payload(service_offerings):
    return {"serviceOfferings": service_offerings}


def build_service_offering_versioning_payload(provider_code,  enable_version_flag, adapter=None):
    _adapter = adapter if adapter else f"http://localhost:5000/genericcontentserver/v1/providers/{provider_code}"
    return {
        "provider": provider_code,
        "adapter": _adapter,
        "enableVersion": enable_version_flag
    }


def build_service_offering_group_payload(name, description='sog description', defaultVersion='latest'):
    return {
        "name" : name,
        "description" : description,
        "defaultVersionId" : defaultVersion
    }


def build_pricing_rule(name, code, rule_cat, descr, rule_type, adj_type, adj_value, applies_to, status, effective_date, end_date, context=[], org=[]):
    return {
                "name": name,
                "code": code,
                "ruleCategory": rule_cat,
                "description": descr,
                "ruleType": rule_type,
                "adjustmentType": adj_type,
                "adjustmentValue": adj_value,
                "appliesTo": applies_to,
                "context": context,
                "organization": org,
                "status": status,
                "effectiveDate": effective_date,
                "endDate": end_date
            }


def build_pricing_rules_payload(p_rules):
    return {"pricing_rules": p_rules}


def build_common_clients_payload(name, provider_code, callback_url, connection_protocol,
                                        endpoint_ca_cer="", endpoint_cer="", endpoint_key="", applicable_for=[]):
    return {
        "name": name,
        "provider_code": provider_code,
        "applicable_for": applicable_for,
        "callback": {
            "url": callback_url,
            "certs": {
                "endpoint_ca_cer": endpoint_ca_cer,
                "endpoint_cer": endpoint_cer,
                "endpoint_key": endpoint_key
            },
            "connection_protocol": connection_protocol}
    }


def build_common_clients_filter_payload(provider_code=None, applicable_for=None):
    return {
        "provider_code": provider_code,
        "applicable_for": applicable_for
    }


def target_owner_payload(soi_id: list, user_id: list):
    payload = []
    for i in range(len(soi_id)):
        payload.append({
            "owner": user_id[0] if len(user_id) == 1 else user_id[i],
            "sid": soi_id[i]
        })
    return payload


def initiate_payload(soi_list, team_id):
    return {
        "teamId": team_id,
        "sid": soi_list
    }


def context_payload(context_payload, user_id, soi_id, team_name):
    for team in context_payload:
        if team['name'] == 'Team':
            team['values'][0] = team_name
            team['tagValue'] = team_name
    return [
        {
            "owner": user_id,
            "sid": soi_id,
            "context": context_payload
        }
    ]


def accept_transfer_payload(accept_payload, user_id, soi_id, transfer_id, team_id):
    for team in accept_payload:
        if team['name'] == 'Team':
            team['values'][0] = team_id
            team['tagValue'] = team_id
    return {
            "owner": user_id,
            "sid": soi_id,
            "transferId": transfer_id,
            "teamId": team_id,
            "context": accept_payload
        }


def deny_transfer(transfer_id: str, comment: str):
    return {
        "transferId": transfer_id,
        "comments": comment
    }


def cancel_transfer(ids: list):
    return {
        "transferId": ids
    }


def resend_transfer(ids: list):
    return cancel_transfer(ids)


def service_ids(soi_id):
    return {
        "serviceIds": soi_id
    }


def filter_SOI_payload(searchText, sortField, status, soiSource, serviceOffering, org, team, context, provider,sortOrder, offset, limit, addon, addonStatus, owner, provisionDate, orderedBy, currentVersion):
    return {
        "searchText": searchText,
        "sortField": sortField,
        "status": status,
        "soiSource": soiSource,
        "serviceOffering": serviceOffering,
        "org": org,
        "team":team,
        "context":context,
        "provider": provider,
        "offset": offset,
        "limit": limit,
        "sortOrder": sortOrder,
        "addon": addon,
        "addonStatus": addonStatus,
        "owner": owner,
        "provisionDate": provisionDate,
        "orderedBy": orderedBy,
        "currentVersion": currentVersion,
    }


def fetch_configuration_payload(context, actionDefinitionSource, serviceOfferingInstanceId, resourceId):
    return {
        "resourceInfo": {},
        "additionalInfo": {},
        "contexts": context,
        "actionDefinitionSource": actionDefinitionSource,
        "serviceOfferingInstanceId": serviceOfferingInstanceId,
        "resourceId": resourceId
    }


def execute_operation_payload(actionSource, providerCode, providerName, resourceFamily, operation_payload, operationDisplayName, _type):
    provider_actionSource = {
        "isConfigurationEnabled": False,
        "operationDisplayName": operationDisplayName,
        "provider": {
            "contentProvider": {
                "providerCode": providerCode,
                "providerName": providerName
            },
            "fulfilmentProvider": {
                "providerCode": providerCode,
                "providerName": providerName
            },
            "targetProvider": {
                "providerCode": providerCode,
                "providerName": providerName
            }
        },
        "actionSource": actionSource,
        "resourceFamily": resourceFamily,
        "type": _type
    }
    operation_payload["operationConfigParams"]["systemParams"] = []
    if len(operation_payload["operationConfigParams"]["customParams"]) != 0:
        provider_actionSource["isConfigurationEnabled"] = True
    operation_payload.update(provider_actionSource)
    return operation_payload


def post_mcas_operations_definition(targetProviderCode, context, resourceTypeId, serviceOfferingId, _type, actionSource, actionType=None, contentProviderCode=None):
    payload = {
        "resourceTypeId": resourceTypeId,
        "type": _type,
        "targetProviderCode": targetProviderCode,
        "contentProviderCode": contentProviderCode,
        "serviceOfferingId": serviceOfferingId,
        "context": context,
        "managed": False,
        "limit": 10,
        "offset": 0,
        "actionType": actionType,
        "actionSource": actionSource
    }
    if actionType == None:
        del payload['actionType']
    if contentProviderCode == None:
        del payload['contentProviderCode']
    return payload
    