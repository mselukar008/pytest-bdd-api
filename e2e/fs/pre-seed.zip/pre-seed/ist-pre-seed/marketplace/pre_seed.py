from core.pre_seed import CoreData
from marketplace import payload_helper
from utils.pre_seed_base import PreSeedBase


class MarketplacePreSeed(PreSeedBase):
    keys = [
        'approval_policies'
    ]

    def create_data(self):
        return CoreData({})

    def run_script(self, entities) -> list:
        self.error_list = []
        self._create_approval_policies(entities)
        return self.error_list

    def _create_approval_policies(self, entities):
        if 'approval_policies' in self.data:
            try:
                for policy in self.data['approval_policies']:
                    rules = []
                    rule_counter = 1
                    for rule in policy['rules']:
                        criteria = rule['criteria']
                        condition_payload = payload_helper.condition_builder(order_types=criteria['order_types'],
                                                                             provider_codes=criteria['provider_codes'],
                                                                             monthly_cost=criteria['monthly_cost'],
                                                                             one_time_charge=criteria['one_time_charge'],
                                                                             budget_status=criteria['budget'])
                        outcome = []
                        for approver in rule['outcomes']:
                            outcome.append((approver, rule['outcomes'][approver],
                                            'test' if rule['outcomes'][approver] == payload_helper.RuleOutcome.EXTERNAL else 'null'))
                        outcome_payload = payload_helper.outcome_builder(outcome)

                        rules.append(payload_helper.rule_builder(rule['name'], rule_counter, condition_payload,
                                                                 outcome_payload))
                        rule_counter += 1

                    policy_payload = payload_helper.policy_builder(name=policy['name'], rules=rules,
                                                                   start_date=policy['start_date'],
                                                                   end_date=policy['end_date'],
                                                                   status=payload_helper.PolicyStatus.ACTIVE,
                                                                   **policy['context'])
                    if not entities.Policies.create_or_re_create_approval_policy(policy_payload):
                        self._log_error(entities.logger, f"Failed to create approval policy {policy['name']}")
            except:
                self._log_exception(entities.logger, 'Encountered an exception when creating approval policies')
