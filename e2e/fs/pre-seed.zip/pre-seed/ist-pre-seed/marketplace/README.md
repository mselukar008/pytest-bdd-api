# Marketplace Automation

### Bootstrapping
- This tool clones the bootstrap repo and the templates repo and runs the scripts necessary for bootstraping. The setup_properties are found [here](setup_properties.json)
    ``` bash
    marketplace/bootstrap.sh --host <host> --admin_user <userid> --apikey <apikey> --secret <secret> \
                            # Other args
                            --aws . \  # "." means upload all content
                            --gcp CB_GCP_DEPMGR_COMPUTE_ENGINE  # Only upload offerings in the CB_GCP_DEPMGR_COMPUTE_ENGINE folder
                            --ibmcloud CB_SL_VM,CB_SL_VLAN,CB_SL_SUBNET \  # Upload offerings in these 3 folders
                            --test . --imi . \  # 2 other providers people forget about, plus notice azure is not supplied therefore it will be omitted
                            --only_update_content true  # this only does the content; NO message-subscriptions, provider account, d2ops_agent, etc.
                            --multitenant true  # Determines if the tenant is multi-tenant or not
                            --encrypted true  # Determines if the setup_properties.json needs to be decrypted or not
    ```
- If you would like to see the actual decypted values in setup_properties.json you may run this tool
    ``` bash
    marketplace/encrypt_properties.py --secret <secret> --config <path/to/config.conf> -d
    ```
