import json
import os
import sys

sys.path.insert(0, os.getcwd())
from core.payload_helper import ProviderCode
from encryption import process_config
from utils.encryption import Encryption


def main(args):
    config = process_config(args.config, args.secret, decrypt=True) if args.config else None
    return 0 if run(args.secret, args.decrypt, config, args.file_name) else 1


def run(secret: str, decrypt: bool, config=None, file_name=None):
    file_path = os.path.join('marketplace', 'setup_properties.json') if not file_name else file_name
    data = json.load(open(file_path))

    encryption_ = Encryption(secret)
    method = encryption_.encrypt if not decrypt else encryption_.decrypt

    provider_codes_keys = {
        ProviderCode.AWS: ['aws_accesskey', 'aws_secret'],
        ProviderCode.AZURE: ['azure_accesskey', 'azure_secret', 'azure_tenantid', 'azure_subscriptionid', 'azure_offerid'],
        ProviderCode.SOFTLAYER: ['ibmcloud_username', 'ibmcloud_apikey', 'ibmcloud_bx_apikey'],
        ProviderCode.GOOGLE: ['gcp_projectid', 'gcp_servicekey', 'gcp_project_name', 'gcp_service_account_name']
    }
    if 'marketplace/setup_properties.json' not in file_path:
        keys = data.keys()
        for key in keys:
            data[key] = method(data[key])
        with open(file_path, mode='w') as f:
            f.write(json.dumps(data, indent=4).replace('\\"', "'"))
    else:
        for provider_code, keys in provider_codes_keys.items():
            for key in keys:
                if data[key] == '$config':
                    try:
                        data[key] = config[provider_code][key]
                    except KeyError:
                        data[key] = config[provider_code][f'_{key}']
                elif isinstance(data[key], str) and data[key].startswith('$config.'):
                    data[key] = config[provider_code][data[key].replace('$config.', '')]
                else:
                    try:
                        data[key] = method(data[key])
                    except:
                        pass

        with open(file_path, mode='w') as f:
            f.write(json.dumps(data, indent=4))
    return True


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--secret', default=os.getenv('MCMP_API_AUTOMATION_SECRET'), help='The secret key')
    parser.add_argument('--file_name', help='The file path to encrypt/decrypt')
    parser.add_argument('--config', help='The .conf provider creds file to use')
    parser.add_argument('-d', '--decrypt', action='store_true', help='To decrypt')
    main(parser.parse_args())