from copy import deepcopy
import gzip
from io import BytesIO
import os
from zipfile import ZipFile

from core.api_client import CoreApiClient
from utils.api_client_base import Route


class MarketplaceApiClient(CoreApiClient):
    def create_configuration_headers(self, account_id, cred_id, version=None):
        config_headers = {
            'cb-user-info': self.username,
            'cb-user-provider-account': account_id,
            'cb-provider-credential-refid': cred_id
        }
        if version:
            config_headers['apiDocVersion'] = version
        config_headers.update(self._headers)
        return config_headers

    def get_mda_health(self):
        return self.get(Route('mda/health'))

    def get_approval_policy_vocabulary(self):
        return self.get(Route('approvals/v3/policies/vocabulary'))

    def create_approval_policy(self, payload):
        return self.post(Route('approvals/v3/policies'), payload)

    def get_approval_policies(self):
        return self.get(Route('approvals/v3/policies'))

    def get_approval_policy(self, policy_id):
        return self.get(Route('approvals/v3/policies/{policy_id}', {'policy_id': policy_id}))

    def update_approval_policy(self, policy_id, payload):
        return self.put(Route('approvals/v3/policies/{policy_id}', {'policy_id': policy_id}), payload)

    def update_approval_policy_rule(self, policy_id, rule_id, payload):
        return self.put(Route('approvals/v3/policies/{policy_id}/rules/{rule_id}', {'policy_id': policy_id, 'rule_id': rule_id}), payload)

    def edit_approval_policy_status(self, policy_id, payload):
        return self.patch(Route('approvals/v3/policies/{policy_id}', {'policy_id': policy_id}), payload)

    def delete_approval_policy(self, policy_id):
        return self.delete(Route('approvals/v3/policies/{policy_id}', {'policy_id': policy_id}))

    def create_approval_rule(self, policy_id, payload):
        return self.post(Route('approvals/v3/policies/{policy_id}/rules', {'policy_id': policy_id}), payload)

    def get_policies(self):
        return self.get(Route('policies'))

    def get_approval_rules(self, policy_id):
        return self.get(Route('approvals/v3/policies/{policy_id}/rules', {'policy_id': policy_id}))

    def delete_approval_rule(self, policy_id, rule_id):
        return self.delete(Route('approvals/v3/policies/{policy_id}/rules/{rule_id}', {'policy_id': policy_id, 'rule_id': rule_id}))

    def create_fulfillment_policy(self, payload):
        return self.post(Route('v4/api/fulfillment/policies'), payload)

    def get_fulfillment_policies(self):
        return self.get(Route('fulfillments/v3/policies'))

    def update_fulfillment_policy(self, policy_id, payload):
        return self.patch(Route('v4/api/fulfillment/policies/{policy_id}', {'policy_id': policy_id}), payload)

    def delete_fulfillment_policy(self, policy_id):
        return self.delete(Route('v4/api/fulfillment/policies/{policy_id}', {'policy_id': policy_id}))

    def create_operation_group(self, payload):
        return self.post(Route('inventory/v3/operations/OperationGroups'), payload)

    def create_operation_group_v4(self, payload):
        return self.post(Route('inventory/v4/operations/OperationGroups'), payload)

    def get_operation_group(self, group_id):
        return self.get(Route('inventory/v3/operations/OperationGroups/{group_id}', {'group_id': group_id}))

    def get_operation_group_by_groupcode_v4(self, group_code):
        return self.get(Route('inventory/v4/operations/OperationGroups/{group_code}', {'group_code': group_code}))

    def get_operation_groups(self):
        return self.get(Route('inventory/v3/operations/OperationGroups'))

    def get_operation_groups_v4(self):
        return self.get(Route('inventory/v4/operations/OperationGroups'))

    def update_operation_group_v4(self, group_code, payload):
        return self.put(Route('inventory/v4/operations/OperationGroups/{group_code}', {'group_code': group_code}), payload)

    def get_policy_rules(self):
        return self.get(Route('policy/rules'))

    def delete_operation_group(self, group_id):
        return self.delete(Route('inventory/v3/operations/OperationGroups/{group_id}', {'group_id': group_id}))

    def create_operation_policy(self, payload):
        return self.post(Route('inventory/v3/operations/AuthorizationPolicies'), payload)

    def get_operation_policies(self):
        return self.get(Route('inventory/v3/operations/AuthorizationPolicies'))

    def get_operation_policy_status(self, policy_code):
        return self.get(Route('inventory/v3/operations/AuthorizationPolicies/{policy_code}', {'policy_code': policy_code}))

    def update_operation_policy(self, policy_code, payload):
        return self.put(Route('inventory/v3/operations/AuthorizationPolicies/{policy_code}', {'policy_code': policy_code}), payload)

    def delete_operation_policy(self, policy_code):
        return self.delete(Route('inventory/v3/operations/AuthorizationPolicies/{policy_code}', {'policy_code': policy_code}))

    def get_request_number(self, order_id):
        return self.get(Route('adapter/generic/external/orders/{order_id}', {'order_id': order_id}))

    def externally_approve(self, payload):
        return self.post(Route('adapter/generic/external/workflow'), payload)

    def initialize_dummy_adapter(self, payload):
        return self.post(Route('adapter/switchdummy/initialize'), payload)

    def get_dummy_status(self):
        return self.get(Route('adapter/switchdummy/status'))

    def enable_dummy_adapter(self, provider_code):
        return self.post(Route('adapter/switchdummy/{provider_code}/enable', {'provider_code': provider_code}), {})

    def disable_dummy_adapter(self, provider_code):
        return self.post(Route('adapter/switchdummy/{provider_code}/disable', {'provider_code': provider_code}), {})

    def drop_dummy_table(self):
        return self.delete(Route('adapter/switchdummy/cleanup'))

    def gcs_on_board(self, file_path):
        fin = open(file_path, 'rb')
        file_name = os.path.basename(file_path)
        files = {'file': (file_name, fin)}
        self.temp_headers = deepcopy(self._headers)
        self.temp_headers.pop("Content-Type")
        self.temp_headers.pop("Accept")
        fin.close()
        return self.upload(Route('genericcontentserver/v1/admin/import'), files)

    def create_provider_adapter(self, payload):
        return self.post(Route('catalog/v3/providers_adapters'), payload)

    def update_provider_adapter(self, provider_code, payload):
        return self.put(Route('catalog/v3/providers/%s' % provider_code), payload)

    def get_provider_adapters(self, provider_offering_types='iaas,asp', limit=None):
        return self.get(Route('catalog/v3/providers', query_parameters={'providerOfferingTypes': provider_offering_types, 'limit': limit}))

    def update_provider_type(self, provider_code, payload):
        return self.put(Route('catalog/v3/providers/%s' % provider_code), payload)

    def create_service_offering(self, provider_code, payload):
        return self.post(Route('catalog/v3/admin/providers/%s/services' % provider_code), payload)

    def update_service_offering(self, provider_code, service_offering_id, payload):
        return self.put(Route('catalog/v3/admin/providers/%s/services/{service_offering_id}' % provider_code, {'service_offering_id': service_offering_id}), payload)

    def patch_service_offering(self, provider_code, service_offering_id, payload):
        return self.patch(Route('catalog/v3/admin/providers/%s/services/{service_offering_id}' % provider_code,
                                {'service_offering_id': service_offering_id}), payload)

    def delete_service_offering(self, provider_code, service_offering_id):
        return self.delete(Route('catalog/v3/admin/providers/%s/services/{service_offering_id}' % provider_code, {'service_offering_id': service_offering_id}))

    def delete_content_template(self, provider_content_code, service_offering_id):
        return self.delete(Route('catalog/content/admin/%s/v2/contentpackage' % provider_content_code, query_parameters={'serviceId': service_offering_id}))

    def get_service_offerings(self, payload, sort_order=None, limit=None, offset=None, search_fields=None,
                              service_type=None, default_version=None):
        return self.post(Route('catalog/v3/services', query_parameters={'sortOrder': sort_order, 'limit': limit,
                                                                        'offset': offset, 'searchFields': search_fields,
                                                                        'serviceType': service_type,
                                                                        'defaultVersion': default_version}), payload)

    def get_service_offering_info(self, provider_code, service_offering_id):
        return self.get(Route('catalog/v3/providers/%s/services/{service_offering_id}' % provider_code, {'service_offering_id': service_offering_id}))

    def get_generic_content_services(self, provider_code):
        return self.get(Route('genericcontentserver/v1/providers/{provider_code}/services', {'provider_code': provider_code}))

    def get_generic_content_service(self, provider_code, service_offering_id):
        return self.get(Route('genericcontentserver/v1/providers/{provider_code}/services/{service_offering_id}', {'provider_code': provider_code, 'service_offering_id': service_offering_id}))

    def update_generic_content_service(self, provider_code, service_offering_id, body, ignorestatus=True):
        return self.put(Route('genericcontentserver/v1/providers/{provider_code}/services/{service_offering_id}', {'provider_code': provider_code, 'service_offering_id': service_offering_id}, query_parameters={"ignorestatus": ignorestatus}), body)

    def patch_generic_content_service(self, provider_code, service_offering_id, body, ignorestatus=True):
        return self.patch(Route('genericcontentserver/v1/providers/{provider_code}/services/{service_offering_id}', {'provider_code': provider_code, 'service_offering_id': service_offering_id}, query_parameters={"ignorestatus": ignorestatus}), body)

    def get_system_configuration_info(self, provider_code, service_offering_id):
        return self.get(Route('catalog/v3/providers/%s/services/{service_offering_id}/systemconfigurations' % provider_code, {'service_offering_id': service_offering_id}))

    def delete_service_offering2(self, provider_code, service_offering_id):
        return self.delete(Route('catalog/v3/admin/providers/%s/serviceofferings/{service_offering_id}' % provider_code, {'service_offering_id': service_offering_id}))

    def delete_provider_adapter(self, adapter_url, provider_code):
        return self.delete(Route('catalog/v3/adapters/{adapter_url}/providers/{provider_code}', {'adapter_url': adapter_url, 'provider_code': provider_code}))

    def get_configurations(self, provider_code, service_offering_id, account_id, cred_id, payload):
        self.temp_headers = self.create_configuration_headers(account_id, cred_id)
        return self.post(Route("catalog/v3/providers/%s/services/{service_offering_id}/configurations" % provider_code, {'service_offering_id': service_offering_id}), payload)

    def configuration_callback(self, provider_code, service_offering_id, account_id, cred_id, payload):
        self.temp_headers = self.create_configuration_headers(account_id, cred_id)
        return self.post(Route("catalog/v3/providers/%s/services/{service_offering_id}/configurationscallback" % provider_code, {'service_offering_id': service_offering_id}), payload)

    def configuration_search(self, provider_code, service_offering_id, account_id, cred_id, payload):
        self.temp_headers = self.create_configuration_headers(account_id, cred_id)
        return self.post(Route("catalog/v3/providers/%s/services/{service_offering_id}/configurationsearch" % provider_code, {'service_offering_id': service_offering_id}), payload)

    def configuration_validation(self, provider_code, service_offering_id, account_id, cred_id, payload):
        self.temp_headers = self.create_configuration_headers(account_id, cred_id)
        return self.post(Route("catalog/v3/providers/%s/services/{service_offering_id}/configurations/validation" % provider_code, {'service_offering_id': service_offering_id}), payload)

    def get_edit_soi_pricing(self, version, provider_code, service_offering_id, service_instance_id,account_id, cred_id, payload):
        self.temp_headers = self.create_configuration_headers(account_id, cred_id, version)
        self.temp_headers['cb-soi-id'] = service_instance_id
        return self.post(Route("catalog/{version}/providers/%s/services/{service_offering_id}/soiprice" % provider_code, {'version': version, 'service_offering_id': service_offering_id}), payload)

    def get_pricing(self, version, provider_code, service_offering_id, account_id, cred_id, payload):
        self.temp_headers = self.create_configuration_headers(account_id, cred_id, version)
        return self.post(Route("catalog/{version}/providers/%s/services/{service_offering_id}/price" % provider_code, {'version': version, 'service_offering_id': service_offering_id}), payload)

    def create_catalog_personalization_policy(self, payload):
        return self.post(Route('catalog/v3/admin/policies/personalizations'), payload)

    def get_catalog_personalization_policy(self, policy_id):
        return self.get(Route('catalog/v3/policies/personalizations/{policy_id}', {'policy_id': policy_id}))

    def get_catalog_personalization_policy_payload(self, payload):
        return self.post(Route('catalog/v3/policies/personalizations'), payload)

    def get_all_catalog_personalization_policies(self, search_fields=None, search_text=None, sort_field=None,
                                                 limit=None, offset=None, active=None):
        return self.get(Route('catalog/v3/policies/personalizations',
                              query_parameters={'searchFields': search_fields, 'searchText': search_text,
                                                'sortField': sort_field, 'limit': limit, 'offset': offset,
                                                'active': active}))

    def delete_catalog_personalization_policy(self, policy_id):
        return self.delete(Route('catalog/v3/admin/policies/personalizations/{policy_id}', {'policy_id': policy_id}))

    def update_catalog_personalization_policy(self, policy_id, payload):
        return self.put(Route('catalog/v3/admin/policies/personalizations/{policy_id}', {'policy_id': policy_id}), payload)

    def patch_catalog_personalization_policy(self, policy_id, payload):
        return self.patch(Route('catalog/v3/admin/policies/personalizations/{policy_id}', {'policy_id': policy_id}), payload)

    def find_add_on_services(self, provider_code, service_offering_id, payload):
        return self.post(Route('catalog/v3/providers/%s/services/{service_offering_id}/addons' % provider_code, {'service_offering_id': service_offering_id}), payload)

    def set_visibility_mode(self, mode):
        return self.patch(Route('catalog/v3/admin/configs/visibilitymodes/{mode}/turnon', {'mode': mode}), payload={})

    def get_order_workflow_config(self):
        return self.get(Route('order_workflow/api/configuration/v2'))

    def set_order_workflow_config(self, payload):
        return self.post(Route('order_workflow/api/configuration/v2'), payload)

    def get_order_workflow_config_v3(self):
        return self.get(Route('approvals/v3/configuration'))

    def set_order_workflow_config_v3(self, payload):
        return self.post(Route('approvals/v3/configuration'), payload)

    def create_shopping_bag(self, payload):
        return self.post(Route('shoppingbag/v1/bags'), payload)

    def add_shopping_bag_item(self, bag_id, payload):
        return self.post(Route('shoppingbag/v1/bags/{bag_id}/bagitems', {'bag_id': bag_id}), payload)

    def add_add_on_to_shopping_bag_item(self, bag_id, bag_item_id, payload):
        return self.post(Route('shoppingbag/v1/bags/{bag_id}/bagitems/{bag_item_id}/addons', {'bag_id': bag_id, 'bag_item_id': bag_item_id}), payload)

    def delete_add_on_in_shopping_bag_item(self, bag_id, bag_item_id, add_on_id):
        return self.post(Route('shoppingbag/v1/bags/{bag_id}/bagitems/{bag_item_id}/addons/{add_on_id}'), {'bag_id': bag_id, 'bag_item_id': bag_item_id, 'add_on_id': add_on_id})

    def get_shopping_bag_items(self, bag_id, include='', limit='50', offset='0'):
        return self.get(Route('shoppingbag/v1/bags/{bag_id}/bagitems', {'bag_id': bag_id}, {'include': include, 'limit': limit, 'offset': offset}))

    def get_shopping_bag_item(self, bag_id, bag_item_id):
        return self.get(Route('shoppingbag/v1/bags/{bag_id}/bagitems/{bag_item_id}', {'bag_id': bag_id, 'bag_item_id': bag_item_id}))

    def create_shopping_bag_and_items(self, payload):
        return self.post(Route('shoppingbag/v1/bags/bagitems'), payload)

    def patch_shopping_bag_item(self, bag_id, bag_item_id, payload):
        return self.patch(Route('shoppingbag/v1/bags/{bag_id}/bagitems/{bag_item_id}', {'bag_id': bag_id, 'bag_item_id': bag_item_id}), payload)

    def get_all_shopping_bags(self, bag_status=None, limit=None, offset=None):
        return self.get(Route('shoppingbag/v1/bags', query_parameters={'bagStatus': bag_status, 'limit': limit, 'offset': offset}))

    def get_shopping_bag(self, bag_id):
        return self.get(Route('shoppingbag/v1/bags/{bag_id}', {'bag_id': bag_id}))

    def update_shopping_bag(self, bag_id, payload):
        return self.put(Route('shoppingbag/v1/bags/{bag_id}', {'bag_id': bag_id}), payload)

    def transfer_shopping_bag(self, bag_id, payload):
        return self.patch(Route('shoppingbag/v1/bags/{bag_id}', {'bag_id': bag_id}), payload)

    def delete_shopping_bag(self, bag_id):
        return self.delete(Route('shoppingbag/v1/bags/{bag_id}', {'bag_id': bag_id}))

    def delete_shopping_bag_item(self, bag_id, bag_item_id):
        return self.delete(Route('shoppingbag/v1/bags/{bag_id}/bagitems/{bag_item_id}', {'bag_id': bag_id, 'bag_item_id': bag_item_id}))

    def export_shopping_bag_bom(self, bag_id):
        return self.get(Route('shoppingbag/v1/bags/{bag_id}/exportbom', {'bag_id': bag_id}))

    def submit_cart_order(self, bag_id):
        return self.post(Route('orders/v1/bags/{bag_id}/submit', {'bag_id': bag_id}), {})

    def cancel_order(self, order_id, payload):
        return self.post(Route('api/orders/{order_id}/cancel', {'order_id': order_id}), payload)

    def apply_budget_to_order(self, order_id, payload):
        return self.post(Route('api/orders/{order_id}/budgetaryUnit', {'order_id': order_id}), payload)

    def submit_new_order(self, payload):
        return self.post(Route('orders/v1/submit'), payload)

    def get_order(self, order_id):
        return self.get(Route('api/orderWorkFlow/v2', query_parameters={'orderId': order_id}))

    def approve_order(self, payload):
        return self.post(Route('api/orderWorkFlow/v2'), payload)

    def provision_post_hook(self, payload):
        return self.post(Route('message/ProvisioningPostHook'), payload)

    def provision_pre_hook(self, payload):
        return self.post(Route('message/ProvisioningPreHook'), payload)

    def get_external_post_hook_request_number(self, service_fulfillment_id):
        return self.get(Route('adapter/generic/external/posthook/fulfillment/{service_fulfillment_id}', {'service_fulfillment_id': service_fulfillment_id}))

    def provision_post_hook_external(self, payload):
        return self.post(Route('adapter/generic/external/posthook'), payload)

    def export_bom(self, operation_id, provider_code, service_id, bom_type, payload):
        return self.post(Route('icb/inventory/v4/operations/{operation_id}/exportbom', {'operation_id': operation_id},
                               query_parameters={'providerCode': provider_code, 'serviceId': service_id, 'bomType': bom_type}), payload)

    def download_aws_key_pair(self, service_inventory_id):
        status_code, response_body = self.post(Route('icb/inventory/v5/services/{service_inventory_id}/download', {'service_inventory_id', service_inventory_id}), {})
        try:
            response_body = gzip.decompress(response_body).decode('utf-8')
            self.logger.info('GZIP worked')
        except Exception as e:
            self.logger.error(e)
            str_buffer = []
            try:
                with ZipFile(BytesIO(response_body)) as zip_bytes:
                    for content in zip_bytes.namelist():
                        for line in zip_bytes.open(content).readlines():
                            str_buffer.append(line.decode('utf-8'))
                response_body = ''.join(str_buffer)
                self.logger.info('ZIP worked')
            except Exception as e_:
                self.logger.error(e_)
        return status_code, response_body

    def get_all_orders(self, sort_by='createdDate', sort_dir='desc', limit=50, offset=0):
        return self.get(Route('v5/api/orders',
                              query_parameters={'sortBy': sort_by, 'sortDir': sort_dir, 'limit': limit, 'offset': offset}))

    def get_order_details(self, order_id):
        return self.get(Route('v5/api/orders/{order_id}/detail', {'order_id': order_id}))

    def get_orders_budget_info(self, order_id, filter_approvers='true'):
        return self.get(Route('api/orders/{order_id}/budgetInfo', {'order_id': order_id}, query_parameters={'filterByApprovers': filter_approvers}))

    def get_services_order_history(self, service_inventory_id):
        return self.get(Route('v3/api/order_history/{service_inventory_id}', {'service_inventory_id': service_inventory_id}))

    def get_orders_order_history(self, order_id):
        return self.get(Route('v5/api/orders/{order_id}/orderhistory', {'order_id': order_id}))

    def get_approvals_order_history(self, order_id):
        return self.get(Route('approvals/v3/{order_id}/orderHistory', {'order_id': order_id}))

    def search_in_orders(self, search_text=None):
        return self.get(Route('v3/api/orders', query_parameters={'searchText': search_text}))

    def search_in_approve_orders(self, status='Approval%20In%20Progress', sort_by='createdDate', sort_dir='desc', limit=50, offset=0, search_text=''):
        return self.get(Route('v5/api/orders/approver_orders',
                        query_parameters={'status': status, 'sortBy': sort_by, 'sortDir': sort_dir, 'limit': limit, 'offset': offset, 'searchText': search_text}))

    def retry_fulfillment(self, service_fulfillment_id):
        return self.post(Route('v3/api/fulfillment/retryservice/{service_fulfillment_id}', {'service_fulfillment_id': service_fulfillment_id}), {})

    def cancel_fulfillment(self, service_fulfillment_id):
        return self.post(Route('v3/api/fulfillment/cancelservice/{service_fulfillment_id}', {'service_fulfillment_id': service_fulfillment_id}), {})

    def get_fulfillment_info(self, order_id):
        return self.get(Route('v2/api/fulfillment/{order_id}/servicefulfillments', {'order_id': order_id}))

    def set_fulfillment_config(self, payload):
        return self.post(Route('v4/api/fulfillment/configuration'), payload)

    def edit_service(self, service_inventory_id, payload):
        return self.put(Route('icb/inventory/v5/services/{service_inventory_id}', {'service_inventory_id': service_inventory_id}), payload)

    def cancel_edit_service(self, service_inventory_id, payload):
        return self.post(Route('v3/api/services/{service_inventory_id}', {'service_inventory_id': service_inventory_id}), payload)

    def delete_service(self, payload):
        return self.post(Route('v2/api/services/deleteservices'), payload)

    def get_soi_properties(self, provider_code, service_inventory_id, header_language=None):
        if header_language:
            self.temp_headers.update(self._headers)
            self.temp_headers['Accept-Language'] = header_language
        return self.get(Route('v2/api/services/%s/{service_inventory_id}/properties' % provider_code, {'service_inventory_id': service_inventory_id}))

    def search_in_inventory(self, provider_code=None, page=1, size=40, search_text='', status='Active', sort_by='ProvisionDate', sort_order='desc'):
        status = 'status:%s' % status if status else ''
        provider = '%sproviderName:%s' % ('|' if status else '', provider_code) if provider_code else ''
        return self.get(Route('v2/api/services',
                              query_parameters={'page': page, 'size': size, 'searchText': search_text, 'sortBy': sort_by, 'sortOrder': sort_order, 'filterBy': f'{status}{provider}'}))

    def do_operation(self, payload, header_language=None):
        self.temp_headers.update(self._headers)
        self.temp_headers['Accept-Language'] = header_language
        return self.post(Route('icb/inventory/v4/operations'), payload)

    def do_custom_operation(self, payload, provider_account_id, credential_id, header_language=None):
        self.temp_headers = self.create_configuration_headers(provider_account_id, credential_id)
        self.temp_headers.update(self._headers)
        self.temp_headers['Accept-Language'] = header_language
        self.temp_headers.pop('cb-user-info')
        return self.post(Route('icb/inventory/v4/operations'), payload)

    def get_gcs_operations(self, provider_code):
        return self.get(
            Route('genericcontentserver/v1/providers/{provider_code}/operations', {'provider_code': provider_code}))

    def get_gcs_operation(self, provider_code, op_id):
        return self.get(Route('genericcontentserver/v1/providers/{provider_code}/operations/{op_id}',
                              {'provider_code': provider_code, 'op_id': op_id}))

    def update_gcs_operation(self, provider_code, op_id, payload):
        return self.put(Route('genericcontentserver/v1/providers/{provider_code}/operations/{op_id}',
                              {'provider_code': provider_code, 'op_id': op_id}), payload)

    def delete_gcs_operation(self, provider_code, op_id):
        return self.delete(Route('genericcontentserver/v1/providers/{provider_code}/operations/{op_id}',
                                 {'provider_code': provider_code, 'op_id': op_id}))

    def import_soi(self, payload):
        return self.post(Route('v3/api/inventory/import'), payload)

    def delete_zombie(self, inventory_id, provider_account_id, provider_credential_id):
        self.temp_headers = self.create_configuration_headers(provider_account_id, provider_credential_id)
        return self.delete(Route('icb/inventory/v3/services/{inventory_id}', {'inventory_id': inventory_id}))

    def get_service_tag_data(self, page=1, size=10, search_text='', status='Active', format_='json', sort_by='ProvisionDate', sort_order='desc'):
        return self.get(Route('v3/api/inventory/download',
                              query_parameters={'page': page, 'size': size, 'searchText': search_text, 'sortBy': sort_by, 'sortOrder': sort_order, 'filterBy': f'status:{status}', 'format': format_}))

    def get_service(self, provider_code, service_inventory_id, resource_id=None):
        return self.get(Route('v3/api/services/{provider_code}/{service_inventory_id}', {'service_inventory_id': service_inventory_id, 'provider_code': provider_code}, query_parameters={'resourceId': resource_id}))

    def get_service_status(self, resource_id, provider_code, service_inventory_id):
        return self.get(Route('v2.0/resource/{resource_id}/state', {'resource_id': resource_id}, query_parameters={'provider_id': provider_code, 'SID': service_inventory_id}))

    def get_operations_definitions(self, type_= None, provider_code=None, service_offering_id=None, resource_type=None, managed=None, context=None, asset_account=None, cred_account=None, header_language=None):
        if asset_account and cred_account:
            self.temp_headers = self.create_configuration_headers(asset_account, cred_account)
        if resource_type:
            type_ = 'SOC'
        if header_language:
            self.temp_headers.update(self._headers)
            self.temp_headers['Accept-Language'] = header_language
        return self.get(Route('inventory/v3/operations/definition', query_parameters={'type': type_,
        'providerCode': provider_code, 'serviceOfferingId': service_offering_id, 'resourceTypeId': resource_type, 'managed': managed, 'context': '|'.join(['%s:%s' % (k, v) for k, v in context.items()]) if context else None}))


    def get_operation_definition(self, operation_id, header_language=None, provider_code=None):
        self.temp_headers.update(self._headers)
        self.temp_headers['Accept-Language'] = header_language
        return self.get(Route('inventory/v3/operations/definition/{operation_id}', {'operation_id': operation_id},
                              query_parameters={'providerCode': provider_code}))

    def patch_operations_definitions(self, payload):
        return self.patch(Route('inventory/v3/operations/definition/update_existing'), payload)

    def patch_service_offerings(self, payload):
        return self.patch(Route('catalog/v3/admin/serviceOfferings'), payload)

    def patch_configuration_d2ops(self, payload):
        return self.patch(Route('icb/inventory/v1/api/services/configuration'), payload)

    def create_managed_services_tags(self, payload):
        return self.post(Route('v1/api/managedservicestags'), payload)

    def get_managed_services_tags(self, provider_code):
        return self.get(Route('v1/api/managedservicestags/%s' % provider_code))

    def update_managed_services_tags(self, provider_code, payload):
        return self.put(Route('v1/api/managedservicestags/%s' % provider_code), payload)

    def patch_managed_services_tags(self, provider_code, payload):
        return self.patch(Route('v1/api/managedservicestags/%s' % provider_code), payload)

    def delete_managed_services_tags(self, provider_code):
        return self.delete(Route('v1/api/managedservicestags/%s' % provider_code))

    def get_output_params(self , provider_code, serviceId):
        return self.get(Route('icb/inventory/v1/api/services/%s/{serviceId}/outputparams' % provider_code, {"serviceId": serviceId}))

    def post_template_output_params(self , payload):
        return self.post(Route('adapter/generic/inventory/services/outputparams'), payload)

    def get_discovery_status(self, payload, history_param):
        return self.post(Route('catalog/v3/admin/discoverystatus', query_parameters={'history': history_param}), payload)

    def enable_service_offering_versioning(self, provider_code, body):
        return self.put(Route('catalog/v3/providers/%s' % provider_code), body)

    def g11n_export_operation_definition(self, operation_definitions, provider_code):
        str_operation_definitions = ','.join(operation_definitions)
        return self.get(Route('inventory/v3/operations/definition/g11n/export', query_parameters={'providerCode': provider_code,'operationDefinitionIds': str(str_operation_definitions)}))

    def g11n_import_operation_definition(self, payload, header_language):
        self.temp_headers.update(self._headers)
        self.temp_headers['Accept-Language'] = header_language
        return self.post(Route('inventory/v3/operations/definition/g11n/import'), payload)

    def get_pricing_rules(self, payload):
        return self.post(Route('catalog/v3/pricingrule'), payload)

    def create_pricing_rule(self, payload):
        return self.post(Route('catalog/v3/admin/pricingrule'), payload)

    def update_pricing_rule(self, payload):
        return self.put(Route('catalog/v3/admin/pricingrule'), payload)

    def create_service_offering_group(self, payload):
        return self.post(Route('catalog/v3/admin/serviceofferinggroups'), payload)

    def get_service_offering_group(self, sog_id):
        return self.get(Route('catalog/v3/serviceofferinggroups/{sog_id}', {'sog_id': sog_id}))

    def get_service_offering_groups(self, serviceofferingstatus=None):
        return self.get(Route('catalog/v3/serviceofferinggroups',
                              query_parameters={"serviceofferingstatus": serviceofferingstatus}))

    def update_service_offering_group(self, sog_id, payload):
        return self.put(Route('catalog/v3/admin/serviceofferinggroups/{sog_id}', {'sog_id': sog_id}), payload)

    def patch_service_offering_group(self, sog_id, payload):
        return self.patch(Route('catalog/v3/admin/serviceofferinggroups/{sog_id}', {'sog_id': sog_id}), payload)

    def delete_service_offering_group(self, sog_id):
        return self.delete(Route('catalog/v3/admin/serviceofferinggroups/{sog_id}', {'sog_id': sog_id}))

    def get_serviceofferings_versions(self, payload):
        return self.post(Route('catalog/v3/serviceofferings/versions', query_parameters={'limit': '20', 'sortOrder': 'asc'}), payload)

    def create_catalog_category(self, payload):
        return self.post(Route('catalog/v3/admin/categories'), payload)

    def get_catalog_categories(self):
        return self.get(Route('catalog/v3/categories'))

    def update_catalog_category(self, payload):
        return self.put(Route('catalog/v3/admin/categories'), payload)

    def patch_catalog_category(self, cat_id, payload):
        return self.patch(Route('catalog/v3/admin/categories/{cat_id}', {'cat_id': cat_id}), payload)

    def delete_catalog_category(self, cat_id):
        return self.delete(Route('catalog/v3/admin/categories/{cat_id}', {'cat_id': cat_id}))

    def catalog_import(self, files):
        self.temp_headers = deepcopy(self._headers)
        self.temp_headers.pop("Content-Type")
        self.temp_headers.pop("Accept")
        return self.upload(Route('catalog/v3/admin/content/g11n/import'), files)

    def decrypt_aws_password(self, soi_id,provider_code):
        def _password_masker(payload_, mask):
            raise NotImplementedError
            # todo
            #mask(payload_, 'field to mask')
        return self.get(Route('icb/inventory/v5/decrypt/{provider_code}/{soi_id}', {'provider_code':provider_code, 'soi_id': soi_id}), response_mask=_password_masker)

    def common_create_queue(self, payload):
        return self.post(Route('emp/common/messages/queues'), payload)

    def common_get_queues(self):
        return self.get(Route('emp/common/messages/queues'))

    def common_get_queue(self, name):
        return self.get(Route('emp/common/messages/queues/{name}', {'name': name}))

    def common_delete_queue(self, name):
        return self.delete(Route('emp/common/messages/queues/{name}', {'name': name}))

    def common_create_exchange(self, payload):
        return self.post(Route('emp/common/messages/exchanges'), payload)

    def common_get_exchanges(self):
        return self.get(Route('emp/common/messages/exchanges'))

    def common_get_exchange(self, name):
        return self.get(Route('emp/common/messages/exchanges/{name}', {'name': name}))

    def common_delete_exchange(self, name):
        return self.delete(Route('emp/common/messages/exchanges/{name}', {'name': name}))

    def common_create_client(self, payload):
        return self.post(Route('emp/common/clients'), payload)
        
    def common_get_clients(self, payload):
        return self.post(Route('emp/common/retrieve_clients'), payload)

    def common_get_client(self, name):
        return self.get(Route('emp/common/clients/{name}', {'name': name}))

    def common_update_client(self, name, payload):
        return self.put(Route('emp/common/clients/{name}', {'name': name}), payload)

    def common_delete_client(self, name):
        return self.delete(Route('emp/common/clients/{name}', {'name': name}))

    def change_owner(self, payload):
        return self.patch(Route('icb/inventory/v5/services/changeowner'),payload)

    def initiate_transfer(self, payload):
        return self.patch(Route('icb/inventory/v5/services/initiatetransfer'), payload)

    def patch_change_context(self, payload):
        return self.patch(Route('icb/inventory/v5/services/changecontext'), payload)

    def patch_accept_transfer(self, payload):
        return self.patch(Route('icb/inventory/v5/services/accepttransfer'), payload)

    def patch_resend_transfer(self, payload):
        return self.patch(Route('icb/inventory/v5/services/resendtransfer'), payload)

    def patch_cancel_transfer(self, transfer_id):
        return self.patch(Route('icb/inventory/v5/services/canceltransfer'), transfer_id)

    def patch_update_transfer(self, payload):
        return self.patch(Route('icb/inventory/v5/services/updateinventorytransfer'), payload)

    def patch_deny_transfer(self, payload):
        return self.patch(Route('icb/inventory/v5/services/denytransfer'), payload)

    def get_transfer_doc(self, sortOrder='asc', limit=20, offset=0, status=None, transferId=None, sid=None, operation=None):
        return self.get(Route('icb/inventory/v5/services/transferservices', query_parameters={'sortOrder': sortOrder, 'limit': limit, 'offset': offset,'status': status, 'transferId': transferId, 'sid': sid, 'operation': operation}))

    def filter_SOI_inventory(self, payload):
        return self.post(Route('icb/inventory/v5/services'),payload)

    def post_service_transfer_status(self, service_id):
        return self.post(Route('icb/inventory/v5/servicestatus'), service_id)

    def post_migration_start(self):
        return self.post(Route('icb/inventory/v5/migration/start'), { 'MigrationKey': 'Version', 'MigrationValue': '1'})

    def post_inventory_job_one_init(self):
        return self.post(Route('icb/inventory/v5/operations/joboneinit'), {})

    def post_inventory_job_one_failed(self):
        return self.post(Route('icb/inventory/v5/operations/jobonefailed'), {})

    def post_inventory_job_one_complete(self):
        return self.post(Route('icb/inventory/v5/operations/joboneomplete'), {})

    def post_inventory_job_two_init(self):
        return self.post(Route('icb/inventory/v5/operations/jobtwoinit'), {})

    def post_inventory_job_two_failed(self):
        return self.post(Route('icb/inventory/v5/operations/jobtwofailed'), {})

    def post_inventory_job_two_complete(self):
        return self.post(Route('icb/inventory/v5/operations/jobtwocomplete'), {})
    
    def get_transfer_history_docs(self, sortOrder='asc', limit=20, offset=0, status=None, transferId=None, sid=None, operation=None):
        return self.get(Route('icb/inventory/v5/services/transferHistory', query_parameters={'sortOrder': sortOrder, 'limit': limit, 'offset': offset,'status': status, 'transferId': transferId, 'sid': sid, 'operation': operation}))

    def get_filtered_service_offering_ids(self,sortOrder='asc',limit=20,offset=0,searchText=None):
        return self.get(Route('icb/inventory/v5/services/filterserviceofferingids',query_parameters={"sortOrder":sortOrder,"limit":limit,"offSet":offset ,"searchText": searchText}))
      
    def refresh_users(self):
        return self.get(Route('icb/inventory/v5/services/refreshusers'))

    def transfer_users(self, limit=20, offset=0, transferId=None, sid=None, action =None):
        return self.get(Route('icb/inventory/v5/services/transferusers', query_parameters={'limit': limit, 'offset': offset, 'transferId': transferId, 'sid': sid, 'action': action}))

    def fetch_configuration(self, payload, providerCode, serviceId):
        return self.post(Route('inventory/v5/operations/{providerCode}/services/{serviceId}/configurations', {'providerCode': providerCode, 'serviceId': serviceId}), payload)

    def post_execute_operation(self, paylaod):
        return self.post(Route('icb/inventory/v5/operations'), paylaod)

    def get_operation_execution_record(self, operationReqId):
        return self.get(Route('icb/inventory/v5/operations', query_parameters={'operationRequestId': operationReqId}))

    def post_mcas_operations_definition(self, payload):
        return self.post(Route('inventory/v5/operations/definition'), payload)

    def get_operation_visibility(self, contentProviderCode, targetProviderCode, brokerSID, resourceId, operationDefinitionId, actionSource):
        return self.get(Route('icb/inventory/v5/operations/visibility', query_parameters={'contentProviderCode': contentProviderCode, 'targetProviderCode': targetProviderCode, 'brokerSID': brokerSID, 'resourceId': resourceId, 'operationDefinitionId': operationDefinitionId, 'actionSource': actionSource}))