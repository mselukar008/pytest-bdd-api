from requests import codes

from marketplace import payload_helper
from marketplace.api_client import MarketplaceApiClient
from utils.entities_base import (
    EntitiesBase,
    EntityBase
)


class Entities(EntitiesBase):
    def __init__(self, api_client, data, logger=None):
        super().__init__(api_client, data, logger)
        self.Catalog = Catalog(api_client, logger)
        self.Common = Common(api_client, logger)
        self.OrderWorkflow = OrderWorkflow(api_client, logger)
        self.Policies = Policies(api_client, logger)

    @staticmethod
    def create_instance(host: str, user: str, apikey: str, logger, authorization: str):
        headers = MarketplaceApiClient.create_headers(user, apikey, authorization)
        return Entities(
            MarketplaceApiClient(host, headers,
                        logger,
                        {},
                        max_round_trip=300,
                        json_indent=4),
            {},
            logger
        )

class Catalog(EntityBase):
    def _assert_response(self, code=codes.OK):
        return (self.status_code == code
                and self.response_body['failedCount'] == 0
                and self.response_body['reasons'][0]['statusCode'] == code
                and self.response_body['successCount'] > 0)

    def create_provider_adapter(self, payload):
        self.logger.info(f'Creating provider adapter(s) for {", ".join(x["providerCode"] for x in payload["providers_adapters"])}')
        self.request_handler(self.api_client.create_provider_adapter, payload)
        return self.status_code == codes.OK

    def create_service_offering(self, provider_code, payload):
        self.request_handler(self.api_client.create_service_offering, provider_code, payload)
        return self._assert_response()

    def update_provider_adapter(self, provider_code, payload):
        self.request_handler(self.api_client.update_provider_adapter, provider_code, payload)
        return self.status_code == codes.OK

    def get_service_offering(self, provider_code, service_offering_id):
        self.request_handler(self.api_client.get_service_offering_info, provider_code, service_offering_id)
        return self.status_code == codes.OK

    def get_service_offerings(self, payload, sort_order=None, limit=None, offset=None,
                              search_fields=None, service_type=None, default_version=None):
        self.request_handler(self.api_client.get_service_offerings, payload, sort_order=sort_order, limit=limit,
                             offset=offset, search_fields=search_fields, service_type=service_type,
                             default_version=default_version)
        return self._assert_response()

    def update_service_offering(self, provider_code, service_offering_id, payload):
        self.request_handler(self.api_client.update_service_offering, provider_code, service_offering_id, payload)
        return self._assert_response()

    def patch_service_offering(self, provider_code, service_offering_id, payload):
        self.request_handler(self.api_client.patch_service_offering, provider_code, service_offering_id, payload)
        return self.status_code == codes.OK

    def patch_service_offerings(self, payload):
        self.request_handler(self.api_client.patch_service_offerings, payload)
        return self.status_code == codes.OK

    def retire_service_offering(self, provider_code, service_offering_id):
        all_good = False
        if self.get_service_offering(provider_code, service_offering_id):
            payload = self.response_body
            payload['status'] = 'Retired'
            all_good = self.update_service_offering(provider_code, service_offering_id, payload)
        return all_good

    def enable_service_offering_versioning(self, provider_code, body):
        self.request_handler(self.api_client.enable_service_offering_versioning, provider_code, body)
        return self.status_code == codes.OK

    def delete_service_offering(self, provider_code, service_offering_id):
        self.logger.info(f"Deleting {provider_code}'s offering: {service_offering_id}")
        self.request_handler(self.api_client.delete_service_offering, provider_code, service_offering_id)
        return (self.status_code == codes.OK
                and self.response_body.get('failedCount', 1) == 0
                and self.response_body.get('reasons', [{}])[0].get('statusCode', 0) == codes.NO_CONTENT)

    def get_provider_adapter(self, provider_code):
        self.request_handler(self.api_client.get_provider_adapter, provider_code)
        return self.status_code == codes.OK

    def get_provider_adapters(self, provider_offering_types='iaas,asp'):
        self.request_handler(self.api_client.get_provider_adapters, provider_offering_types)
        return self.status_code == codes.OK

    def delete_provider_adapter(self, adapter_url, provider_code):
        self.logger.info(f'Deleting provider adapter for {provider_code}')
        self.request_handler(self.api_client.delete_provider_adapter, parse.quote(adapter_url, safe=''), provider_code)
        return self._assert_response()

    def delete_provider_and_service_offerings(self, provider_code, adapter_url):
        all_good = False
        payload = payload_helper.build_get_catalog_offerings(provider_codes=[provider_code])
        if self.get_service_offerings(payload, limit=500):
            all_good = True
            offerings = self.response_body['result']['services']
            for offering in offerings:
                all_good &= self.delete_service_offering(provider_code, offering['serviceId'])
            if all_good:
                all_good &= self.delete_provider_adapter(adapter_url, provider_code)
        return all_good

    def get_generic_content_services(self, provider_code):
        self.request_handler(self.api_client.get_generic_content_services, provider_code)
        return self.status_code == codes.OK

    def get_generic_content_service(self, provider_code, so_id):
        self.request_handler(self.api_client.get_generic_content_service, provider_code, so_id)
        return self.status_code == codes.OK

    def update_generic_content_service(self, provider_code, so_id, body, ignorestatus=True):
        self.request_handler(self.api_client.update_generic_content_service, provider_code, so_id, body, ignorestatus)
        return self.status_code == codes.OK

    def patch_generic_content_service(self, provider_code, so_id, body, ignorestatus=True):
        self.request_handler(self.api_client.patch_generic_content_service, provider_code, so_id, body, ignorestatus)
        return self.status_code == codes.OK

    def delete_content_template(self, provider_code, service_offering_id):
        self.logger.info(f'Deleting content template: {provider_code} {service_offering_id}')
        self.request_handler(self.api_client.delete_content_template, provider_code, service_offering_id)
        return self.status_code == codes.OK

    def get_configurations(self, provider_code, service_offering_id, provider_account_id, provider_account_cred_id, context):
        self.request_handler(self.api_client.get_configurations, 
                             provider_code,
                             service_offering_id,
                             provider_account_id,
                             provider_account_cred_id,
                             {'contexts': context})
        return self._assert_response()

    def configuration_callback(self, provider_code, service_offering_id, provider_account_id, provider_cred_id, payload):
        self.logger.info(f'Grabbing values for: {payload["dependentConfigId"]}')
        self.request_handler(self.api_client.configuration_callback, provider_code, service_offering_id, provider_account_id, provider_cred_id, payload)
        return self._assert_response()

    def configuration_search(self, provider_code, service_offering_id, provider_account_id, provider_cred_id, payload):
        self.logger.info(f'Searching values for: {payload["configId"]}')
        self.request_handler(self.api_client.configuration_search, provider_code, service_offering_id, provider_account_id, provider_cred_id, payload)
        return self._assert_response()

    def configuration_validation(self, provider_code, service_offering_id, provider_account_id, provider_cred_id, payload):
        self.logger.info(f'Validate configuration for: {service_offering_id}')
        self.request_handler(self.api_client.configuration_validation, provider_code, service_offering_id, provider_account_id, provider_cred_id, payload)
        return self.status_code == codes.OK and all(x.get('statusCode', 0) == codes.OK for x in self.response_body.get('reasons', []))

    def find_add_on_services(self, provider_code, service_offering_id, payload):
        self.request_handler(self.api_client.find_add_on_services, provider_code, service_offering_id, payload)
        return self.status_code == codes.OK

    def get_pricing(self, version, provider_code, service_offering_id, provider_account_id, provider_cred_id, payload):
        self.logger.info(f'Getting pricing on {service_offering_id} configuration')
        self.request_handler(self.api_client.get_pricing, version, provider_code, service_offering_id,
                             provider_account_id, provider_cred_id, payload)
        return self.status_code == codes.OK and self.response_body.get('failedCount') == 0

    def get_service_offering_info(self, provider_code, service_offering_id):
        self.request_handler(self.api_client.get_service_offering_info, provider_code, service_offering_id)
        return self.status_code == codes.OK and self.response_body.get('failedCount') == 0 and self.response_body.get('reasons', [{}])[0].get('statusCode') != codes.NOT_FOUND

    def calculate_pricing(self, order_payload):
        pricing = None
        if self.get_service_offering_info(order_payload['providerCode'], order_payload['serviceOfferingId']):
            pricing_payload = payload_helper.create_pricing_payload(order_payload)
            if (self.get_pricing(self.response_body['result']['apiDocVersion'],
                                 order_payload['providerCode'],
                                 order_payload['serviceOfferingId'],
                                 order_payload['providerAccountRefId'],
                                 order_payload['providerCredentialRefId'],
                                 pricing_payload)
                    and self.response_body['result']['total']['nonOneTimeCharge'] is not None
                    and self.response_body['result']['total']['oneTimeCharge'] is not None):
                pricing = self.response_body['result']['total']['nonOneTimeCharge'] + self.response_body['result']['total']['oneTimeCharge']
        return pricing

    def get_edit_soi_pricing(self, version, provider_code, service_offering_id, service_instance_id, provider_account_id, provider_cred_id, payload):
        self.logger.info(f'Getting pricing on Edit {service_offering_id} configuration')
        self.request_handler(self.api_client.get_edit_soi_pricing, version, provider_code, service_offering_id, service_instance_id,provider_account_id, provider_cred_id, payload)
        return self.status_code == codes.OK and self.response_body.get('failedCount') == 0

    def gcs_on_board(self, file_path):
        self.logger.info(f'On boarding content to GCS: {os.path.basename(file_path)}')
        self.request_handler(self.api_client.gcs_on_board, file_path)
        return self.status_code == codes.OK and self.response_body.get('statusCode', 0) == codes.OK

    def set_visibility_mode(self, mode):
        self.request_handler(self.api_client.set_visibility_mode, mode)
        return self.status_code == codes.OK

    def get_discovery_status(self, payload, history_param):
        self.request_handler(self.api_client.get_discovery_status, payload, history_param)
        return self.status_code == codes.OK and self.response_body.get('failedCount') == 0

    def get_pricing_rules(self, payload):
        self.request_handler(self.api_client.get_pricing_rules, payload)
        return self.status_code == codes.OK

    def create_pricing_rule(self, payload):
        self.request_handler(self.api_client.create_pricing_rule, payload)
        return self.status_code == codes.OK

    def update_pricing_rule(self, payload):
        self.request_handler(self.api_client.update_pricing_rule, payload)
        return self.status_code == codes.OK

    def create_service_offering_group(self, payload):
        self.request_handler(self.api_client.create_service_offering_group, payload)
        return self.status_code == codes.OK and self.response_body.get('failedCount') == 0

    def get_service_offering_group(self, sog_id):
        self.request_handler(self.api_client.get_service_offering_group, sog_id)
        return self.status_code == codes.OK

    def get_service_offering_groups(self, serviceofferingstatus=None):
        self.request_handler(self.api_client.get_service_offering_groups, serviceofferingstatus)
        return self.status_code == codes.OK

    def update_service_offering_group(self, sog_id, payload):
        self.request_handler(self.api_client.update_service_offering_group, sog_id, payload)
        return self.status_code == codes.OK

    def patch_service_offering_group(self, sog_id, payload):
        self.request_handler(self.api_client.patch_service_offering_group, sog_id, payload)
        return self.status_code == codes.OK

    def delete_service_offering_group(self, sog_id):
        self.request_handler(self.api_client.delete_service_offering_group, sog_id)
        return self.status_code == codes.OK

    def get_serviceofferings_versions(self, payload):
        self.request_handler(self.api_client.get_serviceofferings_versions, payload)
        serviceofferingids_catalog = []
        for soid in payload:
            serviceofferingids_catalog.append(soid['serviceOfferingIds'])
        serviceofferingds_response = []
        for soid in self.response_body['results']:
            serviceofferingds_response.append(soid['soVersions']['serviceOfferingId'])
        return all(x in serviceofferingids_catalog for x in serviceofferingds_response) and self.status_code == codes.OK

    def create_catalog_category(self, payload):
        self.request_handler(self.api_client.create_catalog_category, payload)
        return self.status_code == codes.OK and self.response_body.get('failedCount') == 0

    def get_catalog_categories(self):
        self.request_handler(self.api_client.get_catalog_categories)
        return self.status_code == codes.OK

    def update_catalog_category(self, payload):
        self.request_handler(self.api_client.update_catalog_category, payload)
        return self.status_code == codes.OK and self.response_body.get('failedCount') == 0

    def patch_catalog_category(self, cat_id, payload):
        self.request_handler(self.api_client.patch_catalog_category, cat_id, payload)
        return self.status_code == codes.OK

    def delete_catalog_category(self, cat_id):
        self.request_handler(self.api_client.delete_catalog_category, cat_id)
        return self.status_code == codes.OK

    def get_gcs_operations(self, provider_code):
        self.request_handler(self.api_client.get_gcs_operations, provider_code)
        return self.status_code == codes.OK

    def get_gcs_operation(self, provider_code, op_id):
        self.request_handler(self.api_client.get_gcs_operation, provider_code, op_id)
        return self.status_code == codes.OK

    def update_gcs_operation(self, provider_code, op_id, payload):
        self.request_handler(self.api_client.update_gcs_operation, provider_code, op_id, payload)
        return self.status_code == codes.OK

    def delete_gcs_operation(self, provider_code, op_id):
        self.request_handler(self.api_client.delete_gcs_operation, provider_code, op_id)
        return self.status_code == codes.OK

    def catalog_import(self, file_path):
        with open(file_path, 'rb') as fin:
            file_name = os.path.basename(file_path)
            files = {'file': (file_name, fin, 'application/zip')}
            self.logger.info(f'On boarding content to Catalog: {file_name}')
            self.request_handler(self.api_client.catalog_import, files)
        return self.status_code == codes.OK and self.response_body['reasons'][0]['statusCode'] == codes.OK


class Common(EntityBase):
    def _assert_response_ok(self):
        return (self.status_code == codes.OK
                and self.response_body['status'] == 'OK'
                and self.response_body['statusCode'] == codes.OK)

    def get_feature_flag(self):
        self.request_handler(self.api_client.get_config_values, "icb_consume_beta")
        return self.status_code == codes.OK
        
    def set_feature_flag(self, enable):
        payload = {
            "configurationkey": "icb_consume_beta",
            "configurationvalue": "true" if enable else "false"
        }
        self.logger.info(f'Setting feature flag to "{payload["configurationvalue"]}"')
        self.request_handler(self.api_client.create_config_values, payload)
        return self.status_code == codes.OK

    def enable_feature_flag(self):
        return self.set_feature_flag(True)

    def disable_feature_flag(self):
        return self.set_feature_flag(False)

    def initialize_dummy_adapter(self, payload):
        self.logger.info(f"Initializing dummy adapter")
        self.request_handler(self.api_client.initialize_dummy_adapter, payload)
        return self.status_code == codes.OK

    def enable_dummy_adapter(self, provider_code):
        self.logger.info(f'Pointing {provider_code} adapter to dummy')
        self.request_handler(self.api_client.enable_dummy_adapter, provider_code)
        return self.status_code == codes.OK and isinstance(self.response_body, dict) and self.response_body.get('status', '') == 'Success'

    def disable_dummy_adapter(self, provider_code):
        self.logger.info(f'Pointing {provider_code} adapter to real')
        self.request_handler(self.api_client.disable_dummy_adapter, provider_code)
        return self.status_code == codes.OK and isinstance(self.response_body, dict) and self.response_body.get('status', '') == 'Success'

    def drop_dummy_table(self):
        self.logger.info('Dropping dummy adapter db table')
        self.request_handler(self.api_client.drop_dummy_table)
        return self.status_code == codes.OK

    def get_dummy_status(self):
        self.request_handler(self.api_client.get_dummy_status)
        return self.status_code == codes.OK

    def set_message_subscription(self, payload):
        self.logger.info('Subscribing a message')
        self.request_handler(self.api_client.common_create_client, payload)
        return self.status_code == codes.OK

    def create_queue(self, payload):
        self.logger.info(f'Creating queue for {payload.get("name")}')
        self.request_handler(self.api_client.common_create_queue, payload)
        return self._assert_response_ok()

    def get_queues(self):
        self.request_handler(self.api_client.common_get_queues)
        return self.status_code == codes.OK

    def get_queue(self, name):
        self.request_handler(self.api_client.common_get_queue, name)
        return self.status_code == codes.OK

    def delete_queue(self, name):
        self.logger.info(f'Deleting queue for {name}')
        self.request_handler(self.api_client.common_delete_queue, name)
        return self._assert_response_ok()


class OrderWorkflow(EntityBase):
    def __init__(self, api_client, logger):
        super(OrderWorkflow, self).__init__(api_client, logger)
        self.order_ids = []
        self._index = -1

    @property
    def order_id(self):
        return self.order_ids[self._index] if self.order_ids else None

    def set_order_id(self, index):
        try:
            self.order_ids[index]
            self._index = index
        except IndexError:
            self.logger.warning(f'Failed to set order because index is out of bounds. Tried to access [{index}]')

    def get_order_workflow_config(self):
        self.request_handler(self.api_client.get_order_workflow_config)
        return self.status_code == codes.OK

    def set_order_workflow_config(self, payload):
        self.logger.info('Setting Order-Workflow config')
        self.request_handler(self.api_client.set_order_workflow_config, payload)
        all_good = self.status_code == codes.OK
        if all_good and 'approvals' in payload:
            all_good = self.wait_for_approval_steps(
                [payload['approvals'][index]['name'] for index in range(len(payload['approvals']))]
            )
        return all_good

    def set_default_order_workflow_state(self):
        payload = utils.load_test_data(os.path.join('setup', 'default_state.json'))['orderworkflow_config']
        return self.set_order_workflow_config(payload)

    def get_order_workflow_config_v3(self):
        self.request_handler(self.api_client.get_order_workflow_config_v3)
        return self.status_code == codes.OK

    def set_order_workflow_config_v3(self, payload):
        self.logger.info('Setting Order-Workflow config')
        self.request_handler(self.api_client.set_order_workflow_config_v3, payload)
        all_good = self.status_code == codes.OK
        if all_good and 'approvals' in payload:
            all_good = self.wait_for_approval_steps(
            [payload['approvals'][index]['name'] for index in range(len(payload['approvals']))]
            )
        return all_good

    def external_approval_state(self, state, version='v3'):
        if version == 'v3' and state is True:
            self.set_order_workflow_config_v3(payload_helper.external_approval_state_v3())
        elif state is True:
            self.set_order_workflow_config(payload_helper.external_approval_state(True, version=version))
        else:
            self.set_order_workflow_config(payload_helper.external_approval_state(False, version='v2'))
        return self.status_code == codes.OK

    def enable_external_approval(self, version):
        return self.external_approval_state(True, version)

    def disable_external_approval(self, version):
        return self.external_approval_state(False, version)


class Policies(EntityBase):
    def __init__(self, api_client, logger):
        super().__init__(api_client, logger)
        self.operation_group_codes = []
        self._index = -1

    @property
    def operation_group_code(self):
        return self.operation_group_codes[self._index] if self.operation_group_codes else None

    def set_operation_group_code(self, group_code):
        try:
            self.operation_group_codes.append(group_code)
            self._index += 1
        except IndexError:
            self.logger.warning(f'Failed to set operation group because index is out of bounds. Tried to access [{self._index}]')

    def create_catalog_personalization_policy(self, policy_payload):
        self.logger.info(f'Creating catalog personalization policy: {policy_payload["name"]}')
        self.request_handler(self.api_client.create_catalog_personalization_policy, policy_payload)
        return self.status_code == codes.CREATED

    def get_all_catalog_personalization_policies(self, search_fields=None, search_text=None, sort_field=None,
                                                 limit=None, offset=None, active=None):
        self.request_handler(self.api_client.get_all_catalog_personalization_policies, search_fields=search_fields,
                             search_text=search_text, sort_field=sort_field, limit=limit, offset=offset, active=active)
        return self.status_code == codes.OK

    def get_catalog_personalization_policy(self, policy_id):
        self.request_handler(self.api_client.get_catalog_personalization_policy, policy_id)
        return self.status_code == codes.OK

    def get_catalog_personalization_policy_payload(self, payload):
        self.request_handler(self.api_client.get_catalog_personalization_policy_payload, payload)
        return self.status_code == codes.OK

    def patch_catalog_personalization_policy(self, policy_id, payload):
        self.logger.info(f'Patching catalog personalization policy: {policy_id}')
        self.request_handler(self.api_client.patch_catalog_personalization_policy, policy_id, payload)
        return self.status_code == codes.OK

    def get_policies(self):
        self.request_handler(self.api_client.get_policies)
        return self.status_code == codes.OK

    def get_policy_rules(self):
        self.request_handler(self.api_client.get_policy_rules)
        return self.status_code == codes.OK

    def delete_catalog_personalization_policy(self, policy_id):
        self.request_handler(self.api_client.delete_catalog_personalization_policy, policy_id)
        if self.status_code == codes.OK:
            self.logger.info(f'Deleted catalog personalization policy: "{policy_id}"')
        return self.status_code == codes.OK

    def delete_catalog_personalization_policies_by(self, predicate):
        all_good = True
        self.logger.info('Deleting catalog personalization policies')
        default_policy = '-1'
        while all_good and self.get_all_catalog_personalization_policies():
            if len(self.response_body['policies']) == 1 and self.response_body['policies'][0]['id'] == default_policy:
                break
            for policy in self.response_body['policies']:
                if policy['id'] != default_policy and predicate(policy):
                    all_good &= (self.activate_catalog_personalization_policy(policy['id'], False)
                                 and self.delete_catalog_personalization_policy(policy['id']))
        return all_good

    def delete_all_catalog_personalization_policies(self):
        return self.delete_catalog_personalization_policies_by(lambda x: True)

    def update_catalog_personalization_policy(self, policy_id, payload):
        self.logger.info(f'Updating catalog personalization policy: {policy_id}')
        self.request_handler(self.api_client.update_catalog_personalization_policy, policy_id, payload)
        return self.status_code == codes.OK

    def activate_catalog_personalization_policy(self, policy_id: str, active: bool) -> bool:
        return self.patch_catalog_personalization_policy(policy_id, {"active": active})

    def turn_off_default_catalog_personalization_policy(self):
        return self.activate_catalog_personalization_policy('-1', False)

    def turn_on_default_catalog_personalization_policy(self):
        return self.activate_catalog_personalization_policy('-1', True)

    def create_approval_policy(self, payload):
        self.logger.info('Calling Approval v3 Configurations')
        self.api_client.get_order_workflow_config_v3()
        self.logger.info(f'Creating new approval policy: {payload["name"]}')
        self.request_handler(self.api_client.create_approval_policy, payload)
        # Polling in case order workflow config was recently updated; which needs time to update internally.
        #self.poll_handler(30, lambda s, r: s in [codes.OK, codes.FORBIDDEN], self.api_client.create_approval_policy, payload)
        return self.status_code == codes.OK

    def get_approval_policy(self, policy_id):
        self.request_handler(self.api_client.get_approval_policy, policy_id)
        return self.status_code == codes.OK

    def get_approval_policies(self):
        self.request_handler(self.api_client.get_approval_policies)
        return self.status_code == codes.OK

    def get_approval_policy_rules(self, policy_id):
        self.request_handler(self.api_client.get_approval_rules, policy_id)
        return self.status_code == codes.OK

    def create_approval_policy_rule(self, policy_id, payload):
        self.request_handler(self.api_client.create_approval_rule, policy_id, payload)
        return self.status_code == codes.OK

    def update_approval_policy(self, policy_id, payload):
        self.request_handler(self.api_client.update_approval_policy, policy_id, payload)
        return self.status_code == codes.OK

    def update_approval_policy_rule(self, policy_id, rule_id, payload):
        self.request_handler(self.api_client.update_approval_policy_rule, policy_id, rule_id, payload)
        return self.status_code == codes.OK

    def delete_approval_policy_rule(self, policy_id, rule_id):
        self.request_handler(self.api_client.delete_approval_rule, policy_id, rule_id)
        return self.status_code == codes.OK

    def create_or_re_create_approval_policy(self, payload):
        ok = self.create_approval_policy(payload)
        if not ok and self.response_body.get('reasons', [{}])[0].get('translateCode') == 'MO400_POLICY_VALIDATION_FAILED_':
            if self.get_approval_policies():
                for policy in self.response_body['data']:
                    if policy['name'] == payload['name']:
                        self.delete_approval_policy(policy['policyId'])
                        ok = (self.edit_approval_policy_status(policy['policyId'], payload_helper.PolicyStatus.RETIRED)
                              and self.delete_approval_policy(policy['policyId']))
                        break
                if ok:
                    self.create_approval_policy(payload)
        return ok

    def re_rank_approval_policy(self, policy_id, priority):
        self.request_handler(self.api_client.edit_approval_policy_status, policy_id, {'priority': priority})
        return self.status_code == codes.OK

    def re_rank_approval_rules(self, policy_id, priority_map):
        ok = False
        if self.get_approval_policy(policy_id):
            self.logger.info('Re-ranking policies')
            for rule in self.response_body['rules']:
                if rule['priority'] in priority_map:
                    rule['priority'] = priority_map[rule['priority']]
            payload = {}
            for x in ['name', 'status', 'startDate', 'context', 'rules']:
                payload[x] = self.response_body[x]
            ok = self.update_approval_policy(policy_id, payload)
        return ok

    def delete_all_approval_policies(self):
        return self.delete_approval_policies_by(lambda x: True)

    def delete_approval_policies_by(self, predicate):
        result = True
        if self.get_approval_policies() and self.status_code != codes.NOT_FOUND:
            data = self.response_body['data']
            for policy in data:
                if predicate(policy):
                    self.logger.info(f'Deleting approval policy "{policy["name"]}"')
                    if policy['status'] == payload_helper.PolicyStatus.ACTIVE:
                        result &= self.edit_approval_policy_status(policy['policyId'], payload_helper.PolicyStatus.RETIRED)
                    result &= self.delete_approval_policy(policy['policyId'])
        else:
            result = False
        return result

    def edit_approval_policy_status(self, policy_id, status):
        self.request_handler(self.api_client.edit_approval_policy_status, policy_id, {"status": status})
        return self.status_code == codes.OK

    def delete_approval_policy(self, policy_id):
        self.logger.info(f'Deleting approval policy {policy_id}')
        self.request_handler(self.api_client.delete_approval_policy, policy_id)
        return self.status_code == codes.OK

    def create_fulfillment_policy(self, payload):
        self.logger.info(f'Creating fulfillment policy "{payload["name"]}"')
        self.request_handler(self.api_client.create_fulfillment_policy, payload)
        return self.status_code == codes.OK

    def get_fulfillment_policies(self):
        self.request_handler(self.api_client.get_fulfillment_policies)
        return self.status_code == codes.OK or self.status_code == codes.NOT_FOUND

    def update_fulfillment_policy(self, policy_id, payload):
        self.request_handler(self.api_client.update_fulfillment_policy, policy_id, payload)
        return self.status_code == codes.OK

    def delete_fulfillment_policy(self, policy_id):
        self.request_handler(self.api_client.delete_fulfillment_policy, policy_id)
        return self.status_code == codes.OK

    def delete_fulfillment_policies_by(self, predicate):
        result = True
        if self.get_fulfillment_policies() and self.response_body.get('data'):
            self.logger.info('Deleting all fulfillment policies')
            data = self.response_body['data']
            for policy in data:
                if predicate(policy):
                    payload = {
                        'name': policy['name'],
                        'status': payload_helper.PolicyStatus.RETIRED
                    }
                    if policy['status'] == payload_helper.PolicyStatus.ACTIVE:
                        if self.update_fulfillment_policy(policy['policyId'], payload):
                            result &= self.delete_fulfillment_policy(policy['policyId'])
                        else:
                            result &= False
                    else:
                        result &= self.delete_fulfillment_policy(policy['policyId'])
        return result

    def delete_all_fulfillment_policies(self):
        return self.delete_fulfillment_policies_by(lambda x: True)

    def delete_all_policies(self):
        all_good = self.delete_all_approval_policies()
        all_good &= self.delete_all_catalog_personalization_policies()
        all_good &= self.delete_all_fulfillment_policies()
        all_good &= self.delete_all_operation_policies()
        all_good &= self.delete_all_operation_groups()
        return all_good

    def create_operation_group(self, payload):
        self.logger.info(f'Creating operation group: {payload["groupName"]}')
        self.request_handler(self.api_client.create_operation_group, payload)
        if self.status_code == codes.CREATED:
            self.operation_group_codes.append(self.response_body['reasons'][0]['groupCode'])
        return self.status_code == codes.CREATED

    def create_operation_group_v4(self, payload):
        self.logger.info(f'Creating operation group v4: {payload["groupName"]}')
        self.request_handler(self.api_client.create_operation_group_v4, payload)
        if self.status_code == codes.CREATED:
            self.set_operation_group_code(self.response_body['reasons'][0]['groupCode'])
        return self.status_code == codes.CREATED

    def get_operation_group(self, group_code):
        self.request_handler(self.api_client.get_operation_group, group_code)
        return self.status_code == codes.OK

    def get_operation_groups(self):
        self.request_handler(self.api_client.get_operation_groups)
        return self.status_code == codes.OK

    def get_operation_groups_v4(self):
        self.request_handler(self.api_client.get_operation_groups_v4)
        return self.status_code == codes.OK

    def get_operation_group_by_groupcode_v4(self, group_code_to_fetch=None):
        # If group_code_to_fetch is not passed in, default to the latest one in self.operation_group_codes
        group_code_to_fetch = group_code_to_fetch or self.operation_group_code

        self.logger.info(f'Fetching operation group v4 by group_code: {group_code_to_fetch}')
        self.request_handler(self.api_client.get_operation_group_by_groupcode_v4, group_code_to_fetch)
        return self.status_code == codes.OK and self.response_body['result']['groupCode'] == group_code_to_fetch

    def update_operation_group_v4(self, group_code, payload):
        self.request_handler(self.api_client.update_operation_group_v4, group_code, payload)
        return self.status_code == codes.OK

    def delete_operation_group(self, group_code):
        self.request_handler(self.api_client.delete_operation_group, group_code)
        if self.status_code != codes.OK:
            return False
        if group_code in self.operation_group_codes:
            self.operation_group_codes.remove(group_code)
            self._index -= 1
        return True

    def create_operation_policy(self, payload):
        self.logger.info(f'Creating operation policy: {payload["policyName"]}')
        self.request_handler(self.api_client.create_operation_policy, payload)
        return self.status_code == codes.CREATED

    def get_operation_policies(self):
        self.request_handler(self.api_client.get_operation_policies)
        return self.status_code == codes.OK

    def get_operation_policy_status(self):
        self.request_handler(self.api_client.get_operation_policy_status, self.policy_code)
        return self.status_code == codes.OK

    def update_operation_policy(self, policy_code, payload):
        self.request_handler(self.api_client.update_operation_policy, policy_code, payload)
        return self.status_code == codes.OK

    def delete_operation_policy(self, policy_code):
        self.request_handler(self.api_client.delete_operation_policy, policy_code)
        return self.status_code == codes.OK

    def delete_all_operation_policies(self):
        self.logger.info("Deleting all operation policies")
        result = False
        if self.get_operation_policies() and self.response_body.get('result'):
            result = True
            data = self.response_body['result']['documentList']
            for policy in data:
                if policy['policyCode'] != 'DefPolicy' and policy['status'] == 'Active':
                    for context in policy['associatedEntities']:
                        if "tagValueName" in context:
                            del(context["tagValueName"])
                        if "tagName" in context:
                            del(context["tagName"])
                    payload = payload_helper.operation_policy_builder(policy['policyName'],
                                                                      [x['groupCode'] for x in policy['associatedOperationGroups']],
                                                                      policy['associatedEntities'],
                                                                      'Retired')
                    result &= (self.update_operation_policy(policy['policyCode'], payload)
                               and self.delete_operation_policy(policy['policyCode']))
        return result

    def delete_all_operation_groups(self):
        self.logger.info("Deleting all operation groups")
        result = False
        if self.get_operation_groups():
            result = True
            if self.response_body.get('result'):
                data = self.response_body['result']['operationGroups']
                for group in data:
                    if group['groupCode'] != 'DefGroup':
                        result &= self.delete_operation_group(group['groupCode'])
        return result
