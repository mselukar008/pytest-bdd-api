#!/bin/bash

# Make sure the "overwrite_strategy" variables are set properly before running.
# Possible values: "OVERWRITE", "NEW"

read_variable()
{
    var=$1
    value=$(python -c "import json;
with open('setup_properties.json') as json_file:
    data = json.load(json_file)
    print (data['$var'])")
    echo $value
}

update_json()
{
    args=("$@")
    # get length of an array
    arraylength=${#args[@]}
    data=""
    for ((i=0; i<${arraylength};i++));
    do
        data="$data data['${args[$i]}'] = '${args[$i+1]}';"
        i=$i+1
    done
    $(python -c "import json;
with open('setup_properties.json') as json_file:
    data = json.load(json_file);$data
with open('setup_properties.json', mode='wb') as json_file:
    json.dump(data, json_file)")
}

host=$(read_variable host)
user=$(read_variable app_user)
admin_user=$(read_variable admin_user)
admin_apikey=$(read_variable apikey)
team_code=$(read_variable team_code)
load_aws=$(read_variable load_aws)
aws_offering_subset=$(read_variable aws_offering_subset)
aws_overwrite_strategy=$(read_variable aws_overwrite_strategy)
aws_skip_template_validation=$(read_variable aws_skip_template_validation)
load_azure=$(read_variable load_azure)
azure_offering_subset=$(read_variable azure_offering_subset)
azure_overwriteStrategy=$(read_variable azure_overwriteStrategy)
azure_ignorePriceErrors=$(read_variable azure_ignorePriceErrors)
load_ibmcloud=$(read_variable load_ibmcloud)
ibmcloud_offering_subset=$(read_variable ibmcloud_offering_subset)
load_gcp=$(read_variable load_gcp)
gcp_offering_subset=$(read_variable gcp_offering_subset)
gcp_overwrite_strategy=$(read_variable gcp_overwrite_strategy)
gcp_account_name=$(read_variable gcp_account_name)
aws_provider_account_name=$(read_variable aws_provider_account_name)
azr_provider_account_name=$(read_variable azr_provider_account_name)
sl_provider_account_name=$(read_variable ibmcloud_provider_account_name)
sl_provider_credential_name=$(read_variable ibmcloud_provider_credential_name)
load_test=$(read_variable load_test)
load_imi=$(read_variable load_imi)
cb_provisioning_template_branch=$(read_variable cb_provisioning_template_branch)
clean_up_workspace=$(read_variable clean_up_workspace)
multitenant=$(read_variable multitenant)

# clean up
rm -rf cb-provisioning-template

declare -a aws_offering_subset_list
declare -a azure_offering_subset_list
declare -a gcp_offering_subset_list
declare -a ibmcloud_offering_subset_list

# clone cb-provisioning-template
git clone -b $cb_provisioning_template_branch git@github.kyndryl.net:MCMP-Integrations/cb-provisioning-template.git
chmod 755 cb-provisioning-template/*
find . -name "*.sh" | xargs chmod 755

# run Provider's readTemplate.sh
cd cb-provisioning-template
if [ "$load_aws" == "true" ]; then
    cd AWS
    IFS=',' read -r -a aws_offering_subset_list <<< "$aws_offering_subset"
    for item in "${aws_offering_subset_list[@]}"; do
        ./readTemplates.sh $item $host $admin_user $admin_apikey $aws_provider_account_name $aws_overwrite_strategy $aws_skip_template_validation
    done
    cd ..
fi

if [ "$load_azure" == "true" ]; then
    cd AZURE
    IFS=',' read -r -a azure_offering_subset_list <<< "$azure_offering_subset"
    for item in "${azure_offering_subset_list[@]}"; do
        ./readTemplates.sh $item $host $admin_user $admin_apikey $azure_overwriteStrategy $azure_ignorePriceErrors
    done
    cd ..
fi

if [ "$load_gcp" == "true" ]; then
    cd GCP
    IFS=',' read -r -a gcp_offering_subset_list <<< "$gcp_offering_subset"
    for item in "${gcp_offering_subset_list[@]}"; do
        ./readTemplates.sh $item $host $admin_user $admin_apikey $gcp_account_name $gcp_overwrite_strategy v2
    done
    cd ..
fi

if [ "$load_ibmcloud" == "true" ]; then
    cd IBMCLOUD
    IFS=',' read -r -a ibmcloud_offering_subset_list <<< "$ibmcloud_offering_subset"
    for item in "${ibmcloud_offering_subset_list[@]}"; do
        ./readTemplates.sh $item $host $admin_user $admin_apikey $sl_provider_account_name $sl_provider_credential_name ibmcloud
    done
    cd ..
fi

if [ "$load_test" == "true" ]; then
    # Setup Test provider and load content
    git clone git@github.kyndryl.net:MCMP-Integrations/cb-consume-bootstrap.git
    chmod 755 cb-consume-bootstrap/*
    find . -name "*.sh" | xargs chmod 755

    cd cb-consume-bootstrap/dummy-integrations
    chmod 755 setup_properties.json
    $(update_json 'host' $host 'username' $admin_user 'apikey' $admin_apikey 'team_code' $team_code 'multitenant' $multitenant)
    ./setup.sh
    cd ../..
fi

if [ "$load_imi" == "true" ]; then
    # Setup imi provider and load content
    starting_directory=$(pwd)

    git clone git@github.kyndryl.net:MCMP-Integrations/cb-consume-bootstrap.git
    chmod 755 cb-consume-bootstrap/*
    find . -name "*.sh" | xargs chmod 755

    cd cb-consume-bootstrap/imi-integration
    chmod 755 setup_properties.json
    $(update_json 'host' $host 'username' $admin_user 'apikey' $admin_apikey 'team_code' $team_code 'multitenant' $multitenant)
    ./setup.sh
    cd ../../..

    cd imi_setup
    ./setup.sh $host $admin_user $admin_apikey
    cd $starting_directory
fi

# clean up
cd ..
if [ "$clean_up_workspace" == "true" ]; then
    rm -rf cb-provisioning-template
fi

