# ist-pre-seed
This Repo automates creating data in a given tenant to help save time and makes the setup consistent accross tenants as well. The data is separated by each area: teams, users, provider accounts, DRGs, etc. These files are organized by QA-teams/area-of-testing and are owned/maintained by the respective QA-team. All sensitive information is encrypted with the **secret** key and must be used to decrypt. The secret key can be supplied on the command line `--secret <secret>` or stored as an environment variable `export MCMP_API_AUTOMATION_SECRET=<secret>`. Use the [Encryption](#encryption) below to encrypt and decrypt any sensitive information.

### Pre-requisites
- Python 3.7 and up
    - for required packages read [requirements.txt](requirements.txt)
- On Windows:
    + Microsoft Visual C++ 14.0
- Google Chrome (Optional)

### Pre-seeding
Is the process of loading the tenant with users, teams/roles, contexts, and provider accounts required for our tests
- Each pre-seed data type has a specific file name and are not required for test execution (but you might run into test failures without some pre-seed data). It is recommended at a minimum to have at least users and teams:
    ```
    pre_seeds/large/
            external_contexts.json
            internal_contexts.json
            organizations.json
            provider_accounts.json
            system_users.json
            teams.json
            users.json
    pre_seeds/medium/
            organizations.json
            provider_accounts.json
            teams.json
            users.json
    pre_seeds/small/
            teams.json
            users.json
        ...
    ```
- The json schema inside each file is not the request payload for api to create the resource. It follows the python naming conventions and only has the required fields for the request payloads to help save space. Some pre-seed types have an extra field: `__id__` which is used specifically for testing where we lookup the value of `__id__` and return it to the test. A common use of it is for grabbing the users id and apikey to execute an api with a specific user. For users.json, it is required to have 1 `"__id__": "admin"` user in your file
- It is **important** to have a separate user doing the pre-seeding than the admin user in your tests. Having the same admin user pre-seed would cause the admin to lose its roles in the middle of pre-seeding and would not get 403 response's for the remaining of the pre-seeding
- An example of pre-seed data can be found here [pre_seeds/hills](pre_seeds/hills)

#### .conf file
This file holds all of the advanced info and password fields for each provider. The advanced info does not have to be encrypted but the password fields must. All of the encrypted fields in this file will start with an underscore
##### Using the .conf file in pre_seed
In the provider_accounts.json file, you may reference the conf file field by using `$config`: `"accessKey": "$config.<field_name>",`. If the field name in provider_accounts.json file matches the field name in the conf file you may omit the conf field name: `"accessKey": "$config",`

### How to run
``` bash
python3 run.py --host <host> --user <user> --apikey <apikey> --path <path/to/folder> --config <path/to/file.conf> --secret <secret>
```

### Encryption
Used to Encrypt or Decrypt data
- To Encrypt text:
    ``` bash
    python3 encryption.py --text myStringToEncrypt --secret <secret>
    ```
- To Encrypt a conf file:
    ``` bash
    python3 encryption.py --config <path/to/file.conf> --secret <secret>
    ```

- To Decrypt text:
    ``` bash
    python3 encryption.py --text gAAAAABdQzleWGRoUWsT0m7lMD-HI2JxkrttNNUZqK1ukf6u_sAKf0vcmlVxZ4JaYhzxPJlRpNlFmLNJMqPzPjNJxMdFmeQqMhxLP_KWzKi07cO2IJxM9lI= --secret <secret> -d
    ```
- To Decrypt conf file:
    ``` bash
    python3 encryption.py --config <path/to/file.conf> --secret <secret> -d
    ```

### Delete VM's
For quick manual cleanup of specific VM's that you want to delete on a public Provider, this tool will do just that
``` bash
python3 delete_vms.py --provider <provider> --config <path/to/file.conf> --secret <secret>
```
Deleting VM's is as simple as:
1. Getting the list of VM's: `vms` (or `ec2s` if aws)
2. Deleting a range of VM's: `delete_vms 0 4 6-9`; will delete the 1st, 5th, 7th, 8th, 9th & 10th VM's in the list
3. Press `y` & `[RETURN/ENTER]` to confirm deletion

If there are common cases that require us to use the shell over and over or if we need to automate specific scripts without a shell, you can use the `--script <scripted function>` arg. To be able to run just a script you need to define the scripted function first. The function needs to be defined in the `<provider>Shell` class with the name `def script_<scripted function>(self)` (Notice there are no parameters) e.g.:
``` bash
python3 delete_vms.py --provider <provider> --config <path/to/file.conf> --secret <secret> --script delete_perf_vms
```
This example requires a method named `script_delete_perf_vms` in the provider's shell class; and it holds the necessary script to delete a specific set of VM's.