from utils import all_helper


class HealthStatus:
    CRITICAL = 'Critical'
    HEALTHY = 'Healthy'
    WARNING = 'Warning'


class Index:
    ACTIONABLE_INSIGHTS_DETAILS = 'actionable_insights_details'
    ACTIONABLE_INSIGHTS_DETAILS_DEVICES = 'actionable_insights_details_devices'
    ACTIONABLE_INSIGHTS_SUMMARY = 'actionable_insights_summary'
    AVAILABILITY_HISTORY = 'availability_history'
    DELETED_INVENTORY = 'deleted_inventory'
    INCIDENTS = 'incidents'
    INVENTORY = 'inventory'
    CHANGE_INVENTORY = 'change_inventory'
    NETCOOL_LDS = 'netcool_lds_data'
    RESOURCE_EVENTS = 'resource_events'
    RESOURCE_KPI_HISTORY = 'resource_kpis_history'
    SUNRISE = 'sunrise_data'
    UNIFIED_CHANGE_PROCESSED = 'unified_changerequest_processed_v2'
    UNIFIED_PROBLEMS_PROCESSED = 'unified_problem_processed_v2'
    RESOURCE_OPEN_TICKETS_INDEX = 'incidents,unified_problem_processed_v2,unified_changerequest_processed_v2'

READ_ONLY_INDICES = [Index.DELETED_INVENTORY, Index.ACTIONABLE_INSIGHTS_SUMMARY]
ALL_INDICES = all_helper(Index)


class Provider:
    AWS = 'aws'
    AZURE = 'azure'
    IBM_CLOUD = 'ibmcloud'
    IBM_DC = 'IBM DC'
    DEMO_CLOUD = 'democloud'