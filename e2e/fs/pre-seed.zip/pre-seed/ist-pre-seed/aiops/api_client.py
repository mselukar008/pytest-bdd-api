import json

from core.api_client import CoreApiClient
from utils.api_client_base import (
    McmpApiClientCustom,
    Route
)


class AiOpsApiClient(CoreApiClient):
    def __init__(self, url, headers, tenant_id, logger, tenant, max_round_trip=60, json_indent=0):
        super().__init__(url, headers, logger, tenant, max_round_trip, json_indent)
        self.tenant_id = tenant_id

    def get_cloud_inventory(self):
        return self.get(Route(f'cssr/kibana/urlmap/{self.tenant_id}/cloudInventory'))

    def get_incident_management(self):
        return self.get(Route(f'cssr/kibana/urlmap/{self.tenant_id}/advancedIncident'))

    def get_assets(self):
        return self.get(Route('aiops/assets/i18n/en.json?v=1'))

    def get_sunrise(self):
        return self.get(Route(f'cssr/converged/sunrise/{self.tenant_id}'))

    def get_alert(self):
        return self.get(Route(f'cssr/converged/alert/{self.tenant_id}'))

    def get_health(self):
        return self.get(Route(f'cssr/converged/health/{self.tenant_id}'))

    def get_inventory(self):
        return self.get(Route(f'cssr/converged/inventory/{self.tenant_id}'))

    def get_pervasive_card(self):
        return self.get(Route(f'cssr/advanced/pervasive/card/{self.tenant_id}'))

    def get_monitor_and_visibility(self):
        return self.get(Route(f'cssr/monitoring-and-visibility/card/{self.tenant_id}'))

    def get_incident_card(self):
        return self.get(Route(f'cssr/advanced/incident/card/{self.tenant_id}'))

    def get_change_card(self):
        return self.get(Route(f'cssr/advanced/change/card/{self.tenant_id}'))

    def postHssw(self, payload):
        return self.post(Route('/hwsw-currency/v1/asset/search'), payload)

    def get_problem_card(self):
        return self.get(Route(f'cssr/problem/card/{self.tenant_id}'))

    def do_discovery(self, payload):
        return self.post(Route('api/v2/aiops/discovery/schedule'), payload)

    def get_discovery(self, name):
        return self.get(Route('api/v2/aiops/discovery/schedule/{name}', {'name': name}))

    def get_applications(self):
        return self.get(Route('api/v1/aiops/aggregation/contexts/applications'))

    def get_environments(self):
        return self.get(Route('api/v1/aiops/aggregation/contexts/environments'))

    def update_tags(self, payload):
        return self.put(Route('api/v1/aiops/aggregation/resource/tags'), payload)

    def assign_remove_tags(self, payload):
        return self.post(Route('api/v1/aiops/tags/tagging'), payload)

    def get_context_applications(self):
        return self.get(Route('api/v1/aiops/tags/context/application'))

    def get_context_environments(self):
        return self.get(Route('api/v1/aiops/tags/context/environment'))

    def get_onprem_feature_flag(self):
        return self.get(Route(f'onprem/feature-flag/{self.tenant_id}'))

    # Inventory carbonization API List
    def get_topinsights_most_eol_resrcs(self, payload):
        return self.post(Route('api/v1/aiops/inventory/applications/top-insights/most-eol-resrcs'), payload)

    def get_topinsights_most_resrcs(self, payload):
        return self.post(Route('api/v1/aiops/inventory/applications/top-insights/most-resrcs'), payload)

    def get_topinsights_most_active_resrcs(self, payload):
        return self.post(Route('api/v1/aiops/inventory/applications/top-insights/most-active-resrcs'), payload)

    def get_inventory_application_treemap(self, view_by, payload):
        return self.post(Route('api/v1/aiops/inventory/applications/treemap/{viewBy}', {
            'viewBy': view_by
            }), payload)

    def get_inv_last_updated_time(self):
        return self.get(Route('api/v1/aiops/inventory/header/last-updated-time'))

    def get_inv_resrc_summary(self):
        return self.get(Route('api/v1/aiops/inventory/header/summary'))

    def get_application_list_view(self, payload):
        return self.post(Route('api/v1/aiops/inventory/applications/list/view'), payload)

    def get_inventory_resources_treemap(self, view_by, payload):
        return self.post(Route('api/v1/aiops/inventory/resources/treemap/{viewBy}', {
            'viewBy': view_by
            }), payload)

    def get_topinsights_monitored_resrcs(self, payload):
        return self.post(Route('api/v1/aiops/inventory/resources/top-insights/monitored-resrcs'), payload)

    def get_topinsights_firmware_currency_designator(self, payload):
        return self.post(Route('api/v1/aiops/inventory/resources/top-insights/firmware-currency-designator'), payload)

    def get_topinsights_cloud_readiness(self, payload):
        return self.post(Route('api/v1/aiops/inventory/resources/top-insights/cloud-readiness'), payload)

    def get_topinsights_untagged_resrcs(self, payload):
        return self.post(Route('api/v1/aiops/inventory/resources/top-insights/untagged-resrcs'), payload)

    def get_resource_list_view(self, payload):
        return self.post(Route('api/v1/aiops/inventory/resources/list/view'), payload)

    def get_inventory_application_details_overview(self, payload):
        return self.post(Route('api/v1/aiops/inventory/applications/details/overview'), payload)

    def get_resource_list_export(self, payload):
        return self.post(Route('api/v1/aiops/inventory/resources/list/export'), payload)
    
    def get_inventory_resources_overview(self, correlationid):
        return self.get(Route(f'api/v1/aiops/inventory/resources/overview/{correlationid}'))

    def get_inventory_resources_configuration(self, correlationid):
        return self.get(Route(f'api/v1/aiops/inventory/resources/configuration/{correlationid}'))

    def get_inventory_resources_tags(self, correlationid):
        return self.get(Route(f'api/v1/aiops/inventory/resources/tags/{correlationid}'))

    def get_inventory_global_filters(self):
        return self.get(Route(f'api/v1/aiops/inventory/global/filters'))

    # Health carbonization API List
    def get_topinsights_least_healthy_applications(self, payload):
        return self.post(Route('api/v1/aiops/health/applications/top-insights/least-healthy'), payload)

    def get_topinsights_most_healthy_applications(self, payload):
        return self.post(Route('api/v1/aiops/health/applications/top-insights/most-healthy'), payload)

    def get_topinsights_most_high_priority_incidents(self, payload):
        return self.post(Route('api/v1/aiops/health/applications/top-insights/high-priority-incidents'), payload)

    def get_topinsights_most_incidents(self, payload):
        return self.post(Route('api/v1/aiops/health/applications/top-insights/most-incidents'), payload)

    def get_application_list(self, payload):
        return self.post(Route('api/v1/aiops/health/applications/list/view'), payload)

    def get_resource_list(self, payload):
        return self.post(Route('api/v1/aiops/health/resources/list/view'), payload)

    def get_resource_export_list(self, payload):
        return self.post(Route('api/v1/aiops/health/resources/list/export'), payload)
    
    def get_app_details_overview(self, payload):
        return self.post(Route('api/v1/aiops/health/app-details/overview'), payload)


    def get_health_last_updated_time(self):
        return self.get(Route('api/v1/aiops/health/header/last-updated-time'))

    def get_health_header_summary(self):
        return self.get(Route('api/v1/aiops/health/header/summary'))

    def get_health_application_status(self, payload):
        return self.post(Route('api/v1/aiops/health/applications/status'), payload)

    def get_health_application_breakdown(self, payload):
        return self.post(Route('api/v1/aiops/health/applications/breakdown/info'), payload)

    def get_health_resource_breakdown(self, payload):
        return self.post(Route('api/v1/aiops/health/resources/breakdown/info'), payload)

    def get_health_resource_status(self, payload):
        return self.post(Route('api/v1/aiops/health/resources/status'), payload)

    def get_topinsights_least_healthy_resources(self, payload):
        return self.post(Route('api/v1/aiops/health/resources/top-insights/least-healthy'), payload)

    def get_topinsights_most_incidents_resources(self, payload):
        return self.post(Route('api/v1/aiops/health/resources/top-insights/most-incidents'), payload)

    def get_topinsights_max_cpu_utilization_resources(self, payload):
        return self.post(Route('api/v1/aiops/health/resources/top-insights/max-cpu-utilization'), payload)

    def get_health_resource_most_incidents(self, payload):
        return self.post(Route('/api/v1/aiops/health/resources/top-insights/most-incidents'), payload)

    def get_health_resource_least_healthy(self, payload):
        return self.post(Route('/api/v1/aiops/health/resources/top-insights/least-healthy'), payload)

    def get_health_resource_max_cpu_utilization(self, payload):
        return self.post(Route('/api/v1/aiops/health/resources/top-insights/max-cpu-utilization'), payload)

    def get_health_resource_details_overview(self, correlation_id):
        return self.get(Route(f'/api/v1/aiops/health/res-details/overview/{correlation_id}'))

    def get_health_resource_details_ticket_details(self, correlation_id,ticket_id,id):
        return self.get(Route(f'/api/v1/aiops/health/res-details/ticket-details/{correlation_id}/{ticket_id}/{id}'))

    def get_health_resource_details_availability(self, correlation_id):
        return self.get(Route(f'/api/v1/aiops/health/res-details/availability/{correlation_id}'))

    def get_associated_resources_list(self, payload):
        return self.post(Route('/api/v1/aiops/health/app-details/associated-resources/list'), payload)

    def get_associated_resources_export_list(self, payload):
        return self.post(Route('/api/v1/aiops/health/app-details/associated-resources/list/export'), payload)

    def get_location_application(self, payload):
        return self.post(Route('/api/v1/aiops/inventory/applications/location'), payload)

    def get_location_resource(self, payload):
        return self.post(Route('/api/v1/aiops/inventory/resources/location'), payload)

    def get_deleted_resources(self, payload):
        return self.post(Route('/api/v1/aiops/health/resources/deleted/list/view'), payload)

    def get_deleted_resources_export_list(self, payload):
        return self.post(Route('/api/v1/aiops/health/resources/deleted/list/export'), payload)

    def get_health_global_filters(self):
        return self.get(Route(f'api/v1/aiops/health/global/filters'))

    def get_health_resource_details_ticket_list(self,source_type,correlation_id):
        return self.get(Route(f'/api/v1/aiops/health/res-details/tickets/list/{source_type}/{correlation_id}'))

    def get_health_resource_details_performance_kpi(self, kpi_name, no_of_days, correlation_id):
        return self.get(Route(f'/api/v1/aiops/health/res-details/performance/kpi/{kpi_name}/{no_of_days}/{correlation_id}'))

    def get_health_resource_details_compute_performance_kpi(self, kpi_name, no_of_days, correlation_id):
        return self.get(Route(f'/api/v1/aiops/health/res-details/performance/kpi/compute/{kpi_name}/{no_of_days}/{correlation_id}'))

    def get_health_resource_details_disk_performance_kpi(self, kpi_name, no_of_days, correlation_id):
        return self.get(Route(f'/api/v1/aiops/health/res-details/performance/kpi/disk/{kpi_name}/{no_of_days}/{correlation_id}'))

    def get_health_resource_details_tags_list(self, correlation_id):
        return self.get(Route(f'/api/v1/aiops/health/res-details/tags/list/{correlation_id}'))

    def get_command_center_url(self):
        return self.get(Route(f'/api/v1/aiops/health/header/command-center/url'))

    def get_health_resource_details_performance_network_kpi(self, kpi_name, no_of_days, correlation_id):
        return self.get(Route(f'/api/v1/aiops/health/res-details/performance/kpi/network/{kpi_name}/{no_of_days}/{correlation_id}'))

    def get_health_resource_details_memory_performance_kpi(self, kpi_name, no_of_days, correlation_id):
        return self.get(Route(f'/api/v1/aiops/health/res-details/performance/kpi/memory/{kpi_name}/{no_of_days}/{correlation_id}'))
 
    def get_health_resource_details_heap_size_performance_kpi(self, kpi_name, no_of_days, correlation_id):
        return self.get(Route(f'/api/v1/aiops/health/res-details/performance/kpi/heap-size/{kpi_name}/{no_of_days}/{correlation_id}'))

    def get_health_resource_details_garbage_collection_performance_kpi(self, kpi_name, no_of_days, correlation_id):
        return self.get(Route(f'/api/v1/aiops/health/res-details/performance/kpi/garbage-collection/{kpi_name}/{no_of_days}/{correlation_id}'))


class ElasticApiClient(McmpApiClientCustom):
    def __init__(self, url, logger, max_round_trip=60*5, json_indent=None):
        super().__init__(url, {'content-type': 'application/x-ndjson'}, logger, max_round_trip, json_indent)

    def post(self, route, payload, request_mask=None):
        return self.request_handler(self.session.post, route, "\n".join([json.dumps(p) for p in payload]) + "\n",
                                    request_mask)

    def m_search(self, payload, as_int=None, ignore_throttled=None):
        return self.post(Route('_msearch', query_parameters={'rest_total_hits_as_int': as_int,
                                                             'ignore_throttled': ignore_throttled}), payload)

    def get_role_mappings(self):
        return self.get(Route('_security/role_mapping'))

    def put_role_mappings(self, name, data):
        return self.put(Route(f'_security/role_mapping/{name}'), data)
