from aiops.elastic_helper import reingest
from core.pre_seed import CoreData
from utils.pre_seed_base import PreSeedBase


class AiOpsPreSeed(PreSeedBase):
    def create_data(self):
        return CoreData({})

    def run_script(self, entities) -> list:
        self.error_list = []
        self._ingest_static_data(entities)
        return self.error_list

    def _ingest_static_data(self, entities):
        if self.args.elastic_host:
            tenant_id = self._get_tenant_id(entities)
            entities.logger.info('Running re-ingestion script...')
            try:
                reingest(self.args.elastic_data_dump, self.args.elastic_host, tenant_id, entities.logger)
            except:
                text = 'Encountered an exception with elastic or view_builder'
                self._log_exception(entities.logger, text)

    @staticmethod
    def _get_tenant_id(entities) -> str:
        tenant_id = None
        if entities.Core.get_basic_info():
            tenant_id = entities.Core.response_body['tenant']
        return tenant_id
