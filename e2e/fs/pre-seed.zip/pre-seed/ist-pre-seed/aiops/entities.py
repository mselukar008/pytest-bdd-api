from requests import codes

from aiops.api_client import (
    AiOpsApiClient,
    ElasticApiClient
)
from core.entities import (
    Budget,
    Core
)
from utils.entities_base import EntitiesBase


class Entities(EntitiesBase):
    def __init__(self, aiops_client, elastic_client, data, views, logger=None):
        super().__init__(aiops_client, data, logger)
        self.elastic_client = elastic_client
        self.Budget = Budget(aiops_client, logger)
        self.Core = Core(aiops_client, logger)
        self.Elastic = Elastic(elastic_client, logger)
        self.views = views

    @staticmethod
    def create_instance(host: str, user: str, apikey: str, logger, authorization: str, tenant_id: str, elastic_url):
        headers = AiOpsApiClient.create_headers(user, apikey, authorization)
        return Entities(
            AiOpsApiClient(host, headers,
                        tenant_id,
                        logger,
                        {},
                        max_round_trip=300,
                        json_indent=4),
            ElasticApiClient(elastic_url,
                            logger,
                            max_round_trip=300,
                            json_indent=4),
            {},
            {},
            logger
        )


class Elastic:
    def __init__(self, client, logger=None):
        self.client = client
        self.logger = logger or self.client.logger
        self.status_code = None
        self.response_body = None

    def request_handler(self, request, *args, **kwargs):
        self.status_code, self.response_body = request(*args, **kwargs)

    def poll_handler(self, wait_time, exit_if, request, *args, **kwargs):
        self.status_code, self.response_body, timed_out = self.client.poll_handler(wait_time, exit_if, request, *args, **kwargs)
        if timed_out:
            self.logger.info(f'Timed out after waiting for {wait_time} seconds')

    def m_search(self, payload, as_int=None, ignore_throttled=None, log_message=''):
        if log_message:
            self.logger.info(log_message)
        self.request_handler(self.client.m_search, payload, as_int, ignore_throttled)
        return self.status_code == codes.OK and self.response_body['responses'][0]['status'] == codes.OK

    def wait_on_resource(self, payload, wait_time: int):
        self.logger.info('Waiting on resource...')
        self.poll_handler(
            wait_time,
            lambda s, r: s == codes.OK and r.get("responses", [{}])[0].get("hits", {}).get("hits", [{}])[0].get("_source"),
            self.client.m_search,
            payload
        )
        return self.status_code == codes.OK
