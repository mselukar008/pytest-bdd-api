from datetime import (
    datetime,
    timedelta,
    timezone
)
import json
from io import BytesIO
from itertools import cycle
import os
import re
import shutil
import sys
import time
import traceback
from random import randint
from uuid import uuid1
from zipfile import (
    ZIP_DEFLATED,
    ZipFile,
    ZipInfo
)

from elasticsearch import Elasticsearch
from elasticsearch.exceptions import (
    NotFoundError,
    TransportError
)
from elasticsearch.helpers import (
    bulk,
    parallel_bulk,
    scan
)

sys.path.insert(0, os.getcwd())
from aiops.payload_helper import (
    ALL_INDICES,
    Index
)
from utils import (
    create_logger,
    datetime_to_str
)


_json_list = []
_utc_now = datetime.now(timezone.utc)
STEP = 2
_now210days = [datetime_to_str(_utc_now - timedelta(days=d), "%Y-%m-%dT00:00:00.000Z") for d in range(1, 208, STEP)]
_now1days = _now210days[0]
_it_now210days = cycle(_now210days)
_it_now90days = cycle(_now210days[:88//STEP])
_it_now30days = cycle(_now210days[:28//STEP])


def get_records_generator(path: str, tenant_id: str, new_dates: bool):
    def append_json_doc(path__):
        with open(path__) as fp:
            for line in fp:
                str_dict = re.sub("\d{4}[-/]\d{2}[-/]\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z", next(_it_now210days), line.strip()) if new_dates else line.strip()
                json_doc_ = json.loads(str_dict)
                json_doc_.pop('_id', None)
                _update_record(json_doc_, tenant_id)
                yield json_doc_

    if os.path.isdir(path):
        for filename in os.listdir(path):
            path_ = os.path.join(path, filename)
            return append_json_doc(path_)
    else:  # Is file.
        return append_json_doc(unzip(path))


def change_timestamp(date_str, delta):
    date = datetime.strptime(date_str, '%Y-%m-%dT%H:%M:00.000Z')
    return datetime_to_str(date - timedelta(hours=delta), "%Y-%m-%dT%H:%M:00.000Z")


def diff_between_timestamps(date1, date2):
    diff = datetime.strptime(date1, '%Y-%m-%dT%H:%M:%S.000Z') - datetime.strptime(date2, '%Y-%m-%dT%H:%M:%S.000Z')
    return diff.days


def update_availability_history_timestamp(record):
    record["_source"]['@timestamp'] = next(_it_now30days)
    record["_source"]['timestamp'] = record["_source"]['@timestamp']
    return record


def update_incidents_timestamp(record):
    date = next(_it_now210days)
    record["_source"]['@timestamp'] = change_timestamp(date, 4)
    record["_source"]['open_dttm'] = record["_source"]['@timestamp']
    record["_source"]['actual_start_dttm'] = change_timestamp(date, 5)
    record["_source"]['modified_dttm'] = change_timestamp(date, 2)
    month = date[5:7]
    month = month[1] if month[0] == '0' else month
    record['_source']['created_month'] = month
    if record["_source"]['status'] in ['CLOSED', 'RESOLVED']:
        record["_source"]['actual_finish_dttm'] = change_timestamp(date, -1)
        record["_source"]['closed_dttm'] = change_timestamp(date, -2)
        record["_source"]['resolved_dttm'] = change_timestamp(date, -2)
        record['_source']['resolved_month'] = month
    record['_id'] = f'{date}{uuid1()}'
    return record


def update_kpi_history_timestamp(record):
    record["_source"]['@timestamp'] = next(_it_now30days)
    record["_source"]['timestamp'] = record["_source"]['@timestamp']
    return record


def update_sunrise_timestamp(record):
    snapshot_date_1 = _now1days
    snapshot_date_2 = change_timestamp(snapshot_date_1, -_utc_now.hour)
    record['_source']['@timestamp'] = snapshot_date_1
    record['_source']['open_dttm'] = snapshot_date_1
    record['_source']['actual_start_dttm'] = snapshot_date_1
    if record['_source']['status'] in ['CLOSED', 'RESOLVED']:
        record['_source']['actual_finish_dttm'] = snapshot_date_2
        record['_source']['resolved_dttm'] = snapshot_date_2
        record['_source']['modified_dttm'] = snapshot_date_2
        record['_source']['closed_dttm'] = snapshot_date_2
        if diff_between_timestamps(snapshot_date_2, snapshot_date_1) == 1:
            record['_source']['resolved_24hrs'] = 1
    record['_source']['snapshot_date'] = record['_source']['@timestamp'].split('T')[0] + 'T00:00:00.000Z'
    return record


def update_problem_processed_timestamp(record):
    date = next(_it_now210days)
    record['_source']['@timestamp'] = change_timestamp(date, 2)
    record['_source']['OPEN_DTTM'] = change_timestamp(date, 5)
    record['_source']['CREATIONDATE_DF'] = record['_source']['OPEN_DTTM']
    year_month = date[:7].replace('-', '_')
    record['_source']['YEAR_MONTH_CREATED'] = year_month
    if record['_source']['STATUS'] in ['CLOSED', 'RESOLVED', 'CANCELLED']:
        record['_source']['CLOSED_DTTM'] = change_timestamp(date, -2)
        record['_source']['RESOLVED_DTTM'] = change_timestamp(date, -2)
        record['_source']['YEAR_MONTH_RESOLVED'] = year_month
    record['_source']['LAST_REFRESH_DTTM'] = change_timestamp(date, 1)
    record['_source']['MODIFY_DTTM'] = change_timestamp(date, 1)
    record['_id'] = f'{date}{uuid1()}'
    return record


def update_change_request_timestamp(record):
    date = next(_it_now210days)
    record['_source']['@timestamp'] = change_timestamp(date, 2)
    record['_source']['CREATED'] = change_timestamp(date, 1)
    record['_source']['SUBMITDATE'] = change_timestamp(date, 1)
    record['_source']['ACTUALSTARTDATE'] = change_timestamp(date, 1)
    record['_source']['REQUEST_DTTM'] = change_timestamp(date, -1)
    month = date[5:7]
    month = month[1] if month[0] == '0' else month
    record['_source']['CREATED_MONTH'] = month
    if randint(0, 15) > 10:
        record['_source']['PLAN_ST_DTTM'] = change_timestamp(date, -2)
    if record['_source']['STATUS'] in ['Closed', 'Cancelled']:
        record['_source']['CLOSED_DTTM'] = change_timestamp(date, -1)
        record['_source']['ACTUALENDDATE'] = change_timestamp(date, -4)
    if record['_source']['STATUS_CD'] in ['Closed', 'In Progress', 'Review', 'Ready to Deploy']:
        record['_source']['SCHED_FINISH_DTTM'] = record['_source']['CLOSED_DTTM']
    record['_source']['LAST_REFRESH_DTTM'] = record['_source']['CLOSED_DTTM']
    record['_source']['MODIFIEDDATE'] = record['_source']['CLOSED_DTTM']
    record['_source']['TARGETDATE'] = change_timestamp(date, -1)
    record['_source']['SCHEDULED_DTTM'] = change_timestamp(date, -2)
    record['_source']['SCHEDULEDENDDATE'] = change_timestamp(date, 1)
    record['_source']['SCHEDULEDSTARTDATE'] = change_timestamp(date, 1)
    record['_id'] = f'{date}{uuid1()}'
    return record


def update_inventory(record):
    record['_source']['@timestamp'] = next(_it_now90days)


def get_records(path: str, tenant_id: str, new_dates: bool):
    def append_json_doc(path__):
        with open(path__) as fp:
            for line in fp:
                record = json.loads(line)
                record.pop('_type', None)
                if record['_index'] not in [Index.ACTIONABLE_INSIGHTS_SUMMARY, Index.RESOURCE_KPI_HISTORY]:
                    if new_dates:
                        if record['_index'] == Index.INVENTORY:
                            update_inventory(record)
                        if record['_index'] == Index.SUNRISE:
                            update_sunrise_timestamp(record)
                        if record['_index'] == Index.AVAILABILITY_HISTORY:
                            update_availability_history_timestamp(record)
                        if record['_index'] == Index.INCIDENTS:
                            update_incidents_timestamp(record)
                        if record['_index'] == Index.RESOURCE_KPI_HISTORY:
                            update_kpi_history_timestamp(record)
                        if record['_index'] == Index.UNIFIED_PROBLEMS_PROCESSED:
                            update_problem_processed_timestamp(record)
                        if record['_index'] == Index.UNIFIED_CHANGE_PROCESSED:
                            update_change_request_timestamp(record)
                    _update_record(record, tenant_id)
                    _json_list.append(record)

    if not _json_list:
        if os.path.isdir(path):
            for filename in os.listdir(path):
                path_ = os.path.join(path, filename)
                append_json_doc(path_)
        else:  # Is file.
            append_json_doc(unzip(path))
    else:
        for i, json_doc in enumerate(_json_list):
            _update_record(json_doc, tenant_id)
            _json_list[i] = json_doc
    return _json_list


def _update_record(json_doc: dict, tenant_id: str):
    if json_doc['_index'] in ALL_INDICES:
        if 'tenant_id' in json_doc['_source']:
            json_doc['_source']['tenant_id'] = tenant_id
        elif 'TENANT_ID' in json_doc['_source']:
            json_doc['_source']['TENANT_ID'] = tenant_id


def _create_client(host: str):
    return Elasticsearch(host, use_ssl=True, verify_certs=False, timeout=60*20)


def unzip(file_path: str):
    new_path = os.path.join('aiops', 'temp')
    shutil.unpack_archive(file_path, new_path)
    mac_dir = os.path.join(new_path, '__MACOSX')
    if os.path.exists(mac_dir):
        shutil.rmtree(mac_dir)
    ds_store = os.path.join(new_path, '.DS_Store')
    if os.path.exists(ds_store):
        os.remove(ds_store)
    # todo: Will revisit this if we decide to have more than 1 file in a zip
    return os.path.join(new_path, os.listdir(new_path)[0])


def get(host: str, tenant_ids: list, logger):
    all_good = True
    es = _create_client(host)
    all_indices = [x for x in es.indices.get_alias("*") if not x.startswith('.')]
    count = 0
    os.makedirs('logs', exist_ok=True)
    logger.info(f'Getting data from: {tenant_ids[0]}...')
    for index in all_indices:
        str_buffer = []
        buffer = BytesIO()
        logger.info(f'Getting data on index: {index}...')
        tenant_key = 'TENANT_ID' if 'unified_' in index else 'tenant_id'
        query = {'query': {'term': {tenant_key: tenant_ids[0]}}, 'size': 1000}
        response = es.search(index=index, body=query, scroll='20s')
        while response['hits']['hits']:
            count += len(response['hits']['hits'])
            str_buffer.append("\n".join([json.dumps(hit) for hit in response['hits']['hits']]))
            response = es.scroll(scroll_id=response['_scroll_id'], scroll = '20s')

        with ZipFile(buffer, 'w', ZIP_DEFLATED, compresslevel=9) as zfile:
            file1 = ZipInfo(f'{index}.ndjson')
            zfile.writestr(file1 , "\n".join(str_buffer))
        with open(os.path.join("logs", f"{index}.zip"), "wb") as f:
            f.write(buffer.getbuffer())
        buffer.close()
    logger.info(f'Total record count: {count}')
    return 0 if all_good else 1


def delete(host: str, tenant_ids: list, logger):
    all_good = True
    es = _create_client(host)
    for tenant_id in tenant_ids:
        logger.info(f'Deleting documents on tenant: {tenant_id}...')
        for index in [x for x in ALL_INDICES]:
            tenant_key = 'TENANT_ID' if 'unified_' in index else 'tenant_id'
            query = {'query': {'term': {tenant_key: tenant_id}}}
            logger.info(f'Deleting {index}')
            logger.debug(f'REQUEST: {query}')
            try:
                response = es.delete_by_query(index=index, body=query)
                logger.debug(f'RESPONSE: {response}')
                all_good &= response.get('failures') == []
            except TransportError:
                logger.debug(traceback.format_exc())
        for index in ALL_INDICES:
            tenant_key = 'TENANT_ID' if 'unified_' in index else 'tenant_id'
            try:
                count = es.count(index=index, body={'query': {'term': {tenant_key: tenant_id}}})
                logger.info(f'{index}: {count}')
            except NotFoundError:
                logger.info(f'{index}: NOT FOUND')
    if all_good:
        logger.info('Deleting was successful')
    else:
        logger.info('Deleting failed')
    return 0 if all_good else 1


def ingest(host: str, tenant_ids: list, path: str, new_dates: bool, logger):
    def chunker(sequence, size):
        return (sequence[pos:pos + size] for pos in range(0, len(sequence), size))

    all_good = True
    es = _create_client(host)
    logger.info(f"Cluster status: {es.info()}")
    for tenant_id in tenant_ids:
        start_time = time.time()
        if new_dates:
            logger.info(f"The records will be updated with new timestamps...")
        json_list = get_records(path, tenant_id, new_dates)
        logger.info(f"Ingesting for tenant {tenant_id}...")
        success, failed = bulk(es, json_list)
        # Sometimes we might get a "413 Request Entity Too Large", if so comment out line above and un-comment lines below
        # success = 0
        # failed = []
        # for chunk in chunker(json_list, 25):
        #     s, f = bulk(es, chunk)
        #     success += s
        #     failed += f
        logger.info(f"Success count: {success}")
        logger.info(f"Failed: {failed}")
        all_good &= success == len(json_list)
        logger.info(f'Duration: {time.time() - start_time} seconds')
        for index in ALL_INDICES:
            tenant_key = 'TENANT_ID' if 'unified_' in index else 'tenant_id'
            try:
                count = es.count(index=index, body={'query': {'term': {tenant_key: tenant_id}}})
                logger.info(f'{index}: {count}')
            except NotFoundError:
                pass
        if new_dates:
            logger.info("Rewriting the existing zip file with new data")
            file_name = os.path.basename(path).replace('.zip', '')
            with ZipFile(path, 'w', ZIP_DEFLATED) as zfile:
                zfile.writestr(file_name, "\n".join([json.dumps(d) for d in json_list]) + "\n")
    return 0 if all_good else 1


def ingest_documents(host: str, tenant_id: str, documents: list, logger):
    all_good = False
    es = _create_client(host)
    logger.info("Ingesting documents...")
    start_time = time.time()
    success, failed = bulk(es, documents)
    logger.info(f"Success count: {success}")
    logger.info(f"Failed: {failed}")
    all_good = success == len(documents)
    logger.info(f'Duration: {time.time() - start_time} seconds')
    for index in ALL_INDICES:
        tenant_key = 'TENANT_ID' if 'unified_' in index else 'tenant_id'
        try:
            count = es.count(index=index, body={'query': {'term': {tenant_key: tenant_id}}})
            logger.info(f'{index}: {count}')
        except NotFoundError:
            pass
    return all_good


def reingest(file_path: str, host: str, tenant_id: str, logger):
    documents = get_records(file_path, tenant_id, new_dates=True)
    assert delete(host, [tenant_id], logger) == 0
    assert ingest_documents(host, tenant_id, documents, logger)


def ingest_parallel(host: str, tenant_ids: list, path: str, new_dates: bool, logger):
    all_ok = True
    es = _create_client(host)
    for tenant_id in tenant_ids:
        start_time = time.time()
        logger.info(f"Ingesting for tenant {tenant_id}...")
        for ok, result in parallel_bulk(es, get_records_generator(path, tenant_id, new_dates)):
            all_ok &= ok
            if not ok:
                logger.info(result)
        logger.info(f"Success: {all_ok}")
        logger.info(f'Duration: {time.time() - start_time} seconds')
    return 0 if all_ok else 1


def update_file(path: str, tenant_ids: list, new_dates=True, logger=None):
    documents = get_records(path, tenant_ids[0], new_dates)
    file_name = os.path.basename(path).replace('.zip', '')
    with ZipFile(path, 'w', ZIP_DEFLATED) as zfile:
        zfile.writestr(file_name, "\n".join([json.dumps(d) for d in documents]) + "\n")


def _build_url(env: str, secret: str):
    from utils.encryption import decrypt
    tenant = get_tenant(lambda k, v: k == env)
    elastic = json.load(open('clusters.json'))[tenant['cluster']]['elastic']
    user = elastic['user']
    password = decrypt(elastic['password'], secret)
    return elastic['api_url'].replace('https://', f'https://{user}:{password}@')

if __name__ == '__main__':
    import argparse

    _logger = create_logger('elastic')
    parser = argparse.ArgumentParser()
    options = ["ingest", "delete", 'update_file', 'get']
    parser.add_argument('option', choices=options, help="Option to run")
    option = parser.parse_args(sys.argv[1:2]).option
    parser.add_argument('--env', help='The env to use')
    parser.add_argument('--secret', default=os.getenv('MCMP_API_AUTOMATION_SECRET'), help='The secret to decrypt elastic password')

    args, _ = parser.parse_known_args()
    host_ = ''
    if args.tenant and args.secret:
        host_ = _build_url(args.tenant, args.secret)

    if option not in [options[2]]:
        parser.add_argument('--host', required=(host_ == ''), default=host_,  help='URL path, with http basic auth user and password, for elastic calls')
    parser.add_argument('--tenant-ids', required=True, nargs='*', type=str, help='The tenant ids of each tenant')
    if option in [options[0], options[2]]:
        parser.add_argument('--path', default=os.path.join('aiops', 'test_data', 'ACME_QA_datadump_1k.ndjson.zip'), help='The path to bulk upload; can be a file or folder')
        if option == options[0]:
            parser.add_argument('--new-dates', action='store_true', help='Make all timestamps between yesterday and 310 days ago')

    args = parser.parse_args()
    option_args_ = {k: v for k, v in parser.parse_args().__dict__.items() if k not in ['option', 'env', 'secret']}
    option_args_['logger'] = _logger
    exit(globals()[option](**option_args_))
