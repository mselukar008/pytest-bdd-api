#!/usr/bin/env python3
from encryption import process_config

from core.payload_helper import ProviderCode
from provider_clients import ProviderSwitchException
from provider_clients.aws import AwsShell
from provider_clients.azure import AzureShell
from provider_clients.ibmcloud import IbmCloudShell


def aws_shell(config_section):
    return AwsShell(config_section['_accessKey'], config_section['_secretKey'])


def azure_shell(config_section):
    return AzureShell(config_section['tenantID'], config_section['subscriptionID'], config_section['_clientId'], config_section['_secret'], 'MCMP-QA_IST_ResGrp_VMs')


def ibmcloud_shell(config_section):
    return IbmCloudShell(config_section['_username'], config_section['_apiKey'])


if __name__ == '__main__':
    import argparse
    import os

    parser = argparse.ArgumentParser()
    parser.add_argument('--provider', required=True, help='The provider shell to start with', choices=[ProviderCode.AWS, ProviderCode.AZURE, ProviderCode.SOFTLAYER])
    parser.add_argument('--config', required=True, help='The .conf provider creds file to use')
    parser.add_argument('--script', help='The name of the scripted function to call (No shell)')
    parser.add_argument('--secret', default=os.getenv('MCMP_API_AUTOMATION_SECRET'), help='Symmetric key used to decrypt the pre seed file')
    args = parser.parse_args()

    config = process_config(args.config, args.secret, decrypt=True)
    provider_cmd = globals()[f'{args.provider}_shell'](config[args.provider])
    if args.script:
        provider_cmd.script(args.script)
    else:
        while True:
            try:
                provider_cmd.cmdloop()
                break
            except ProviderSwitchException as pse:
                provider_cmd = globals()[f'{pse.name}_shell'](config[pse.name])
