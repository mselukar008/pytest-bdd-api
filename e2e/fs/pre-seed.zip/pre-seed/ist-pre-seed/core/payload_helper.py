from copy import deepcopy
from datetime import (
    datetime,
    timedelta,
)
import enum
import json
from typing import List, Any

import utils
from utils.api_client_base import Authorization


class BudgetAction:
    CHECK = 'check'
    COMMIT = 'commit'
    PRE_COMMIT = 'precommit'
    REFRESH = 'refreshPrecommit'
    ACTUAL = 'actual'


class BudgetChargeFrequency:
    ANNUAL = 'ANNUAL'
    MONTHLY = 'MONTHLY'
    ONETIME = 'ONETIME'
    QUARTERLY = 'QUARTERLY'
    SEMI_ANNUAL = 'SEMI-ANNUAL'


class BudgetPeriod:
    ANNUAL = "Annual"
    BIENNIAL = "Biennial"
    CUSTOM = "Custom"
    QUARTERLY = "Quarterly"
    SEMI_ANNUAL = "Semi-Annual"
    MONTHLY = "Monthly"


class BudgetConsumptionExtraAction:
    REPLACE_ACTUAL = "replaceActual"


class BudgetStatus:
    AVAILABLE = 'BUDGET_AVAILABLE'
    NOT_AVAILABLE = 'BUDGET_NOT_AVAILABLE'
    NOT_APPLICABLE = 'NotApplicable'


class BudgetType:
    PERCENTAGE = "Percentage"
    ACTUAL = "Actual"


class Provider:
    AMAZON = 'Amazon'
    AWS = 'AWS'
    AZURE = 'Azure'
    GOOGLE = 'Google'
    ICD = 'ICD'
    IMI = 'IMI'
    SOFTLAYER = 'IBM Cloud'
    TEST = 'test'
    TEST_ADDON = 'Test Add-On'
    TEST_ADDON2 = 'Test Add-On 2'
    VRA = 'VRA'


class ProviderCode:
    AWS = 'aws'
    AZURE = 'azure'
    GOOGLE = 'gcp'
    IMI = 'imi'
    SOFTLAYER = 'ibmcloud'
    TEST = 'test'
    TEST_ADDON = 'testAddOn'
    TEST_ADDON2 = 'testAddOn2'
    VRA = 'vra'
    @staticmethod
    def to_provider(provider_code):
        return {
            ProviderCode.AWS: Provider.AWS,
            ProviderCode.AZURE: Provider.AZURE,
            ProviderCode.GOOGLE: Provider.GOOGLE,
            ProviderCode.SOFTLAYER: Provider.SOFTLAYER,
            ProviderCode.TEST: Provider.TEST,
            ProviderCode.TEST_ADDON: Provider.TEST_ADDON,
            ProviderCode.TEST_ADDON2: Provider.TEST_ADDON2,
            ProviderCode.VRA: Provider.VRA,
            ProviderCode.IMI:Provider.IMI,
            ProviderCode.SOFTLAYER: Provider.SOFTLAYER,
        }[provider_code]


def create_config_value_builder(key, value):
    return {"configurationkey": key, "configurationvalue": value}


def organization_builder(ids, names=None):
    names = names or [None for _ in ids]
    assert len(ids) == len(names)
    return [{"id": ids[i], "name": names[i] or ids[i], "description": "", "status": "Active"} for i in range(len(ids))]


def context_builder(**kwargs):
    return [{"tagType": key, "tagValueCode": value} for key, value in kwargs.items()]


def context_value_builder(value_name, value_id, value_status, scope):
    return {"tagvalue": value_name, "tagcode": value_id, "status" if scope == "external" else "active": value_status}


def context_key_list_builder(**kwargs):
    return [{key: value if isinstance(value, list) else [value] for key, value in kwargs.items()}]


def create_contexts(value_source, name, context_tag_type, values, sort_weight=100):
    return {
        "is_enabled": True,
        "value_source": value_source,
        "sort_weight": sort_weight,
        "name": name,
        "is_dependent": False,
        "values": values,
        "is_authorization_context": True,
        "contexttagtype": context_tag_type,
    }


def external_context_values_builder(type_values):
    context_values = {}
    for type_, values in type_values.items():
        context_values[type_] = [context_value_builder(value[1], value[0], "Active", "external") for value in values]
        context_values[type_].append(context_value_builder(f"{type_}_all", f"{type_}_all", "Active", "external"))
        context_values[type_].append(context_value_builder("NONE", "!none!", "Active", "external"))
    return context_values


def external_context_type_dependencies(type_dependents):
    dependents_list = [
        {"contexttagtype": type_, "dependents": [{"contexttagtype": dependent} for dependent in dependents]}
        for type_, dependents in type_dependents.items()
    ]
    depends_on_list = [
        {"contexttagtype": dependent, "depends_on": [{"contexttagtype": type_}]}
        for type_, dependents in type_dependents.items()
        for dependent in dependents
    ]
    return dependents_list + depends_on_list


def external_context_values(values, dependencies, dependencies_values):
    return {
        "context_values": values,
        "context_dependencies": dependencies,
        "context_dependencies_values": dependencies_values,
    }


def filtered_contexts(business_function, known_contexts=None, find_context="", level="BROWSE"):
    return {
        "permission": {"businessfunction": business_function, "level": level},
        "known_contexts": known_contexts or {},
        "find_context": find_context,
        "include_unassigned_contexts": False,
        "addAllValue": "false",
        "offset": 0,
        "active": False,
        "limit": 100,
    }


def config_key_value_builder(key, value):
    return {"configKey": key, "configValue": value}


def roles_builder(name_list, contexts_lists):
    roles = []
    for i in range(len(name_list)):
        roles.append({"name": name_list[i], "contexts": contexts_lists[i]})
    return roles


def create_team(team_name, team_id, team_organization, roles=None, external_ref_id=None, enabled=True):
    payload = {
        "name": team_name,
        "teamcode": team_id,
        "org": team_organization,
        "roles": roles if roles else [],
        "enabled": enabled,
    }
    if external_ref_id is not None:
        payload["external_ref_id"] = external_ref_id
    return payload


def update_team(team_name, team_id, team_organization, enable_flag=True, roles=None):
    return {
        "name": team_name,
        "teamcode": team_id,
        "org": team_organization,
        "roles": roles if roles else [],
        "enabled": enable_flag,
    }


def create_user(user_id, first_name=None, last_name=None, middle_name="", display_name=None, emails=None):
    return {
        "firstname": first_name if first_name else utils.add_custom_prefix_to(utils.random_string(5), ""),
        "lastname": last_name if last_name else utils.add_custom_prefix_to(utils.random_string(5), ""),
        "middlename": middle_name,
        "displayname": display_name if display_name else user_id,
        "userid": user_id,
        "userstatus": "Active",
        "emails": emails if isinstance(emails, list) else [emails] if emails else [user_id],
    }


def create_system_user(user_id, user_name=None, roles=None):
    return {
        "userid": user_id,
        "enable": True,
        "roles": roles or [],
        "username": user_name or user_id,
        "description": "",
    }


def pricing_context_builder(**kwargs):
    return [{"tagType": key, "tagValueCodes": value} for key, value in kwargs.items()]


def team_external_entry(primaryteams, primary_teams, role_name, team_id):
    return {"primaryteams": primaryteams, "primary_teams": primary_teams, "teamcode": team_id, "roles": [role_name]}


def user_external_build_contexts(role, team_id):
    primary_teams_1 = []
    primary_teams_2 = []
    extras = {}
    for context in role["contexts"]:
        for k, v in context.items():
            if k == "team":
                primary_teams_1.append(v[0])
                primary_teams_2.append({"teamcode": v[0], "org": context["org"][0]})
            else:
                extras[k] = v[0]
    user_context = team_external_entry(primary_teams_1, primary_teams_2, role["name"], team_id)
    user_context.update(extras)
    return user_context


def create_users_external(teams_data, users_data, admin_username):
    users = []
    for user_data in users_data:
        user = create_user(
            user_data["id"],
            user_data["first_name"],
            user_data["last_name"],
            user_data["middle_name"],
            emails=user_data["emails"],
        )
        user["uid"] = user["userid"]
        del user["userid"]
        user["contexts"] = []
        for team in teams_data:
            if user["uid"] in team["users"]:
                for role in team["roles"]:
                    user["contexts"].append(user_external_build_contexts(role, team["id"]))
        users.append(user)
        if user_data["__id__"] == "admin":  # Need to add pre-seed admin as well.
            admin_user = deepcopy(user)
            admin_user["uid"] = admin_username
            users.append(admin_user)
    return {"users": users}


def assign_user_to_team(team_name, team_users):
    return {"team_code_list": [team_name], "user_id_list": team_users}


def service_provider_builder(vault_id, provider_code, provider_name=""):
    return {
        "vaultAdaptorId": vault_id,
        "serviceProviderName": provider_name or provider_code,
        "serviceProviderCode": provider_code,
        "serviceProviderType": provider_code,
    }


def account_builder(account_name, provider_code, is_master, credentials, advanced_info, parent_account_id=""):
    payload = {
        "account": {
            "basicInfo": {
                "accountName": account_name,
                "serviceProviderType": provider_code,
                "serviceProviderCode": provider_code,
                "isActive": "Active",
                "accountType": "master" if is_master else "subaccount",
                "userType": "billing" if is_master else "asset",
                "description": None,
            },
            "advancedInfo": advanced_info,
            "credentials": credentials,
        }
    }
    if parent_account_id:
        payload["account"]["basicInfo"]["parentAccountId"] = parent_account_id
    return payload


def account_credential_builder(name, purpose, context, password_fields=None, cref_id=None):
    credential = {
        "credentialName": name,
        "description": "",
        "purpose": purpose,
        "status": "Active",
        "createdBy": {"time": utils.datetime_now_str()},
        "context": [context],
        "additionalinfo": [dict(unassignedcontexts={}, **context)],
    }
    if password_fields:
        credential['passwordFields'] = password_fields
    if cref_id:
        credential['crefId'] = cref_id
    return credential


def budgetary_unit_builder(period, id_=None, name=None, status="Active", **kwargs):
    id_ = id_ or utils.unique_name("budget")
    return {
        "status": status,
        "budgetperiod": BudgetPeriod.CUSTOM if isinstance(period, int) else period,
        "name": name or id_,
        "budgetcode": id_,
        "context": kwargs,
    }


def budget_builder(
    total,
    period,
    soft_threshold_total,
    hard_threshold_total,
    soft_type=BudgetType.ACTUAL,
    hard_type=BudgetType.ACTUAL,
    name=None,
    status="Active",
):
    name = name or utils.unique_name()
    periods = period if isinstance(period, list) else create_budget_period(period)
    return {
        "name": name,
        "status": status,
        "soft_threshold_enabled": "True" if soft_threshold_total else "False",
        "soft_threshold_type": soft_type,
        "softThresholdTotal": soft_threshold_total or 0,
        "hard_threshold_enabled": "True" if hard_threshold_total else "False",
        "hard_threshold_type": hard_type,
        "hardThresholdTotal": hard_threshold_total or 0,
        "budgetTotal": total,
        "currency": "",
        "startPeriod": periods[0],
        "endPeriod": periods[1],
    }


def budget_policy_builder(
    start_time,
    end_time,
    name=None,
    expire_policy=True,
    status="Draft",
    applies_on_date=1,
    applies_to_bu=[]
):
    name = name or utils.random_string_with_prefix(20, prefix='BPB')
    payload = {
        "name": name,
        "status": status,
        "start_date_time": start_time,
        "end_date_time": end_time,
        "expire_policy": expire_policy,
        "rules": [{
            "id": "budget_rule_id_apply_to_next_month",
            "rule_data": {
                "applies_on_date": applies_on_date
            }
        }],
        "description": "policy description",
        "applies_to_bu": applies_to_bu
    }
    if expire_policy == False:
        del payload['end_date_time']
    return payload

def create_actual_period(months):
    start = datetime.now()
    end = add_months(start, months)
    def year_month(date):
        return date.strftime("%Y") + date.strftime("%m")

    return year_month(start), year_month(end)

def monthly_spend_quota(period, charge_values):
    return {
        "monthly_budget": dict(
            zip(
                [
                    create_actual_period(i)[1]
                    for i in range(0, int(get_budget_month_count(period)))
                ],
                [{"spend_quota": values} for values in charge_values],
            )
        )
    }

def bulk_budget_builder(
    total,
    period,
    budgets_count,
    soft_threshold_total,
    hard_threshold_total,
    soft_type=BudgetType.ACTUAL,
    hard_type=BudgetType.ACTUAL,
):
    budgets = []
    current = 0
    current_start_date = datetime.now()
    budget_period_months = get_budget_month_count(period) - 1
    while current < budgets_count:
        current_end_date = add_months(current_start_date, budget_period_months)
        current_start_period = current_start_date.strftime("%Y%m")
        current_end_period = current_end_date.strftime("%Y%m")
        name = f'{utils.CUSTOM_PREFIX}_{current_start_period}_{current_end_period}'
        current_budget = budget_builder(total, period, soft_threshold_total, hard_threshold_total, soft_type, hard_type, name)
        current_budget["startPeriod"] = current_start_period
        current_budget["endPeriod"] = current_end_period
        budgets.append(current_budget)
        current_start_date = add_months(current_end_date, 1)
        current += 1
    return {"budgets": budgets}


def bulk_activate_inactivate_budget_builder(budget_id_list, status_list):
    budget_statuses = []
    for i in range(len(budget_id_list)):
        budget_statuses.append({"id": budget_id_list[i], "status": status_list[i]})
    return {"budgets": budget_statuses}


def bulk_delete_budgets_builder(budget_id_list):
    return {"ids": budget_id_list}


def bulk_delete_budgetary_units_builder(budgetary_unit_id_list):
    return {"ids": budgetary_unit_id_list}


def commit_budget_builder(action, charges, start, context, end="", currency="", budgetary_unit=""):
    payload = {
        "action": action,
        "partial": False,
        "budgetTxId": "",
        "startMonthYear": start,
        "endMonthYear": end,
        "currency": currency,
        "charges": [
            {"charge": charge[0], "chargeFrequency": charge[1], "startMonthYear": charge[2], "endMonthYear": charge[3]}
            for charge in charges
        ],
        "context": context,
        "requestorInfo": [{"source": "string", "sourceRefId": "string"}],
        "budgetaryunit": budgetary_unit,
    }

    return payload


def commit_budget_payload(action, charges, startMonthYear, budgetaryunit=None, currency="USD", budgetTxId=None, partial=False, extraAction=None, context=None, endMonthYear=None, userid=None):
    new_charges= []
    for charge in charges:
        data = {"charge": charge[0], "chargeFrequency": charge[1], "startMonthYear": charge[2]}
        if charge[3]:
            data.update({"endMonthYear": charge[3]})
        new_charges.append(data)

    payload = {
        "action": action,
        "charges": new_charges,
        "startMonthYear": startMonthYear,
        "currency": currency,
        "partial": partial,
        "requestorInfo": [{"source": "CSFVT", "sourceRefId": "Testing"}]
    }
    if budgetaryunit:
        payload.update({"budgetaryunit": budgetaryunit})
    if budgetTxId:
        payload.update({"budgetTxId": budgetTxId})
    if context:
        payload.update({"context": context})
    if extraAction:
        payload.update({"extraAction": ["replaceActual"]})
    if endMonthYear:
        payload.update({"endMonthYear": endMonthYear})
    if userid:
        payload.update({"userid":userid})
    return payload


def create_budget_period(period):
    start = datetime.now()
    end = add_months(start, get_budget_month_count(period) - 1)

    def year_month(date):
        return date.strftime("%Y") + date.strftime("%m")

    return year_month(start), year_month(end)


def get_budget_month_count(period):
    periods = {
        BudgetPeriod.MONTHLY: 1,
        BudgetPeriod.QUARTERLY: 3,
        BudgetPeriod.SEMI_ANNUAL: 6,
        BudgetPeriod.ANNUAL: 12,
        BudgetPeriod.BIENNIAL: 24,
    }
    return period if isinstance(period, int) else periods[period]


def add_months(date_time, months):
    dt = date_time.replace(day=1)
    days = 32 if months > 0 else -32
    for _ in range(months):
        dt += timedelta(days=days)
        dt = dt.replace(day=1)
    return dt


def currency_conversion_builder(currency_from, currency_to, rate, start_date=None, end_date=None):
    str_format = "%Y-%m-%dT05:00:00.000Z"
    start_date = start_date or (datetime.now() - timedelta(days=2))
    end_date = end_date or start_date + timedelta(days=1000)
    return {
        "currencyfrom": currency_from,
        "currencyto": currency_to,
        "exchangerate": str(rate),
        "startdate": utils.datetime_to_str(start_date, str_format),
        "enddate": utils.datetime_to_str(end_date, str_format),
        "source": "default",
    }


def set_authorization(auth_type):
    return {
        "agent_name": "sampleagent1",
        "_auth_agent_url": "http://cb-core-sample-auth-agent:5000/iam_agent/v2/authorization",
        "auth_service_client_key": "",
        "_uid": "test@us.ibm.com",
        "usedefaultauth": str(auth_type == Authorization.INTERNAL),
        "_health_check_endpoint": "http://cb-core-sample-auth-agent:5000/iam_agent/v2/authorization/teams",
        "auth_service_client_cert": "",
        "connection_protocol": "http",
        "_agent_api_key": "test",
        "agent_ca_cert": "",
        "is_mutual_auth": "false",
        "_gateway_host": "https://cb-core-auth-internal:4001",
        "auth_type": auth_type,
    }


def job_definition_builder():
    return {
        "status": "Active",
        "name": "test-cron",
        "job_definition_id": utils.random_string_with_prefix(20, separator="-"),
        "icb_application": utils.random_string(10),
        "description": "test desc",
        "actions": [
            {
                "url": "https://reqres.in/api/users?page=2",
                "request_method": "GET",
                "params": {
                    "header_params": [
                        {"key": "apikey123", "value": "hdgaghdhasgdhasd6566da4sd5as4d5as6"},
                        {"key": "username123", "value": "testuser@mail.com"},
                    ],
                    "query_params": [{"key": "userid", "value": "testuser"}, {"key": "username", "value": "test1"}],
                    "body": {"test": "This is expected to be sent back as part of response body."},
                },
                "code": "ONINIT",
            },
            {"url": "https://reqres.in/api/users?page=2", "request_method": "GET", "params": {}, "code": "ONFAILED"},
            {
                "url": "https://postman-echo.com/post",
                "request_method": "POST",
                "params": {"body": {"test": "testbody"}},
                "code": "ONCOMPLETE",
            },
            {"url": "http://api.plos.org/search?q=title:DNA", "request_method": "GET", "code": "ONSUSPEND"},
            {"url": "http://api.plos.org/search?q=title:DNA", "request_method": "GET", "code": "ONRESUME"},
        ],
        "scheduled_at": "* * * * *",
        "run_status": "INPROGRESS",
    }


def job_definition_withstatus_builder():
    return {
        "status": "Active",
        "name": "test-cron",
        "job_definition_id": utils.random_string_with_prefix(20, separator="-"),
        "icb_application": utils.random_string(10),
        "description": "test desc",
        "actions": [
            {
                "url": "https://reqres.in/api/users?page=2",
                "request_method": "GET",
                "params": {
                    "header_params": [
                        {"key": "apikey123", "value": "hdgaghdhasgdhasd6566da4sd5as4d5as6"},
                        {"key": "username123", "value": "testuser@mail.com"},
                    ],
                    "query_params": [{"key": "userid", "value": "testuser"}, {"key": "username", "value": "test1"}],
                    "body": {"test": "This is expected to be sent back as part of response body."},
                },
                "code": "ONINIT",
            },
            {
                "url": "https://reqres.in/api/users?page=2",
                "request_method": "GET",
                "params": {
                    "header_params": [
                        {"key": "apikey123", "value": "hdgaghdhasgdhasd6566da4sd5as4d5as6"},
                        {"key": "username123", "value": "testuser@mail.com"},
                    ],
                    "query_params": [{"key": "userid", "value": "testuser"}, {"key": "username", "value": "test1"}],
                    "body": {"test": "This is expected to be sent back as part of response body."},
                },
                "code": "ONSTATUSCHECK",
            },
            {"url": "https://reqres.in/api/users?page=2", "request_method": "GET", "params": {}, "code": "ONFAILED"},
            {
                "url": "https://postman-echo.com/post",
                "request_method": "POST",
                "params": {"body": {"test": "testbody"}},
                "code": "ONCOMPLETE",
            },
            {"url": "http://api.plos.org/search?q=title:DNA", "request_method": "GET", "code": "ONSUSPEND"},
            {"url": "http://api.plos.org/search?q=title:DNA", "request_method": "GET", "code": "ONRESUME"},
        ],
        "scheduled_at": "* * * * *",
        "status_check_interval": 10,
        "status_check_retries_threshold": 7,
        "delayed_status_check_interval": 20,
    }


class VariableType(enum.Enum):
    number = "number"
    boolean = "boolean"
    string = "string"
    array_number = "array_number"
    array_boolean = "array_boolean"
    array_string = "array_string"


class FrequencyCode(enum.Enum):
    month = "MONTH"
    hour = "HOUR"


class _LastLevel(enum.IntEnum):
    ratecard = 0
    plan = 1
    group = 2
    item = 3


class RateCardBuilder(dict):
    def __init__(self, client_id: str = "test-client", currency_code: str = "USD"):
        super().__init__()
        self.update(
            {
                "name": "e2e Test RateCard " + utils.random_string(10),
                "client_id": client_id,
                "description": "A test RateCard created for e2e tests",
                "currency_code": currency_code,
                "applicable_for": [],
                "variables": [],
                "rate_card_plans": [],
                "parameters": [],
            }
        )
        self._last_level = _LastLevel.ratecard

    def add_variable(
        self,
        variable_id: str,
        data_type: VariableType = VariableType.number,
        value: Any = 0,
        values: dict = None,
        name: str = None,
        description: str = None,
    ) -> "RateCardBuilder":
        if self._last_level == _LastLevel.ratecard:
            dest = self
        elif self._last_level == _LastLevel.plan:
            dest = self["rate_card_plans"][-1]
        else:
            dest = self["rate_card_plans"][-1]["rate_card_groups"][-1]
        data = {
            "id": variable_id,
            "data_type": data_type.value,
            "name": name or "e2e Test RateCard Variable " + utils.random_string(10),
            "description": description or "A test RateCard Variable created for e2e tests",
        }
        if data_type in (VariableType.array_boolean, VariableType.array_number, VariableType.array_string,):
            data["values"] = values
        else:
            data["value"] = value
        dest["variables"].append(data)
        return self

    def add_parameter(
        self, parameter_id: str, data_type: VariableType = VariableType.number, value: Any = 0, values: dict = None,
    ) -> "RateCardBuilder":
        data = {
            "id": parameter_id,
            "name": "e2e Test RateCard Parameter #" + parameter_id,
            "description": "A test RateCard Parameter created for e2e tests",
            "data_type": data_type.value,
            "uom": [],
            "range": [],
            "min_size": 0,
            "max_size": 0,
            "regex": "",
        }
        if data_type in (VariableType.array_boolean, VariableType.array_number, VariableType.array_string,):
            data["values"] = values
        else:
            data["value"] = value
        self["parameters"].append(data)
        return self

    def add_applicable_for(
        self,
        is_metadata: bool = False,
        valueID: str = "test-value-id",
        label: str = "test-value-label",
        values: List[dict] = None,
    ) -> "RateCardBuilder":
        sequence = len(self["applicable_for"])
        self["applicable_for"].append(
            {
                "is_metadata": is_metadata,
                "id": valueID,
                "label": label,
                "values": [{"id": "test-value-1", "label": "value 1"}, {"id": "test-value-1", "label": "value 1"},]
                if values is None
                else values,
                "sequence": sequence,
            }
        )
        return self

    def add_plan(self, name=None, plan_id=None) -> "RateCardBuilder":
        self._last_level = _LastLevel.plan
        sequence = len(self["rate_card_plans"])
        data = {
            "name": "e2e Test RateCard Plan #" + str(sequence) if name is None else name,
            "sequence": sequence,
            "description": "A test RateCard Plan created for e2e tests",
            "variables": [],
            "rate_card_groups": [],
        }
        if plan_id is not None:
            data["id"] = plan_id
        self["rate_card_plans"].append(data)
        return self

    def add_group(self, name: str = None, group_id: str = None) -> "RateCardBuilder":
        self._last_level = _LastLevel.group
        plan = self["rate_card_plans"][-1]
        sequence = len(plan["rate_card_groups"])
        data = {
            "name": "e2e Test RateCard Group #" + str(sequence) if name is None else name,
            "sequence": sequence,
            "description": "A test RateCard Group created for e2e tests",
            "variables": [],
            "rate_card_items": [],
        }
        if group_id is not None:
            data["id"] = group_id
        plan["rate_card_groups"].append(data)
        return self

    def add_item(
        self,
        name: str = None,
        descriptions: str = None,
        frequency_code: FrequencyCode = FrequencyCode.month,
        frequency_value: int = 1,
        item_id=None,
    ) -> "RateCardBuilder":
        self._last_level == _LastLevel.item
        plan = self["rate_card_plans"][-1]
        group = plan["rate_card_groups"][-1]
        sequence = len(group["rate_card_items"])
        data = {
            "name": "e2e Test RateCard Item #" + str(sequence) if name is None else name,
            "sequence": sequence,
            "description": descriptions or "A test RateCard Item created for e2e tests",
            "frequency": {"code": frequency_code.value, "value": frequency_value},
            "expression": {"when": {}, "then": [],},
        }
        if item_id is not None:
            data["id"] = item_id
        group["rate_card_items"].append(data)
        return self

    def when(self, data) -> "RateCardBuilder":
        plan = self["rate_card_plans"][-1]
        group = plan["rate_card_groups"][-1]
        item = group["rate_card_items"][-1]
        item["expression"]["when"] = data
        return self

    def then(
        self,
        name: str = None,
        raw_formula: str = None,
        json_formula: dict = None,
        uom_code: str = "",
        uom_value: int = 1,
    ) -> "RateCardBuilder":
        plan = self["rate_card_plans"][-1]
        group = plan["rate_card_groups"][-1]
        item = group["rate_card_items"][-1]
        data = {
            "uom": {"code": uom_code, "value": uom_value},
            "name": "Then expression #" + str(len(item["then"])) if name is None else name,
        }
        if raw_formula is not None:
            data["raw_formula"] = raw_formula
        elif json_formula is not None:
            data["json_formula"] = json_formula
        else:
            raise RuntimeError("either raw_formula or json_formula should be set")

        item["expression"]["then"].append(data)
        return self

    def copy(self, uniq: bool = False) -> "RateCardBuilder":
        data = deepcopy(self)
        if uniq:
            if "id" in data:
                data["id"] = utils.random_string(36)
            data["name"] = "e2e Test RateCard " + utils.random_string(10)
        return data


class ClientBuilder(dict):
    def __init__(self, client_id: str = ""):
        super().__init__()
        self.update(
            {
                "name": "e2e Test Client " + utils.random_string(10),
                "client_id": client_id if client_id else utils.random_string(64),
                "description": "A test Client created for e2e tests",
                "base_url": "test_base_url",
                "certs": "test_certs",
                "applicable_for": [],
            }
        )

    def add_applicable_for(
        self, value_id: str = "test_value_id", label: str = "test_value_label", values: List[dict] = None,
    ) -> "ClientBuilder":
        sequence = len(self["applicable_for"])
        self["applicable_for"].append(
            {
                "id": value_id,
                "label": label,
                "values": [{"id": "test_value_1", "label": "value 1"}, {"id": "test_value_2", "label": "value 2"},]
                if values is None
                else values,
                "sequence": sequence,
            }
        )
        return self

    def copy(self, uniq: bool = False) -> "ClientBuilder":
        data = deepcopy(self)
        if uniq:
            data["client_id"] = utils.random_string(64)
            data["name"] = "e2e Test Client " + utils.random_string(10)
        return data


class InputDataBuilder(dict):
    def __init__(self):
        super().__init__()
        self["input_data"] = []

    def add_variable(
        self, variable_id: str, data_type: VariableType = VariableType.number, value: Any = 0, values: dict = None,
    ) -> "InputDataBuilder":
        data = {
            "id": variable_id,
            "data_type": data_type.value,
        }
        if data_type in (VariableType.array_boolean, VariableType.array_number, VariableType.array_string,):
            data["values"] = values
        else:
            data["value"] = value
        self["input_data"].append(data)
        return self


def service_metadata_builder(service_type, supplier_id=None, service_metadata_name=None):
    service_metadata_name = service_metadata_name or "serviceOfferingMetadataName" + utils.random_string(5)
    supplier_id = supplier_id or utils.random_string(3)
    return {
        "serviceOfferingMetadataName": service_metadata_name,
        "serviceOfferingMetadataId": "serviceOfferingMetadataId" + utils.random_string(5),
        "supplierId": supplier_id,
        "description": "Random Description",
        "serviceType": service_type,
        "createdBy": "Test User, test_user@ibm.com",
    }


def attribute_group_builder(attribute_group_name, attribute_name, type):
    attr_id = "attributeId-" + utils.random_string(10)
    return {
        "attributeGroupId": "attributeGroupId-" + utils.random_string(10),
        "attributeGroupName": attribute_group_name,
        "attributes": [{"attributeId": attr_id, "attributeName": attribute_name, "type": type}],
        "required": [attr_id],
    }


def attribute_group_doc_builder():
    return {
        "documentID": "doc_id-" + utils.random_string(10),
        "attributeGroupId": None,
        "rowItems": [{"attributeId": None, "attributeValue": {"valueObject": "blah4"},}],
    }


USE_DEFAULT = object()


def pricing_policy_builder(
    startDate=None,
    endDate=None,
    currencyCode=USE_DEFAULT,
    rules=USE_DEFAULT,
    description=USE_DEFAULT,
    name=USE_DEFAULT,
    assetAccountCredentials=None,
    context=None,
    billingAccounts=None,
    serviceOfferings=None,
    providers=None,
    tags=None,
    name_prefix="policy",
):
    objectReturn = dict()

    if name == USE_DEFAULT:
        objectReturn["name"] = utils.random_string_with_prefix(30, prefix=name_prefix)
    elif name is not None:
        objectReturn["name"] = name

    if description == USE_DEFAULT:
        objectReturn["description"] = "descr-" + utils.random_string(20)
    elif description is not None:
        objectReturn["description"] = name

    if currencyCode == USE_DEFAULT:
        objectReturn["currencyCode"] = "USD"
    elif currencyCode is not None:
        objectReturn["currencyCode"] = currencyCode

    if startDate is not None:
        objectReturn["startDate"] = startDate

    if endDate is not None:
        objectReturn["endDate"] = endDate

    if context is not None:
        objectReturn["context"] = context

    if rules == USE_DEFAULT:
        objectReturn["rules"] = [
            {
                "adjustmentType": "oneTimeCharge",
                "amountType": "Percentage",
                "name": utils.random_string_with_prefix(30, prefix="rule"),
                "ruleType": "Discount",
                "value": 10,
            }
        ]
    elif rules is not None:
        objectReturn["rules"] = rules

    objectReturn["conditions"] = dict()

    if providers is not None:
        objectReturn["conditions"]["providers"] = providers
    if billingAccounts is not None:
        objectReturn["conditions"]["billingAccounts"] = billingAccounts
    if assetAccountCredentials is not None:
        objectReturn["conditions"]["assetAccountCredentials"] = assetAccountCredentials
    if serviceOfferings is not None:
        objectReturn["conditions"]["serviceOfferings"] = serviceOfferings
    if tags is not None:
        objectReturn["conditions"]["tags"] = tags

    return objectReturn


def pricing_policy_execute_builder(
    id=USE_DEFAULT,
    currencyCode=USE_DEFAULT,
    date=USE_DEFAULT,
    charges=USE_DEFAULT,
    assetAccountCredential=None,
    billingAccount=None,
    serviceOfferingID=None,
    provider=None,
    tags=None,
    context=None,
):

    payload = dict()

    if id == USE_DEFAULT:
        payload["id"] = utils.random_string_with_prefix(30, prefix="order")
    elif id is not None:
        payload["id"] = str(id)

    if currencyCode == USE_DEFAULT:
        payload["currencyCode"] = "USD"
    elif currencyCode is not None:
        payload["currencyCode"] = currencyCode

    if date == USE_DEFAULT:
        payload["date"] = "2021-07-21T00:00:00.000Z"
    elif date is not None:
        payload["date"] = date

    if charges == USE_DEFAULT:
        payload["charges"] = {"oneTimeCharge": 22}
    elif charges is not None:
        payload["charges"] = charges

    if assetAccountCredential is not None:
        payload["assetAccountCredential"] = assetAccountCredential

    if billingAccount is not None:
        payload["billingAccount"] = billingAccount

    if serviceOfferingID is not None:
        payload["serviceOfferingID"] = serviceOfferingID

    if provider is not None:
        payload["provider"] = provider

    if tags is not None:
        payload["tags"] = tags

    if context is not None:
        payload["context"] = context

    return payload


class QueryBuilder(dict):
    def __init__(self):
        self.queries = {}

    def template(self, template):
        self["template"] = template
        return self

    def variables(self, variables):
        self["variables"] = variables
        return self

    def schema_all_in_one(self):
        return self.schema("all-in-one")

    def schema_static(self):
        return self.schema("auditLog-budget-userInfo")

    def schema(self, name: str):
        self["schemaName"] = name
        return self

    def as_payload(self):
        query = "query FVT {%s}" % ("\n".join(self.queries.values()))
        return {
            "variables": self.get("variables", {}),
            "template": self.get("template", ""),
            "query": query,
            "schemaName": self.get("schemaName", ""),
        }

    def budgetaryunit(self):
        self.queries["budgetaryunit"] = """
    budgetaryunit{
        id
        budgetcode
        name
    }"""
        return self

    def auditlog(self):
        self.queries["auditlog"] = """
    auditlog (limit:10){
        messageContent {
            actorOrg
            actorUid
        }
    }"""
        return self


def endpoint_payload_helper(application_name=None, end_point_url=None, icb_application=None, schema_description=None, schema_name=None):
    return {
        "application_name": application_name if application_name else utils.random_string(10),
        "end_point_url": end_point_url if end_point_url else "http://common-service.core:8090/api/am/v1/graphql",
        "icb_application": icb_application if icb_application else "cs",
        "schema_description": schema_description if schema_description else "cs_20_api_layer",
        "schema_name": schema_name if schema_name else "cs20_api_layer"
    }


def report_service_payload_helper(
    temp_type, 
    excelTemp=None, 
    query="{user (limit:5){ firstname }}", 
    schemaname="auditLog-budget-userInfo", 
    transfortemp= "", 
    withTemplate="No",
    name_prefix="rep",
):
    return {
        "excelTemplate": excelTemp if not excelTemp else "data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,UEsDBBQACAAIAAAAAAAAAAAAAAAAAAAAAAATAAAAeGwvdGhlbWUvdGhlbWUxLnhtbOyZz2/bNhTH7/srCN5XyT9kx0GVIrHjdmvSFo3bocdniZZYU6RA0kl8G9rTLgMGdMMuA3bbYRhWYAVW7LI/JkCLrfsjBkmOTdp0my7u0A21DxGpz3v88j3yUXKuXjvNGDomUlHBQ1y74mNEeCRiypMQ3xv0P97CSGngMTDBSYinROFrOx9dhW2dkoyg04xxtQ0hTrXOtz1PRSnJQF0ROeGnGRsJmYFWV4RMvFjCCeVJxry677e8DCjHiENGQnx7NKIRQYPCJd45d77PSEa4VkVHxORRVI5oWpRsPK4Vf9RUdZlEx8BCfEJ5LE4G5FRjxEDpLpMh9ssP9nauenMjptfYGnb98jOzmxnE43ppJ5Ph3LDZDJqt3bn/euV/ldtv77f2W3N/JQBRRPhMi8kGe529XjBjDai6dPjutXuNmsUb/hsr/G5QfC2+seCbK3y/313E0ICqy8ARk3a927T4YMG3Vvi2v9trti2+hFJG+XiF9oNWo3s+2zkyEuyGE+8EzX67PsMXlGesrsqe63VrLYOHQvYF12VyQVOO9DQnI4hIiLvA6FBSdECTVGOUAxeKhNiv+32/4dfLb7O8KiMC2wQM66orUitdhR6kIklzHeJPc+DYQF48f3726NnZo1/PHj8+e/TzbOxVuxvAE9Pu1Q9f/fXd5+jPX75/9eRrN69M/uVPX7z87ffXudeWrG+evnz29MW3X/7x4xMHvithaOIDmhGFbpETdFdkwF0DkKF8O4tBCtSygFRk4AD3dWqBt6bAXNwesUN4X1Ieu8Drk4eW1qNUTjR1gDfTzAIPhWB7Qjqnc7MYy5zOhCfuweXE5O4CHLvG7i4leH+SpySjLpfdlFgy7zDgGhLCiUbFPTEmxGH2gFIrroc0kkKJkUYPKNoD6gzJgA612+gGzYDB1CVwkIIVm8P7aE8wl/seObZJ4Akwl0vCrDBeh4mGzKkYMmaSB6BTl8ijqYysgCstgSeECbQfE6VcNrfl1JJ7Exh1p/2QTTOblJqOXeQBCGGSPTHuppDlTs2Upyb7iRoLwQDdEdopQtg7pGgLRoGvTfd9SvTbbet7NEndC6S4M5GuLUGEvR+nbASkdO4tlfSM8jfW96XKHvw7ld1ddDdQ093gZar5rqTOPbVcw9dx/8HK3YMJv0N46kI/FO4Phft/X7jX7eXNl+tFhfYqQ+PJPVv74D6ijB3pKSMHqqztSjAa9yljZaM0mr8n5GmXydlwFpdIKK+RFPozqtOjFHIS4lo5QqJmrhOFcqFC7OO1vosbbJIdirjqrdXOX01hW4Fe9PvBvF9TrqveVnvxDjZ3X7YSZQoISqcXF2EMZotoOES0GxcTUfM3paLjULFVe50Kz8gKoxwBT0IcNCtFSEXASFzkqbI/z+7GM70umPa0647pdZoXC/IFMm2JMJabLcJYhinEZLl7w7nudNyprjtltLfeRa691drAuN1CJyFuNQIfowjyEI8YaIyiLI9DrIq6CSzhIY70LND/pLLkUukeqLTCylvV/DOqiUSMZiHeMtPA+EJbrd72319xHf/9i5y3nGQyGpFIr+lZNA+Urpw4714SLhpiook8SuMTNGQTeRfiEAftWhHAmCo9j2ZMpbG4F1FcKlezrWj9ZLbYosDyFGYnilnMK7y8nssx5lEqXZ6V5wrhMOlv4tR9s9GOXTTXHCDttVXs3R3yhqqGW1XgrHWdrTecEpc/EAxpW25pDbe0dWfHBh8IjOFaa+JWf+2ZdInTYHnVesZzZdla+d+EGD4kke6REUyYVqVUcqoldM9/VZ5XgtJ05+8AAAD//1BLBwg3MPwYTAUAAHUZAABQSwMEFAAIAAgAAAAAAAAAAAAAAAAAAAAAAA0AAAB4bC9zdHlsZXMueG1spJhdj9soF4Dv31+BfD9jkyaZTGS7etWqUqXuaqR2pd4SjBM0fFiAs6Sr/e8rsIOdOJ1SJ1Lsk2N4gMP5MMnfW87AkShNpSgS+JglgAgsKyr2RfLXt08PmwRog0SFmBSkSE5EJ+/L/+XanBj5eiDEAGA5E7pIDsY02zTV+EA40o+yIcJyVkvFkdGPUu1T3SiCKu16cZYusmydckRF0hG2qImByLqmmHyUuOVEmI5CrCGiItVDo2RDlKFEn6FyNhS32kh+A4liiJVCf1Oxv7VOPKM/PiBlAqBScxEfO10gSR5ln2uU5A0ydEcZNaczq9rzGaiKor1C/Axhc4zDJH4l1QckjihsUkPnkBqKTavIGWJnGXrk5lfmjqLd8kVFGDJUCn2gTVhiFRV0P3ft75ydUVE7d4vEkTkEa8VAfpEDNIuC+Edf6E4hdZpCeNTWc6Re2+bhwpc9K6zHJbwrDqdYSS1r84gl7y2SEovJjbVwLeP6+54Z7LelpSHRTC368/4IG3ok30NkN83U237eG8sjUS9oT16UHDwMV3SaHt6A+PmfHeSz6KxNpXhBggRfw+Y3kJwYVCGDUiyFIcJ8OzUhOoW5UXZiUJ3367BR7HcWGTBMiv3LpDjwaXWIYA1Fxuv+b4yiu9aMsJqK11+QqXhNFxnMLosNXMZNqE9ibmJP6SZdTErO74NgdrPooFmk8aIaOmNZMJuk91jIJGk9p88XE7Lx5jknC5i9USgsXKJpEoufG8JDkYh07tH+b66rMtcydnl+AtnTJJdVex6LuNiyq5lYuIqDXJsFZimEl3sGF3NtDGEKRza2cDWb5Kc1QkUm7QlnmSpypO41fkAtZrJWgbUYYO9mwtYB9m6ARXrCG7DlAJvrEQNsNcDWd8OG9wf1dDfsaYBt7oZtBtjz3bDnAQazu2kwG+Hg/Tg4ws0NgxFuFAfw/kCAo0iITYpv4UaxMDs9jnBDNMC50bCcJtv1HekoW/Qwjref90IqtGOkSDBcAv9iAhBcAv9SAKz7ep2voaDSDfDlC/gKBCxcAZ/5gc/awCpg1QJY9Q5YtQRWrYBVa2DVE7BqA6x6Bs7B3QW6i2sKXVvHUh7mvmvgVwi4BNwCfgQSHEP1jDwGcIRHVXRzeZaIPAo4RjiOXCGORdIqse37P4T+7gi05Qhvj8OBUL7Vthurv517vEnvyGrb0qpI/sn6z0OWZfDhLHWX8+ffpMxrKYwGWLbCFAnsFWWuf4AjYkUCnSrVP8ocSyYVMAfCSdcw9ZoyF4iTrvEHxOhOUffMKcu8RpyyU/dw4dSdwgl+FH/TZV5TxsIkXEOnKPMGGUOU+EQZA73sziZFIqQgrtX+QzeFNEi7oBqkEcY19bdfDLBX6AQXq/vG8Ddd5jupKqIujNypypyR2pmhuym6P7hf/d3IpsxTf91JYyR3A/aCe2OTArlBRuKZ2gu6zDFh7Ks5MfK9vhjf1kC0/BM3n6siyRLg9uEsUsZ6scN0P8o8tbXb9BGx49+NBraejhHwfrCLEYIWOC8rkj/dEZgNGLBrKTNUBGjoMJZ1mVd2mLpv6BRlblzmuxw2S0BFatQy80KP0viHRTLIX9yWwXVo9S0gimSQ/yAVbbkPhNEYLr7CP73lfwEAAP//UEsHCEJWkP3LBAAALhYAAFBLAwQUAAgACAAAAAAAAAAAAAAAAAAAAAAAGAAAAHhsL3dvcmtzaGVldHMvc2hlZXQzLnhtbJSTT4/bIBDF7/0UiHuNE0tVVQFp/lXqve2dAElQgLEYYiffvnK067UdS6vcxub3Zt7TAF/dgieNTeggCrooSkps1GBcPAn698+vr98pwayiUR6iFfRuka7kF95CuuDZ2kxuwUcU9Jxz/YMx1GcbFBZQ23gL/ggpqIwFpBPDOlllHqLg2bIsv7GgXKSSGxds7ByQZI+CrhdUctb/lPyh+edsi4OadBYOAJfu47cRtOxU/fGwfpftVFaSJ2hJErQbortivaAkC4o5UckbaRzWXt2jCpazRnKm37jNmDu6hPmZ2o4pr+ag3Ri6ok3OjJH9M4JZ5Sv2GEvQ9mmWfZrlSKcPyoT4E67ZA1wKDWES6jV8O8Q/4rzWZD/G1zq7xs7HqvpY1dzgTTUZrCFN9zFBcLKJuQ4P+6egnJ8xX31ung1uG+tfivwfAAD//1BLBwiMHcR+SgEAAG0DAABQSwMEFAAIAAgAAAAAAAAAAAAAAAAAAAAAABAAAABkb2NQcm9wcy9hcHAueG1snM/PSjQxEATw+/cUoe87mc+DyJLJIvjn6mH0HpKe3UDSHdLtkvXpRQTXs8ei4EeVO4xazBm7ZKYF/k8zGKTIKdNxgdf1aXcHRjRQCoUJF7igwMH/cy+dG3bNKGbUQrLASbXtrZV4whpk4oY0atm416AycT9a3rYc8YHje0VSezPPtxaHIiVMu/YDwre4P+tf0cTxa5+8rZeGAt6trKGsuaKfnb0Gd99ayTFoZvLPbB5HxJI/0NnfhbPXs/4zAAD//1BLBwjzQZnEwQAAADEBAABQSwMEFAAIAAgAAAAAAAAAAAAAAAAAAAAAABoAAAB4bC9fcmVscy93b3JrYm9vay54bWwucmVsc7zOz0rDQBDH8btPsczdbJqqiGTTiwi9SnyAJZn8obs7y86oydsLEWwLFXIovewyl9/3U+4m79QXJh4pGNhkOSgMDbVj6A181G/3z6BYbGito4AGZmTYVXflOzorIwUexshq8i6wgUEkvmjNzYDeckYRw+RdR8lb4YxSr6NtDrZHXeT5k06nG1Cdbap9ayDt2wJUbVOPYoBldsjZ5B2oeo64pkddNzb4Ss2nxyAXsvp3FapSn+YvY7ZHjAzoUS/v5tqkZXWd6OEo+qZ04AFRWC9fcW3WX2Ad7fF/2vaGtLOTq58AAAD//1BLBwhdKLuz5wAAAPECAABQSwMEFAAIAAgAAAAAAAAAAAAAAAAAAAAAABgAAAB4bC93b3Jrc2hlZXRzL3NoZWV0Mi54bWxMj0FLAzEQhe/+ijB3N1sPIpKkCCJ4V++xmXZDMzNLJtj130uKXfb2zRs+eM/tFyrmB6tmYQ+7YQSDfJCU+eTh8+Pt/gmMtsgpFmH08IsK+3DnLlLPOiE2s1Bh9TC1Nj9bq4cJKeogM/JC5SiVYtNB6snqXDGmq0TFPozjo6WYGYJLmZB7A1Px6OFlB8HZNQzu6nxlvOiGTa/wLXLux3vyMHZrfW/5pr3GFm/5P687wl8AAAD//1BLBwgAJxDhtgAAAAsBAABQSwMEFAAIAAgAAAAAAAAAAAAAAAAAAAAAAA8AAAB4bC93b3JrYm9vay54bWyMkU9v2zAMxe/7FALvjaUuCYLAcoFhG5bL0EPXnhWJjonojyHJjf3tBzt146KXnmiTeL9HPpUPvbPsFWOi4CWIFQeGXgdD/iTh39Pvux2wlJU3ygaPEgZM8FB9Ky8hno8hnFnvrE8SmpzbfVEk3aBTaRVa9L2zdYhO5bQK8VSkNqIyqUHMzhb3nG8Lp8jDlbCPX2GEuiaNP4PuHPp8hUS0KlPwqaE2zTSnv4JzKp679k4H16pMR7KUhwkKzOn94eRDVEeLEnqxmcm92HxCO9IxpFDnlQ7ubclP9wpeCHE9uSprsvh8TZ2ptv2r3OhigVmV8i9DGY2ELTAbLvihEbv2R0fWSBDr9T2HqiwWrOr9XR4jM1irzuanBt08lyC2ay4EsJpsxvgY6VXpQUKOHY6sm7wqx/pMeEk36vjLLuRNuPxBOjVZwo4LDm+9FzK5GTfb8TGvl6kpgQMbbt8LlxFXlcXCaIprrsxPsRw7c8Ks4tB5ysCm0cFIuAcW92QkxINZj9hp8lHbJYwLyfeFZLOQFLPv+2rV/wAAAP//UEsHCFXAG2ycAQAAGgMAAFBLAwQUAAgACAAAAAAAAAAAAAAAAAAAAAAAEwAAAFtDb250ZW50X1R5cGVzXS54bWy8lM2u2jAQhfd9isjbKjZQqaqqJCz6s2xZ0Adw7QmxsD2WZ6Dh7askwAK1iFyu7ibexOf7Mieaat0HXxwhk8NYi6VciAKiQevirha/tt/LT6Ig1tFqjxFqcQIS6+ZdtT0loKIPPlItOub0WSkyHQRNEhPEPvgWc9BMEvNOJW32egdqtVh8VAYjQ+SShwzRVD+PkLOzUGx05h86QC1U7xV3EGB6LmUfvCi+TBcHdi10St4ZzQ6jOkZ7Qy2xbZ0Bi+YQILIcY94PKU2lLsD/oolPHuhpKKUM2lIHwMHLKfRhhz+Y978R969tMZwyaBcfM7FoNhkTKZ3S0yrQM0QLtkwZE2R2j87jamEww3yN8+8nh9uz2ecuxsGRGo/VfIW7pVzzX2z04e2MvkKrD56Lb0OZ097I4Gke/NJIBj++Q51L1z7OhH+i7n/mbYAa91TzNwAA//9QSwcIN78MDVMBAADnBAAAUEsDBBQACAAIAAAAAAAAAAAAAAAAAAAAAAALAAAAX3JlbHMvLnJlbHOM0sFKMzEQB/D79xRh7t1p+4GINO1FhN5E6gOMyexu2CQTkqjp24sH0YVa9/7nP78ZZndowas3zsVJ1LDp1qA4GrEuDhqeTw+rW1ClUrTkJbKGMxc47P/tnthTdRLL6FJRLfhYNIy1pjvEYkYOVDpJHFvwveRAtXSSB0xkJhoYt+v1DeafHbCfdaqj1ZCP9j+o0znxkm7pe2f4Xsxr4FgvjEBulaNlu0pZEufquIA6UR64arBiHrOkgpRS14IHvCzaLhf9vi0GrmSpEhrJfN3zmbgG2iwH/X2ieeJb0zy+S55eRKYvC85+YP8RAAD//1BLBwgXtjc47wAAAEsCAABQSwMEFAAIAAgAAAAAAAAAAAAAAAAAAAAAABEAAABkb2NQcm9wcy9jb3JlLnhtbKSRT2vzMAyH7++nCL4ncloo70KSHjZ62mCwjo3djK22ZvEfLHdxv/1I2qYd623gk36PHmSpXibTZV8YSDvbsLLgLEMrndJ227DX9Sr/zzKKwirROYsNOyCxZfuvlr6SLuBzcB5D1EhZMp2lSvqG7WL0FQDJHRpBhfNok+k2LhgRqXBhC17IT7FFmHG+AINRKBEFDMLcT0Z2Uio5Kf0+dKNAScAODdpIUBYlXNiIwdDNhjG5Io2OB4830XM40Yn0BPZ9X/TzEZ1xXsL70+PL+NVc22FVEllbK1nJgCK60KZ90DVcFerTlMcCqiyRro6znJO3+f3DesXaYUE5v8vLxZrzanwfg+tH/0VonNIb/QfjWdDW8OvC7XcAAAD//1BLBwiW4gU1HQEAAC0CAABQSwECFAAUAAgACAAAAAAANzD8GEwFAAB1GQAAEwAAAAAAAAAAAAAAAAAAAAAAeGwvdGhlbWUvdGhlbWUxLnhtbFBLAQIUABQACAAIAAAAAABCVpD9ywQAAC4WAAANAAAAAAAAAAAAAAAAAI0FAAB4bC9zdHlsZXMueG1sUEsBAhQAFAAIAAgAAAAAAIwdxH5KAQAAbQMAABgAAAAAAAAAAAAAAAAAkwoAAHhsL3dvcmtzaGVldHMvc2hlZXQzLnhtbFBLAQIUABQACAAIAAAAAADzQZnEwQAAADEBAAAQAAAAAAAAAAAAAAAAACMMAABkb2NQcm9wcy9hcHAueG1sUEsBAhQAFAAIAAgAAAAAAF0ou7PnAAAA8QIAABoAAAAAAAAAAAAAAAAAIg0AAHhsL19yZWxzL3dvcmtib29rLnhtbC5yZWxzUEsBAhQAFAAIAAgAAAAAAAAnEOG2AAAACwEAABgAAAAAAAAAAAAAAAAAUQ4AAHhsL3dvcmtzaGVldHMvc2hlZXQyLnhtbFBLAQIUABQACAAIAAAAAABVwBtsnAEAABoDAAAPAAAAAAAAAAAAAAAAAE0PAAB4bC93b3JrYm9vay54bWxQSwECFAAUAAgACAAAAAAAN78MDVMBAADnBAAAEwAAAAAAAAAAAAAAAAAmEQAAW0NvbnRlbnRfVHlwZXNdLnhtbFBLAQIUABQACAAIAAAAAAAXtjc47wAAAEsCAAALAAAAAAAAAAAAAAAAALoSAABfcmVscy8ucmVsc1BLAQIUABQACAAIAAAAAACW4gU1HQEAAC0CAAARAAAAAAAAAAAAAAAAAOITAABkb2NQcm9wcy9jb3JlLnhtbFBLBQYAAAAACgAKAIQCAAA+FQAAAAA=",
        "name":  utils.random_string_with_prefix(30, prefix=name_prefix),
        "query": query,
        "schemaName": schemaname,
        "transformationTemplate": transfortemp,
        "type": temp_type,
        "withTemplate": withTemplate,
    }

def get_idp_payload(idp):
    payload = json.load(open(f"utils/data/{idp}_idp_payload.json"))
    return payload

