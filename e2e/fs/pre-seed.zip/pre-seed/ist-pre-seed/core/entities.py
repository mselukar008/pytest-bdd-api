from requests import codes
from aiops import api_client

from core.api_client import CoreApiClient,AzureApiClient
from core import payload_helper
from utils import (
    datetime_now_str,
    entities_base
)


class Entities(entities_base.EntitiesBase):
    def __init__(self, api_client, data, logger=None):
        super().__init__(api_client, data, logger)
        self.Budget = Budget(api_client, logger)
        self.Core = Core(api_client, logger)
        self.Azure = Azure(api_client, logger)

    @staticmethod
    def create_instance(host: str, user: str, apikey: str, logger, authorization: str):
        headers = CoreApiClient.create_headers(user, apikey, authorization)
        return Entities(
            CoreApiClient(host, headers,
                        logger,
                        {},
                        max_round_trip=300,
                        json_indent=4),
            {},
            logger
        )

    @staticmethod
    def create_azure_instance(host: str, logger):
        return Entities(
            AzureApiClient(host, {},logger),
            {},
            logger
        )

class Azure(entities_base.EntityBase):
    def __init__(self, api_client, logger):
        super().__init__(api_client, logger)
    
    def get_azure_bearer_token(self ,tenant,form_data):
        token = None
        self.request_handler(self.api_client.get_bearer_token,tenant, form_data)
        if self.status_code == codes.OK:
            token = self.response_body.get('access_token')
        return token
    
    def get_application_details(self, bearer_token, application_id):
        self.request_handler(self.api_client.get_application_details, bearer_token, application_id)
        if self.status_code == codes.OK:
            body = self.response_body
        return body
    
    def set_application_identified_uris(self, bearer_token, application_id , payload):
        self.request_handler(self.api_client.set_application_identified_uris, bearer_token, application_id,payload)
        return self.status_code == 204
    
    def set_application_redirect_uris(self, bearer_token, application_id , payload):
        self.request_handler(self.api_client.set_application_redirect_uris, bearer_token, application_id,payload)
        return self.status_code == 204




class Core(entities_base.EntityBase):
    def __init__(self, api_client, logger):
        super().__init__(api_client, logger)
        self.saved_currency_conversion_rates = []

    def _already_created(self):
        return ((self.status_code == codes.BAD_REQUEST or self.status_code == codes.CONFLICT)
                and 'duplicate' in self.response_body.get('message', '')
                or 'already exists' in self.response_body.get('message', ''))

    def create_config_values(self, payload):
        self.request_handler(self.api_client.create_config_values, payload)
        return self.status_code == codes.OK

    def get_config_values(self, key):
        self.request_handler(self.api_client.get_config_values, key)
        return self.status_code == codes.OK

    def update_config_values(self, payload):
        self.request_handler(self.api_client.update_config_values, payload)
        return self.status_code == codes.OK

    def delete_config_value(self, key):
        self.request_handler(self.api_client.delete_config_value, key)
        return self.status_code == codes.OK

    def get_authorization(self):
        self.request_handler(self.api_client.get_authorization)
        return self.status_code == codes.OK

    def set_authorization(self, authorization):
        payload = payload_helper.set_authorization(authorization)
        self.logger.info(f'Pointing authorization to {authorization}')
        self.request_handler(self.api_client.set_authorization, payload)
        return self.status_code == codes.OK or self.status_code == codes.CREATED

    def get_bearer_token(self, api_key_name="cd_auto_key", user=None, apikey=None):
        token = None
        if user and apikey:
            self.api_client.temp_headers.update({
                'username': user,
                'apikey': apikey
            })
        self.request_handler(self.api_client.get_bearer_token, api_key_name)
        if self.status_code == codes.OK:
            token = self.response_body.get('token')
        return token

    def set_message_subscription(self, payload):
        self.logger.info(f'Setting message subscription: {payload["name"]}')
        self.request_handler(self.api_client.set_message_subscription, payload)
        if self.status_code == codes.CONFLICT:
            self.logger.info("Message subscription already exists")
        return self.status_code == codes.OK

    def create_user(self, payload):
        self.logger.info('Creating user')
        self.request_handler(self.api_client.create_user, payload)
        return self.status_code == codes.OK

    def set_system_user_management(self, enable: bool):
        self.logger.info(f'{"Enabling" if enable else "Disabling"} system user management')
        self.request_handler(self.api_client.set_system_user_management, {"enable": enable})
        return self.status_code == codes.OK

    def create_system_user(self, payload):
        self.logger.info(f'Creating system user {payload["userid"]}')
        self.request_handler(self.api_client.create_system_user, payload)
        return self.status_code == codes.OK

    def update_user(self, user_id, payload):
        self.logger.info(f'Updating user: {user_id}')
        self.request_handler(self.api_client.update_user, user_id, payload)
        return self.status_code == codes.OK

    def update_system_user(self, user_id, payload):
        self.logger.info(f'Updating user: {user_id}')
        self.request_handler(self.api_client.update_system_user, user_id, payload)
        return self.status_code == codes.OK

    def get_user(self, user_id):
        self.request_handler(self.api_client.get_user, user_id)
        return self.status_code == codes.OK

    def get_system_user_api_key(self, user_id):
        payload = {'type': 'systemuser'}
        self.request_handler(self.api_client.create_api_key, user_id, payload)
        ok = self.status_code == codes.CREATED and 'key' in self.response_body
        if not ok and self.status_code == codes.ACCEPTED:
            self.request_handler(self.api_client.update_api_key, user_id, payload)
            ok = self.status_code == codes.OK and 'key' in self.response_body
        return ok

    def create_or_update_user(self, payload):
        ok = self.create_user(payload)
        if not ok and self._already_created():
            self.logger.info('User already existed')
            user_id = self.response_body['translateParameters'][0]
            ok = self.update_user(user_id, payload)
        return ok

    def create_or_update_system_user(self, payload):
        ok = self.create_system_user(payload)
        if not ok and self._already_created():
            self.logger.info('System user already existed')
            ok = self.update_system_user(payload['userid'], payload)
        return ok

    def set_external_context_adapter(self, payload):
        self.logger.info(f'Pointing external context adapter to: {payload["_adapter_url"]}')
        self.request_handler(self.api_client.set_external_context_adapter, payload)
        return self.status_code == codes.OK

    def external_auth_create_users(self, payload):
        self.logger.info('Creating users')
        self.request_handler(self.api_client.external_auth_create_users, payload)
        return self.status_code == codes.OK and self.response_body == payload

    def load_external_context_values(self, payload):
        self.request_handler(self.api_client.load_external_context_values, payload)
        return self.status_code == codes.OK

    def create_organizations(self, payload):
        self.logger.info('Creating organizations')
        self.request_handler(self.api_client.create_organizations, payload)
        return self.status_code == codes.OK

    def update_organization(self, id, payload):
        self.logger.info(f'Updating organization: {id}')
        self.request_handler(self.api_client.update_organization, id, payload)
        return self.status_code == codes.OK

    def create_or_update_organizations(self, payload):
        all_good = self.create_organizations(payload)
        if not all_good and self._already_created():
            all_good = True
            for org in payload:
                ok = self.update_organization(org['id'], org)
                if not ok:
                    ok = self.create_organizations([org])
                all_good &= ok
        return all_good

    def create_context_values(self, context_tag_id, payload):
        self.logger.info('Creating context values')
        self.request_handler(self.api_client.create_context_values, context_tag_id, payload)
        if self._already_created():
            self.logger.info('Context values already created')
        return self.status_code == codes.OK

    def update_context_values(self, context_tag_id, payload):
        self.logger.info('Updating context values')
        self.request_handler(self.api_client.update_context_values, context_tag_id, payload)
        return self.status_code == codes.OK

    def create_context_type(self, payload):
        self.logger.info('Creating context type')
        self.request_handler(self.api_client.create_context_type, payload)
        if self._already_created():
            self.logger.info('Context type already created')
        return self.status_code == codes.OK

    def update_context_type(self, context_tag_id, payload):
        self.logger.info('Updating context type')
        self.request_handler(self.api_client.update_context_type, context_tag_id, payload)
        return self.status_code == codes.OK

    def get_context_tag_types(self, business_function='CATALOG', level='BROWSE'):
        self.logger.info('Getting context tag types')
        self.request_handler(self.api_client.get_context_tag_types, business_function, level)
        return self.status_code == codes.OK

    def get_filter_contexts(self, payload):
        self.logger.info('Getting filtered contexts')
        self.request_handler(self.api_client.get_filtered_contexts, payload)
        return self.status_code == codes.OK

    def get_contexts(self):
        self.request_handler(self.api_client.get_contexts)
        return self.status_code == codes.OK

    def delete_context_type(self, type_id):
        self.request_handler(self.api_client.delete_context_type, type_id)
        return self.status_code == codes.OK

    def delete_context_types_by(self, predicate):
        all_good = False
        if self.get_contexts():
            contexts = self.response_body
            all_good = True
            for context in contexts:
                if predicate(context):
                    all_good &= self.delete_context_type(context['contexttagtype'])
        return all_good

    def delete_all_context_types(self):
        return self.delete_context_types_by(lambda x: True)

    def context_builder(self, business_function, **kwargs):
        context = []
        self.get_context_tag_types()
        contexts_response = self.response_body
        payload = payload_helper.filtered_contexts(business_function)

        def append_to_context(context_tag_type):
            payload['find_context'] = context_tag_type
            self.get_filter_contexts(payload)
            if self.response_body[context_tag_type]:
                tag_value = ''
                if context_tag_type in kwargs:
                    for value in self.response_body[context_tag_type]:
                        if kwargs[context_tag_type] == value['tagcode']:
                            tag_value = value['tagcode']
                if not tag_value:
                    tag_value = self.response_body[context_tag_type][0]['tagcode']
                context.append({
                    "tagValueCode": tag_value,
                    "tagType": context_tag_type
                })
        # Get team 1st; index is always 1.
        append_to_context(contexts_response[1]['contexttagtype'])
        payload['known_contexts']["team"] = context[0]['tagValueCode']
        # Get org 2nd; index is always 0.
        append_to_context(contexts_response[0]['contexttagtype'])
        payload['known_contexts']["org"] = context[1]['tagValueCode']
        # Get custom contexts.
        for item in contexts_response[2:]:
            append_to_context(item['contexttagtype'])
        return context

    def import_soi_context_builder(self, business_function, **kwargs):
        context = []
        self.get_context_tag_types()
        contexts_response = self.response_body
        payload = payload_helper.filtered_contexts(business_function)

        def append_to_context(context_tag_type, context_type_name):
            payload['find_context'] = context_tag_type
            self.get_filter_contexts(payload)
            if self.response_body[context_tag_type]:
                tag_value = ''
                if context_tag_type in kwargs:
                    for value in self.response_body[context_tag_type]:
                        if kwargs[context_tag_type] == value['tagcode']:
                            tag_value = value['tagcode']
                if not tag_value:
                    tag_value = self.response_body[context_tag_type][0]['tagcode']
                context.append({
                    'tagValue': '',
                    'values': [tag_value],
                    'name': context_type_name,
                    'tagType': context_tag_type
                })
        # org is always 1st
        append_to_context(contexts_response[0]['contexttagtype'], contexts_response[0]['name'])
        # team is always 2nd
        append_to_context(contexts_response[1]['contexttagtype'], contexts_response[1]['name'])
        payload['known_contexts'] = {
            "org": context[0]['values'][0],
            "team": context[1]['values'][0]
        }
        for item in contexts_response[2:]:
            append_to_context(item['contexttagtype'], item['name'])
        return context

    def create_team(self, payload):
        self.logger.info(f"Creating team: {payload['name']}")
        self.request_handler(self.api_client.create_team, payload)
        return self.status_code == codes.OK

    def create_or_update_team(self, payload):
        ok = self.create_team(payload)
        if not ok and self._already_created():
            self.logger.info(f"Team '{payload['name']}' already created")
            ok = self.update_team(payload['teamcode'], payload)
        return ok

    def create_team_and_move_users(self, team_code, roles, users, name=None, org='svt_api'):
        payload = {
            "roles": [],
            "enabled": True,
            "version": "3.0",
            "name": name if name else team_code,
            "teamcode": team_code,
            "org": org
        }
        all_good = False
        if self.create_team(payload) or self._already_created():
            payload['roles'] = roles
            all_good = self.update_team(team_code, payload)
            if all_good:
                move_payload = {
                    "team_code_list": [team_code],
                    "user_id_list": users
                }
                all_good &= self.move_users_to_different_teams(move_payload)
        return all_good

    def external_auth_create_teams(self, payload):
        self.logger.info('Creating teams')
        self.request_handler(self.api_client.external_auth_create_teams, payload)
        return self.status_code == codes.OK

    def update_team(self, team_code, payload):
        self.logger.info(f'Updating team: {team_code}')
        self.request_handler(self.api_client.update_team, team_code, payload)
        return self.status_code == codes.OK

    def delete_team(self, team_code):
        self.request_handler(self.api_client.delete_team, team_code)
        return self.status_code == codes.OK

    def delete_organization(self, team_code):
        self.request_handler(self.api_client.delete_organization, team_code)
        return self.status_code == codes.OK

    def get_basic_info(self):
        self.request_handler(self.api_client.get_basic_info)
        return self.status_code == codes.OK

    def get_user_info(self, id_):
        self.request_handler(self.api_client.get_user_info, id_)
        return self.status_code == codes.OK

    def get_user_infos(self, usertype=None, start_offset=None, limit=None, search_value=None, search_properties=None, 
                       sortby=None, direction=None, exclude=None):
        self.request_handler(self.api_client.get_user_infos, usertype, start_offset, limit, search_value,
                             search_properties, sortby, direction, exclude)
        return self.status_code == codes.OK

    def get_users_teams(self, user_id):
        self.request_handler(self.api_client.get_users_teams, user_id)
        return self.status_code == codes.OK

    def assign_users_to_teams(self, payload):
        self.logger.info('Assigning users to teams')
        self.request_handler(self.api_client.assign_users_to_teams, payload)
        return self.status_code == codes.OK

    def remove_users_from_teams(self, payload):
        self.logger.info('Removing users from teams')
        self.request_handler(self.api_client.remove_users_to_teams, payload)
        return self.status_code == codes.OK

    def move_users_to_different_teams(self, payload):
        all_good = True
        for user_id in payload['user_id_list']:
            if self.get_users_teams(user_id):
                remove_payload = {
                    "team_code_list": [x['teamcode'] for x in self.response_body],
                    "user_id_list": [user_id]
                }
                all_good &= self.remove_users_from_teams(remove_payload)
            else:
                all_good &= False
        all_good &= self.assign_users_to_teams(payload)
        return all_good

    def validate_credentials(self, provider_code, additional_info, password_fields):
        payload = {
            "basicInfo": {
                "accountName": "just_validating",
                "serviceProviderType": provider_code,
                "serviceProviderCode": provider_code,
                "isActive": "Active",
                "accountType": "subaccount",
                "userType": "asset",
                "description": None
            },
            "advancedInfo": additional_info,
            "credentials": {
                "credentialName": "just_validating",
                "description": "",
                "purpose": ["provisioning", "assetIngestion"],
                "status": True,
                "passwordFields": password_fields
            }
        }
        self.request_handler(self.api_client.credential_validator, payload)
        return self.status_code == codes.OK

    def get_vault(self):
        self.request_handler(self.api_client.get_vault)
        return self.status_code == codes.OK

    def create_service_provider_meta_data(self, payload):
        self.logger.info(f'Creating {payload["providerType"]} meta data')
        self.request_handler(self.api_client.create_service_provider_meta_data, payload)
        return self.status_code == codes.OK

    def create_service_provider(self, payload):
        self.logger.info(f'Creating {payload["serviceProviderCode"]} provider')
        self.request_handler(self.api_client.create_service_provider, payload)
        return self.status_code == codes.OK

    def create_asset_provider(self, payload):
        all_good = self.create_service_provider_meta_data(payload)
        if all_good:
            if self.get_vault():
                vault_id = self.response_body[0]['vault_id']
                payload = payload_helper.service_provider_builder(vault_id, payload['providerType'], payload['displayName'])
                all_good = self.create_service_provider(payload)
        return all_good

    def create_provider_account(self, payload):
        self.logger.info(f'Creating {payload["account"]["basicInfo"]["userType"]} provider account')
        self.request_handler(self.api_client.create_provider_account, payload)
        if self.status_code == codes.CONFLICT:
            self.logger.info('Provider account already created')
        return self.status_code == codes.OK and self.response_body.get('statusCode', 0) == codes.OK

    def create_or_update_service_provider(self, payload):
        ok = self.create_service_provider_meta_data(payload)
        if not ok and self.status_code == codes.CONFLICT:
            prov_type = payload["providerType"]
            ok = self.update_service_provider_metadata(payload["providerType"],payload)
        if ok and self.get_vault():
            vault_id = self.response_body[0]['vault_id']
            payload = payload_helper.service_provider_builder(vault_id, payload["providerType"], payload['displayName'])
            ok = self.create_service_provider(payload)
            if not ok and self.status_code == codes.CONFLICT:
                ok = self.update_service_provider(payload["serviceProviderCode"],payload)
        return ok

    def create_or_update_provider_account(self, payload):
        ok = self.create_provider_account(payload)
        if not ok and self.status_code == codes.CONFLICT:
            prov_code = payload["account"]["basicInfo"]["serviceProviderCode"]
            acct_name = payload["account"]["basicInfo"]["accountName"]
            user_type = payload["account"]["basicInfo"]["userType"]
            if self.get_providers_accounts(prov_code, user_type, 10, acct_name):
                for account in self.response_body[1:]:
                    if acct_name == account["basicInfo"]["accountName"]:
                        acct_id = account["accountId"]
                        ok = self.update_provider_account(acct_id, payload)
                        break
        return ok

    def update_service_provider_metadata(self, service_provider_type, payload):
        self.logger.info(f'Updating {service_provider_type} meta data')
        self.request_handler(self.api_client.update_service_provider_meta_data, service_provider_type, payload)
        return self.status_code == codes.OK

    def update_service_provider(self, service_provider_code, payload):
        self.logger.info(f'Updating {service_provider_code} meta data')
        self.request_handler(self.api_client.update_service_provider, service_provider_code, payload)
        return self.status_code == codes.OK

    def update_provider_account(self, account_id, payload):
        self.logger.info(f'Updating {payload["account"]["basicInfo"]["userType"]} provider account')
        self.request_handler(self.api_client.update_provider_account, account_id, payload)
        return self.status_code == codes.OK and self.response_body.get('statusCode', 0) == codes.OK

    def create_or_patch_provider_account(self, payload):
        def get_ids(account, credential_name):
            cref_id, cred_id = None,  None
            for credential in account['credentials']:
                if credential['credentialName'] == credential_name:
                    cref_id = credential['crefId']
                    cred_id = credential['id']
            return cref_id, cred_id

        account_id, cred_ids = "", {}
        if self.create_provider_account(payload):
            account_id = list(self.response_body["accountIds"][0].values())[0]
            if self.get_provider_account(account_id):
                for credential in self.response_body['credentials']:
                    cred_ids[credential['credentialName']] = credential['id']
        elif self.status_code == codes.CONFLICT:
            account_name = payload["account"]["basicInfo"]["accountName"]
            if self.get_providers_accounts(payload["account"]["basicInfo"]["serviceProviderCode"], payload["account"]["basicInfo"]["userType"], 10, account_name):
                for account in self.response_body[1:]:
                    if account_name == account["basicInfo"]["accountName"]:
                        account_id = account['accountId']
                        asset_payload = {
                            'basicInfo': payload["account"]['basicInfo'],
                            'advancedInfo': payload["account"]['advancedInfo']
                        }
                        if 'description' in asset_payload['basicInfo']:
                            asset_payload['basicInfo']['description'] = asset_payload['basicInfo']['description'] or ""
                        if self.patch_asset_provider_account(account["accountId"], asset_payload):
                            account_id = account["accountId"]
                            for credential in payload['account']['credentials']:
                                cref_id, cred_id = get_ids(account, credential['credentialName'])
                                if cref_id:
                                    credential['crefId'] = cref_id
                                    credential['credentialId'] = cred_id
                                    credential['isPasswordUpdated'] = True
                                    credential.pop('createdBy', None)
                                    credential.pop('testConnectionStatus', None)
                                    credential.pop('additional_info', None)
                                    credential['editedBy'] = {
                                        'time': datetime_now_str()
                                    }
                                    if self.patch_credential_provider_account(account["accountId"], cred_id, credential):
                                        cred_ids[credential['credentialName']] = cred_id
                                elif self.add_credential_to_provider_account(account["accountId"], {'credentials': credential}):
                                    cred_ids[credential['credentialName']] = cred_id
                        break
        return account_id, cred_ids

    def patch_asset_provider_account(self, account_id, payload):
        self.logger.info(f'Patching {payload["basicInfo"]["userType"]} provider account: {account_id}')
        self.request_handler(self.api_client.patch_asset_provider_account, account_id, payload)
        return self.status_code == codes.OK and self.response_body.get('statusCode', 0) == codes.OK

    def patch_credential_provider_account(self, account_id, cred_id, payload):
        self.logger.info(f'Patching credential provider account: {account_id}/{cred_id}')
        self.request_handler(self.api_client.patch_credential_provider_account, account_id, cred_id, payload)
        return self.status_code == codes.OK and self.response_body.get('statusCode', 0) == codes.OK

    def add_credential_to_provider_account(self, account_id, payload):
        self.logger.info(f'Adding credential to provider account: {account_id}')
        self.request_handler(self.api_client.add_credential_to_provider_account, account_id, payload)
        return self.status_code == codes.OK and self.response_body.get('statusCode', 0) == codes.OK

    def delete_provider_account(self, account_id):
        self.logger.info('Deleting provider account')
        self.request_handler(self.api_client.delete_provider_account, account_id)
        return self.status_code == codes.NO_CONTENT

    def get_provider_account(self, account_id):
        self.request_handler(self.api_client.get_provider_account, account_id)
        return self.status_code == codes.OK

    def get_providers_accounts(self, provider_code, user_type, size=10, search_text=''):
        self.request_handler(self.api_client.get_providers_accounts, provider_code, user_type, size, search_text)
        return self.status_code == codes.OK

    def delete_provider_account_by(self, predicate, provider_code, user_type, search_text=''):
        ok = False
        if self.get_providers_accounts(provider_code, user_type, search_text=search_text):
            ok = True
            for item in self.response_body[1:]:
                if predicate(item):
                    ok &= self.delete_provider_account(item['accountId'])
        return ok

    def delete_service_provider_code(self, provider_code):
        self.request_handler(self.api_client.delete_service_provider_code, provider_code)
        return self.status_code == codes.NO_CONTENT

    def delete_service_provider_meta_data(self, provider_code):
        self.request_handler(self.api_client.delete_service_provider_meta_data, provider_code)
        return self.status_code == codes.OK

    def delete_service_provider(self, provider_code):
        self.request_handler(self.api_client.delete_service_provider, provider_code)
        return self.status_code == codes.NO_CONTENT

    def delete_asset_provider(self, provider_code):
        return (self.delete_service_provider_code(provider_code)
                and self.delete_service_provider_meta_data(provider_code))

    def delete_all_provider_account_data(self, provider_code):
        return (self.delete_provider_account_by(lambda x: True, provider_code, 'asset')
                and self.delete_provider_account_by(lambda x: True, provider_code, 'billing')
                and self.delete_service_provider_code(provider_code)
                and self.delete_service_provider_meta_data(provider_code)
                and self.delete_service_provider(provider_code))

    def get_default_currency(self):
        self.request_handler(self.api_client.get_default_currency)
        return self.status_code == codes.OK

    def lock_default_currency(self, currency_code):
        self.request_handler(self.api_client.lock_default_currency, currency_code)
        return self.status_code == codes.NO_CONTENT or (self.status_code == codes.BAD_REQUEST and "CO400CURRENCY_ALREADY_LOCKED" in self.response_body.get("message", ""))

    def get_supported_currencies(self):
        self.request_handler(self.api_client.get_supported_currencies)
        return self.status_code == codes.OK

    def get_currency_conversion_rate(self, _id):
        self.request_handler(self.api_client.get_currency_conversion_rate, _id)
        return self.status_code == codes.OK

    def get_currency_conversion_rates(self, _from='', _to=''):
        self.request_handler(self.api_client.get_currency_conversion_rates, _from, _to)
        return self.status_code == codes.OK

    def create_currency_conversion_rate(self, payload):
        self.logger.info(f'Creating currency conversion rate -> 1 {payload["currencyfrom"]} : {payload["exchangerate"]} {payload["currencyto"]}')
        self.request_handler(self.api_client.create_currency_conversion_rate, payload)
        return self.status_code == codes.CREATED

    def update_currency_conversion_rate(self, _id, payload):
        self.logger.info(f'Updating currency conversion rate -> 1 {payload["currencyfrom"]} : {payload["exchangerate"]} {payload["currencyto"]}')
        self.request_handler(self.api_client.update_currency_conversion_rate, _id, payload)
        return self.status_code == codes.OK

    def delete_currency_conversion_rate(self, _id):
        self.logger.info(f'Deleting currency conversion rate: {_id}')
        self.request_handler(self.api_client.delete_currency_conversion_rate, _id)
        return self.status_code == codes.NO_CONTENT

    def delete_all_currency_conversion_rates(self):
        all_good = True
        if self.get_currency_conversion_rates() and self.status_code == codes.OK:
            for rate in self.response_body:
                all_good &= self.delete_currency_conversion_rate(rate['id'])
        return all_good

    def save_currency_conversion_rates(self):
        self.logger.info('Saving currency conversion rates')
        all_good = self.get_currency_conversion_rates()
        if all_good:
            for rate in self.response_body:
                self.saved_currency_conversion_rates.append((rate['currencyfrom'], rate['currencyto'], rate['exchangerate']))
        return all_good

    def load_currency_conversion_rates(self):
        self.logger.info('Loading currency conversion rates')
        all_good = True
        for rate in self.saved_currency_conversion_rates:
            payload = payload_helper.currency_conversion_builder(rate[0], rate[1], rate[2])
            all_good &= self.create_currency_conversion_rate(payload)
        self.saved_currency_conversion_rates.clear()
        return all_good
    
    def _enable_featureflag(self, payload):
        self.logger.info('Setting feature flag')
        self.request_handler(self.api_client._enable_featureflag, payload)
        return self.status_code == codes.OK
    
    def add_new_idp(self, payload, idp, bearer_token):
        self.logger.info(f'Creating new {idp} IdP')
        self.request_handler(self.api_client.create_idp, payload, bearer_token)
        return self.status_code == codes.OK
        


class BudgetPopo:
    def __init__(self, id_, name, total):
        self.id = id_
        self.name = name
        self.total = total


class BudgetaryUnit:
    def __init__(self, id_, code, name, period):
        self.id = id_
        self.code = code
        self.name = name
        self.period = period
        self.budgets = []


class Budget(entities_base.EntityBase):
    def __init__(self, api_client, logger):
        super(Budget, self).__init__(api_client, logger)
        self._budgetary_unit_index = -1
        self._budget_index = -1
        self.budgetary_units = []

    @property
    def budgetary_unit_code(self):
        return self.budgetary_units[self._budgetary_unit_index].code if self.budgetary_units else None

    @property
    def budget_id(self):
        return self.budgetary_units[self._budgetary_unit_index].budgets[self._budget_index].id if self.budgetary_units and self.budgetary_units[self._budgetary_unit_index].budgets else None

    @property
    def period(self):
        return self.budgetary_units[self._budgetary_unit_index].period if self.budgetary_units else None

    @property
    def budget_total(self):
        return self.budgetary_units[self._budgetary_unit_index].budgets[self._budget_index].total if self.budgetary_units and self.budgetary_units[self._budgetary_unit_index].budgets else None

    def set_budget_by_index(self, budgetary_unit_index, budget_index):
        try:
            self.budgetary_units[budgetary_unit_index].budgets[budget_index]
            self._budgetary_unit_index = budgetary_unit_index
            self._budget_index = budget_index
        except IndexError:
            self.logger.warning(f'Failed to set budget because budgetary-unit/budget index is out of bounds. Tried to access [{budgetary_unit_index}][{budget_index}]')

    def create_budgetary_unit(self, payload):
        self.logger.info(f'Creating budgetary unit: {payload["name"]}')
        self.request_handler(self.api_client.create_budgetary_unit, payload)
        if self.status_code == codes.OK and 'id' in self.response_body:
            self.budgetary_units.append(BudgetaryUnit(self.response_body['id'], payload['budgetcode'], payload["name"], payload['budgetperiod']))
        return self.status_code == codes.OK and 'id' in self.response_body

    def create_or_update_budgetary_unit(self, payload):
        all_good = self.create_budgetary_unit(payload)
        if not all_good and self.status_code == codes.CONFLICT:
            self.budgetary_units.append(BudgetaryUnit("", payload['budgetcode'], payload["name"], payload['budgetperiod']))
            budgets = []
            budgets_inactive = True
            if self.get_budgets():
                budgets = self.response_body
                for budget in budgets:
                    self.budgetary_units[self._budgetary_unit_index].budgets.append(BudgetPopo(budget['id'], None, None))
                    if budget['status'] == 'Active':
                        budget['status'] = 'Inactive'
                        self._fix_budget_payload(budget)
                        self.update_budget(budget)
            all_good = budgets_inactive and self.update_budgetary_unit(payload)
            if all_good:
                for i, budget in enumerate(budgets):
                    self.set_budget_by_index(-1, i)
                    budget['status'] = 'Active'
                    self._fix_budget_payload(budget)
                    all_good &= self.update_budget(budget)
        return all_good

    def create_budget(self, payload):
        self.logger.info(f'Creating budget: {payload["name"]}')
        self.request_handler(self.api_client.create_budget, self.budgetary_unit_code, payload)
        if self.status_code == codes.OK and 'id' in self.response_body:
            self.budgetary_units[self._budgetary_unit_index].budgets.append(BudgetPopo(self.response_body['id'], payload["name"], payload['budgetTotal']))
        return self.status_code == codes.OK and 'id' in self.response_body

    def create_or_update_budget(self, payload):
        all_good = self.create_budget(payload)
        if not all_good and isinstance(self.response_body, list) and any('BD409_BUDGET_EXISTS' in item for item in self.response_body):
            budget_id = ''
            for budget in self.budgetary_units[self._budgetary_unit_index].budgets:
                if budget.name == payload['name']:
                    budget_id = budget.id
                    break
            if not budget_id:
                self.get_budgets()
                for budget in self.response_body:
                    if budget['name'] == payload['name']:
                        budget_id = budget['id']
                        break
            if budget_id:
                self.budgetary_units[self._budgetary_unit_index].budgets.append(BudgetPopo(budget_id, payload["name"], payload['budgetTotal']))
                all_good = self.update_budget(payload)
        return all_good

    def update_budgetary_unit(self, payload):
        self.logger.info(f'Updating Budgetary Unit {payload["budgetcode"]}')
        self.request_handler(self.api_client.update_budgetary_unit, self.budgetary_unit_code, payload)
        return self.status_code == codes.OK

    def update_budget(self, payload):
        self.logger.info(f'Updating budget {payload["name"]}')
        self.request_handler(self.api_client.update_budget, self.budgetary_unit_code, self.budget_id, payload)
        return self.status_code == codes.OK

    def create_bulk_budgets(self, payload):
        self.logger.info(f'Creating bulk budget')
        self.request_handler(self.api_client.bulk_create_budgets, self.budgetary_unit_code, self.budget_id, payload)
        return self.status_code == codes.OK

    def get_budgetary_unit(self):
        self.request_handler(self.api_client.get_budgetary_unit, self.budgetary_unit_code)
        return self.status_code == codes.OK

    def get_budgetary_units(self, **query):
        self.request_handler(self.api_client.get_budgetary_units, **query)
        return self.status_code == codes.OK

    def get_budgets(self, search_text=None):
        self.request_handler(self.api_client.get_budgets, self.budgetary_unit_code, search_text)
        return self.status_code == codes.OK

    def get_all_budgets(self):
        self.request_handler(self.api_client.get_all_budgets)
        return self.status_code == codes.OK

    def get_budget(self, filter_=None):
        self.request_handler(self.api_client.get_budget, self.budgetary_unit_code, self.budget_id, filter_)
        return self.status_code == codes.OK

    def get_budget_audits(self):
        self.request_handler(self.api_client.get_budget_audits, self.budgetary_unit_code, self.budget_id)
        return self.status_code == codes.OK

    def get_budgetary_terms(self):
        self.request_handler(self.api_client.get_budgetary_terms)
        return self.status_code == codes.OK

    def commit_budget(self, payload):
        payload['budgetaryunit'] = self.budgetary_unit_code
        self.logger.info(f'Committing budget: {payload["charges"]}')
        self.request_handler(self.api_client.commit_budget, payload)
        return self.status_code == codes.OK

    def monthly_spend_quota(self, budgetary_unit_code, payload, budget_id):
        self.request_handler(self.api_client.patch_monthly_spend_quota, budgetary_unit_code, payload, budget_id)
        return self.status_code == codes.OK

    @staticmethod
    def _fix_budget_payload(payload):
        payload['budgetTotal'] = float(payload['budgetTotal'])
        payload['softThresholdTotal'] = float(payload['softThresholdTotal'])
        payload['hardThresholdTotal'] = float(payload['hardThresholdTotal'])
        payload['contacts_soft_threshold'] = payload['contacts_soft_threshold'] or []
        payload['contacts_hard_threshold'] = payload['contacts_hard_threshold'] or []
        payload['teams'] = payload['teams'] or []
        payload['externalrefid'] = payload['externalrefid'] or ''

    def delete_budget(self):
        self.logger.info(f'Deleting budget: {self.budget_id}')
        self.request_handler(self.api_client.delete_budget, self.budgetary_unit_code, self.budget_id)
        return self.status_code == codes.OK

    def delete_budgetary_unit(self):
        self.logger.info(f'Deleting budgetary unit: {self.budgetary_unit_code}')
        self.request_handler(self.api_client.delete_budgetary_unit, self.budgetary_unit_code)
        return self.status_code == codes.OK

    def delete_budgetary_units_by(self, predicate):
        got_budgets=False
        all_good = self.get_budgetary_units()
        if all_good:
            budgetary_units = self.response_body
            self._budgetary_unit_index = -1
            self._budget_index = -1
            for budgetary_unit in budgetary_units:
                if predicate(budgetary_unit):
                    self.budgetary_units.append(BudgetaryUnit(None, budgetary_unit['budgetcode'], None, None))
                    self.logger.info(f'budgetary_unit: {budgetary_unit["budgetcode"]}')
                    got_budgets = self.get_budgets()
                    if got_budgets:
                        budgets = self.response_body
                        for budget in budgets:
                            self.budgetary_units[self._budgetary_unit_index].budgets.append(BudgetPopo(budget['id'], None, None))
                            if budget['status'] == 'Active':
                                budget['status'] = 'Inactive'
                                self._fix_budget_payload(budget)
                                all_good &= self.update_budget(budget)
                            all_good &= self.delete_budget()
                            self.budgetary_units[self._budgetary_unit_index].budgets.pop()
                        all_good &= self.delete_budgetary_unit()
        return all_good and got_budgets

    def delete_all_budgets(self):
        return self.delete_budgetary_units_by(lambda x: True)

    def inactivate_budgetary_unit(self, budgetary_unit_payload=None):
        if budgetary_unit_payload:
            self.budgetary_units.append(BudgetaryUnit(None, budgetary_unit_payload['budgetcode'], None, None))
        else:
            self.get_budgetary_unit()
            budgetary_unit_payload = self.response_body
        budgetary_unit_payload.pop('externalrefid', None)
        budgetary_unit_payload.pop('description', None)
        all_good = self.get_budgets()
        if all_good and budgetary_unit_payload is not None:
            budgets = self.response_body
            for budget in budgets:
                self.budgetary_units[self._budgetary_unit_index].budgets.append(BudgetPopo(budget['id'], None, None))
                if budget['status'] == 'Active':
                    budget['status'] = 'Inactive'
                    Budget._fix_budget_payload(budget)
                    budget.pop('externalrefid', None)
                    all_good &= self.update_budget(budget)
            budgetary_unit_payload['status'] = 'Inactive'
            all_good &= self.update_budgetary_unit(budgetary_unit_payload)
        return all_good

    def inactivate_budgetary_units_by(self, predicate):
        self._budgetary_unit_index = -1
        self._budget_index = -1
        all_good = self.get_budgetary_units(status='Active')
        while all_good and self.response_body:
            budgetary_units = self.response_body
            for budgetary_unit in budgetary_units:
                if budgetary_unit['status'] == 'Active' and predicate(budgetary_unit):
                    all_good &= self.inactivate_budgetary_unit(budgetary_unit)
            self.get_budgetary_units(status='Active')
        return all_good

    def inactivate_all_budgets(self):
        return self.inactivate_budgetary_units_by(lambda x: True)
