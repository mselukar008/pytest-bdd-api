from encryption import process_config
from requests import codes

from core import payload_helper
from utils.pre_seed_base import PreSeedBase


class CoreData(dict):
    def __init__(self, data: dict):
        super().__init__()
        self.update(data)

    def get_internal_context(self, context_tag_id: str) -> dict:
        for context in self['internal_contexts']:
            if context['type_id'] == context_tag_id:
                return context
        raise KeyError(f'{context_tag_id} not found in internal contexts')

    def get_external_context(self, context_tag_id: str) -> dict:
        for context in self['external_contexts']['types']:
            if context['type_id'] == context_tag_id:
                return context
        raise KeyError(f'{context_tag_id} not found in external contexts')

    def get_team(self, __id__: str) -> dict:
        for team in self['teams']:
            if team['__id__'] == __id__:
                return team
        raise KeyError(f'{__id__} not found in teams')

    def get_team_code(self, __id__: str) -> str:
        for team in self['teams']:
            if team['__id__'] == __id__:
                return team['id']
        raise KeyError(f'{__id__} not found in teams')

    def get_team_org(self, __id__: str, role: str = None) -> dict:
        for team in self['teams']:
            if team['__id__'] == __id__:
                if role:
                    for team_role in team['roles']:
                        if team_role['name'] == role:
                            return team_role['contexts'][0]['org']
                else:
                    return team['organization']
        raise KeyError(f'team org not found for: {__id__}, {role}')

    def get_team_context(self, __id__: str, role: str) -> dict:
        for team in self['teams']:
            if team['__id__'] == __id__:
                for team_role in team['roles']:
                    if team_role['name'] == role:
                        return {key: value[0] for key, value in team_role['contexts'][0].items()}
        raise KeyError(f'team context not found for: {__id__}, {role}')

    def get_user(self, __id__: str) -> str:
        return self.get_credentials(__id__)[0]

    def get_credentials(self, __id__: str) -> tuple:
        for user in self.get('users', []):
            if user['__id__'] == __id__:
                id_ = user['user_id'] if user.get('user_id') else user['id']  # todo: this is temporary until all systems at multi-tenancy
                return id_, user['api_key']
        for user in self.get('system_users', []):
            if user['__id__'] == __id__:
                return user['id'], user['api_key']
        raise KeyError(f'{__id__} not found in users or system_users')

    def get_hybrid_credentials(self, __id__: str) -> tuple:
        for user in self.get('users', []):
            if user['__id__'] == __id__:
                return user['user_id'], user['bearer_token']
        raise KeyError(f'{__id__} not found in users')

    def get_all_user_ids(self):
        ids = []
        for user in self['users']:
            ids.append(user['__id__'])
        return ids

    def get_provider_account_purpose(self, provider_code: str, team_code: str) -> str:
        for master in self['provider_accounts'][provider_code]:
            for credential_account in master["credential_accounts"]:
                if team_code in credential_account['context']['team']:
                    return credential_account['purpose']
            for asset in master["assets"]:
                for account in asset['credential_accounts']:
                    if team_code in account['context']['team']:
                        return account['purpose']
        raise KeyError(f'No provider account with this provider and team: {provider_code}, {team_code}')

    def get_provider_account_password_fields(self, provider_code: str, team_code: str) -> str:
        for master in self['provider_accounts'][provider_code]:
            for credential_account in master["credential_accounts"]:
                if team_code in credential_account['context']['team']:
                    return credential_account['password_fields']
            for asset in master["assets"]:
                for account in asset['credential_accounts']:
                    if team_code in account['context']['team']:
                        return account['password_fields']
        raise KeyError(f'No provider account with this provider and team: {provider_code}, {team_code}')

    def get_provider_master_account_ids(self, provider_code: str, team_code: str) -> str:
        for master in self['provider_accounts'][provider_code]:
            for credential_account in master["credential_accounts"]:
                if team_code in credential_account['context']['team']:
                    return master['master_ref_id'], credential_account['credential_ref_id']
        raise KeyError(f'No provider account with this provider and team: {provider_code}, {team_code}')

    def get_provider_asset_account_ids(self, provider_code: str, team_code: str) -> str:
        for master in self['provider_accounts'][provider_code]:
            for asset in master["assets"]:
                for account in asset['credential_accounts']:
                    if team_code in account['context']['team']:
                        return asset['asset_ref_id'], account['credential_ref_id']
        raise KeyError(f'No provider account with this provider and team: {provider_code}, {team_code}')

    def get_provider_account_names(self, provider_code: str, team_code: str) -> str:
        for master in self['provider_accounts'][provider_code]:
            for credential_account in master["credential_accounts"]:
                if team_code in credential_account['context']['team']:
                    return master['master_name'], credential_account['name']
            for asset in master["assets"]:
                for account in asset['credential_accounts']:
                    if team_code in account['context']['team']:
                        return asset['asset_name'], account['name']
        raise KeyError(f'No provider account with this provider and team: {provider_code}, {team_code}')

    def get_provider_asset_advanced_info(self, provider_code: str, team_code: str) -> str:
        for master in self['provider_accounts'][provider_code]:
            for asset in master["assets"]:
                for account in asset['credential_accounts']:
                    if team_code in account['context']['team']:
                        return asset['advanced_info']
        raise KeyError(f'No provider account with this provider and team: {provider_code}, {team_code}')

    def get_provider_password_fields(self, provider_code: str, team_code: str) -> dict:
        for master in self['provider_accounts'][provider_code]:
            for credential_account in master["credential_accounts"]:
                if team_code in credential_account['context']['team']:
                    return credential_account['password_fields']
            for asset in master["assets"]:
                for account in asset['credential_accounts']:
                    if team_code in account['context']['team']:
                        return account['password_fields']
        raise KeyError(f'No provider account with this provider and team: {provider_code}, {team_code}')


    


class CorePreSeed(PreSeedBase):
    keys = [
        'budgets',
        'external_contexts',
        'internal_contexts',
        'organizations',
        'provider_accounts',
        'service_providers',
        'setup_admin',
        'system_users',
        'teams',
        'users',
    ]
    def __init__(self, args, folder: str, logger=None, get_header_credentials: bool = False):
        super().__init__(args, folder, logger)
        self.get_header_credentials = get_header_credentials
        self.config = process_config(self.args.config, self.args.secret, decrypt=True) if self.args.config else None

    def create_data(self):
        return CoreData({})

    def decrypt(self, key: str, secret: str):
        self._do_encryption(key, secret, encrypt=False)

    def encrypt(self, key: str, secret: str):
        self._do_encryption(key, secret, encrypt=True)

    def _do_encryption(self, key: str, secret: str, encrypt: bool):
        helper = self._encryption_helper(secret, encrypt)
        if key == 'users' and 'users' in self.data:
            for user in self.data['users']:
                user['api_key'] = helper(user['api_key'])
                user['password'] = helper(user['password'])
                if 'bearer_token' in user:
                    user['bearer_token'] = helper(user['bearer_token'])
        elif key == 'system_users' and 'system_users' in self.data:
            for system_user in self.data['system_users']:
                system_user['api_key'] = helper(system_user['api_key'])
        elif key == 'provider_accounts' and 'provider_accounts' in self.data:
            for _, masters in self.data['provider_accounts'].items():
                for master in masters:
                    for credential in master['credential_accounts']:
                        for k, v in credential['password_fields'].items():
                            credential['password_fields'][k] = v if v and v.startswith('$config') else helper(v)
                    for asset in master['assets']:
                        for credential in asset['credential_accounts']:
                            for k, v in credential['password_fields'].items():
                                credential['password_fields'][k] = v if v and v.startswith('$config') else helper(v)

    def check_preconditions(self, entities) -> list:
        error_str = []
        setup_user = entities.Core.response_body['emails'][0] if entities.Core.response_body.get('emails') else entities.Core.response_body['userid']
        for team in self.data.get('teams', []):
            if setup_user in team['users']:
                error_str.append(f'This setup user ({setup_user}) cannot exist in teams.json')
        for user in self.data.get('users', []):
            if setup_user in user['emails']:
                error_str.append(f'This setup user ({setup_user}) cannot exist in users.json')
        for system_user in self.data.get('system_users', []):
            if setup_user == system_user['id']:
                error_str.append(f'This setup user ({setup_user}) cannot exist in system_users.json')
        return error_str

    def run_script(self, entities) -> list:
        self._create_organizations(entities)
        self._create_contexts(entities)
        self._create_setup_admin_team(entities)
        self._create_teams_with_roles(entities)
        self._create_users(entities)
        self._assign_users_to_teams(entities)
        self._create_service_providers(entities)
        self._create_provider_accounts(entities)
        self._create_budgets(entities)
        return self.error_list
    
    def run_idp_script(self,entities, idp) -> list:
        self._create_new_idp(entities, idp)
        return self.error_list

    def _create_organizations(self, entities):
        if 'organizations' in self.data:
            try:
                ids = [org['id'] for org in self.data['organizations']]
                names = [org['name'] for org in self.data['organizations']]
                payload = payload_helper.organization_builder(ids, names)
                if not entities.Core.create_or_update_organizations(payload):
                    self._log_error(entities.logger, 'Failed to create organizations')
            except:
                self._log_exception(entities.logger, 'Encountered an exception when creating contexts')

    def _create_contexts(self, entities):
        if 'internal_contexts' in self.data:
            try:
                contexts = self.data['internal_contexts']
                for context in contexts:
                    values = [payload_helper.context_value_builder(value['name'], value['id'], True, 'internal')
                              for value in context['type_values']]
                    all_good = entities.Core.delete_context_type(context['type_id'])
                    if all_good or entities.Core.status_code == codes.NOT_FOUND:
                        payload = payload_helper.create_contexts('internal', context['type_name'],
                                                                 context['type_id'], values, context['display_order'])
                        all_good = entities.Core.create_context_type(payload)
                        if not (all_good or entities.Core._already_created()):
                            self._log_error(entities.logger, f'Failed to create {payload["name"]} context')
                    else:
                        self._log_error(entities.logger, f'Failed to delete {context["type_id"]} context type')
            except:
                self._log_exception(entities.logger, 'Encountered an exception when creating internal contexts')

        if 'external_contexts' in self.data:
            try:
                # This key exists on some tenants and will cause an error if it exists
                entities.api_client.delete_config_value('current_encryption_id')

                if self._point_external_context_to_sample_adapter(entities):
                    contexts = self.data['external_contexts']
                    for context in contexts['types']:
                        payload = payload_helper.create_contexts('external', context['type_name'],
                                                                context['type_id'], [], context['display_order'])
                        if not (entities.Core.create_context_type(payload)
                                or entities.Core._already_created()):
                            self._log_error(entities.logger, f'Failed to create {payload["name"]} context')
                    context_values = {}
                    for type_ in contexts['types']:
                        context_values[type_['type_id']] = [
                            payload_helper.context_value_builder(value['name'], value['id'], value['status'], 'external')
                            for value in type_['type_values']]
                    payload = payload_helper.external_context_values(context_values, contexts['context_dependencies'],
                                                                    contexts['context_dependencies_values'])
                    if not entities.Core.load_external_context_values(payload):
                        self._log_error(entities.logger, 'Failed to load external context values')
            except:
                self._log_exception(entities.logger, 'Encountered an exception when creating external contexts')

    def _point_external_context_to_sample_adapter(self, entities) -> bool:
        ok = False
        try:
            payload = {
                "adapter_type": "context",
                "adapter_name": "ContextAdapter",
                "_adapter_url": "http://cb-core-sample-auth-agent:5000/iam_agent",
                "authservice_client_key": "string",
                "_uid": "string",
                "_adapterapikey": "string",
                "_gateway_host": "https://cb-core-auth-internal:4001",
                "connection_protocol": "http",
                "authservice_client_cert": "string",
                "adapter_ca_cert": "string",
                "is_mutual_auth": "False"
            }
            ok = entities.Core.set_external_context_adapter(payload)
            if not ok:
                self._log_error(entities.logger, 'Failed to point to sample adapter')
        except:
            self._log_exception(entities.logger, 'Encountered an exception when pointing external context to sample adapter')
        return ok

    def _create_setup_admin_team(self, entities):
        if 'setup_admin' in self.data:
            team = self.data['setup_admin']
            try:
                # Create teams without roles.
                payload = payload_helper.create_team(team['name'], team['id'], team['organization'], external_ref_id=team.get('external_ref_id'))
                if not entities.Core.create_or_update_team(payload):
                    self._log_error(entities.logger, f'Failed to create {payload["name"]} team')
                # Update teams wih roles.
                roles = payload_helper.roles_builder([role['name'] for role in team['roles']], [role['contexts'] for role in team['roles']])
                payload = payload_helper.create_team(team['name'], team['id'], team['organization'], roles, external_ref_id=team.get('external_ref_id'))
                if not entities.Core.update_team(team['id'], payload):
                    self._log_error(entities.logger, f'Failed to update {payload["name"]} team')
            except:
                self._log_exception(entities.logger, 'Encountered an exception when creating teams')

            try:
                if not entities.Core.assign_users_to_teams(
                    payload_helper.assign_user_to_team(team['id'], [entities.api_client.username])):
                    self._log_error(entities.logger, f'Failed to add {self.api_client.username} to team: {team["name"]}')
            except:
                self._log_exception(entities.logger, 'Encountered an exception when assigning users to teams')

    def _create_teams_with_roles(self, entities):
        if 'teams' in self.data:
            try:
                # Create teams without roles.
                for team in self.data['teams']:
                    payload = payload_helper.create_team(team['name'], team['id'], team['organization'], external_ref_id=team.get('external_ref_id'))
                    if not entities.Core.create_or_update_team(payload):
                        self._log_error(entities.logger, f'Failed to create {payload["name"]} team')
                # Update teams wih roles.
                for team in self.data['teams']:
                    roles = payload_helper.roles_builder([role['name'] for role in team['roles']], [role['contexts'] for role in team['roles']])
                    payload = payload_helper.create_team(team['name'], team['id'], team['organization'], roles, external_ref_id=team.get('external_ref_id'))
                    if not entities.Core.update_team(team['id'], payload):
                        self._log_error(entities.logger, f'Failed to update {payload["name"]} team')
            except:
                self._log_exception(entities.logger, 'Encountered an exception when creating teams')

    def _create_users(self, entities):
        if 'users' in self.data:
            try:
                for i, user in enumerate(self.data['users']):
                    payload = payload_helper.create_user(user['id'], user['first_name'], user['last_name'], emails=user['emails'])
                    if entities.Core.create_or_update_user(payload):
                        self.data['users'][i]['user_id'] = entities.Core.response_body['userid']
                    else:
                        self._log_error(entities.logger, 'Failed to create user: ' + user['id'])
            except:
                self._log_exception(entities.logger, 'Encountered an exception when creating users')
        if 'system_users' in self.data:
            self._set_system_key_flag(entities)
            try:
                for user in self.data['system_users']:
                    payload = payload_helper.create_system_user(user['id'], user['name'], user['roles'])
                    if not entities.Core.create_or_update_system_user(payload):
                        self._log_error(entities.logger, 'Failed to create system user: ' + user['id'])
            except:
                self._log_exception(entities.logger, 'Encountered an exception when creating system users')

    def _set_system_key_flag(self, entities):
        try:
            if not entities.Core.set_system_user_management(True):
                self._log_error(entities.logger, 'Failed to set system user management')
        except:
            self._log_exception(entities.logger, 'Encountered an exception when setting system user management')

    def _assign_users_to_teams(self, entities):
        if 'teams' in self.data:
            try:
                for team in self.data['teams']:
                    if not entities.Core.assign_users_to_teams(
                        payload_helper.assign_user_to_team(team['id'], self._get_users_ids(team['users']))):
                        self._log_error(entities.logger, 'Failed to add %s to team: %s' % (', '.join(team['users']), team['name']))
            except:
                self._log_exception(entities.logger, 'Encountered an exception when assigning users to teams')

    def _get_users_ids(self, users):
        user_ids = []
        if 'users' in self.data:
            for user in self.data['users']:
                if user['id'] in users:
                    user_ids.append(user['user_id'])
        if 'system_users' in self.data:
            for user in self.data['system_users']:
                if user['id'] in users:
                    user_ids.append(user['id'])
        return user_ids

    def _create_service_providers(self, entities):
        if 'service_providers' in self.data:
            try:
                for provide_code, service_provider_metadata in self.data['service_providers'].items():
                    result = entities.Core.create_or_update_service_provider(
                       service_provider_metadata)
                    if not result:
                        self._log_error(entities.logger, 
                            f'Failed to create service provider {provide_code}'
                        )
            except:
                self._log_exception(entities.logger, 'Encountered an exception when creating service providers')

    def _create_provider_accounts(self, entities):
        if 'provider_accounts' in self.data:
            try:
                for provide_code, master_accounts in self.data['provider_accounts'].items():
                    for master_account in master_accounts:
                        master_credentials, master_ref_id = [], ""
                        if master_account["master_name"]:
                            for each_master_credential in master_account['credential_accounts']:
                                master_credentials.append(payload_helper.account_credential_builder(
                                        each_master_credential['name'], each_master_credential['purpose'],
                                        each_master_credential['context'],
                                        self._parse_fields(each_master_credential['password_fields'], provide_code)
                                    ))
                            payload = payload_helper.account_builder(
                                master_account['master_name'], provide_code, is_master=True,
                                credentials=master_credentials,
                                advanced_info=self._parse_fields(master_account['advanced_info'], provide_code)
                            )
                            master_ref_id, cred_ids = entities.Core.create_or_patch_provider_account(payload)
                            if master_credentials:
                                if master_ref_id and cred_ids:
                                    master_account['master_ref_id'] = master_ref_id
                                    for each_master_credential in master_account['credential_accounts']:
                                        each_master_credential['credential_ref_id'] = cred_ids[each_master_credential['name']]
                                else:
                                    self._log_error(entities.logger, 
                                        f'Failed to create master provider account {master_account["master_name"]}')
                        for each_asset_account in master_account["assets"]:
                            credentials = []
                            for credential in each_asset_account['credential_accounts']:
                                credentials.append(payload_helper.account_credential_builder(
                                    credential['name'], credential['purpose'],
                                    credential['context'], self._parse_fields(credential['password_fields'], provide_code)
                                ))
                            payload = payload_helper.account_builder(
                                each_asset_account['asset_name'], provide_code, is_master=False,
                                credentials=credentials,
                                advanced_info=self._parse_fields(each_asset_account['advanced_info'], provide_code),
                                parent_account_id=master_ref_id
                            )
                            asset_id, cred_ids = entities.Core.create_or_patch_provider_account(payload)
                            if credentials:
                                if asset_id and cred_ids:
                                    each_asset_account['asset_ref_id'] = asset_id
                                    for each_master_credential in each_asset_account['credential_accounts']:
                                        each_master_credential['credential_ref_id'] = cred_ids[each_master_credential['name']]
                                else:
                                    self._log_error(entities.logger, 
                                        f'Failed to create asset provider account {each_asset_account["asset_name"]}'
                                    )
            except:
                self._log_exception(entities.logger, 'Encountered an exception when creating provider accounts')

    def _parse_fields(self, fields: dict, provider_code: str) -> dict:
        parsed_dict = {}
        for k, v in fields.items():
            if v == '$config':
                try:
                    parsed_dict[k] = self.config[provider_code][k]
                except KeyError:
                    parsed_dict[k] = self.config[provider_code][f'_{k}']
            elif isinstance(v, str) and v.startswith('$config.'):
                parsed_dict[k] = self.config[provider_code][v.replace('$config.', '')]
            else:
                parsed_dict[k] = v
        return parsed_dict

    def _create_budgets(self, entities):
        if 'budgets' in self.data:
            try:
                for budget_unit in self.data['budgets']:
                    budgetary_unit_payload = payload_helper.budgetary_unit_builder(budget_unit['term'], budget_unit['id'], budget_unit['name'], **budget_unit['context'])
                    if entities.Budget.create_or_update_budgetary_unit(budgetary_unit_payload):
                        for budget in budget_unit['budgets']:
                            budget_payload = payload_helper.budget_builder(total=budget['amount'], period=budget_unit['term'],
                                                                           soft_threshold_total=budget['soft_threshold']['amount'],
                                                                           hard_threshold_total=budget['hard_threshold']['amount'],
                                                                           soft_type=budget['soft_threshold']['type'],
                                                                           hard_type=budget['hard_threshold']['type'],
                                                                           name=budget['name'])
                            budget_payload['startPeriod'] = budget['start_period'] or budget_payload['startPeriod']
                            budget_payload['endPeriod'] = budget['end_period'] or budget_payload['endPeriod']
                            if not entities.Budget.create_or_update_budget(budget_payload):
                                self._log_error(entities.logger, f"Failed to create budget: {budget_payload['name']}")
                        # if budget_unit['bulk_budgets'] and budget_unit['bulk_budgets']['bulk_count'] > 0:
                        #     bulk_budget = budget_unit['bulk_budgets']
                        #     bulk_budget_payload = payload_helper.bulk_budget_builder(bulk_budget['amount'],
                        #                                                              budget_unit['term'],
                        #                                                              bulk_budget['bulk_count'],
                        #                                                              bulk_budget['soft_threshold']['amount'],
                        #                                                              bulk_budget['hard_threshold']['amount'],
                        #                                                              bulk_budget['soft_threshold']['type'],
                        #                                                              bulk_budget['hard_threshold']['type'])
                        #     if not (entities.Budget.create_bulk_budgets(bulk_budget_payload) or entities.Budget.status_code == codes.CONFLICT):
                        #         self._log_error(entities.logger, f"Failed to create bulk budgets")
                    else:
                        self._log_error(entities.logger, f"Failed to create budgetary unit: {budget_unit['name']}")
            except:
                self._log_exception(entities.logger, 'Encountered an exception when creating budgets')


    def _create_new_idp(self, entities,idp):
        try:
            entities.logger.info("Getting Bearer Token")
            bearer_token = entities.Core.get_bearer_token(user = self.args.user[0], apikey=self.args.apikey[0])
            if bearer_token is None:
                self._log_error(entities.logger, f"Failed to get Bearer Token")

            entities.logger.info(f"Getting {idp} idp payload")
            payload = payload_helper.get_idp_payload(idp)
            if payload  is None:
                self._log_error(entities.logger, f"Failed to payload for {idp} IdP")

            result = entities.Core.add_new_idp(payload,idp,bearer_token)
            if not result:
                self._log_error(entities.logger, f"Failed to create {idp} IdP")
            else:
                entities.logger.info(f"Succesfully created {idp} idp")
        except:
            self._log_exception(entities.logger,  f'Encountered an exception when creating the {idp} IdP')
                


