import copy
import json
import urllib

from utils.api_client_base import McmpApiClientCustom, AzureApiClientBase
from utils.api_client_base import Route


def _apikey_masker(response, mask):
    mask(response, "key")


def _accounts_masker(payload, mask):
    for credential in payload["account"]["credentials"]:
        _credential_masker(credential, mask)


def _credentials_masker(payload, mask):
    _credential_masker(payload["credentials"], mask)


def _credential_masker(credential, mask):
    for k, _ in credential["passwordFields"].items():
        mask(credential["passwordFields"], k)


class AzureApiClient(AzureApiClientBase):
    def get_bearer_token(self, tenant, form_data):
        self.temp_headers = {'Content-Type':'application/x-www-form-urlencoded'}
        return self.post_data(Route(f'{tenant}/oauth2/v2.0/token'), form_data)

    def get_application_details(self, bearer_token, application_id):
        self.temp_headers = {'Authorization':f'Bearer {bearer_token}'}
        return self.get(Route(f'v1.0/applications/{application_id}'))
    
    def set_application_identified_uris(self, bearer_token, application_id,payload):
        self.temp_headers = {'Authorization':f'Bearer {bearer_token}'}
        self.temp_headers = {'Content-Type':'application/json'}

        return self.patch(Route(f'v1.0/applications/{application_id}'),payload)
    
    def set_application_redirect_uris(self, bearer_token, application_id,payload):
        self.temp_headers = {'Authorization':f'Bearer {bearer_token}'}
        self.temp_headers = {'Content-Type':'application/json'}

        return self.patch(Route(f'v1.0/applications/{application_id}'),payload)


class CoreApiClient(McmpApiClientCustom):
    def get_bearer_token(self, api_key_name="cd_auto_key"):
        # This api uses the UI url
        self.temp_headers = {'Authorization': f'APIKEY {self.apikey}'}
        return self.post(Route("api/iam/v3/users/{userId}/apikeys/{apiKeyName}/bearertoken", {"userId": self.username, "apiKeyName": api_key_name}), {})

    def disable_bootstrap_mode(self):
        return self.get(Route("gateway/disableBootstrapMode"))

    def get_d2ops_agent(self):
        return self.get(Route("core/configuration/v1/configvalues/d2ops_agent_api"))

    def create_config_values(self, payload):
        return self.post(Route("core/configuration/v1/configvalues"), payload)

    def get_config_values(self, key):
        return self.get(Route(f"core/configuration/v1/configvalues/{key}"))

    def update_config_values(self, payload):
        return self.put(Route(f"core/configuration/v1/configvalues"), payload)

    def delete_config_value(self, key):
        return self.delete(Route(f"core/configuration/v1/configvalues/{key}"))

    def get_default_currency(self):
        return self.get(Route("core/currency/v2/defaultCurrency"))

    def lock_default_currency(self, currency_code):
        return self.put(
            Route(
                "core/currency/v2/defaultCurrency/{currency_code}",
                {"currency_code": currency_code},
            ),
            payload={"is_locked": True},
        )

    def get_supported_currencies(self):
        return self.get(Route("core/currency/v2/supportedCurrencies"))

    def get_currency_conversion_rates(self, _from, _to):
        return self.get(
            Route(
                "core/currency/v2/currencyConversionRates?{_from}&{_to}",
                {"_from": _from, "_to": _to},
            )
        )

    def create_currency_conversion_rate(self, payload):
        return self.post(Route("core/currency/v2/currencyConversionRates"), payload)

    def update_currency_conversion_rate(self, _id, payload):
        return self.put(
            Route("core/currency/v2/currencyConversionRates/{id}", {"id": _id}), payload
        )

    def delete_currency_conversion_rate(self, _id):
        return self.delete(
            Route("core/currency/v2/currencyConversionRates/{id}", {"id": _id})
        )

    def set_external_context_adapter(self, payload):
        return self.post(
            Route("authorization/bootstrap/v1/configurations/adapters"), payload
        )

    def set_authorization(self, payload):
        return self.post(Route("authorization/bootstrap/v1/configurations"), payload)

    def get_authorization(self):
        return self.get(Route("authorization/bootstrap/v1/configurations/authType"))

    def create_organizations(self, payload):
        return self.post(Route("core/authorization/v1/organizations"), payload)

    def update_organization(self, id_, payload):
        return self.patch(
            Route("core/authorization/v1/organizations/{id}", {"id": id_}), payload
        )

    def delete_organization(self, id_):
        return self.delete(
            Route("core/authorization/v1/organizations/{id}", {"id": id_})
        )

    def get_context_tag_types(self, business_function="CATALOG", level="BROWSE"):
        return self.get(
            Route(
                'authorization/v2/users/contexttagtypes',
                query_parameters={'permission': f'{{{{"businessfunction":"{business_function}","level":"{level}"}}}}'},
            )
        )

    def get_filtered_contexts(self, payload):
        return self.post(Route("authorization/v2/user/filteredcontexts"), payload)

    def create_context_type(self, payload):
        return self.post(Route("authorization/v2/contexts"), payload)

    def create_context_values(self, context_tag_id, payload):
        return self.post(
            Route(
                "authorization/v2/contexts/contextvalues/{context_tag_id}",
                {"context_tag_id": context_tag_id},
            ),
            payload,
        )

    def update_context_type(self, context_tag_id, payload):
        return self.put(
            Route(
                "authorization/v2/contexts/{context_tag_id}",
                {"context_tag_id": context_tag_id},
            ),
            payload,
        )

    def update_context_values(self, context_tag_id, payload):
        return self.put(
            Route(
                "authorization/v2/contexts/contextvalues/{context_tag_id}",
                {"context_tag_id": context_tag_id},
            ),
            payload,
        )

    def delete_context_type(self, context_tag_id):
        return self.delete(
            Route(
                "authorization/v2/contexts/{context_tag_id}",
                {"context_tag_id": context_tag_id},
            )
        )

    def delete_context_value(self, context_tag_id, context_tag_code):
        return self.delete(
            Route(
                "authorization/v2/contexts/contextvalues/{context_tag_id}/{context_tag_code}",
                {
                    "context_tag_id": context_tag_id,
                    "context_tag_code": context_tag_code,
                },
            )
        )

    def get_context(self, tag_code):
        return self.get(
            Route(
                "authorization/v2/contexts/org",
                query_parameters={"tagcode": tag_code},
            )
        )

    def get_contexts(self, exclude='true'):
        return self.get(Route("authorization/v2/contexts", query_parameters={'excludeorg': exclude}))

    def create_api_key(self, user_id, payload):
        return self.post(
            Route("authorization/v1/user/key/{userid}", {"userid": user_id}),
            payload,
            response_mask=_apikey_masker,
        )

    def update_api_key(self, user_id, payload):
        return self.put(
            Route("authorization/v1/user/key/{userid}", {"userid": user_id}),
            payload,
            response_mask=_apikey_masker,
        )

    def get_basic_info(self):
        return self.get(Route("authorization/v2/users/user/basicinfo"))

    def get_user(self, user_id):
        return self.get(
            Route("authorization/v2/users", query_parameters={"userid": user_id})
        )

    def get_users(self):
        return self.get(Route("authorization/v2/users"))

    def get_user_infos(
        self,
        usertype=None,
        start_offset=None,
        limit=None,
        search_value=None,
        search_properties=None,
        sortby=None,
        direction=None,
        exclude=None,
    ):
        return self.get(
            Route(
                "authorization/v2/userinfo",
                query_parameters={
                    "usertype": usertype,
                    "start_offset": start_offset,
                    "limit": limit,
                    "search_value": search_value,
                    "search_properties": search_properties,
                    "sortby": sortby,
                    "direction": direction,
                    "exclude": exclude,
                },
            )
        )

    def get_user_info(self, user_id):
        return self.get(
            Route("authorization/v2/userinfo/{user_id}", {"user_id": user_id})
        )

    def get_users_teams(self, user_id):
        return self.get(
            Route("authorization/v2/userteam/{user_id}", {"user_id": user_id})
        )

    def delete_user(self, user_id):
        return self.delete(
            Route("authorization/v2/userinfo/{user_id}", {"user_id": user_id})
        )

    def create_user(self, payload):
        return self.post(Route("authorization/v2/userinfo"), payload)

    def update_user(self, user_id, payload):
        return self.put(
            Route("authorization/v2/userinfo/{user_id}", {"user_id": user_id}), payload
        )

    def get_system_users_team(self, system_user_name):
        return self.get(Route("/authorization/v1/systemusers/{system_user_name}/teams", {"system_user_name": system_user_name}))

    def set_system_user_management(self, payload):
        return self.post(Route("authorization/v1/sysusermgmt"), payload)

    def create_system_user(self, payload):
        return self.post(Route("authorization/v1/systemusers"), payload)

    def update_system_user(self, user_id, payload):
        return self.put(
            Route("authorization/v1/systemusers/{user_id}", {"user_id": user_id}),
            payload,
        )

    def assign_users_to_teams(self, payload):
        return self.post(Route("authorization/v2/users/teams"), payload)

    def remove_users_to_teams(self, payload):
        return self.post(Route("authorization/v2/users/teams/remove"), payload)

    def get_teams(self, manage='True'):
        return self.get(Route("authorization/v3/teams", query_parameters={'manage': manage}))

    def get_team(self, team_code):
        return self.get(
            Route("authorization/v3/teams/{team_code}", {"team_code": team_code})
        )

    def create_team(self, payload):
        return self.post(Route("authorization/v3/teams"), payload)

    def update_team(self, team_code, payload):
        return self.put(
            Route("authorization/v3/teams/{team_code}", {"team_code": team_code}),
            payload,
        )

    def delete_team(self, team_code):
        return self.delete(
            Route("authorization/v2/teams/{team_code}", {"team_code": team_code})
        )

    def get_team_details(self, team_code):
        return self.get(
            Route("authorization/v2/users/{team_code}", {"team_code": team_code})
        )

    def create_role(self, payload):
        return self.post(Route("authorization/v2/roles"), payload)

    def update_role(self, role_name, payload):
        return self.put(
            Route("authorization/v2/roles/{role_name}", {"role_name": role_name}),
            payload,
        )

    def load_external_context_values(self, payload):
        return self.post(Route("iam_agent/authorization/context"), payload)

    def external_auth_create_users(self, payload):
        return self.post(Route("iam_agent/v2/authorization/upload/users"), payload)

    def external_auth_create_teams(self, payload):
        return self.post(Route("iam_agent/v2/authorization/teams"), payload)

    def get_vault(self):
        return self.get(
            Route(
                "cb-credential-service/api/v2.0/vault/configuration/name/HashiCorp-Vault"
            )
        )

    def create_service_provider_meta_data(self, payload):
        return self.post(
            Route("cb-credential-service/api/v2.0/metadata/serviceProviders"), payload
        )

    def create_service_provider(self, payload):
        return self.post(
            Route("cb-credential-service/api/v2.0/serviceProviders"), payload
        )

    def create_provider_account(self, payload):
        return self.post(
            Route("cb-credential-service/api/v2.0/accounts"), payload, _accounts_masker
        )

    def update_service_provider_meta_data(self, service_provider_type, payload):
        return self.put(
            Route(
                "cb-credential-service/api/v2.0/metadata/serviceProviders/{service_provider_type}",
                {"service_provider_type": service_provider_type},
            ),
            payload
        )

    def update_service_provider(self, service_provider_code, payload):
        return self.put(
            Route(
                "cb-credential-service/api/v2.0/serviceProviders/{service_provider_code}",
                {"service_provider_code": service_provider_code},
            ),
            payload
        )

    def update_provider_account(self, account_id, payload):
        return self.put(
            Route(
                "cb-credential-service/api/v2.0/accounts/{account_id}",
                {"account_id": account_id},
            ),
            payload,
            _accounts_masker,
        )

    def patch_asset_provider_account(self, account_id, payload):
        return self.patch(
            Route(
                "cb-credential-service/api/v2.0/accounts/{account_id}/basicAdvancedInfo",
                {"account_id": account_id},
            ),
            payload,
        )

    def patch_credential_provider_account(self, account_id, cred_id, payload):
        return self.patch(
            Route(
                "cb-credential-service/api/v2.0/accounts/{account_id}/credentials/{cred_id}",
                {"account_id": account_id, "cred_id": cred_id},
            ),
            payload,
            _credential_masker,
        )

    def add_credential_to_provider_account(self, account_id, payload):
        return self.post(
            Route(
                "cb-credential-service/api/v2.0/accounts/{account_id}/credentials",
                {"account_id": account_id},
            ),
            payload,
            _credentials_masker,
        )

    def delete_service_provider_code(self, provider_code):
        return self.delete(
            Route(
                "cb-credential-service/api/v2.0/serviceProviders/serviceProviderCode/{provider_code}",
                {"provider_code": provider_code},
            )
        )

    def delete_service_provider_meta_data(self, provider_code):
        return self.delete(
            Route(
                "cb-credential-service/api/v2.0/metadata/serviceProviders/{provider_code}",
                {"provider_code": provider_code},
            )
        )

    def delete_service_provider(self, provider_code):
        return self.delete(
            Route(
                "cb-credential-service/api/v2.0/serviceProviders/{provider_code}",
                {"provider_code": provider_code},
            )
        )

    def get_billing_accounts(self):
        return self.get(Route("cb-credential-service/api/v2.0/accounts/type/billing"))

    def get_provider_account(self, account_number_id):
        return self.get(
            Route(
                "cb-credential-service/api/v2.0/accounts/{account_number_id}",
                {"account_number_id": account_number_id},
            )
        )

    def delete_provider_account(self, account_number_id):
        return self.delete(
            Route(
                "cb-credential-service/api/v2.0/accounts/{account_number_id}",
                {"account_number_id": account_number_id},
            )
        )

    def credential_validator(self, payload):
        return self.post(
            Route("cb-credential-service/api/v2.0/credentialsValidator"), payload
        )

    def get_providers_accounts(self, provider_code, user_type, size=10, search_text=""):
        default_provider_key = "serviceProviderCode[]"
        provider_key = default_provider_key
        provider_code_ = provider_code
        if isinstance(provider_code, list):
            provider_code_ = provider_code[-1]
            for p in provider_code[:-1]:
                provider_key += f"={p}&{default_provider_key}"
        return self.get(
            Route(
                "cb-credential-service/api/v2.0/search",
                query_parameters={
                    "userType": user_type,
                    "manage": "true",
                    "size": size,
                    "searchText": search_text,
                    provider_key: provider_code_,
                },
            )
        )

    def get_budgetary_units(self, status=None, start_period=None, end_period=None, budgetperiod=None, expandbudget=None, context=None, sort_order=None, sort_by=None, limit=None, search_text=None):
        return self.get(Route("budgetmanagement/v1/budgetaryunits",
                              query_parameters={'status': status, 'start_period': start_period, 'end_period': end_period, 'budgetperiod': budgetperiod, 'expandbudget': expandbudget, 'context': context, 'sort_order': sort_order, 'sort_by': sort_by, 'limit': limit, 'search_text': search_text}))

    def get_budgetary_unit(self, budgetary_unit_id):
        return self.get(
            Route(
                "budgetmanagement/v1/budgetaryunits/{budgetary_unit_id}",
                {"budgetary_unit_id": budgetary_unit_id},
            )
        )

    def get_budget(self, budget_code, budget_id, filter_=None):
        return self.get(
            Route(
                "budgetmanagement/v1/{budget_code}/budget/{budget_id}",
                {"budget_code": budget_code, "budget_id": budget_id},
                query_parameters={'filter': urllib.parse.quote(filter_) if filter_ else None}
            )
        )

    def get_budgets(self, budget_code, search_text=None):
        return self.get(
            Route(
                "budgetmanagement/v1/{budget_code}/budget", {"budget_code": budget_code},
                query_parameters={'search_text': search_text}
            )
        )

    def bulk_activate_or_inactivate_budgets(self, budget_code, payload):
        return self.patch(
            Route(
                "budgetmanagement/v1/{budget_code}/budget/batchModify",
                {"budget_code": budget_code},
            ),
            payload,
        )

    def bulk_delete_budgets(self, budget_code, payload):
        return self.post(
            Route(
                "budgetmanagement/v1/{budget_code}/budget/batchDelete",
                {"budget_code": budget_code},
            ),
            payload,
        )

    def bulk_delete_budgetary_units(self, payload):
        return self.post(
            Route("budgetmanagement/v1/budgetaryunits/batchDelete"), payload
        )

    def get_budget_audits(self, budget_code, budget_id, sort_order=None, sort_by=None, limit=None, search_text=None, offset=None):
        return self.get(
            Route(
                "budgetmanagement/v1/{budget_code}/budget/{budget_id}/audits",
                {"budget_code": budget_code, "budget_id": budget_id},
                query_parameters={'sort_order': sort_order, 'sort_by': sort_by, 'limit': limit,
                                  'search_text': search_text, "offset": offset}
            )
        )

    def get_audit_logs(
        self,
        page=1,
        limit=100,
        sort_by="initiatedDate",
        sort="desc",
        start_date=None,
        end_date=None,
        message_type="",
        component="",
        sub_component="",
        user_id="",
        team_id="",
        search_type=None,
    ):
        return self.get(
            Route(
                "core/audit/api/v2.1/logs",
                query_parameters={
                    "page": page,
                    "limit": limit,
                    "sortBy": sort_by,
                    "sort": sort,
                    "startDate": start_date,
                    "endDate": end_date,
                    "messageType": [message_type],
                    "component": [component],
                    "subcomponent": [sub_component],
                    "userId": [user_id],
                    "teamId": [team_id],
                    "searchType": search_type,
                },
            )
        )

    def get_audit_logs_v3(
        self,
        page=1,
        limit=100,
        sort_by="initiatedDate",
        sort="desc",
        start_date=None,
        end_date=None,
        message_type=None,
        component=None,
        sub_component=None,
        user_id=None,
        team_id=None,
        resource_id=None,
        resource_name=None,
    ):
        query_parameters = {
            "page": page,
            "limit": limit,
            "sortBy": sort_by,
            "sort": sort,
            "startDate": start_date,
            "endDate": end_date,
            "messageType": message_type,
            "component": component,
            "subcomponent": sub_component,
            "userId": user_id,
            "teamId": team_id,
            "resourceId": resource_id,
            "resourceName": resource_name,
        }
        return self.get(
            Route(
                "core/audit/v3/logs",
                query_parameters=query_parameters,
            )
        )

    def get_audit_log_message(self, audit_id):
        return self.get(Route(f"core/audit/api/v2.1/messages/{audit_id}"))

    def get_budgetary_terms(self):
        return self.get(Route("budgetmanagement/v1/terms"))

    def get_budget_units_budget(self, budget_code):
        return self.get(
            Route(
                "budgetmanagement/v1/{budget_code}/budget", {"budget_code": budget_code}
            )
        )

    def create_budgetary_unit(self, payload):
        return self.post(Route("budgetmanagement/v1/budgetaryunits"), payload)

    def update_budgetary_unit(self, budget_code, paylaod):
        return self.put(
            Route(
                "budgetmanagement/v1/budgetaryunits/{budget_code}",
                {"budget_code": budget_code},
            ),
            paylaod,
        )

    def create_budget(self, budget_code, payload):
        return self.post(
            Route(
                "budgetmanagement/v1/{budget_code}/budget", {"budget_code": budget_code}
            ),
            payload,
        )

    def bulk_create_budgets(self, budget_code, payload):
        return self.post(
            Route(
                "budgetmanagement/v1/{budget_code}/budget/batchCreate",
                {"budget_code": budget_code},
            ),
            payload,
        )

    def update_budget(self, budget_code, id, payload):
        return self.put(
            Route(
                "budgetmanagement/v1/{budget_code}/budget/{id}",
                {"budget_code": budget_code, "id": id},
            ),
            payload,
        )

    def delete_budget(self, budget_code, id):
        return self.delete(
            Route(
                "budgetmanagement/v1/{budget_code}/budget/{id}",
                {"budget_code": budget_code, "id": id},
            )
        )

    def delete_budgetary_unit(self, budget_code):
        return self.delete(
            Route(
                "budgetmanagement/v1/budgetaryunits/{budget_code}",
                {"budget_code": budget_code},
            )
        )

    def commit_budget(self, payload):
        return self.post(Route("budgets/v1/budget"), payload)


    def check_commit_budget(self, budget_payload, action="check"):
        payload = urllib.parse.quote(json.dumps(budget_payload))
        return self.get(
            Route("budgets/v1/budget",
                  query_parameters={
                      "action": action,
                      "budget_payload": payload,
                    }
                  )
        )


    def patch_monthly_spend_quota(self, budgetary_unit_code, payload, budget_id):
        return self.patch(
            Route(
                "budgetmanagement/v1/{budgetary_unit_code}/budget/{budget_id}/monthlySpendQuota".format(
                    budgetary_unit_code=budgetary_unit_code, budget_id=budget_id
                )
            ),
            payload,
        )

    def pricing_create_ratecard(self, payload):
        return self.post(Route("ratecard/ratecards"), payload)

    def pricing_update_ratecard(self, rc_id, payload, action=None):
        return self.patch(
            Route(
                "ratecard/ratecards/{rc_id}",
                parameters={"rc_id": rc_id},
                query_parameters={"action": action},
            ),
            payload,
        )

    def pricing_replace_ratecard(self, rc_id, payload):
        return self.put(
            Route("ratecard/ratecards/{rc_id}", parameters={"rc_id": rc_id}), payload
        )

    def pricing_delete_ratecard(self, rc_id):
        return self.delete(
            Route("ratecard/ratecards/{rc_id}", parameters={"rc_id": rc_id})
        )

    def pricing_get_ratecard(self, rc_id):
        return self.get(
            Route("ratecard/ratecards/{rc_id}", parameters={"rc_id": rc_id})
        )

    def pricing_get_all_ratecards(
        self, offset=None, limit=None, sort_order=None, sort_by=None
    ):
        self.temp_headers = copy.deepcopy(self._headers)
        self.temp_headers["Accept-Language"] = "simple"
        return self.get(
            Route(
                "ratecard/ratecards",
                query_parameters={
                    "offset": offset,
                    "limit": limit,
                    "sort_order": sort_order,
                    "sort_by": sort_by,
                },
            )
        )

    def pricing_get_applicable_for_ratecards(
        self, payload, offset=None, limit=None, sort_order=None, sort_by=None
    ):
        self.temp_headers = copy.deepcopy(self._headers)
        self.temp_headers["Accept-Language"] = "simple"
        return self.post(
            Route(
                "ratecard/ratecards/applicablefor",
                query_parameters={
                    "offset": offset,
                    "limit": limit,
                    "sort_order": sort_order,
                    "sort_by": sort_by,
                },
            ),
            payload,
        )

    def pricing_create_client(self, payload):
        return self.post(Route("ratecard/clients"), payload)

    def pricing_get_all_clients(
        self, offset=None, limit=None, sort_by=None, sort_order=None
    ):
        self.temp_headers = copy.deepcopy(self._headers)
        self.temp_headers["Accept-Language"] = "simple"
        return self.get(
            Route(
                "ratecard/clients",
                query_parameters={
                    "offset": offset,
                    "limit": limit,
                    "sort_order": sort_order,
                    "sort_by": sort_by,
                },
            )
        )

    def pricing_get_client(self, client_id):
        return self.get(Route("ratecard/clients/{client_id}", {"client_id": client_id}))

    def pricing_delete_client(self, client_id):
        return self.delete(
            Route("ratecard/clients/{client_id}", {"client_id": client_id})
        )

    def pricing_update_client(self, client_id, payload):
        return self.put(
            Route("ratecard/clients/{client_id}", parameters={"client_id": client_id}),
            payload,
        )

    def pricing_patch_client(self, client_id, payload, action=None):
        return self.patch(
            Route(
                "ratecard/clients/{client_id}",
                parameters={"client_id": client_id},
                query_parameters={"action": action},
            ),
            payload,
        )

    def pricing_get_client_data(self, client_id):
        return self.get(
            Route("ratecard/clients/{client_id}/data", {"client_id": client_id})
        )

    def pricing_execute_ratecard(
        self, rc_id: str, payload: dict, plan_id=None, group_id=None
    ):
        parameters = {"rc_id": rc_id}
        url = "ratecard/ratecards/{rc_id}/execute"
        if plan_id is not None:
            parameters["plan_id"] = plan_id
            url += "/plan/{plan_id}"
            if group_id is not None:
                parameters["group_id"] = group_id
                url += "/group/{group_id}"
        return self.post(Route(url, parameters=parameters), payload)

    def pricing_get_ratecard_ui(self, rc_id):
        return self.get(Route("ratecard/ui/{rc_id}", {"rc_id": rc_id}))

    def pricing_get_ratecard_ui_variables(self, rc_id, plan_id, group_id):
        return self.get(
            Route(
                "ratecard/ui/{rc_id}/plan/{plan_id}/group/{group_id}/variables",
                {"rc_id": rc_id, "plan_id": plan_id, "group_id": group_id},
            )
        )

    def pricing_get_ratecard_ui_item(self, rc_id, plan_id, group_id, item_id):
        return self.get(
            Route(
                "ratecard/ui/{rc_id}/plan/{plan_id}/group/{group_id}/item/{item_id}",
                {
                    "rc_id": rc_id,
                    "plan_id": plan_id,
                    "group_id": group_id,
                    "item_id": item_id,
                },
            )
        )

    def pricing_get_all_operations(self):
        return self.get(Route("ratecard/operations"))

    def pricing_get_operation(self, data_type: str):
        return self.get(
            Route(
                "ratecard/operations/{data_type}", parameters={"data_type": data_type}
            )
        )

    def get_api_swagger_apps(self):
        return self.get(Route("cb-core-swagger/v1/applications"))

    def get_api_swagger_services(self, service, sub_service):
        return self.get(
            Route(f"cb-core-swagger/v1/applications/{service}/services/{sub_service}")
        )

    def create_service_metadata(self, payload):
        return self.post(Route("somd/api/v1/serviceOfferingMetadata"), payload)

    def get_service_metadata(
        self,
        service_metadata_id=None,
        categories=None,
        provisioners=None,
        regions=None,
        operationgroup=None,
        sort=None,
        fields=None,
        offset=None,
        limit=None,
    ):
        return self.get(
            Route(
                "somd/api/v1/serviceOfferingMetadata",
                query_parameters={
                    "serviceOfferingMetadataId": service_metadata_id,
                    "categories": None,
                    "provisioners": None,
                    "regions": None,
                    "operationgroup": None,
                    "sort": sort,
                    "fields": None,
                    "offset": offset,
                    "limit": limit,
                },
            )
        )

    def get_service_metadata_by_id(self, service_metadata_id):
        return self.get(
            Route(
                "somd/api/v1/serviceOfferingMetadata/{serviceOfferingMetadataId}",
                parameters={"serviceOfferingMetadataId": service_metadata_id},
            )
        )

    def patch_service_metadata(self, service_metadata_id, payload):
        return self.patch(
            Route(
                "somd/api/v1/serviceOfferingMetadata/{serviceOfferingMetadataId}",
                parameters={"serviceOfferingMetadataId": service_metadata_id},
            ),
            payload,
        )

    def delete_service_metadata(self, service_metadata_id):
        return self.delete(
            Route(
                "somd/api/v1/serviceOfferingMetadata/{serviceOfferingMetadataId}",
                parameters={"serviceOfferingMetadataId": service_metadata_id},
            )
        )

    def create_attibute_group(self, payload):
        return self.post(Route("somd/api/v1/attributeGroup/schema"), payload)

    def get_attibute_group(
        self,
        attributeGroupId=None,
        attributeGroupName=None,
        sort=None,
        fields=None,
        offset=None,
        limit=None,
    ):
        return self.get(
            Route(
                "somd/api/v1/attributeGroup/schema",
                query_parameters={
                    "attributeGroupId": attributeGroupId,
                    "attributeGroupName": attributeGroupName,
                    "sort": sort,
                    "fields": fields,
                    "offset": offset,
                    "limit": limit,
                },
            )
        )

    def get_attibute_group_by_id(self, attibute_group_id):
        return self.get(
            Route(
                "somd/api/v1/attributeGroup/schema/{attributeGroupId}",
                parameters={"attributeGroupId": attibute_group_id},
            )
        )

    def patch_attibute_group(self, attibute_group_id, payload):
        return self.patch(
            Route(
                "somd/api/v1/attributeGroup/schema/{attributeGroupId}",
                parameters={"attributeGroupId": attibute_group_id},
            ),
            payload,
        )

    def delete_attibute_group(self, attibute_group_id):
        return self.delete(
            Route(
                "somd/api/v1/attributeGroup/schema/{attributeGroupId}",
                parameters={"attributeGroupId": attibute_group_id},
            )
        )

    def create_attibute_group_doc(self, attibute_group_id, payload):
        return self.post(
            Route(
                "somd/api/v1/attributeGroup/{attributeGroupId}/doc",
                parameters={"attributeGroupId": attibute_group_id},
            ),
            payload,
        )

    def get_attibute_group_doc(
        self,
        attibute_group_id,
        attributeIdValue=None,
        sort=None,
        fields=None,
        offset=None,
        limit=None,
    ):
        return self.get(
            Route(
                "somd/api/v1/attributeGroup/{attributeGroupId}/doc",
                parameters={"attributeGroupId": attibute_group_id},
                query_parameters={
                    "attributeIdValue": attributeIdValue,
                    "sort": sort,
                    "fields": fields,
                    "offset": offset,
                    "limit": limit,
                },
            )
        )

    def get_attibute_group_doc_by_id(self, attibute_group_id, doc_id):
        return self.get(
            Route(
                "somd/api/v1/attributeGroup/{attributeGroupId}/doc/{docId}",
                parameters={"attributeGroupId": attibute_group_id, "docId": doc_id},
            )
        )

    def patch_attibute_group_doc(self, attibute_group_id, doc_id, payload):
        return self.patch(
            Route(
                "somd/api/v1/attributeGroup/{attributeGroupId}/doc/{docId}",
                parameters={"attributeGroupId": attibute_group_id, "docId": doc_id},
            ),
            payload,
        )

    def delete_attibute_group_doc(self, attibute_group_id, doc_id):
        return self.delete(
            Route(
                "somd/api/v1/attributeGroup/{attributeGroupId}/doc/{docId}",
                parameters={"attributeGroupId": attibute_group_id, "docId": doc_id},
            )
        )

    def create_job_definition(self, payload):
        return self.post(Route("core/jobmanagement/v1/jobdefinitions"), payload)

    def get_job_definition(
        self,
        start_offset=None,
        limit=None,
        run_status=None,
        status=None,
        icb_application=None,
        search_string=None,
    ):
        return self.get(
            Route(
                "core/jobmanagement/v1/jobdefinitions",
                query_parameters={
                    "start_offset": start_offset,
                    "limit": limit,
                    "run_status": run_status,
                    "status": status,
                    "icb_application": icb_application,
                    "search_string": search_string,
                },
            )
        )

    def get_job_definition_by_id(self, job_definition_id, icb_application):
        return self.get(
            Route(
                "core/jobmanagement/v1/jobdefinitions/job_definition/{job_definition_id}/icb_application/{icb_application}",
                parameters={
                    "job_definition_id": job_definition_id,
                    "icb_application": icb_application,
                },
            )
        )

    def patch_job_definition(self, job_definition_id, icb_application, payload):
        return self.patch(
            Route(
                "core/jobmanagement/v1/jobdefinitions/job_definition/{job_definition_id}/icb_application/{icb_application}",
                parameters={
                    "job_definition_id": job_definition_id,
                    "icb_application": icb_application,
                },
            ),
            payload,
        )

    def delete_job_definition(self, job_definition_id, icb_application):
        return self.delete(
            Route(
                "core/jobmanagement/v1/jobdefinitions/job_definition/{job_definition_id}/icb_application/{icb_application}",
                parameters={
                    "job_definition_id": job_definition_id,
                    "icb_application": icb_application,
                },
            )
        )

    def get_job_instance(self, job_definition_id, icb_application):
        return self.get(
            Route(
                "core/jobmanagement/v1/jobinstances/job_definition/{job_definition_id}/icb_application/{icb_application}",
                parameters={
                    "job_definition_id": job_definition_id,
                    "icb_application": icb_application,
                },
            )
        )

    def delete_job_instance(self, job_definition_id, icb_application):
        return self.delete(
            Route(
                "core/jobmanagement/v1/jobinstances/job_definition/{job_definition_id}/icb_application/{icb_application}",
                parameters={
                    "job_definition_id": job_definition_id,
                    "icb_application": icb_application,
                },
            )
        )

    def patch_job_instance(self, job_definition_id, icb_application, action, payload):
        return self.patch(
            Route(
                "core/jobmanagement/v1/jobinstances/job_definition/{job_definition_id}/icb_application/{icb_application}/action/{action}",
                parameters={
                    "job_definition_id": job_definition_id,
                    "icb_application": icb_application,
                    "action": action,
                },
            ),
            payload,
        )

    def create_pricing_policy(self, duplicate_policy, payload):
        return self.post(
            Route(
                "common-pricing/policy/v1/pricingPolicy",
                query_parameters={"duplicatePolicy": duplicate_policy},
            ),
            payload,
        )

    def get_all_pricing_policies(
        self,
        id=None,
        name=None,
        sort=None,
        search=None,
        status=None,
        offset=None,
        limit=None,
    ):
        return self.get(
            Route(
                "common-pricing/policy/v1/pricingPolicy",
                query_parameters={
                    "id": id,
                    "name": name,
                    "search": search,
                    "status": status,
                    "offset": offset,
                    "limit": limit,
                },
            )
        )

    def get_pricing_policy(self, id):
        return self.get(
            Route("common-pricing/policy/v1/pricingPolicy/{id}", parameters={"id": id})
        )

    def delete_pricing_policy(self, id):
        return self.delete(
            Route("common-pricing/policy/v1/pricingPolicy/{id}", parameters={"id": id})
        )

    def patch_pricing_policy(self, id, payload):
        return self.patch(
            Route("common-pricing/policy/v1/pricingPolicy/{id}", parameters={"id": id}),
            payload,
        )

    def export_pricing_policies(self, payload):
        return self.post(
            Route("common-pricing/policy/v1/pricingPolicy/export"), payload
        )

    def import_pricing_policies(self, payload):
        return self.post(
            Route("common-pricing/policy/v1/pricingPolicy/import"), payload
        )

    def execute_pricing_policies(self, payload, showDetails=True):
        return self.post(
            Route(
                "common-pricing/policy/v1/pricingPolicy/execute",
                query_parameters={
                    "showDetails": showDetails,
                },
            ),
            payload,
        )

    def query_service_query(self, payload):
        return self.post(Route("query-service/query"), payload)

    def create_register_endpoint(self, payload):
        return self.post(Route("query-service/register/graphql/endpoint"), payload)

    def get_registered_endpoints(
        self,
        icb_application=None,
        application_name=None,
        schema_name=None,
        projection=None, #Values of field names to return in results. Use following field names with comma seprated. "id,icb_application,application_name,schema_name,schema_description, end_point_url,createdBy,createdAt,updatedBy,updatedAt"
        limit=None,
        offset=None,
    ):
        return self.get(
            Route(
                "query-service/register/graphql/endpoint",
                query_parameters={
                    "icb_application": icb_application,
                    "application_name": application_name,
                    "schema_name": schema_name,
                    "projection": projection,
                    "limit": limit,
                    "offset": offset,

                },
            )
        )

    def get_registered_endpoint_by_id(self, id):
        return self.get(
            Route("query-service/register/graphql/endpoint/{id}", parameters={"id": id})
        )

    def put_registered_endpoint_by_id(self, id, payload):
        return self.put(
            Route("query-service/register/graphql/endpoint/{id}", parameters={"id": id}), payload
        )

    def delete_registered_endpoint_by_id(self, id):
        return self.delete(
            Route("query-service/register/graphql/endpoint/{id}", parameters={"id": id})
        )

    def get_health_probe_endpoint(self):
        return self.get(
            Route("/query-service/health")
        )

    def reporting_services_create_template(self, payload):
        return self.post(Route("reporting-service/reportTemplates"), payload)

    def reporting_services_get_template(self, id=None, name=None, type=None, url=None):
        return self.get(
            Route(
                "reporting-service/reportTemplates",
                query_parameters={
                    "id": id,
                    "name": name,
                    "type": type,
                    "url": url,
                },
            )
        )

    def reporting_services_delete_template(self, id=None, name=None, temptype=None, chartType=None, url=None):
        return self.delete(
            Route(
                "reporting-service/reportTemplates",
                query_parameters={
                    "id": id,
                    "name": name,
                    "type": temptype,
                    "chartType": chartType,
                    "url": url,
                },
            )
        )

    def reporting_services_get_templates(self, id=None, name=None, temp_type=None, url=None):
        return self.get(
            Route(
                "reporting-service/reportTemplates",
                query_parameters={
                    "id": id,
                    "name": name,
                    "type": temp_type,
                    "url": url,
                },
            )
        )

    def reporting_services_get_latest_report(self, id):
        return self.get(
            Route("/reporting-service/templates/{id}/download-latest", parameters={"id": id})
        )

    def reporting_services_generate_report(self, id, payload={}):
        return self.post(
            Route("reporting-service/templates/{id}/generate", parameters={"id": id}), payload=payload
        )

    def reporting_services_get_report(self, id=None):
        return self.get(
            Route(
                "reporting-service/reports/{id}",
                parameters={"id": id},
            )
        )

    def reporting_services_get_reports(self, search=None):
        return self.get(
            Route(
                "reporting-service/reports",
                query_parameters={"search": search},
            )
        )

    def reporting_services_delete_report(self, id):
        return self.delete(
            Route("reporting-service/reports/{id}", parameters={"id": id})
        )


    def create_budget_policy(self, payload):
        return self.post(
            Route("budgetpolicymanagement/v1/budgetpolicies"), payload
        )

    def update_budget_policy(self, budgetpolicyid, payload):
        return self.patch(
            Route(
                "/budgetpolicymanagement/v1/budgetpolicies/{budgetpolicyid}",
                {"budgetpolicyid": budgetpolicyid},
            ),
            payload
        )

    def get_budget_policy(
        self,
        status=None, #status eg. Active/Draft
        search_text=None, #Add strings to be searched
        sort_order=None, #asc or desc defaults to asc
        sort_by=None, #Sorting based on one of the following fields ['name', 'status', 'start_date_time', 'end_date_time']
        limit=None, #The number of records on the page. Default is set to 500.
        offset=None, #The first record of the page. Default is set to 0.


    ):
        return self.get(
            Route(
                "/budgetpolicymanagement/v1/budgetpolicies",
                query_parameters={
                    "status": status,
                    "search_text": search_text,
                    "sort_order": sort_order,
                    "sort_by": sort_by,
                    "limit": limit,
                    "offset": offset,

                },
            )
        )


    def get_budget_policy_by_id(self, policy_id):
        return self.get(
            Route(
                "/budgetpolicymanagement/v1/budgetpolicies/{policy_id}",
                {"policy_id": policy_id},
            )
        )

    def get_budgetary_unit_of_budget_policy_using_id(self, policy_id):
        return self.get(
            Route(
                "/budgetpolicymanagement/v1/budgetpolicies/{budgetpolicyid}/budgetaryunits",
                {"budgetpolicyid": policy_id},
            )
        )

    def delete_budget_policy(self, budgetpolicyid):
        return self.delete(
            Route(
                "/budgetpolicymanagement/v1/budgetpolicies/{budgetpolicyid}",
                {"budgetpolicyid": budgetpolicyid},
            )
        )

    def _enable_featureflag(self, payload):
        return self.post(
            Route("core/featureflagmanagement/v1/featureflag"),payload
        )
    def create_idp(self, payload, bearer_token):
        self.temp_headers = {'Authorization': f'Bearer  {bearer_token}'}
        return self.post(
            Route("/api/iam/v4/identityproviders"), payload
        )
