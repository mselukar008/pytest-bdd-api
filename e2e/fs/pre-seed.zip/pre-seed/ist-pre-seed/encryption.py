#!/usr/bin/env python3
from configparser import ConfigParser
import os

from utils import encryption


def process_text(text: str, secret: str, decrypt: bool) -> str:
    if decrypt:
        text = encryption.decrypt(text, secret)
    else:
        text = encryption.encrypt(text, secret)
    return text


def process_config(file_path: str, secret: str, decrypt: bool, save: bool = False) -> ConfigParser:
    config = ConfigParser()
    config.optionxform = str
    config.read(file_path)
    for section in config.sections():
        for k, v in config[section].items():
            if k.startswith('_'):
                config[section][k] = process_text(v, secret, decrypt)
    if save:
        with open(file_path, mode='w') as f:
            config.write(f)
    return config


def main(args) -> str:
    if args.text:
        text = process_text(args.text, args.secret, args.decrypt)
    elif args.config:
        process_config(args.config, args.secret, args.decrypt, save=True)
        text = f'{args.config} {"decrypted" if args.decrypt else "encrypted"}'
    return text


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--text', help='The plaintext to be encrypted/decrypted')
    parser.add_argument('--config', help='The .conf cred file to be encrypted/decrypted')
    parser.add_argument('--secret', default=os.getenv('MCMP_API_AUTOMATION_SECRET'), help='Secret key to be used for encryption')
    parser.add_argument('-d', '--decrypt', action='store_true', help='To decrypt')
    print(main(parser.parse_args()))
