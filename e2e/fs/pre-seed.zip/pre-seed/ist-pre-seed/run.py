#!/usr/bin/env python3
import os

from utils import create_logger
from utils.api_client_base import Authorization
from aiops.entities import Entities as AiOpsEntities
from aiops.pre_seed import AiOpsPreSeed
from core.entities import Entities as CoreEntities
from core.pre_seed import CorePreSeed
from ecam.entities import Entities as ECamEntities
from ecam.pre_seed import ECamPreSeed
from marketplace.entities import Entities as MarketplaceEntities
from marketplace.pre_seed import MarketplacePreSeed


def main(args) -> int:
    logger = create_logger('pre_seed')
    errors = []
    for i, host in enumerate(args.host):
        entities = CoreEntities.create_instance(host, args.user[i], args.apikey[i], logger, args.authorization)
        errors += CorePreSeed(args, args.path[i], logger).run_script(entities)
        entities = AiOpsEntities.create_instance(host, args.user[i], args.apikey[i], logger, args.authorization, None, args.elastic_host)
        errors += AiOpsPreSeed(args, args.path[i], logger).run_script(entities)
        entities = ECamEntities.create_instance(host, args.user[i], args.apikey[i], logger, args.authorization)
        errors += ECamPreSeed(args, args.path[i], logger).run_script(entities)
        entities = MarketplaceEntities.create_instance(host, args.user[i], args.apikey[i], logger, args.authorization)
        errors += MarketplacePreSeed(args, args.path[i], logger).run_script(entities)
    if errors:
        exit_code = 1
        logger.error(errors)
    else:
        exit_code = 0
    return exit_code


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--host', nargs='*', required=True, help='URL path for api calls')
    parser.add_argument('--user', nargs='*', required=True, help='Admin user id')
    parser.add_argument('--apikey', nargs='*', required=True, help='Admin apikey')
    parser.add_argument('--path', nargs='*', required=True, help='pre-seed folder path(s)')
    parser.add_argument('--config', help='The .conf cred file to use')
    parser.add_argument('--elastic-host', help="The tenant's elastic URL path for api calls")
    parser.add_argument('--elastic-data-dump', help="The file path of the static data dump")
    parser.add_argument('--authorization', choices=[Authorization.INTERNAL, Authorization.HYBRID], default=Authorization.INTERNAL, help='The authorization mode')
    parser.add_argument('--secret', default=os.getenv('MCMP_API_AUTOMATION_SECRET'),
                        help='Symmetric key used to decrypt the pre seed file')
    exit(main(parser.parse_args()))
