import os
from core.entities import Entities as CoreEntities
from core.pre_seed import CorePreSeed
from utils.azure_setup import AzureSetup
from utils import create_logger


def main(args):
    logger = create_logger('hybrid_tenant')
    errors = []

    for i, host in enumerate(args.host):
        entities = CoreEntities.create_instance(host, args.user[i], args.apikey[i], logger, 'default')
        errors += CorePreSeed(args,"pre_seeds/e2e_marketplace_default", logger).run_idp_script(entities,args.idp[i])
        entities = CoreEntities.create_azure_instance("https://login.microsoftonline.com/",logger)
        bearer_token = AzureSetup(args, logger)._get_bearer_token(entities)
        if not bearer_token:
             errors.append("Failed to get Bearer Token for Azure")
             break
        entities = CoreEntities.create_azure_instance("https://graph.microsoft.com/" ,logger)
        errors = AzureSetup(args,logger,bearer_token).run_idp_script(entities,host)
    if errors:
        logger.error(errors)
        return 1
    return 0   

if __name__ == '__main__':

    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', nargs='*', required=True, help='URL path for api calls')
    parser.add_argument('--user', nargs='*', required=True, help='Admin user id')
    parser.add_argument('--apikey', nargs='*', required=True, help='Admin apikey')
    parser.add_argument('--idp', nargs='*', required=True, help='IdP to create')
    parser.add_argument('--config', help='The .conf cred file to use')
    parser.add_argument('--secret', default=os.getenv('MCMP_API_AUTOMATION_SECRET'),
                        help='Symmetric key used to decrypt the pre seed file')
    exit(main(parser.parse_args()))