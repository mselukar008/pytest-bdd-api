import logging
import json
import os
import traceback

from utils.encryption import Encryption


class ScriptInstanceBase:
    def __init__(self, args, tenant_data, settings, logger=None):
        self.args = args
        self.tenant_data = tenant_data
        self.settings = settings
        self.logger = logger or logging.getLogger()
        self.error_list = []

    @property
    def json_indent(self) -> int:
        return self.settings['params']['log_json_indent']

    @property
    def expected_response_time(self) -> int:
        return self.settings['params']['expected_response_time']

    def check_preconditions(self, entities):
        return []

    def run_script(self, entities):
        raise NotImplementedError('Overwrite in derived class')

    def _log_exception(self, logger, message: str):
        logger.critical(traceback.format_exc())
        logger.critical(message)
        self.error_list.append(message)

    def _log_error(self, logger, message: str):
        logger.error(message)
        self.error_list.append(message)


class PreSeedBase(ScriptInstanceBase):
    keys = []
    def __init__(self, args, folder: str, logger=None):
        if type(self) == PreSeedBase:
            raise Exception(f'Do not instantiate base: {PreSeedBase.__name__}')
        super().__init__(args, None, None, logger)
        self.folder = folder
        self.data = {}
        self.error_list = []
        self._load()

    def decrypt(self, key: str, secret: str):
        pass

    def encrypt(self, key: str, secret: str):
        pass

    def create_data(self):
        raise NotImplementedError('Overwrite in derived class')

    def decrypt_all(self):
        for key in self.keys:
            self.decrypt(key, self.args.secret)

    def encrypt_all(self):
        for key in self.keys:
            self.encrypt(key, self.args.secret)

    @staticmethod
    def _encryption_helper(secret: str, encrypt: bool):
        if secret:
            encryption = Encryption(secret)
            method = encryption.encrypt if encrypt else encryption.decrypt
        else:
            method = lambda text: text
        return method

    def _log_exception(self, logger, message: str):
        logger.critical(traceback.format_exc())
        logger.critical(message)
        self.error_list.append(message)

    def _log_error(self, logger, message: str):
        logger.error(message)
        self.error_list.append(message)

    def _load(self):
        if os.path.exists(self.folder):
            self.data = self.create_data()
            for key in self.keys:
                try:
                    self.data[key] = json.load(open(os.path.join(self.folder, f'{key}.json')))
                except:
                    pass
            self.decrypt_all()
        else:
            raise FileNotFoundError(self.folder)
