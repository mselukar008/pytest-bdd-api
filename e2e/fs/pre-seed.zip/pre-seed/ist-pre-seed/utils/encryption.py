from cryptography.fernet import Fernet
from configparser import ConfigParser



class Encryption:
    def __init__(self, secret):
        self.cipher = Fernet(str.encode(secret))

    @staticmethod
    def _format(method, text):
        return method(str.encode(text)).decode('utf-8') if isinstance(text, str) else text

    def decrypt(self, text):
        return Encryption._format(self.cipher.decrypt, text)

    def encrypt(self, text):
        return Encryption._format(self.cipher.encrypt, text)


def encrypt(text, secret):
    encryption = Encryption(secret)
    return encryption.encrypt(text)


def decrypt(text, secret):
    encryption = Encryption(secret)
    return encryption.decrypt(text)

def process_text(text: str, secret: str, is_encrypted: bool) -> str:
    if is_encrypted:
        text = decrypt(text, secret)
    else:
        text = encrypt(text, secret)
    return text

def process_config(file_path: str, secret: str, decrypt: bool, save: bool = False) -> ConfigParser:
    config = ConfigParser()
    config.optionxform = str
    config.read(file_path)
    for section in config.sections():
        for k, v in config[section].items():
            if k.startswith('_'):
                config[section][k] = process_text(v, secret, decrypt)
    if save:
        with open(file_path, mode='w') as f:
            config.write(f)
    return config
