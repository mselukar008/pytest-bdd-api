from socket import AddressFamily
from encryption import process_config


class AzureSetup():
    def __init__(self, args,logger=None, bearer_token=None ):
        self.args = args
        self.logger = logger
        self.config = process_config(self.args.config, self.args.secret, decrypt=True) if self.args.config else None
        self.bearer_token = bearer_token

    def run_idp_script(self, entities, tenant):
        data = self._get_application_details(entities)
        if data:
            identified_uris, reply_urls = self._get_current_app_urls_config(entities, data)
        else:
            self._log_exception(entities.logger,  f'No Data Found')
            raise 

        if identified_uris and reply_urls:
            self._add_identified_uris(entities,identified_uris,tenant)
            self._add_reply_url(entities,reply_urls,tenant)
        else:
            self._log_exception(entities.logger,  f'No Identified URIs or Reply URLs found')
            

            

    def _get_bearer_token(self, entities):
        try:
            entities.logger.info("Getting Bearer Token for Azure")
            data = {}
            data['grant_type'] = 'client_credentials'
            data['client_secret'] = self.config._sections['azure-idp']['_client_secret']
            data['client_id'] = self.config._sections['azure-idp']['_app_id']
            data['scope'] = 'https://graph.microsoft.com/.default'

            tenant = self.config._sections['azure-idp']['_tenant_id']
            bearer_token = entities.Azure.get_azure_bearer_token(tenant, dict(data))
            if not bearer_token:
                self._log_error(entities.logger, f"Failed to get Bearer Token")
            
            entities.logger.info(f"Bearer Token was succesfully retrieved Bearer Token: {bearer_token}")
            
            return bearer_token

        except:
            self._log_exception(entities.logger,  f'Encountered an exception when getting the bearer token for Azure')

    def _get_application_details(self, entities):
        try:
            idp_object_id = self.config._sections['azure-idp']['_object_id_idp_app']
            entities.logger.info(f'Using Bearer token to retrive {idp_object_id} details')
            data = entities.Azure.get_application_details(self.bearer_token, idp_object_id)
            if not data:
                self._log_error(entities.logger, f"Failed to get details for {idp_object_id} ObjectID.")
            return data
        except:
            self._log_exception(entities.logger,  f'Encountered an exception when getting the details for {idp_object_id}')

    def _get_current_app_urls_config(self, entities, data):
        entities.logger.info(f'Getting Idenitified URIs from the application details')
        identified_uris = data['identifierUris']
        entities.logger.info(identified_uris)

        entities.logger.info(f'Getting Reply URLs from the application details')
        reply_urls = data['web']
        entities.logger.info(reply_urls)

        return identified_uris, reply_urls

    def _add_identified_uris(self, entities, identified_uris, tenant):
        try:
            idp_object_id = self.config._sections['azure-idp']['_object_id_idp_app']
            identified_uris.append(tenant)
            entities.logger.info(f'Adding Identified URIs for tenant {tenant} into application {idp_object_id}')
            payload = {'identifierUris': identified_uris}
            resposne = entities.Azure.set_application_identified_uris(self.bearer_token, idp_object_id, payload)
            if not resposne:
                self._log_error(entities.logger, f"Failed to update Identified URIs.")
                return
            entities.logger.info(f'Added succesfully  Identified URIs for tenant {tenant} into application {idp_object_id}')
            
        except:
            entities._log_exception(entities.logger,  f'Encountered an exception when adding identified URIs to application {idp_object_id}')
    
    def _add_reply_url(self, entities, reply_urls, tenant):
        try:
            idp_object_id = self.config._sections['azure-idp']['_object_id_idp_app']
            reply_urls['redirectUris'].append(f"{tenant}/api/iam/v2/callback")
            entities.logger.info(f'Adding reply url  {tenant}/api/iam/v2/callback into application {idp_object_id}')
            payload = {"web" : reply_urls}
            resposne = entities.Azure.set_application_redirect_uris(self.bearer_token, idp_object_id, payload)
            if not resposne:
                self._log_error(entities.logger, f"Failed to update reply URLs.")
                return
            entities.logger.info(f'Added succesfully Reply URLs {tenant}/api/iam/v2/callbac into application {idp_object_id}')
            
        except:
            entities._log_exception(entities.logger,  f'Encountered an exception when adding reply URLs to application {idp_object_id}')








