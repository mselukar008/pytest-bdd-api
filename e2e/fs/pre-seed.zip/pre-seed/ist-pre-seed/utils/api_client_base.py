import concurrent.futures
import configparser
from copy import deepcopy
import json
import logging
import signal
from time import (
    sleep,
    time
)
from urllib import parse
from urllib3 import Retry

import requests
from requests import ReadTimeout


requests.packages.urllib3.disable_warnings()
retry = Retry(connect=10)
adapter = requests.adapters.HTTPAdapter(max_retries=retry)
expected_response_time = 60.0


def create_headers(username_apikey: tuple = None, user_id_bearer_token: tuple = None):
    if username_apikey:
        headers = {
            'username': username_apikey[0],
            'apikey': username_apikey[1]
        }
    elif user_id_bearer_token:
        headers = {
            'username': user_id_bearer_token[0],
            'Authorization': f'Bearer {user_id_bearer_token[1]}'
        }
    else:
        raise Exception('No parameters passed for header Authorization')
    return headers


def mask(iterable, key):
    iterable[key] = '******' if isinstance(iterable[key], str) else iterable[key]


class Authorization:
    EXTERNAL = 'external'
    HYBRID = 'hybrid'
    INTERNAL = 'default'


class Route:
    def __init__(self, path, parameters=None, query_parameters=None):
        self.parameters = parameters or {}
        self.query_parameters = query_parameters or {}
        params = '&'.join(['%s=%s' % (k, v) for k, v in self.query_parameters.items() if v is not None])
        self.path = parse.urlunsplit(("", "", path, params, ""))
        self.formatted = self.path.format(**self.parameters)

    def __str__(self):
        return self.formatted


class RequestTimeout():
    """
    Context Manager class used to raise an exception if a request is taking too long
    even if the request is still receiving data
    """
    @staticmethod
    def _timeout(signum, frame):
        """
        Raises a ReadTimeout
        :param signum: The signal number
        :param frame: The frame
        """
        raise ReadTimeout()

    def __init__(self, timeout):
        self.timeout = timeout
        signal.signal(signal.SIGALRM, RequestTimeout._timeout)

    def __enter__(self):
        signal.alarm(self.timeout)

    def __exit__(self, exc_type, exc_value, traceback):
        signal.alarm(0)
        return exc_type is None


class HttpClientBase:
    def __init__(self, end_point, headers=None):
        self.session = requests.Session()
        self.session.trust_env = False  # Don't read proxy settings from OS; on Macs this can make requests hang/crash when using multi-processing
        self.session.mount('https://', adapter)
        self.session.mount('http://', adapter)
        self.end_point = end_point
        self._headers = headers if headers else {}


class SimpleApiClientBase(HttpClientBase):
    def __init__(self, end_point, headers=None, logger=None):
        super().__init__(end_point, headers if headers is not None else {'Content-Type': 'application/json', 'Accept': 'application/json'})
        self.logger = logger or logging.getLogger()

    def request_handler(self, request, route, payload=None, **kwargs):
        """
        Makes the request.
        :param request: Callback of session request method
        :param route: The api route
        :param payload: The payload
        :param **kwargs: Keyword arguments for the request
        :return: Tuple of status code and response body
        """
        url = parse.urljoin(self.end_point, route)
        response = request(url, headers=self._headers, timeout=(3.05, 60), verify=False, data=payload, **kwargs)
        self.logger.debug(f'{request.__name__.upper()} {response.status_code} {url}')
        try:
            status_code, response_body = response.status_code, json.loads(response.text)
        except ValueError:
            status_code, response_body = response.status_code, response.text
        return status_code, response_body

    def get(self, route):
        return self.request_handler(self.session.get, route)

    def auth_get(self, route, username, password):
        return self.request_handler(self.session.get, route, auth=(username, password))

    def post(self, route, payload):
        return self.request_handler(self.session.post, route, json.dumps(payload))

    def auth_post(self, route, username, password, payload):
        return self.request_handler(self.session.post, route, json.dumps(payload), auth=(username, password))

    def put(self, route, payload):
        return self.request_handler(self.session.put, route, json.dumps(payload))

    def patch(self, route, payload):
        return self.request_handler(self.session.patch, route, json.dumps(payload))

    def delete(self, route):
        return self.request_handler(self.session.delete, route)

    def auth_delete(self, route, username, password):
        return self.request_handler(self.session.delete, route, auth=(username, password))

    def upload(self, route, files):
        return self.request_handler(self.session.post, route, files=files)
    
    def post_data(self, route , data):
        return self.request_handler(self.session.post, route, data )

class AzureApiClientBase(SimpleApiClientBase):
    def __init__(self, url, headers, logger_, max_round_trip=60):
        super().__init__(url, headers, logger=logger_)
        self._headers.update(headers)
        self.temp_headers = {}
        self.temp_form_data = {}
        self.max_round_trip = max_round_trip


    def set_user_bearer(self, bearer_token):
        self._headers['Authorization'] = f'Bearer {bearer_token}'
    
    def set_form_data(self, form_data):
        self.temp_form_data.update(form_data)
    @property
    def get_form_data(self):
        return self.temp_form_data

    def request_handler(self, request, route, payload=None, **kwargs):
            """
            Makes the request and times the roundtrip, and logs the results. Also updates headers if temps are used.
            :param request: Callback of session request method
            :param route: The route instance
            :param payload: The payload
            :param **kwargs: Keyword arguments for the request
            :return: Tuple of status code and response body
            """
            url = parse.urljoin(self.end_point, route.formatted)
            if self.temp_headers:
                self._headers.update(self.temp_headers)
            headers = self._headers
            response = request(url, headers=headers, timeout=(3.05, self.max_round_trip), verify=False, data=payload, **kwargs)
            self.temp_headers = {}
            self.logger.debug(f'{request.__name__.upper()} {response.status_code} {url}')
            try:
                status_code, response_body = response.status_code, json.loads(response.text)
            except ValueError:
                status_code, response_body = response.status_code, response.text
            return status_code, response_body




        



class McmpApiClientBase(SimpleApiClientBase):
    def __init__(self, url, headers, logger_, extra_users=None, max_round_trip=60):
        super().__init__(url, logger=logger_)
        self._headers.update(headers)
        self.is_hybrid = True if 'Authorization' in self._headers else False
        self.temp_headers = {}
        self.extra_users = extra_users
        self.max_round_trip = max_round_trip

    def __getattr__(self, item):
        if 'as_' in item:
            if self.extra_users is not None:
                suffix = item.replace('as_', '')
                if self.is_hybrid:
                    user_id, bearer_token = self.extra_users.get_hybrid_credentials(suffix)
                    self.set_user_bearer(user_id, bearer_token)
                else:
                    user_name, api_key = self.extra_users.get_credentials(suffix)
                    self.set_user(user_name, api_key)
                # TODO: might want to keep
                # self.session.cookies.clear_session_cookies()
                # self.session.cookies.clear()
                return self
            else:
                raise KeyError("extra_users can't be None")
        else:
            raise AttributeError(f'{item} does not exist')

    @property
    def username(self):
        return self.temp_headers.get('username') or self._headers['username']

    @property
    def apikey(self):
        return self.temp_headers.get('apikey') or self._headers['apikey']

    @staticmethod
    def create_headers(user: str, apikey: str, authorization: str = Authorization.INTERNAL) -> dict:
        if authorization == Authorization.HYBRID:
            headers = create_headers(user_id_bearer_token=(user, apikey))
        else:
            headers = create_headers((user, apikey))
        return headers

    def set_user(self, user_id, apikey):
        self._headers['username'] = user_id
        self._headers['apikey'] = apikey

    def set_user_bearer(self, user_id, bearer_token):
        self._headers['username'] = user_id
        self._headers['Authorization'] = f'Bearer {bearer_token}'

    def request_handler(self, request, route, payload=None, **kwargs):
        """
        Makes the request and times the roundtrip, and logs the results. Also updates headers if temps are used.
        :param request: Callback of session request method
        :param route: The route instance
        :param payload: The payload
        :param **kwargs: Keyword arguments for the request
        :return: Tuple of status code and response body
        """
        url = parse.urljoin(self.end_point, route.formatted)
        headers = self.temp_headers or self._headers
        response = request(url, headers=headers, timeout=(3.05, self.max_round_trip), verify=False, data=payload, **kwargs)
        self.temp_headers = {}
        self.logger.debug(f'{request.__name__.upper()} {response.status_code} {url}')
        try:
            status_code, response_body = response.status_code, json.loads(response.text)
        except ValueError:
            status_code, response_body = response.status_code, response.text
        return status_code, response_body

    def poll_handler(self, wait_time, exit_if, request, *args, **kwargs):
        """
        Makes the request and times the roundtrip, and logs the results
        :param wait_time: The total wait of the poll
        :param exit_if: Callback condition to determine when to exit
        :param request: Callback request method
        :param *args: Positional arguments for the request
        :param **kwargs: Keyword arguments for the request
        :return: Tuple of status code, response body, True if timed out
        """
        start_time = time()
        status_code, response_body = None, None
        done, timed_out = False, False
        while not done and not timed_out:
            status_code, response_body = request(*args, **kwargs)
            done = exit_if(status_code, response_body)
            timed_out = (time() - start_time) > wait_time
            sleep(3)
        return status_code, response_body, timed_out


class McmpApiClientCustom(McmpApiClientBase):
    def __init__(self, url, headers, logger_, extra_users=None, max_round_trip=60, json_indent=0):
        super().__init__(url, headers, logger_, extra_users, max_round_trip)
        parse_result = parse.urlparse(url)
        self.poll_freq = [2, 4, 8, 10]
        self.basic_auth_username = parse_result.username
        self.basic_auth_password = parse_result.password
        self._log_request_payload = True
        self._log_response_payload = True
        self.json_indent = None if json_indent == 0 else json_indent
        self.is_polling = False
        self.last_request = None
        self.last_request_metric = None
        self.elapsed_time = 0
        self.good_response_time = None
        self._metric_logger = logging.getLogger('api_metrics.csv')

    def _log_headers(self, headers):
        included_headers = json.dumps({k: v for k, v in headers.items() if k not in ['Content-Type', 'Accept', 'apikey']})
        self.logger.debug(f'HEADERS: {included_headers}')

    def _log_request(self, request, request_mask):
        if request and self._log_request_payload:
            try:
                request_ = json.loads(request)
            except:
                request_ = request
            if not isinstance(request_, str):
                if request_mask:
                    request_mask(request_, mask)
                request_ = json.dumps(request_, indent=self.json_indent)
            self.logger.debug(f'REQUEST: {request_}')

    def _log_response(self, response, response_mask=None):
        if self._log_response_payload:
            response_ = deepcopy(response)
            if not isinstance(response_, str) and response_mask:
                response_mask(response_, mask)
            try:
                response_str = json.dumps(response_, indent=self.json_indent)
            except ValueError:
                response_str = response_
            self.logger.debug(f'RESPONSE: {response_str}')

    def get(self, route, response_mask=None):
        return self.request_handler(self.session.get, route, response_mask=response_mask)

    def post(self, route, payload, request_mask=None, response_mask=None):
        return self.request_handler(self.session.post, route, json.dumps(payload), request_mask)

    def auth_post(self, route, username, password, payload, request_mask=None, response_mask=None):
        return self.request_handler(self.session.post, route, json.dumps(payload), request_mask, response_mask, auth=(username, password))

    def put(self, route, payload, request_mask=None, response_mask=None):
        return self.request_handler(self.session.put, route, json.dumps(payload), request_mask, response_mask)

    def patch(self, route, payload, request_mask=None, response_mask=None):
        return self.request_handler(self.session.patch, route, json.dumps(payload), request_mask)

    def head(self, route, response_mask=None): 
        return self.request_handler(self.session.head, route, response_mask=response_mask)

    def request_handler(self, request, route, payload=None, request_mask=None, response_mask=None, **kwargs):
        """
        Makes the request and times the roundtrip, and logs the results. Also updates headers if temps are used.
        :param request: Callback of session request method
        :param route: The route instance
        :param payload: The payload
        :param request_mask: The function to determine what needs to be masked in the request
        :param response_mask: The function to determine what needs to be masked in the response
        :param **kwargs: Keyword arguments for the request
        :return: Tuple of status code and response body
        """
        url_unformatted = parse.urljoin(self.end_point, route.path)
        url_formatted = parse.urljoin(self.end_point, route.formatted)
        no_cred_url_formatted = url_formatted if self.basic_auth_username is None else url_formatted.replace(f"{self.basic_auth_username}:{self.basic_auth_password}@", "")
        no_cred_url_unformatted = url_unformatted if self.basic_auth_username is None else url_unformatted.replace(f"{self.basic_auth_username}:{self.basic_auth_password}@", "")
        headers = self.temp_headers or self._headers
        method = request.__name__.upper()
        self.logger.debug(f'{method} {no_cred_url_formatted}')
        self._log_headers(headers)
        self._log_request(payload, request_mask)
        start_time = time()
        response = request(url_formatted, headers=headers, timeout=(3.05, self.max_round_trip), verify=False, data=payload if payload is not None else None, **kwargs)
        end_time = time()
        self.logger.debug(f'RESPONSE CODE: {response.status_code}')
        self.temp_headers = {}
        self.elapsed_time = round(end_time - start_time, 3)
        self.good_response_time = self.elapsed_time <= expected_response_time
        self.last_request_metric = f'{method},{response.status_code},{no_cred_url_unformatted},{repr(start_time)},{repr(end_time)},{self.elapsed_time},{self.good_response_time}'
        try:
            status_code, response_body = response.status_code, json.loads(response.text)
        except ValueError:
            status_code, response_body = response.status_code, response.text
        if not self.is_polling:
            self._metric_logger.debug(self.last_request_metric)
            self._log_response(response_body, response_mask)
        return status_code, response_body

    def poll_handler(self, wait_time, exit_if, request, *args, **kwargs):
        """
        Polls on the request until the exit condition is met or wait time has passed.
        :param wait_time: The total wait of the poll
        :param exit_if: Callback condition to determine when to exit
        :param request: Callback request method
        :param *args: Positional arguments for the request
        :param **kwargs: Keyword arguments for the request
        :return: Tuple of status code, response body, True if timed out
        """
        start_time = time()
        done, timed_out = False, False
        status_code, response_body = None, None
        self.is_polling = True
        poll_index = 0
        while not done and not timed_out:
            status_code, response_body = request(*args, **kwargs)
            done = exit_if(status_code, response_body)
            timed_out = (time() - start_time) > wait_time
            sleep(self.poll_freq[poll_index])
            poll_index += 1
            poll_index = min(poll_index, len(self.poll_freq) - 1)
        self.is_polling = False
        self._metric_logger.debug(self.last_request_metric)
        self._log_response(response_body)
        return status_code, response_body, timed_out

    def parallel_handler(self, wait_time, exit_if, request, *args, **kwargs):
        """
        Makes the same request  in parallel n times and exits when a condition is met or wait time has passed.
        The status code and response body returned will the response that matched   the exit condition
        :param wait_time: The total wait of the poll
        :param exit_if: Callback condition to determine when to exit
        :param request: Callback request method
        :param *args: Positional arguments for the request
        :param **kwargs: Keyword arguments for the request
        :return: Tuple of status code, response body, True if timed out
        """
        start_time = time()
        stop, timed_out = False, False
        status_code, response_body = None, None
        self.is_polling = True
        max_workers = 8
        max_tasks = 2
        max_tries = 20
        total_tries = 0
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            tasks = [executor.submit(request, *args, **kwargs) for _ in range(max_tasks)]
            while tasks:
                done, tasks = concurrent.futures.wait(tasks, return_when=concurrent.futures.FIRST_COMPLETED)
                for future in done:
                    total_tries += 1
                    temp_status_code, temp_response_body = future.result()
                    if exit_if(temp_status_code, temp_response_body):
                        status_code, response_body = temp_status_code, temp_response_body
                        stop = True
                    timed_out = (time() - start_time) > wait_time
                    if timed_out or total_tries >= max_tries:
                        stop = True
                if stop:
                    break
                else:
                    tasks.extend([executor.submit(request, *args, **kwargs) for _ in range(max_tasks)])
        self.is_polling = False
        self._metric_logger.debug(self.last_request_metric)
        self._log_response(response_body)
        return status_code, response_body
