from datetime import datetime
import logging
import os
import random
import string
import sys
import time

from pytz import timezone


CUSTOM_PREFIX = os.getenv("MCMP_API_AUTOMATION_CUSTOM_PREFIX", "e2esvtapi")
DATE_TIME_STR_FORMAT = "%Y-%m-%dT%H:%M:%S.123Z"
GUID_REGEX_PATTERN = '[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}'
USERID_REGEX_PATTERN = '[0-9a-f]{24}'
BEARER_REGEX_PATTERN = r'[A-Za-z0-9\-\._~\+\/]+=*'


def create_logger(name: str):
    _FORMATTER = logging.Formatter(fmt=f'%(asctime)s [%(levelname)s]   %(message)s', datefmt='%Y-%m-%d %H:%M:%S CDT')
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    file_handler = logging.FileHandler(f'{name}.log', mode='w')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(_FORMATTER)
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setLevel(logging.INFO)
    stream_handler.setFormatter(_FORMATTER)
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    return logger


def add_custom_prefix_to(name, separator='_'):
    return f'{CUSTOM_PREFIX}{separator}{name}'


def read_in_chunks(file_object, chunk_size=1024):
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break
        yield data


def all_helper(class_):
    return [getattr(class_, x) for x in dir(class_) if not x.startswith('__')]


def random_string(size=3, chars=string.ascii_lowercase):
    return ''.join(random.choice(chars) for _ in range(size))


def chunks_iter(sequence, size: int):
    for i in range(0, len(sequence), size):
        yield sequence[i:i + size]


def epoch_str(dot=False):
    str_time = str(time.time())
    return str_time.replace('.', '') if not dot else str_time


def unique_name(infix=''):
    return add_custom_prefix_to(infix + epoch_str())


def get_prefix(prefix=None, separator="_"):
    if prefix is not None:
        return f"{CUSTOM_PREFIX}{separator}{prefix}{separator}"

    return f"{CUSTOM_PREFIX}{separator}"


def random_string_with_prefix(size, prefix=None, separator="_"):
    prefix = get_prefix(prefix=prefix, separator=separator)
    prefix_len = len(prefix)
    if prefix_len >= size:
        raise ValueError(f"The size ({size}) must be greater than lentgh of CUSTOM_PREFIX+1 ({prefix_len})")
    return prefix + random_string(size - prefix_len)


def datetime_now_str(str_format=DATE_TIME_STR_FORMAT, time_zone_str='America/Chicago'):
    time_zone = timezone(time_zone_str)
    return datetime_to_str(datetime.now(time_zone), str_format)


def datetime_to_str(date_time, str_format=DATE_TIME_STR_FORMAT):
    return date_time.strftime(str_format)
