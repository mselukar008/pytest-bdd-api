from datetime import datetime
import json
import logging
import os
import SoftLayer
from utils.encryption import decrypt, process_config


client = None
LOG_FILE = f'manage_ibmcloud_vms_{datetime.now().strftime("%d-%m_%H-%M-%S")}.log'
"""Credentials"""


logging.basicConfig(
    level=logging.INFO, 
    format="[%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ])


def turn_on_vm(vm_id):
    logging.info(f'Turning ON VM with Id: {vm_id}')
    response = client.call('SoftLayer_Virtual_Guest', 'powerOn', id=vm_id)
    if response:
        logging.info('VM turned ON')
    else:
        logging.error('Error occurred during turning ON VM')
    
    
def turn_off_vm(vm_id):
    logging.info(f'Turning OFF VM with Id: {vm_id}')
    response = client.call('SoftLayer_Virtual_Guest', 'powerOff', id=vm_id)
    if response:
        logging.info('VM turned OFF')
    else:
        logging.error('Error occurred during turning OFF VM')
    

def get_vm_id_from_ip(ip_address):
    manager = SoftLayer.VSManager(client)
    response = list(manager.list_instances(public_ip=ip_address))
    logging.info(f'Getting Id for IP {ip_address}')
    if len(response):
        id = response[0].get('id')
        logging.info(f'Id for IP address {ip_address} is {id}')
        return id
    return None

def create_client(username, api_key):
    global client
    client = SoftLayer.create_client_from_env(username=username, api_key=api_key)


def __log_devider():
    logging.info('-'*100)

    
def main(parser):
    config = process_config(parser.config , parser.secret, decrypt=True) if parser.config else None
    if parser.username and parser.secret:
        create_client(decrypt(parser.username, parser.secret), decrypt(parser.apikey, parser.secret))
    else:
        create_client(config._sections['ibmcloud']['_username'],config._sections['ibmcloud']['_apiKey'])
    __log_devider()
    ips = get_ips_from_input(parser)
    only_get_vms_status = True if parser.mode == "ONLY_GET_VM_STATUS" else False
    if only_get_vms_status:
        get_vms_status(ips)
    else:
        logging.info(f'Turn {parser.mode} mode')
        for ip in ips:
            try: 
                vm_id = get_vm_id_from_ip(ip)
                if parser.mode == 'ON':
                    turn_on_vm(vm_id)
                else:
                    turn_off_vm(vm_id)
                __log_devider()
            except Exception as ex:
                logging.exception(ex)
        logging.info('Process finished')
        get_vms_status(ips)


    
    
def get_ips_from_input(parser):
    ips = parser.ips
    if parser.file:
        file_path = parser.file
        if os.path.isfile(file_path) and '.json' in file_path:
            file = open(file_path, "r")
            parsed_file = file.read()
            loaded_ips = json.loads(parsed_file)
            file.close()
            if parser.vms == "ALL":
                for group in loaded_ips:
                    for ip in loaded_ips[group]:
                        try:
                            ip = decrypt(ip, parser.secret)
                        except:
                            pass
                        ips.append(ip)
            else:
                for ip in loaded_ips[parser.vms]:
                        try:
                            ip = decrypt(ip, parser.secret)
                        except:
                            pass
                        ips.append(ip)

        else:
            raise Exception('A valid JSON file is required')       
    return ips

def get_vms_status(ips):
    for ip in ips:
        vm_id = get_vm_id_from_ip(ip)
        if vm_id is not None:
            response = client.call('SoftLayer_Virtual_Guest', 'getDeviceStatus', id=vm_id)
            logging.info(f"VM: {ip}, is currently: {response['name']} ")
            __log_devider()

        else:
            logging.error(f'Not able to find status for VM with IP {ip}')  
            __log_devider()





            

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--ips', nargs='*', default=[], type=str, help='IPs of virtual servers')
    parser.add_argument('--vms', type=str,  choices=['ALL', 'perf_vms',"functional_vms"], help='Which VMs will be used') 
    parser.add_argument('--file', type=str, help='IPs of virtual servers')
    parser.add_argument('-m', '--mode', type=str, choices=['ON', 'OFF', 'ONLY_GET_VM_STATUS'])
    parser.add_argument('--secret', default=os.getenv('MCMP_API_AUTOMATION_SECRET'), help='Key to decrypt the credentials')
    parser.add_argument('--username', help='Username for ibmcloud')    
    parser.add_argument('--apikey', help='Api key for ibmcloud')
    parser.add_argument('--config', help='Config File Path', default="ist_provider_creds.conf")

    exit(main(parser.parse_args()))