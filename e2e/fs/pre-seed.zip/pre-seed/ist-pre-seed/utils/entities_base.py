
class EntityBase:
    def __init__(self, api_client, logger=None):
        if type(self) == EntityBase:
            raise Exception(f'Do not instantiate base: {EntityBase.__name__}')
        self.api_client = api_client
        self.logger = logger or api_client.logger
        self.status_code = None
        self.response_body = None

    def __getattr__(self, name):
        if 'as_' in name:
            self.api_client.__getattr__(name)
        return self

    def __getstate__(self):
        return vars(self)

    def __setstate__(self, state):
        vars(self).update(state)

    def log_actual_expected_response(self, actual_status_code, expected_status_code, actual_response, expected_response, pre_message=''):
        self.log_actual_expected_message(actual_status_code, expected_status_code, pre_message or 'Status code')
        self.log_actual_expected_message(actual_response, expected_response, pre_message or 'Response')

    def log_actual_expected_message(self, actual_message, expected_message, pre_message=''):
        pre_message = f'{pre_message} -' if pre_message else ''
        self.logger.info(f'{pre_message} Actual: {actual_message} | Expected: {expected_message}')

    def request_handler(self, request, *args, **kwargs):
        self.status_code, self.response_body = request(*args, **kwargs)

    def poll_handler(self, wait_time, exit_if, request, *args, **kwargs):
        self.status_code, self.response_body, timed_out = self.api_client.poll_handler(wait_time, exit_if, request, *args, **kwargs)
        if timed_out:
            self.logger.info(f'Timed out after waiting for {wait_time} seconds')

    def save_previous_response(self, handler, *args, **kwargs):
        temp = self.status_code, self.response_body
        result = handler(*args, **kwargs)
        self.status_code, self.response_body = temp
        return result


class EntitiesBase:
    def __init__(self, api_client, data=None, logger=None):
        if type(self) == EntitiesBase:
            raise Exception(f'Do not instantiate base: {EntitiesBase.__name__}')
        self.api_client = api_client
        self.data = data
        self.logger = logger or api_client.logger

    def __getattr__(self, name):
        if 'as_' in name:
            self.api_client.__getattr__(name)
        return self

    def __getstate__(self):
        return vars(self)

    def __setstate__(self, state):
        vars(self).update(state)

    @staticmethod
    def create_instance(host: str, user: str, apikey: str, logger):
        raise NotImplementedError(f'Overwrite in your derived class')

    def assert_equals(self, actual, expected, pre_message=''):
        assert actual == expected, f"{pre_message + ' -' if pre_message else pre_message}\n Actual: {actual} != Expected: {expected}"

    def new_instance(self):
        return self.__class__(self.api_client, self.logger)
