#!/usr/bin/env python3
import base64
from datetime import datetime
import hashlib
import hmac
import logging
import os
import sys
import re
from urllib.parse import urljoin
import xml.etree.ElementTree as ET

from bs4 import BeautifulSoup
from requests import codes

sys.path.insert(0, os.getcwd())
from utils.api_client_base import HttpClientBase
from utils.encryption import decrypt
from utils import chunks_iter


def _sign(key: str, message: str):
    return hmac.new(key, message.encode('utf-8'), hashlib.sha256).digest()


def _get_signature_key(key: str, date_stamp: str, region_name: str, service_name: str):
    k_date = _sign(('AWS4' + key).encode('utf-8'), date_stamp)
    k_region = _sign(k_date, region_name)
    k_service = _sign(k_region, service_name)
    return _sign(k_service, 'aws4_request')


def _xml_print(xml_str: str):
    print(BeautifulSoup(xml_str, 'html.parser').prettify())


def us_south(secret: str, logger=None):
    host = 's3.us-south.cloud-object-storage.appdomain.cloud'
    access_key = 'gAAAAABepGazV9l9dAeDaYvMZlgqmbb0avHd-tckw6Vq_3X6VQtd_i00WvtGxLzXyBthTkZjVwPYhJOWE4WiLrznKCrs8rMWm3srb12ZQ8bfISZwHkYIIg0='
    secret_key = 'gAAAAABepGbHMkdLGun6ASzzWyLBEZomVUnWSNXDyxMKrAKMGJsNxp3oPoIdyKWCJhAdwPFxvmngaY7g7BzpRXTw7Dp-dtPSlDqTJc9kz_fzivos2ZNtUqJ8JdW74qW2h-l6lxrpVbF0'
    return ObjectStorageApiClient(host, decrypt(access_key, secret), decrypt(secret_key, secret), logger)


def us_east(secret: str, logger=None):
    host = 's3.us.cloud-object-storage.appdomain.cloud'
    access_key = 'gAAAAABficqO1U_DNkXZZlNE2YAuGMeRcEvw1R57WGNtEnqOgkl1fv8pyIHn3NNVNeSyP2EhmxrBu7LLAiQ9ZKshpWUyXZVk7Wv1ip04hLkjzlo3doGoxmwwnrG67BnoAIE_6KlnVBSK'
    return ObjectStorageApiClient2(host, decrypt(access_key, secret), logger)


def add_zip_object(secret, bucket_name: str, name: str, file_path: str, logger=None):
    client = us_east(secret, logger)
    status_code, _ = client.create_bucket(bucket_name)
    all_ok = status_code in [codes.OK, codes.CONFLICT]
    if all_ok:
        with open(file_path, 'rb') as f:
            payload = ''.join(base64.b64encode(f.read()).decode('utf-8'))
            size = sys.getsizeof(payload) / 1024 / 1024
            if size > 100.0:
                status_code, upload_id = client.initialize_multi_part_upload(bucket_name, name)
                all_ok = status_code == codes.OK
                if all_ok:
                    part_etags = {}
                    for i, chunk in enumerate(chunks_iter(payload, int(len(payload) / (size/50))), start=1):
                        status_code, etag = client.upload_part(bucket_name, name, i, upload_id, chunk)
                        all_ok &= status_code == codes.OK and isinstance(etag, str)
                        if not all_ok:
                            break
                        part_etags[i] = etag
                    if all_ok:
                        status_code, _ = client.complete_multi_part_upload(bucket_name, name, part_etags, upload_id)
                        all_ok = status_code == codes.OK
                    if not all_ok:
                        client.delete_incomplete_multi_part_upload(bucket_name, name, upload_id)
            else:
                all_ok = client.add_zip_object(bucket_name, name, payload)
    return all_ok


def get_zip_object(secret, bucket_name: str, name: str, file_path: str, logger=None):
    client = us_east(secret, logger)
    status_code = client.get_zip_object(bucket_name, name, file_path)
    return status_code == codes.OK


class ObjectStorageApiClient(HttpClientBase):
    """
    Example taken from:
    https://cloud.ibm.com/docs/services/cloud-object-storage/api-reference?topic=cloud-object-storage-compatibility-api-bucket-operations
    https://cloud.ibm.com/docs/services/cloud-object-storage?topic=cloud-object-storage-object-operations
    https://cloud.ibm.com/docs/services/cloud-object-storage?topic=cloud-object-storage-large-objects
    """
    def __init__(self, host: str, access_key: str, secret_key: str, logger=None):
        super().__init__(f'https://{host}')
        self.host = host
        self.region = host.split('.')[1]
        self.algorithm = 'AWS4-HMAC-SHA256'
        self.access_key = access_key
        self.secret_key = secret_key
        self.service = 'my-service'
        self.signed_headers = 'host;x-amz-date'
        self.logger = logger if logger else logging.getLogger()

    @staticmethod
    def _prettify(xml_str: str):
        return BeautifulSoup(xml_str, 'html.parser').prettify()

    def build_headers(self, method: str, canonical_uri: str = '', canonical_querystring: str = '', payload: str = '', content_type: str = ''):
        """
        https://docs.aws.amazon.com/general/latest/gr/sigv4-signed-request-examples.html#sig-v4-examples-get-query-string
        https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-content-encodings-examples-image-s3.html#api-gateway-content-encodings-example-upload-image-to-s3
        https://github.com/cleardataeng/requests-sigv4/blob/master/requests_sigv4/sigv4request.py
        """
        t = datetime.utcnow()
        amzdate = t.strftime('%Y%m%dT%H%M%SZ')
        date_stamp = t.strftime('%Y%m%d')
        canonical_headers = '\n'.join([f'host:{self.host}', f'x-amz-date:{amzdate}']) + '\n'
        payload_hash = hashlib.sha256((payload).encode('utf-8')).hexdigest()
        canonical_request = '\n'.join([method, f'/{canonical_uri}', canonical_querystring, canonical_headers,
                                       self.signed_headers, payload_hash])
        credential_scope = f"{date_stamp}/{self.region}/{self.service}/aws4_request"
        string_to_sign = '\n'.join([self.algorithm, amzdate, credential_scope,
                                    hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()])
        signing_key = _get_signature_key(self.secret_key, date_stamp, self.region, self.service)
        signature = hmac.new(signing_key, (string_to_sign).encode('utf-8'), hashlib.sha256).hexdigest()
        authorization_header = f"{self.algorithm} Credential={self.access_key}/{credential_scope}, SignedHeaders={self.signed_headers}, Signature={signature}"
        headers = {'x-amz-date': amzdate, 'Authorization': authorization_header}
        if payload:
            headers['x-amz-content-sha256'] = payload_hash
        if content_type:
            headers['Content-Type'] = content_type
        return headers

    def create_bucket(self, name: str):
        headers = self.build_headers('PUT', name)
        response = self.session.put(urljoin(self.end_point, name), headers=headers)
        self.logger.debug(response.status_code)
        self.logger.debug(response.text)
        return response.status_code, response.text

    def get_buckets(self):
        headers = self.build_headers('GET')
        response = self.session.get(self.end_point, headers=headers)
        response_body = ObjectStorageApiClient._prettify(response.text)
        self.logger.debug(response.status_code)
        self.logger.debug(response_body)
        return response.status_code, response_body

    def get_bucket(self, name: str):
        headers = self.build_headers('GET', name)
        response = self.session.get(urljoin(self.end_point, name), headers=headers)
        response_body = ObjectStorageApiClient._prettify(response.text)
        self.logger.debug(response.status_code)
        self.logger.debug(response_body)
        return response.status_code, response_body

    def delete_bucket(self, name: str):
        headers = self.build_headers('DELETE', name)
        response = self.session.delete(urljoin(self.end_point, name), headers=headers, timeout=(3.05, 5))
        self.logger.debug(response.status_code)
        self.logger.debug(response.text)
        return response.status_code, response.text

    def add_object(self, bucket_name: str, name: str, payload: str):
        route = f'{bucket_name}/{name}'
        headers = self.build_headers('PUT', route, payload=payload)
        response = self.session.put(urljoin(self.end_point, route), data=payload, headers=headers)
        self.logger.debug(response.status_code)
        self.logger.debug(response.text)
        return response.status_code, response.text

    def get_object(self, bucket_name: str, name: str):
        route = f'{bucket_name}/{name}'
        headers = self.build_headers('GET', route)
        response = self.session.get(urljoin(self.end_point, route), headers=headers)
        self.logger.debug(response.status_code)
        self.logger.debug(response.text)
        return response.status_code, response.text

    def add_zip_object(self, bucket_name: str, name: str, payload: str):
        route = f'{bucket_name}/{name}'
        headers = self.build_headers('PUT', route, payload=payload, content_type='application/zip')
        response = self.session.put(urljoin(self.end_point, route), data=payload, headers=headers)
        self.logger.debug(response.status_code)
        self.logger.debug(response.text)
        return response.status_code, response.text

    def initialize_multi_part_upload(self, bucket_name: str, name: str):
        self.logger.debug('Initializing multi-part upload')
        query_str = 'uploads='
        route = f'{bucket_name}/{name}'
        headers = self.build_headers('POST', route, canonical_querystring=query_str)
        response = self.session.post(urljoin(self.end_point, f'{route}?{query_str}'), headers=headers)
        self.logger.debug(response.status_code)
        self.logger.debug(ObjectStorageApiClient._prettify(response.text))
        try:
            root = ET.fromstring(response.text)
            namespace, _ = root.tag[1:].split("}")
            response_body = root.find(f'{{{namespace}}}UploadId').text
        except:
            response_body = response.text
        return response.status_code, response_body

    def upload_part(self, bucket_name: str, name: str, part_number:str, upload_id: str, payload: str, content_type='application/zip'):
        self.logger.debug(f'Uploading part #{part_number}')
        query_str = f'partNumber={part_number}&uploadId={upload_id}'
        route = f'{bucket_name}/{name}'
        headers = self.build_headers('PUT', route, payload=payload, canonical_querystring=query_str, content_type=content_type)
        response = self.session.put(urljoin(self.end_point, f'{route}?{query_str}'), data=payload, headers=headers)
        self.logger.debug(response.status_code)
        self.logger.debug(str(response.headers))
        self.logger.debug(response.text)
        return response.status_code, response.headers.get('ETag')

    def complete_multi_part_upload(self, bucket_name: str, name: str, part_etag: dict, upload_id: str):
        self.logger.debug(f'Completing multi-part upload')
        parts = ''.join([f'<Part><PartNumber>{k}</PartNumber><ETag>{v}</ETag></Part>' for k, v in part_etag.items()])
        payload = f'<CompleteMultipartUpload>{parts}</CompleteMultipartUpload>'
        self.logger.debug(payload)
        query_str = f'uploadId={upload_id}'
        route = f'{bucket_name}/{name}'
        headers = self.build_headers('POST', route, payload=payload, canonical_querystring=query_str)
        response = self.session.post(urljoin(self.end_point, f'{route}?{query_str}'), data=payload, headers=headers)
        response_body = ObjectStorageApiClient._prettify(response.text)
        self.logger.debug(response.status_code)
        self.logger.debug(response_body)
        return response.status_code, response_body

    def delete_incomplete_multi_part_upload(self, bucket_name: str, name: str, upload_id: str):
        self.logger.debug('Deleting incomplete multi-part upload')
        query_str = f'uploadId={upload_id}'
        route = f'{bucket_name}/{name}'
        headers = self.build_headers('DELETE', route, canonical_querystring=query_str)
        response = self.session.delete(urljoin(self.end_point, f'{route}?{query_str}'), headers=headers)
        status_code = response.status_code
        self.logger.debug(response.status_code)
        self.logger.debug(response.text)
        return status_code == codes.NO_CONTENT

    def get_zip_object(self, bucket_name: str, name: str, file_name: str = None):
        self.logger.debug('Downloading zip object')
        route = f'{bucket_name}/{name}'
        headers = self.build_headers('GET', route, content_type='application/zip')
        response = self.session.get(urljoin(self.end_point, route), headers=headers)
        self.logger.debug(response.status_code)
        if response.status_code == codes.OK:
            file_name_ = file_name or (name if name.endswith('.zip') else f'{name}.zip')
            with open(file_name_, 'wb') as f:
                #f.write(base64.b64decode(response.content.decode('utf-8')))
                f.write(response.content)
        return response.status_code, None

    def delete_object(self, bucket_name: str, name: str):
        route = f'{bucket_name}/{name}'
        headers = self.build_headers('DELETE', route)
        response = self.session.delete(urljoin(self.end_point, route), headers=headers)
        self.logger.debug(response.status_code)
        self.logger.debug(response.text)
        return response.status_code, response.text


class ObjectStorageApiClient2(ObjectStorageApiClient):
    """
    https://cloud.ibm.com/docs/cloud-object-storage/cli?topic=cloud-object-storage-curl
    """
    def __init__(self, host: str, access_key: str, logger=None):
        super().__init__(host, access_key, None, logger)
        self.token = self._get_token()
        
    def _get_token(self):
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json"
        }
        data = {
            "apikey": str(self.access_key),
            "response_type": "cloud_iam",
            "grant_type":"urn:ibm:params:oauth:grant-type:apikey"
        }
        response = self.session.post('https://iam.cloud.ibm.com/oidc/token', headers=headers, data=data)

        if response.status_code == 200:
            response_json = response.json()
            self.logger.info('Token retrieved')
        else:
            self.logger.info(f'Error retreiving token. Ex: {str(response.text)}')
            raise Exception(str(response.text))

        return response_json['access_token']

    def build_headers(self, method: str, canonical_uri: str = '', canonical_querystring: str = '', payload: str = '', content_type: str = ''):
        return {'Authorization': f'bearer {self.token}', 'ibm-service-instance-id': '682774c9-ee98-459e-a594-8af83825ce74'}


if __name__ == '__main__':
    import argparse
    from cmd import Cmd

    from utils.encryption import decrypt

    parser = argparse.ArgumentParser()
    parser.add_argument('--secret', type=str, default=os.getenv('MCMP_API_AUTOMATION_SECRET'), help='The decryption key')
    args = parser.parse_args()

    class ObjectStorageShell(Cmd):
        intro = 'Welcome to the object-storage shell.   Type help or ? to list commands.\n'
        prompt = '(object-storage) '
        file = None

        def __init__(self, secret):
            self.client = us_east(secret)
            self.verbose = False
            super().__init__(completekey='tab', stdin=None, stdout=None)

        @staticmethod
        def _get_entries(xml, tag):
            root = ET.fromstring(xml)
            namespace, _ = root.tag[1:].split("}")
            return [x.text.strip() for x in root.iter(f'{{{namespace}}}{tag}')]

        def log(self, status_code, response_body=None, filter_=None):
            if self.verbose:
                print(status_code)
                if response_body:
                    print(response_body, '\n')
            elif filter_ and response_body:
                try:
                    entries = ObjectStorageShell._get_entries(response_body, filter_)
                    print('\n'.join(entries), '\n')
                except Exception as e:
                    print(e, '\n')

        def do_verbose(self, value=None):
            """value: str = y, n"""
            if value:
                self.verbose = value.lower() == 'y'
            else:
                print(f'Verbose is {"On" if self.verbose else "Off"}')

        def do_exit(self, inp):
            """exits"""
            print("Bye")
            return True

        def do_buckets(self, line=None):
            """bucket_names: list"""
            if line:
                for bucket_name in line.split(' '):
                    status_code, response_body = self.client.get_bucket(bucket_name)
                    print('{0}:{1}{2}'.format(bucket_name, '\n', '-'*len(bucket_name)))
                    self.log(status_code, response_body, filter_='key')
            else:
                status_code, response_body = self.client.get_buckets()
                self.log(status_code, response_body, filter_='name')

        def do_delete_buckets(self, line):
            """bucket_names: list"""
            for bucket_name in line.split(' '):
                status_code, response_body = self.client.delete_bucket(bucket_name)
                self.log(status_code, response_body)

        def do_delete_objects(self, line):
            """bucket_name: str, object_names: list (wildcard is *)"""
            args = line.split(' ')
            try:
                bucket_name, names = args[0], args[1:]
            except IndexError:
                print(self.do_delete_objects.__doc__)
            else:
                status_code, response_body = self.client.get_bucket(bucket_name)
                if status_code == codes.OK:
                    objects = ObjectStorageShell._get_entries(response_body, 'key')
                    delete_objects = []
                    for name in [w.replace('*', '.*') for w in names]:
                        for object_ in objects:
                            if name == object_:
                                delete_objects.append(object_)
                            elif '.*' in name and re.search(name, object_):
                                delete_objects.append(object_)
                    for name in delete_objects:
                        status_code, response_body = self.client.delete_object(bucket_name, name)
                        self.log(status_code, response_body)
                else:
                    print(f'{bucket_name} does not exist')

        def do_get_zips(self, line):
            """bucket_name: str, file_names: list"""
            args = line.split(' ')
            try:
                bucket_name, file_names = args[0], args[1:]
            except IndexError:
                print(self.do_get_zips.__doc__)
            else:
                for name in file_names:
                    status_code, _ = self.client.get_zip_object(bucket_name, name)
                    self.log(status_code)

    ObjectStorageShell(args.secret).cmdloop()
