from datetime import datetime, timedelta
from dateutil.tz import tzutc
import boto3
from botocore.exceptions import ClientError

from core.payload_helper import ProviderCode
from provider_clients import ProviderShellBase


STACK_STATUS_FILTER = [
    'CREATE_FAILED', 'CREATE_COMPLETE', 'ROLLBACK_FAILED', 'ROLLBACK_COMPLETE', 
    'UPDATE_COMPLETE', 'UPDATE_ROLLBACK_FAILED', 'UPDATE_ROLLBACK_COMPLETE', 
    'IMPORT_COMPLETE', 'IMPORT_ROLLBACK_FAILED', 'IMPORT_ROLLBACK_COMPLETE'
]


def get_ec2_tags(access_key: str, secret_key: str, region: str, instance_id: str):
    return AwsClient(access_key, secret_key, region).get_ec2_tags(instance_id)


def add_ec2_tags(access_key: str, secret_key: str, region: str, instance_id: str, tags: dict):
    return AwsClient(access_key, secret_key, region).add_ec2_tags(instance_id, tags)


def delete_ec2(access_key: str, secret_key: str, region: str, instance_id: str):
    return AwsClient(access_key, secret_key, region).delete_ec2_instances([instance_id])


def download_s3_folder(access_key: str, secret_key: str, region: str, bucket_name: str, download_path: str, file_pattern: str):
    client = AwsClient(access_key, secret_key, region).client('s3')
    objects = client.list_objects(bucket_name, delimiter='/')['Contents']
    for object_ in objects:
        key_string = str(object_['Key'])
        s3_path = download_path + key_string
        try:
            if file_pattern in key_string:
                print("Downloading from aws s3 bucket ... ...")
                client.download_file(bucket_name, key_string, s3_path)
                print(("Current File is ", s3_path))
                break
        except OSError as e:
            pass


class AwsClient:
    def __init__(self, access_key: str, secret_key: str, region: str = None):
        self.access_key = access_key
        self.secret_key = secret_key
        self.region = region

    def client(self, service_name: str, region: str = None):
        return boto3.client(
            service_name,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
            region_name=region or self.region
        )

    def resource(self, service_name: str, region: str = None):
        return boto3.resource(
            service_name,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
            region_name=region or self.region
        )

    def session(self, region: str = None):
        return boto3.session.Session(
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
            region_name=region or self.region
        )

    def get_regions(self):
        return self.client('ec2', 'ap-northeast-1').describe_regions()['Regions']

    def get_ec2_tags(self, instance_id: str, region: str = None):
        return self.resource('ec2', region).Instance(instance_id).tags

    def add_ec2_tags(self, instance_id: str, tags: dict, region: str = None):
        return self.resource('ec2', region).Instance(instance_id).create_tags(Tags=[{'Key': k, 'Value': v} for k, v in tags.items()])

    def get_ec2_instances(self, region: str = None):
        instances = []
        client = self.client('ec2', region)
        try:
            reservations = client.describe_instances()["Reservations"]
            for reservation in reservations:
                for instance in reservation['Instances']:
                    if instance['State']['Name'] != 'terminated':
                        try:
                            o = {
                                'InstanceId': instance['InstanceId'],
                                'InstanceType': instance['InstanceType'],
                                'Name': [x['Value'] for x in instance['Tags'] if x['Key'] == 'serviceInstanceName'][0],
                                'OwnerId': reservation['OwnerId'],
                                'LaunchTime': instance["LaunchTime"]
                            }
                            instances.append(o)
                        except Exception as e:
                            print(e)

        except ClientError:
            pass  # There is no instances in this region.
        return instances

    def get_ec2_instance_ids(self, region: str = None):
        return [instance['InstanceId'] for instance in self.get_ec2_instances(region)]

    def delete_ec2_instances(self, instance_ids: list, region: str = None):
        return self.resource('ec2', region).instances.filter(InstanceIds=instance_ids).terminate()

    def delete_all_ec2_instances(self):
        session = self.session()
        for region in session.get_available_regions('ec2'):
            instance_ids = self.get_ec2_instance_ids(region)
            self.delete_ec2_instances(instance_ids, region)

    def get_stacks(self, region: str = None, nexttoken=''):
        params = {
            'StackStatusFilter': STACK_STATUS_FILTER
        }
        if nexttoken:
            params['NextToken'] = nexttoken
        client = self.client('cloudformation', region)
        stacks = client.list_stacks(**params)
        return stacks

    def delete_stack(self, stackname, region: str = None):
        client = self.client('cloudformation', region)
        return client.delete_stack(StackName=stackname)


class AwsShell(ProviderShellBase):
    def __init__(self, access_key: str, secret_key: str, region: str = None):
        self.client = AwsClient(access_key, secret_key)
        self.regions = [x['RegionName'] for x in self.client.get_regions()]
        self.region = region
        self.ec2_cache = []
        super().__init__(ProviderCode.AWS, self.region)
        start_index = -1 if self.region is None else self.regions.index(self.region)
        self._set_region(start_index)
        self.do_regions()

    def _set_region(self, index: int):
        try:
            self.region = self.regions[int(index)]
        except:
            print(f'{index} is an invalid value')
        self._set_prompt(self.region)

    def log(self, status_code, response_body=None):
        if self.verbose:
            print(status_code)
            if response_body:
                print(response_body, '\n')

    def do_regions(self, index: int = None):
        """Changes region by index or displays all regions if no integer is given"""
        if index:
            self._set_region(index)
        else:
            self._print_table('Regions', self.regions)

    def do_ec2s(self, index=None):
        """Display ec2 instances in a region, passing in an integer will change the region"""
        if index:
            self._set_region(index)
        self.ec2_cache = self.client.get_ec2_instances(self.region)
        self._print_table("EC2's", self.ec2_cache, '\n')

    def do_delete_ec2s(self, indexes):
        """Deletes ec2 instances in a region. Integers separated by a space; for a range you can use '-' (0-9)"""
        if not self.ec2_cache:
            self.ec2_cache = self.client.get_ec2_instances(self.region)
        if indexes:
            indexes_ = indexes.split(' ')
            ids = set()
            for index in indexes_:
                range_ = index.split('-')
                range_ = [int(range_[0]), int(range_[1])] if len(range_) == 2 else [int(range_[0]), int(range_[0])]
                for i in range(range_[0], range_[1]+1):
                    try:
                        ids.add(self.ec2_cache[i]['InstanceId'])
                    except:
                        print(f'Invalid range: {range_[0]}-{range_[1]}')
                        break
            self._print_table("Delete EC2's?", ids)
            answer = input('Confirm to delete (y/N): ')
            if answer.lower() == 'y':
                print(self.client.delete_ec2_instances(list(ids), self.region))
            elif answer.lower() == 'exit':
                return self.do_exit()
            self.ec2_cache = []

    def do_get_stacks(self, index=None):
        """Displays stacks, passing in an integer will change the region"""
        if index:
            self._set_region(index)
        stack_ids = []
        stacks = self.client.get_stacks(self.region)
        for stack in stacks['StackSummaries']:
            stack_ids.append(stack['StackId'])
        self._print_table("Stacks", stack_ids, '\n')

    def do_delete_stacks(self, indexes: str = None):
        """Deletes the stacks created more than 5 days ago by e2e automation and performance automation from the specified region"""
        if indexes:
            try:
                regions = [self.regions[int(i)] for i in indexes.split(' ')]
            except:
                print('1 or more indexes is incorrect')
                regions = []
        else:
            regions = [self.region]
        last_year = datetime.now().year - 1
        five_daysago = datetime.now(tzutc()) - timedelta(days=5)
        for region in regions:
            client = self.client.client('cloudformation', region)
            stacks = client.list_stacks(StackStatusFilter=STACK_STATUS_FILTER)
            while stacks['StackSummaries']:
                for stack in stacks['StackSummaries']:
                    if ('e2esvtapi' in stack['StackName'].lower() and stack['CreationTime'] < five_daysago) or stack['CreationTime'].year == last_year or 'perf' in stack['StackName'].lower():
                        print(f"Deleting Stack: {stack['StackName']}")
                        print(client.delete_stack(StackName=stack['StackName']))
                if 'NextToken' in stacks:
                    stacks = client.list_stacks(NextToken=stacks['NextToken'], StackStatusFilter=STACK_STATUS_FILTER)
                else:
                    break

    def script_delete_perf_ec2s(self):
        for i, region in enumerate(self.regions):
            ec2s = self.client.get_ec2_instances(region)
            ids = [ec2['InstanceId'] for ec2 in ec2s if ec2['Name'].startswith('PerfUIAws')]
            if ids:
                print(self.client.delete_ec2_instances(ids, region))
            self.do_delete_stacks(str(i))

    def script_delete_e2e_ec2s(self):
        for i, region in enumerate(self.regions):
            ec2s = self.client.get_ec2_instances(region)
            ids = [ec2['InstanceId'] for ec2 in ec2s if ec2['Name'].startswith('e2esvtapi')]
            if ids:
                print(self.client.delete_ec2_instances(ids, region))
            self.do_delete_stacks(str(i))
