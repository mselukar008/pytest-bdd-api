from requests import codes

from core.payload_helper import ProviderCode
from provider_clients import ProviderShellBase
from utils.api_client_base import SimpleApiClientBase


def get_vm_tags(user: str, apikey: str, id_: str):
    tags = None
    client = IbmCloudClient(user, apikey)
    status_code, response_body = client.get_vm_tags(id_)
    if status_code == codes.OK:
        tags = response_body
    return tags


def add_vm_tags(user: str, apikey: str, id_: str, tags: dict):
    client = IbmCloudClient(user, apikey)
    status_code, response_body = client.get_vm_tags(id_)
    if status_code == codes.OK:
        updated_tags = f"{response_body[0]['tag']['name']},{','.join([f'{k}:{v}' for k, v in tags.items()])}"
        status_code, response_body = client.set_vm_tags(id_, updated_tags)
    return status_code, response_body


def delete_vm(user: str, apikey: str, id_: str):
    client = IbmCloudClient(user, apikey)
    client.delete_vm(id_)
    return True


def power_on_vm(user: str, apikey: str, id_: str):
    client = IbmCloudClient(user, apikey)
    client.power_on_vm(id_)
    return True


def power_off_vm(user: str, apikey: str, id_: str):
    client = IbmCloudClient(user, apikey)
    client.power_off_vm(id_)
    return True


def ibm_delete_all_instances(user: str, apikey: str, predicate):
    # example ibm_delete_all_instances(decrypt(user, secret), decrypt(apikey, secret), lambda x: x['domain'] == 'sl.com')
    client = IbmCloudClient(user, apikey)
    status_code, count = client.get_count()
    if status_code == codes.OK:
        for i in range(0, count, 300):
            status_code, response = client.get_all_bare_metals(i, 300)
            if status_code == codes.OK:
                for bare_metal in (response if isinstance(response, list) else [response]):
                    if predicate(bare_metal):
                        print(client.delete_bare_metal(bare_metal['id']))
            status_code, response = client.get_all_vms(i, 300)
            if status_code == codes.OK:
                for vm in (response if isinstance(response, list) else [response]):
                    if predicate(vm):
                        print(client.delete_vm(vm['id']))


class IbmCloudClient(SimpleApiClientBase):
    """
    https://sldn.softlayer.com/article/rest/
    https://sldn.softlayer.com/blog/bpotter/more-softlayer-rest-api-examples/
    https://sldn.softlayer.com/reference/services/
    """
    def __init__(self, user: str, apikey: str, logger=None):
        super().__init__('https://api.softlayer.com/rest/v3/', logger=logger)
        self.auth = (user, apikey)

    def get_count(self):
        return self.auth_get('SoftLayer_Account/countHourlyInstances', *self.auth)

    def get_bare_metal_tags(self, instance_id: str):
        return self.auth_get(f'SoftLayer_Hardware_Server/{instance_id}/getTagReferences.json', *self.auth)

    def get_all_bare_metals(self, offset=0, limit=20):
        return self.auth_get(f'SoftLayer_Account/getHardware.json?resultLimit={offset}%2C{limit}', *self.auth)

    def get_hourly_bare_metals(self, offset=0, limit=20):
        return self.auth_get(f'SoftLayer_Account/getHourlyBareMetalInstances.json?resultLimit={offset}%2C{limit}', *self.auth)

    def get_monthly_bare_metals(self, offset=0, limit=20):
        return self.auth_get(f'SoftLayer_Account/getMonthlyBareMetalInstances.json?resultLimit={offset}%2C{limit}', *self.auth)

    def delete_bare_metal(self, instance_id: str):
        return self.auth_delete(f'SoftLayer_Hardware_Server/{instance_id}.json', *self.auth)

    def get_vm_tags(self, instance_id: str):
        return self.auth_get(f'SoftLayer_Virtual_Guest/{instance_id}/getTagReferences.json', *self.auth)

    def set_vm_tags(self, instance_id: int, tags: str):
        payload = {
            'parameters': [
                tags,
                'GUEST',
                instance_id
            ]
        }
        return self.auth_post(f'SoftLayer_Tag/setTags.json', *self.auth, payload)

    def get_all_vms(self, offset=0, limit=200, object_filter='{"virtualGuests":{"domain":{"operation":"^=sl.co"},"statusId":{"operation":"1001"}}}', object_mask=None):
        return self.auth_get(f'SoftLayer_Account/getVirtualGuests.json?resultLimit={offset}%2C{limit}&objectMask={object_mask}&objectFilter={object_filter}', *self.auth)

    def get_all_hourly_vms(self):
        return self.auth_get('SoftLayer_Account/getHourlyVirtualGuests.json', *self.auth)

    def get_all_monthly_vms(self):
        return self.auth_get('SoftLayer_Account/getMonthlyVirtualGuests.json', *self.auth)

    def get_vms_active_transactions(self, instance_id: str):
        return self.auth_get(f'SoftLayer_Virtual_Guest/{instance_id}/getActiveTransactions.json', *self.auth)

    def get_vms_last_transaction(self, instance_id: str):
        return self.auth_get(f'SoftLayer_Virtual_Guest/{instance_id}/getLastTransaction.json', *self.auth)

    def delete_vm(self, instance_id: str):
        return self.auth_delete(f'SoftLayer_Virtual_Guest/{instance_id}.json', *self.auth)

    def get_all_network_storages(self, offset=0, limit=20):
        return self.auth_get(f'SoftLayer_Account/getNetworkStorage.json?resultLimit={offset}%2C{limit}', *self.auth)

    def power_on_vm(self, instance_id: str):
        return self.auth_get(f'SoftLayer_Virtual_Guest/{instance_id}/powerOn.json', *self.auth)

    def power_off_vm(self, instance_id: str):
        return self.auth_get(f'SoftLayer_Virtual_Guest/{instance_id}/powerOff.json', *self.auth)

    def power_status_vm(self, instance_id: str):
        return self.auth_get(f'SoftLayer_Virtual_Guest/{instance_id}/getPowerState.json', *self.auth)


class IbmCloudShell(ProviderShellBase):
    def __init__(self, user: str, apikey: str):
        super().__init__(ProviderCode.SOFTLAYER)
        self.client = IbmCloudClient(user, apikey)
        self.bms_cache = {}
        self.vms_cache = {}

    def do_bms(self, _):
        """Display Bare Metal instances"""
        _, self.bms_cache = self.client.get_all_bare_metals()
        self._print_table("Bare Metal's", self.bms_cache, '\n')

    def do_vms(self, _):
        """Display VM instances"""
        self._get_vms()
        self._print_table("VM's", self.vms_cache, '\n')

    def _get_vms(self):
        _, vms_cache = self.client.get_all_vms()
        self.vms_cache = [x for x in vms_cache if not (x['fullyQualifiedDomainName'].startswith('long') or x['hostname'].startswith('long'))]

    def do_delete_vms(self, indexes):
        """Deletes VM instances in a resource group. Integers separated by a space; for a range you can use '-' (0-9)"""
        if not self.vms_cache:
            self._get_vms()
        if indexes:
            indexes_ = indexes.split(' ')
            ids = set()
            for index in indexes_:
                range_ = index.split('-')
                range_ = [int(range_[0]), int(range_[1])] if len(range_) == 2 else [int(range_[0]), int(range_[0])]
                for i in range(range_[0], range_[1]+1):
                    try:
                        ids.add(self.vms_cache[i]['id'])
                    except:
                        print(f'Invalid range: {range_[0]}-{range_[1]}')
                        break
            self._print_table("Delete VM's?", ids)
            answer = input('Confirm to delete (y/N): ')
            if answer.lower() == 'y':
                for id_ in ids:
                    print(self.client.delete_vm(id_))
            elif answer.lower() == 'exit':
                return self.do_exit()
            self.vms_cache = {}

    def delete_all_vms(self, indexes):
        """Deletes VM instances in a resource group. Integers separated by a space; for a range you can use '-' (0-9)"""
        if not self.vms_cache:
            self._get_vms()
        if indexes:
            indexes_ = indexes.split(' ')
            ids = set()
            for index in indexes_:
                range_ = index.split('-')
                range_ = [int(range_[0]), int(range_[1])] if len(range_) == 2 else [int(range_[0]), int(range_[0])]
                for i in range(range_[0], range_[1]+1):
                    try:
                        ids.add(self.vms_cache[i]['id'])
                    except:
                        print(f'Invalid range: {range_[0]}-{range_[1]}')
                        break
            for id_ in ids:
                print(self.client.delete_vm(id_))
            self.vms_cache = {}

    def do_delete_bms(self, indexes):
        """Deletes Bare Metal instances in a resource group. Integers separated by a space; for a range you can use '-' (0-9)"""
        if not self.bms_cache:
            _, self.bms_cache = self.client.get_all_bare_metals()
        indexes_ = indexes.split(' ')
        ids = set()
        for index in indexes_:
            range_ = index.split('-')
            range_ = [int(range_[0]), int(range_[1])] if len(range_) == 2 else [int(range_[0]), int(range_[0])]
            for i in range(range_[0], range_[1]+1):
                try:
                    ids.add(self.bms_cache[i]['id'])
                except:
                    print(f'Invalid range: {range_[0]}-{range_[1]}')
                    break
        self._print_table("Delete VM's?", ids)
        answer = input('Confirm to delete (y/N): ')
        if answer.lower() == 'y':
            for id_ in ids:
                print(self.client.delete_bare_metal(id_))
        elif answer.lower() == 'exit':
            return self.do_exit()
        self.bms_cache = {}

    def script_delete_vms(self):
        if not self.vms_cache:
            self._get_vms()
        self.delete_all_vms(f'0-{len(self.vms_cache)-1}')
