import json
from urllib.parse import quote, urljoin

import requests
from requests import codes
from requests.auth import HTTPBasicAuth

from core.payload_helper import ProviderCode
from provider_clients import ProviderShellBase
from utils.api_client_base import SimpleApiClientBase


def get_vm_tags(tenant_id: str, subscription_id: str, client_id: str, client_secret: str, group_name: str, name: str):
    tags = None
    client = AzureClient(tenant_id, subscription_id, client_id, client_secret, group_name)
    status_code, response_body = client.get_vm(name)
    if status_code == codes.OK:
        tags = response_body['tags']
    return tags


def add_vm_tags(tenant_id: str, subscription_id: str, client_id: str, client_secret: str, group_name: str, name: str, tags: dict):
    client = AzureClient(tenant_id, subscription_id, client_id, client_secret, group_name)
    status_code, response_body = client.get_vm(name)
    if status_code == codes.OK:
        response_body['tags'].update(tags)
        status_code, response_body = client.update_vm(name, response_body)
    return status_code, response_body


def delete_vms(tenant_id: str, subscription_id: str, client_id: str, client_secret: str, group_name: str):
    client = AzureClient(tenant_id, subscription_id, client_id, client_secret, group_name)
    status_code, response_body = client.get_all_vms()
    all_good = True
    for vm in response_body['value']:
        status_code, _ = client.delete_vm(vm['name'])
        all_good &= status_code == codes.ACCEPTED
    return all_good


class AzureClient(SimpleApiClientBase):
    """
    https://docs.microsoft.com/en-us/rest/api/?view=Azure
    https://abcdazure.azurewebsites.net/how-to-authenticate-in-azure-rest-api/
    https://microsoft.github.io/AzureTipsAndTricks/blog/tip223.html
    """
    def __init__(self, tenant_id: str, subscription_id: str, client_id: str, client_secret: str, group_name: str = None):
        bearer_token = self._get_bearer_token(tenant_id, client_id, client_secret)
        super().__init__(f'https://management.azure.com/subscriptions/{subscription_id}/')
        self._headers.update({
            'Authorization': f'Bearer {bearer_token}'
        })
        self.group_name = group_name

    def _get_bearer_token(self, tenant_id, client_id, client_secret):
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        payload = '&'.join([
            'grant_type=client_credentials',
            f'client_id={client_id}',
            f'client_secret={quote(client_secret)}',
            f'resource={quote("https://management.azure.com/")}'
        ])
        response = requests.post(f'https://login.microsoftonline.com/{tenant_id}/oauth2/token', auth=HTTPBasicAuth(client_id, client_secret), headers=headers, data=payload)
        if response.status_code != codes.OK:
            raise Exception('Unable to get Azure bearer token')
        return json.loads(response.text)['access_token']

    def _build_query(self, api_version, **kwargs):
        return f'?api-version={api_version}' + '&'.join([f'{k}={v}' for k, v in kwargs if v != None])

    def _build_route(self, route: str, api_version: str, group_name: str = None, **kwargs):
        group_name_ = group_name or self.group_name
        group = f'resourceGroups/{group_name_}/' if group_name_ else ''
        return urljoin(group, f'{route}{self._build_query(api_version, **kwargs)}')

    def get_resource_groups(self):
        return self.get(f'resourcegroups{self._build_query("2020-06-01")}')

    def get_all_vms(self, group_name: str = None):
        route = self._build_route('providers/Microsoft.Compute/virtualMachines', '2019-12-01', group_name)
        print(route)
        return self.get(route)

    def get_vm(self, name: str, group_name: str = None):
        route = self._build_route(f'providers/Microsoft.Compute/virtualMachines/{name}', '2019-12-01', group_name)
        return self.get(route)

    def update_vm(self, name: str, payload: dict, group_name: str = None):
        route = self._build_route(f'providers/Microsoft.Compute/virtualMachines/{name}', '2019-12-01', group_name)
        return self.put(route, payload)

    def delete_vm(self, name: str, group_name: str = None):
        route = self._build_route(f'providers/Microsoft.Compute/virtualMachines/{name}', '2019-12-01', group_name)
        return self.delete(route)


class AzureShell(ProviderShellBase):
    def __init__(self, tenant_id, subscription_id, client_id, client_secret, group_name):
        self.client = AzureClient(tenant_id, subscription_id, client_id, client_secret, group_name)
        _, response = self.client.get_resource_groups()
        self.groups = [{"name": x["name"], "location": x["location"]} for x in response['value']]
        self.vms_cache = {}
        super().__init__(ProviderCode.AZURE)
        index = [i for i, x in enumerate(self.groups) if group_name == x["name"]]
        self._set_group(index[0] if index else 0)
        self._print_groups_table()

    def _print_groups_table(self):
        return self._print_table('Resource Groups', [f'{x["name"]} -> {x["location"]}' for x in self.groups])

    def _set_group(self, index: int):
        try:
            self.group = self.groups[int(index)]
        except:
            print(f'{index} is an invalid value')
        self._set_prompt(f'{self.group["name"]} -> {self.group["location"]}')

    def do_groups(self, index):
        """Changes resource group by index or displays all resource groups if no integer is given"""
        if index:
            self._set_group(index)
        else:
            self._print_groups_table()

    def do_vms(self, index):
        """Display VM instances in a resource group, passing in an integer will change the resource group"""
        if index:
            self._set_group(index)
        _, self.vms_cache = self.client.get_all_vms(self.group["name"])
        self._print_table("VM's", self.vms_cache['value'], '\n')

    def do_delete_vms(self, indexes):
        """Deletes VM instances in a resource group. Integers separated by a space; for a range you can use '-' (0-9)"""
        if not self.vms_cache:
            _, self.vms_cache = self.client.get_all_vms(self.group["name"])
        if indexes:
            indexes_ = indexes.split(' ')
            names = set()
            for index in indexes_:
                range_ = index.split('-')
                range_ = [int(range_[0]), int(range_[1])] if len(range_) == 2 else [int(range_[0]), int(range_[0])]
                for i in range(range_[0], range_[1]+1):
                    try:
                        names.add(self.vms_cache['value'][i]['name'])
                    except:
                        print(f'Invalid range: {range_[0]}-{range_[1]}')
                        break
            self._print_table("Delete VM's?", names)
            answer = input('Confirm to delete (y/N): ')
            if answer.lower() == 'y':
                for name in names:
                    print(self.client.delete_vm(name, self.group["name"]))
            elif answer.lower() == 'exit':
                return self.do_exit()
            self.vms_cache = {}