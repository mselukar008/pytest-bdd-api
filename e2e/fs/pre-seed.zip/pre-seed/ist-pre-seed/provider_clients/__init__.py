from cmd import Cmd

from core.payload_helper import ProviderCode


class ProviderSwitchException(Exception):
    def __init__(self, *args: object):
        self.name = args[0]


class ProviderShellBase(Cmd):
    valid_providers = [ProviderCode.AWS, ProviderCode.AZURE, ProviderCode.SOFTLAYER]
    def __init__(self, name: str, scope: str = None):
        if type(self) == ProviderShellBase:
            raise Exception(f'Do not instantiate base: {ProviderShellBase.__name__}')
        self.name = name
        self.intro = f'Welcome to the {name} shell.   Type help or ? to list commands.\n'
        self.verbose = False
        self._set_prompt(scope)
        super().__init__(completekey='tab', stdin=None, stdout=None)

    def _set_prompt(self, scope: str = None):
        if scope:
            self.prompt = f'({self.name} {scope}) '
        else:
            self.prompt = f'({self.name}) '

    def _print_table(self, header: str, list_: list, delimiter=' | '):
        print(f'\n{header}:')
        print(delimiter.join(f'{i}: {x}' for i, x in enumerate(list_)))
        print('--------------------------------\n')

    def do_verbose(self, value=None):
        """value: str = y, n"""
        if value:
            self.verbose = value.lower() == 'y'
        else:
            print(f'Verbose is {"On" if self.verbose else "Off"}')

    def do_provider(self, provider_code):
        """Switch to another provider
        provider_code: str = aws, azure, ibmcloud"""
        if provider_code in self.valid_providers:
            raise ProviderSwitchException(provider_code)
        else:
            print(f'{provider_code} is not valid; please use one of {self.valid_providers}')

    def do_exit(self, inp=None):
        """exits"""
        print("Bye")
        return True

    def script(self, name: str):
        getattr(self, f'script_{name}')()
