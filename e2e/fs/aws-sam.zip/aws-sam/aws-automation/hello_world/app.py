import json
import boto3
import os
# import requests


def lambda_handler(event, context):
    s3 = boto3.client('s3')

    try:
        s3.upload_file("C:\\Users\\MahendraSelukar\\Downloads\\uat-db.csv", os.environ['BUCKET_NAME'], "tdm_data.csv")
        url = s3.generate_presigned_url(
            ClientMethod='get_object',
            Params={
                'Bucket': os.environ['BUCKET_NAME'],
                'Key': "tdm_data.csv"
            },
            ExpiresIn=24 * 3600
        )

        print("Upload Successful", url)
        return url
    except FileNotFoundError:
        print("The file was not found")
        return None
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('File Uploaded Succesfully!')
    }

