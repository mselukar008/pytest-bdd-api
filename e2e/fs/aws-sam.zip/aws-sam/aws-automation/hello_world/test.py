# import pandas as pd
import pymongo
import json
import os
import s3fs
import io


def test1():
    # Init ...
    # print("The event details are : ", json.dumps(event))
    response_data = {}
    database = os.environ.get("DB_NAME")
    collection = os.environ.get("COLLECTION_NAME")
    bucket = "tdm-postgres"
    db_uri = os.environ.get("MONGO_CLIENT_URI")
    s3 = s3fs.S3FileSystem()

    all_files = list(s3.glob(bucket + '/s3_output/csv/*/*.csv'))
    # print(all_files)
    try:
        # client = MongoClient(db_uri)
        # db = client[database]
        # col = db[collection]
        for file in all_files:
            #df = pd.read_csv("s3://" + file)
            # payload = json.loads(df.to_json(orient='records'))
            # col.insert_many(payload)
            print(file)

        return {
            'statusCode': 200,
            'body': json.dumps('Inserted records succesfully')
        }
    except Exception as e:
        print("Operation failed...")
        print(str(e))

