// jest-playwright.config.js

module.exports = {   
    collectCoverage:true,    
    exitOnPageError: false,     
    browsers: ["chromium"],
    serverOptions: {
        command: "npm start",
        port: 3000,
        launchTimeout: 10000,
        debug: true,
        options: {
          env: {
            E2E_TESTS: "true"            
          }
        }
    },
    launchType: "LAUNCH", 
    launchOptions: {
        channel:'chrome', //This is supported for chromium. Options are 'chrome' or 'msedge', 'chrome-beta', 'msedge-beta', 'msedge-dev', etc.
        headless: true,
        //slowMo: 50
        //For execution of local browsers
        //executablePath:"/home/mahendra/Downloads/firefox/firefox",
        //args: ['-height=1280', '-width=650']
    },
    contextOptions: {
        ignoreHTTPSErrors: true,
        viewport:null,       
        // viewport: {
        //   width: 1280,
        //   height: 650
        // },     
        
        recordVideo:{
            dir:'./Reports/videos/'
        }
    },
                   
    // Local Test Configuration Parameters   
    environment:"https://mcmp-stagedal-master-autoui.multicloud-ibm.com",
    //environment:"https://mcmp-dev2fra-release-autoui.multicloud-ibm.com/",
    userName:"uiautomcmpuser@outlook.com",
    password:"Automcmpuser@00",
    isDummyAdapterDisabled:"false",
    isProvisioningRequired:"true",
    defaultCurrency:"USD",
    skipImiConfig:"false",
    postSlack:"false",
    postSlackWebhookURL:"https://hooks.slack.com/services/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",
    buildURL:"Playright -1",
    testSuitList:"compute,pubSub,cloudstorage,persistentDisk,tcpLoadBalncer,udpLoadBalncer,cloudSpanner,cloudDns,vpc"
    //testSuitList:"pubSub"
    //Jenkins test parameters
    // testSuitList : process.env.testSuitList,
    // environment : process.env.Environment,
    // userName : process.env.UserName,
    // password : process.env.Password,
    // isDummyAdapterEnabled : process.env.isDummyAdapterEnabled,
    // isProvisioningRequired : process.env.isProvisioningRequired,
    // defaultCurrency : process.env.defaultCurrency,
    // skipImiConfig : process.env.skipImiConfig,
    // postToSlack : process.env.postToSlack
}