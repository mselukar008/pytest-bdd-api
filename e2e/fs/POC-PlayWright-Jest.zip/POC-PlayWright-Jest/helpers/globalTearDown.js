const util = require('./util');

module.exports = async function globalTeardown(){
    require('../helpers/integrationUtils');
    //Post Text report to slack
    await postToSlack();
    //post html report to slack
    await slackJunitHtmlReport();
    //delete cookies file
    await util.deleteFile('./Cookies/state.json');    
}