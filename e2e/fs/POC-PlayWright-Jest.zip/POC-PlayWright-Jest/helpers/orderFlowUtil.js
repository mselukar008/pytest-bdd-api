"use strict";
const testConfig = require('../jest-playwright.config');
const logGenerator = require('./logGenerator');
const reviewOrderPageParamsXpath = "//*[@class='order-summary-stats__item bx--structured-list-row']/span[1]";
const reviewOrderPageParamsValues = "//*[@class='order-summary-stats__item bx--structured-list-row']/span[2]";
const fileDwnldMsgCss = '.bx--inline-notification__subtitle span';

exports.orderFlowUtil = class orderFlowUtil{
    constructor(Page) {
        this.page = Page;
    };

    async fillOrderDetails(jsonTemplate, modifiedParamMap) {    
              
        var requiredReturnMap = {}, expectedMap = {}, actualMap = {};
        var jsonObject;
        var self=this;
        //Handling for the scenarios that dont need Main Parameter object
        if (modifiedParamMap["UpdateMainParamObject"] == false) {
            jsonObject = JSON.parse(JSON.stringify(jsonTemplate));
        } else {
            jsonObject = JSON.parse(JSON.stringify(await self.getMainParameterObject(jsonTemplate, modifiedParamMap)));
        }
           
        //Delete Configure Add-ons key if imi configuration needs to be skipped
        if (testConfig.skipImiConfig != undefined && testConfig.skipImiConfig == "true") {
            delete jsonObject["Order Parameters"]["Configure Add-ons"];
        }
    
        var elem = null;
        var elemName;
        var fillImiDetails = "false";
    
        // Adding below condition for Provisioning/Edit/Custom operations  flows
        var orderParameters, jsonObjectForParameters;
        if (modifiedParamMap["EditService"] == true) {
            orderParameters = Object.keys(jsonObject["Edit Parameters"]);
            jsonObjectForParameters = jsonObject["Edit Parameters"];
        } else if (modifiedParamMap["dynamicValidation"] == true) {
            orderParameters = Object.keys(jsonObject["Dynamic Parameters"]);
            jsonObjectForParameters = jsonObject["Dynamic Parameters"];
        } else if (modifiedParamMap["CustomOperation"] == true) {
            orderParameters = Object.keys(jsonObject["Custom Operation Parameters"]);
            jsonObjectForParameters = jsonObject["Custom Operation Parameters"];
        }
        else {
            orderParameters = Object.keys(jsonObject["Order Parameters"]);
            jsonObjectForParameters = jsonObject["Order Parameters"];
        }
                  
        for await (var detailSection of Object.keys(orderParameters)){
            var webElements = Object.keys(jsonObjectForParameters[orderParameters[detailSection]]);
            for await (var webElement of Object.keys(webElements)){
                //Default value to fetch is from QA 4 Key	
                var environment = "QA 4";
                var webElementObject = Object.keys(jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]]);
                var elementType = Object.values(jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]][webElementObject[0]]).join("");
                var elementID = Object.values(jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]][webElementObject[1]]).join("");
                var elementValue = Object.values(jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]][webElementObject[2]][environment]).join("");
                elem = elementID;
                elemName = webElements[webElement];
                if (modifiedParamMap != undefined) {
                    if (Object.keys(modifiedParamMap).includes(webElements[webElement]))
                        elementValue = modifiedParamMap[webElements[webElement]];                
                }
                if (elementValue != "") {
                    if (elementType == "Dropdown") {                       
                        await commonUiMethods.selectDropdownValueBasedOnName(elementID, elementValue, elemName).then(function(){
                        }).catch(async function(err){
                            //Retry 
                            await commonUiMethods.selectDropdownValueBasedOnName(elementID, elementValue, elemName);
                        });                      
                        expectedMap[webElements[webElement].trim()] = elementValue.trim();                                               
                    }
                    if (elementType == "RadioButton" || elementType == "CheckBox") {
                        //await commonUiMethods.check("label[for=\"" + elementID + "\"]", elemName, elementValue).then(async function(){ 
                        await commonUiMethods.check("label[for=\"" + elementID + "\"]", elemName, elementValue).then(async function(){
                        }).catch(async function(err){
                            await commonUiMethods.fclick("label[for=\"" + elementID + "\"]", elemName);
                        });
                        //await commonUiMethods.fclick("label[for=\"" + elementID + "\"]", elemName);
                        expectedMap[webElements[webElement].trim()] = elementValue.trim();                       
                    }
                    if (elementType == "Textbox") {
                        await commonUiMethods.sendKeys("id=" + elementID, elementValue, elemName);
                        expectedMap[webElements[webElement].trim()] = elementValue.trim();                        
                    }                   
                    if (elementType == "MultiselectDropdown") {
                        var multiElementValue = jsonObjectForParameters[orderParameters[detailSection]][webElements[webElement]][webElementObject[2]][environment];
                        var n = multiElementValue.toString().search(",");
                        var multiElementValueArray;

                        if (n != -1) {
                            multiElementValueArray = multiElementValue.toString().split(",");
                        } else {
                            multiElementValueArray = [multiElementValue];
                        }
                        //Click on Dropdown
                        await self.page.frame(mcmpIframe).click("#" + elementID);
                        await Reporter.info("Clicked on Multiselect dropdown - " + elemName);

                        for (var i = 0; i < multiElementValueArray.length; i++) {
                            await self.page.frame({
                                name: 'mcmp-iframe'
                            }).click("//label[title='" + multiElementValueArray[i] + "']");
                            expectedMap[webElements[webElement].trim()] = multiElementValueArray.toString().trim();
                            await Reporter.info("Selected value from multiselect dropdown - " + multiElementValueArray[i]);
                        }
                        //Reset Dropdown
                        await self.page.frame(mcmpIframe).click("#" + elementID);
                    }
                    if (elementType == "SearchList") {
                        //Open dropdown having search option
                        var searchListIds = elementID.split(",");
                        await self.page.frame(mcmpIframe).click("#" + searchListIds[0]);
                        await Reporter.info("Clicked on dropdownsearch" + elemName);
                        //enter value in search field
                        await self.page.frame(mcmpIframe).fill("#" + searchListIds[1]);
                        //Hit enter button
                        await self.page.press("#" + searchListIds[1], 'Enter');
                        //Select Value
                        await self.page.frame(mcmpIframe).click("text=" + elementValue);
                        expectedMap[webElements[webElement].trim()] = elementValue.trim();
                        await Reporter.info("Selected value from Dropdown search - " + elementValue.trim());

                    } 
                    if (elementType == "DropdownSearch") {                       
                        await self.page.frame(mcmpIframe).click("//*[@id='" + elementID + "' or @id = '" + elementID.toLowerCase() + "']/div//div"),
                        await self.page.frame(mcmpIframe).click("text=" + elementValue),
                        await Reporter.info("Selected value from Dropdown search - " + elementValue.trim());
                        expectedMap[webElements[webElement].trim()] = elementValue.trim();
                    }                  
                    if (elementType == "Button") {
                        //Fix for UI change of button element                   
                        var n = elementID.startsWith("button-");
                        if (n) {
                            elementID = elementID.replace("button-", "");
                        }
                        await commonUiMethods.fclick("[id*='" + elementID + "']", elemName)                                              
                    }                    
                    if (elementType == "InputOptions") {                        
                        await commonUiMethods.fclick("#" + elementID + " input[value='" + elementValue + "'] ~ .bx--tile-content", elemName); 
                    }
                    if (elementType == "VerifyText") {
                        var expTxt = elementValue; 
                        return await commonUiMethods.getText(fileDwnldMsgCss).then(function (actText) {
                            expect(actText).toContain(expTxt);
                        });
                    }
                    if (elementType == "SearchListWithMultiSelect") {
                        var multiElementValue = Object.values(jsonObject["Order Parameters"][orderParameters[detailSection]][webElements[webElement]][webElementObject[2]][environment]);
                        var multiElementValueArray = multiElementValue.toString().split(",");
                        await self.page.frame(mcmpIframe).fill("#" + elementID);
                        for (var i = 0; i < multiElementValueArray.length; i++) {
                            await self.page.frame(mcmpIframe).click("text=" + multiElementValueArray[i]);
                            console.log("MultiSelectList-", "Info", "Clicked on checkbox " + multiElementValueArray[i] + " from " + webElements[webElement] + " multi-select dropdown");
                            expectedMap[webElements[webElement].trim()] = multiElementValueArray.toString().trim();
                        }
                        await self.page.frame(mcmpIframe).click("#" + elementID);

                        await self.page.frame(mcmpIframe).press("#" + elementID, "TAB");
                    }                
                 }
            }
            if (elemName != "IMI") {
                if (fillImiDetails == "false") {
                    await commonUiMethods.sleep(2000);
                    await placeOrderPage.clickNextButton();
                } else {
                    //workarounf for review order page
                    if (elemName != "Next") {
                        if (elemName == "saveCartIMI") {
                            await placeOrderPage.clickOnAddOnSaveBtn();
                        }
                        else {
                            await placeOrderPage.clickNextBtnImiConfiguration();
                        }    
                    }
                }
            } else {
                fillImiDetails = "true";
            }
        }    
         
        if (modifiedParamMap["dynamicValidation"] == true) {
            console.log("Order cannot  be continued due to dynamic Validation error ")
        }
        else {
            if (modifiedParamMap["skipRevierOrderValidation"] != true) {
                //Get details of service configuration on review order page
                                
                var orderSummaryParams = await commonUiMethods.getTextArray(reviewOrderPageParamsXpath);
                var orderSummaryValues = await commonUiMethods.getTextArray(reviewOrderPageParamsValues);
               
                for (var i = 0; i < orderSummaryParams.length; i++) {                    
                    actualMap[orderSummaryParams[i].split(":")[0].trim()] = orderSummaryValues[i].trim();
                }
                
                requiredReturnMap["Actual"] = actualMap;
                requiredReturnMap["Expected"] = expectedMap;
            }
        }
       
        return requiredReturnMap;          

    };
    
    async getMainParameterObject(serviceDataTemplate, modifiedParamMap) {
    
        var mainParamDataObj = JSON.parse(JSON.stringify(serviceDataTemplate));
        var providerAccount = mainParamDataObj["Order Parameters"]["Main Parameters"]["Provider Account"]["value"]["QA 4"];
    
        if (Object.keys(modifiedParamMap).includes("Provider Account")) {
            providerAccount = modifiedParamMap["Provider Account"];
        }
        providerAccount = providerAccount.replace(" /", "_/");
    
        var providerAccountId = "radio-button-providerAccount_" + providerAccount;
        var env, app, team;
    
        //Handling for budgetary tests
        if (modifiedParamMap != undefined) {
            if (Object.keys(modifiedParamMap).includes("Environment")) {
                env = modifiedParamMap["Environment"];
                app = modifiedParamMap["Application"];
            } else {
                env = "NONE";
                app = "NONE";
            }
    
            if (Object.keys(modifiedParamMap).includes("Team")) {
                team = modifiedParamMap["Team"];
            } else {
                //team = "TEAM1";
                team = "Auto-TEAM1";
            }
    
        }
        var envId = "env";
        var appId = "app";
        var teamId = "radio-button-team_" + team;
    
        mainParamDataObj["Order Parameters"]["Main Parameters"]["Service Instance Prefix"] = {
            "type": "Textbox",
            "id": "text-input-main_params-serviceName",
            "value": {
                "QA 1": "TestAutomation",
                "QA 2": "TestAutomation",
                "QA 4": "TestAutomation",
                "Customer 1": "TestAutomation"
            }
        };
        mainParamDataObj["Order Parameters"]["Main Parameters"]["Quantity"] = {
            "type": "Textbox",
            "id": "number-input-main-params_multi-quantity",
            "value": {
                "QA 1": "",
                "QA 2": "",
                "QA 4": "",
                "Customer 1": ""
            }
        };
        mainParamDataObj["Order Parameters"]["Main Parameters"]["Team"] = {
            "type": "RadioButton",
            "id": teamId,
            "value": {
                "QA 1": team,
                "QA 2": team,
                "QA 4": team,
                "Customer 1": team
            }
        };
        mainParamDataObj["Order Parameters"]["Main Parameters"]["Environment"] = {
            "type": "DropdownSearch",
            "id": envId,
            "value": {
                "QA 1": env,
                "QA 2": env,
                "QA 4": env,
                "Customer 1": env
            }
        };
        mainParamDataObj["Order Parameters"]["Main Parameters"]["Application"] = {
            "type": "DropdownSearch",
            "id": appId,
            "value": {
                "QA 1": app,
                "QA 2": app,
                "QA 4": app,
                "Customer 1": app
            }
        };
        mainParamDataObj["Order Parameters"]["Main Parameters"]["Provider Account"] = {
            "type": "RadioButton",
            "id": providerAccountId,
            "value": {
                "QA 1": providerAccount,
                "QA 2": providerAccount,
                "QA 4": providerAccount,
                "Customer 1": providerAccount
            }
        };
        mainParamDataObj["Order Parameters"]["Main Parameters"]["Cart Service"] = {
            "type": "CheckBox",
            "id": "checkbox-useShoppingCart",
            "value": {
                "QA 1": "",
                "QA 2": "",
                "QA 4": "",
                "Customer 1": ""
            }
        };
        mainParamDataObj["Order Parameters"]["Main Parameters"]["New Shopping Cart"] = {
            "type": "InputOptions",
            "id": "cartGroup",
            "value": {
                "QA 1": "",
                "QA 2": "",
                "QA 3": "",
                "QA 4": "",
                "Customer 1": ""
            }
        };
        mainParamDataObj["Order Parameters"]["Main Parameters"]["Cart Name"] = {
            "type": "Textbox",
            "id": "text-input-main_params-cartName",
            "value": {
                "QA 1": "",
                "QA 2": "",
                "QA 3": "",
                "QA 4": "",
                "Customer 1": ""
            }
        };
    
        return mainParamDataObj;
    
    };    
}
