"use strict";

const logGenerator = require('./logGenerator'),
logger = logGenerator.getApplicationLogger();
const buttonCloseServiceDetailSliderCss = '[class="is-active"] button.bx--slide-over-panel--close';
const moreLink = 'button:has-text("More")';
const addnDetailsParameters = '.order-summary-stats label:visible';
const addnDetailsParamsValues = '.order-summary-stats p:visible'; 
const oneTimeChargesBOMTableXpath = '//tr//td[contains(@class,"data-number")][4]';
const currentBom = '[id*="non-one-time-charge_parent"]'

exports.pageObjectCommonMethods = class pageObjectCommonMethods{
    constructor(Page) {
        this.page = Page;
    };

    async clickServiceDetailSliderCloseButton (counter) {
        var self = this;
        var count = 1;
        if(counter == undefined){
            counter = 3
        }
        
        var res = await this.page.frame(mcmpIframe).isVisible(buttonCloseServiceDetailSliderCss, { timeout : timeOuts.element })
        if (res) {
            while(count <= counter){
                try {
                    await commonUiMethods.fclick(buttonCloseServiceDetailSliderCss, "Close Service Details window").then(async function(){
                        counter = 0;
                        return;
                    });                    
                } catch (error) {
                    logger.info("Service details close button not displayed");			
					counter = counter - 1;
					await self.clickServiceDetailSliderCloseButton(counter);
                }
            }
        }
        else {
            logger.info("Slider is already closed");
        }         
    };

    async validateorderDetails(expectedValuesMap, pageName) { 
        var expctdParams = Object.keys(expectedValuesMap["Expected"]);      
        var actualParamsMap={};
        var addnDetailsParams = await commonUiMethods.getElementsList(addnDetailsParameters);
        var addnDetailsParamValues = await commonUiMethods.getElementsList(addnDetailsParamsValues);
                
        var serviceParam, paramValue;
        for (var i = 0; i < addnDetailsParams.length; i++) {
            serviceParam =  await addnDetailsParams[i].innerText();
            paramValue = await addnDetailsParamValues[i].innerText();
            actualParamsMap[serviceParam.trim()] = paramValue.trim();
        }

        //Compare Expected and Actual Values of service configuration
        var actMap = Object.keys(actualParamsMap)
        for (var i = 0; i < expctdParams.length; i++) {
            if(actualParamsMap[expctdParams[i]] != undefined){
                var expValue = expectedValuesMap["Expected"][expctdParams[i]];
                var actValue = actualParamsMap[expctdParams[i]];
                        
                if (expValue == actValue) {
                    await Reporter.info(pageName + " page service configuration parameter -> " + expctdParams[i] + " = " + actValue);                    
                } else if (expValue.includes(actValue)) {
                    await Reporter.info(pageName + " page service configuration parameter -> " + expctdParams[i] + " = " + actValue);                   
                }
                else {
                    await Reporter.info(pageName + " page service configuration parameter - Actual --> " + expctdParams[i] + " = " + actValue + " | Expected --> " + expctdParams[i] + " = " + expValue);
                    return false;
                }
            }            
        }
        return true;
    }
    
    async getBOMTablePrice () {        
        await commonUiMethods.fclick(moreLink, "More Link")
        var total = 0.000;
        var cost = 0.000;
                  
        try {
            var txtArry = await commonUiMethods.getTextArray(oneTimeChargesBOMTableXpath);            
            for (var i = 0; i < txtArry.length; i++) {
                cost = txtArry[i].replace("USD ", "");
                total = total + parseFloat(parseFloat(cost).toFixed(3));
            };
            logger.info("Total price of BOM table is USD " +  total);           
            return ("USD " +  total);  
        } catch (error) {
            logger.info(error);
            return "";                
        }
        
    
    }

    async getCurrentBOMTablePrice () {
               
        var total = 0.000;
        var cost = 0.000;
                  
        try {
            var txtArry = await commonUiMethods.getTextArray(currentBom);            
            for (var i = 0; i < txtArry.length; i++) {
                cost = txtArry[i].replace("USD ", "");
                total = total + parseFloat(parseFloat(cost).toFixed(3));
            };
            logger.info("Total price of BOM table is USD " +  total);           
            return ("USD " +  total);  
        } catch (error) {
            logger.info(error);
            return "";                
        }
        
    
    }

}    