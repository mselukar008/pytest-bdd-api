var fs = require('fs');
var logGenerator = require('../helpers/logGenerator'),
logger = logGenerator.getApplicationLogger();
var orderIdfile = './Reports/orderId.json';

async function getFrame(page){
    var pageWithFrame;
    pageWithFrame = await page.frame({
        name: 'mcmp-iframe'
    });
    return pageWithFrame;
};

function getRandomString(charLength) {
	var randomText = "";
	var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	for (var i = 0; i < charLength; i++)
		randomText += possible.charAt(Math.floor(Math.random() * possible.length));
	return randomText;
};

async function saveOrderId(serviceName, operationName, orderId) {
	var serviceInstance = {
		"service": {
			"operation": orderId
		}
	};

	serviceInstance["service"][operationName] = serviceInstance["service"]["operation"];
	delete serviceInstance["service"]["operation"];
	serviceInstance[serviceName] = serviceInstance["service"];
	delete serviceInstance["service"];
	
	var objData = serviceInstance[serviceName];
	var read_data = await readFile(orderIdfile);	
	if (read_data == false) {
		logger.info('Unable to read data from orderId file, creating new.');
		var dataWrittenStatus = await writeFile(orderIdfile, serviceInstance);		
	}
	else {	
		if (read_data[serviceName] != undefined){
			read_data[serviceName][operationName] = orderId;
		}else{
			read_data[serviceName] = objData;
		}
		var dataWrittenStatus = await writeFile(orderIdfile, read_data);			
		if (dataWrittenStatus == true) {
			logger.info('order Id added successfully for operation ' + operationName);
		}
		else {
			logger.info('Unable to add order Id for operation ' + operationName);
		}		
	}
};

async function readFile(filePath) {
	try {
		const data = await fs.promises.readFile(filePath, 'utf8');		
		return JSON.parse(data)
	}
	catch (err) {
		return false;
	}
}

async function writeFile(filename, writedata) {
	try {
		await fs.promises.writeFile(filename, JSON.stringify(writedata, null, 4), 'utf8');		
		return true
	}
	catch (err) {
		return false
	}
}

async function deleteFile (file) {
	try {
		fs.unlinkSync(file)
		logger.info("Succesfully Deleted file " + file)
	} catch(err) {
		console.error(err)
		logger.info("Unable to delete file " + file)
	}
}

function generateRuntimeSpecString(suitesList) {
	var specArray = [];
	var suitesArray = suitesList.split(",");
	var suitesLength = suitesArray.length;
	for (var i = 0; i < suitesLength; i++) {
		//AWS Specsfile
		if (suitesArray[i] == "aws")			
			specArray.splice(i, 0, "<rootDir>/e2e/tests/orderIntegration/aws/" + '*.spec.js',);
		if (suitesArray[i] == "ec2AWS")			
			specArray.splice(i, 0, "<rootDir>/e2e/tests/orderIntegration/aws/ec2.spec.js");
		//GCP Specs
		if (suitesArray[i] == "gcp")
			specArray.splice(i, 0, "<rootDir>/e2e/tests/orderIntegration/gcp/" + '*.spec.js',);
		if (suitesArray[i] == "compute")
			specArray.splice(i, 0, "<rootDir>/e2e/tests/orderIntegration/gcp/compute.spec.js");
		if (suitesArray[i] == "pubSub")
			specArray.splice(i, 0, "<rootDir>/e2e/tests/orderIntegration/gcp/pubSub.spec.js");
		if (suitesArray[i] == "cloudstorage")
			specArray.splice(i, 0, "<rootDir>/e2e/tests/orderIntegration/gcp/cloudstorage.spec.js");
		if (suitesArray[i] == "persistentDisk")
			specArray.splice(i, 0, "<rootDir>/e2e/tests/orderIntegration/gcp/persistentdisk.spec.js");
		if (suitesArray[i] == "tcpLoadBalncer")
			specArray.splice(i, 0, "<rootDir>/e2e/tests/orderIntegration/gcp/tcpLb.spec.js");
		if (suitesArray[i] == "udpLoadBalncer")
			specArray.splice(i, 0, "<rootDir>/e2e/tests/orderIntegration/gcp/udpLb.spec.js");
		if (suitesArray[i] == "cloudSpanner")
			specArray.splice(i, 0, "<rootDir>/e2e/tests/orderIntegration/gcp/spanner.spec.js");
		if (suitesArray[i] == "cloudDns")
			specArray.splice(i, 0, "<rootDir>/e2e/tests/orderIntegration/gcp/dns.spec.js");		
		if (suitesArray[i] == "vpc")
			specArray.splice(i, 0, "<rootDir>/e2e/tests/orderIntegration/gcp/vpc.spec.js");
				
			
	}
	return specArray;
}

module.exports = {
    getFrame : getFrame,
    saveOrderId:saveOrderId,
	readFile:readFile,
	writeFile:writeFile,
	deleteFile:deleteFile,
	getRandomString:getRandomString,
	generateRuntimeSpecString:generateRuntimeSpecString	
}