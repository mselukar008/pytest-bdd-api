"use strict";

const logGenerator = require('./logGenerator'),
logger = logGenerator.getApplicationLogger();

exports.commonMethods = class commonMethods{
    constructor(Page) {
        this.page = Page;
    };

    //Static wait
    async sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    };
        
    //Click on elemnts inside frame
    async fclick(elmLocator, elemName){ 
        //Adding static wait of 1s before click event as playwright does it very fast
        await Promise.all([
             this.sleep(1000),
             this.syncWithUi(),
             this.page.frame(mcmpIframe).click(elmLocator),              
             this.page.frame(mcmpIframe).waitForLoadState(),
             Reporter.info("Clicked on " + elemName)
         ])        
    }
     //Click on elemnts without any frame
    async click(elmLocator, elemName){
        await this.sleep(1000);                  
        await this.page.click(elmLocator);
        await this.page.waitForLoadState();
        await Reporter.info("Clicked on " + elemName);
    }
    //type value in textbox and hit enter button
    async sendKeysEnter(elmLocator, elemName, value) {        
        await this.syncWithUi(),        
        await this.page.frame(mcmpIframe).waitForSelector(elmLocator, { timeout:timeOuts.element }),
        await this.page.frame(mcmpIframe).fill(elmLocator, value),
        await this.waitForLoaderToComplete(),
        await this.page.frame(mcmpIframe).press(elmLocator, "Enter", { timeout : timeOuts.element}),        
        await Reporter.info("Entered value : " +  value + " in textbox : " + elemName)        
    }
    //Entering text in textbox
    async sendKeys(elmLocator, value, elemName) {
        await Promise.all([
             this.syncWithUi(),
             this.page.frame(mcmpIframe).waitForSelector(elmLocator, {timeout:timeOuts.element}),
             this.page.frame(mcmpIframe).fill(elmLocator, value),
             this.waitForLoaderToComplete(),       
             Reporter.info("Entered value : " +  value + " in textbox : " + elemName)
        ])        
    }
    //Selecting values from dropdown
    async selectDropdownValue(elmLocator, value, elemName){ 
        var self=this;
        await Promise.all([
             this.syncWithUi(),
             this.page.frame(mcmpIframe).click(elmLocator),      
             this.page.frame(mcmpIframe).click("text="+value),
             Reporter.info("Selected value from dropdown " + elemName + " : " + value)
        ])    
        
    }

    async selectDropdownValueBasedOnName(elementID, value, elemName){ 
        var self=this;
        var dropDownVal,valueSelected;
        await Promise.all([
             this.syncWithUi(),
             this.page.frame(mcmpIframe).click("[id=\"" + elementID + "\"]"),
             this.page.frame(mcmpIframe).waitForLoadState()
        ])      
        var dropDownList = await this.page.frame(mcmpIframe).$$("//*[@id='" + elementID + "']//carbon-dropdown-option//li")
        for await (var dropdown of dropDownList){        
            dropDownVal =  await dropdown.innerText();
            if(dropDownVal == value){
                await dropdown.click();
                await Reporter.info("Selected value from dropdown " + elemName + " : " + value);
                valueSelected = true;
            }            
        }
        //Select first element if no matching element found
        if(valueSelected != true){
            await dropDownList[0].click();
        }
      
    }

    //For Selecting RadioButtons and checkbox
    async check(elemLocator, elemName, value){
        await Promise.all([
             this.syncWithUi(),
             this.page.frame(mcmpIframe).waitForSelector(elemLocator, {timeout:timeOuts.element}),
             this.page.frame(mcmpIframe).check(elemLocator),
             this.waitForLoadState("networkidle"),
             Reporter.info("Checked " + elemName + " as " +  value)
        ])
        
    }
    //Select values by searching
    async selectBySearchingValue(elemLocator, value){
        await this.page.frame(mcmpIframe).type(elemLocator, value),
        await Reporter.info("Checked " + elemName);
    }

    //Get text of element
    async getText(elmLocator, elmName){         
        await this.page.frame(mcmpIframe).waitForSelector(elmLocator, { timeout:timeOuts.element });
        var elem = await this.page.frame(mcmpIframe).$(elmLocator);
        var txt = await elem.innerText();
        if(elmName != undefined){
            await Reporter.info(elmName  + " : " + txt);
        }        
        return txt;
    }

    //Return all matching elements collection based on locator
    async getElementsList(elmLocator){
        //Wait till page loads completely
        await this.syncWithUi();        
        await this.page.frame(mcmpIframe).waitForSelector(elmLocator, {timeout:timeOuts.element});
        return await this.page.frame(mcmpIframe).$$(elmLocator);
    }

    //Get specific attribute of webelement
    async getAttribute(elemLocator, attrbtName) {        
        await this.page.waitForSelector(elemLocator, {timeout : timeOuts.element});
        return await this.page.getAttribute(elemLocator, attrbtName);
    }

    //Get specific attribute of webelement on frame
    async fgetAttribute(elemLocator, attrbtName) {
        await this.syncWithUi();
        await this.page.frame(mcmpIframe).waitForSelector(elemLocator, {timeout : timeOuts.element});
        return await this.page.frame(mcmpIframe).getAttribute(elemLocator, attrbtName);
    }

    //Wait for loader to dissapear
    async waitForLoaderToComplete() {
		try {
			await this.page.frame(mcmpIframe).waitForSelector('.bx--loading__svg', { state: "hidden" });
		} catch (error) {
			//throw new Error(`Wait for loader failed: ${error}`);
            logger.info("Loader is not hidden")
		}
	}

    //Must be called before performing any native event
    //event : load, domcontentloaded,framattached,framedetached,framenavigated etc.Refer documentation
    async waitForEvent(event) {
        if(event != undefined){
            await this.page.waiForEvent(event); 
        }else{//Wait until the page is completely loaded within 3 mins
            await this.page.waiForEvent("load");
        }
        
    }
    //Must be called after performing native event
    //Options are load by default and domcontentloaded, networkidle
    async waitForLoadState() {
        await this.page.waitForLoadState("networkidle")
    }
   
    async syncWithUi (){
        //Wait till spinner loading completes
        await Promise.all([           
            this.page.frame(mcmpIframe).waitForLoadState(),
            this.waitForLoaderToComplete()
        ])        
    }
    //Returns an array of text matching locator
    async getTextArray(elemLocator){

        var elemList = await this.getElementsList(elemLocator);        
        var textArray = await Promise.all((elemList.map(async (elem, index) => {        
            return await elem.innerText()
        })))

        //var textArray =  await this.page.frame(mcmpIframe).$$eval(elemLocator, nodes => nodes.map(n => n.innerText.trim()));

        return textArray;
    }

    async isDisplayed(elmLocator){
        await this.syncWithUi();        
        await this.page.frame(mcmpIframe).waitForSelector(elmLocator, {timeout:timeOuts.element});
        return await this.page.frame(mcmpIframe).isVisible(elmLocator);
    }

}