//Here reporter is allure object which is exported globally and is available everywhere.

var logGenerator = require("./logGenerator.js"),
    logger = logGenerator.getApplicationLogger();

exports.customReporter = class customReporter {
    constructor(Page) {
        this.page = Page;
    };

    async info(msg) {
        await reporter.startStep(msg);
        await reporter.endStep("passed");
        logger.info(msg);
    };

    async failed(msg) {
        await reporter.startStep(msg);
        await reporter.endStep("failed");
        logger.info(msg);
    };

    async description(testName) {
        // await reporter.description(testName);
        logger.info(testName);
    };

    async takeScreenShot(screenshotDesc) {
        //Save screenshots to local folder
        try {
            await this.page.screenshot({ path: './Reports/screenshots/' + screenshotDesc + '.png' });
        } catch (error) {
            logger.info("Exception while taking screenshot - " + error);
        }

    };

}
