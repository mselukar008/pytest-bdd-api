beforeEach(async () => {
  await page.goto('http://localhost:3000')
})

test('use Turquoise as a default background color', async () => {
  await expect(page).toHaveSelector("text=#1abc9c")
});

//Workaround for TS error: 'All files must be modules when the '--isolatedModules' flag is provided.'
//export { }