const { mainParam } = require('./e2e/page/mainParam.pageobject');
const { catalog } = require('./e2e/page/catalog.pageObject');
const { placeOrder } = require('./e2e/page/placeOrder.pageObject');
const { orders } = require('./e2e/page/orders.pageObject');
const { orderedServices } = require('./e2e/page/orderedServices.pageObject');
const { orderHistory } = require('./e2e/page/orderHistory.pageobject');
const { customReporter } = require('./helpers/customReporter');
const { PlaywrightHar } = require('playwright-har');
const { orderFlowUtil } = require('./helpers/orderFlowUtil');
const { commonMethods } = require('./helpers/commonMethods');
const { pageObjectCommonMethods } = require('./helpers/pageObjectCommonMethods');
const genericTestData  = require('./testData/genericData.json');
const timeOuts = require('./testData/timeouts.json');
const loginUtil = require('./helpers/globalLogin');
const testConfig = require('./jest-playwright.config');
const util = require('./helpers/util');
const logincookiesFile = "./Cookies/state.json";
const logGenerator = require('./helpers/logGenerator');
const logger = logGenerator.getApplicationLogger();
const jasmineReporters = require('jasmine-reporters');
const pwConfig = require('./jest-playwright.config');

const fs = require('fs');
var txtBoxuserNameCss = "input[type='text']";
var btnIAccpetCss = "text=I Accept";
var playwrightHar;
var testSuiteName;

// my-test-suite
/**
 * @jest-environment ./customEnvironment
 */

beforeAll(async () => {    

    var loginCookiesAvailable = await util.readFile(logincookiesFile);
    if (loginCookiesAvailable == false) {
        await loginStore(testConfig.environment, testConfig.userName, testConfig.password);
    } else {
        //Login based on available session cookies. As cookies are available, close existing browser
        //and use new browser loaded with cookies.        
        // Create a new context with the saved storage state/cookies.              
        context = await browser.newContext({ storageState: logincookiesFile, recordVideo : { dir:'./Reports/videos/'} });
        page = await context.newPage();
        //Close original context
        await browser.contexts()[0].close();       
        await page.goto(testConfig.environment);       
        //Check if cookies are valid
        //Assumption - If username field is displayed then cookies are expired
        //Check visibility of username field
        await page.waitForSelector(txtBoxuserNameCss, { timeout : 10000 }).then(async function(){
            logger.info("Browser session Cookies are expired, relogin ...");
            await loginStore(testConfig.environment, testConfig.userName, testConfig.password);
        }).catch(function(err){
            logger.info("Browser session Cookies are valid ...");
        }); 
        
        //Check if privacy pop up is displayed        
        await page.waitForSelector(btnIAccpetCss, {timeout : 5000}).then(async function(){
            logger.info("IBM Privacy pop up is displayed");
            await page.click(btnIAccpetCss);
        }).catch(function(err){
            logger.info("IBM Privacy pop up is not displayed");
        });
    }

    // //Set context viewport as per page
    await page.setViewportSize({width: 1280, height: 620});
   //await page.setViewportSize({ viewport:null });

   //Set navigation timeout 
   await page.setDefaultNavigationTimeout(180000);

    //Defining global Objects to be used across each test suite
     
    global.mainParamPage = new mainParam(page);
    global.catalogPage = new catalog(page);
    global.placeOrderPage = new placeOrder(page);
    global.ordersPage = new orders(page);
    global.orderHistoryPage = new orderHistory(page);
    global.orderedServicesPage = new orderedServices(page);
    global.commonUiMethods = new commonMethods(page);
    global.poCommonMethods = new pageObjectCommonMethods(page);    
    global.orderflow = new orderFlowUtil(page);
    playwrightHar = new PlaywrightHar(page);
    //Define global Reporter object which is pointing to allure;
    global.Reporter = new customReporter(page);
    global.mcmpIframe = { name: 'mcmp-iframe' };
    //Generic Test Data file that can be used across all tests for common verification
    global.genericTestData = genericTestData;
    global.timeOuts = timeOuts;
    global.pwConfig = pwConfig;
    //Make logger as global
    global.logger = logger;
   
    //Trace Network logs for each spec
    await context.tracing.start({
        screenshots: true,
        snapshots: true
    });

    //Capture har file for spec
    await playwrightHar.start();
    try {
        fs.mkdirSync("./Reports/har"); 
    } catch (error) {
        logger.info("Folder exist already")
    }     
    
    // Do network interception block images, adds and some third part urls
    // Page wont load those resources that we are planning to block
    // page.route('**', route => {
    //     logger.info(route.request().url());      
    //     route.continue();
    //     //route.abort();
    // });

    // //Log page errors from developer console 
    // await page.on('pageerror', pagError => {
    //     logger.info("Page errors - " + pagError )
    // });

    // await page.on('requestfailed', reqstFailed => {
    //     logger.info("Page errors after failing request- " + reqstFailed.url() );
    // });

    //PDF Generation - PDF generation only works in Headless Chromium.    
    //await page.emulateMedia({media: 'screen'});
    //await page.pdf({path: 'execution.pdf'});

    
});
//Collect Network logs after each spec
afterAll(async () => {

    testSuiteName = await reporter.suites[0].name

    await context.tracing.stop({       
        path: "./Reports/Trace/" + testSuiteName + ".zip"
    });
    //Store har file
    await playwrightHar.stop('./Reports/har/' + testSuiteName + '.har');

    try {
        //Save video recording of test execution        
        var videoFilePath = await page.video().path();
        var newVideoPath = './Reports/videos/' + testSuiteName + '.webm';
        fs.renameSync(videoFilePath, newVideoPath);            
    } catch (error) {
        //logger.info("Video file can not be renamed")
    }
    //Save pdf file
    //await page.pdf({path: 'execution.pdf'});
    //done();
});

// beforeEach(async () => {

// });

// afterEach(async () => {
//     testSuiteName = await reporter.suites[0].name

// });


