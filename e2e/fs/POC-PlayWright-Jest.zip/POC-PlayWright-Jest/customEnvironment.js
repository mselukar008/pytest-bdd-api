const logGenerator = require('./helpers/logGenerator'),
    logger = logGenerator.getApplicationLogger();
const Allure = require('allure-js-commons');
const PlaywrightEnvironment = require('jest-playwright-preset/lib/PlaywrightEnvironment').default;
const strip_ansi_1 = require("strip-ansi");
class CustomEnvironment extends PlaywrightEnvironment {

    constructor(config) {
        super(config);
        this.config = config;
    }

    async setup() {
        await super.setup();
        this.allure = new Allure();
        this.allure.setOptions({
            targetDir: "./Reports/allure-results",
        });
        this.global.reporter = this.allure;
    }

    async teardown() {
        await super.teardown()
    }

    async handleTestEvent(event, state) {
        
        await super.handleTestEvent(event, state)
        switch (event.name) {
            case 'setup':
                break
            case 'add_hook':
                break
            case 'add_test':
                break
            case 'run_start':
                break
            case 'test_skip':
                this.allure.startCase(event.test.name);
                this.allure.endCase('skipped');
                logger.info("Test skipped - " + event.test.name)
                logger.info("-------------------------------------------------------------------------------------------");
                break
            case 'test_todo':
                break
            case 'start_describe_definition':
                this.allure.startSuite(event.blockName)
                logger.info("Test Suite Started - " + event.blockName)
                break
            case 'finish_describe_definition':
                break
            case 'run_describe_start':                
                break
            case 'test_start':
                this.allure.startCase(event.test.name);
                logger.info("Test Started - " + event.test.name);                
                break
            case 'hook_start':
                break
            case 'hook_success':
                break
            case 'hook_failure':
                break
            case 'test_fn_start':
                break
            case 'test_fn_success':
                break
            case 'test_fn_failure':
                break
            case 'test_done':
                if (event.test.errors.length > 0) {

                    for (var i = 0; i < event.test.errors.length; i++)
                    logger.info("Failure reason: " + event.test.errors[i]);
                    logger.info("-------------------------------------------------------------------------------------------");

                    let error;
                    const parentName = event.test.parent.name.replace(/\W/g, '-')
                    const specName = event.test.name.replace(/\W/g, '-')

                    const screenshot = await this.global.page.screenshot({ path: "./Reports/screenshots/" + parentName + "_" + specName + ".png" });
                    this.allure.addAttachment('Failed Step Screenshot', screenshot, 'image/png');
                    error = {
                        message: strip_ansi_1(event.test.errors[0][0].message),
                        stack: strip_ansi_1(event.test.errors[0][0].stack)
                    };                    
                    //this.allure.endCase('failed', event.error);
                    this.allure.endCase('failed', error);
                    logger.info("Test Failed: " + event.test.name)
                } else {
                    this.allure.endCase('passed');
                    logger.info("Test Passed: " + event.test.name);
                }

                // for (var i = 0; i < event.test.errors.length; i++)
                //     logger.info("Failure reason: " + event.test.errors[i]);

                logger.info("-------------------------------------------------------------------------------------------");

                break
            case 'run_describe_finish':
                break
            case 'run_finish':
                this.allure.endSuite();
                logger.info("Test Suite Finished " + state.currentDescribeBlock.children[0].name)
                // // for (var i = 0; i <  event.describeBlock.tests.length; i++)
                // //     if(event.describeBlock.tests[i].errors.length > 0)
                // //         logger.info("Failure reason: " + event.test.errors[i] );

                logger.info("-------------------------------------------------------------------------------------------");
                logger.info("===========================================================================================");
                                            
                break
            case 'teardown':                                   
                break
            case 'error':
                break
            default:
                break
        }
    }
}

module.exports = CustomEnvironment