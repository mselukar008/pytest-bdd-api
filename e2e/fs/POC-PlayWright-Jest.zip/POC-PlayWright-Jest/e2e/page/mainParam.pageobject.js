"use strict";

var util = require("../../helpers/util");
var locatorsConfig = {
    txtBxServiceName: "[placeholder='Please insert Service Instance Prefix']",
    drpdownEnv: "//*[@id='env']/div//div",
    drpdownApp: "//*[@id='app']/div//div",
    btnNext : "#next-button-mainParams"
}

exports.mainParam = class mainParam {
    constructor(Page) {
        this.page = Page;
    };

    async fillMainParameterPageDetails(configDetails) {
        await this.setServiceName(configDetails["serviceName"]);
        await this.selectTeam(configDetails["Team"]);
        await this.selectContexts(configDetails["Env"], configDetails["App"]);
        await this.selectProviderAccount(configDetails["providerAccount"]);
    };

    async setServiceName(serviceName) {
        await commonUiMethods.sendKeys(locatorsConfig.txtBxServiceName, serviceName, "Service Name");
    };

    async selectTeam(team) {
        await commonUiMethods.check('label[for="radio-button-team_' + team + '"]', team, "Team");
    };

    async selectContexts(env, app) {
        await commonUiMethods.selectDropdownValue(locatorsConfig.drpdownEnv, env, "Environment");
        await commonUiMethods.selectDropdownValue(locatorsConfig.drpdownApp, app, "Application");
    };

    async selectProviderAccount(providerAcc) {
        var providerAccount = providerAcc.replace(" /", "_/");
        await commonUiMethods.fclick("label[for = 'radio-button-providerAccount_" + providerAccount + "']", providerAcc, "Provider Account");
    };

    async isNextButtonEnabled() {
        return await this.page.frame(mcmpIframe).isEnabled(locatorsConfig.btnNext, { timeout : timeOuts.element });
    }

}