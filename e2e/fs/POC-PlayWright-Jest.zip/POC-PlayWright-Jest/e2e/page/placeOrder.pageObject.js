"use strict";

var util = require('./../../helpers/util');

var locatorsConfig = {    
    //btnNextCss : "button[title='Next']",
    //btnNextCss : "button:has-text('Next')",
    btnNext : "//button[contains(text(), 'Next')]",
    buttonTextPrevious:	'button:has-text("Previous")',
    btnSubmitOrderCss : "button[id$='primary-btn-review-order']",
    txtOrderSubmtdModal : "h3.bx--modal-header__heading",
    txtOrderIdCss : "#order-number",
    btnGoToCatlgCss : "#order-submitted-modal_carbon-button",
    estimatedCostsReviewOrderPageCss: '.bx--side-nav__item.bx--side-nav__item--total span:nth-child(2) strong',
    txtCompListXpath : "//li[@class='bx--side-nav__item']",
    txtCompName : "//*[@class='bx--side-nav__item']/span",
    txtCompPrice : "//*[@class='bx--side-nav__item']//span/strong",
    errorMsgEditServiceCss : '.bx--toast-notification__subtitle span',
    errorMsgCloseBtnXpath : '//button[@class="bx--toast-notification__close-button"]',
}

exports.placeOrder = class placeOrder{
        constructor(Page) {
        this.page = Page;
    };

    async clickNextButton(){
        await commonUiMethods.waitForLoaderToComplete();
        await commonUiMethods.fclick(locatorsConfig.btnNext, "Place Order - Next button");        
    };

    async submitOrder(){
        await commonUiMethods.waitForLoaderToComplete();
        await commonUiMethods.fclick(locatorsConfig.btnSubmitOrderCss, "Submit order button");         
    };

    async getTextOrderSubmittedHeaderOrderSubmittedModal() {
        var text = await commonUiMethods.getText(locatorsConfig.txtOrderSubmtdModal);
        await Reporter.info("Order submission modal header - " + text);
        return text; 
    };

    async getTextOrderNumberOrderSubmittedModal() {
        var text = await commonUiMethods.getText(locatorsConfig.txtOrderIdCss);
        await Reporter.info("Order Number - " + text); 
        return text; 
    };

    async clickgoToServiceCatalogButtonOrderSubmittedModal() {              
        await commonUiMethods.fclick(locatorsConfig.btnGoToCatlgCss, "Go to Service Catalog button");
    }

    async validateReviewOrderPageParams (reviewOrderExpActParamsMap) {
        var expctdParams = Object.keys(reviewOrderExpActParamsMap["Expected"]);
        //reviewOrderExpActParamsMap["Expected"]["Service Instance Name"] = reviewOrderExpActParamsMap["Expected"]["Service Instance Prefix"]
        var expValue, actValue;
        for (var i = 0; i < expctdParams.length; i++) {
            if(reviewOrderExpActParamsMap["Actual"][expctdParams[i]] != undefined){
                expValue = reviewOrderExpActParamsMap["Expected"][expctdParams[i]];
                actValue = reviewOrderExpActParamsMap["Actual"][expctdParams[i]].replace("\nUpdated", "").replace("\nNew", "")
        
                if (actValue.includes("... more")) {
                    actValue = actValue.split("... more")[0];
                }
                //Handling for Main parameters page
                if(actValue == "!none!"){
                    actValue = "NONE"
                }

                if (actValue.includes(" /")) {
                    actValue = actValue.replace(" /", "_/");
                }

                if (expValue == actValue) {
                    await Reporter.info("Review Order page parametr -> " + expctdParams[i] + " = " + actValue);                    
                } else if (expValue.includes(actValue)) {
                    await Reporter.info("Review Order page parametr -> " + expctdParams[i] + " = " + actValue);                   
                } else if (actValue.includes(expValue)) {
                    await Reporter.info("Review Order page parametr -> " + expctdParams[i] + " = " + actValue);                   
                }
                else {
                    await Reporter.info("Review Order page parametr - Actual --> " + expctdParams[i] + " = " + actValue + " | Expected --> " + expctdParams[i] + " = " + expValue);
                    return false;
                }
            }            
        }
        return true;
    };

    async getAndSaveOrderId (serviceName, orderType) {
        var text = await commonUiMethods.getText(locatorsConfig.txtOrderIdCss);
        await util.saveOrderId(serviceName, orderType, text);
        await Reporter.info("Order Number - " + text); 
        return text; 
    };

    async getEstimatedPrice_ReviewOrder(){
        var txt = await commonUiMethods.getText(locatorsConfig.estimatedCostsReviewOrderPageCss);
        await Reporter.info("Estimated price on review order page is " + txt);
        return txt;
    }

    async validateBOMOnReviewOrderPage (expPricingMap){
        var expPrice,actPrice;
        return this.getActBOMOnReviewOrderPage().then(function(actBomPricingMap){
            Object.keys(expPricingMap).forEach(function(key){
                expPrice = expPricingMap[key];
                actPrice = actBomPricingMap[key];
                if(expPrice == actPrice){
                    logger.info("Pricing for " + key + " is : " + expPrice);
                }else{
                    logger.info("Pricing do not match for " + key + " | Expected : " + expPrice + " | Actual : " + actPrice);
                    return false;
                }
            });
            return true;
        });    
    };

    async getActBOMOnReviewOrderPage (){
        var actualBillOfMaterialsMap = {};   
        var j=0;
        var compList = await commonUiMethods.getTextArray(locatorsConfig.txtCompListXpath);
        var compName = await commonUiMethods.getTextArray(locatorsConfig.txtCompName);
        var compPrice = await commonUiMethods.getTextArray(locatorsConfig.txtCompPrice);
        compList.forEach(async function(elem, index){
            actualBillOfMaterialsMap[compName[index * 2]] = compPrice[j];
            j = j + 1;       
        });        
        return actualBillOfMaterialsMap

    };

    async clickPreviousBtn() {
        await commonUiMethods.fclick(locatorsConfig.buttonTextPrevious, "Previous button")
    }

    async getTextEditOrderErrorMsg() {
        return await commonUiMethods.getText(locatorsConfig.errorMsgEditServiceCss)        
    }

    

}    