"use strict";

var util = require("../../helpers/util");
const logGenerator = require('../../helpers/logGenerator');
const logger = logGenerator.getApplicationLogger();
var mcmpUIDataTemplate = require('../../testData/mcmpUI.json');
var locatorsConfig = {
    srchOrderTxtbox: "#search__input-orders-search",
    orderTableActionIconCss: '.bx--overflow-menu__icon',
    btnServiceDetails:'button:has-text("Service Details")',
    btnBillOfMaterialsPage:'button:has-text("Bill of Materials")',
    btnBillOfMaterials:'[data-tab-id="bill_of_materials"]:visible',    
    estmtdCost:'.total-cost-value:visible',
    currentBom :'[id*="non-one-time-charge_parent"]'
}

exports.orderHistory = class orderHistory {
    constructor(Page) {
        this.page = Page;
    };

    async open() {       
        await catalogPage.clickHamburgerCatalog();
        await catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);        
        await catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkOrderHistory);
    };

    async searchOrderById (orderId) {
        await this.page.frame(mcmpIframe).waitForLoadState();
        await commonUiMethods.sendKeys(locatorsConfig.srchOrderTxtbox, orderId, "Search order");                 
    };

    async clickOrdersTableActionIcon() {
      await commonUiMethods.fclick(locatorsConfig.orderTableActionIconCss, "Action Button");  
    }

    async clickServiceDetailSliderCloseButton () {       
        await poCommonMethods.clickServiceDetailSliderCloseButton();
    }
    
    async clickServiceDetails() {
        await this.clickOrdersTableActionIcon();
        await commonUiMethods.fclick(locatorsConfig.btnServiceDetails, "Order History-Service Details");  
    }

    async clickBillOfMaterials() {
        await this.clickOrdersTableActionIcon();
        await commonUiMethods.fclick(locatorsConfig.btnBillOfMaterialsPage, "Order History-Bill Of Materials");  
    }

    async validateorderDetails(expectedValuesMap) {
        return await poCommonMethods.validateorderDetails(expectedValuesMap, "Order History");
    }

    async clickBOMServiceDetails(){
        await commonUiMethods.fclick(locatorsConfig.btnBillOfMaterials, "Bill of Materials");
    }    

    async getEstimatedCostServiceDetails() {
        return await commonUiMethods.getText(locatorsConfig.estmtdCost, "Estimated Cost in Service Details")
    }

    async getUpdatedBOMTablePrice () {
               
        var total = 0.000;
        var cost = 0.000;
                  
        try {
            var txtArry = await commonUiMethods.getTextArray(currentBom);            
            for (var i = 0; i < txtArry.length; i++) {
                cost = txtArry[i].replace("USD ", "");
                total = total + parseFloat(parseFloat(cost).toFixed(3));
            };
            logger.info("Total price of BOM table is USD " +  total);           
            return ("USD " +  total);  
        } catch (error) {
            logger.info(error);
            return "";                
        }
        
    
    }
    
    

}