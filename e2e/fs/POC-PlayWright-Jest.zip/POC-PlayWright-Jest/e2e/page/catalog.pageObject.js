"use strict";
var mcmpUIDataTemplate = require('../../testData/mcmpUI.json');
var locatorsConfig = {
    hamburgerCatalogCss: 'ibm-hamburger button',
    leftNavBarCss: 'ibm-sidenav',
    pinLeftNavBarCss: 'ibm-icon-pin svg',
    arrowLeftNavBarCss: 'ibm-icon-arrow-left svg',
    textLeftNavLinkCss: 'a.bx--side-nav__link span',
    textLeftNavButtonCss: '.bx--side-nav__submenu-title',
    buttonLeftNavSubMenu: '.bx--side-nav__submenu',
    linkResetProviderText: 'RESET',
    linkCatalogMainParamText: 'Catalog',
    btnConfigureServiceCss: '#configure-service'
};

exports.catalog = class catalog {
    constructor(Page) {
        this.page = Page;
    };

    async open() {
        var self = this;
        await self.clickHamburgerCatalog();
        await self.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
        await self.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkCatalog);
    };

    async clickHamburgerCatalog() {
        await commonUiMethods.click(locatorsConfig.hamburgerCatalogCss, "Hambergur Button");
    };

    async clickLeftNavButtonBasedOnName(navBtnName) {
        var isExpanded = await commonUiMethods.getAttribute("button:has-text('" + navBtnName + "')", "aria-expanded")
        if (isExpanded != "true") {
            await commonUiMethods.click("button:has-text('" + navBtnName + "')", navBtnName);
        } else {
            await Reporter.info("Store is already expanded ");
        }
    };

    async clickLeftNavLinkBasedOnName(navLink) {
        await commonUiMethods.click("a[role='menuitem']:has-text('" + navLink + "')", navLink);
    };

    async clickCategory(category) {
        await commonUiMethods.fclick("text=" + category, "Category -->" + category);
    };

    async clickProvider(provider) {
        await commonUiMethods.fclick("text=" + provider, "Provider -->" + provider);
    };

    async clickOnserviceName(serviceName) {
        await commonUiMethods.fclick('text=' + serviceName, "Select Service -->" + serviceName);
    };

    async clickConfigureBtn() {
        await commonUiMethods.fclick(locatorsConfig.btnConfigureServiceCss, "Configure Service button");
    };

    
}