"use strict";
const logGenerator = require('../../helpers/logGenerator');
const logger = logGenerator.getApplicationLogger();
var mcmpUIDataTemplate = require('../../testData/mcmpUI.json');
var locatorsConfig = {    
    txtBoxSearchOrder : '#search__input-orders-search',
    btnOrderApprove : '#order_approve_button',
    chkboxTechnical : 'label[for="checkbox-technical"] span',
    chkboxFinancial : 'label[for="checkbox-financial"] span',
    btnOrderApprovalApprove : '#order_details_approval_approve',
    btnOrderApprovalOk : '#order_details_approval_ok',
    btnAllOrders : '#tab-control-all_orders_tab',
    txtOrderStatus : '//*[@id="carbon-deluxe-data-table-orderDetailsTable"]//td[3]',
    orderId : '.order-items a',
    btnPendingApp : 'text = Pending approval',
    orderNotFoundTextXpath:	'//p[@class = "bx--inline-notification__subtitle"]/span',
    btnCancelOrderApproval : '#order_details_approval_cancel',
    orderTableOrderTypeColumnCss: '.bx--table-body tr td:nth-child(4) span',
    textServiceOfferingNameCss: '#carbon-deluxe-data-table-tableOrderServiceDetails td:nth-child(2) span',
    orderTableAmountColumnCss: '.bx--table-body tr td:nth-child(1) span',
    orderTableActionIconCss: '.bx--overflow-menu__icon',
    buttonTextViewDetails: 'button:has-text("View Details")',    
    btnBom:'button:has-text("Bill of Materials")',
    orderTotalCostBillofMaterialsTabCss	:'.total-cost-value',    
    denyButtonOrderDetailsPageCss : '#order_deny_button',
    OrderDenyModalTechincalApprovalCheckboxCss : 'label[for="checkbox-denial-technical"]',
    OrderDenyModalCommentsTextAreaCss:'#text-areadenial-reason',
    OrderDenyModalOkButtonCss: '#order_details_deny_approve',
    OrderDenyModalOkayButtonCss: '#order_details_deny_ok',
    btnCurrentBom:'[data-tab-id="current_bom"]',
    moreLink : 'button:has-text("More")'
   
};

exports.orders = class orders {
    constructor(Page) {
        this.page = Page;
    };

    async open() {       
        await catalogPage.clickHamburgerCatalog();
        await catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);        
        await catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkApproveOrders);
    };

    async searchOrderById (orderId, totalRepeatCountApproveOrder) { 
        var self=this;
        if (totalRepeatCountApproveOrder == undefined) {
            totalRepeatCountApproveOrder = 60;          
        }
        //Wait till page loads completely
        await this.page.frame(mcmpIframe).waitForLoadState();        
        //Wait till order Ids are displayed on left panel
        await this.page.frame(mcmpIframe).waitForSelector(locatorsConfig.orderId, {timeout:timeOuts.element}).then(async function(){
            logger.info("Order Ids are displyed on left panel");
        }).catch(async function(err){
            logger.info("Order Ids are not displyed on left panel");
        });        	
        await commonUiMethods.sendKeys(locatorsConfig.txtBoxSearchOrder, orderId, "Search order");
        
        //Handling for No orders found error        
        await this.page.frame(mcmpIframe).waitForSelector(locatorsConfig.orderNotFoundTextXpath, {timeout:timeOuts.tmpText}).then(async function(){
            logger.info("No Orders found on Pending Approval tab ");
            await self.clickAllOrdersTab();
            await self.searchOrderById(orderId);
        }).catch(async function(err){
            logger.info("Order Ids are displyed");
        });
        
        await this.validateOrderId(orderId, totalRepeatCountApproveOrder);        
    };
    
    async validateOrderId (expOrderId, repeatCount){
        var self = this;
        await this.getTextFirstOrderIdOrdersTable().then(async function(actOrderId){
            if(expOrderId == actOrderId){
                logger.info("Order id found on orders page");
                return true;
            }else{
                logger.info("Order id on orders page do not match with the searched orderId");
                await self.clickPendingApprovalUnderOrdersSection();
                await self.clickAllOrdersTab();
                await self.searchOrderById(expOrderId, repeatCount - 1);
            }
        })
    }
    
    async clickApproveButtonOrderDetails(orderId, repeatCount){
        var self = this;       
        if(repeatCount == undefined){
            repeatCount = 1;            
        }
        while (repeatCount < 3){           
            await commonUiMethods.fclick(locatorsConfig.btnOrderApprove, "Approve Button").then(async function(){
               repeatCount = 3;                               
            }).catch(async function(err){
                logger.info("Approve/Deny button not displayed");
                repeatCount = repeatCount + 1;                
                await self.approveOrder(orderId, repeatCount);
            });         
        }                
    };

    async approveOrderTechFin (){
        await commonUiMethods.sleep(2000);
        await commonUiMethods.fclick(locatorsConfig.chkboxTechnical, "Technical Approval Checkbox");
        await commonUiMethods.fclick(locatorsConfig.chkboxFinancial, "Financial Approval Checkbox");
        await commonUiMethods.fclick(locatorsConfig.btnOrderApprovalApprove, "Approve Order");
        await this.clickOkOrderApproval().then(async function(){
        }).catch(async function(err){
            logger.info("Ok button not displayed after approving order");
            await commonUiMethods.fclick(locatorsConfig.btnCancelOrderApproval, "Order Approval-Cancel");
        });
    };

    async clickOkOrderApproval (){
        await commonUiMethods.fclick(locatorsConfig.btnOrderApprovalOk, "Order Approval-Ok button");       
    };

    async waitUntilOrderStatusChange(orderId, orderStatus, repeatCount){
        var actOrderStatus;
        await this.open();
        await this.page.frame(mcmpIframe).waitForLoadState("domcontentloaded");
        if (repeatCount == undefined) {
            repeatCount = 120; //Each count corresponds to 1sec
        }
        repeatCount = repeatCount - 1;
        if (repeatCount > 0) {
            //await this.clickPendingApprovalUnderOrdersSection();
            await this.clickAllOrdersTab();         
            await this.searchOrderById(orderId);            
            actOrderStatus = await commonUiMethods.getText(locatorsConfig.txtOrderStatus);
            if(actOrderStatus == orderStatus){
                Reporter.info("Order status is changed to "+ actOrderStatus + " ; breaking the loop");
                repeatCount = 0; 
                return;
            }else if (actOrderStatus == "Failed" || actOrderStatus == "Completed with Failure"){
                Reporter.info("Order status is changed to "+ actOrderStatus + " ; breaking the loop");
                repeatCount = 0;
                return;
            }else if (actOrderStatus == "Approval In Progress") {
                Reporter.info("Order status is still in  Approval In Progress state");
                repeatCount = 0;
                return;
            }else{
                logger.info("Current order status : " + actOrderStatus + " ;Waiting for order status to change to - " + orderStatus);
                await commonUiMethods.sleep(3000);
                await this.waitUntilOrderStatusChange(orderId, orderStatus, repeatCount);
            }
        }    

    };

    async approveOrder(orderId, repeatCount){
        if(repeatCount == undefined){
            repeatCount = 1
        }
        await this.open();
        await this.searchOrderById(orderId);
        await this.clickApproveButtonOrderDetails(orderId, repeatCount);
        await this.approveOrderTechFin();
    };

    async getOrderStatus(orderId) {
        await this.open();
        await this.clickAllOrdersTab();        
        await this.searchOrderById(orderId);        
        var orderStatus = await commonUiMethods.getText(locatorsConfig.txtOrderStatus);
        return orderStatus;
    }

    async getTextFirstOrderIdOrdersTable (){
        try{
            //await commonUiMethods.sleep(3000);
                      
            var orderId = await commonUiMethods.getText(locatorsConfig.orderId);
            if(orderId.includes('ORDER #')){
                orderId=orderId.replace('ORDER # ','');
            }
            logger.info("Order ID :: "+orderId);
            return orderId.trim();
        }catch(err){
            logger.info("Order id not found on orders page : Exception : " + err.message);
            return "";
        }        
    };

    async clickAllOrdersTab (){
        await commonUiMethods.fclick(locatorsConfig.btnAllOrders, "All Orders").then(async function(){
        }).catch(async function(err){
            logger.info("All Orders tab is not clickable");
        });
        
    }

    async clickPendingApprovalUnderOrdersSection(){
        try {
            await commonUiMethods.fclick(locatorsConfig.btnPendingApp, "Pending Approval");                      
        } catch (error) {
            logger.info("Unable to click on Pending Approval tab");
        }
        
    }

    async getTextFirstOrderTypeOrdersTable(){
        return await commonUiMethods.getText(locatorsConfig.orderTableOrderTypeColumnCss, "Order type")
    }

    async getServiceNameOfferingText(){
        return await commonUiMethods.getText(locatorsConfig.textServiceOfferingNameCss, "Service Name offering")
    }

    async getTextFirstAmountOrdersTable() {
        return await commonUiMethods.getText(locatorsConfig.orderTableAmountColumnCss, "Estimated price on approve order page")
    }

    async getTextBasedOnLabelName(labelName) {
       return await commonUiMethods.getText('//*[contains(text(), "' + labelName + '")]/following-sibling::p', labelName)
    }

    async clickFirstViewDetailsOrdersTable() {
        await commonUiMethods.fclick(locatorsConfig.orderTableActionIconCss, "Orders Action Button")
        await commonUiMethods.fclick(locatorsConfig.buttonTextViewDetails, "View Details")        
    }

    async validateorderDetails(expectedValuesMap) { 
        return await poCommonMethods.validateorderDetails(expectedValuesMap, "Orders");
    }

    async clickBillOfMaterialsTabOrderDetails(){
        await commonUiMethods.fclick(locatorsConfig.btnBom, "Bill Of Materials");
    }

    async getTextTotalCostOnBillofMaterialsOrderDetails (){
        return await commonUiMethods.getText(locatorsConfig.orderTotalCostBillofMaterialsTabCss, "Estimated Cost on orders page BOM");
    };

    async clickServiceDetailSliderCloseButton (counter) {        
        await poCommonMethods.clickServiceDetailSliderCloseButton();
    };    
    
    async denyOrder(orderNumber) {
        await this.open();
        await this.searchOrderById(orderNumber);        
        await commonUiMethods.fclick(locatorsConfig.denyButtonOrderDetailsPageCss, "Deny button");
        await commonUiMethods.fclick(locatorsConfig.OrderDenyModalTechincalApprovalCheckboxCss, "Deny Order - Technicala Approval checkbox");
        await commonUiMethods.sendKeys(locatorsConfig.OrderDenyModalCommentsTextAreaCss, "Testing", "Deny Comments");
        await commonUiMethods.fclick(locatorsConfig.OrderDenyModalOkButtonCss, "Deny order");
        await commonUiMethods.fclick(locatorsConfig.OrderDenyModalOkayButtonCss, "Ok  for Deny order");
    }

    async getBOMTablePrice(){
        return await poCommonMethods.getBOMTablePrice();
    }

    async getCurrentBOMTablePrice () {
        await commonUiMethods.fclick(locatorsConfig.moreLink, "More Link")
        await commonUiMethods.fclick(locatorsConfig.btnCurrentBom, "Current BOM")
        return await poCommonMethods.getCurrentBOMTablePrice();   
    }

    

    
}