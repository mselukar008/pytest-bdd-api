"use strict";
const logGenerator = require('../../helpers/logGenerator');
const logger = logGenerator.getApplicationLogger();
const util = require('../../helpers/util');
var mcmpUIDataTemplate = require('../../testData/mcmpUI.json');
var locatorsConfig = {
    txtboxSrchService: "#data-table-search__input",
    instanceTableActionIconCss: '.bx--table-overflow',
    btnDeleteService: 'text=Delete Service',
    btnEditService: 'text=Edit Service',
    deleteServiceModalConfirmCheckBoxCss: '#checkbox-inventory-listing_action-modal_ConfirmDeleteServiceChecked ~ .bx--checkbox-label',
    deleteServiceModalOKButtonCss: '#inventory-listing_action-modal_carbon-button_ok',
    deleteOrderNumberFromPopUpTextCss: '#inventory-listing_carbon-notification_delete-service-import-id',
    deleteServiceInfoTooltipXpath: '//*[@class=" bx--toast-notification bx--toast-notification--success "]',
    deleteOrderNumberXpath: '//*[@class="bx--toast-notification__subtitle"]/span',
    expandFirstRowCss: '.bx--table-expand__button',
    powerStateOverflowMenuIcon: '#carbon-deluxe-data-table-inventory-listing_carbon-data-table-deluxe-parent-row-1-child-row-1-overflow-menu-icon',
    viewComponent: 'text=View Component',
    viewDetails: 'text=View Details',
    d2OpsOkButtonCss: '#inventory-listing_action-modal_carbon-button_ok',
    fetchOrderDetailCss: 'a.btn-fetch-order',
    ordrSubmitdMsg: '//h2[contains(text(), "Order Submitted")]',
    orderId: '#order-submitted-number',
    btnokD2ops: 'button#soi-order-submitted-modal_carbon-button',
    outputParamsXpath: '//*[@class="two-columns m-padding"]//li//span',
    textComponentTypeCss: "[class='bx--table-row bx--parent-row bx--table-row--sub-row'] td:nth-child(4)",
    glifIconXpath: '(//*[@class="bx--overflow-menu__icon"])',
    TagCss: '.ml-padding:nth-child(3) div',
    linkServiceDetailsLabelsXpath: '//*[contains(text(),"abels")]/..//a',
    txtSystemTagValueFieldXpath: '//h5[contains(text(),"Ibm_mcmp_soiid") or contains(text(),"ibm_mcmp_soiid")]',
    btnBomCss:'[data-tab-id="bill_of_materials"]',
    txtEstimatedCost: '#total_cost_value',
    lnkMore:'a:has-text("More")',
    oneTimeChargesBOMTableXpath :'//tr//td[contains(@class,"data-number")][4]'

};

exports.orderedServices = class orders {
    constructor(Page) {
        this.page = Page;
    };

    async open() {
        await catalogPage.clickHamburgerCatalog();
        await catalogPage.clickLeftNavButtonBasedOnName(mcmpUIDataTemplate.leftNavButtonStore);
        await catalogPage.clickLeftNavLinkBasedOnName(mcmpUIDataTemplate.leftNavLinkInventory);
    };

    async searchOrderByServiceName(serviceName) {
        //Wait till page loads completely
        await this.page.frame(mcmpIframe).waitForLoadState();
        await commonUiMethods.sendKeysEnter(locatorsConfig.txtboxSrchService, "Search Service", serviceName);
        await commonUiMethods.waitForLoaderToComplete();
        await this.page.frame(mcmpIframe).waitForSelector("span:has-text('" + serviceName + "')", { timeout: timeOuts.element });
    };

    async clickServiceActionBtn() {
        await commonUiMethods.fclick(locatorsConfig.instanceTableActionIconCss, "Service Action Button");
    };

    async clickDeleteService() {
        await commonUiMethods.fclick(locatorsConfig.btnDeleteService, "Delete Service Button");
    };

    async clickConfirmCheckBoxDeleteServiceModal() {
        await commonUiMethods.check(locatorsConfig.deleteServiceModalConfirmCheckBoxCss, "delete service popup", "Confirm checkbox")
    };

    async clickOKDeleteServiceModal() {
        await commonUiMethods.fclick(locatorsConfig.deleteServiceModalOKButtonCss, "Delete Service-Ok button");
    };

    async getDeleteOrderNumberFromPopUpText() {
        var orderId = await commonUiMethods.getText(locatorsConfig.deleteOrderNumberXpath);
        var deleteOrderNumber = orderId.toString().split(":")[1];
        //Check if Delete order no is captured
        if (deleteOrderNumber.includes("/operations/definition")) {
            await commonUiMethods.sleep(2000);
            await this.getDeleteOrderNumberFromPopUpText();
        } else {
            await Reporter.info("Delete Order Number:" + deleteOrderNumber.trim());
            return deleteOrderNumber.trim();
        }
    };

    async deleteService(serviceName) {
        await this.open();
        await this.searchOrderByServiceName(serviceName);
        await this.clickServiceActionBtn();
        await this.clickDeleteService();
        await this.clickConfirmCheckBoxDeleteServiceModal();
        await this.clickOKDeleteServiceModal();
        return await this.getDeleteOrderNumberFromPopUpText();
    }

    async deleteServiceAndSaveOrderId(serviceBluePrintName, serviceInstName) {
        await this.open();
        await this.searchOrderByServiceName(serviceInstName);
        await this.clickServiceActionBtn();
        await this.clickDeleteService();
        await this.clickConfirmCheckBoxDeleteServiceModal();
        await this.clickOKDeleteServiceModal();
        var deleteOrderId = await this.getDeleteOrderNumberFromPopUpText();
        await util.saveOrderId(serviceBluePrintName, "Delete", deleteOrderId);
        return deleteOrderId;
    }

    async clickExpandFirstRow() {
        await commonUiMethods.fclick(locatorsConfig.expandFirstRowCss, "Expand Service Instance");
    };

    async clickOverflowActionButtonForPowerStates() {
        await commonUiMethods.fclick(locatorsConfig.powerStateOverflowMenuIcon, "SOI Components Action Button");
    };

    async clickD2opsBtn(d2operation) {
        var locator = "button:has-text('" + d2operation + "')";
        await commonUiMethods.fclick(locator, d2operation);
        await commonUiMethods.fclick(locatorsConfig.d2OpsOkButtonCss, "Confirm ok button for operation " + d2operation);
    }

    async fetchD2opsOrderDetails(repeatCount) {
        let self = this;
        if (repeatCount == undefined) {
            repeatCount = 10;
        }
        repeatCount = repeatCount - 1;
        if (repeatCount > 0) {
            await self.page.frame(mcmpIframe).waitForSelector(locatorsConfig.fetchOrderDetailCss, { timeout: timeOuts.element })
            await commonUiMethods.fclick(locatorsConfig.fetchOrderDetailCss, "Please Click here for order updates")
            //Check if order submitted modal is present           
            await this.page.frame(mcmpIframe).waitForSelector(locatorsConfig.ordrSubmitdMsg, { timeout: timeOuts.loop }).then(async function () {
                logger.info("D2 Ops Order Submitted Details displayed,Order Submitted!,breaking the loop");
                repeatCount = 0;
                return;
            }).catch(async function (err) {
                await self.fetchD2opsOrderDetails(repeatCount);
                logger.info(" D2 Ops Order Submitted Details not displayed,Waiting for Order Submitted Details to be displayed, => continuing the loop ");
            });

        };
    };

    async clickOkbtnOrderSubmission() {
        await commonUiMethods.fclick(locatorsConfig.btnokD2ops, "Order Submitted -ok")
    }

    async getTextOrderSubmittedHeaderOrderSubmittedModal() {
        return await commonUiMethods.getText(locatorsConfig.ordrSubmitdMsg);
    }

    async getAndSaveOrderId(serviceBluePrintName, operation) {
        var orderId = await commonUiMethods.getText(locatorsConfig.orderId);
        await util.saveOrderId(serviceBluePrintName, operation, orderId);
        await Reporter.info("Order id for " + operation + " : " + orderId);
        return orderId;
    }

    async verifyOutputParams(inputServiceConfiguration, serviceName) {

        await this.open();
        await this.searchOrderByServiceName(serviceName);        
        await this.clickViewService();

        var arryList = await commonUiMethods.getTextArray(locatorsConfig.outputParamsXpath);

        for (var i = 0; i <= arryList.length - 1; i += 2) {
            field = arryList[i];
            fieldValue = arryList[i + 1];
            if ((fieldValue != "" && field != "") && (fieldValue != "undefined" && fieldValue != undefined)) {
                if (fieldValue.includes(",")) {
                    var fielValues = fieldValue.split(",");
                    if (fielValues[1] == "") {
                        fieldValue = fieldValue + arryList[i + 2];
                        i = i + 1;
                    }
                }
                if (inputServiceConfiguration["Actual"][field] = fieldValue) {
                    logger.info("Output param - " + field + " = " + fieldValue);
                } else {
                    logger.info("Output param - Actual --> " + field + " = " + fieldValue + " | Expected --> " + field + " = " + inputServiceConfiguration["Actual"][field]);
                    return false;
                }
            }
        }
        await poCommonMethods.clickServiceDetailSliderCloseButton();

    };

    async clickOverflowACtionBtnBasedOnComponent(component) {
        var componentType = await commonUiMethods.getTextArray(locatorsConfig.textComponentTypeCss);

        if (componentType.includes(component)) {
            var stringID = componentType.indexOf(component);
            //var vmID = stringID + 3;
            var vmID = stringID + 2;
            await commonUiMethods.fclick(locatorsConfig.glifIconXpath + "[" + vmID + "]", "Action icon of " + component)
            return vmID - 2;
        }
        else {
            logger.info("Error: SOI Component not found");
        }
    }

    async getImiTags(orderObject) {
        var indexOfElem = 0;
        await this.open();
        await this.searchOrderByServiceName(orderObject.servicename);
        await this.clickExpandFirstRow();
        if (orderObject.componentType == undefined) {
            await this.clickOverflowActionButtonForPowerStates();
        } else {
            await this.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType).then(function (index) {
                indexOfElem = index;
            });
        }
        await this.clickViewComponent();
        //Get all the tags
        return await this.getTagsOnInventory();
    };

    async clickViewComponent() {
        await commonUiMethods.fclick(locatorsConfig.viewComponent, "View Component");
    };

    async getTagsOnInventory() {
        var tags = await commonUiMethods.getTextArray(locatorsConfig.TagCss);
        await Reporter.info("System tags are " + tags.toString());
        return tags.toString();
    };

    async getServiceTags(actTagList) {
        var counter = 0;
        var systemTag;
        var sytemTagKeyValue;
        var systemTagKey;
        var systemTagValue;
        var systemTagMap = {};
        while (counter < actTagList.length) {
            systemTag = actTagList[counter];
            sytemTagKeyValue = systemTag.split(":");
            systemTagKey = sytemTagKeyValue[0];
            systemTagValue = sytemTagKeyValue[1];
            systemTagMap[systemTagKey] = systemTagValue;
            counter = counter + 1;
        }
        return systemTagMap;
    };

    async clickLabelsViewDetailsLink() {
        await commonUiMethods.fclick(locatorsConfig.linkServiceDetailsLabelsXpath, "Service labels")
    }

    async validateSystemTagValueIsDisplayed() {
        return await commonUiMethods.isDisplayed(locatorsConfig.txtSystemTagValueFieldXpath)
    }

    async getSystemTagLabel() {
        return await commonUiMethods.getText(locatorsConfig.txtSystemTagValueFieldXpath, "System Tag label")
    }

    async clickServiceDetailSliderCloseButton () {       
        await poCommonMethods.clickServiceDetailSliderCloseButton();
    }

    async editService(serviceName){
        await this.open()
        await this.searchOrderByServiceName(serviceName)
        await this.clickServiceActionBtn()
        await commonUiMethods.fclick(locatorsConfig.btnEditService, "Edit Service")
    }

    async clickBOM(){
        await commonUiMethods.fclick(locatorsConfig.btnBomCss, "Bill Of Materials")
    }

    async getEstimatedPrice(){
        return await commonUiMethods.getText(locatorsConfig.txtEstimatedCost)
    }

    async getBOMTablePrice() {
        var total = 0.000;
        var cost = 0.000;

        await this.clickViewService()
        await this.clickBOM()
        await commonUiMethods.fclick(locatorsConfig.lnkMore, "More Link")    
                   
        try {
            var txtArry = await commonUiMethods.getTextArray(locatorsConfig.oneTimeChargesBOMTableXpath);            
            for (var i = 0; i < txtArry.length; i++) {
                cost = txtArry[i].replace("USD ", "");
                total = total + parseFloat(parseFloat(cost).toFixed(3));
            };
            logger.info("OrderedServices Page - BOM USD " +  total);           
            return ("USD " +  total);  
        } catch (error) {
            logger.info(error);
            return "";                
        }
    }

    async clickViewService(){
        await this.clickServiceActionBtn()
        await commonUiMethods.fclick(locatorsConfig.viewDetails, "View Service Details");
    }
}