const util = require("../../../../helpers/util.js");
const spannerTemplate = require('../../../../testData/orderIntegration/Google/gcpCloudSpanner.json');
var modifiedParams = {}, mainParamsMap = {};

describe("GCP-Cloud Spanner", () => {
    beforeEach(async () => {
        serviceName = "auto-cloudSpanner" + util.getRandomString(5),
        modifiedParams = { "Service Instance Prefix": serviceName.toLowerCase() };
        await catalogPage.open();
        await catalogPage.clickProvider(spannerTemplate.provider);
        await catalogPage.clickCategory(spannerTemplate.Category);
        await catalogPage.clickOnserviceName(spannerTemplate.bluePrintName);
        await catalogPage.clickConfigureBtn();
    });

    it('Cloud Spanner - Validate Details on Main Parameter page', async () => {
        mainParamsMap = { "serviceName": serviceName, "Team": genericTestData.Team, "Env": genericTestData.Env, "App": genericTestData.App, "providerAccount": genericTestData.gcpProviderAcc };
        await mainParamPage.fillMainParameterPageDetails(mainParamsMap);
        //Validate Next button is enabled after entering details
        expect(await mainParamPage.isNextButtonEnabled()).toBe(true);
    });

    it('Cloud Spanner : Verify Service Details are listed in Review Order page', async () => {
        var requiredReturnMap = await orderflow.fillOrderDetails(spannerTemplate, modifiedParams);
        //Validate all review order page parameters are as per input service configuration 
        expect(await placeOrderPage.validateReviewOrderPageParams(requiredReturnMap)).toEqual(true);
        //Validate Estimated Cost on Review Order Page for USD Tenants
        if (pwConfig.defaultCurrency == "USD") {
            expect(await placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(spannerTemplate.TotalCost);
            //BOM Validation as per components of service.
            expect(await placeOrderPage.validateBOMOnReviewOrderPage(spannerTemplate.Pricing)).toBe(true);
        }
    });

    it('Cloud Spanner : Verify Order Details on Orders and Order History page once order is submitted', async () => {
        var serviceConfParams = await orderflow.fillOrderDetails(spannerTemplate, modifiedParams);
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(spannerTemplate.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.open();
        await ordersPage.searchOrderById(orderNumber);
        expect(await ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderNumber);
        expect(await ordersPage.getTextFirstAmountOrdersTable()).toEqual(spannerTemplate.EstimatedPrice)
        await ordersPage.clickFirstViewDetailsOrdersTable();
        //Validate Additional Parameters Details
        expect(await ordersPage.validateorderDetails(serviceConfParams)).toBe(true);
        if (pwConfig.defaultCurrency == "USD") {
            //Verify estimated price
            await ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(await ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(spannerTemplate.TotalCost);
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(spannerTemplate.TotalCost).toContain(totalCostBOM);
        }
        await ordersPage.clickServiceDetailSliderCloseButton(); 
        await ordersPage.denyOrder(orderNumber);
        expect(await ordersPage.getOrderStatus(orderNumber)).toEqual(genericTestData.rejctdState); 
        await ordersPage.clickServiceDetailSliderCloseButton();
        await orderHistoryPage.open();
        await orderHistoryPage.searchOrderById(orderNumber);
        await orderHistoryPage.clickServiceDetails();
        //Validate Additional Parameters Details and BOM on Order History page
        expect(await orderHistoryPage.validateorderDetails(serviceConfParams)).toBe(true);
        if (pwConfig.defaultCurrency == "USD") {
            await orderHistoryPage.clickBOMServiceDetails();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(spannerTemplate.TotalCost)
            await orderHistoryPage.clickServiceDetailSliderCloseButton();
            await orderHistoryPage.clickBillOfMaterials();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(spannerTemplate.TotalCost)
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(spannerTemplate.TotalCost).toContain(totalCostBOM);
        }
        await orderHistoryPage.clickServiceDetailSliderCloseButton();

    });   

})
