const util = require("../../../../helpers/util.js");
const tcpLbTemplate = require('../../../../testData/orderIntegration/Google/gcpTcpLoadBalancing.json');
var modifiedParams = {}, mainParamsMap = {};

describe("GCP-TCP Load Balancer", () => {
    beforeEach(async () => {
        serviceName = "tcpLoadbal" + util.getRandomString(5),
        modifiedParams = { "Service Instance Prefix": serviceName.toLowerCase() };
        await catalogPage.open();
        await catalogPage.clickProvider(tcpLbTemplate.provider);
        await catalogPage.clickCategory(tcpLbTemplate.Category);
        await catalogPage.clickOnserviceName(tcpLbTemplate.bluePrintName);
        await catalogPage.clickConfigureBtn();
    });

    it('TCP Load Balancer - Validate Details on Main Parameter page', async () => {
        mainParamsMap = { "serviceName": serviceName, "Team": genericTestData.Team, "Env": genericTestData.Env, "App": genericTestData.App, "providerAccount": tcpLbTemplate.providerAccount };
        await mainParamPage.fillMainParameterPageDetails(mainParamsMap);
        //Validate Next button is enabled after entering details
        expect(await mainParamPage.isNextButtonEnabled()).toBe(true);
    });

    it('TCP Load Balancer : Verify Service Details are listed in Review Order page', async () => {
        var requiredReturnMap = await orderflow.fillOrderDetails(tcpLbTemplate, modifiedParams);
        //Validate all review order page parameters are as per input service configuration 
        expect(await placeOrderPage.validateReviewOrderPageParams(requiredReturnMap)).toEqual(true);
        //Validate Estimated Cost on Review Order Page for USD Tenants
        if (pwConfig.defaultCurrency == "USD") {
            expect(await placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(tcpLbTemplate.TotalCost);
            //BOM Validation as per components of service.
            expect(await placeOrderPage.validateBOMOnReviewOrderPage(tcpLbTemplate.Pricing)).toBe(true);
        }
    });

    it('TCP Load Balancer : Verify Order Details on Orders and Order History page once order is submitted', async () => {
        var serviceConfParams = await orderflow.fillOrderDetails(tcpLbTemplate, modifiedParams);
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(tcpLbTemplate.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.open();
        await ordersPage.searchOrderById(orderNumber);
        expect(await ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderNumber);
        expect(await ordersPage.getTextFirstAmountOrdersTable()).toEqual(tcpLbTemplate.EstimatedPrice)
        await ordersPage.clickFirstViewDetailsOrdersTable();
        //Validate Additional Parameters Details
        expect(await ordersPage.validateorderDetails(serviceConfParams)).toBe(true);
        if (pwConfig.defaultCurrency == "USD") {
            //Verify estimated price
            await ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(await ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(tcpLbTemplate.TotalCost);
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(tcpLbTemplate.TotalCost).toEqual(totalCostBOM);
        }
        await ordersPage.clickServiceDetailSliderCloseButton();
        await orderHistoryPage.open();
        await orderHistoryPage.searchOrderById(orderNumber);
        await orderHistoryPage.clickServiceDetails();
        //Validate Additional Parameters Details and BOM on Order History page
        expect(await orderHistoryPage.validateorderDetails(serviceConfParams)).toBe(true);
        if (pwConfig.defaultCurrency == "USD") {
            await orderHistoryPage.clickBOMServiceDetails();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(tcpLbTemplate.TotalCost)
            await orderHistoryPage.clickServiceDetailSliderCloseButton();
            await orderHistoryPage.clickBillOfMaterials();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(tcpLbTemplate.TotalCost)
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(tcpLbTemplate.TotalCost).toEqual(totalCostBOM);
        }
        await orderHistoryPage.clickServiceDetailSliderCloseButton();

    });

    it('TCP Load Balancer - Provision and Delete Service', async () => {
        var orderObject = {};
        orderObject.servicename = serviceName
        await orderflow.fillOrderDetails(tcpLbTemplate, modifiedParams);
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(tcpLbTemplate.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.approveOrder(orderNumber);
        await ordersPage.waitUntilOrderStatusChange(orderNumber, genericTestData.completedState);
        var orderStatus = await ordersPage.getOrderStatus(orderNumber);
        expect(orderStatus).toEqual(genericTestData.completedState);
        if (orderStatus == genericTestData.completedState) {
            var deleteOrderNo = await orderedServicesPage.deleteServiceAndSaveOrderId(tcpLbTemplate.bluePrintName, serviceName);
            await ordersPage.approveOrder(deleteOrderNo);
            await ordersPage.waitUntilOrderStatusChange(deleteOrderNo, genericTestData.completedState);
            var deleteOrderStatus = await ordersPage.getOrderStatus(deleteOrderNo);
            expect(deleteOrderStatus).toEqual(genericTestData.completedState);
        }
    });


})
