const util = require("../../../../helpers/util.js");
const vpcTemp = require('../../../../testData/orderIntegration/Google/vpc.json');
var modifiedParams = {},mainParamsMap = {}, orderObject = {}, vpcName;
  
describe("GCP-VPC Network", () => {
    beforeEach(async () => {
        serviceName = "autovpc" + util.getRandomString(5),
        vpcName = "auto-vpc-" + util.getRandomString(5).toLowerCase();        		
        modifiedParams = { "Service Instance Prefix": serviceName, "Name": vpcName };
        await catalogPage.open();
        await catalogPage.clickProvider(vpcTemp.provider);
        await catalogPage.clickCategory(vpcTemp.Category);
        await catalogPage.clickOnserviceName(vpcTemp.bluePrintName);
        await catalogPage.clickConfigureBtn();
    });
    
    it('VPC - Validate Details on Main Parameter page', async () => {
        mainParamsMap = { "serviceName": serviceName, "Team": genericTestData.Team, "Env": genericTestData.Env, "App": genericTestData.App, "providerAccount": vpcTemp.providerAccount };
        await mainParamPage.fillMainParameterPageDetails(mainParamsMap);
        //Validate Next button is enabled after entering details
        expect(await mainParamPage.isNextButtonEnabled()).toBe(true);
    });

    it('VPC : Verify Service Details are listed in Review Order page', async () => {
        var requiredReturnMap = await orderflow.fillOrderDetails(vpcTemp, modifiedParams);
        //Validate all review order page parameters are as per input service configuration 
        expect(await placeOrderPage.validateReviewOrderPageParams(requiredReturnMap)).toEqual(true);
        //Validate Estimated Cost on Review Order Page for USD Tenants
        if(pwConfig.defaultCurrency == "USD") {
            expect(vpcTemp.TotalCost).toContain(await placeOrderPage.getEstimatedPrice_ReviewOrder());
        }
    });
    
    it('VPC : Verify Order Details once order is submitted from catalog page', async () => {
        var serviceConfParams = await orderflow.fillOrderDetails(vpcTemp, modifiedParams);        
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(vpcTemp.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.open();
        await ordersPage.searchOrderById(orderNumber);
        expect(await ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderNumber);
        expect(await ordersPage.getTextFirstAmountOrdersTable()).toEqual(vpcTemp.EstimatedPrice)
        await ordersPage.clickFirstViewDetailsOrdersTable();
        //Validate Additional Parameters Details
        expect(await ordersPage.validateorderDetails(serviceConfParams)).toBe(true);
        if(pwConfig.defaultCurrency == "USD") {
            //Verify estimated price
            await ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(await ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(vpcTemp.TotalCost);
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(vpcTemp.TotalCost).toContain(totalCostBOM);
        }
        await ordersPage.clickServiceDetailSliderCloseButton();
        await orderHistoryPage.open();
        await orderHistoryPage.searchOrderById(orderNumber);
        await orderHistoryPage.clickServiceDetails();
        //Validate Additional Parameters Details and BOM on Order History page
        expect(await orderHistoryPage.validateorderDetails(serviceConfParams)).toBe(true);
        if(pwConfig.defaultCurrency == "USD") {
            await orderHistoryPage.clickBOMServiceDetails();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(vpcTemp.TotalCost)
            await orderHistoryPage.clickServiceDetailSliderCloseButton();
            await orderHistoryPage.clickBillOfMaterials();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(vpcTemp.TotalCost)
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(vpcTemp.TotalCost).toContain(totalCostBOM);
        }
        await orderHistoryPage.clickServiceDetailSliderCloseButton();   
        
    });
    
    it('VPC - Provision Service', async () => { 
        //var orderObject = {};
        orderObject.servicename = serviceName
        await orderflow.fillOrderDetails(vpcTemp, modifiedParams);       
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(vpcTemp.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.approveOrder(orderNumber);
        await ordersPage.waitUntilOrderStatusChange(orderNumber, genericTestData.completedState);
        var orderStatus = await ordersPage.getOrderStatus(orderNumber);
        expect(orderStatus).toEqual(genericTestData.completedState);
        if (pwConfig.isDummyAdapterDisabled == "true") {
            await orderedServicesPage.open();
            //Validate service Tags
            var tags = await orderedServicesPage.getImiTags(orderObject)
            var tagList = tags.split(",");
            var tagMap = await orderedServicesPage.getServiceTags(tagList);
            var mcmpTag = false;               
            if (Object.keys(tagMap).includes(genericTestData.systemTagText)) {
                mcmpTag = true;
            }
            expect(mcmpTag).toBe(true);
            //Verify system tags
            await orderedServicesPage.clickLabelsViewDetailsLink();
            expect(await orderedServicesPage.validateSystemTagValueIsDisplayed()).toBe(true);
            expect(await orderedServicesPage.getSystemTagLabel()).toEqual(genericTestData.systemTagText);
            expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderNumber);
            expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
            expect(tagMap["serviceofferingname"]).toEqual(vpcTemp.serviceOffrngName);
        }
    });
    
    it('VPC - Edit/Delete Service Instance', async () => {            
        //Edit Service instance       
        var editInsObject = JSON.parse(JSON.stringify(vpcTemp));
        var modifiedParamMapEdit = { "EditService": true };
        var modifiedParamMapEditNeg = { "EditService": true, "Service": "VPC Network", "Routing Mode": "", "Subnet creation mode": "", "Custom subnet": "", "Subnet name": "", "Region": "", "IP address range": "" };
        await orderedServicesPage.editService(orderObject.servicename);
        //Negative Scenario for Edit
        var reviewOrderExpActParamsMap = await orderflow.fillOrderDetails(vpcTemp, modifiedParamMapEditNeg)
        //Validate Edited Parmeters on review order page
        expect(await placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextEditOrderErrorMsg()).toBe(genericTestData.editOrderErrorMessage);
        await placeOrderPage.clickPreviousBtn();
		await placeOrderPage.clickPreviousBtn();
        //Perform valid edit flow
        delete editInsObject["Edit Parameters"]["Main Parameters"];
        var reviewOrderExpActParamsMapP = await orderflow.fillOrderDetails(editInsObject, modifiedParamMapEdit)
        
        //Validate Review order page parameters
		expect(await placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMapP)).toBe(true);
        if (pwConfig.defaultCurrency == "USD") {
            // Checking cost of BOM on Updated BOM tab (review Order Page)					
            expect(await placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(vpcTemp.TotalCostAfterEdit);
        }
        await placeOrderPage.submitOrder();
        var editOrderNumber = await placeOrderPage.getAndSaveOrderId(vpcTemp.bluePrintName, genericTestData.editOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.approveOrder(editOrderNumber);
        await ordersPage.waitUntilOrderStatusChange(editOrderNumber, genericTestData.completedState);
        //Validate edited details
        await ordersPage.open();
        await ordersPage.searchOrderById(editOrderNumber);
        expect(await ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(editOrderNumber);        
        await ordersPage.clickFirstViewDetailsOrdersTable();
        //Validate Additional Parameters Details          
        expect(await ordersPage.validateorderDetails(reviewOrderExpActParamsMap)).toBe(true);
        if (pwConfig.defaultCurrency == "USD") {
            await ordersPage.clickBillOfMaterialsTabOrderDetails();
            // Checking cost of BOM on Updated BOM tab (Orders Page)
            var totalCostUpdated = await ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails();
            expect(vpcTemp.TotalCostAfterEdit).toContain(totalCostUpdated);
            //Checking cost of BOM on Current BOM tab(Orders Page)
            var totalCostBOM = await ordersPage.getCurrentBOMTablePrice();
            expect(vpcTemp.TotalCost).toContain(totalCostBOM);
            //Verify details on orderHistory page 
            await orderHistoryPage.open();
            await orderHistoryPage.searchOrderById(editOrderNumber);
            await orderHistoryPage.clickServiceDetails();
            //Validate Additional Parameters Details and BOM on Order History page
            expect(await orderHistoryPage.validateorderDetails(reviewOrderExpActParamsMap)).toBe(true);
            await orderHistoryPage.clickBOMServiceDetails();
            // Checking cost of BOM on Updated BOM tab(order History Page)
            totalCostUpdated = await orderHistoryPage.getUpdatedBOMTablePrice();
            expect(vpcTemp.TotalCostAfterEdit).toContain(totalCostUpdated);
            // Checking cost of BOM on Current BOM tab(order History Page)
            totalCostBOM = await ordersPage.getCurrentBOMTablePrice();
            expect(vpcTemp.TotalCost).toContain(totalCostBOM);
            await orderHistoryPage.clickServiceDetailSliderCloseButton();
            //Validate Details on Ordered Services page
            await orderedServicesPage.open();
            await orderedServicesPage.searchOrderByServiceName(orderObject.servicename);
            totalCostUpdated = await orderedServicesPage.getBOMTablePrice();
            expect(vpcTemp.TotalCostAfterEdit).toContain(totalCostUpdated);
            
            if (pwConfig.isDummyAdapterDisabled == 'true') {
                //Validate System tags
                await orderedServicesPage.open();
                await orderedServicesPage.searchOrderByServiceName(orderObject.servicename);
                await orderedServicesPage.clickExpandFirstRow()                        
                await orderedServicesPage.clickOverflowActionButtonForPowerStates()
                await orderedServicesPage.clickViewComponent()
                await orderedServicesPage.clickLabelsViewDetailsLink();
                //Verify system tags
                expect(await orderedServicesPage.validateSystemTagValueIsDisplayed()).toBe(true);
                expect(await orderedServicesPage.getSystemTagLabel()).toEqual(genericTestData.systemTagText);
                                           
            }
            await orderedServicesPage.clickServiceDetailSliderCloseButton();
            await orderedServicesPage.clickExpandFirstRow();   

            // if (pwConfig.isDummyAdapterDisabled == "true") {
            //     inventoryPage.open();
            //     //Validate service Tags
            //     inventoryPage.getImiTags(orderObject).then(function (tags) {
            //         var tagList = tags.split(",");
            //         var tagMap = inventoryPage.getServiceTags(tagList);
            //         var mcmpTag = false;
            //         if (isDummyAdapterDisabled == "true") {
            //             if (Object.keys(tagMap).includes(messageStrings.systemTagText)) {
            //                 mcmpTag = true;
            //             }
            //             expect(mcmpTag).toBe(true);
            //             //Verify system tags
            //             inventoryPage.clickLabelsViewDetailsLink();
            //             expect(inventoryPage.validateSystemTagValueIsDisplayed()).toBe(true);
            //             expect(inventoryPage.getSystemTagLabel()).toEqual(messageStrings.systemTagText);
            //         }
            //         expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderObject.orderNumber);
            //         expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
            //         expect(tagMap["serviceofferingname"]).toEqual(vpcTemplate.serviceOffrngName);
            //         orderFlowUtil.closeHorizontalSliderIfPresent();
            //     });
            // }
        }                       
        
        var deleteOrderNo = await orderedServicesPage.deleteServiceAndSaveOrderId(vpcTemp.bluePrintName, orderObject.servicename);
        await ordersPage.approveOrder(deleteOrderNo);
        await ordersPage.waitUntilOrderStatusChange(deleteOrderNo, genericTestData.completedState);
        var deleteOrderStatus = await ordersPage.getOrderStatus(deleteOrderNo);
        expect(deleteOrderStatus).toEqual(genericTestData.completedState);
    });
    
})
