const util = require("../../../../helpers/util.js");
const computeTemp = require('../../../../testData/orderIntegration/Google/gcpComputeIns.json');
var modifiedParams = {},mainParamsMap = {}, orderObject = {}, instanceName, serviceName;
  
describe("GCP-Compute Engine", () => {
    beforeEach(async () => {
        serviceName = "att-compute-engine-" + util.getRandomString(5);
        instanceName = "att-vm-" + util.getRandomString(3);
        instanceName =  instanceName.toLowerCase();
        modifiedParams = { "Service Instance Prefix": serviceName, "Quantity": "2", "Instance Name": instanceName };		
    });

    xit('Compute Engine : Verify Only One service is displaying after searching with servicename', async () => {
        catalogPage.open();
        catalogPage.clickFirstCategoryCheckBoxBasedOnName("All Categories");      
        catalogPage.searchForBluePrint(gcpComputeInsTemplate.bluePrintName);
        expect(catalogPage.checkServiceIsPresent(gcpComputeInsTemplate.bluePrintName)).toEqual(true);
        expect(catalogPage.validateIfOneServiceIsDisplayed()).toEqual(1);
    });

    it('Compute Engine - Validate Details on Main Parameter page', async () => {
        await catalogPage.open();
        await catalogPage.clickProvider(computeTemp.provider);
        await catalogPage.clickCategory(computeTemp.Category);
        await catalogPage.clickOnserviceName(computeTemp.bluePrintName);
        await catalogPage.clickConfigureBtn();
        mainParamsMap = { "serviceName": serviceName, "Team": genericTestData.Team, "Env": genericTestData.Env, "App": genericTestData.App, "providerAccount": computeTemp.providerAccount };
        await mainParamPage.fillMainParameterPageDetails(mainParamsMap);
        //Validate Next button is enabled after entering details
        expect(await mainParamPage.isNextButtonEnabled()).toBe(true);
    });

    it('Compute Engine : Verify Service Details are listed in Review Order page', async () => {
        await catalogPage.open();
        await catalogPage.clickProvider(computeTemp.provider);
        await catalogPage.clickCategory(computeTemp.Category);
        await catalogPage.clickOnserviceName(computeTemp.bluePrintName);
        await catalogPage.clickConfigureBtn();
        var requiredReturnMap = await orderflow.fillOrderDetails(computeTemp, modifiedParams);
        //Validate all review order page parameters are as per input service configuration 
        expect(await placeOrderPage.validateReviewOrderPageParams(requiredReturnMap)).toEqual(true);
        //Validate Estimated Cost on Review Order Page for USD Tenants
        if(pwConfig.defaultCurrency == "USD") {
            expect(computeTemp.TotalCost).toContain(await placeOrderPage.getEstimatedPrice_ReviewOrder());
            //BOM Validation as per components of service.
            expect(await placeOrderPage.validateBOMOnReviewOrderPage(computeTemp.Pricing)).toBe(true);    
        }
    });
    
    it('Compute Engine : Verify Order Details once order is submitted from catalog page', async () => {
        await catalogPage.open();
        await catalogPage.clickProvider(computeTemp.provider);
        await catalogPage.clickCategory(computeTemp.Category);
        await catalogPage.clickOnserviceName(computeTemp.bluePrintName);
        await catalogPage.clickConfigureBtn();
        var serviceConfParams = await orderflow.fillOrderDetails(computeTemp, modifiedParams);        
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(computeTemp.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.open();
        await ordersPage.searchOrderById(orderNumber);
        expect(await ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderNumber);
        expect(await ordersPage.getTextFirstAmountOrdersTable()).toEqual(computeTemp.EstimatedPrice)
        await ordersPage.clickFirstViewDetailsOrdersTable();
        //Validate Additional Parameters Details
        expect(await ordersPage.validateorderDetails(serviceConfParams)).toBe(true);
        if(pwConfig.defaultCurrency == "USD") {
            //Verify estimated price
            await ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(await ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(computeTemp.TotalCost);
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(computeTemp.TotalCost).toContain(totalCostBOM);
        }
        await ordersPage.clickServiceDetailSliderCloseButton();
        await orderHistoryPage.open();
        await orderHistoryPage.searchOrderById(orderNumber);
        await orderHistoryPage.clickServiceDetails();
        //Validate Additional Parameters Details and BOM on Order History page
        expect(await orderHistoryPage.validateorderDetails(serviceConfParams)).toBe(true);
        if(pwConfig.defaultCurrency == "USD") {
            await orderHistoryPage.clickBOMServiceDetails();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(computeTemp.TotalCost)
            await orderHistoryPage.clickServiceDetailSliderCloseButton();
            await orderHistoryPage.clickBillOfMaterials();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(computeTemp.TotalCost)
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(computeTemp.TotalCost).toContain(totalCostBOM);
        }
        await orderHistoryPage.clickServiceDetailSliderCloseButton();   
        
    });
    
    it('Compute Engine - Provision Service', async () => {
        await catalogPage.open();
        await catalogPage.clickProvider(computeTemp.provider);
        await catalogPage.clickCategory(computeTemp.Category);
        await catalogPage.clickOnserviceName(computeTemp.bluePrintName);
        await catalogPage.clickConfigureBtn();
        modifiedParams = { "Service Instance Prefix": serviceName, "Quantity": "1", "Instance Name": instanceName };
        orderObject.servicename = serviceName
        await orderflow.fillOrderDetails(computeTemp, modifiedParams);       
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(computeTemp.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.approveOrder(orderNumber);
        await ordersPage.waitUntilOrderStatusChange(orderNumber, genericTestData.completedState);
        var orderStatus = await ordersPage.getOrderStatus(orderNumber);
        expect(orderStatus).toEqual(genericTestData.completedState);
        if (pwConfig.isDummyAdapterDisabled == "true") {
            await orderedServicesPage.open();
            //Validate service Tags
            var tags = await orderedServicesPage.getImiTags(orderObject)
            var tagList = tags.split(",");
            var tagMap = await orderedServicesPage.getServiceTags(tagList);
            var mcmpTag = false;               
            if (Object.keys(tagMap).includes(genericTestData.systemTagText)) {
                mcmpTag = true;
            }
            expect(mcmpTag).toBe(true);
            //Verify system tags
            await orderedServicesPage.clickLabelsViewDetailsLink();
            expect(await orderedServicesPage.validateSystemTagValueIsDisplayed()).toBe(true);
            expect(await orderedServicesPage.getSystemTagLabel()).toEqual(genericTestData.systemTagText);
            expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderNumber);
            expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
            expect(tagMap["serviceofferingname"]).toEqual(computeTemp.serviceOffrngName);
        }
    });
    
    it('Compute Engine - Edit Service Instance', async () => {        
        //Edit Service instance       
        var modifiedParamMapEdit = { "EditService": true };
        await orderedServicesPage.editService(orderObject.servicename);
        var reviewOrderExpActParamsMap = await orderflow.fillOrderDetails(computeTemp, modifiedParamMapEdit)
        //Validate Edited Parmeters on review order page
        expect(await placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
        if (pwConfig.defaultCurrency == "USD") {
            // Checking cost of BOM on Updated BOM tab (review Order Page)					
            expect(await placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(computeTemp.TotalCostAfterEdit);
        }
        await placeOrderPage.submitOrder();
        var editOrderNumber = await placeOrderPage.getAndSaveOrderId(computeTemp.bluePrintName, genericTestData.editOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.approveOrder(editOrderNumber);
        await ordersPage.waitUntilOrderStatusChange(editOrderNumber, genericTestData.completedState);
        //Validate edited details
        await ordersPage.open();
        await ordersPage.searchOrderById(editOrderNumber);
        expect(await ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(editOrderNumber);        
        await ordersPage.clickFirstViewDetailsOrdersTable();
        //Validate Additional Parameters Details          
        expect(await ordersPage.validateorderDetails(reviewOrderExpActParamsMap)).toBe(true);
        if (pwConfig.defaultCurrency == "USD") {
            await ordersPage.clickBillOfMaterialsTabOrderDetails();
            // Checking cost of BOM on Updated BOM tab (Orders Page)
            var totalCostUpdated = await ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails();
            expect(computeTemp.TotalCostAfterEdit).toContain(totalCostUpdated);
            //Checking cost of BOM on Current BOM tab(Orders Page)
            var totalCostBOM = await ordersPage.getCurrentBOMTablePrice();
            expect(computeTemp.TotalCostSingleInstance).toContain(totalCostBOM);
            //Verify details on orderHistory page 
            await orderHistoryPage.open();
            await orderHistoryPage.searchOrderById(editOrderNumber);
            await orderHistoryPage.clickServiceDetails();
            //Validate Additional Parameters Details and BOM on Order History page
            expect(await orderHistoryPage.validateorderDetails(reviewOrderExpActParamsMap)).toBe(true);
            await orderHistoryPage.clickBOMServiceDetails();
            // Checking cost of BOM on Updated BOM tab(order History Page)
            totalCostUpdated = await orderHistoryPage.getUpdatedBOMTablePrice();
            expect(computeTemp.TotalCostAfterEdit).toContain(totalCostUpdated);
            // Checking cost of BOM on Current BOM tab(order History Page)
            totalCostBOM = await ordersPage.getCurrentBOMTablePrice();
            expect(computeTemp.TotalCostSingleInstance).toContain(totalCostBOM);
            await orderHistoryPage.clickServiceDetailSliderCloseButton();
            //Validate Details on Ordered Services page
            await orderedServicesPage.open();
            await orderedServicesPage.searchOrderByServiceName(orderObject.servicename);
            totalCostUpdated = await orderedServicesPage.getBOMTablePrice();
            expect(computeTemp.TotalCostAfterEdit).toContain(totalCostUpdated);

            if (pwConfig.isDummyAdapterDisabled == 'true') {
                //Validate System tags
                await orderedServicesPage.open();
                await orderedServicesPage.searchOrderByServiceName(orderObject.servicename);
                await orderedServicesPage.clickExpandFirstRow()                        
                await orderedServicesPage.clickOverflowActionButtonForPowerStates()
                await orderedServicesPage.clickViewComponent()
                await orderedServicesPage.clickLabelsViewDetailsLink();
                //Verify system tags
                expect(await orderedServicesPage.validateSystemTagValueIsDisplayed()).toBe(true);
                expect(await orderedServicesPage.getSystemTagLabel()).toEqual(genericTestData.systemTagText);
                await orderedServicesPage.clickServiceDetailSliderCloseButton();
                await orderedServicesPage.clickExpandFirstRow();                            
            }

            // if (pwConfig.isDummyAdapterDisabled == "true") {
            //     inventoryPage.open();
            //     //Validate service Tags
            //     inventoryPage.getImiTags(orderObject).then(function (tags) {
            //         var tagList = tags.split(",");
            //         var tagMap = inventoryPage.getServiceTags(tagList);
            //         var mcmpTag = false;
            //         if (isDummyAdapterDisabled == "true") {
            //             if (Object.keys(tagMap).includes(messageStrings.systemTagText)) {
            //                 mcmpTag = true;
            //             }
            //             expect(mcmpTag).toBe(true);
            //             //Verify system tags
            //             inventoryPage.clickLabelsViewDetailsLink();
            //             expect(inventoryPage.validateSystemTagValueIsDisplayed()).toBe(true);
            //             expect(inventoryPage.getSystemTagLabel()).toEqual(messageStrings.systemTagText);
            //         }
            //         expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderObject.orderNumber);
            //         expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
            //         expect(tagMap["serviceofferingname"]).toEqual(computeTemplate.serviceOffrngName);
            //         orderFlowUtil.closeHorizontalSliderIfPresent();
            //     });
            // }
        }
    });

    // if (pwConfig.isDummyAdapterDisabled == 'true') {

    //     it('Compute Engine - Verify system tags of provisioned resources after Editing service', async () => {
    //         serviceName = orderObject.servicename;
    //         inventoryPage.open();
    //         inventoryPage.getImiTags(orderObject).then(function (tags) {
    //             var tagList = tags.split(",");
    //             var tagMap = inventoryPage.getServiceTags(tagList);
    //             var mcmpTag = false;               
    //             if (Object.keys(tagMap).includes(messageStrings.systemTagText)) {
    //                 mcmpTag = true;
    //             }
    //             expect(mcmpTag).toBe(true);
    //             inventoryPage.clickLabelsViewDetailsLink();
    //             //Verify system tags
    //             expect(inventoryPage.validateSystemTagValueIsDisplayed()).toBe(true);
    //             expect(inventoryPage.getSystemTagLabel()).toEqual(messageStrings.systemTagText);
               
    //             expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderObject.orderNumber);
    //             expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
    //             expect(tagMap["serviceofferingname"]).toEqual(gcpComputeInsTemplate.serviceOffrngName);
    //             orderFlowUtil.closeHorizontalSliderIfPresent();
    //         });
    //     });

    //     it('Compute Engine - Verify View Component-Template Output Parameters for the powered ON VM', async () => {

    //         var vmName = orderObject.instanceName;
    //         var val = JSON.stringify({ "IsUsingDummy": "Yes" });
    //         vmName = vmName.toLowerCase();
    //         inventoryPage.open();
    //         inventoryPage.searchOrderByServiceName(orderObject.servicename);
    //         inventoryPage.clickExpandFirstRow().then(function () {
    //             inventoryPage.getComponentTags().then(function (text) {
    //                 if (val == text) {
    //                     //Status for dummy adapter
    //                     messageStrings.componentType = 'compute.v1.instance';
    //                 }
    //                 inventoryPage.clickOverflowActionButtonForPowerStates().then(function () {
    //                     inventoryPage.clickViewComponentofAWSInstance().then(function () {
    //                         //View Component VM details
    //                         expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Component Type")).toEqual(messageStrings.componentType);
    //                         expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Name")).toContain(vmName);
    //                         expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Status")).toEqual(messageStrings.powerStateOn);
    //                         expect(inventoryPage.getViewComponentVMdetailsBasedOnLabelText("Provider Name")).toEqual(messageStrings.providerName);

    //                         //View Component Template Output Properties
    //                         expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("name")).toContain(vmName);
    //                         expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("machineType")).toContain(gcpComputeInsTemplate.machineTypeForVm);
    //                         expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("zone")).toContain(messageStrings.zone);
    //                         expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("canIpForward")).toEqual(messageStrings.Canipforward);
    //                         expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("cpuPlatform")).toEqual(messageStrings.Cpuplatform);
    //                         expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("deletionProtection")).toEqual(messageStrings.Deletionprotection);
    //                         expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("kind")).toEqual(messageStrings.kind);
    //                         expect(inventoryPage.getViewComponentTempOPPropBasedOnLabelText("startRestricted")).toEqual(messageStrings.Startrestricted);
    //                         inventoryPage.closeViewComponent();
    //                     });
    //                 });
    //             });

    //         });
    //     });
    // }

    it("Compute Engine - Verify instance Turn OFF functionality", async () => {        
        await orderedServicesPage.open();
        await orderedServicesPage.searchOrderByServiceName(orderObject.servicename);
        await orderedServicesPage.clickExpandFirstRow();
        await orderedServicesPage.clickOverflowActionButtonForPowerStates();
        await orderedServicesPage.clickD2opsBtn(computeTemp.bluePrintNameTurnOff);
        await orderedServicesPage.fetchD2opsOrderDetails();
        expect(await orderedServicesPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(genericTestData.orderSubmittedConfirmationMessage);          
        orderObject.orderNumber = await orderedServicesPage.getAndSaveOrderId(computeTemp.bluePrintName, computeTemp.bluePrintNameTurnOff);
        await orderedServicesPage.clickOkbtnOrderSubmission();
        await ordersPage.waitUntilOrderStatusChange(orderObject.orderNumber, genericTestData.completedState);
        expect(await ordersPage.getOrderStatus(orderObject.orderNumber)).toBe(genericTestData.completedState);
        expect(await ordersPage.getTextFirstOrderTypeOrdersTable()).toBe(genericTestData.orderTypeAction);
        expect(await ordersPage.getServiceNameOfferingText()).toBe(genericTestData.actnTurnOff);

    });
    
    it("Compute Engine - Verify instance Turn ON functionality", async () => {        
        await orderedServicesPage.open();
        await orderedServicesPage.searchOrderByServiceName(orderObject.servicename);
        await orderedServicesPage.clickExpandFirstRow();
        await orderedServicesPage.clickOverflowActionButtonForPowerStates();
        await orderedServicesPage.clickD2opsBtn(computeTemp.bluePrintNameTurnOn);
        await orderedServicesPage.fetchD2opsOrderDetails();
        expect(await orderedServicesPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(genericTestData.orderSubmittedConfirmationMessage);          
        orderObject.orderNumber = await orderedServicesPage.getAndSaveOrderId(computeTemp.bluePrintName, computeTemp.bluePrintNameTurnOn);
        await orderedServicesPage.clickOkbtnOrderSubmission();
        await ordersPage.waitUntilOrderStatusChange(orderObject.orderNumber, genericTestData.completedState);
        expect(await ordersPage.getOrderStatus(orderObject.orderNumber)).toBe(genericTestData.completedState);
        expect(await ordersPage.getTextFirstOrderTypeOrdersTable()).toBe(genericTestData.orderTypeAction);
        expect(await ordersPage.getServiceNameOfferingText()).toBe(genericTestData.actbTurnOn);

    });

    it("Compute Engine - Verify instance Reboot functionality", async () => {        
        await orderedServicesPage.open();
        await orderedServicesPage.searchOrderByServiceName(orderObject.servicename);
        await orderedServicesPage.clickExpandFirstRow();
        await orderedServicesPage.clickOverflowActionButtonForPowerStates();
        await orderedServicesPage.clickD2opsBtn(computeTemp.bluePrintNameReboot);
        await orderedServicesPage.fetchD2opsOrderDetails();
        expect(await orderedServicesPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(genericTestData.orderSubmittedConfirmationMessage);          
        orderObject.orderNumber = await orderedServicesPage.getAndSaveOrderId(computeTemp.bluePrintName, computeTemp.bluePrintNameReboot);
        await orderedServicesPage.clickOkbtnOrderSubmission();
        await ordersPage.waitUntilOrderStatusChange(orderObject.orderNumber, genericTestData.completedState);
        expect(await ordersPage.getOrderStatus(orderObject.orderNumber)).toBe(genericTestData.completedState);
        expect(await ordersPage.getTextFirstOrderTypeOrdersTable()).toBe(genericTestData.orderTypeAction);
        expect(await ordersPage.getServiceNameOfferingText()).toBe(computeTemp.bluePrintNameReboot);
        //Delete order
        var deleteOrderNo = await orderedServicesPage.deleteServiceAndSaveOrderId(computeTemp.bluePrintName, orderObject.servicename);
        await ordersPage.approveOrder(deleteOrderNo);
        await ordersPage.waitUntilOrderStatusChange(deleteOrderNo, genericTestData.completedState);
        var deleteOrderStatus = await ordersPage.getOrderStatus(deleteOrderNo);
        expect(deleteOrderStatus).toEqual(genericTestData.completedState);
    });
    
})
