const util = require("../../../../helpers/util.js");
const pubSubTemplate = require('../../../../testData/orderIntegration/Google/pubsub.json');
var modifiedParams = {},mainParamsMap = {};
  
describe("GCP-PubSub", () => {
    beforeEach(async () => {
        serviceName = "pubsub1" + util.getRandomString(5),
        topicName = "testTopic" + util.getRandomString(5);
        modifiedParams = { "Service Instance Prefix": serviceName.toLowerCase(), "Name": topicName.toLowerCase() };
        await catalogPage.open();
        await catalogPage.clickProvider(pubSubTemplate.provider);
        await catalogPage.clickCategory(pubSubTemplate.Category);
        await catalogPage.clickOnserviceName(pubSubTemplate.bluePrintName);
        await catalogPage.clickConfigureBtn();
    });

    it('PubSub - Validate Details on Main Parameter page', async () => {
        mainParamsMap = { "serviceName": serviceName, "Team": genericTestData.Team, "Env": genericTestData.Env, "App": genericTestData.App, "providerAccount": pubSubTemplate.providerAccount };
        await mainParamPage.fillMainParameterPageDetails(mainParamsMap);
        //Validate Next button is enabled after entering details
        expect(await mainParamPage.isNextButtonEnabled()).toBe(true);
    });

    it('PubSub : Verify Service Details are listed in Review Order page', async () => {
        var requiredReturnMap = await orderflow.fillOrderDetails(pubSubTemplate, modifiedParams);
        //Validate all review order page parameters are as per input service configuration 
        expect(await placeOrderPage.validateReviewOrderPageParams(requiredReturnMap)).toEqual(true);
        //Validate Estimated Cost on Review Order Page for USD Tenants
        if(pwConfig.defaultCurrency == "USD") {
            expect(await placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(pubSubTemplate.TotalCost);    
        }
    });
    
    it('PubSub : Verify Order Details once order is submitted from catalog page', async () => {
        var serviceConfParams = await orderflow.fillOrderDetails(pubSubTemplate, modifiedParams);        
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(pubSubTemplate.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.open();
        await ordersPage.searchOrderById(orderNumber);
        expect(await ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderNumber);
        expect(await ordersPage.getTextFirstAmountOrdersTable()).toEqual(pubSubTemplate.EstimatedPrice)
        await ordersPage.clickFirstViewDetailsOrdersTable();
        //Validate Additional Parameters Details
        expect(await ordersPage.validateorderDetails(serviceConfParams)).toBe(true);
        if(pwConfig.defaultCurrency == "USD") {
            //Verify estimated price
            await ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(await ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(pubSubTemplate.TotalCost);
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(pubSubTemplate.TotalCost).toContain(totalCostBOM);
        }
        await ordersPage.clickServiceDetailSliderCloseButton(); 
        await ordersPage.denyOrder(orderNumber);
        expect(await ordersPage.getOrderStatus(orderNumber)).toEqual(genericTestData.rejctdState); 
        
        await orderHistoryPage.open();
        await orderHistoryPage.searchOrderById(orderNumber);
        await orderHistoryPage.clickServiceDetails();
        //Validate Additional Parameters Details and BOM on Order History page
        expect(await orderHistoryPage.validateorderDetails(serviceConfParams)).toBe(true);
        if(pwConfig.defaultCurrency == "USD") {
            await orderHistoryPage.clickBOMServiceDetails();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(pubSubTemplate.TotalCost)
            await orderHistoryPage.clickServiceDetailSliderCloseButton();
            await orderHistoryPage.clickBillOfMaterials();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(pubSubTemplate.TotalCost)
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(pubSubTemplate.TotalCost).toContain(totalCostBOM);
        }
        await orderHistoryPage.clickServiceDetailSliderCloseButton();   
        
    });
    
    it('PubSub - Provision and Delete Service', async () => { 
        var orderObject = {};
        orderObject.servicename = serviceName       
        await orderflow.fillOrderDetails(pubSubTemplate, modifiedParams);       
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(pubSubTemplate.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.approveOrder(orderNumber);
        await ordersPage.waitUntilOrderStatusChange(orderNumber, genericTestData.completedState);
        var orderStatus = await ordersPage.getOrderStatus(orderNumber);
        expect(orderStatus).toEqual(genericTestData.completedState);
        //Delete Service
        if (orderStatus == genericTestData.completedState) {
            if (pwConfig.isDummyAdapterDisabled == "true") {
                await orderedServicesPage.open();
                //Validate service Tags
                var tags = await orderedServicesPage.getImiTags(orderObject)//.then(function (tags) {
                var tagList = tags.split(",");
                var tagMap = await orderedServicesPage.getServiceTags(tagList);
                var mcmpTag = false;
                //if (pwConfig.isDummyAdapterDisabled == "true") {
                    if (Object.keys(tagMap).includes(genericTestData.systemTagText)) {
                        mcmpTag = true;
                    }
                    expect(mcmpTag).toBe(true);
                    await orderedServicesPage.clickLabelsViewDetailsLink();
                    //Verify system tags
                    expect(await orderedServicesPage.validateSystemTagValueIsDisplayed()).toBe(true);
                    expect(await orderedServicesPage.getSystemTagLabel()).toEqual(genericTestData.systemTagText);
                //}
                expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderNumber);
                expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
                expect(tagMap["serviceofferingname"]).toEqual(pubSubTemplate.serviceOffrngName);
                await orderedServicesPage.clickServiceDetailSliderCloseButton();
                //});
            }
            var deleteOrderNo = await orderedServicesPage.deleteServiceAndSaveOrderId(pubSubTemplate.bluePrintName, serviceName);
            await ordersPage.approveOrder(deleteOrderNo);
            await ordersPage.waitUntilOrderStatusChange(deleteOrderNo, genericTestData.completedState);
            var deleteOrderStatus = await ordersPage.getOrderStatus(deleteOrderNo);
            expect(deleteOrderStatus).toEqual(genericTestData.completedState);
        }
    });
    //To be done for Real Adapter
    // if (pwConfig.isProvisioningRequired == "true") {
    //     if (pwConfig.isDummyAdapterDisabled == 'true') {
    //         xit('Pub/Sub : Verify Proper failure message in case of provisioning failure', async () => {
    //             modifiedParams = { "Service Instance Name": serviceName, "Name": topicName, "Add Subscription": "click", "Subscription Name": suscrpName, "Delivery Type": "Push into an endpoint url", "Endpoint url": "test.com" };
    //             await orderflow.fillOrderDetails(pubSubTemplate, modifiedParams);       
    //             //Submit order
    //             await placeOrderPage.submitOrder();
    //             expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
    //             //Get order id        
    //             var orderNumber = await placeOrderPage.getAndSaveOrderId(pubSubTemplate.bluePrintName, genericTestData.newOrder);
    //             await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
    //             await ordersPage.approveOrder(orderNumber);
    //             await ordersPage.waitUntilOrderStatusChange(orderNumber, genericTestData.failedState);
    //             var orderStatus = await ordersPage.getOrderStatus(orderNumber);
    //             expect(orderStatus).toEqual(genericTestData.failedState);
    //             //Retry failed order
    //             if (orderStatus == genericTestData.failedState) {
    //                 var failurReason = await orderHistoryPage.getOrderFailureReason(orderNumber)
    //                 expect(failurReason).toContain(genericTestData.gcpOrderFailureMsg);
    //                 await orderHistoryPage.clickOrdersTableActionIcon();
    //                 await orderHistoryPage.clickOnOrderTableActionsRetryOption();
    //                 await orderHistoryPage.clickOnOrderTableActionsRetryYesButton();
    //                 await orderHistoryPage.clickOnOrderTableActionsRetryModelOkButton();                   
    //                 await ordersPage.waitUntilOrderStatusChange(orderNumber, genericTestData.failedState);
    //                 var orderStatus = await ordersPage.getOrderStatus(orderNumber);
    //                 expect(orderStatus).toEqual(genericTestData.failedState);
    //             }               
    //         });
    //     }
    // }

})
