const util = require("../../../../helpers/util.js");
const persistentTemp = require('../../../../testData/orderIntegration/Google/persistentdisk.json');
var modifiedParams = {},mainParamsMap = {}, orderObject = {};
  
describe("GCP-Persistent Disk", () => {
    beforeEach(async () => {
        serviceName = "autopersistentdisk" + util.getRandomString(5),        		
        modifiedParams = { "Service Instance Prefix": serviceName };
        await catalogPage.open();
        await catalogPage.clickProvider(persistentTemp.provider);
        await catalogPage.clickCategory(persistentTemp.Category);
        await catalogPage.clickOnserviceName(persistentTemp.bluePrintName);
        await catalogPage.clickConfigureBtn();
    });

    xit('Persistent Disk : Verify Only One service is displaying after searching with servicename', async () => {
		catalogPage.open();
		catalogPage.clickProviderOrCategoryCheckbox(persistentTemp.provider);
		catalogPage.clickProviderOrCategoryCheckbox(persistentTemp.Category);
		catalogPage.searchForBluePrint(persistentTemp.bluePrintName);
		expect(catalogPage.checkServiceIsPresent(persistentTemp.bluePrintName)).toEqual(true);
		expect(catalogPage.validateIfOneServiceIsDisplayed()).toEqual(1);
	});

    it('Persistent Disk - Validate Details on Main Parameter page', async () => {
        mainParamsMap = { "serviceName": serviceName, "Team": genericTestData.Team, "Env": genericTestData.Env, "App": genericTestData.App, "providerAccount": persistentTemp.providerAccount };
        await mainParamPage.fillMainParameterPageDetails(mainParamsMap);
        //Validate Next button is enabled after entering details
        expect(await mainParamPage.isNextButtonEnabled()).toBe(true);
    });

    it('Persistent Disk : Verify Service Details are listed in Review Order page', async () => {
        var requiredReturnMap = await orderflow.fillOrderDetails(persistentTemp, modifiedParams);
        //Validate all review order page parameters are as per input service configuration 
        expect(await placeOrderPage.validateReviewOrderPageParams(requiredReturnMap)).toEqual(true);
        //Validate Estimated Cost on Review Order Page for USD Tenants
        if(pwConfig.defaultCurrency == "USD") {
            expect(persistentTemp.TotalCost).toContain(await placeOrderPage.getEstimatedPrice_ReviewOrder());
            //BOM Validation as per components of service.
            expect(await placeOrderPage.validateBOMOnReviewOrderPage(persistentTemp.Pricing)).toBe(true);    
        }
    });
    
    it('Persistent Disk : Verify Order Details once order is submitted from catalog page', async () => {
        var serviceConfParams = await orderflow.fillOrderDetails(persistentTemp, modifiedParams);        
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(persistentTemp.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.open();
        await ordersPage.searchOrderById(orderNumber);
        expect(await ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderNumber);
        expect(await ordersPage.getTextFirstAmountOrdersTable()).toEqual(persistentTemp.EstimatedPrice)
        await ordersPage.clickFirstViewDetailsOrdersTable();
        //Validate Additional Parameters Details
        expect(await ordersPage.validateorderDetails(serviceConfParams)).toBe(true);
        if(pwConfig.defaultCurrency == "USD") {
            //Verify estimated price
            await ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(await ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(persistentTemp.TotalCost);
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(persistentTemp.TotalCost).toContain(totalCostBOM);
        }
        await ordersPage.clickServiceDetailSliderCloseButton();
        await orderHistoryPage.open();
        await orderHistoryPage.searchOrderById(orderNumber);
        await orderHistoryPage.clickServiceDetails();
        //Validate Additional Parameters Details and BOM on Order History page
        expect(await orderHistoryPage.validateorderDetails(serviceConfParams)).toBe(true);
        if(pwConfig.defaultCurrency == "USD") {
            await orderHistoryPage.clickBOMServiceDetails();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(persistentTemp.TotalCost)
            await orderHistoryPage.clickServiceDetailSliderCloseButton();
            await orderHistoryPage.clickBillOfMaterials();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(persistentTemp.TotalCost)
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(persistentTemp.TotalCost).toContain(totalCostBOM);
        }
        await orderHistoryPage.clickServiceDetailSliderCloseButton();   
        
    });
    
    it('Persistent Disk - Provision Service', async () => { 
        //var orderObject = {};
        orderObject.servicename = serviceName
        await orderflow.fillOrderDetails(persistentTemp, modifiedParams);       
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(persistentTemp.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.approveOrder(orderNumber);
        await ordersPage.waitUntilOrderStatusChange(orderNumber, genericTestData.completedState);
        var orderStatus = await ordersPage.getOrderStatus(orderNumber);
        expect(orderStatus).toEqual(genericTestData.completedState);
        if (pwConfig.isDummyAdapterDisabled == "true") {
            await orderedServicesPage.open();
            //Validate service Tags
            var tags = await orderedServicesPage.getImiTags(orderObject)
            var tagList = tags.split(",");
            var tagMap = await orderedServicesPage.getServiceTags(tagList);
            var mcmpTag = false;               
            if (Object.keys(tagMap).includes(genericTestData.systemTagText)) {
                mcmpTag = true;
            }
            expect(mcmpTag).toBe(true);
            //Verify system tags
            await orderedServicesPage.clickLabelsViewDetailsLink();
            expect(await orderedServicesPage.validateSystemTagValueIsDisplayed()).toBe(true);
            expect(await orderedServicesPage.getSystemTagLabel()).toEqual(genericTestData.systemTagText);
            expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderNumber);
            expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
            expect(tagMap["serviceofferingname"]).toEqual(persistentTemp.serviceOffrngName);
        }
    });
    
    it('Persistent Disk - Edit/Delete Service Instance', async () => {
        //orderObject.servicename = "autopersistentdiskSQ1A3"        
        //Edit Service instance
        var modifiedParamMapEdit = { "EditService": true };
        await orderedServicesPage.editService(orderObject.servicename);
        var reviewOrderExpActParamsMap = await orderflow.fillOrderDetails(persistentTemp, modifiedParamMapEdit)
        //Validate Edited Parmeters on review order page
        expect(await placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
        if (pwConfig.defaultCurrency == "USD") {
            // Checking cost of BOM on Updated BOM tab (review Order Page)					
            expect(await placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(persistentTemp.TotalCostAfterEdit);
        }
        await placeOrderPage.submitOrder();
        var editOrderNumber = await placeOrderPage.getAndSaveOrderId(persistentTemp.bluePrintName, genericTestData.editOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.approveOrder(editOrderNumber);
        await ordersPage.waitUntilOrderStatusChange(editOrderNumber, genericTestData.completedState);
        //Validate edited details
        await ordersPage.open();
        await ordersPage.searchOrderById(editOrderNumber);
        expect(await ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(editOrderNumber);        
        await ordersPage.clickFirstViewDetailsOrdersTable();
        //Validate Additional Parameters Details          
        expect(await ordersPage.validateorderDetails(reviewOrderExpActParamsMap)).toBe(true);
        if (pwConfig.defaultCurrency == "USD") {
            await ordersPage.clickBillOfMaterialsTabOrderDetails();
            // Checking cost of BOM on Updated BOM tab (Orders Page)
            var totalCostUpdated = await ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails();
            expect(persistentTemp.TotalCostAfterEdit).toContain(totalCostUpdated);
            //Checking cost of BOM on Current BOM tab(Orders Page)
            var totalCostBOM = await ordersPage.getCurrentBOMTablePrice();
            expect(persistentTemp.TotalCost).toContain(totalCostBOM);
            //Verify details on orderHistory page 
            await orderHistoryPage.open();
            await orderHistoryPage.searchOrderById(editOrderNumber);
            await orderHistoryPage.clickServiceDetails();
            //Validate Additional Parameters Details and BOM on Order History page
            expect(await orderHistoryPage.validateorderDetails(reviewOrderExpActParamsMap)).toBe(true);
            await orderHistoryPage.clickBOMServiceDetails();
            // Checking cost of BOM on Updated BOM tab(order History Page)
            totalCostUpdated = await orderHistoryPage.getUpdatedBOMTablePrice();
            expect(persistentTemp.TotalCostAfterEdit).toContain(totalCostUpdated);
            // Checking cost of BOM on Current BOM tab(order History Page)
            totalCostBOM = await ordersPage.getCurrentBOMTablePrice();
            expect(persistentTemp.TotalCost).toContain(totalCostBOM);
            await orderHistoryPage.clickServiceDetailSliderCloseButton();
            //Validate Details on Ordered Services page
            await orderedServicesPage.open();
            await orderedServicesPage.searchOrderByServiceName(orderObject.servicename);
            totalCostUpdated = await orderedServicesPage.getBOMTablePrice();
            expect(persistentTemp.TotalCostAfterEdit).toContain(totalCostUpdated);

            if (pwConfig.isDummyAdapterDisabled == 'true') {
                //Validate System tags
                await orderedServicesPage.open();
                await orderedServicesPage.searchOrderByServiceName(orderObject.servicename);
                await orderedServicesPage.clickExpandFirstRow()                        
                await orderedServicesPage.clickOverflowActionButtonForPowerStates()
                await orderedServicesPage.clickViewComponent()
                await orderedServicesPage.clickLabelsViewDetailsLink();
                //Verify system tags
                expect(await orderedServicesPage.validateSystemTagValueIsDisplayed()).toBe(true);
                expect(await orderedServicesPage.getSystemTagLabel()).toEqual(genericTestData.systemTagText);
                                       
            }

            // if (pwConfig.isDummyAdapterDisabled == "true") {
            //     inventoryPage.open();
            //     //Validate service Tags
            //     inventoryPage.getImiTags(orderObject).then(function (tags) {
            //         var tagList = tags.split(",");
            //         var tagMap = inventoryPage.getServiceTags(tagList);
            //         var mcmpTag = false;
            //         if (isDummyAdapterDisabled == "true") {
            //             if (Object.keys(tagMap).includes(messageStrings.systemTagText)) {
            //                 mcmpTag = true;
            //             }
            //             expect(mcmpTag).toBe(true);
            //             //Verify system tags
            //             inventoryPage.clickLabelsViewDetailsLink();
            //             expect(inventoryPage.validateSystemTagValueIsDisplayed()).toBe(true);
            //             expect(inventoryPage.getSystemTagLabel()).toEqual(messageStrings.systemTagText);
            //         }
            //         expect(tagMap["ordernumber"].toUpperCase()).toEqual(orderObject.orderNumber);
            //         expect(tagMap["serviceinstancename"]).toContain(serviceName.toLowerCase());
            //         expect(tagMap["serviceofferingname"]).toEqual(persistentTemplate.serviceOffrngName);
            //         orderFlowUtil.closeHorizontalSliderIfPresent();
            //     });
            // }
        }                       
        await orderedServicesPage.clickServiceDetailSliderCloseButton();
        await orderedServicesPage.clickExpandFirstRow();   
        var deleteOrderNo = await orderedServicesPage.deleteServiceAndSaveOrderId(persistentTemp.bluePrintName, orderObject.servicename);
        await ordersPage.approveOrder(deleteOrderNo);
        await ordersPage.waitUntilOrderStatusChange(deleteOrderNo, genericTestData.completedState);
        var deleteOrderStatus = await ordersPage.getOrderStatus(deleteOrderNo);
        expect(deleteOrderStatus).toEqual(genericTestData.completedState);
    })
    
})
