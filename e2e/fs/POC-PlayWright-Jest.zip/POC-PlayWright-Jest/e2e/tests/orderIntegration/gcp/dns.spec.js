const util = require("../../../../helpers/util.js");
const dnsTemplate = require('../../../../testData/orderIntegration/Google/gcpCLoudDNSInstance.json');
var modifiedParams = {},mainParamsMap = {}, orderObject = {}, zoneName, dnsName;
  
describe("GCP-Cloud DNS", () => {
    beforeEach(async () => {
        serviceName = "autodns" + util.getRandomString(5),
        zoneName = "gcp-test-cbs" + util.getRandomString(5);
        zoneName = zoneName.toLowerCase();
        dnsName = "auto.gcp." + util.getRandomString(3);
        dnsName = dnsName.toLowerCase();
        modifiedParams = { "Service Instance Prefix": serviceName, "Zone name": zoneName, "DNS name": dnsName };
        await catalogPage.open();
        await catalogPage.clickProvider(dnsTemplate.provider);
        await catalogPage.clickCategory(dnsTemplate.Category);
        await catalogPage.clickOnserviceName(dnsTemplate.bluePrintName);
        await catalogPage.clickConfigureBtn();
    });

    it('Cloud DNS - Validate Details on Main Parameter page', async () => {
        mainParamsMap = { "serviceName": serviceName, "Team": genericTestData.Team, "Env": genericTestData.Env, "App": genericTestData.App, "providerAccount": dnsTemplate.providerAccount };
        await mainParamPage.fillMainParameterPageDetails(mainParamsMap);
        //Validate Next button is enabled after entering details
        expect(await mainParamPage.isNextButtonEnabled()).toBe(true);
    });

    it('Cloud DNS : Verify Service Details are listed in Review Order page', async () => {
        var requiredReturnMap = await orderflow.fillOrderDetails(dnsTemplate, modifiedParams);
        //Validate all review order page parameters are as per input service configuration 
        expect(await placeOrderPage.validateReviewOrderPageParams(requiredReturnMap)).toEqual(true);
        //Validate Estimated Cost on Review Order Page for USD Tenants
        if(pwConfig.defaultCurrency == "USD") {
            expect(dnsTemplate.TotalCost).toContain(await placeOrderPage.getEstimatedPrice_ReviewOrder());
            //BOM Validation as per components of service.
            expect(await placeOrderPage.validateBOMOnReviewOrderPage(dnsTemplate.Pricing)).toBe(true);    
        }
    });
    
    it('Cloud DNS : Verify Order Details once order is submitted from catalog page', async () => {
        var serviceConfParams = await orderflow.fillOrderDetails(dnsTemplate, modifiedParams);        
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(dnsTemplate.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.open();
        await ordersPage.searchOrderById(orderNumber);
        expect(await ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(orderNumber);
        expect(await ordersPage.getTextFirstAmountOrdersTable()).toEqual(dnsTemplate.EstimatedPrice)
        await ordersPage.clickFirstViewDetailsOrdersTable();
        //Validate Additional Parameters Details
        expect(await ordersPage.validateorderDetails(serviceConfParams)).toBe(true);
        if(pwConfig.defaultCurrency == "USD") {
            //Verify estimated price
            await ordersPage.clickBillOfMaterialsTabOrderDetails();
            expect(await ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails()).toBe(dnsTemplate.TotalCost);
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(dnsTemplate.TotalCost).toContain(totalCostBOM);
        }
        await ordersPage.clickServiceDetailSliderCloseButton();
        await orderHistoryPage.open();
        await orderHistoryPage.searchOrderById(orderNumber);
        await orderHistoryPage.clickServiceDetails();
        //Validate Additional Parameters Details and BOM on Order History page
        expect(await orderHistoryPage.validateorderDetails(serviceConfParams)).toBe(true);
        if(pwConfig.defaultCurrency == "USD") {
            await orderHistoryPage.clickBOMServiceDetails();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(dnsTemplate.TotalCost)
            await orderHistoryPage.clickServiceDetailSliderCloseButton();
            await orderHistoryPage.clickBillOfMaterials();
            expect(await orderHistoryPage.getEstimatedCostServiceDetails()).toEqual(dnsTemplate.TotalCost)
            //Validate BOM table price
            var totalCostBOM = await ordersPage.getBOMTablePrice();
            expect(dnsTemplate.TotalCost).toContain(totalCostBOM);
        }
        await orderHistoryPage.clickServiceDetailSliderCloseButton();   
        
    });
    
    it('Cloud DNS - Provision/Edit Service', async () => {        
        orderObject.servicename = serviceName        
        orderObject.dnsname = dnsName;       
        await orderflow.fillOrderDetails(dnsTemplate, modifiedParams);       
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual(genericTestData.orderSubmittedConfirmationMessage);
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(dnsTemplate.bluePrintName, genericTestData.newOrder);
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
        await ordersPage.approveOrder(orderNumber);
        await ordersPage.waitUntilOrderStatusChange(orderNumber, genericTestData.completedState);
        var orderStatus = await ordersPage.getOrderStatus(orderNumber);
        expect(orderStatus).toEqual(genericTestData.completedState);
        
        if (orderStatus == genericTestData.completedState) {
            //Edit Service instance
            var modifiedParamMapEdit = { "EditService": true };
            await orderedServicesPage.editService(serviceName);
            var reviewOrderExpActParamsMap = await orderflow.fillOrderDetails(dnsTemplate, modifiedParamMapEdit)
            //Validate Edited Parmeters on review order page
            expect(await placeOrderPage.validateReviewOrderPageParams(reviewOrderExpActParamsMap)).toBe(true);
            if (pwConfig.defaultCurrency == "USD") {
                // Checking cost of BOM on Updated BOM tab (review Order Page)					
                expect(await placeOrderPage.getEstimatedPrice_ReviewOrder()).toBe(dnsTemplate.TotalCost);
            }
            await placeOrderPage.submitOrder();
            var editOrderNumber = await placeOrderPage.getAndSaveOrderId(dnsTemplate.bluePrintName, genericTestData.editOrder);
            await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
            await ordersPage.approveOrder(editOrderNumber);
            await ordersPage.waitUntilOrderStatusChange(editOrderNumber, genericTestData.completedState);
            //Validate edited details
            await ordersPage.open();
            await ordersPage.searchOrderById(editOrderNumber);
            expect(await ordersPage.getTextFirstOrderIdOrdersTable()).toEqual(editOrderNumber);
            expect(await ordersPage.getTextFirstAmountOrdersTable()).toEqual(dnsTemplate.EstimatedPrice)
            await ordersPage.clickFirstViewDetailsOrdersTable();
            //Validate Additional Parameters Details          
            expect(await ordersPage.validateorderDetails(reviewOrderExpActParamsMap)).toBe(true);
            if (pwConfig.defaultCurrency == "USD") {
                await ordersPage.clickBillOfMaterialsTabOrderDetails();
                // Checking cost of BOM on Updated BOM tab (Orders Page)
                var totalCostUpdated = await ordersPage.getTextTotalCostOnBillofMaterialsOrderDetails();
                expect(dnsTemplate.TotalCost).toContain(totalCostUpdated);
                //Checking cost of BOM on Current BOM tab(Orders Page)
                var totalCostBOM = await ordersPage.getCurrentBOMTablePrice();
                expect(dnsTemplate.TotalCost).toContain(totalCostBOM);
                //Verify details on orderHistory page 
                await orderHistoryPage.open();
                await orderHistoryPage.searchOrderById(editOrderNumber);
                await orderHistoryPage.clickServiceDetails();
                //Validate Additional Parameters Details and BOM on Order History page
                expect(await orderHistoryPage.validateorderDetails(reviewOrderExpActParamsMap)).toBe(true);
                await orderHistoryPage.clickBOMServiceDetails();
                // Checking cost of BOM on Updated BOM tab(order History Page)
                totalCostUpdated = await orderHistoryPage.getUpdatedBOMTablePrice();
                expect(dnsTemplate.TotalCost).toContain(totalCostUpdated);
                // Checking cost of BOM on Current BOM tab(order History Page)
                totalCostBOM = await ordersPage.getCurrentBOMTablePrice();
                expect(dnsTemplate.TotalCost).toContain(totalCostBOM);
                await orderHistoryPage.clickServiceDetailSliderCloseButton();
                //Validate Details on Ordered Services page
                await orderedServicesPage.open();
                await orderedServicesPage.searchOrderByServiceName(serviceName);
                totalCostUpdated = await orderedServicesPage.getBOMTablePrice();
                expect(dnsTemplate.TotalCost).toContain(totalCostUpdated);

                if (pwConfig.isDummyAdapterDisabled == 'true') {
                    //Validate System tags
                    await orderedServicesPage.open();
                    await orderedServicesPage.searchOrderByServiceName(serviceName);
                    await orderedServicesPage.clickExpandFirstRow()                        
                    await orderedServicesPage.clickOverflowActionButtonForPowerStates()
                    await orderedServicesPage.clickViewComponent()
                    await orderedServicesPage.clickLabelsViewDetailsLink();
                    //Verify system tags
                    expect(await orderedServicesPage.validateSystemTagValueIsDisplayed()).toBe(true);
                    expect(await orderedServicesPage.getSystemTagLabel()).toEqual(genericTestData.systemTagText);
                                              
                }
                await orderedServicesPage.clickServiceDetailSliderCloseButton();
                await orderedServicesPage.clickExpandFirstRow();   
            }
                       
        }
    });

    // if (pwConfig.isDummyAdapterDisabled == 'true') {
    //     it('Cloud DNS - Add Recordset', async () => {
    //         //Add Recordset flow            
    //         await orderedServicesPage.open();
    //         await orderedServicesPage.searchOrderByServiceName(serviceName);
    //         await orderedServicesPage.clickExpandFirstRow()
    //         await orderedServicesPage.clickOverflowActionButtonForPowerStates()
    //         await orderedServicesPage.clickD2opsBtn(dnsTemplate.addRecordSet)
    //         await orderedServicesPage.clickTurnOnOakybutton();
    //         var dnsDeatils = await orderedServicesPage.fillDnsRecordSetDetails();
                    
    //         await placeOrderPage.submitOrder();
    //         await orderedServicesPage.fetchD2opsOrderDetails();
    //         var addRecrdSetOrderNumber = await placeOrderPage.getAndSaveOrderId(dnsTemplate.bluePrintName, dnsTemplate.addRecordSet);
    //         var recrdSetotalPrice = await placeOrderPage.getTextTotalPriceOrderSubmittedModal();
    //         await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
    //         await ordersPage.waitForOrderStatusChange(addRecrdSetOrderNumber, genericTestData.completedState);
    //         await ordersPage.verifyOrderStatus(addRecrdSetOrderNumber).then(async function (status) {
    //             if (status == genericTestData.completedState) {
    //                 //Verify updated details are reflected on order details apge.
    //                 await ordersPage.clickFirstViewDetailsOrdersTable();
    //                 expect(await ordersPage.validateorderDetails(dnsDeatils)).toBe(true);
    //                 // expect(ordersPage.getTextBasedOnLabelName("DNS name")).toEqual(gcpCloudDNSTemplate.dnsname);
    //                 // expect(ordersPage.getTextBasedOnLabelName("TTL")).toEqual(messageStrings.TTL);
    //                 // expect(ordersPage.getTextBasedOnLabelName("IPv4 Address")).toEqual(messageStrings.IPv4Address);
    //                 // expect(ordersPage.getTextBasedOnLabelName("Resource Record Type")).toEqual(messageStrings.ResourceRecordType);
    //                 // expect(ordersPage.getTextBasedOnLabelName("TTL Unit")).toEqual(messageStrings.TTLUnit);
    //                 await ordersPage.clickServiceDetailSliderCloseButton();
    //             }
    //         });
    //     });

    //     it('Cloud DNS - Delete Recordset', async () => {
    //         var modifiedParamMapDns = { "CustomOperation": true, "Recordsets": gcpCloudDNSTemplate.dnsname + "." + orderObject.dnsname + "." };
    //         //Delete Recordset flow 
    //         orderObject.componentType = "dns.v1.managedZone";
    //         orderedServicesPage.open();
    //         orderedServicesPage.searchOrderByServiceName(orderObject.servicename);
    //         orderedServicesPage.clickExpandFirstRow()
    //         orderedServicesPage.clickOverflowACtionBtnBasedOnComponent(orderObject.componentType)
    //         orderedServicesPage.clickDeleteRecordSet()
            
    //         orderedServicesPage.clickOKDeleteServiceModal();
    //         orderFlowUtil.fillOrderDetails(gcpCloudDNSTemplate, modifiedParamMapDns);
                   
    //         placeOrderPage.submitOrder();
    //         inventoryPage.fetchD2opsOrderDetails();
    //         orderobjectRecordSet.orderNumber = placeOrderPage.getAndSaveOrderId(gcpCloudDNSTemplate.bluePrintName, "DeleteRecordSet");
    //         //orderobjectRecordSet.orderNumber = placeOrderPage.getTextOrderNumberOrderSubmittedModal();
    //         expect(placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe('Order Request Initiated!');
    //         placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();
    //         catalogPage.open();
    //         orderFlowUtil.waitForOrderStatusChange(orderobjectRecordSet, 'Completed');
    //         expect(orderFlowUtil.verifyOrderStatus(orderobjectRecordSet)).toBe('Completed');
    //     });
    // }
    
    it('Cloud DNS - Delete Service Instance', async () => {
        var deleteOrderNo = await orderedServicesPage.deleteServiceAndSaveOrderId(dnsTemplate.bluePrintName, orderObject.servicename);
        await ordersPage.approveOrder(deleteOrderNo);
        await ordersPage.waitUntilOrderStatusChange(deleteOrderNo, genericTestData.completedState);
        var deleteOrderStatus = await ordersPage.getOrderStatus(deleteOrderNo);
        expect(deleteOrderStatus).toEqual(genericTestData.completedState);
    })
    
})
