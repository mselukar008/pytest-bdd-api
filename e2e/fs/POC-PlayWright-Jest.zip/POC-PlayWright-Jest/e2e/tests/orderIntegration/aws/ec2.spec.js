var util = require("../../../../helpers/util.js");
var modifiedParametersMap = { "serviceName": "MyAutoTest", "Team": "Auto-TEAM1", "Env": "NONE", "App": "NONE", "providerAccount": "gcpQA-TEAM1 / gcpQA-TEAM1" };
var ec2Template = require('../../../../testData/orderIntegration/AWS/AWSEC2Instance.json');
var modifiedParams = {}, 
orderObject = {};
var serviceName, groupName;
serviceName = "auto-ec2-" + util.getRandomString(5);
groupName = "att-group-" + util.getRandomString(5);
modifiedParams = { "Service Instance Name": serviceName, "Group Name": groupName };

describe("AWS-EC2", () => {    

    it('EC2 - Validate Details on Review Parameter page, Provision and Delete Service', async () => {
        
        await catalogPage.open()
        await catalogPage.clickProvider(ec2Template.provider)
        await catalogPage.clickCategory(ec2Template.Category)
        await catalogPage.clickOnserviceName(ec2Template.bluePrintName)
        await catalogPage.clickConfigureBtn()        
        var requiredReturnMap = await orderflow.fillOrderDetails(ec2Template, modifiedParams);    
        //Validate all review order page parameters are as per input service configuration 
        expect(await placeOrderPage.validateReviewOrderPageParams(requiredReturnMap)).toEqual(true);   
        //Submit order
        await placeOrderPage.submitOrder();
        expect(await placeOrderPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toEqual("Order Submitted !");
        //Get order id        
        var orderNumber = await placeOrderPage.getAndSaveOrderId(ec2Template.bluePrintName, "New");
        await placeOrderPage.clickgoToServiceCatalogButtonOrderSubmittedModal();      
        await ordersPage.approveOrder(orderNumber);        
        await ordersPage.waitUntilOrderStatusChange(orderNumber, "Completed");
        var orderStatus = await ordersPage.getOrderStatus(orderNumber);
        expect(orderStatus).toEqual("Completed"); 
        //Delete Service
        if(orderStatus == "Completed") {            
            var deleteOrderNo = await orderedServicesPage.deleteServiceAndSaveOrderId(ec2Template.bluePrintName, serviceName);
            await ordersPage.approveOrder(deleteOrderNo);
            await ordersPage.waitUntilOrderStatusChange(deleteOrderNo, "Completed");
            var deleteOrderStatus = await ordersPage.getOrderStatus(deleteOrderNo);
            expect(deleteOrderStatus).toEqual("Completed");
        }   
    });

    it("EC2- Verify instance Turn OFF functionality", async () => {
        //serviceName = "auto-ec2-JQRqX";
        await orderedServicesPage.open();
        await orderedServicesPage.searchOrderByServiceName(serviceName);
        await orderedServicesPage.clickExpandFirstRow();
        await orderedServicesPage.clickOverflowActionButtonForPowerStates();
        await orderedServicesPage.clickD2opsBtn(ec2Template.bluePrintNameTurnOff);
        await orderedServicesPage.fetchD2opsOrderDetails();
        expect(await orderedServicesPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(genericTestData.orderSubmittedConfirmationMessage);          
        orderObject.orderNumber = await orderedServicesPage.getAndSaveOrderId(ec2Template.bluePrintName, ec2Template.bluePrintNameTurnOff);
        await orderedServicesPage.clickOkbtnOrderSubmission();
        await ordersPage.waitUntilOrderStatusChange(orderObject.orderNumber, genericTestData.completedState);
        expect(await ordersPage.getOrderStatus(orderObject.orderNumber)).toBe(genericTestData.completedState);
        expect(await ordersPage.getTextFirstOrderTypeOrdersTable()).toBe(genericTestData.orderTypeAction);
        expect(await ordersPage.getServiceNameOfferingText()).toBe(genericTestData.actnTurnOff);

    });
    
    it("EC2- Verify instance Turn ON functionality", async () => {
        //serviceName = "auto-ec2-JQRqX";
        await orderedServicesPage.open();
        await orderedServicesPage.searchOrderByServiceName(serviceName);
        await orderedServicesPage.clickExpandFirstRow();
        await orderedServicesPage.clickOverflowActionButtonForPowerStates();
        await orderedServicesPage.clickD2opsBtn(ec2Template.bluePrintNameTurnOn);
        await orderedServicesPage.fetchD2opsOrderDetails();
        expect(await orderedServicesPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(genericTestData.orderSubmittedConfirmationMessage);          
        orderObject.orderNumber = await orderedServicesPage.getAndSaveOrderId(ec2Template.bluePrintName, ec2Template.bluePrintNameTurnOn);
        await orderedServicesPage.clickOkbtnOrderSubmission();
        await ordersPage.waitUntilOrderStatusChange(orderObject.orderNumber, genericTestData.completedState);
        expect(await ordersPage.getOrderStatus(orderObject.orderNumber)).toBe(genericTestData.completedState);
        expect(await ordersPage.getTextFirstOrderTypeOrdersTable()).toBe(genericTestData.orderTypeAction);
        expect(await ordersPage.getServiceNameOfferingText()).toBe(genericTestData.actbTurnOn);

    });

    it("EC2- Verify instance Reboot functionality", async () => {
        //serviceName = "auto-ec2-JQRqX";
        await orderedServicesPage.open();
        await orderedServicesPage.searchOrderByServiceName(serviceName);
        await orderedServicesPage.clickExpandFirstRow();
        await orderedServicesPage.clickOverflowActionButtonForPowerStates();
        await orderedServicesPage.clickD2opsBtn(ec2Template.bluePrintNameReboot);
        await orderedServicesPage.fetchD2opsOrderDetails();
        expect(await orderedServicesPage.getTextOrderSubmittedHeaderOrderSubmittedModal()).toBe(genericTestData.orderSubmittedConfirmationMessage);          
        orderObject.orderNumber = await orderedServicesPage.getAndSaveOrderId(ec2Template.bluePrintName, ec2Template.bluePrintNameReboot);
        await orderedServicesPage.clickOkbtnOrderSubmission();
        await ordersPage.waitUntilOrderStatusChange(orderObject.orderNumber, genericTestData.completedState);
        expect(await ordersPage.getOrderStatus(orderObject.orderNumber)).toBe(genericTestData.completedState);
        expect(await ordersPage.getTextFirstOrderTypeOrdersTable()).toBe(genericTestData.orderTypeAction);
        expect(await ordersPage.getServiceNameOfferingText()).toBe(ec2Template.bluePrintNameReboot);
    })
    
})
