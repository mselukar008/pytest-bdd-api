import pytest

from locators.landingzone.landing_zone_catalog_locator import *
from conftest import get_env_url
from pages.landingzone.landing_zone_dashboard import *
from pages.landingzone.landing_zone_catalog_page import *
from pages.store.approve_order_page import *
from pages.store.ordered_services_page import *
from helpers.mo_json_utils import modify_parameter
from pages.store.order_history_page import *
from pages.store.review_order_page import *
from tests.common_test import *
from helpers.mo_check import mo_check as check
from pages.common.launchpad_page import verify_landing_zone_requisites
from pages.store.provider_account_page import *

test_data_path = os.path.join(landingzone_data_path, "user_development_user.json")
set_data_path(test_data_path)
service_name = ""
order_no = ""
date_time = ""


def test_user_development_user_request_flow():
    """Verify the user_development order flow in AccountDetails Page, Policy Page, Budget and Review Order Page"""
    verify_landing_zone_requisites()
    modify_param = {
        'Policy Name': get_random_int('testpolicy')
    }
    modify_parameter(modify_param)
    open_catalog_page()
    select_service_template(test_data_path)
    fill_user_request_details()
    verify_landing_zone_review_order_page(for_user=True)
    click_submit_request()
    set_data_path(test_data_path)
    global date_time
    date_time = get_current_date()
    validate_service_card_details(date_time, for_user=True)
    # # Validate details in landing zone Dashboard
    validate_request_details_in_export_icon(for_user=True)


def test_create_user_development_request():
    # Approve the latest order and verify the approval status
    approve_account_request_in_landing_zone_dashboard()
    validate_service_card_details(date_time, pending_approval=False, for_user=True)
    validate_request_details_in_export_icon(pending_approval=False, for_user=True)


def test_denial_user_development_user_request_flow():
    """Verify the user_development order flow in AccountDetails Page, Policy Page, Budget and Review Order Page"""
    modify_param = {
        'Policy Name': get_random_int('testpolicy')
    }
    modify_parameter(modify_param)
    open_catalog_page()
    select_service_template(test_data_path)
    fill_user_request_details()
    verify_landing_zone_review_order_page(for_user=True)
    click_submit_request()
    set_data_path(test_data_path)
    global date_time
    date_time = get_current_date()
    # Validate details in landing zone Dashboard
    validate_service_card_details(date_time, for_user=True)
    validate_request_details_in_export_icon(for_user=True)


def test_deny_user_development_request():
    # Approve the latest order and verify the approval status
    deny_account_request_in_landing_zone_dashboard()
    validate_service_card_details(date_time, pending_approval=False, for_user=True)
    validate_request_details_in_export_icon(pending_approval=False, for_user=True)