import pytest

from locators.landingzone.landing_zone_catalog_locator import *
from conftest import get_env_url
from pages.landingzone.landing_zone_dashboard import *
from pages.landingzone.landing_zone_catalog_page import *
from pages.store.approve_order_page import *
from pages.store.ordered_services_page import *
from helpers.mo_json_utils import modify_parameter
from pages.store.order_history_page import *
from pages.store.review_order_page import *
from tests.common_test import *
from helpers.mo_check import mo_check as check
from pages.common.launchpad_page import verify_landing_zone_requisites
from pages.store.provider_account_page import *

test_data_path = os.path.join(landingzone_data_path, "account_development_account.json")
set_data_path(test_data_path)
service_name = ""
order_no = ""
date_time = ""


@pytest.mark.dependency()
def test_recurring_account_development_order_flow():
    """Verify the account_development order flow in AccountDetails Page, Policy Page, Budget and Review Order Page"""
    verify_landing_zone_requisites()
    modify_param = {
        'Policy Name': get_random_int('testpolicy'),
        'Budget Name': get_random_int('hyperscaler-development')
    }
    modify_parameter(modify_param)
    open_catalog_page()
    select_service_template(test_data_path)
    fill_account_order_details()
    verify_landing_zone_review_order_page()
    click_submit_request()
    global date_time
    date_time = get_current_date()
    validate_service_card_details(date_time)
    # Validate details in landing zone Dashboard
    validate_request_details_in_export_icon()


@pytest.mark.dependency(depends=["test_recurring_account_development_order_flow"])
def test_create_recurring_account_development_request():
    # Approve the latest order and verify the approval status
    approve_account_request_in_landing_zone_dashboard()
    validate_service_card_details(date_time)
    validate_request_details_in_export_icon()


@pytest.mark.dependency()
def test_expiring_account_development_order_flow():
    """Verify the account_development order flow in AccountDetails Page, Policy Page, Budget and Review Order Page"""
    modify_param = {
        'Policy Name': get_random_int('testpolicy'),
        'Budget Name': get_random_int('hyperscaler-development'),
        'Threshold Type': 'Absolute value'
    }
    modify_parameter(modify_param)
    open_catalog_page()
    select_service_template(test_data_path)
    fill_account_order_details(expiring=True)
    verify_landing_zone_review_order_page(expiring=True)
    click_submit_request()
    global date_time
    date_time = get_current_date()
    validate_service_card_details(date_time, expiring=True)
    # Validate details in landing zone Dashboard
    validate_request_details_in_export_icon(expiring=True)


@pytest.mark.dependency(depends=["test_expiring_account_development_order_flow"])
def test_create_expiring_account_development_request():
    # Validate details in landing zone Dashboard
    approve_account_request_in_landing_zone_dashboard()
    validate_service_card_details(date_time, pending_approval=False, expiring=True)
    validate_request_details_in_export_icon(pending_approval=False, expiring=True)


@pytest.mark.dependency()
def test_denial_account_development_order_flow():
    """Verify the account_development order flow in AccountDetails Page, Policy Page, Budget and Review Order Page"""
    verify_landing_zone_requisites()
    modify_param = {
        'Policy Name': get_random_int('testpolicy'),
        'Budget Name': get_random_int('hyperscaler-development')
    }
    modify_parameter(modify_param)
    open_catalog_page()
    select_service_template(test_data_path)
    fill_account_order_details()
    verify_landing_zone_review_order_page()
    click_submit_request()
    global date_time
    date_time = get_current_date()
    validate_service_card_details(date_time)
    # Validate details in landing zone Dashboard
    validate_request_details_in_export_icon()


@pytest.mark.dependency(depends=["test_denial_account_development_order_flow"])
def test_deny_recurring_account_development_request():
    # Validate details in landing zone Dashboard
    deny_account_request_in_landing_zone_dashboard()