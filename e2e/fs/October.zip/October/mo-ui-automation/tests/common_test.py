import json
import time
from logging import log
import os
import shutil
import pytest
import string
import random
from helpers.mo_api_client import get_call, post_call
from helpers.mo_element_operations import click, get_element_text, explicit_wait
from helpers.mo_page_operations import wait_for_spinner_off, switch_to_default_content_iframe
from helpers.mo_resources import output_folder
from helpers.mo_selenium_helper import *
from datetime import datetime
from dateutil.relativedelta import *

from locators.common.login_page_locator import ibm_icon, developer_console_link, bearer_token_tab, display_btn, \
    bearer_token_text
from mo_encryption_decryption import decrypt_password
from ui_config import users_data
from helpers.mo_env import api_tenant, tenant_test_adapter, providers_adapters
from pages.common.login_page import load_base_page, log_into_server, logout
from helpers.mo_env import tenant, mo_secret_ibm, mo_secret_kyn
from helpers.mo_driver_manager import delete_cookies, load_url

data = None
status = None


def get_random_int(value, concat_before=False):
    # Generates a random int according the timestamp everytime is called
    timestamp = datetime.now().strftime("%H%M%S%f")
    # Allows to concat the timestamp before the values, by default concats at the end
    if concat_before:
        return f"{timestamp}{value}"
    return f"{value}{timestamp}"


def get_random_string(length):
    res = ''.join(random.choices(string.ascii_uppercase + string.ascii_lowercase
                                 + string.digits, k=length))
    return res


# Returns Month and Year in "MMM YYYY" format using index
# index usage: 0 - current month, 1 - previous month
def get_month_year_using_index(index, budget=False):
    month_year = datetime.now() - relativedelta(months=index)
    formatted_month_year = format(month_year, '%h %Y')
    if budget:
        if "Jun" in formatted_month_year:
            full_month = "June"
            formatted_month_year = format(month_year, full_month + ' %Y')
        if "Jul" in formatted_month_year:
            full_month = "July"
            formatted_month_year = format(month_year, full_month + ' %Y')
    logger.info("Month Year:" + formatted_month_year)
    return formatted_month_year


# Get Month's full name using index
# 0 - current month
def get_full_name_month_using_index(index):
    month_name = datetime.now() - relativedelta(months=index)
    formatted_month = format(month_name, '%B')
    logger.info("Full name Month: " + formatted_month)
    return formatted_month


# Get Full year string using index
# 0 - current year
def get_full_year_using_index(index):
    year = datetime.now() - relativedelta(years=index)
    formatted_year = format(year, '%Y')
    logger.info("Full Year: " + formatted_year)
    return formatted_year


# Delete all files/subdirectories in downloaded_files directory
def delete_all_downloaded_files():
    if os.path.exists(output_folder):
        for file in os.listdir(output_folder):
            path = os.path.join(output_folder, file)
            try:
                shutil.rmtree(path)
            except OSError:
                os.remove(path)
    else:
        logger.info("Directory is not present")


# Check if file/s is exists in downloaded_files directory or not
def is_downloaded_file_exists():
    logger.info(os.listdir(output_folder))
    if any(File.endswith(".zip") and (File.startswith("Costs_AD") or File.startswith("Assets_AD")) for File in os.listdir(output_folder)):
        logger.info("File is downloaded")
        return True
    else:
        logger.info("File not found")
        return False


def set_data(value):
    global data
    data = value


def set_rt_status(value):
    global status
    status = value


@pytest.fixture(scope='module')
def check_rt_status():
    logger.info(status)
    if status != "Completed":
        raise pytest.skip("order is not provisioned")


# skip the test cases if status is not completed
@pytest.fixture
def check_status():
    global data
    if data != "Completed":
        raise pytest.skip("order is not provisioned")

    host = tenant
    test_file = os.getenv('PYTEST_CURRENT_TEST').split("::")[0].split("/")[-1].split(".py")[0]
    if os.environ.get("Environment"):
        host = os.environ.get("Environment")
    if "snowui" in host:
        if "homo" or "hetero" or "mq" not in test_file:
            data = None


# skip the test cases if order is not created
@pytest.fixture
def check_order_creation():
    global data
    if data is None:
        raise pytest.skip("order is not created")


# Enable or disable the dummy adapter according 'mo.tenant.adapter' flag in config.ini
@pytest.fixture(scope='session', autouse=True)
def enable_disable_dummy_adapter():
    main_user = users_data['main_user']
    tenant_url = f"https://{api_tenant}/adapter/switchdummy"
    services = [value.strip() for value in providers_adapters.split(',')]
    if len(services) == 1 and services[0] == '':
        return
    for service in services:
        url = tenant_url
        if tenant_test_adapter == 'dummy':
            logger.info(f'Enabling Dummy Adapter for {service}')
            url = f"{url}/{service}/enable"
        elif tenant_test_adapter == 'real':
            logger.info(f'Disabling Dummy Adapter for {service}')
            url = f"{url}/{service}/disable"
        try:
            response = post_call(host_url=url, username=main_user.get('user_id'),
                                 apikey=decrypt_password(main_user['apikey']), json_payload=json.dumps(dict()),
                                 raise_exception=False)
            logger.info(f'Dummy Adapter Response:\n {response}')
        except:
            logger.error(f'Error when trying to enable or disable dummy adapter for {service}')


# Allows to logout and login with an user
def logout_and_login(user_data, tenant_url=None):
    logout()
    explicit_wait(2)
    delete_cookies()
    app_url = tenant
    username = user_data.get('user')
    password = user_data.get('password')
    #secret_non_kyn = user_data.get('secret') #commenting this as we are using only kyndryl user for login.
    mo_secret_key = user_data.get('secret')
          
    if os.environ.get("Environment"):
        app_url = os.environ.get("Environment")
        secret_non_kyn = os.environ.get("SecretIBM")
    else:
        secret_non_kyn = users_data['main_user']['secret'] 

    # if os.environ.get("SecretKYN"):
    #     mo_secret_key = os.environ.get("SecretKYN")
    # else:
    #     mo_secret_key = mo_secret_kyn
    if tenant_url is None:
        log_into_server(app_url, username, password, mo_secret_key, secret_non_kyn)
    else:
        log_into_server(tenant_url, username, password, mo_secret_key, secret_non_kyn)


def get_bearer_token():
    switch_to_default_content_iframe()
    click(ibm_icon, "User Icon")
    click(developer_console_link, "Developer Console")
    wait_for_spinner_off()
    click(bearer_token_tab, "Bearer Token")
    click(display_btn, "Display")
    explicit_wait(5)
    token = get_element_text(bearer_token_text)
    return token
