from pages.common.mo_navigation_page import navigate_to_mo_launchpad_page
from pages.common.system_settings_page import enable_notifications
from pages.ecam.costs_page import *
from pages.store.navigation_page import open_costs_page
from tests.common_test import logout_and_login
from ui_config import hills_ecam_test_data_path, users_data

costs_data_path = os.path.join(hills_ecam_test_data_path, "costs_assets_page.json")


def test_jane_costs_dashboard(check_rt_status):
    """Jane tracks the costs of the infrastructure supporting the Petstore Application"""
    set_data_path(costs_data_path)
    open_costs_page()
    select_drg_from_data_set_filters(get_data("petstoreDRG"))
    validate_current_month_cost_chart(budget=False)
    current_month_year = get_month_year_using_index(0)
    cost_dropdown_values = [get_data("costPerBilling"), get_data("costPerAsset"), get_data("costPerSerProvider"),
                            get_data("costPerCategory"), get_data("costPerAssetType"), get_data("costPerBU")]
    add_and_delete_segment_chart()
    configure_segment_charts(get_data("petcostTag"))
    validate_cost_page_minichart_values(cost_dropdown_values, current_month_year)

    # Jane is asked to look at their historical spend to compare spending and make an informative decision.
    navigate_to_mo_launchpad_page()
    open_costs_page()
    apply_filter(get_data("providerFilter"), get_data("azureProvider"))

    # Jane saves dashboard view
    save_dashboard_view()

    validate_current_month_cost_chart()
    validate_cost_page_minichart_values(cost_dropdown_values, current_month_year)


def test_craig_costs_dashboard(check_rt_status):
    """Craig needs to analize the cost and budget, but in the context of the Petstore Application."""
    set_data_path(costs_data_path)
    open_costs_page()
    apply_filter(get_data("providerFilter"), get_data("azureProvider"))
    select_drg_from_data_set_filters(get_data("petstoreDRG"))
    validate_current_month_cost_chart(budget=False)

    # Activate notifications
    enable_notifications()
