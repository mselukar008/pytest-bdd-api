from pages.aiops.dashboard_page import *
from pages.aiops.health_page import *
from ui_config import users_data
from tests.common_test import *


def test_aiops_health_dashboard(check_rt_status):
    """Sonya ensures the infrastructure supporting company Red Thread is sound"""
    redthread_user = users_data['kyn_user']['Manasa']
    logout_and_login(redthread_user)
    open_aiops_dashboard_sunrise_report_page()
    validate_resource_health()
    open_health_page()
    select_provider_filter(mo_aiops_ui_test_data["azure_provider"])
    validate_petstore_app_health_table()
    validate_petstore_resources()

    # This is the same flow as above one, supposed to be executed with different user. Currently disabled since there
    # is no support for non-kyndryl IDs.
    '''# Craig Can Also Review the Health of the Infrastructure Supporting the Petstore Application
    open_aiops_dashboard_sunrise_report_page()
    validate_resource_health()
    open_health_page()
    select_provider_filter(mo_aiops_ui_test_data["azure_provider"])
    validate_petstore_app_health_table()
    validate_petstore_resources()'''
