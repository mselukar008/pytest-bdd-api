from pages.aiops.dashboard_page import open_aiops_dashboard_sunrise_report_page
from pages.aiops.health_page import open_health_page, validate_petstore_resources_status
from pages.ccm.ccm_dashboard_page import *
from ui_config import users_data
from tests.common_test import *


def test_ccm_dashboard(check_rt_status):
    """Alvin monitors the cluster in its application environment, ensuring stability and reliability (CCM)"""
    open_ccm_dashboard_page()
    validate_alerts()
    validate_clusters_health_by_provider()
    validate_clusters_health_by_region()
    validate_clusters_table()
    validate_cluster_column_in_cluster_page()

    # Checking the health of the cluster in AIOps
    open_aiops_dashboard_sunrise_report_page()
    open_health_page()
    validate_petstore_resources_status()
