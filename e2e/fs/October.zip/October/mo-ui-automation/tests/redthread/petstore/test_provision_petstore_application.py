from pages.common.login_page import load_base_page
from pages.common.mo_navigation_page import navigate_to_mo_launchpad_page
from pages.devops.common_page import apply_application_filter
from pages.devops.deploy_page import *
from pages.devops.devops_navigation import open_di_deploy_page
from pages.redthread.petstore_jenkins_page import *
from pages.store.approve_order_page import *
from pages.store.navigation_page import open_catalog_page, open_approve_orders_page
from pages.store.order_history_page import wait_for_order_status_order_history, get_service_status
from pages.store.review_order_page import *
from tests.common_test import *
from ui_config import redthread_data_path, devops_data_path, users_data

test_data_path = os.path.join(redthread_data_path, "petstore_application.json")
devops_data_path = os.path.join(devops_data_path, "devops_data.json")
service_name = None
order_no = None
console_logs = None


def test_provision_petstore_app():
    """Craig Orders Petstore from the Enterprise Marketplace Catalog"""
    global service_name
    service_name = get_random_int('uiauto')
    modify_param = {'Service Instance Prefix': service_name, "Resource group name": get_random_int('uiautorg'),
                    "Server name": get_random_int('uiautoserver')}
    modify_parameter(modify_param)
    # Place the order
    open_catalog_page()
    select_service_template(test_data_path)
    verify_catalog_details_page()
    click_on_configure_btn()
    fill_order_details()
    # Validate the parameters on review order page
    verify_review_order()
    exp_estimated_cost = get_data("TotalCost")
    check.is_in(get_estimated_price_review_order(), exp_estimated_cost, 'Pricing')
    validate_bom_review_order_page()
    click_submit_order()
    # Provision the order
    global order_no
    order_no = get_order_id()
    set_data(order_no)

    # Approve order and check the status on Order history page
    open_approve_orders_page()
    search_order_in_approve(order_no)
    wait_for_spinner_on()
    wait_for_spinner_off()
    click_approve_btn()
    approve_order_technical_financial(approver_type=ADMIN_APPROVER)
    check.equal(get_order_success_msg_text(), mo_ui_test_data["approveOrderSuccessMsgText"])
    click_modal_approval_ok()
    wait_for_order_status_order_history(order_no, mo_ui_test_data["provInProgressState"])

    # Login to jenkins and validate the auto triggered job
    login_to_jenkins()
    open_petstore_job()
    open_new_build_console_output_and_get_id()
    global console_logs
    console_logs = get_console_output_logs()
    validate_console_output_logs(console_logs)

    # Check the order status in EMP
    load_base_page(tenant)
    wait_for_order_status_order_history(order_no, mo_ui_test_data["completedState"])
    state = get_service_status(service_name)
    set_rt_status(state)


def test_devops_deploy_dashboard(check_rt_status):
    """Viewing the overall Deploy activity for the Petstore application"""
    set_data_path(devops_data_path)
    open_di_deploy_page()
    apply_application_filter(get_data("applicationName"))
    validate_deployment_frequency()
    validate_deployment_frequency_trend()
    validate_apps_by_failure_rate()
    validate_deployment_by_environment()
    validate_deployment_status(console_logs)
    validate_deployment_duration_trend()
    validate_deployments_table(console_logs)
    validate_latest_deployment_details(console_logs)
    navigate_to_mo_launchpad_page()
