import pytest
from pages.devops.build_page import *
from pages.devops.common_page import *
from pages.devops.develop_page import *
from pages.devops.devops_navigation import open_di_build_page, open_di_develop_page, open_di_test_page
from pages.devops.test_page import *
from ui_config import devops_data_path
from tests.common_test import *

devops_data_path = os.path.join(devops_data_path, "devops_data.json")


@pytest.mark.dependency()
def test_devops_intelligence_header_data(check_rt_status):
    """Validate devops header data"""
    set_data_path(devops_data_path)
    open_di_build_page()
    apply_application_filter(get_data("applicationName"))
    validate_header_titles()
    validate_header_data_and_subtitles()


@pytest.mark.dependency(depends=["test_devops_intelligence_header_data"])
def test_devops_develop_dashboard():
    """Viewing the overall Develop activity for the Petstore application"""
    open_di_develop_page()
    select_defects_issues_dropdown(get_data("defects_text"))
    validate_development_activity()
    defects_count = validate_applications()

    select_defects_issues_dropdown(get_data("issues_text"))
    validate_development_activity()
    issues_count = validate_applications()

    validate_technical_services_table(defects_count, issues_count)
    validate_development_activity_panel_overview()
    validate_development_activity_panel_defects()
    validate_development_activity_panel_issues()


@pytest.mark.dependency(depends=["test_devops_intelligence_header_data"])
def test_devops_build_dashboard():
    """Viewing the overall Build activity for the Petstore application"""
    open_di_build_page()
    validate_build_status()
    validate_build_success()
    validate_longest_builds()
    validate_technical_service_builds_table()
    validate_build_detail_panel_details_tab()
    validate_build_detail_panel_analysis_history_tab()


@pytest.mark.dependency(depends=["test_devops_intelligence_header_data"])
def test_devops_test_dashboard():
    """Viewing the overall Test activity for the Petstore application"""
    open_di_test_page()
    validate_test_summary_by_application()
    validate_services_with_less_coverage()
    validate_overall_test_status()
    validate_test_type_status()
    validate_technical_service_tests_table()
    validate_technical_service_panel_activity_tab()
    validate_technical_service_panel_historical_details_tab()
