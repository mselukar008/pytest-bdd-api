import pytest
from pages.store.operation_policies_page import *
from pages.store.ordered_services_page import *
from tests.common_test import get_random_int
from ui_config import *
from helpers.mo_check import mo_check as check

operation_policy_data_path = os.path.join(test_data_path, "policy", "operation_policy.json")
operation_group_name = None
operation_policy_name = None


@pytest.mark.dependency()
def test_operation_group_creation():
    """operation policy group name creation"""
    global operation_group_name
    click_to_operation_policies()
    navigate_to_operation_group_section()
    operation_group_name = get_random_int("AutoOperationGrpName")
    modify_param = {'operation group name': operation_group_name}
    modify_parameter(modify_param)
    click(new_operation_group_btn, "New operation group")
    fill_operation_policy_and_group_parameter_details(operation_policy_data_path, "operation group parameters")
    check.equal(get_element_text(notification_text), get_data("operationGrpCreateSuccessMsg"),
                'operation group created status msg')
    click(notification_close_icon, "notification close icon")
    search_operation_policy(operation_group_name)
    check.equal(get_number_of_elements(operation_policy_table_row, "Operator policies"), 1, "table row count")
    check.equal(get_element_text(operation_policy_table_name), operation_group_name, 'operation group name')


@pytest.mark.dependency(depends=["test_operation_group_creation"])
def test_operation_policy_creation_with_draft_status():
    """operation policy name creation with draft status"""
    global operation_policy_name
    click_to_operation_policies()
    navigate_to_operation_policy_section()
    operation_policy_name = get_random_int("AutoOperationPolicyName")
    modify_param = {"operation group dropdown": [operation_group_name], "operation policy name": operation_policy_name}
    modify_parameter(modify_param)
    click(new_operation_policy_btn, "New operation group")
    fill_operation_policy_and_group_parameter_details(operation_policy_data_path, "operation policy parameters")
    check.equal(get_element_text(notification_text), get_data("operationPolicyCreateSuccessMsg"),
                'operation policy created status msg')
    click(notification_close_icon, "notification close icon")
    search_operation_policy(operation_policy_name)
    check.equal(get_number_of_elements(operation_policy_table_row, "Operator policies"), 1, "table row count")
    check.equal(get_element_text(operation_policy_table_name), operation_policy_name, 'operation group name')
    check.equal(get_element_text(operation_policy_status_text), get_data("draftOperationPolicyStatus"),
                'operation policy status')


@pytest.mark.dependency(depends=["test_operation_policy_creation_with_draft_status"])
def test_operation_policy_with_active_status():
    """operation policy name creation with active status"""
    click_to_operation_policies()
    navigate_to_operation_policy_section()
    modify_param = {"operation policy name": operation_policy_name}
    modify_parameter(modify_param)
    notification_message = activate_operation_policy(operation_policy_data_path, operation_policy_name)
    check.equal(notification_message, get_data("operationPolicyUpdatedSuccessMsg"),
                'operation policy updated status msg')
    search_operation_policy(operation_policy_name)
    check.equal(get_number_of_elements(operation_policy_table_row, "Operator policies"), 1, "table row count")
    check.equal(get_element_text(operation_policy_table_name), operation_policy_name, 'operation group name')
    check.equal(get_element_text(operation_policy_status_text), get_data("activeOperationPolicyStatus"),
                'operation policy status')


@pytest.mark.dependency(depends=["test_operation_policy_with_active_status"])
def test_operation_policy_with_retired_status():
    """Test Retired policy workflow"""
    click_to_operation_policies()
    navigate_to_operation_policy_section()
    modify_param = {"operation policy name": operation_policy_name}
    modify_parameter(modify_param)
    notification_message = retire_operation_policy(operation_policy_data_path, operation_policy_name)
    check.equal(notification_message, get_data("operationPolicyUpdatedSuccessMsg"),
                'operation policy updated status msg')
    search_operation_policy(operation_policy_name)
    check.equal(get_number_of_elements(operation_policy_table_row, "Operator policies"), 1, "table row count")
    check.equal(get_element_text(operation_policy_table_name), operation_policy_name, 'operation group name')
    check.equal(get_element_text(operation_policy_status_text), get_data("retiredOperationPolicyStatus"),
                'operation policy status')


@pytest.mark.dependency(depends=["test_operation_policy_with_retired_status"])
def test_operation_policy_deletion_flow():
    """Test Delete operation policy workflow"""
    click_to_operation_policies()
    navigate_to_operation_policy_section()
    modify_param = {"operation policy name": operation_policy_name}
    modify_parameter(modify_param)
    notification_message = delete_operation_policy(operation_policy_data_path, operation_policy_name)
    check.equal(notification_message, " ".join([operation_policy_name, get_data("operationPolicyDeletedSuccessMsg")]),
                'operation policy deleted msg')
    search_operation_policy(operation_policy_name)
    check.equal(get_element_text(no_data_text), get_data("operationPolicyNoData"), 'No Data Available message')


@pytest.mark.dependency(depends=["test_operation_policy_deletion_flow"])
def test_operation_group_deletion_flow():
    """Test Delete operation group workflow"""
    click_to_operation_policies()
    navigate_to_operation_group_section()
    search_operation_policy(operation_group_name)
    search_and_click_on_action_icon(operation_group_name)
    click(delete_policy_btn, "delete operation group")
    click(delete_policy_grp_continue_btn, "continue button")
    search_operation_policy(operation_group_name)
    check.equal(get_element_text(no_data_text), get_data("operationPolicyNoData"), 'No Data Available message')
