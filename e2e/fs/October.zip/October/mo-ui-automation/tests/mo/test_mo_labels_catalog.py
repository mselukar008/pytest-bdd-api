from pages.store.order_history_page import *
from pages.store.review_order_page import *
from tests.common_test import *

test_data_path_label = os.path.join(mo_test_data_path, "labels", "mo_label_vaidation.json")


@pytest.mark.dependency()
def test_labels_section_and_count():
    """ Verify labels section is available in Catalog page and count of labels dropdown options before and after
    clicking Load More"""
    open_catalog_page()
    verify_text_labels_header(test_data_path_label)
    verify_labels_dropdown_count(test_data_path_label)


@pytest.mark.dependency(depends=["test_labels_section_and_count"])
def test_labelled_templates_vra84label():
    """ Verify on selecting a single label vra8.4Label displays the labelled templates only for vra8.4Label"""
    verify_service_on_the_label(get_data("vra8.4Label"), get_data("label8.4"), get_data("vra8.4LabelCount"))
    click_on_the_close_button()


@pytest.mark.dependency(depends=["test_labels_section_and_count"])
def test_labelled_templates_vra85label_catalog_page():
    """ Verify on selecting a single labels vra8.5Label display the labelled templates only for vra8.5Label and
    verify the catalog page detail for the same label"""
    verify_service_on_the_label(get_data("vra8.5Label"), get_data("label8.5"), get_data("vra8.5LabelCount"))
    verify_catalog_page_detail()
    open_catalog_page()
    click_on_the_close_button()


@pytest.mark.dependency(depends=["test_labels_section_and_count"])
def test_labelled_templates_vraHybridlabel():
    """ Verify on selecting 2 labels for 2 different service """
    verify_service_on_the_label(get_data("vraXaasLabel"), get_data("labelXaaS"), get_data("labelXaaSCount"))
    click_on_the_close_button()


@pytest.mark.dependency(depends=["test_labels_section_and_count"])
def test_labelled_templates_vraxaas84label():
    """ Verify a single label for the 2 different services """
    verify_service_on_the_label(get_data("labelXaaS"), get_data("lableXaaSvRA8.4"), get_data("vraXaas8.4LabelCount"))
    click_on_the_close_button()
