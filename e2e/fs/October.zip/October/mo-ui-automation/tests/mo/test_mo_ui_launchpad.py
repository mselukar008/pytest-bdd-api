from pages.common.launchpad_page import *


def test_launchpad():
    """Verifying the number of tile on mo dashboard"""
    #Verifying the first 6 tiles on logging into mo dashboard
    verify_first_6_tiles()
    #Verifying if show all tasks can load the additional tiles
    click_on_show_all_tasks_link()
    #Verifying the list of all 11 tiles after expanidng the show all task
    verify_next_11_tiles()
    #Verifying the show less task is cllickable and would remove the additional tiles
    click_on_show_less_tasks_link()
    #Verifyinng the orginal 6 titles
    verify_first_6_tiles()

def test_mo_tile_link():
    """Verifying the titles of each title on mo dashboard"""
    #Verify the loading of manage iam tile
    click_on_mo_manage_iam_tile_link()
    #Verify the loading of manage user access tile
    click_on_mo_manage_user_access_tile_link()
    #Verify the loading of manange provider account tile
    click_on_mo_manage_provider_account_tile_link()
    #Verify the loading of manange provider tile
    click_on_mo_manage_provider_tile_link()
    #Verify the loading of maange currency conversion tile
    click_on_mo_manage_currency_conversion_tile_link()
    #Verify the loading of view audit log tile
    click_on_mo_manage_view_audit_log_tile_link()
    #Verify the loading of
    click_on_mo_manage_archive_audit_logs_tile_link()
    #Verify the loading of mannage budget tile
    click_on_mo_manage_budget_tile_link()
    #Verify the loading of view budget tile
    click_on_mo_view_budget_text_tile_link()
    #Verify the loading of order service tile
    click_on_mo_order_new_services_text_tile_link()
    #Verify the loading of review currennt cart tile
    click_on_mo_review_current_cart_text_tile_link()
    #Verify the loading of track order status tile
    click_on_mo_track_order_status_text_tile_link()
    #Verify the loading of view order sercive tile
    click_on_mo_view_ordered_service_text_tile_link()
    #Verify the loading of review pending order tile
    click_on_mo_review_pending_orders_text_tile_link()
    #Verify the loading of maange catalog tile
    click_on_mo_manage_catalog_text_tile_link()
    #Verify the loading of manange approval policies tile
    click_on_mo_manage_approval_policies_text_tile_link()
    #Verify the loading of manange opertation policies tile
    click_on_mo_manage_operation_policies_tile_link()











