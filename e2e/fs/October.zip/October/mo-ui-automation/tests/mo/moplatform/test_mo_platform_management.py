from helpers.mo_json_utils import modify_parameter, set_data_path
from pages.common.system_settings_page import enable_platform_management, disable_platform_management
from pages.store.navigation_page import open_platform_management, open_system_settings_page, open_user_access_page
from pages.common.platform_management_page import *
from pages.store.user_access_management_page import *
from tests.common_test import get_random_int
import pytest


test_data_path = os.path.join(mo_test_data_path, "platform_management", "platform_management.json")
org_name = None
team_name = None

# Skipping Organizations and Teams tests as they are deprecated with this message.
skip_test_message = "Organizations and Teams are deprecated. No way of currently test this. New UI coming in Q2"


# @pytest.mark.skip(reason=skip_test_message)
# @pytest.mark.dependency()    
# def test_enable_platform_management():
#     """Platform Management --- Enable Platform Management and verifies add buttons not present in User Access Management"""
#     open_system_settings_page()
#     enable_platform_management()
#     # -- Verify add buttons are not present in Teams, Organizations and User Access --
#     open_user_access_page()
#     # Organizations
#     open_organizations_tab()
#     verify_user_access_mngmt_add_button_not_present()
#     # Teams
#     open_teams_tab()
#     verify_user_access_mngmt_add_button_not_present()
#     # User Access
#     open_user_access_tab()
#     verify_user_access_mngmt_add_button_not_present()


# @pytest.mark.skip()
# @pytest.mark.dependency(depends=['test_enable_platform_management'])    
# def test_platform_management_create_new_organization():
#     """Platform Management --- Create an organization, validates it and adds tenant existing users"""
#     global org_name
#     org_name = get_random_int('testautoorg')
#     modify_param = {
#         'Organization.Name': org_name
#     }
#     modify_parameter(modify_param)
#     set_data_path(test_data_path)
#     transfer_user = users_data['transfer_user']['user']
#     open_platform_management()
#     platform_mngmt_add_organization()
#     platform_mngmt_add_member_to_organization(transfer_user)
#     platform_mngmt_validate_organization_values_in_org_details(org_name)
#     platform_mngmt_click_settings_button()
#     platform_mngmt_validate_organization_in_settings()
#     platform_mngmt_navigate_in_breadcrumb(PF_BC_ORG_DETAILS)
#     platform_mngmt_validate_member_added(transfer_user)


# @pytest.mark.skip()
# @pytest.mark.dependency(depends=['test_platform_management_create_new_organization'])
# def test_platform_management_edit_organization():
#     """Platform Management --- Edit an organization and validates it"""
#     org_name_aux = get_random_int('testautoorgedit')
#     modify_param = {
#         'Edit Organization.Name': org_name_aux
#     }
#     modify_parameter(modify_param)
#     set_data_path(test_data_path)
#     platform_mngmt_click_settings_button()
#     platform_mngmt_edit_organization()
#     platform_mngmt_validate_organization_in_settings(
#         org_data_key=PF_ORGANIZATION_EDIT_KEY)
#     platform_mngmt_navigate_in_breadcrumb(PF_BC_ORG_DETAILS)
#     global org_name
#     org_name = org_name_aux
#     platform_mngmt_validate_organization_values_in_org_details(org_name)


# @pytest.mark.skip()
# @pytest.mark.dependency(depends=['test_platform_management_create_new_organization'])
# def test_platform_management_add_member_with_invite_to_organization():
#     """Platform Management --- Selects an organization, invite a new user and revoke invite"""
#     open_platform_management()
#     platform_mngmt_select_organization_details(org_name)
#     platform_mngmt_open_add_members_slider()
#     new_user = platform_mngmt_generate_random_email()
#     platform_mngmt_add_member_to_organization(new_user)
#     platform_mngmt_validate_member_added(new_user, with_invite=True)
#     platform_mngmt_revoke_invite(new_user)


# @pytest.mark.skip()
# @pytest.mark.dependency(depends=['test_platform_management_create_new_organization'])
# def test_platform_management_create_new_team():
#     """Platform Management --- Create a team, validates it and adds tenant existing users"""
#     global team_name
#     team_name = get_random_int('testautoteam')
#     modify_param = {
#         'Team.Organization': org_name,
#         'Team.Name': team_name
#     }
#     modify_parameter(modify_param)
#     set_data_path(test_data_path)
#     buyer_user = users_data['buyer_user']['user']
#     open_platform_management()
#     platform_mngmt_add_team()
#     platform_mngmt_add_member_to_team(buyer_user)
#     platform_mngmt_validate_team_values_in_team_details(team_name, org_name)
#     platform_mngmt_click_settings_button()
#     platform_mngmt_validate_team_in_settings()
#     platform_mngmt_navigate_in_breadcrumb(PF_BC_TEAM_DETAILS)
#     platform_mngmt_validate_member_added(buyer_user)


# @pytest.mark.skip()
# @pytest.mark.dependency(depends=['test_platform_management_create_new_team'])
# def test_platform_management_edit_team():
#     """Platform Management --- Edit a team and validates it"""
#     team_name_aux = get_random_int('testautoteamedit')
#     modify_param = {
#         'Edit Team.Name': team_name_aux
#     }
#     modify_parameter(modify_param)
#     set_data_path(test_data_path)
#     platform_mngmt_click_settings_button()
#     platform_mngmt_edit_team()
#     platform_mngmt_validate_team_in_settings(team_data_key=PF_TEAM_EDIT_KEY)
#     platform_mngmt_navigate_in_breadcrumb(PF_BC_TEAM_DETAILS)
#     global team_name
#     team_name = team_name_aux
#     platform_mngmt_validate_team_values_in_team_details(team_name, org_name)


# @pytest.mark.skip()
# @pytest.mark.dependency(depends=['test_platform_management_create_new_team'])
# def test_platform_management_add_member_with_invite_to_team():
#     """Platform Management --- Selects a team, invite a new user and revoke invite"""
#     open_platform_management()
#     platform_mngmt_select_team_details(team_name)
#     platform_mngmt_open_add_members_slider()
#     new_user = platform_mngmt_generate_random_email()
#     platform_mngmt_add_member_to_team(new_user)
#     platform_mngmt_validate_member_added(new_user, with_invite=True)
#     platform_mngmt_revoke_invite(new_user)


# @pytest.mark.skip()
# @pytest.mark.dependency(depends=['test_platform_management_create_new_team'])
# def test_platform_management_delete_team():
#     """Platform Management --- Selects a team and delete it"""
#     open_platform_management()
#     platform_mngmt_select_team_details(team_name)
#     platform_mngmt_click_settings_button()
#     platform_mngmt_delete_team(team_name)


# @pytest.mark.skip()
# @pytest.mark.dependency(depends=['test_platform_management_create_new_organization'])
# def test_platform_management_delete_organization():
#     """Platform Management --- Selects an organization and delete it"""
#     open_platform_management()
#     platform_mngmt_select_organization_details(org_name)
#     platform_mngmt_click_settings_button()
#     platform_mngmt_delete_organization(org_name)


def test_platform_management_create_and_delete_new_user():
    """Platform Management --- Creates a new user, validates and revoke invite"""
    email = platform_mngmt_generate_random_email()
    modify_param = {
        'User.Emails': email
    }
    modify_parameter(modify_param)
    set_data_path(test_data_path)
    open_platform_management()
    platform_mngmt_add_user()
    platform_mngmt_validate_invite_pending(email)
    platform_mngmt_revoke_invite(email)


# @pytest.mark.skip()
# @pytest.mark.dependency(depends=['test_enable_platform_management'])
# def test_disable_platform_management():
#     """Platform Management --- Disable Platform Management and verifies add buttons are present in User Access Management"""
#     open_system_settings_page()
#     disable_platform_management()
#     # -- Verify add buttons are present in Teams, Organizations and User Access --
#     open_user_access_page()
#     # Organizations
#     open_organizations_tab()
#     verify_user_access_mngmt_add_button_present()
#     # Teams
#     open_teams_tab()
#     verify_user_access_mngmt_add_button_present()
#     # User Access
#     open_user_access_tab()
#     verify_user_access_mngmt_add_button_present()


# @pytest.mark.skip()
# def test_remove_all_created_resources():
#     """Platform Management --- Delete all remaining organizations, teams and pending invitations created by the tests (Teardown)"""
#     open_platform_management()
#     element_prefix = 'testauto'
#     click_organizations_tab()
#     delete_all_table_elements_by_search(element_prefix)
#     click_teams_tab()
#     delete_all_table_elements_by_search(element_prefix)
#     click_pending_invitations_tab()
#     delete_all_table_elements_by_search(element_prefix)


def test_platform_management_create_delete_access_group():
    """Platform Management --- Creates new Access Group, validates and Delete"""
    access_group_name = get_random_int("testautogroup")
    modify_param = {
        'Access Group.Access Group Name': access_group_name
    }
    modify_parameter(modify_param)
    set_data_path(test_data_path)
    # open_platform_management()
    add_access_group(access_group_name)
    delete_access_group(access_group_name)


def test_platform_management_create_delete_connection():
    """Platform Management --- Creates a new Connection, validates and Delete"""
    connection_name = get_random_int("testautoconnection")
    modify_param = {
        'Connection.Connection Name': connection_name
    }
    modify_parameter(modify_param)
    set_data_path(test_data_path)
    # open_platform_management()
    add_new_connection(connection_name)
    platform_mngmt_navigate_in_breadcrumb("IAM")
    delete_connection(connection_name)

