import pytest
from pages.assetlib.asset_library_page import *
from pages.common.launchpad_page import *
from pages.store.catalog_management_page import *
from pages.store.topology_page import *
from pages.store.navigation_page import *
from pages.store.catalog_page import *
from helpers.mo_resources import *
from pages.common.login_page import *
from tests.common_test import logout_and_login

assetlib_data_path = os.path.join(assetlib_data_path, "assetlibrary.json")


@pytest.fixture(autouse=True)
def before_tests():
    set_data_path(assetlib_data_path)


def test_asset_library_navigations():
    """open Asset Library from link on launch pad and other from menu"""
    open_asset_library_page()
    validate_title_on_asset_library_page()
    click_on_asset_library_link()


def test_validate_quick_links():
    """open Asset Library and verify quick links"""
    open_asset_library_page()
    validate_title_on_asset_library_page()
    validate_quick_links()
    validate_explore_templates(get_data("OfficialTitle"))
    validate_explore_templates(get_data("PartnerTitle"))
    validate_explore_templates(get_data("CommunityTitle"))
    validate_explore_catalog()


def test_validate_applied_filter():
    """open Asset Library, apply filter and validate applied filter value"""
    open_asset_library_page()
    # validate before filter
    check.is_true(is_element_not_present(filtered_result, "filtered results"), "filter is not applied")
    validate_applied_filter(get_data("OfficialTitle"))
    filtered_results = get_element_text(filtered_result).split()
    # validate after apply filter, results count should greater than 0
    check.greater(filtered_results[-1].strip("()"), "0", 'count after filter')
    template_list = get_element_text(templates_list)
    logger.info(template_list)
    # after applying filter, validate templates list should not none
    check.is_not_none(get_element_text(templates_list), "templates list")


def test_add_template():
    """open Asset Library, add template and verify added template in dashboard"""
    refresh_current_page()
    open_asset_library_page()
    clear_notification()
    click_on_add_template()
    add_template_fill_parameters("Add Template")
    check.equal(get_element_text(success_notification), get_data('add_notification'), 'added template success message')
    refresh_current_page()
    open_asset_library_page()
    # validate notification and wait for 5 mins to get inapp notification and validate notification
    validate_success_message_from_notification()
    search_added_template_on_dashboard(assetlib_data_path)
    template = get_element_text(template_title)
    check.equal(template, get_data('addedTemplateName'), 'template title')


def test_existed_template():
    """open Asset Library, select any existed template, verify its details and validate whether file is downloading"""
    open_asset_library_page()
    select_template(assetlib_data_path)
    template = get_element_text_replace_value(template_title, get_data('TemplateName'), 'template title')
    check.equal(template, get_data('TemplateName'), 'template title')
    get_reliability_details()
    download_template()
    check.is_true(is_file_downloaded(), 'File downloaded')


def test_edit_template():
    """open Asset Library, select added template and edit its details and validate changes"""
    refresh_current_page()
    open_asset_library_page()
    search_added_template_on_dashboard(assetlib_data_path)
    click_on_edit_template()
    edit_fill_parameters("Edit Template")
    check.is_in(get_element_text(success_notification), get_data("edit_notification"), 'edit success message')
    value1 = get_data("edited_value1")
    validate_readiness_details(value1)
    value2 = get_data("edited_value2")
    validate_label_details(value2)


def test_template_with_known_issue():
    """open Asset Library, add template with known issue and click on known issue link, then extract all zip and validate whether zip file is downloading"""
    refresh_current_page()
    open_asset_library_page()
    search_added_template_on_dashboard(assetlib_data_path)
    click_on_known_issue_link()
    # click on all tab and check data is not empty then click on export all zip
    click_using_java_script(tfsec_tab, "tfsec tab")
    check.is_not_none(get_element_text(tab_content), "tfsec tab content")
    click_using_java_script(kics_tab, "kics tab")
    check.is_not_none(get_element_text(tab_content), "kics tab content")
    click_using_java_script(checkov_tab, "checkov tab")
    check.is_not_none(get_element_text(tab_content), "checkov tab content")
    click_on_export_all_button()
    check.is_true(is_file_downloaded(), 'File downloaded')

