from pages.store.approve_order_page import *
from pages.store.order_history_page import *
from pages.store.ordered_services_page import *
from pages.store.review_order_page import *
from tests.common_test import *

mongo_db_data_path = os.path.join(test_data_path, "alicloud", "apsara_mongo_db.json")
vpc_data_path = os.path.join(test_data_path, "alicloud", "virtual_private_cloud.json")
service_name = None
order_no = None
service_name_vpc = None
vpc_name = None


def test_provision_vpc_service():
    """ ALI CLOUD: Apsara DB for MongoDb ---- Create VPC Service"""
    global service_name_vpc
    global vpc_name
    vpc_name = get_random_int("ali-vpc-mongo-db-")
    service_name_vpc = get_random_int("ali-vpc-mongo-")
    modify_param = {'Service Instance Name': service_name_vpc, "Region": "UAE (Dubai)", "VPC Name": vpc_name, "Zone Id": "me-east-1a"}
    modify_parameter(modify_param)
    open_catalog_page()
    select_service_template(vpc_data_path)
    click_on_configure_btn()
    fill_order_details()
    # Submit order
    click_submit_order()
    global order_no
    order_no = get_order_id()
    set_data(order_no)
    # Approve order and wait till it gets completed
    approve_order_wait_for_completion(order_no, service_name_vpc)


def test_verify_service_order_flow():
    """ ALI CLOUD: Apsara DB for MongoDb ---- Verify fields on Main Parameters, Summary details and
    Additional Details are listed on Review Order page """
    global service_name
    service_name = get_random_int("ali-apsara-mongodb-")
    modify_param = {'Service Instance Prefix': service_name, "Vpc ID": vpc_name}
    modify_parameter(modify_param)
    open_catalog_page()
    select_service_template(mongo_db_data_path)
    verify_catalog_details_page()
    click_on_configure_btn()
    fill_order_details()
    # Validate service configurations on review order page
    verify_review_order()
    # Validate the pricing
    exp_estimated_cost = get_data("TotalCost")
    # Submit order
    click_submit_order()
    global order_no
    order_no = get_order_id()
    set_data(order_no)
    # Validate service configurations, order details and bill of materials on orders page
    validate_orders_page(order_no, service_name, exp_estimated_cost, None, None, mo_ui_test_data["orderTypeNew"],
                         False, True)
    # Validate service configurations and bill of materials on order history page
    click_to_order_history()
    search_order_in_history(order_no)
    validate_service_details_bill_of_materials(exp_estimated_cost, "Service Details", False, None, None, None, None,
                                               True)


def test_verify_service_provisioning(check_order_creation):
    """ ALI CLOUD: Apsara DB for MongoDb ---- Approve and Provision Order """
    # Approve order and wait till it gets completed
    approve_order_wait_for_completion(order_no, service_name)


def test_verify_service_details_on_ordered_services(check_status):

    """ ALI CLOUD: Apsara DB for MongoDb ---- Verify Service details """
    # Validate Service Configurations and Bill of Materials for service on ordered services page
    validate_service_details_ordered_services(service_name, False, None, True)
    # Get SOI component and system tag details from test data file
    soi_component_details = get_data("Component Details")
    system_tags_details, output_params = verify_soi_component_details(soi_component_details)
    verify_soi_component_details_for_real(system_tags_details, output_params, exp_tags_key='real_adapter_tags',
                                          exp_output_params_key='real_adapter_output_params')


def test_verify_deletion_of_service(check_status):
    """ ALI CLOUD: Apsara DB for MongoDb ---- Delete Order """
    # Delete Service instance of cloud enterprise network
    delete_order_no = delete_service(service_name)
    # Approve order and wait till it gets completed
    approve_order_wait_for_completion(delete_order_no, service_name)
    # Delete Service instance of vpc
    delete_order_no_vpc = delete_service(service_name_vpc)
    # Approve order and wait till it gets completed
    approve_order_wait_for_completion(delete_order_no_vpc, service_name_vpc)
