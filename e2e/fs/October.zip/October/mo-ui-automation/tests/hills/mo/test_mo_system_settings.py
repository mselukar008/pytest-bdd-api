import pytest
from pages.common.launchpad_page import *
from pages.common.login_page import load_base_page
from pages.store.navigation_page import *
from pages.common.system_settings_page import *
from tests.common_test import logout_and_login

urls_path = os.path.join(test_data_path, "app_urls.json")
valid_logo_path = os.path.join(hills_system_settings_test_data_path, "IBM_Logo.JPG")
invalid_logo_path = os.path.join(hills_system_settings_test_data_path, "IBM_Logo_1mb.JPG")


@pytest.fixture(scope="module", autouse=True)
def before_all():
    load_base_page(tenant)
    # Logout and logged in using "Admin"
    admin_user = users_data['main_user']
    logout_and_login(admin_user)


@pytest.fixture(scope="function", autouse=True)
def before_each():
    load_base_page(tenant)
    verify_home_page()


def test_verify_visibility_invisibility_disabled_app_links():
    """ Verify visibility/invisibility of Not accessible application links from launchpad """

    set_data_path(urls_path)
    validate_current_url(get_json_data_key("launchpad_url"))
    is_present = is_disabled_app_links_present()
    if is_present:
        open_system_settings_page()
        verify_and_go_to_theme_settings()
        validate_current_url(get_json_data_key("system_settings_theme_url"))
        hide_disabled_links()
        click_on_save_cancel_theme_button(mo_ui_test_data["themeSaveButton"])
        load_base_page(tenant)
        verify_home_page()
        validate_current_url(get_json_data_key("launchpad_url"))
        check.equal(is_disabled_app_links_present(), False, "Disabled app links")
        open_system_settings_page()
        verify_and_go_to_theme_settings()
        validate_current_url(get_json_data_key("system_settings_theme_url"))
        click_on_reset_default_link()
        load_base_page(tenant)
        verify_home_page()
        validate_current_url(get_json_data_key("launchpad_url"))
        check.equal(is_disabled_app_links_present(), True, "Disabled app links")


def test_change_logo_setting():
    """ Verify choose logo functionality """

    open_system_settings_page()
    verify_and_go_to_theme_settings()
    check.is_true(is_choose_logo_button_enable(), "Choose logo button")
    apply_logo(valid_logo_path)
    click_on_save_cancel_theme_button(mo_ui_test_data["themeSaveButton"])
    check.is_true(verify_logo_preview(), "Logo preview")
    click_on_reset_default_link()
    check.is_false(verify_logo_preview(), "Logo preview")


def test_change_logo_setting_negative_test():
    """ Negative test: Logo file size is more than 1 MB """

    open_system_settings_page()
    verify_and_go_to_theme_settings()
    check.is_true(is_choose_logo_button_enable(), "Choose logo button")
    apply_logo(invalid_logo_path)
    check.equal(get_notification_msg_text(), mo_ui_test_data["fileSizeExceedsMsg"], "File Size Exceeds Error message")


def test_apply_theme_setting():
    """ Verify Theme is applied """

    current_color_code = get_mini_tile_color_code()
    if current_color_code != mo_ui_test_data["grayThemeColorCode"]:
        open_system_settings_page()
        verify_and_go_to_theme_settings()
        check.is_true(is_theme_dropdown_enable(), "Theme dropdown button")
        select_theme(mo_ui_test_data["grayThemeOption"])
        click_on_save_cancel_theme_button(mo_ui_test_data["themeSaveButton"])
        load_base_page(tenant)
        verify_home_page()
        check.equal(get_mini_tile_color_code(), mo_ui_test_data["grayThemeColorCode"], "Gray theme color code")
        open_system_settings_page()
        verify_and_go_to_theme_settings()
        click_on_reset_default_link()
        load_base_page(tenant)
        verify_home_page()
        check.equal(get_mini_tile_color_code(), mo_ui_test_data["defaultThemeColorCode"], "Default theme color code")


def test_verify_white_labeling():
    """Hill 22.02 IT Admin Layla does actions on behalf the customer tenant"""

    # Validate white labeling is disabled
    # load_base_page(tenant)
    # Logout and logged in using "CT Marshall"
    ct_marshall = users_data["kyn_user"]
    logout_and_login(ct_marshall)
    # Verify the services for Multicloud management portal
    check.is_true(is_element_present(common_tasks_text, "Common Tasks"), "Common Tasks")
    check.is_true(is_element_present(applications_text, "Applications"), "Applications")
    check.is_true(is_element_present(knowledge_center_text, "Knowledge Center"), "Knowledge Center")
    open_system_settings_page()
    check.equal(get_element_text(system_settings_header_text), mo_ui_test_data["systemSettingsHeaderText"],
                "System Settings header text")
    check.is_true(is_element_not_present(tab_links, mo_ui_test_data["themeTitle"]), "Theme Title is not present")

    # Validate white labeling is enabled for Layla(SP Admin user)
    layla_user = users_data["main_user"]
    logout_and_login(layla_user)
    # Verify the services for Multicloud management portal
    check.is_true(is_element_present(common_tasks_text, "Common Tasks"), "Common Tasks")
    check.is_true(is_element_present(applications_text, "Applications"), "Applications")
    check.is_true(is_element_present(knowledge_center_text, "Knowledge Center"), "Knowledge Center")
    open_system_settings_page()
    verify_and_go_to_theme_settings()
    check.is_true(is_brand_textbox_present(), "Brand Textbox button")
    enter_brand_name(mo_ui_test_data["BrandName"])
    click_on_save_cancel_theme_button(mo_ui_test_data["themeSaveButton"])
    load_base_page(tenant)
    verify_home_page()
    check.equal(get_element_text(app_title), mo_ui_test_data["BrandName"], "Application Title")
    open_system_settings_page()
    check.equal(get_element_text(app_title), mo_ui_test_data["BrandName"], "Application Title")

    # Validate CT Marshall user is able to see the changes made by the SP Admin User
    logout_and_login(ct_marshall)
    verify_home_page()
    check.equal(get_element_text(app_title), mo_ui_test_data["BrandName"], "Application Title")
    open_system_settings_page()
    check.equal(get_element_text(app_title), mo_ui_test_data["BrandName"], "Application Title")

    logout_and_login(layla_user)
    open_system_settings_page()
    verify_and_go_to_theme_settings()
    click_on_reset_default_link()
    load_base_page(tenant)
    verify_home_page()
    check.equal(get_element_text(app_title), mo_ui_test_data["PortalPageHeader"], "Application Title")
    open_system_settings_page()
    check.equal(get_element_text(app_title), mo_ui_test_data["PortalPageHeader"], "Application Title")

    # Validate CT Marshall user is able to see the reset to default changes made by the SP Admin User
    logout_and_login(ct_marshall)
    verify_home_page()
    check.equal(get_element_text(app_title), mo_ui_test_data["PortalPageHeader"], "Application Title")
    open_system_settings_page()
    check.equal(get_element_text(app_title), mo_ui_test_data["PortalPageHeader"], "Application Title")
