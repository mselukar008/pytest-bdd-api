from helpers.mo_json_utils import *
from pages.common.login_page import load_base_page
from pages.ecam.insights_page import *
from pages.store.navigation_page import *
from locators.ecam.insights_locator import *

# Set up testdata file path
test_data_path = os.path.join(hills_ecam_test_data_path, "insights_page.json")


def test_savings_with_provisioned_resources():
    """ Hill 14: Director of IT Finance: Find savings with currently provisioned assets """
    set_data_path(test_data_path)
    load_base_page(tenant)
    open_insights_page()
    # Validate user is landed on Insights Dashboard
    check.equal(get_insights_header_title_text(), get_data("headerTitleText"), "Insights Dashboard title text")
    # Validate Dynamic Resource Group is displayed and contains filterable items
    check.greater(is_present_dynamic_resource_groups(), 0, "Number of DRGs")
    click(filters_close_button, "Filters close button")
    # Validate Summary values before applying filters
    validate_summary_values()
    # estimated_cost_before_filter = get_summary_values(get_data("summaryEstimatedCostLabel"))
    no_of_opportunities_before_filter = get_summary_values(get_data("summaryOpportunitiesLabel"))
    estimated_savings_before_filter = get_summary_values(get_data("summaryEstimatedSavingsLabel"))
    # Validate Mini chart values before applying filters
    validate_minichart_values()
    total_estimated_savings_before_filter = get_minichart_values(get_data("totalEstimatedSavingsPerServiceProvider"))
    total_opportunities_before_filter = get_minichart_values(get_data("totalOpportunitiesPerServiceProvider"))
    # Apply optimization filters- removed as per new FEATURE 1079070
    # apply_optimization_filter("1")
    # Compare Summary values before and after applying filters
    # estimated_cost_after_filter = get_summary_values(get_data("summaryEstimatedCostLabel"))
    # no_of_opportunities_after_filter = get_summary_values(get_data("summaryOpportunitiesLabel"))
    # estimated_savings_after_filter = get_summary_values(get_data("summaryEstimatedSavingsLabel"))
    # try:
    #     # check.greater(estimated_cost_before_filter, estimated_cost_after_filter, "Estimated Cost")
    #     check.greater(no_of_opportunities_before_filter, no_of_opportunities_after_filter, "Opportunities")
    #     check.greater(estimated_savings_before_filter, estimated_savings_after_filter, "Estimated Savings")
    # except:
    #     pass
    # # Compare Mini chart values before and after applying filters
    # total_estimated_savings_after_filter = get_minichart_values(get_data("totalEstimatedSavingsPerServiceProvider"))
    # total_opportunities_after_filter = get_minichart_values(get_data("totalOpportunitiesPerServiceProvider"))
    # try:
    #     check.greater(total_estimated_savings_before_filter, total_estimated_savings_after_filter, "Estimated Savings")
    #     check.greater(total_opportunities_before_filter, total_opportunities_after_filter, "Opportunities")
    # except:
    #     pass
    # Apply optimization filters
    # apply_optimization_filter("11")
    # Check for 'No Data' in table
    if get_elements_count(table_no_data_text) == 0:
        # Validate sorting of Estimated Savings column
        check.is_true(validate_sorting_of_assets(get_data("estimatedSavingsColName")), "Sorting of Assets")
        if click_on_asset_id_having_tags(get_data("shutOffAssetValue")):
            # Validate Properties tab [Reason, Recommendation type, Estimated Savings]
            validate_asset_properties_values()
            # Validate Tags tab
            click_on_asset_details_tabs(get_data("tagsTabText"))
            if get_tags_count_from_tab_name() != 0:
                check.not_equal(get_tags_keys(), None, "Tag keys")
            # Validate Associated Costs tab
            click_on_asset_details_tabs(get_data("associatedCostsTabText"))
            check.greater_equal(get_elements_count(table_rows), 0, "Associated Costs Table Rows")
