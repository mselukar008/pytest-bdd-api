from tests.common_test import *
from helpers.mo_json_utils import *
from pages.ecam.costs_page import *
from pages.ecam.assets_page import *
from pages.store.navigation_page import *

# Set up testdata file path
test_data_path = os.path.join(hills_ecam_test_data_path, "costs_assets_page.json")


def test_spend_status_in_relation_to_budget():
    """ Hill 9 - Senior Developer: Understanding spend status in relation to budget """
    current_month_year = get_month_year_using_index(0)
    previous_month_year = get_month_year_using_index(1)

    # Costs page validations
    set_data_path(test_data_path)
    load_base_page(tenant)
    open_costs_page()
    # Validate user is landed on Costs Dashboard
    check.equal(get_costs_header_title_text(), get_data("costsHeaderTitleText"), 'Cost Header')
    select_drg_from_data_set_filters(get_data("drgDropdownValue"))
    # Validate summary header info text
    check.is_in(get_data("costsSummaryHeaderText"), get_element_text(summary_header_info_text), 'Cost Summary Header')
    
    # Click on current month
    click_costs_bar_chart_using_month(get_data("currentMonthIndex"))
    # Validate costs summary values
    validate_costs_page_summary()
    check.equal(get_element_text(summary_value_month_text), current_month_year, 'Summary Value Month')
    # Click on show projection checkbox
    click_on_show_projection_checkbox()
    # Validate cost bar chart values
    validate_cost_bar_chart()
    # Validate minicharts count
    check.equal(get_elements_count(mini_charts), get_data("miniChartsCount"), 'Minicharts Count')
    # Validate mini charts values for current month
    cost_dropdown_values = [get_data("costPerBilling"), get_data("costPerAsset"), get_data("costPerSerProvider"),
                        get_data("costPerCategory"), get_data("costPerBU")]
    validate_cost_page_minichart_values(cost_dropdown_values, current_month_year)

    # Click on previous month
    click_costs_bar_chart_using_month(get_data("previousMonthIndex"))
    # Validate summary values
    validate_costs_page_summary()
    check.equal(get_element_text(summary_value_month_text), previous_month_year, 'Summary Month')
    # Validate cost bar chart values
    validate_cost_bar_chart()
    # Validate minicharts count
    check.equal(get_elements_count(mini_charts), get_data("miniChartsCount"), 'Minichart Count')
    # Validate mini charts values for previous month
    validate_cost_page_minichart_values(cost_dropdown_values, previous_month_year)
    # Validate table widget title text
    check.equal(get_element_text(table_widget_title_text), get_data("costTableWidgetTitle"), 'Cost Table Widget Title')

    # Assets page validations
    open_assets_page()
    # Validate user is landed on Assets Dashboard
    check.equal(get_costs_header_title_text(), get_data("assetsHeaderTitleText"))
    select_drg_from_data_set_filters(get_data("drgDropdownValue"))
    # Validate summary header info text
    check.is_in(get_data("assetsSummaryHeaderText"), get_element_text(summary_header_info_text))

    wait_for_to_load_costs_page()
    # Click on current month
    click_assets_bar_chart_using_month(get_data("currentMonthIndex"))
    # Validate assets summary values
    validate_costs_page_summary()
    check.equal(get_element_text(summary_value_month_text), current_month_year, 'Summary Month Text')
    # Validate asset bar chart values
    validate_asset_bar_chart()
    # Validate asset vs utilization heat map values
    validate_asset_utilization_heat_map()
    # Validate minicharts count
    check.equal(get_elements_count(mini_charts), get_data("miniChartsCount"), 'Minichart Count')
    # Validate mini charts values for current month
    asset_dropdown_values = [get_data("costPerAssetType"), get_data("costPerBilling"), get_data("assetCostPerCategory"),
                        get_data("costPerSerProvider"), get_data("costPerAsset"), get_data("costPerBU"), get_data("costPerAssetStatus")]
    asset_count_per_dropdown_values = [get_data("countPerLocation"), get_data("countPerSerProvider"), get_data("countPerBilling"),
                                    get_data("countPerAsset"), get_data("countPerCategory"), get_data("countPerAssetType"), get_data("countPerAssetStatus")]
    validate_cost_page_minichart_values(asset_dropdown_values, current_month_year)
    validate_cost_page_minichart_values(asset_count_per_dropdown_values, current_month_year)

    # Click on previous month
    click_assets_bar_chart_using_month(get_data("previousMonthIndex"))
    # Validate assets summary values
    validate_costs_page_summary()
    check.equal(get_element_text(summary_value_month_text), previous_month_year, 'Summary Month Text')
    # Validate asset bar chart values
    validate_asset_bar_chart()
    # Validate asset vs utilization heat map values
    validate_asset_utilization_heat_map()
    # Validate minicharts count
    check.equal(get_elements_count(mini_charts), get_data("miniChartsCount"), 'Minichart Count')
    # Validate mini charts values for previous month
    validate_cost_page_minichart_values(asset_dropdown_values, previous_month_year)
    validate_cost_page_minichart_values(asset_count_per_dropdown_values, previous_month_year)
    # Validate table widget title text
    check.equal(get_element_text(table_widget_title_text), get_data("assetTableWidgetTitle"), 'Table Widget Title')
    # Validate download line items from assets table
    if download_line_items_from_table(get_data("formatType")):
        download_report_from_notification()
        # Validate if file is downloaded or not
        check.is_true(is_downloaded_file_exists(), 'File downloaded')
