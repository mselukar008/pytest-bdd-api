from pages.ecam.costs_page import *
from pages.store.navigation_page import *


# Set up testdata file path
test_data_path = os.path.join(hills_ecam_test_data_path, "costs_assets_page.json")


def test_generate_itemized_invoice():
    """ Hill 7 - Billing Analyst: Generate itemized invoice """
    set_data_path(test_data_path)
    load_base_page(tenant)
    open_costs_page()
    # Validate user is landed on Costs Dashboard
    check.equal(get_costs_header_title_text(), get_data("costsHeaderTitleText"), 'Cost Header Title')
    select_drg_from_data_set_filters(get_data("drgDropdownValue"))
    # Validate summary header info text
    check.is_in(get_data("costsSummaryHeaderText"), get_element_text(summary_header_info_text), 'Cost Summary Header')
    # Validate costs summary values
    validate_costs_page_summary()
    # Click on show projection checkbox
    click_on_show_projection_checkbox()
    # Validate cost bar chart values
    validate_cost_bar_chart()
    # Validate minicharts count
    check.equal(get_elements_count(mini_charts), get_data("miniChartsCount"), 'Minichart Count')
    # Validate table widget title text
    check.equal(get_element_text(table_widget_title_text), get_data("costTableWidgetTitle"), 'Cost Table Widget Title')
    # Validate download line items from assets table
    if download_line_items_from_table(get_data("formatType")):
        download_report_from_notification()
        # Validate if file is downloaded or not
        check.is_true(is_downloaded_file_exists(), 'File downloaded')
