from pages.ecam.drg_page import *
from pages.store.navigation_page import *
from  helpers.mo_check import mo_check as check


# Set up testdata file path
test_data_path = os.path.join(hills_ecam_test_data_path, "drg_page.json")
dynamic_values_testdata = os.path.join(hills_test_data_path, "dynamic_values.json")

def test_dynamic_resource_group_creation():
    """ Hill 10.02 - IT Admin: Dynamic Resource Group Creation """

    load_base_page(tenant)
    # Logout and logged in using "Jane"
    jane_user = users_data["financial_user"]
    logout_and_login(jane_user)

    drg_name = get_random_int("EMP_IBM_Resource")
    set_data_path(dynamic_values_testdata)
    budgetary_unit_name = get_data("BudgetaryUnitName")
    open_drg_page()
    load_base_page(tenant)
    open_drg_page()
    wait_for_to_load_drg_page()
    set_data_path(test_data_path)
    click_on_create_new_btn()
    select_drg_type(get_data("budgetaryTypeDrgValue"))
    enter_drg_name(drg_name)
    click_on_next_btn()
    select_team_in_associate_context(get_data("teamName"))
    select_budgetary_unit_name(budgetary_unit_name)
    click_on_next_btn()
    wait_for_spinner_off()
    click_on_filters_button()
    select_provider_from_filters(get_data("providerName"))
    select_provider_tag_from_filters(get_data("tagKey"), get_data("tagValue"))
    click_on_apply_filters_button()
    wait_for_spinner_off()
    click_bar_chart_using_month(get_data("currentMonthIndex"))
    wait_for_spinner_off()
    check.is_true(is_element_present(table_line_items,"Table line items"),'Table line items')
    click_on_next_btn()
    # Validate DRG name on review page
    check.equal(get_element_text(review_page_drg_name_text).strip(), drg_name, "Review page DRG name")
    wait_for_spinner_off()
    click_on_save_btn()
    assert get_data("drgSuccessMessage") in get_element_text(notification_msg_text)
    # Update Budgetary unit name in the json
    update_json_file_single_value(dynamic_values_testdata, "DRGName", drg_name)