from locators.common.launchpad_page_locator import *
from pages.ecam.costs_page import verify_if_drg_is_available
from pages.ecam.drg_page import *
from pages.store.navigation_page import *
from helpers.mo_check import mo_check as check

# Set up testdata file path
drg_data_path = os.path.join(hills_ecam_test_data_path, "drg_page.json")
dynamic_values_testdata = os.path.join(hills_test_data_path, "dynamic_values.json")


def test_configure_drg_dynamic_tag():
    """Hill 03.11 - Configure Dynamic Resource Group and Dynamic tag"""

    load_base_page(tenant)
    # Logout and logged in using "Marshall"
    marshall_user = users_data["financial_user"]
    logout_and_login(marshall_user)

    # Verify the services for Multicloud management portal
    check.is_true(is_element_present(common_tasks_text, "Common Tasks"), "Common Tasks")
    check.is_true(is_element_present(applications_text, "Applications"), "Applications")
    check.is_true(is_element_present(knowledge_center_text, "Knowledge Center"), "Knowledge Center")

    # Create new DRG
    drg_name = get_random_int("HillDRGAuto")
    dynamic_key = get_random_int("HillAuto")
    dynamic_value = 20
    set_data_path(drg_data_path)
    open_drg_page()
    click_on_create_new_btn()
    select_drg_type(get_data("typeVisibility"))
    add_dynamic_tag(dynamic_key, dynamic_value)
    enter_drg_name(drg_name)
    click_on_next_btn()
    select_team_in_associate_context(get_data("teamBudget"))
    click_on_next_btn()
    wait_for_spinner_off()
    click_on_filters_button()
    select_provider_from_filters(get_data("providerName"))
    select_provider_tag_from_filters(get_data("tagKey"), get_data("tagValue"))
    click_on_apply_filters_button()
    wait_for_spinner_off()
    click_bar_chart_using_month(get_data("currentMonthIndex"))
    wait_for_spinner_off()
    check.is_true(is_element_present(table_line_items, "Table line items"), 'Table line items')
    click_on_next_btn()

    # Validate all on review page
    wait_for_spinner_off()
    check.equal(get_element_text(review_page_drg_type_text).lower(), get_data("typeVisibility"), "DRG Type")
    tag = dynamic_key + "~" + str(dynamic_value)
    check.equal(get_element_text(review_page_dynamic_tags_text), tag, "Dynamic Tag")
    check.equal(get_element_text(review_page_drg_name_text).strip(), drg_name, "DRG Name")
    check.is_in(get_element_text(review_page_context_text), get_data("teamBudget"), "DRG Context")
    check.equal(get_element_text(review_page_provider_text), get_data("providerName"), "Provider")
    check.is_in(get_element_text(review_page_provider_tag_text), get_data("tagKey"), "Provider Tag")
    check.is_true(verify_filter_set_table_for_provider(get_data("filterSetProvider")), "Provider in Filter set")
    check.is_true(verify_filter_set_table_for_tag(get_data("tagKey")), "Tag in Filter set")
    click_on_save_btn()
    assert get_data("drgSuccessMessage") in get_element_text(notification_msg_text)
    explicit_wait(5)

    # Open above DRG and validate all fields
    open_drg(drg_name)
    check.equal(get_element_text(review_page_drg_type_text).lower(), get_data("typeVisibility"), "DRG Type")
    tag = dynamic_key + "~" + str(dynamic_value)
    check.equal(get_element_text(review_page_dynamic_tags_text), tag, "Dynamic Tag")
    check.equal(get_element_text(review_page_drg_name_text).strip(), drg_name, "DRG Name")
    check.is_in(get_element_text(review_page_context_text), get_data("teamBudget"), "DRG Context")
    check.equal(get_element_text(review_page_provider_text), get_data("providerName"), "Provider")
    check.is_in(get_element_text(review_page_provider_tag_text), get_data("tagKey"), "Provider Tag")
    check.is_true(verify_filter_set_table_for_provider(get_data("filterSetProvider")), "Provider in Filter set")
    check.is_true(verify_filter_set_table_for_tag(get_data("tagKey")), "Tag in Filter set")

    # Verify if new DRG is available on Costs Dashboard
    open_costs_page()
    check.is_true(verify_if_drg_is_available(drg_name), "DRG on Costs Dashboard")

    # Delete the new DRG
    open_drg_page()
    delete_drg(drg_name)
