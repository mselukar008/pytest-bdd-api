from pages.common.login_page import load_base_page
from pages.store.catalog_page import *
from pages.store.navigation_page import *
from pages.store.review_order_page import *
from tests.common_test import get_random_int, logout_and_login

ibm_vs_test_data = os.path.join(hills_store_test_data_path, "ibm_cloud", "virtual_server.json")
dynamic_values_testdata = os.path.join(hills_test_data_path, "dynamic_values.json")


def test_order_new_service():
    """ Hill 03.03 - App Developer: Order New Service """

    load_base_page(tenant)
    # Logout and logged in using "Maureen"
    maureen_user = users_data["buyer_user"]
    logout_and_login(maureen_user)

    service_name = get_random_int("HillsTestAutomation")
    host_name = get_random_int("GSLSLVM")
    modify_param = {"Service Instance Prefix": service_name, "Hostname": host_name, "Operating System": "Redhat EL - 8.x Minimal (64 bit)", "Memory": "4 GB", "Cores": "8 x 2.0 GHz or higher Cores"}
    modify_parameter(modify_param)
    # Navigate to Catalog page
    open_catalog_page()
    select_service_template(ibm_vs_test_data)
    verify_catalog_details_page()
    click_on_configure_btn()
    fill_order_details()
    verify_review_order()
    check.is_in(get_data("estimatedPrice_increasedcost"), get_element_text(estimated_cost_text), "Estimated cost")
    click_submit_order()
    order_no = get_order_id()
    if len(order_no) > 0:
        update_json_file_single_value(dynamic_values_testdata, "ServiceName", service_name)
        update_json_file_single_value(dynamic_values_testdata, "OrderId", order_no)
    check.equal(get_element_text(total_estimated_cost_text), get_data("TotalCost_increasedcost"), "Total cost")
    click_on_goto_service_catalog_btn()
