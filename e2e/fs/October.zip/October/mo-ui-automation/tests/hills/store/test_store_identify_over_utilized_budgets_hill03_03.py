from pages.common.launchpad_page import *
from pages.ecam.costs_page import *
from pages.ecam.drg_page import *
from pages.ecam.insights_page import *
from pages.store.approve_order_page import *
from pages.store.budget_page import *
from pages.store.navigation_page import *
from pages.store.ordered_services_page import *
from tests.common_test import *

dynamic_values_testdata = os.path.join(hills_test_data_path, "dynamic_values.json")
cost_asset_data_path = os.path.join(hills_ecam_test_data_path, "costs_assets_page.json")
drg_data_path = os.path.join(hills_ecam_test_data_path, "drg_page.json")
budget_json_data = os.path.join(hills_test_data_path, "budget", "budgetary_unit_budget_data.json")
order_no = None
service_name = None
drg_name = None
budgetary_unit_name = None
service_name_url = None
service_provisioning = False


@pytest.fixture(scope="module", autouse=True)
def before_all():
    set_data_path(dynamic_values_testdata)
    global order_no
    order_no = get_data("OrderId")
    global service_name
    service_name = get_data("ServiceName")
    global drg_name
    drg_name = get_data("DRGName")
    global budgetary_unit_name
    budgetary_unit_name = get_data("BudgetaryUnitName")


@pytest.fixture(scope="function", autouse=True)
def before_each():
    load_base_page(tenant)
    # Logout and logged in using "Jane"
    jane_user = users_data["financial_user"]
    logout_and_login(jane_user)
    verify_home_page()


def test_complete_financial_approval_process():
    """ Hill 03.03 - IT Finance Manager: Approve financial approval for the ordered service """

    if order_no != "":
        open_approve_orders_page()
        search_order_in_approve(order_no)
        wait_for_order_present(order_no)
        validate_service_names(service_name)
        select_budgetary_unit_on_approve_orders(budgetary_unit_name)
        validate_alerts_for_hard_quota_threshold()
        click_approve_btn()
        # Validate order approval flow popup header
        check.equal(get_order_approval_flow_popup_table_header_text(),
                    mo_ui_test_data["approvalOrderFlowPopupHeaderText"])
        approve_order_technical_financial(FINANCIAL_APPROVER)
        # Validate approve order success message
        check.equal(get_order_success_msg_text(), mo_ui_test_data["approveOrderSuccessMsgText"])
        click_modal_approval_ok()
        click_on_all_orders_tab()
        try:
            search_order_in_approve(order_no)
        except:
            pass
        wait_for_order_present(order_no)
        order_status = wait_for_order_status(order_no, mo_ui_test_data["completedState"])
        check.equal(order_status, mo_ui_test_data["completedState"], "Completed order status")
        if order_status == mo_ui_test_data["completedState"]:
            global service_provisioning
            service_provisioning = True
            # Logout and logged in using 'admin' user
            load_base_page(tenant)
            admin_user = users_data["main_user"]
            logout_and_login(admin_user)

            # Get Service name url from Order Services page
            global service_name_url
            service_name_url = get_name_value_from_sub_table(service_name)
    else:
        raise pytest.skip("Order is not created in Hill 02.01")


def test_asset_name_on_costs_page():
    """ Hill 03.03 - IT Finance Manager: Verify provisioned asset name should be
    present in line items table according to the DRG filter selected """

    set_data_path(cost_asset_data_path)
    open_costs_page()
    # Validate user is landed on Costs Dashboard
    check.equal(get_costs_header_title_text(), get_data("costsHeaderTitleText"), 'Cost Header')
    # Click on current month
    click_costs_bar_chart_using_month(get_data("currentMonthIndex"))
    select_drg_from_data_set_filters(drg_name)
    click_on_filters_button()
    set_data_path(drg_data_path)
    select_provider_tag_from_filters(get_data("tagKey"), get_data("tagValue"))
    click_on_apply_filters_button()
    wait_for_to_load_costs_page()
    click_on_first_asset()
    set_data_path(cost_asset_data_path)
    click_on_asset_details_tabs(get_data("tagsTabText"))
    set_data_path(drg_data_path)
    check.equal(get_tag_value(get_data("tagKey")), get_data("tagValue"))


def test_review_budget_constraints():
    """ Hill 03.03 - IT Finance Manager: Review Budget Constraints """

    set_data_path(budget_json_data)
    open_budget_management()
    is_budget_unit_present = search_budget_unit(budgetary_unit_name)
    if is_budget_unit_present:
        open_budget_unit_details_slider_with_name(budgetary_unit_name)
        check.equal(get_element_text(budget_unit_slider_header_text), budgetary_unit_name, "Budgetary unit name")
        validate_budget_unit_status()
        validate_budget_unit_details()
        click_slider_budgets_tab()
        wait_for_budgets_table_to_load()
        current_month_year = get_month_year_using_index(0, budget=True)
        formatted_month_year = current_month_year.split(" ")[0] + "_" + current_month_year.split(" ")[1]
        budget_name = f"{budgetary_unit_name}_{formatted_month_year}"
        logger.info(f"Budget name: {budget_name}")
        show_all_budgets()
        check.is_true(is_budget_present(budget_name), "Budget name status")
        open_budget_details_slider_with_name(budget_name)
        validate_budget_details()
        budget_amount = get_element_text_replace_value(budget_detail_txt, 'Budget Amount', 'Budget Amount Value')
        budget_amount_num = float(budget_amount.split(" ")[1])
        available_amount = get_element_text_replace_value(budget_detail_txt, 'Available Amount',
                                                          'Available Amount Value')
        available_amount_num = float(available_amount.split(" ")[1])
        committed_amount = get_element_text_replace_value(budget_detail_txt, 'Committed Amount', 'Committed Amount Value')
        committed_amount_num = float(committed_amount.split(" ")[1])
        check.greater(committed_amount_num, budget_amount_num, "Committed Amount vs Budget Amount")
        check.greater(committed_amount_num, available_amount_num, "Committed Amount vs Available Amount")
        check.greater(budget_amount_num, available_amount_num, "Budget Amount vs Available Amount")
        # Close budget slider
        close_budget_slider()
        # Close budgetary unit slider
        close_budget_slider()

def test_clean_up_resources():
    """ Hill 03.03 - IT Finance Manager: Delete provisioned service and
    inactivate created budgetary unit """

    # Logout and logged in using 'admin' user
    load_base_page(tenant)
    admin_user = users_data["main_user"]
    logout_and_login(admin_user)
    if service_provisioning:
        # Delete provisioned service
        delete_order_no = delete_service(service_name)
        # Approve order and wait till it gets completed
        approve_order_wait_for_completion(delete_order_no, service_name)
    # Deactivate budget unit, if budget unit is present
    open_budget_management()
    is_budget_unit_present = search_budget_unit(budgetary_unit_name)
    if is_budget_unit_present:
        open_budget_unit_details_slider_with_name(budgetary_unit_name)
        inactive_budgets_in_batch()
        inactivate_budget_unit()
        close_budget_slider()
    # Delete created DRG
    open_drg_page()
    wait_for_to_load_drg_page()
    set_data_path(drg_data_path)
    delete_drg(drg_name)