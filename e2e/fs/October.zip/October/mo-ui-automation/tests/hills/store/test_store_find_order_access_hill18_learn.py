from helpers.mo_json_utils import *
from pages.store.catalog_page import *
from pages.store.navigation_page import *
from pages.store.order_history_page import *
from pages.store.ordered_services_page import *
from pages.store.review_order_page import *
from tests.common_test import *

lamp_stack_test_data = os.path.join(hills_store_test_data_path, "aws", "lamp_stack_using_single_ec2_learn.json")

def test_cancel_order_flow():
    """ Hill - 18: App Developer: Place an order, verify order details and cancel the order """

    service_name = get_random_int("TestAutomation")
    modify_param = { 'Service Instance Prefix': service_name }
    modify_parameter(modify_param)
    # Navigate to Catalog page
    open_catalog_page()
    set_data_path(lamp_stack_test_data)
    select_provider_type(get_data("provider"))
    click_category_type(get_data("Category"))
    # validate_and_select_label(get_data("Label"))
    # check.equal(get_elements_count(service_template_cards), 1, "Service template cards")
    click_service_name(get_data("bluePrintName"))
    verify_catalog_details_page()
    click_on_configure_btn()
    fill_order_details()
    # Validate service configurations on review order page
    verify_review_order()
    check.is_in(get_data("estimatedPrice"), get_element_text(estimated_cost_text), "Estimated cost")
    validate_bom_review_order_page()
    click_submit_order()
    order_no = get_order_id()
    check.equal(get_element_text(total_estimated_cost_text).strip(), get_data("TotalCost"), "Total cost")
    click_on_goto_service_catalog_btn()
    # Navigate to Orders History page
    open_order_history_page()
    wait_for_order_history_page_to_load()
    search_order_in_history(order_no)
    service_names_list = get_all_rows_service_names()
    check.equal(service_names_list[0], service_name, "Service name")
    click_on_order_details_link()
    click_on_order_updates_tab()
    check.equal(get_approval_status_from_order_updates(mo_ui_test_data["technicalApprovalLabel"]),
                                                        mo_ui_test_data["approveStatusPending"], "Technical Approval status")
    check.equal(get_approval_status_from_order_updates(mo_ui_test_data["financialApprovalLabel"]),
                                                        mo_ui_test_data["approveStatusPending"], "Financial Approval status")
    close_order_details_slider_window()
    # Cancel the order
    search_order_cancel_and_validate_messages(order_no)
    wait_for_order_history_page_to_load()
    select_status_from_orders_status_dropdown(mo_ui_test_data["canceledState"])
    search_order_in_history(order_no)
    validate_order_status_and_color(mo_ui_test_data["canceledState"], mo_ui_test_data["rejectedOrderColor"])
    
    # Validate existing Completed Order details
    search_order_in_history(mo_ui_test_data["completedServiceName"])
    wait_for_order_history_page_to_load()
    select_status_from_orders_status_dropdown(mo_ui_test_data["completedState"])
    validate_order_status_and_color(mo_ui_test_data["completedState"], mo_ui_test_data["completedOrderColor"])
    click_on_order_details_link()
    validate_order_details_tab_info(mo_ui_test_data["completedState"])
    validate_order_updates_tab_info()
    validate_approval_details_using_order_status(mo_ui_test_data["completedState"])
    close_order_details_slider_window()


def test_verify_service_details_on_ordered_services():
    """ Hill - 18: App Developer: Verify order details on Ordered services page """

    set_data_path(lamp_stack_test_data)
    # Navigate to Ordered services page and click on View details
    validate_service_details_ordered_services(mo_ui_test_data["completedServiceName"])
    # Validate order history tab
    validate_order_history_tab(mo_ui_test_data["completedServiceName"])
    # Validate access component message
    validate_access_component_text(mo_ui_test_data["completedServiceName"], get_data("componentType"))
    # Validate EC2 header text from view component
    header_text = get_ec2_url_header_text_from_view_component(mo_ui_test_data["completedServiceName"], get_data("componentType"))
    check.is_in(mo_ui_test_data["ec2ServerMsg"], header_text, "EC2 Server URL's header text")
    