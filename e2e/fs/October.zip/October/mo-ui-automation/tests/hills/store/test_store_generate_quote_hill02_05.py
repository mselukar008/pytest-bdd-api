from locators.common.launchpad_page_locator import common_tasks_text, applications_text, knowledge_center_text
from locators.ecam.drg_locator import notification_msg_text
from pages.common.launchpad_page import verify_home_page
from pages.common.login_page import load_base_page
from pages.store.navigation_page import *
from pages.store.quotes_page import *
from pages.store.review_order_page import *
from tests.common_test import get_random_int, logout_and_login

aws_data_path = os.path.join(hills_store_test_data_path, "aws", "lamp_stack_single_ec2_quote.json")


def test_generate_a_quote():
    load_base_page(tenant)
    verify_home_page()
    """Hill 02.05 - Generate a Quote, estimate the order of new service"""
    # Verify the services for Multicloud management portal
    check.is_true(is_element_present(common_tasks_text, "Common Tasks"), "Common Tasks")
    check.is_true(is_element_present(applications_text, "Applications"), "Applications")
    check.is_true(is_element_present(knowledge_center_text, "Knowledge Center"), "Knowledge Center")

    # Generate quote
    quote_item_name = get_random_int("HillsAutoQuoteItem")
    quote_name = get_random_int("HillsAutoQuoteName")
    modify_param = {"Quote Item Name": quote_item_name, "Quote Name": quote_name}
    modify_parameter(modify_param)
    open_catalog_page()
    select_service_menu(aws_data_path)
    click_on_generate_quote()
    fill_order_details()
    verify_review_order()
    check.is_in(get_data("estimatedPrice"), get_element_text(estimated_cost_text), "Estimated cost")
    click_add_to_quote()
    check.is_in(get_element_text(notification_msg_text), get_data("quote_created_message"), "Success message")

    # Edit service parameters of a quote
    set_data_path(aws_data_path)
    open_quotes_page()
    switch_to_default_content_iframe()
    verify_new_quote(quote_name)
    check.equal(get_quote_status(quote_name), get_data("quote_draft_state"), "Quote Status")
    view_details(quote_name)
    edit_quote_item()
    fill_edit_order_details(aws_data_path)
    click_save()
    open_quotes_page()
    view_details(quote_name)
    verify_service_details()

    # Move to review
    move_to_review(quote_name)
    check.is_in(get_element_text(notification_msg_text), get_data("review_success_message"), "Success message")
    explicit_wait(2)
    check.equal(get_quote_status(quote_name), get_data("quote_review_state"), "Quote Status")

    # Move to ready
    move_to_ready(quote_name)
    check.is_in(get_element_text(notification_msg_text), get_data("ready_success_message"), "Success message")
    explicit_wait(2)
    check.equal(get_quote_status(quote_name), get_data("quote_ready_state"), "Quote Status")

    # Make inactive
    make_inactive(quote_name)
    check.is_in(get_element_text(notification_msg_text), get_data("inactive_success_message"), "Success message")
    explicit_wait(2)
    check.equal(get_quote_status(quote_name), get_data("quote_inactive_state"), "Quote Status")

    # Delete
    delete_quote(quote_name)
    check.is_in(get_element_text(notification_msg_text), get_data("delete_success_message"), "Success message")





