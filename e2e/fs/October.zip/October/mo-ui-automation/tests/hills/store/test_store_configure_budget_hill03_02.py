from helpers.mo_json_utils import *
from pages.store.budget_page import *
from pages.store.navigation_page import *
from tests.common_test import *

budget_json_data = os.path.join(hills_test_data_path, "budget", "budgetary_unit_budget_data.json")


def test_configure_and_modify_budget():
    """Hill 03.02 - Configure and Modify Budget"""

    load_base_page(tenant)
    # Logout and logged in using "Jane"
    jane_user = users_data["financial_user"]
    logout_and_login(jane_user)

    budgetary_unit_name = get_random_int('HillsAutoBU')
    start_month = get_full_name_month_using_index(0)
    start_year = get_full_year_using_index(0)
    modify_param = {"Budgetary Unit": budgetary_unit_name, "Budgetary Unit Identifier": budgetary_unit_name,
                    "Entity Value": "budgetTEAM1 (budgetORG)", "Start Month": start_month, "Start Year": start_year,
                    "Notify When Soft Quota reached": ["budgetTEAM1 (budgetORG)"],
                    "Notify When Hard Quota reached": ["budgetTEAM1 (budgetORG)"]}
    modify_parameter(modify_param)

    # Configure Budgetary Unit
    open_budget_management()
    set_data_path(budget_json_data)
    add_new_budgetary_unit_and_goto_define_budgets()

    # Define Budget
    define_budget_set_in_bu(get_data("totalBudgetAmount"))
    click_slider_budgets_tab()
    wait_for_budgets_table_to_load()
    show_all_budgets_using_pagination()
    check.is_true(validate_budgets_created_budget_amount(get_data("totalBudgetAmount")))

    # Edit Budget
    edit_budget()
    validate_budget_details(is_editing=True)
    # Close Budget slider
    close_budget_slider()
    # Close BU slider
    close_budget_slider()

    # Delete Budgetary Unit
    delete_budgetary_unit(budgetary_unit_name)
