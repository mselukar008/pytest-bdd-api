import pytest
from pages.common.login_page import load_base_page
from pages.store.approve_order_page import *
from pages.store.navigation_page import *
from tests.common_test import logout_and_login


dynamic_values_testdata = os.path.join(hills_test_data_path, "dynamic_values.json")

def test_complete_technical_approval_process():
    """ Hill 07.01 - Dev and Budget Manager: Technical Approval """
    
    load_base_page(tenant)
    set_data_path(dynamic_values_testdata)
    order_no = get_data("OrderId")
    service_name = get_data("ServiceName")

    if order_no != "":
        # Logout and logged in using "Roman"
        roman_user = users_data["technical_user"]
        logout_and_login(roman_user)
        open_approve_orders_page()
        search_order_in_approve(order_no)
        wait_for_order_present(order_no)
        # Validate searched order number link text to be match with from submit order popup
        assert get_first_order_id_link_text() == order_no
        validate_service_names(service_name)
        click_approve_btn()
        # Validate order approval flow popup header
        check.equal(get_order_approval_flow_popup_table_header_text(), mo_ui_test_data["approvalOrderFlowPopupHeaderText"])
        approve_order_technical_financial(TECHNICAL_APPROVER)
        # Validate approve order success message
        check.equal(get_order_success_msg_text(), mo_ui_test_data["approveOrderSuccessMsgText"])
        click_modal_approval_ok()
    else:
        raise pytest.skip("Order is not created in Hill 02.01")
