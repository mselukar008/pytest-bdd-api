from conftest import get_env_url
from locators.common.launchpad_page_locator import *
from pages.ecam.costs_page import *
from pages.ecam.drg_page import *
from pages.store.navigation_page import *
from pages.store.pricing_management_page import *
from tests.common_test import *
from ui_config import *
from helpers.mo_check import mo_check as check

drg_data_path = os.path.join(hills_ecam_test_data_path, "drg_page.json")
pricing_policy_data_path = os.path.join(hills_test_data_path, "pricing_management", "pricing_management.json")
cost_asset_data_path = os.path.join(hills_ecam_test_data_path, "costs_assets_page.json")
pricing_policy_name = ""
drg_name = ""


def test_create_upcharge_pricing_policy():
    """ Hill 03.07 - Billing Analyst: Create Upcharge Pricing Rule """
    global pricing_policy_name
    load_base_page(hills_unrestricted_tenant)
    # Logout and logged in using "CT Marshall"
    charlotte_user = users_data["kyn_user"]
    logout_and_login(charlotte_user, hills_unrestricted_tenant)
    pricing_policy_name = get_random_int('Hills-Auto-Upcharge-Pricing-Policy-')
    pricing_rule_name = get_random_int("HillsUpchargePricingRule")
    # Navigate to Pricing Management page
    open_pricing_management()
    # Validate user is landed on Pricing Management Page
    set_data_path(pricing_policy_data_path)
    check.equal(get_pricing_management_header_title_text(), get_data("headerTitleText"),
                "Pricing Management Page title text")
    modify_param = {'Policy Name': pricing_policy_name, 'Rule Name': pricing_rule_name}
    modify_parameter(modify_param)
    add_new_policy()
    select_start_date()
    fill_pricing_policy_details(pricing_policy_data_path)
    save_pricing_policy()
    check.equal(get_element_text(policy_success_txt), get_data("policyCreateSuccessTxt"),
                'Policy Create Success Notification Text')
    check.equal(get_element_text(policy_success_msg), get_data("policyCreateSuccessMsg"),
                'Policy Create Success Message')

    # search pricing policy in table
    search_pricing_policy(pricing_policy_name)
    verify_pricing_policy_details(pricing_policy_name, get_data("pricingPolicyStatusInactive"))

    # Activate the just created policy
    click_pricing_policy_hamburger_icon(pricing_policy_name)
    click_pricing_policy_actions(pricing_policy_name, "Activate")
    check.equal(get_element_text(policy_success_txt), get_data("policyCreateSuccessTxt"),
                'Policy Update Success Notification Text')
    check.equal(get_element_text(policy_success_msg), get_data("policyUpdateSuccessMsg"),
                'Policy Update Success Message')
    verify_pricing_policy_details(pricing_policy_name, get_data("pricingPolicyStatusActive"))

    # Open above pricing policy and validate all fields
    click_pricing_policy_hamburger_icon(pricing_policy_name)
    click_pricing_policy_actions(pricing_policy_name, "View Details")
    check.equal(get_element_text(view_policy_header_title), get_data("viewPolicyTitleText"), 'View a Policy')
    validate_basic_information_details(pricing_policy_name)
    validate_tag_details()
    validate_upcharge_pricing_rules(pricing_rule_name)


def test_configure_drg_dynamic_tag():
    """Hill 03.11 - Configure Dynamic Resource Group and Dynamic tag"""
    global drg_name
    load_base_page(hills_unrestricted_tenant)
    # Logout and logged in using "Marshall"
    marshall_user = users_data["financial_user"]
    logout_and_login(marshall_user, hills_unrestricted_tenant)

    # Verify the services for Multicloud management portal
    check.is_true(is_element_present(common_tasks_text, "Common Tasks"), "Common Tasks")
    check.is_true(is_element_present(applications_text, "Applications"), "Applications")
    check.is_true(is_element_present(knowledge_center_text, "Knowledge Center"), "Knowledge Center")

    # Create new DRG
    drg_name = get_random_int("HillDRGAuto")
    dynamic_key = get_random_int("HillAuto")
    dynamic_value = 20
    set_data_path(drg_data_path)
    open_drg_page()
    click_on_create_new_btn()
    select_drg_type(get_data("typeVisibility"))
    add_dynamic_tag(dynamic_key, dynamic_value)
    enter_drg_name(drg_name)
    click_on_next_btn()
    select_team_in_associate_context(get_data("teamPricing"))
    click_on_next_btn()
    wait_for_spinner_off()
    click_on_filters_button()
    select_provider_from_filters(get_data("providerName"))
    select_provider_tag_from_filters(get_data("tagKey"), get_data("tagValue"))
    click_on_apply_filters_button()
    wait_for_spinner_off()
    click_bar_chart_using_month(get_data("currentMonthIndex"))
    wait_for_spinner_off()
    check.is_true(is_element_present(table_line_items, "Table line items"), 'Table line items')
    click_on_next_btn()

    # Validate all on review page
    wait_for_spinner_off()
    check.equal(get_element_text(review_page_drg_type_text).lower(), get_data("typeVisibility"), "DRG Type")
    tag = dynamic_key + "~" + str(dynamic_value)
    check.equal(get_element_text(review_page_dynamic_tags_text), tag, "Dynamic Tag")
    check.equal(get_element_text(review_page_drg_name_text).strip(), drg_name, "DRG Name")
    check.is_in(get_element_text(review_page_context_text), get_data("teamPricing"), "DRG Context")
    check.equal(get_element_text(review_page_provider_text), get_data("providerName"), "Provider")
    check.is_in(get_element_text(review_page_provider_tag_text), get_data("tagKey"), "Provider Tag")
    check.is_true(verify_filter_set_table_for_provider(get_data("filterSetProvider")), "Provider in Filter set")
    check.is_true(verify_filter_set_table_for_tag(get_data("tagKey")), "Tag in Filter set")
    click_on_save_btn()
    assert get_data("drgSuccessMessage") in get_element_text(notification_msg_text)
    explicit_wait(5)

    # Open above DRG and validate all fields
    open_drg(drg_name)
    check.equal(get_element_text(review_page_drg_type_text).lower(), get_data("typeVisibility"), "DRG Type")
    tag = dynamic_key + "~" + str(dynamic_value)
    check.equal(get_element_text(review_page_dynamic_tags_text), tag, "Dynamic Tag")
    check.equal(get_element_text(review_page_drg_name_text).strip(), drg_name, "DRG Name")
    check.is_in(get_element_text(review_page_context_text), get_data("teamPricing"), "DRG Context")
    check.equal(get_element_text(review_page_provider_text), get_data("providerName"), "Provider")
    check.is_in(get_element_text(review_page_provider_tag_text), get_data("tagKey"), "Provider Tag")
    check.is_true(verify_filter_set_table_for_provider(get_data("filterSetProvider")), "Provider in Filter set")
    check.is_true(verify_filter_set_table_for_tag(get_data("tagKey")), "Tag in Filter set")


def test_pricing_policy_on_costs_page():
    """ 03.07 Customer Tenant Charlotte, the customer financial analyst, can only see the customer retail cost,
    with customer specific price rules applied """
    load_base_page(hills_unrestricted_tenant)
    # Logout and logged in using "Charlotte" user
    charlotte_user = users_data["kyn_user"]
    logout_and_login(charlotte_user, hills_unrestricted_tenant)
    set_data_path(cost_asset_data_path)
    open_costs_page()
    # Validate user is landed on Costs Dashboard
    check.equal(get_costs_header_title_text(), get_data("costsHeaderTitleText"), 'Cost Header')
    # Click on current month
    click_costs_bar_chart_using_month(get_data("currentMonthIndex"))
    select_drg_from_data_set_filters(drg_name)
    click_on_filters_button()
    set_data_path(drg_data_path)
    select_provider_tag_from_filters(get_data("tagKey"), get_data("tagValue"))
    click_on_apply_filters_button()
    wait_for_to_load_costs_page()
    set_data_path(cost_asset_data_path)
    if download_line_items_from_table(get_data("formatType"), apply_pricing=True):
        download_report_from_notification()
        # Validate if file is downloaded or not
        check.is_true(is_downloaded_file_exists(), 'File downloaded')


def test_clean_up_resources():
    """ Hill 03.03 - IT Finance Manager: deactivate pricing policy and delete it, delete the DRG created"""
    load_base_page(hills_unrestricted_tenant)
    # Logout and logged in using 'admin' user
    admin_user = users_data["main_user"]
    logout_and_login(admin_user, hills_unrestricted_tenant)

    # Deactivate pricing policy
    open_pricing_management()
    set_data_path(pricing_policy_data_path)
    search_pricing_policy(pricing_policy_name)
    click_pricing_policy_hamburger_icon(pricing_policy_name)
    click_pricing_policy_actions(pricing_policy_name, "Deactivate")
    check.equal(get_element_text(policy_success_txt), get_data("policyCreateSuccessTxt"),
                'Policy Update Success Notification Text')
    check.equal(get_element_text(policy_success_msg), get_data("policyUpdateSuccessMsg"),
                'Policy Update Success Message')
    verify_pricing_policy_details(pricing_policy_name, get_data("pricingPolicyStatusInactive"))

    # Delete pricing policy
    search_pricing_policy(pricing_policy_name)
    click_pricing_policy_hamburger_icon(pricing_policy_name)
    click_pricing_policy_actions(pricing_policy_name, "Delete")
    click(delete_pricing_policy_ok_button, "Delete Policy OK Button")
    check.equal(get_element_text(policy_success_txt), get_data("policyCreateSuccessTxt"),
                'Policy Delete Success Notification Text')
    check.equal(get_element_text(policy_success_msg), get_data("policyDeleteSuccessMsg"),
                'Policy Delete Success Message')

    # Delete created DRG
    open_drg_page()
    wait_for_to_load_drg_page()
    set_data_path(drg_data_path)
    delete_drg(drg_name)
