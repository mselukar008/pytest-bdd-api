from helpers.mo_json_utils import *
from pages.store.budget_page import *
from pages.store.navigation_page import *
from tests.common_test import *

budget_json_data = os.path.join(hills_test_data_path, "budget", "budgetary_unit_budget_data.json")
dynamic_values_testdata = os.path.join(hills_test_data_path, "dynamic_values.json")


def test_add_new_budgetary_unit_and_budgets():
    """ Hill 12.02 - IT Finance Manager: Define Budgetary unit and Budgets """

    load_base_page(tenant)
    # Logout and logged in using "Jane"
    jane_user = users_data["financial_user"]
    logout_and_login(jane_user)

    budgetary_unit_name = get_random_int('HillsAutoBU')
    start_month = get_full_name_month_using_index(0)
    start_year = get_full_year_using_index(0)
    modify_param = {"Name": budgetary_unit_name, "Budgetary Unit Identifier": budgetary_unit_name,
                    "Start Month": start_month, "Start Year": start_year}
    modify_parameter(modify_param)
    # Navigate to Budget Management page
    open_budget_management()
    set_data_path(budget_json_data)
    add_new_budgetary_unit_and_goto_define_budgets()
    # Update Budgetary unit name in the json
    update_json_file_single_value(dynamic_values_testdata, "BudgetaryUnitName", budgetary_unit_name)
    define_budget_set_in_bu(get_data("totalBudgetAmount"))
    click_slider_budgets_tab()
    wait_for_budgets_table_to_load()
    show_all_budgets_using_pagination()
    # Validate created budget amount should be as expected
    check.is_true(validate_budgets_created_budget_amount(get_data("totalBudgetAmount")))
    # Close budget slider
    close_budget_slider()
