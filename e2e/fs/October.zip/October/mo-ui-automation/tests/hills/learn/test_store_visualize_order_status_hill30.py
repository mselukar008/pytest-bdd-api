from pages.common.login_page import load_base_page
from pages.store.navigation_page import *
from locators.store.order_history_locator import *
from pages.store.order_history_page import *


def test_visualize_order_status():
    """ Hill 30 - App Developer: Visualize Order Status """
    load_base_page(tenant)
    open_order_history_page()
    wait_for_order_history_page_to_load()
    # Validate page header title to be Order History
    check.equal(get_element_text(order_history_title_text), mo_ui_test_data["orderHistoryLinkText"])
    # Validate Completed, Approval in Progress and Rejected orders searched by using service name
    service_names = [mo_ui_test_data["pendingServiceName"], mo_ui_test_data["rejectedServiceName"], mo_ui_test_data["completedServiceName"]]
    validate_service_names_in_searched_results(service_names)

    # Validate Approval In Progress Order details
    search_order_in_history(mo_ui_test_data["pendingServiceName"])
    select_status_from_orders_status_dropdown(mo_ui_test_data["approvalInProgState"])
    validate_order_status_and_color(mo_ui_test_data["approvalInProgState"], mo_ui_test_data["approvalInProgOrderColor"])
    click_on_order_details_link()
    validate_order_details_tab_info(mo_ui_test_data["approvalInProgState"])
    validate_order_updates_tab_info()
    validate_approval_details_using_order_status(mo_ui_test_data["approvalInProgState"])
    close_order_details_slider_window()

    # Validate Rejected Order details
    search_order_in_history(mo_ui_test_data["rejectedServiceName"])
    select_status_from_orders_status_dropdown(mo_ui_test_data["approveStatusRejected"])
    validate_order_status_and_color(mo_ui_test_data["approveStatusRejected"], mo_ui_test_data["rejectedOrderColor"])
    click_on_order_details_link()
    validate_order_details_tab_info(mo_ui_test_data["approveStatusRejected"])
    validate_order_updates_tab_info()
    validate_approval_details_using_order_status(mo_ui_test_data["approveStatusRejected"])
    close_order_details_slider_window()

    # Validate Completed Order details
    search_order_in_history(mo_ui_test_data["completedServiceName"])
    select_status_from_orders_status_dropdown(mo_ui_test_data["completedState"])
    validate_order_status_and_color(mo_ui_test_data["completedState"], mo_ui_test_data["completedOrderColor"])
    click_on_order_details_link()
    validate_order_details_tab_info(mo_ui_test_data["completedState"])
    validate_order_updates_tab_info()
    validate_approval_details_using_order_status(mo_ui_test_data["completedState"])
    close_order_details_slider_window()
    