import time

from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_exception_utils import exceptions_decorator
from helpers.mo_json_utils import *
from helpers.mo_page_operations import wait_for_spinner_on, wait_for_spinner_off_with_timer
from locators.landingzone.landing_zone_dashboard_locator import *
from locators.store.catalog_page_locator import *
from helpers.mo_check import mo_check as check
from locators.store.review_order_locator import next_btn_path
from pages.store.order_parameters_page import fill_order_parameter, go_next_or_previous_in_order_page, click_next_btn
from pages.store.mo_store_utils import get_filtered_data, merge_imi_additional_parameters
from locators.landingzone.landing_zone_catalog_locator import *
from pages.store.review_order_page import convert_string
from datetime import datetime


def fill_account_order_details(path=None, expiring=False):
    if path:
        set_data_path(path)
    fill_catalog_account_details(get_data("Request Detail"))
    fill_tags_details(get_data("Tag"))
    fill_catalog_service_control_policy_details(get_data("Service Control Policy"))
    attach_detach_additional_policies(get_data("Additional Policy"))
    if expiring:
        fill_catalog_budget_details(get_data("Expiring Budget Detail"))
    else:
        fill_catalog_budget_details(get_data("Budget Detail"))
    fill_alert_actions_details(get_data("Alert Action"))
    attach_detach_budget_policies(get_data("Budget Policy"))


def fill_user_request_details(path=None, expiring=False):
    if path:
        set_data_path(path)
    fill_user_catalog_request_details(get_data("Request Detail"))
    fill_user_catalog_request_details(get_data("AWS Access Detail"), use_next_button=True)
    fill_set_permissions_details(get_data("Permission Detail"))
    fill_set_permissions_details(get_data("Service Control Policy"), use_next_button=True)
    check.equal(get_element_text(default_policy_user), get_data("DefaultRootPolicy"), "Check Default Policy Exists")
    fill_set_permissions_details(get_data("Additional Policy"), use_next_button=True)
    fill_tags_details(get_data("Tag"))


def fill_catalog_account_details(account_details):
    fill_order_parameter(account_details, use_next_button=False)

def fill_user_catalog_request_details(user_details, use_next_button=False):
    fill_order_parameter(user_details, use_next_button)


def fill_tags_details(tags):
    fill_order_parameter(tags)

def fill_set_permissions_details(permissions,use_next_button=False):
    if is_element_present(set_permissions_text, "Set Permissions"):
        fill_order_parameter(permissions, use_next_button)

def fill_catalog_service_control_policy_details(scp_details):
    if is_element_present(service_control_policy_label, "SCP Label"):
        check.equal(get_element_text(root_default_policy), get_data("DefaultRootPolicy"), "Check Default Policy Exists")
    if is_element_present(attach_policy_label, "Attach Policy Label"):
        fill_order_parameter(scp_details)


def attach_detach_additional_policies(additional_policy):
    fill_order_parameter(additional_policy)


def fill_catalog_budget_details(budget_details):
    fill_order_parameter(budget_details, use_next_button=False)


def fill_alert_actions_details(alert_actions):
    fill_order_parameter(alert_actions, use_next_button=False)


def attach_detach_budget_policies(budget_policy):
    fill_order_parameter(budget_policy)


def click_submit_request():
    toast_intercept = is_element_present(toast_banner, "Notification Toast")
    if not toast_intercept:
        wait_before_click(submit_request_btn, "Submit Request button")
        wait_before_click(submit_modal_btn, "Submit Modal Button")
    else:
        wait_for_element_to_invisible(toast_banner, "Notification Toast")
        wait_before_click(submit_request_btn, "Submit Request button")
        wait_before_click(submit_modal_btn, "Submit Modal Button")

def attach_detach_policy_in_catalog(attach=True, detach=True):
    # Create a dictionary that maps each policy name to its corresponding value
    policy_values = {
        "StronglyRecommendedGuardrails": "DisallowActionsAsRoot",
        "MandatoryGuardrails": "CloudTrailDisallowConfigurationChangesForCt",
        "ElectiveGuardrails": "S3DisallowChangesToBucketPolicy",
        "DenyAll": "AccountsPreventAccountsFromLeavingTheOrg",
        "CustomPolicies": "DisallowCreationOfAccessKeyForRootz"
    }
    # Attach policies for each tab
    if attach:
        for curated_policy_name, policy_value in policy_values.items():
            if curated_policy_name == "StronglyRecommendedGuardrails":
                attach_policy_values_for_curated_policies(strongly_recommended_guardrails_tab, policy_value,
                                                          curated_policy_name)
            elif curated_policy_name == "MandatoryGuardrails":
                attach_policy_values_for_curated_policies(mandatory_guardrails_tab, policy_value, curated_policy_name)
            elif curated_policy_name == "ElectiveGuardrails":
                attach_policy_values_for_curated_policies(elective_guardrails_tab, policy_value, curated_policy_name)
            elif curated_policy_name == "DenyAll":
                attach_policy_values_for_curated_policies(deny_all_tab, policy_value, curated_policy_name)
            elif curated_policy_name == "CustomPolicies":
                attach_policy_values_for_curated_policies(custom_policies_tab, policy_value, curated_policy_name)
            else:
                logger.info(f"Unknown policy name: {curated_policy_name}")
        if not detach:
            click_next_btn()
    # Detach policies for each tab
    if detach:
        for curated_policy_name, policy_value in policy_values.items():
            if policy_value == "AccountsPreventAccountsFromLeavingTheOrg":
                detach_policy_from_table(policy_value)
            elif policy_value == "DisallowCreationOfAccessKeyForRootz":
                detach_policy_from_table(policy_value)
            else:
                logger.info(f"Policies not required to Detach: {policy_value}")
        click_next_btn()


def attach_policy_values_for_curated_policies(curated_policy_locator, policy_value, tab_name):
    click_using_java_script(curated_policy_locator, tab_name)
    click_using_java_script(search_additional_policy_button, "Search for policy")
    type_value_and_enter(additional_policy_input_text, policy_value, policy_value)
    wait_for_element_to_visible_with_replace_value(policy_name_in_table, policy_value, policy_value)
    wait_before_click(attach_button, "Attach Button")


def detach_policy_from_table(policy_value):
    click_using_java_script(search_service_policy_button, "Search for Policy")
    type_value_and_enter(service_policy_input_text_box, policy_value, policy_value)
    wait_for_element_to_visible_with_replace_value(policy_name_in_table, policy_value, policy_value)
    wait_before_click(detach_button, "Detach Button")
    click_using_java_script(clear_search_for_new_policy, "Clear Search Box")


def verify_landing_zone_review_order_page(expiring=False, for_user=False):
    json_value = "value"
    account_details_param_ui_data = dict(
        zip(get_elements_texts(account_details_params), get_elements_texts(account_details_params_values)))
    # Account Details Parameters Validations
    account_details_param_json_dic_data = get_data("Request Details", get_data("Request Detail"))
    for key, value in account_details_param_ui_data.items():
        if get_json_data_key(key, account_details_param_json_dic_data) is not None:
            actual_data = get_data(json_value, get_json_data_key(key, account_details_param_json_dic_data))
            if actual_data == "NONE":
                actual_data = convert_string(actual_data)
            check.is_in(actual_data, value, key)

    # Verify Tags
    tags_param_ui_data = dict(
        zip(get_elements_texts(tags_details_params), get_elements_texts(tags_details_values)))
    tags_details_param_json_dic_data = get_data("Tags", get_data("Tag"))
    for key, value in tags_param_ui_data.items():
        if get_json_data_key(key, tags_details_param_json_dic_data) is not None:
            actual_data = get_data(json_value, get_json_data_key(key, tags_details_param_json_dic_data))
            if actual_data == "NONE":
                actual_data = convert_string(actual_data)
            check.is_in(actual_data, value, key)

    # verify Service Control Policies
    service_policies_ui_data = get_elements_texts(service_policies_params)
    service_policy_json_dic_data = get_data("Additional Policies", get_data("Additional Policy"))
    for key in service_policies_ui_data:
        if get_json_data_key(key, service_policy_json_dic_data) is not None:
            actual_data = get_data(json_value, get_json_data_key(key, service_policy_json_dic_data))
            if actual_data == "NONE":
                actual_data = convert_string(actual_data)
            check.is_in(actual_data, key)
    if not for_user:
        # Verify Budget Control Policy
        budget_control_policy_param_ui_data = dict(
            zip(get_elements_texts(budget_controls_params), get_elements_texts(budget_controls_params_values)))
        recurring_budget_json_data = get_data("Budget Details", get_data("Budget Detail"))
        expiring_budget_json_data = get_data("Expiring Budget Details", get_data("Expiring Budget Detail"))
        budget_control_policy_param_json_data = expiring_budget_json_data if expiring else recurring_budget_json_data
        for key, value in budget_control_policy_param_ui_data.items():
            if get_json_data_key(key, budget_control_policy_param_json_data) is not None:
                actual_data = get_data(json_value, get_json_data_key(key, budget_control_policy_param_json_data))
                if actual_data == "NONE":
                    actual_data = convert_string(actual_data)
                check.is_in(actual_data, value, key)

        # Verify Alert Actions
        alert_actions_param_ui_data = dict(
            zip(get_elements_texts(alerts_params), get_elements_texts(alerts_params_values)))
        alert_actions_param_json_data = get_data("Alert Actions", get_data("Alert Action"))
        for key, value in alert_actions_param_ui_data.items():
            if get_json_data_key(key, alert_actions_param_json_data) is not None:
                actual_data = get_data(json_value, get_json_data_key(key, alert_actions_param_json_data))
                if actual_data == "NONE":
                    actual_data = convert_string(actual_data)
                check.is_in(actual_data, value, key)

        # Budget Policies
        budget_policies_ui_data = get_elements_texts(budget_polices_params)
        budget_policy_json_dic_data = get_data("Budget Policies", get_data("Budget Policy"))
        for key in budget_policies_ui_data:
            if get_json_data_key(key, budget_policy_json_dic_data) is not None:
                actual_data = get_data(json_value, get_json_data_key(key, budget_policy_json_dic_data))
                if actual_data == "NONE":
                    actual_data = convert_string(actual_data)
                check.is_in(actual_data, key)


def remove_leading_zero(day_or_hour_str):
    if day_or_hour_str.startswith("0"):
        return day_or_hour_str[1:]
    return day_or_hour_str


def get_current_date():
    current_date = datetime.now()
    month = current_date.strftime("%b")
    day = remove_leading_zero(current_date.strftime("%d"))
    year = current_date.strftime("%Y")
    formatted_date = f"{month} {day}, {year}"
    logger.info("Submission Date: " + formatted_date)
    return formatted_date.strip()


def get_current_time():
    current_time = datetime.now()
    hour = remove_leading_zero(current_time.strftime("%I"))
    minute = current_time.strftime("%M")
    second = current_time.strftime("%S")
    am_pm = current_time.strftime("%p")
    formatted_time = f"{hour}:{minute}:{second} {am_pm}"
    logger.info("The current Time :" + formatted_time)
    return formatted_time
