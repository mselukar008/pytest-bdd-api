from pages.landingzone.landing_zone_catalog_page import *
from pages.store.navigation_page import *
from locators.landingzone.landing_zone_dashboard_locator import *
from pages.store.review_order_page import convert_string


def validate_request_details_in_export_icon(pending_approval=True, expiring=False, for_user=False):
    if pending_approval:
        ui_date_time = get_element_text(pending_last_service_card_date_time)
        if check_date_and_time(ui_date_time):
            scroll_element_into_view(pending_export_icon_last_card)
            click(pending_export_icon_last_card, "Export Icon")
            verify_landing_zone_review_order_page(expiring, for_user)
            click_back_button()
    else:
        ui_date_time = get_element_text(last_service_card_date_time)
        if check_date_and_time(ui_date_time):
            scroll_element_into_view(export_icon_last_card)
            click(export_icon_last_card, "Export Icon")
            verify_landing_zone_review_order_page(expiring, for_user)
            click_back_button()


def check_date_and_time(ui_date_time):
    date_data = get_current_date()
    # time_data = get_current_time()

    if not check.is_in(date_data, ui_date_time, f"Expected date_data: {date_data} to be contained in: {ui_date_time}"):
        logger.info("Incorrect Date in service card")
        return False
    else:
        logger.info("Correct Date in service card, Proceed to Approve")
        return True


def click_back_button():
    wait_for_spinner_off()
    if check_element_exists(back_button):
        wait_for_element_clickable(back_button, "Back button")
        click_using_script(back_button, "Back button")
    else:
        logger.info("Back button is not present")


def approve_account_request_in_landing_zone_dashboard():
    scroll_element_into_view(approve_last_request)
    click_using_java_script(approve_last_request, "Approve Button")
    click_using_java_script(approve_modal_button, "Approve's OK Modal")
    click_checkbox(approved_request_checkbox, "true", "Show Approved Requests")
    wait_for_spinner_off()
    wait_for_element_to_visible(approve_text_visible, "Approved Label in Card")
    logger.info("The Request is successfully Approved")


def deny_account_request_in_landing_zone_dashboard():
    scroll_element_into_view(deny_last_request)
    click_using_java_script(deny_last_request, "Deny Button")
    click_using_java_script(deny_modal_button, "Deny's OK Modal")
    click_checkbox(deny_request_checkbox, "true", "Show Approved Requests")
    wait_for_spinner_off()
    wait_for_element_to_visible(denied_text_visible, "Denied Label in Card")
    logger.info("The Request is successfully Denied")


def validate_service_card_details(date_time, pending_approval=True, expiring=False, for_user=False):
    wait_for_spinner_off()
    if pending_approval:
        open_view_and_approve_request_tab_in_dashboard()
    request_for_card_details_locator = pending_request_for_card_details if pending_approval else request_for_card_details
    requestor_card_details_locator = pending_requestor_card_details if pending_approval else requestor_card_details
    owner_card_details_locator = pending_owner_card_details if pending_approval else owner_card_details
    project_card_details_locator = pending_project_card_details if pending_approval else project_card_details
    requested_policies_card_details_locator = pending_requested_policies_card_details if pending_approval else requested_policies_card_details
    budget_card_details_locator = pending_budget_card_details if pending_approval else budget_card_details
    requested_duration_card_locator = pending_requested_duration_card_details if pending_approval else requested_duration_card_details
    threshold_card_details_locator = pending_threshold_card_details if pending_approval else threshold_card_details
    budget_policies_card_details_locator = pending_budget_policies_card_details if pending_approval else budget_policies_card_details
    date_time_locator = pending_last_service_card_date_time if pending_approval else last_service_card_date_time
    if for_user:
        # Verify Request for card details
        request_for_card_details_ui_data = scroll_and_get_text_with_replace_value(request_for_card_details_locator,
                                                                                  get_data("bluePrintName"),
                                                                                  "Blueprint Name")
        request_for_card_details_json_data = get_data("bluePrintName")
        check_card_details(request_for_card_details_ui_data, request_for_card_details_json_data, "Blueprint Name")

        # Check Requestor Card Details
        requestor_card_details_ui_data = scroll_and_get_element_text(requestor_card_details_locator)
        requestor_card_details_json_data = get_value(get_data_object("Request Detail"),
                                                     "Email address of the account's owner")
        check_card_details(requestor_card_details_ui_data, requestor_card_details_json_data, "Email of Account Owner")

        # Check Owner Card Details
        owner_card_details_ui_data = scroll_and_get_element_text(owner_card_details_locator)
        owner_card_details_json_data = get_value(get_data_object("Request Detail"),
                                                 "Email address of the account's owner")
        check_card_details(owner_card_details_ui_data, owner_card_details_json_data, "Owner Details")

        # Verify Project details card
        project_details_card_ui_data = scroll_and_get_text_with_replace_value(project_card_details_locator,
                                                                              get_data("project"), "Project Details")
        project_details_card_json_data = get_data("project")
        check_card_details(project_details_card_ui_data, project_details_card_json_data, "Project Details")

        # Verify Service Control Policies
        service_policies_ui_data = get_elements_texts(requested_policies_card_details_locator)
        service_policy_json_dic_data = get_data("Additional Policies", get_data("Additional Policy"))
        check_policies(service_policies_ui_data, service_policy_json_dic_data)

        #  Verify Date Time
        service_card_date_time_ui_data = scroll_and_get_element_text(date_time_locator)
        check_card_details(service_card_date_time_ui_data, date_time, " Requested Date")
    else:
        # Verify Request for card details
        request_for_card_details_ui_data = scroll_and_get_text_with_replace_value(request_for_card_details_locator,
                                                                                  get_data("bluePrintName"),
                                                                                  "Blueprint Name")
        request_for_card_details_json_data = get_data("bluePrintName")
        check_card_details(request_for_card_details_ui_data, request_for_card_details_json_data, "Blueprint Name")

        # Check Requestor Card Details
        requestor_card_details_ui_data = scroll_and_get_element_text(requestor_card_details_locator)
        requestor_card_details_json_data = get_value(get_data_object("Request Detail"),
                                                     "Email address of the account's owner")
        check_card_details(requestor_card_details_ui_data, requestor_card_details_json_data, "Email of Account Owner")

        # Check Owner Card Details
        owner_card_details_ui_data = scroll_and_get_element_text(owner_card_details_locator)
        owner_card_details_json_data = get_value(get_data_object("Tag"), "owner")
        check_card_details(owner_card_details_ui_data, owner_card_details_json_data, "Owner Details")

        # Verify Project details card
        project_details_card_ui_data = scroll_and_get_text_with_replace_value(project_card_details_locator,
                                                                              get_value(get_data_object("Tag"),
                                                                                        "project"),
                                                                              "Project Details")
        project_details_card_json_data = get_value(get_data_object("Tag"), "project")
        check_card_details(project_details_card_ui_data, project_details_card_json_data, "Project Details")

        # Verify Service Control Policies
        service_policies_ui_data = get_elements_texts(requested_policies_card_details_locator)
        service_policy_json_dic_data = get_data("Additional Policies", get_data("Additional Policy"))
        check_policies(service_policies_ui_data, service_policy_json_dic_data)

        #  Verify Date Time
        service_card_date_time_ui_data = scroll_and_get_element_text(date_time_locator)
        check_card_details(service_card_date_time_ui_data, date_time, " Requested Date")

        # verify Budget card Details
        budget_service_card_ui_data = scroll_and_get_text_with_replace_value(budget_card_details_locator,
                                                                             get_value(get_data_object("Budget Detail"),
                                                                                       "Budget Amount"),
                                                                             "Budget Amount")

        budget_service_card_json_data = get_value(get_data_object("Budget Detail"), "Budget Amount")
        check_card_details(budget_service_card_ui_data, budget_service_card_json_data, "Budget Details")

        # Verify Requested Duration
        requested_duration_ui_data = scroll_and_get_text_with_replace_value(requested_duration_card_locator,
                                                                            get_value(get_data_object("Budget Detail"),
                                                                                      "Start Date"), "Start date")
        recurring_month_json_data = get_value(get_data_object("Budget Detail"), "Start Date")
        recurring_year_json_data = get_value(get_data_object("Budget Detail"), "Start Year")
        combined_recurring_month_year_data = recurring_month_json_data + " " + recurring_year_json_data
        # Expiring Budget
        expiring_start_month_json_data = get_value(get_data_object("Expiring Budget Detail"), "Start Date")
        expiring_start_year_json_data = get_value(get_data_object("Expiring Budget Detail"), "Start Year")
        expiring_month_json_data = get_value(get_data_object("Expiring Budget Detail"), "End Month")
        expiring_year_json_data = get_value(get_data_object("Expiring Budget Detail"), "End Year")
        combined_expiring_month_year_data = f"From {expiring_start_month_json_data} {expiring_start_year_json_data} to {expiring_month_json_data} {expiring_year_json_data}"
        requested_duration_month_year_json_data = combined_recurring_month_year_data if not expiring else combined_expiring_month_year_data
        check_card_details(requested_duration_ui_data, requested_duration_month_year_json_data,
                           "Requested Duration Details")

        # Threshold validation
        threshold_card_details_ui_data = scroll_and_get_text_with_replace_value(threshold_card_details_locator,
                                                                                get_value(
                                                                                    get_data_object("Alert Action"),
                                                                                    "Threshold"), "Threshold value")
        threshold_value_details_json_data = get_value(get_data_object("Alert Action"), "Threshold")
        threshold_type_details_json_data = get_value(get_data_object("Alert Action"), "Threshold Type")
        threshold_value_type = threshold_value_details_json_data + threshold_type_details_json_data
        check_card_details(threshold_card_details_ui_data, threshold_value_type,
                           "Threshold Details")
        # Verify Budget Policies
        budget_control_policy_param_ui_data = get_elements_texts(budget_policies_card_details_locator)
        budget_control_policy_param_json_data = get_data("Budget Policies", get_data("Budget Policy"))
        check_policies(budget_control_policy_param_ui_data, budget_control_policy_param_json_data)


def check_card_details(ui_data, json_data, description):
    check.is_in(ui_data, json_data, description)


def check_policies(ui_data, json_data):
    json_value = "value"
    for key in ui_data:
        if get_json_data_key(key, json_data) is not None:
            actual_data = get_data(json_value, get_json_data_key(key, json_data))
            if actual_data == "NONE":
                actual_data = convert_string(actual_data)
            check.is_in(actual_data, key)


def open_view_and_approve_request_tab_in_dashboard():
    open_landing_zone_page_menu(mo_ui_test_data["DashboardLandZoneLinktext"])
    wait_for_spinner_on()
    wait_for_spinner_off()
    wait_for_element_to_visible(view_and_approve_requests_tab, "View and Approve Requests Tab")
    wait_for_element_to_visible(iam_users_header, "View IAM Count")
    explicit_wait(3)
    click_using_java_script(view_and_approve_requests_tab, "View and Approve Requests Tab")
    # check request_for_card_details


def verify_card_details_ui_json(locator, nested_object, data_key, elem_name):
    ui_data = scroll_and_get_text_with_replace_value(locator, get_value(get_data_object(nested_object), data_key),
                                                     elem_name)
    json_data = get_value(get_data_object(nested_object), data_key)
    check_card_details(ui_data, json_data, elem_name)
