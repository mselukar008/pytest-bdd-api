from pages.common.mo_navigation_page import *


def open_di_develop_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["devopsIntelligenceText"])
    click_to_menu_option(mo_ui_test_data["developText"])
    wait_for_spinner_off()


def open_di_build_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["devopsIntelligenceText"])
    click_to_menu_expandable_option(mo_ui_test_data["buildText"])
    click_to_menu_option(mo_ui_test_data["buildOverviewText"])
    wait_for_spinner_off()


def open_di_test_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["devopsIntelligenceText"])
    click_to_menu_option(mo_ui_test_data["TestText"])
    wait_for_spinner_off()


def open_di_deploy_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["devopsIntelligenceText"])
    click_to_menu_option(mo_ui_test_data["deployText"])
    wait_for_spinner_off()
