from helpers.mo_element_operations import *
from helpers.mo_json_utils import *
from locators.devops.build_locator import *
from helpers.mo_check import mo_check as check
from pages.devops.common_page import get_current_date

expected_duration_num = ""


def validate_build_status():
    header = get_element_text_replace_value(tile_header_text, "1", "Tile header")
    check.equal(header, get_data("build_status_title"), "Tile header")

    check.greater(get_elements_count(bar_chart_total_builds), 0, "Total builds count")
    check.equal(get_elements_count(bar_chart_duration), 8, "Total duration count")

    current_date = get_current_date()
    check.is_not_none(get_element_text(bar_duration_current_date), "Current duration date")

    mouse_over_click(current_status_bar)
    explicit_wait(2)
    value = get_attribute_value(current_status_bar, "class")
    check.is_in(value, 'hovered', "Current date status bar")


def validate_build_success():
    header = get_element_text_replace_value(tile_header_text, "2", "Tile header")
    check.equal(header, get_data("build_success_title"), "Tile header")

    is_element_present(arc_chart, "Arc chart", stop_on_fail=True)
    pass_number = get_element_text(arc_passed_percent)
    check.is_not_none(pass_number, "Arc passed percentage")

    if float(pass_number) < 100:
        expected_failed_number = "%2.2f" % float(100 - float(pass_number))
        actual_failed_number = get_element_text(arc_failed_percent)
        str_failed_num = str(expected_failed_number)
        list_failed_num = str_failed_num.split('.')
        if int(list_failed_num[1]) > 0:
            check.equal(actual_failed_number, str(expected_failed_number) + "%", "Arc failed percentage")
        else:
            check.equal(actual_failed_number, list_failed_num[0] + "%", "Arc failed percentage")


def validate_longest_builds():
    header = get_element_text_replace_value(tile_header_text, "3", "Tile header")
    check.equal(header, get_data("longest_builds_title"), "Tile header")

    check.is_in(get_element_text(longest_builds_meter_title), get_data("develop_tech_service"), "Meter title")
    check.is_true(is_element_present(longest_builds_meter_progress, "Meter progress"), "Meter progress")
    check.is_not_none(get_element_text(longest_builds_meter_count), "Meter count")


def validate_technical_service_builds_table():
    check.equal(get_element_text(technical_service_title), get_data("service_build_title"), "Title")
    scroll_element_into_view(table_search_icon)
    click(table_search_icon, "Table search")
    type_value_and_enter(table_search_text, get_data("develop_tech_service"), "Table search textbox")
    tag_label = get_attribute_value(table_search_tag_label, "title")
    check.equal(tag_label, get_data("develop_tech_service"), "Table search tag label")

    labels = get_elements_texts(table_labels_text)
    check.equal(labels, get_data("table_labels"), "Table labels")
    data = get_elements_texts(table_data_text)
    check.equal(data[0], get_data("develop_tech_service"), "Technical Service")
    check.equal(data[1], get_data("applicationName"), "Application")
    check.is_not_none(data[2], "Build results")

    duration_num = data[3].split("s")
    expected_duration = get_element_text(longest_builds_meter_count)
    global expected_duration_num
    expected_duration_num = expected_duration.split("s")
    check.is_in(str(float(duration_num[0])), expected_duration_num[0], "Duration")

    check.equal(data[4], get_data("build_engine"), "Build engine")


def validate_build_detail_panel_details_tab():
    click(table_menu_icon, "Menu icon")
    click(view_details_option, "View Details")
    check.equal(get_element_text(build_detail_title), get_data("build_detail_title"), "Panel Title")

    click(details_tab, "Details")

    # Build status validation
    status_header = get_element_text_replace_value(details_tile_header, "1", "Status header")
    check.equal(status_header, get_data("build_status_title"), "Tile header")
    check.greater(get_elements_count_replace_value(detail_bar_charts_left_axis, get_data("build_status_title")), 0,
                  "Total builds count")
    check.equal(get_elements_count_replace_value(detail_bar_charts_bottom_axis, get_data("build_status_title")), 8,
                "Total duration count")
    current_date = get_current_date()
    check.is_not_none(get_element_text_replace_value(detail_bar_charts_current_date, get_data("build_status_title"),
                                                     "Status current date"), "Current duration date")
    mouse_over_click(detail_bar_charts_status_current_bar)
    value = get_attribute_replace_value(detail_bar_charts_status_current_bar, "class", get_data("build_status_title"),
                                        "Current bar attribute")
    check.is_in(value, 'hovered', "Current date status bar")

    # Build duration validation
    status_header = get_element_text_replace_value(details_tile_header, "2", "Status header")
    check.equal(status_header, get_data("build_duration_title"), "Tile header")
    check.greater(get_elements_count_replace_value(detail_bar_charts_left_axis, get_data("build_duration_title")), 0,
                  "Execution duration count")
    check.equal(get_elements_count_replace_value(detail_bar_charts_bottom_axis, get_data("build_duration_title")), 8,
                "Total duration count")
    current_date = get_current_date()
    check.is_not_none(get_element_text_replace_value(detail_bar_charts_current_date, get_data("build_duration_title"),
                                                     "Status current date"), "Current duration date")
    mouse_over_click(details_bar_charts_duration_current_bar)
    value = get_attribute_replace_value(details_bar_charts_duration_current_bar, "class",
                                        get_data("build_duration_title"), "Current bar attribute")
    check.is_in(value, 'hovered', "Current date status bar")


def validate_build_detail_panel_analysis_history_tab():
    click(analysis_history_tab, "Analysis history")
    check.equal(get_element_text(analysis_history_table_title), get_data("build_executions_title"),
                "History table title")

    labels = get_elements_texts(analysis_history_table_labels)
    check.equal(labels, get_data("history_table_labels"), "History table labels")
    data = get_elements_texts(analysis_history_table_data)

    check.is_not_none(data[0], "Build ID")
    check.equal(data[1], get_data("status_passed"), "Status")

    duration_num = data[2].split("s")
    check.is_in(str(float(duration_num[0])), expected_duration_num[0], "Duration")

    check.equal(data[3], get_data("build_engine"), "Build engine")

    current_date = get_current_date(start_month_name=True)
    check.is_in(data[4], current_date, "Built at")

    check.equal(data[5], get_data("build_url_text"), "Build URL")
    # Verify if build link is functional
    click_index_based(table_build_url_link, 0, "Build link")
    switch_to_new_window()
    current_url = get_current_url()
    check.is_in(current_url, get_data("jenkins_url"), "Build link URL")
    switch_to_parent_window()
