from helpers.mo_element_operations import *
from helpers.mo_json_utils import *
from locators.devops.common_locator import *
from helpers.mo_check import mo_check as check
from datetime import date

devops_data_path = os.path.join(devops_data_path, "devops_data.json")
set_data_path(devops_data_path)


def apply_application_filter(app_name):
    click(app_filter_btn, "Filter")
    click(applications_dropdown, "All applications dropdown")
    click_with_replace_value(application_name_checkbox, app_name, "Application")
    # click(filter_arrow_icon, "Arrow icon")
    click_with_replace_value(button_text, "Apply", "Apply")


def validate_header_titles():
    titles = []
    for i in range(1, 5):
        title_locator = (By.XPATH, f"(//strong[@class='header-data__item__title'])[{i}]")
        title_elem = create_wait(30).until(EC.visibility_of_element_located(title_locator))
        title_value = title_elem.text
        titles.append(title_value)
    check.equal(str(titles), get_data("dashboard_header_title"), "Header title")


def validate_header_data_and_subtitles():
    global data_value
    data = []
    subtitles = []
    numbers = []
    for i in range(1, 5):
        # Header data
        data_locator = (By.XPATH, f"(//*[@class='header-data__item__stat flex-space-between'])[{i}]")
        data_elem = create_wait(30).until(EC.visibility_of_element_located(data_locator))
        data_value = data_elem.text
        check.is_not_none(data_value, "Header data")
        data.append(data_value)
        # Header subtitle
        subtitle_locator = (By.XPATH, f"(//span[@class='header-data__item__subtitle'])[{i}]")
        subtitle_elem = create_wait(30).until(EC.visibility_of_element_located(subtitle_locator))
        subtitle_value = subtitle_elem.text
        subtitles.append(subtitle_value)
    # Calculate the % in subtitle
    if data_value is not None:
        for num, name in enumerate(data):
            str_data = str(data[num]).split('/')
            int_data = list(map(int, str_data))
            if int_data[0] > 0:
                result = int_data[0] / int_data[1] * 100
                number = round(result)
            else:
                number = 0
            numbers.append(number)
    # Validate data and subtitles
    check.equal(str(subtitles[0]), "Defects : " + str(numbers[0]) + "%", "Header subtitle")
    check.equal(str(subtitles[1]), "Passing : " + str(numbers[1]) + "%", "Header subtitle")
    check.equal(str(subtitles[2]), "Passing : " + str(numbers[2]) + "%", "Header subtitle")
    check.equal(str(subtitles[3]), "Passing : " + str(numbers[3]) + "%", "Header subtitle")


def get_current_date(start_month=False, start_year=False, start_month_name=False):
    today = date.today()
    if start_month:
        current_date = today.strftime("%m/%d/%Y")
    elif start_year:
        current_date = today.strftime("%Y-%m-%d")
    elif start_month_name:
        current_date = today.strftime("%b %-d, %Y")
    else:
        current_date = today.strftime("%d %b %Y")
    logger.info("Current date: " + current_date)
    return current_date
