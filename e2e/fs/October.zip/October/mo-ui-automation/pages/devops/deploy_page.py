from helpers.mo_element_operations import *
from helpers.mo_json_utils import *
from locators.devops.deploy_locator import *
from helpers.mo_check import mo_check as check
from pages.devops.common_page import get_current_date

data = ""


def validate_deployment_frequency():
    header = get_element_text_replace_value(tile_header_text, "1", "Tile header")
    check.equal(header, get_data("deploy_freq_title"), "Tile header")

    if is_element_present(total_deploy_freq_text, "Deployment frequency"):
        check.equal(get_element_text(total_deploy_freq_text), get_data("total_text"), "Total deployment frequency")
        check.is_not_none(get_element_text(deploy_freq_value_text), "Total value")
        check.is_true(is_element_present(deploy_freq_donut_chart, "Deploy frequency donut chart"), "Donut chart")


def validate_deployment_frequency_trend():
    header = get_element_text_replace_value(tile_title_text, "1", "Tile header")
    check.equal(header, get_data("deploy_freq_trend_title"), "Tile header")

    check.is_true(is_element_present(deploy_avg_text, "Average text"), "Average text")
    check.is_in(get_element_text(deploy_avg_percent_text), "/week", "Average %")

    check.is_true(is_element_present(deploy_frequency_line_chart, "Deploy frequency line chart"), "Line chart")
    check.greater(get_elements_count(freq_trend_line_chart_date_count), 0, "Line chart date count")
    check.greater(get_elements_count(freq_trend_line_chart_freq_count), 0, "Line chart frequency count")


def validate_apps_by_failure_rate():
    header = get_element_text_replace_value(tile_title_text, "2", "Tile header")
    check.equal(header, get_data("apps_failure_title"), "Tile header")
    check.equal(get_element_text(apps_failure_filter_text), get_data("apps_failure_filter_text"), "Filter text")

    if is_element_present(apps_failure_meter_count, "Meter count"):
        meter_percent = get_element_text(apps_failure_meter_count)
        meter_number = meter_percent.split(" ")

        dropdown_percent_values = get_data("apps_failure_percent_values")
        number = 60
        for value in dropdown_percent_values:
            click(apps_failure_percent_dropdown, "Failure percent dropdown")
            click_with_replace_value(apps_failure_dropdown_values, value, "Failure percent dropdown value")
            if int(float(meter_number[0])) > number:
                explicit_wait(2)
                check.equal(get_element_text(apps_failure_meter_title), get_data("applicationName"), "Meter title")
                check.is_not_none(get_element_text(apps_failure_meter_count), "Meter count")
                check.is_true(is_element_present(apps_failure_meter_progress, "Meter progress"), "Meter progress")
                number = number + 15
            else:
                check.is_in(get_element_text(empty_tile_text), get_data("no_data_text"), "Empty tile text")
            if number == 105:
                break


def validate_deployment_by_environment():
    header = get_element_text_replace_value(tile_title_text, "3", "Tile header")
    check.equal(header, get_data("deploy_env_title"), "Tile header")

    check.equal(get_element_text(total_deploy_text), get_data("total_deploy_text"), "Total deployment")
    check.is_not_none(get_element_text(total_value_text), "Total value")
    check.is_true(is_element_present(deploy_env_donut_chart, "Deploy env donut chart"), "Donut chart")


def validate_deployment_status(console_logs):
    header = get_element_text_replace_value(tile_title_text, "4", "Tile header")
    check.equal(header, get_data("deploy_status_title"), "Tile header")

    text = get_element_text(deploy_status_status_value)
    status = text.split(" ")
    check.is_not_none(status[0], "Status value")
    value = status[0].split("/")
    percent = int(value[0]) / int(value[1]) * 100
    check.equal(status[1], str(round(percent)) + "%", "Status percentage")

    check.equal(get_element_text(status_chart_type_dropdown_label), get_data("bar_chart_label"), "Chart label")
    check.greater(get_elements_count(bar_chart_days_count), 0, "Status total days")
    check.greater_equal(get_elements_count(bar_chart_deployment_count), 0, "Status total deployment")

    current_date = get_current_date(start_year=True)

    if 'Fail to deploy' in console_logs:
        click_with_replace_value(deployment_status_current_bar, current_date + "_Failure",
                                 "Current deployment status bar")
        check.equal(get_element_text(deploy_status_status_text), get_data("failure_text"), "Deployment status")
        check.equal(get_attribute_replace_value(deployment_status_current_bar, "stroke", current_date + "_Failure",
                                                "Current status bar"), "white", "Current status bar")
        click_with_replace_value(deployment_status_current_bar, current_date + "_Failure",
                                 "Current deployment status bar")
    else:
        click_with_replace_value(deployment_status_current_bar, current_date + "_Success",
                                 "Current deployment status bar")
        check.equal(get_element_text(deploy_status_status_text), get_data("success_text"), "Deployment status")
        check.equal(get_attribute_replace_value(deployment_status_current_bar, "stroke", current_date + "_Success",
                                                "Current status bar"), "white", "Current status bar")
        click_with_replace_value(deployment_status_current_bar, current_date + "_Success",
                                 "Current deployment status bar")

    # Donut chart
    click(deployments_title,  "Tile header")
    click(status_chart_type_dropdown, "Chart dropdown")
    click_with_replace_value(status_chart_dropdown_values, get_data("donut_chart_label"), "Donut chart")
    check.equal(get_elements_count(status_donut_chart_elements), 2, "Donut chart elements")


def validate_deployment_duration_trend():
    header = get_element_text_replace_value(tile_title_text, "5", "Tile header")
    check.equal(header, get_data("duration_trend_title"), "Tile header")

    check.is_true(is_element_present(deploy_duration_line_chart, "Deploy duration line chart"), "Line chart")
    check.greater(get_elements_count(duration_trend_line_chart_date_count), 0, "Line chart date count")
    check.greater(get_elements_count(duration_trend_line_chart_duration_count), 0, "Line chart frequency count")


def validate_deployments_table(console_logs):
    check.equal(get_element_text(deployments_title), get_data("deployments_title"), "Title")
    scroll_element_into_view(deployments_table_labels_text)
    labels = get_elements_texts(deployments_table_labels_text)
    check.equal(labels, get_data("deployments_table_labels"), "Table labels")

    global data
    current_date = get_current_date(start_month_name=True)
    data = get_elements_texts_replace_value(deployments_table_latest_data, current_date)
    check.equal(data[0], get_data("petstore_deploy_name"), "Deployment name")
    check.equal(data[1], get_data("petstore_jenkins_title"), "Technical service")
    check.is_in(data[2], current_date, "Deployment date")
    check.equal(data[3], get_data("azure_provider"), "Provider")
    check.equal(data[4], get_data("prod_env"), "Environment")
    check.equal(data[5], get_data("applicationName"), "Application")
    check.is_not_none(data[6], "Release")

    if 'Fail to deploy' in console_logs:
        check.equal(data[7], get_data("failure_text"), "Status")
    else:
        check.equal(data[7], get_data("success_text"), "Status")

    check.is_not_none(data[8], "Duration")
    check.is_not_none(data[9], "Tool engine")


def validate_latest_deployment_details(console_logs):
    current_date = get_current_date(start_month_name=True)
    click_with_replace_value(deploy_table_menu_icon, current_date, "Menu icon")
    click(deploy_table_view_details_option, "View Details")

    check.is_not_none(get_element_text(deploy_details_panel_title), "Panel title")
    if 'Fail to deploy' in console_logs:
        check.equal(get_element_text(status_tag_text), get_data("status_failed"), "Status tag")
    else:
        check.equal(get_element_text(status_tag_text), get_data("success_text"), "Status tag")

    check.equal(get_elements_texts(deploy_summary_labels), get_data("deployment_details_summary_labels"),
                "Summary labels")
    details_data = get_elements_texts(deploy_summary_data)

    check.equal(details_data[0], data[5], "Application")
    check.equal(details_data[1], data[8], "Duration")
    check.equal(details_data[2], data[6], "Release")
    check.equal(details_data[3], data[4], "Environment")
    check.is_in(details_data[4], data[2], "Deployment date")
