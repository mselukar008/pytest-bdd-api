from selenium.common.exceptions import StaleElementReferenceException
from selenium.webdriver.common import actions

from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_json_utils import *
from locators.devops.develop_locator import *
from helpers.mo_check import mo_check as check


def select_defects_issues_dropdown(dropdown_value):
    click(defects_issues_dropdown, "Dropdown")
    click_with_replace_value(dropdown_options, dropdown_value, "Dropdown value")
    explicit_wait(2)


def validate_development_activity():
    check.equal(get_element_text(development_activity_title), get_data("develop_activity_title"), "Develop tile title")
    check.is_true(is_element_present(development_activity_graph, "Development activity graph"),
                  "Development activity graph")

    check.greater(get_elements_count(days_axis_total_count), 0, "Days axis total count")
    check.greater(get_elements_count(defects_axis_total_count), 0, "Defects total count")


def validate_applications():
    title = get_elements_texts(applications_title)
    check.equal(title[0], get_data("apps_title"), "Applications tile title")
    check.equal(title[1], get_data("total_text"), "Total text")
    check.equal(get_element_text(applications_meter_title), get_data("applicationName"), "App meter title")
    total_count = get_element_text(app_meter_count)
    check.greater(int(total_count), 0, "Defects count")
    check.is_true(is_element_present(app_meter_progress, "Application progress bar"))

    click(applications_meter_title, "Application")
    return total_count


def open_github_links_and_verify_url(locator):
    links = get_elements_texts(locator)
    for num, name in enumerate(links):
        explicit_wait()
        click_index_based(locator, num, "Github link")
        switch_to_new_window()
        current_url = get_current_url()
        if "label" or "-label" or "closed" in current_url:
            check.is_in(current_url, get_data("petstore_github_url"), "Petstore github URL")
        switch_to_parent_window()


def validate_technical_services_table(defects_count, issues_count):
    check.is_true(is_element_present(tech_service_title, "Table title"), "Table title")
    check.equal(get_element_text(tech_service_tag_label), get_data("applicationName"), "Tag label")

    repeat = 0
    while repeat <= 3:
        try:
            check.is_not_none(get_elements_texts(tech_service_table_labels), "Table labels")
            break
        except StaleElementReferenceException:
            logger.info("Table labels not present")
        repeat = repeat + 1

    data = get_elements_texts(tech_service_table_data)
    check.equal(data[0], get_data("develop_tech_service"), "Technical service")
    check.equal(data[1], get_data("applicationName"), "Application")
    check.equal(data[2], defects_count, "New defects")
    check.equal(data[3], defects_count, "Updated defects")
    check.equal(data[4], issues_count, "New issues")
    check.equal(data[5], issues_count, "Updated issues")
    check.is_not_none(data[6], "Active PR")
    check.equal(data[7], get_data("tool_engine_github"), "Tool engine")

    # Verify defect and issue links
    scroll_to_bottom()
    explicit_wait(2)
    open_github_links_and_verify_url(tech_service_table_data_links)


def validate_development_activity_panel_overview():
    click(tech_service_table_menu_icon, "Table menu icon")
    scroll_element_into_view(table_menu_option)
    click(table_menu_option, "View Details")

    titles = get_elements_texts(develop_activity_panel_titles)
    check.equal(titles[0], get_data("develop_activity_panel_title"), "Develop activity title")
    check.equal(titles[1], get_data("github_panel_title"), "Tool engine title")

    headers = get_elements_texts(panel_details_summary_headers)
    check.equal(headers[0], get_data("defects_header"), "Defects header")
    check.equal(headers[1], get_data("issues_header"), "Issues header")

    check.equal(get_elements_texts_replace_value(panel_summary_status, get_data("defects_header")),
                get_data("defects_issues_status"), "Defects status")
    check.equal(get_elements_texts_replace_value(panel_summary_status, get_data("issues_header")),
                get_data("defects_issues_status"), "Issues status")

    open_github_links_and_verify_url(panel_defects_links)
    open_github_links_and_verify_url(panel_issues_links)

    tiles_header = get_elements_texts(panel_tiles_header)
    check.equal(tiles_header[0], get_data("defects_text"), "Defects header")
    check.equal(tiles_header[1], get_data("issues_text"), "Issues header")

    check.is_true(is_element_present_replace_value(panel_tiles_graph_data, get_data("defects_text")), "Defects graph")
    check.is_true(is_element_present_replace_value(panel_tiles_graph_data, get_data("issues_text")), "Issues graph")

    explicit_wait(3)
    check.greater(get_elements_count_replace_value(panel_days_axis_total_count, get_data("defects_text")), 0,
                  "Total defects days count")
    check.greater(get_elements_count_replace_value(panel_days_axis_total_count, get_data("issues_text")), 0,
                  "Total issues days count")
    check.greater(get_elements_count_replace_value(panel_left_axis_total_count, get_data("defects_text")), 0,
                  "Total defects count")
    check.greater(get_elements_count_replace_value(panel_left_axis_total_count, get_data("issues_text")), 0,
                  "Total issues count")


def validate_development_activity_panel_defects():
    click_with_replace_value(panel_tabs, get_data("defects_text"), "Defects tab")
    check.equal(get_element_text(panel_defects_tab_header), get_data("defects_tab_header"), "Defects header")

    check.equal(get_elements_texts(panel_defects_table_lables), get_data("defects_table_labels"), "Defects table labels")
    data = get_elements_texts(panel_defects_table_data)

    click(panel_defect_link, "Defect no")
    switch_to_new_window()
    issue_name = get_element_text(github_issue_name)
    issue = get_element_text(github_issue_number)
    issue_num = issue.split("#")
    issue_status = get_element_text(github_issue_status)
    switch_to_parent_window()

    check.equal(data[0], issue_num[1], "Defect no")
    check.equal(data[1], issue_name, "Summary")
    check.equal(data[2], issue_status.lower(), "State")
    check.is_not_none(data[3], "Created on")
    check.is_not_none(data[4], "Updated on")
    check.is_not_none(data[6], "Created by")


def validate_development_activity_panel_issues():
    click_with_replace_value(panel_tabs, get_data("issues_text"), "Issues tab")
    check.equal(get_element_text(panel_issues_tab_header), get_data("issues_tab_header"), "Issues header")

    issue_labels = get_data("defects_table_labels")
    issue_labels[0] = "Issue no"
    check.equal(get_elements_texts(panel_issues_table_labels), issue_labels, "Issues table labels")
    data = get_elements_texts(panel_issues_table_data)

    click(panel_issue_link, "Issue no")
    switch_to_new_window()
    issue_name = get_element_text(github_issue_name)
    issue = get_element_text(github_issue_number)
    issue_num = issue.split("#")
    issue_status = get_element_text(github_issue_status)
    switch_to_parent_window()

    check.equal(data[0], issue_num[1], "Issue no")
    check.equal(data[1], issue_name, "Summary")
    check.equal(data[2], issue_status.lower(), "State")
    check.is_not_none(data[3], "Created on")
    check.is_not_none(data[4], "Updated on")
    check.is_not_none(data[6], "Created by")
