from helpers.mo_element_operations import *
from helpers.mo_element_validation import is_element_present_replace_value
from helpers.mo_json_utils import *
from helpers.mo_check import mo_check as check
from locators.devops.build_locator import *
from locators.devops.test_locator import *
from pages.devops.common_page import get_current_date
from pages.devops.devops_navigation import open_di_test_page, open_di_deploy_page

expected_total_count = ""
failed_count = ""
passed_count = ""
skipped_count = ""
total_num = ""


def validate_test_summary_by_application():
    header = get_element_text_replace_value(tile_title_text, "1", "Tile header")
    check.equal(header, get_data("test_summary_title"), "Tile header")

    global failed_count, passed_count, skipped_count
    failed_count = get_element_text_replace_value(test_summary_status_count, "Failed", "Failed count")
    check.is_not_none(failed_count)
    passed_count = get_element_text_replace_value(test_summary_status_count, "Passed", "Passed count")
    check.is_not_none(passed_count)
    skipped_count = get_element_text_replace_value(test_summary_status_count, "Skipped", "Skipped count")
    check.is_not_none(skipped_count)
    global expected_total_count
    total_count = get_element_text_replace_value(test_summary_status_count, "Total", "Total count")
    expected_total_count = int(failed_count) + int(passed_count) + int(skipped_count)
    check.equal(int(total_count), expected_total_count, "Total count")

    if int(failed_count) > 0:
        check.is_true(is_element_present_replace_value(test_summary_status_bar, "Failed"))
    if int(passed_count) > 0:
        check.is_true(is_element_present_replace_value(test_summary_status_bar, "Passed"))
    if int(skipped_count) > 0:
        check.is_true(is_element_present_replace_value(test_summary_status_bar, "Skipped"))


def validate_services_with_less_coverage():
    header = get_element_text_replace_value(tile_header_text, "2", "Tile header")
    check.equal(header, get_data("less_coverage_title"), "Tile header")

    if is_element_present(less_coverage_meter_title, "Lowest coverge"):
        check.is_in(get_element_text(less_coverage_meter_title), get_data("develop_tech_service"), "Meter title")
        check.is_true(is_element_present(meter_progress_bar, "Meter progress bar"), "Meter progress bar")
        check.is_not_none(get_element_text(meter_count_text), "Meter count")


def validate_overall_test_status():
    header = get_element_text_replace_value(tile_header_text, "3", "Tile header")
    check.equal(header, get_data("test_status_title"), "Tile header")
    check.equal(get_element_text(test_status_total_text), get_data("total_text"), "Test status total text")
    total_value = get_element_text(test_status_total_value)
    global total_num
    total_num = total_value.split(" ")
    check.greater(int(total_num[0]), 0, "Total value")

    # Bar chart
    check.equal(get_element_text(chart_type_dropdown_label), get_data("bar_chart_label"), "Chart label")
    check.greater(get_elements_count(status_bar_chart_tests_count), 0, "Test status total tests")
    check.equal(get_elements_count(status_bar_chart_days_count), 8, "Test status total days")

    current_date = get_current_date(start_year=True)

    if int(passed_count) > 0:
        click_with_replace_value(test_status_current_bar, current_date + "_Passed", "Current status bar")
        check.is_not_none(get_attribute_replace_value(test_status_current_bar, "stroke", current_date + "_Passed",
                                                      "Current status bar"), "Passed status")
        click_with_replace_value(test_status_current_bar, current_date + "_Passed", "Current status bar")
    if int(failed_count) > 0:
        click_with_replace_value(test_status_current_bar, current_date + "_Failed", "Current status bar")
        check.is_not_none(get_attribute_replace_value(test_status_current_bar, "stroke", current_date + "_Failed",
                                                      "Current status bar"), "Failed status")
        click_with_replace_value(test_status_current_bar, current_date + "_Failed", "Current status bar")
    if int(skipped_count) > 0:
        click_with_replace_value(test_status_current_bar, current_date + "_Skipped", "Current status bar")
        check.is_not_none(get_attribute_replace_value(test_status_current_bar, "stroke", current_date + "_Skipped",
                                                      "Current status bar"), "Skipped status")
        click_with_replace_value(test_status_current_bar, current_date + "_Skipped", "Current status bar")

    # Donut chart
    scroll_element_into_view(chart_type_dropdown)
    click(chart_type_dropdown, "Chart dropdown")
    click_with_replace_value(chart_dropdown_values, get_data("donut_chart_label"), "Donut chart")
    check.equal(get_elements_count(donut_chart_elements), 3, "Donut chart elements")


def validate_test_type_status():
    header = get_element_text_replace_value(tile_header_text, "4", "Tile header")
    check.equal(header, get_data("test_type_title"), "Tile header")

    check.equal(get_element_text_replace_value(test_type_summary, "1", "Unit tests"), "Unit\n" +
                total_num[0] + "/" + total_num[0], "Unit tests summary")
    check.is_in(get_element_text_replace_value(test_type_summary, "2", "Other tests"), get_data("functional_test_type"),
                "Other tests summary")
    check.is_in(get_element_text_replace_value(test_type_summary, "3", "Functional tests"),
                get_data("other_test_type"), "Functional tests summary")

    check.greater(get_elements_count(test_type_bar_chart_tests_count), 0, "Test type total tests")
    check.greater(get_elements_count(test_type_bar_chart_days_count), 0, "Test type total days")

    current_date = get_current_date(start_year=True)

    click_with_replace_value(test_type_current_bar, current_date + "_Unittests", "Current test type status bar")
    check.is_not_none(get_attribute_replace_value(test_type_current_bar, "stroke", current_date + "_Unittests",
                                                  "Current test type status bar"), "Current test type status bar")


def select_duration(duration):
    scroll_up()
    click(duration_dropdown, "Duration dropdown")
    click_with_replace_value(duration_dropdown_options, duration, "Duration value")
    explicit_wait(3)


def validate_technical_service_tests_table():
    check.equal(get_element_text(technical_service_title), get_data("service_tests_title"), "Title")
    scroll_element_into_view(table_search_icon)
    click(table_search_icon, "Table search")
    type_value_and_enter(table_search_text, get_data("develop_tech_service"), "Table search textbox")
    tag_label = get_attribute_value(table_search_tag_label, "title")
    check.equal(tag_label, get_data("develop_tech_service"), "Table search tag label")

    # Validate the table for 1 day duration
    open_di_deploy_page()
    open_di_test_page()
    select_duration("1 Day")
    validate_test_summary_by_application()

    current_date = get_current_date(start_month_name=True)
    labels = get_elements_texts(table_labels_text)
    check.equal(labels, get_data("test_table_labels"), "Table labels")
    data = get_elements_texts_replace_value(test_table_data_text, current_date)
    check.equal(data[0], get_data("develop_tech_service"), "Technical service")
    check.equal(data[1], get_data("applicationName"), "Application")
    check.equal(data[2], get_data("unit_test_type"), "Test type")
    check.equal(data[3], failed_count + " (" + failed_count + "%)", "Failed")
    check.equal(data[4], skipped_count + " (" + skipped_count + "%)", "Skipped")

    passed_percent = int(passed_count) / int(expected_total_count) * 100
    check.equal(data[5], "20" + " (" + str(int(passed_percent)) + "%)", "Passed")

    check.equal(int(data[6]), 20, "Total")
    check.is_not_none(data[7], "Release")

    check.equal(data[8], get_data("prod_env"), "Environment")
    check.is_not_none(data[9], "Duration")
    check.is_in(data[10], current_date, "Execution date")
    check.equal(data[11], get_data("ant_tool_engine"), "Tool engine")
    select_duration("7 Days")


def validate_technical_service_panel_activity_tab():
    current_date = get_current_date(start_month_name=True)
    click_with_replace_value(test_table_menu_icon, current_date, "Menu icon")
    click(view_details_option, "View Details")
    check.equal(get_element_text(build_detail_title), get_data("technical_service_title"), "Panel Title")
    check.equal(get_element_text(test_side_panel_title), get_data("test_tool_and_type"), "Tool and Test type")

    click(activity_tab, "Activity")

    # Test status validation
    status_header = get_element_text_replace_value(technical_service_tile_header, "1", "Test status header")
    check.equal(status_header, get_data("tech_test_status_title"), "Tile header")
    check.greater(get_elements_count_replace_value(detail_bar_charts_left_axis, get_data("tech_test_status_title")), 0,
                  "Total tests count")
    check.equal(get_elements_count_replace_value(detail_bar_charts_bottom_axis, get_data("tech_test_status_title")), 8,
                "Total duration count")
    check.is_not_none(get_element_text_replace_value(detail_bar_charts_current_date, get_data("tech_test_status_title"),
                                                     "Status current date"), "Current duration date")
    mouse_over_click(tech_service_bar_charts_status_current_bar)
    value = get_attribute_value(tech_service_bar_charts_status_current_bar, "class")
    check.is_in(value, 'hovered', "Current date status bar")

    # Test duration validation
    status_header = get_element_text_replace_value(technical_service_tile_header, "2", "Test duration header")
    check.equal(status_header, get_data("test_duration_title"), "Tile header")
    check.greater(get_elements_count_replace_value(detail_bar_charts_left_axis, get_data("test_duration_title")), 0,
                  "Execution duration count")
    check.equal(get_elements_count_replace_value(detail_bar_charts_bottom_axis, get_data("test_duration_title")), 8,
                "Total duration count")
    check.is_not_none(get_element_text_replace_value(detail_bar_charts_current_date, get_data("test_duration_title"),
                                                     "Status current date"), "Current duration date")
    mouse_over_click(tech_service_bar_charts_duration_current_bar)
    value = get_attribute_value(tech_service_bar_charts_duration_current_bar, "class")
    check.is_in(value, 'hovered', "Current date status bar")


def validate_technical_service_panel_historical_details_tab():
    current_date = get_current_date(start_month_name=True)
    click(historical_details_tab, "Historical details")
    check.equal(get_element_text(historical_details_table_title), get_data("test_executions_title"),
                "Historical table title")

    labels = get_elements_texts(historical_details_table_labels)
    check.equal(labels, get_data("historical_table_labels"), "Historical table labels")
    data = get_elements_texts(historical_details_table_data)

    check.is_in(data[0], current_date, "Execution date")
    check.equal(data[1], failed_count + " (" + failed_count + "%)", "Failed")
    check.equal(data[2], skipped_count + " (" + skipped_count + "%)", "Skipped")

    passed = data[3].split(" ")
    check.greater(int(passed[0]), 0, "Passed")

    total = data[4].split(" ")
    check.greater(int(total[0]), 0, "Total")

    check.is_not_none(data[5], "Code smells")
    check.is_not_none(data[6], "Bugs")
    check.is_not_none(data[7], "Coverage")
    check.is_not_none(data[8], "Release")
    check.equal(data[9], get_data("prod_env"), "Environment")
    check.is_not_none(data[10], "Duration")
