from helpers.mo_json_utils import *
from helpers.mo_element_operations import *
from locators.ecam.drg_locator import *
from helpers.mo_page_operations import *
from tests.common_test import *
from helpers.mo_check import mo_check as check


# Wait to load DRG page
def wait_for_to_load_drg_page():
    wait_for_spinner_on()
    wait_for_spinner_off()
    wait_for_element_to_visible(table_first_col_btn, "Table first column button")


# Click on Create new button
def click_on_create_new_btn():
    wait_for_element_clickable(create_new_btn, "Create new button")
    click(create_new_btn, "Create new button")


def select_drg_type(type):
    click_with_replace_value(drg_type_tile, type, "DRG type")


def enter_drg_name(drg_name):
    type_value(drg_name_input, drg_name, "DRG name input")


# Define new budgetary DRG
def define_budgetary_drg(drg_name):
    click_with_replace_value(drg_type_tile, get_data("budgetaryTypeDrgValue"), "DRG type tile")
    type_value(drg_name_input, drg_name, "DRG name input")


# Click on Next button
def click_on_next_btn():
    scroll_element_into_view(next_button)
    click(next_button, "Next button")


# Click on Save drg button
def click_on_save_btn():
    scroll_element_into_view(drg_save_button)
    click(drg_save_button, "Save DRG button")


# Select Team name as Associate context
def select_team_in_associate_context(team_name):
    explicit_wait(3)
    click_in_shadow_dom(entity_dropdown_checkbox, "entity dropdown checkbox")
    is_element_visible_in_shadow_dom(choose_entity_dropdown_btn, "Choose entity dropdown button")
    click_in_shadow_dom(choose_entity_dropdown_btn, "Choose entity dropdown button")
    is_element_visible_in_shadow_dom(team_entity_dropdown_option, "Team Entity option")
    click_in_shadow_dom(team_entity_dropdown_option, "Team Entity option")
    click_in_shadow_dom(select_team_dropdown_input, "Select team dropdown input")
    type_value_in_shadow_dom(select_team_dropdown_input, team_name, "Select team dropdown input")
    # wait_for_element_to_visible_with_replace_value(team_dropdown_option, team_name, "Team option")
    click_with_replace_value_in_shadow_dom(team_dropdown_option, team_name, "Team option")
    click_in_shadow_dom(select_team_dropdown_input, "Select team dropdown input")
    

# Select Budgetary unit name as Associate context
def select_budgetary_unit_name(budgetary_unit_name, repeater = 5):
    if repeater > 0:
        #wait_for_element_clickable(select_bu_dropdown_btn, "Select Budgetary unit dropdown button")
        is_element_visible_in_shadow_dom(select_bu_dropdown_btn, "Select Budgetary unit dropdown button")
        explicit_wait(3)
        click_in_shadow_dom(select_bu_dropdown_btn, "Select Budgetary unit dropdown button")
        explicit_wait(3)
        option_count = get_elements_count_for_shadow_dom(bu_dropdown_options)
        if option_count > 0:
            scroll_to_element_with_replace_value_in_shadow_dom(bu_dropdown_option, budgetary_unit_name, True)
        else:
            repeater = repeater - 1
            logger.info("Budgetary unit options are not visible, clicking it again")
            select_budgetary_unit_name(budgetary_unit_name, repeater)
    else:
        logger.info("Budgetary unit options are not visible")


# Click on Filters button
def click_on_filters_button():
    scroll_element_into_view(filters_button)
    click(filters_button, "Filters button")


# Select Provider from Provider filter
def select_provider_from_filters(provider_name):
    scroll_element_into_view_with_replace_value(filter_option_button, get_data("providerFilterLabel"), True)
    wait_for_spinner_off()
    wait_for_element_to_visible_with_replace_value(select_provider_checkbox, provider_name, "Provider name checkbox")
    click_with_replace_value(select_provider_checkbox, provider_name, "Provider name checkbox")


# Select Tag [Key:Value] from Provider Tag filter
def select_provider_tag_from_filters(tag_key, tag_value):
    scroll_element_into_view_with_replace_value(filter_option_button, get_data("providerTagFilterLabel"), True)
    wait_for_spinner_off()
    wait_for_element_to_visible(search_provider_tag_input, "Provider tag search input")
    click_with_replace_value(logical_op_radio_button, "AND", "AND operator radio button")
    #value = f"{tag_key} == '{tag_value}'"
    wait_for_spinner_off()
    wait_for_element_clickable(search_provider_tag_input, "Provider tag search input")
    type_value_and_enter(search_provider_tag_input, tag_key, "Provider tag search input")
    explicit_wait(5)
    press_enter_key(search_provider_tag_input, "Tag Key")
    click(tag_key_btn, "Tag Key")
    wait_for_spinner_off()
    tag_values = get_elements_texts(search_list_all_options)
    for value in tag_values:
        if value.strip() == tag_value:
            scroll_element_into_view_with_replace_value(search_list_option, tag_value)
            click_with_replace_value(search_list_option, tag_value, "Searched tag value option")
            wait_for_spinner_off()
            click(add_button, 'Add Button')
            break


# Click on Apply filters button
def click_on_apply_filters_button():
    scroll_element_into_view(apply_filters_button)
    click(apply_filters_button, "Apply filters button")


# Search DRG
def search_drg_name(drg_name):
    click(search_drg_icon, "Search DRG Icon")
    type_value_and_enter(search_drg_textbox, drg_name, "Search DRG Textbox")
    wait_for_to_load_drg_page()
    if get_elements_count(empty_row_cell) > 0:
        logger.info("No DRGs found in the table")
        return False
    else:
        logger.info("Search results found in the table")
        return True


def open_drg(drg_name):
    search_drg_name(drg_name)
    click(table_first_row, "Table first row")
    wait_for_spinner_off()


# Delete DRG
def delete_drg(drg_name):
    if search_drg_name(drg_name):
        click(table_first_row, "Table first row")
        wait_for_element_clickable(delete_drg_button, "Delete DRG button")
        click(delete_drg_button, "Delete DRG button")
        wait_for_element_clickable(confirm_delete_drg_button, "Confirm Delete DRG button")
        click(confirm_delete_drg_button, "Confirm Delete DRG button")
        check.is_in(get_data("drgDeletedMessage"), get_element_text(notification_msg_text))


def add_dynamic_tag(key, value):
    click(add_dynamic_tags_btn, "Dynamic Tag")
    type_value(dynamic_tag_key_textbox, key, "Key")
    type_value(dynamic_tag_value_textbox, value, "Value")
    click(dynamic_key_value_add_btn, "Add")


def verify_filter_set_table_for_provider(provider):
    provider_values = get_elements_texts(filter_set_provider_table_text)
    for value in provider_values:
        if value != provider:
            logger.info(provider + " filtered resources are not displayed")
            return False
        return True


def verify_filter_set_table_for_tag(tag):
    tag_values = get_elements_texts(filter_set_tags_table_text)
    for value in tag_values:
        if tag not in value:
            logger.info(tag + " filtered resources are not displayed")
            return False
        return True


def click_bar_chart_using_month(month_index):
    try:
        click_with_replace_value(month_bar_chart, month_index,'Month Bar Chart')
    except:
        logger.info("Exception occurred, Clicking again..")
        mouse_over_click_using_offset_with_replace_value(month_bar_chart, month_index, 10, 10, 'Month Bar Chart')
