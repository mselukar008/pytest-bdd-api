from helpers.mo_json_utils import *
from helpers.mo_element_operations import *
from locators.ecam.assets_locator import *
from pages.ecam.costs_page import *
from helpers.mo_check import mo_check as check


# Click on bar chart bar using month index
def click_assets_bar_chart_using_month(month_index):
    try:
        click_with_replace_value(asset_month_bar_chart, month_index, 'Asset Month Bar Chart')
    except:
        logger.info("Exception occurred, Clicking again..")
        mouse_over_click_using_offset_with_replace_value(asset_month_bar_chart, month_index, 10, 10, 'Asset Month Bar Chart')
    wait_for_to_load_costs_page()


# Validate asset bar chart values
def validate_asset_bar_chart():
    check.equal(get_element_text(asset_bar_chart_title_text), get_data("assetBarChartTitle"), 'Bar Chart Title')
    check.equal(get_elements_count(asset_bar_chart_x_axis_labels), get_data("assetBarChartXaxisCount"), 'Bar Chart X Axis Count')


# Validate asset vs utilization heatmap values
def validate_asset_utilization_heat_map():
    check.equal(get_element_text(assets_utilization_heatmap_title_text), get_data("assetVUtilizationHeatmapTitle"), 'Heatmap Title')
    check.not_equal(get_element_text(assets_utilization_heatmap_utilization_legends), None, 'Heatmap Utilization Legend')
    check.not_equal(get_element_text(assets_utilization_heatmap_asset_status_legends), None, 'Heatmap Asset Status Legend')