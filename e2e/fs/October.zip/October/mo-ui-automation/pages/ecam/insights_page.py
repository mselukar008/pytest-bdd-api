from helpers.mo_element_validation import *
from helpers.mo_json_utils import *
from helpers.mo_page_operations import *
from locators.ecam.insights_locator import *
from helpers.mo_element_operations import *
from  helpers.mo_check import mo_check as check


# Wait till load all elements on insights page
def wait_for_insights_page_to_load():
    wait_for_spinner_off()
    if is_element_present_replace_value(table_row, 1):
        wait_for_all_elements_to_load(table_rows, 'Table Rows')


# Get header title text for insights page
def get_insights_header_title_text():
    try:
        wait_for_insights_page_to_load()
    except:
        logger.info("Exception occurred, Clicking again..")
        wait_for_insights_page_to_load()
    return get_element_text(insights_title_text).strip()


# Click on Data set button
def click_on_data_set_btn():
    try:
        wait_before_click(data_set_button, "Data set button")
    except:
        logger.info("Exception occurred, Clicking again..")
        wait_before_click(data_set_button, "Data set button")


# Get count of DRGs
def is_present_dynamic_resource_groups():
    click_on_data_set_btn()
    wait_before_click(drg_dropdown_button, "DRG Dropdown button")
    wait_for_all_elements_to_load(drg_dropdown_option_buttons, 'DRG Dropdown Options Button')
    drg_count = get_elements_count(drg_dropdown_option_buttons)
    logger.info("DRG count : {}".format(drg_count))
    return drg_count


# Validate all summary values from insights page
def validate_summary_values():
    # check.not_equal(get_element_text_replace_value(summary_value, get_data("summaryEstimatedCostLabel"), 'Summary Estimated Cost Label'),
    #                 get_data("noDataText"), "Summary Estimated Cost Label")
    check.not_equal(get_element_text_replace_value(summary_value, get_data("summaryOpportunitiesLabel"), 'Summary Opportunities Label'),
                    get_data("noDataText"), "Summary Opportunities Label")
    check.not_equal(get_element_text_replace_value(summary_value, get_data("summaryEstimatedSavingsLabel"), 'Summary Estimated Savings Label'),
                    get_data("noDataText"), "Summary Estimated Savings Label")


# Get summary value using label text
def get_summary_values(labelName):
    if "No Data" in get_element_text_replace_value(summary_value, labelName, "Summary Value"):
        return "No Data"
    else:
        value_text = get_element_text_replace_value(summary_value, labelName, 'Summary Value').strip()
        if "Assets" in labelName:
            value = int(value_text)
        else:
            value = float(value_text.replace("USD ", "").replace(",","").split(" ")[0])
        logger.info(labelName+" {}".format(value))
        return value


# Validate all mini chart values from insights page
def validate_minichart_values():
    check.not_equal(get_element_text_replace_value(mini_chart_value, get_data("totalEstimatedSavingsPerServiceProvider"), 'Minichart Value'),
                    get_data("noDataText"), "Total Estimated Savings Per Service Provider Minichart Value")
    check.not_equal(get_element_text_replace_value(mini_chart_value, get_data("totalOpportunitiesPerServiceProvider"), 'Minichart Value'),
                    get_data("noDataText"), "Total Opportunities Per Service Provider Minichart Value")


# Get mini chart value using dropdown option text
def get_minichart_values(dropdownOption):
    if get_data("noDataText") in get_element_text_replace_value(mini_chart_value, dropdownOption, "Minichart Value"):
        return get_data("noDataText")
    else:
        value_text = get_element_text_replace_value(mini_chart_value, dropdownOption, 'Minichart Value').strip()
        if "Total Opportunities" in dropdownOption:
            value = int(value_text)
        else:
            value = float(value_text.replace("USD ", "").replace(",",""))
        logger.info(dropdownOption+": {}".format(value))
        return value


# Click on Optimization filters button
def click_on_optimization_btn():
    try:
        wait_before_click(optimization_button, "Optimization button")
    except:
        logger.info("Exception occurred, Clicking again..")
        wait_before_click(optimization_button, "Optimization button")


# Apply Optimization filters using given params
def apply_optimization_filter(value):
    click_on_optimization_btn()
    # wait_for_all_elements_to_load(optimization_radio_all_buttons, 'Optimization Radiobuttons')
    # click_with_replace_value(optimization_radio_button, optimize_by_value, 'Optimization Radiobutton')
    # click_with_replace_value(optimization_radio_button, conditions_value, 'Optimization Radiobutton')
    type_value(optimization_textbox, value, "Optimize by value")
    click(optimization_textbox_increment_button, "Value increment button")
    click(filters_apply_button, "Apply button")
    wait_for_insights_page_to_load()


def click_on_previous_month_bar_chart():
    click(previous_month_bar, "Previous month bar")
    wait_for_insights_page_to_load()


# Get column index using column name
def get_column_index(col_name):
    header_names = get_elements_texts(table_header_names)
    for index, name in enumerate(header_names):
        if name.strip() == col_name:
            logger.info("Column index for "+col_name+" column: {}".format(index+1))
            return index+1


# Click on column header button
def click_on_column_header(col_name):
    scroll_element_into_view_with_replace_value(table_header_button, col_name)
    click_using_script_replace_value(table_header_button, col_name, 'Table Header Button')
    wait_for_insights_page_to_load()


# Validate sorting of assets with costs in table using column name
def validate_sorting_of_assets(col_name):
    click_on_column_header(col_name)
    logger.info("Clicked on "+col_name+" column to sort values in ascending order")
    click_on_column_header(col_name)
    logger.info("Clicked on "+col_name+" column to sort values in descending order")
    explicit_wait(5)
    col_index = get_column_index(col_name)
    col_values_list = get_elements_texts_replace_value(table_cell_values, col_index)
    for index, val in enumerate(col_values_list):
        if index != len(col_values_list)-1:
            cost_from_first_row = float(col_values_list[index].replace("USD ", "").replace(",",""))
            cost_from_second_row = float(col_values_list[index+1].replace("USD ", "").replace(",",""))
            if cost_from_first_row >= cost_from_second_row:
                logger.info(col_name+" column value: "+col_values_list[index])
            else:
                logger.info(col_name+" column values are not sorted.")
                logger.info("Value from row-{}".format(index)+": "+col_values_list[index])
                logger.info("Value from row-{}".format(index+1)+": "+col_values_list[index+1])
                return False
    return True


# Get page size for table
def get_table_page_size():
    pagesize_text = get_element_text(table_pagesize_text)
    pagesize = int(pagesize_text.split(" ")[1])
    logger.info("Pagesize for the table: {}".format(pagesize))
    return pagesize


# Click on next page button
def click_on_next_page_btn():
    if is_element_enable(table_next_page_button, "Next button"):
        wait_before_click(table_next_page_button, "Next button")
        wait_for_insights_page_to_load()
    else:
        logger.info("Reached last page, next button is disabled")


# Click on asset having tags with give recommendation type value
def click_on_asset_id_having_tags(recomm_type_value):
    recomm_type_col_index = get_column_index(get_data("recommTypeColName"))
    # tags_col_index = get_column_index(get_data("tagsColName"))
    pagesize = get_table_page_size()
    for page in range(0, pagesize):
        row_count = get_elements_count(table_rows)
        for row in range(0, row_count):
            recomm_type_text = get_element_text_replace_value(table_cell_value, [row+1, recomm_type_col_index], 'Table Cell Value')
            # tags_text = get_element_text_replace_value(table_cell_value, [row+1, tags_col_index], 'Table Cell Value')
            logger.info("Recomm Type Column Text: " + recomm_type_text)
            if recomm_type_value in recomm_type_text:
                logger.info("Asset found on page {}".format(page+1))
                click_with_replace_value(table_row, row+1, 'Table Row')
                return True
        click_on_next_page_btn()
        explicit_wait(3)
    logger.info("Asset not found with given conditions")
    return False


# Get properties value from asset details page
def get_properties_value(property_key):
    wait_for_element_to_visible_with_replace_value(asset_property_value, property_key, 'Asset Property Value')
    value = get_element_text_replace_value(asset_property_value, property_key, 'Asset Property Value').strip()
    logger.info("Property value for "+property_key+": "+value)
    return value


# Get properties value with exact label string from asset details page
def get_properties_value_with_exact_label(property_key):
    wait_for_element_to_visible_with_replace_value(asset_property_value_with_exact_label, property_key, 'Asset Property Value')
    value = get_element_text_replace_value(asset_property_value_with_exact_label, property_key, 'Asset Property Value').strip()
    logger.info("Property value for "+property_key+": "+value)
    return value


# Validate properties value from asset details page
def validate_asset_properties_values():
    check.not_equal(get_properties_value_with_exact_label(get_data("recommReasonPropertyKey")), None, "Recommendation Reason Property Value")
    # check.not_equal(get_properties_value_with_exact_label(get_data("recommPropertyKey")), None, "Recommendation Property Value")
    # check.not_equal(get_properties_value_with_exact_label(get_data("recommTypePropertyKey")), None, "Recommendation Type Property Value")
    # check.not_equal(get_properties_value_with_exact_label(get_data("recommAgePropertyKey")), None,"Recommendation Age Property Value")
    #check.not_equal(get_properties_value(get_data("estimatedSavingsPropertyKey")), None, "Estimated Savings Property Value")
    #check.not_equal(get_properties_value(get_data("estimatedCostPropertyKey")), None, "Estimated Cost Property Value")


# Click on tab button from asset details page
def click_on_asset_details_tabs(tabName):
    wait_for_spinner_off()
    wait_for_element_to_visible_with_replace_value(asset_details_page_tab_button, tabName, 'Assets Details Page Tab Button')
    click_with_replace_value(asset_details_page_tab_button, tabName, 'Asset Details Page Tab Button')


# Get Tags count from Tags tab name
def get_tags_count_from_tab_name():
    tags_tab_text = get_element_text(tags_tab_button)
    tag_count = tags_tab_text.split(" (")[1].split(")")[0]
    logger.info("Tags count from header text: "+tag_count)
    return int(tag_count)


# Get all tags keys in string
def get_tags_keys():
    wait_for_all_elements_to_load(table_first_col_values, 'Table First Column Value')
    list_of_keys = get_elements_texts(table_first_col_values)
    list_to_string = ' '.join([str(elem) for elem in list_of_keys])
    return list_to_string