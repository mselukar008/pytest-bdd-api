from helpers.mo_element_validation import *
from helpers.mo_json_utils import *
from helpers.mo_element_operations import *
from locators.ecam.costs_locator import *
from helpers.mo_check import mo_check as check
from tests.common_test import *


# Wait for costs page to load completely
def wait_for_to_load_costs_page():
    wait_for_all_elements_to_load(costs_table_rows, 'Cost Table Rows')
    wait_for_element_to_invisible(loading_circle, "Loading circle")
    wait_for_spinner_off()


# Get header title text for costs page
def get_costs_header_title_text():
    try:
        wait_for_to_load_costs_page()
    except:
        logger.info("Exception occurred, Clicking again..")
        wait_for_to_load_costs_page()
    return get_element_text(page_header_title_text).strip()


# Click on Data set button
def click_on_data_set_btn():
    try:
        scroll_element_into_view(data_set_filter_button)
        wait_before_click(data_set_filter_button, "Data set button")
    except:
        logger.info("Exception occurred, Clicking again..")
        wait_before_click(data_set_filter_button, "Data set button")


# Select DRG from data set filter using given value
def select_drg_from_data_set_filters(drg_value):
    click_on_data_set_btn()
    wait_before_click(drg_dropdown_button, "DRG Dropdown button")
    wait_for_all_elements_to_load(drg_dropdown_options, 'DRG Dropdown Options')
    type_value_and_enter(drg_search_input, drg_value, "Search DRG")
    click_with_replace_value(drg_dropdown_option, drg_value, 'DRG Dropdown Option')
    click(filters_apply_button, "Apply button")
    wait_for_to_load_costs_page()


# Click on bar chart bar using month index
def click_costs_bar_chart_using_month(month_index):
    scroll_element_into_view(download_line_items_button)
    try:
        click_with_replace_value(month_bar_chart, month_index, 'Month Bar Chart')
    except:
        logger.info("Exception occurred, Clicking again..")
        mouse_over_click_using_offset_with_replace_value(month_bar_chart, month_index, 10, 10, 'Month Bar Chart')
    wait_for_to_load_costs_page()
    explicit_wait(3)


# Validate summary values
def validate_costs_page_summary():
    check.is_true(is_element_present(cost_element_info, "Cost info text"), 'Cost info text')
    # check.is_true(is_element_present(assets_element_info, "Assets info text"), 'Assets info text')
    explicit_wait(3)
    check.is_in(get_data("costCurrencyValue"), get_element_text(summary_values_text), 'Cost Summary')
    # check.not_equal(get_element_text(summary_values_text), None, 'Assets Summary')


def validate_assets_page_summary():
    check.is_true(is_element_present(assets_element_info, "Assets info text"), 'Assets info text')
    explicit_wait(3)
    check.not_equal(get_element_text(summary_values_asset), None, 'Assets Summary')

# Click on show projection checkbox
def click_on_show_projection_checkbox():
    is_element_present(show_projection_label, 'Show Projection Checkbox')
    click(show_projection_label, 'Show Projection Checkbox')


# Validate cost bar chart values
def validate_cost_bar_chart():
    check.equal(get_element_text(cost_bar_chart_title_text), get_data("costBarChartTitle"), 'Cost Bar Chart Title')
    check.equal(get_elements_count(cost_bar_chart_x_axis_labels), get_data("costBarChartXaxisCount"),
                'Cost Bar Chart Axis Count')


# Click on minichart dropdown button using chart index
def click_on_minichart_dropdown_button(chart_index):
    scroll_element_into_view(add_chart_button)
    click_with_replace_value(minichart_dropdown_button, chart_index, 'Minichart Dropdown Button')
    wait_for_all_elements_to_load(minichart_dropdown_options, 'Minichart Dropdown Options')


# Select dropdown value from minichart using chart index and value
def select_minichart_dropdown_value(chart_index, dropdown_value):
    click_on_minichart_dropdown_button(chart_index)
    click_with_replace_value(minichart_dropdown_option, dropdown_value, 'Minichart Dropdown Option')
    wait_for_to_load_costs_page()


# Validate minichart values on cost page
def validate_cost_page_minichart_values(dropdown_values, month_yr):
    indices = [get_data("firstChartIndex"), get_data("secondChartIndex"), get_data("thirdChartIndex")]
    for value in dropdown_values:
        # Select dropdown value from first minichart
        select_minichart_dropdown_value(indices[0], value)
        # Validate values from all minicharts
        for chart_index in indices:
            check.equal(
                get_element_text_replace_value(minichart_month_year_text, chart_index, 'Minichart Month Year Text'),
                month_yr, 'Minichart Month Year')
            if "Count /" in value:
                check.not_equal(get_element_text_replace_value(minichart_cost_text, chart_index, 'Minichart Cost Text'),
                                None, 'Minichart Cost')
            else:
                check.is_in(get_data("costCurrencyValue"),
                            get_element_text_replace_value(minichart_cost_text, chart_index, 'Minichaty Cost Text'),
                            'Cost Currency')
            check.not_equal(get_element_text_replace_value(minichart_data, chart_index, 'Minichart Data'), None,
                            'Minichart Data')


# Click on download button
def click_on_download_button():
    scroll_element_into_view(page_header_title_text)
    click(download_line_items_button, "Download button")
    wait_for_element_to_visible(modal_download_header_text, "Modal download header")
    wait_for_spinner_off()


# Select download format from dropdown
def select_download_format(format_type):
    click(modal_format_dropdown_button, "Modal dropdown button")
    click_with_replace_value(modal_dropdown_option, format_type, 'Modal Dropdown Option')


def click_apply_pricing_policy_toggle_switch():
    scroll_element_into_view(apply_pricing_policy_toggle_switch)
    click(apply_pricing_policy_toggle_switch, 'Apply Pricing Policy Toggle Switch')


# Download line items from table
def download_line_items_from_table(format_type, apply_pricing=False):
    if is_element_present(table_no_data_text, "No data text"):
        logger.info("No data present in line items table.")
        check.is_false(is_element_enable(download_line_items_button, "Download button"), 'Download Button')
        return False
    else:
        # Open notification side panel
        click(notification_button, "Notification icon button")
        if (get_element_text(notification_count_text)) != get_data("notificationCountText"):
            click(clear_notification_link, "Clear Notification")
            explicit_wait(5)
            check.equal(get_element_text(notification_count_text), get_data("notificationCountText"),
                        "Notification Count Validation")
        click(notification_button, "Notification icon button")
        check.is_true(is_element_enable(download_line_items_button, "Download button"), 'Download Button')
        click_on_download_button()
        select_download_format(format_type)
        if apply_pricing:
            click_apply_pricing_policy_toggle_switch()
        click(modal_download_button, "Modal download button")
        return True


# Download report from Notification
def download_report_from_notification():
    delete_all_downloaded_files()
    explicit_wait(3)
    # Open notification side panel
    click(notification_button, "Notification icon button")
    # wait_for_element_to_visible(notification_download_link, "Notification download link")
    # explicit_wait(3)
    # wait_until_notification_download_link_available()
    if is_element_present(notification_download_link, "Notification download link"):
        click_using_java_script(notification_download_link, "Notification download link")
    else:
        explicit_wait(200)
        click_using_java_script(notification_download_link, "Notification download link")
    # Static wait to download zip file completely
    time.sleep(10)
    # Close notification side panel
    click(notification_button, "Notification icon button")


def click_on_first_asset():
    wait_for_spinner_off()
    check.is_false(is_element_present(table_no_data_text, "No data text"), "No data present")
    scroll_element_into_view(table_first_row_first_cell)
    click_using_java_script(table_first_row_first_cell, "Table first cell")


def get_tag_value(tag_key):
    wait_for_spinner_off()
    wait_for_element_to_visible(tag_cell_asset_details_table, "Tag first cell")
    if get_elements_count_replace_value(tag_values_asset_details_table, tag_key) > 0:
        tag_value = get_element_text_replace_value(tag_values_asset_details_table, tag_key, "Tag Value")
        logger.info(f"Tag key: {tag_key}, Tag value: {tag_value}")
        return tag_value
    else:
        logger.info("No tags found")
        return None


def verify_if_drg_is_available(drg_name):
    click(data_set_filter_button, "Filters")
    click(drg_dropdown_button, "DRG dropdown")
    if is_element_present(drg_show_all_btn, "Show all"):
        click(drg_show_all_btn, "Show all")
    values = get_elements_texts(drg_dropdown_options)
    if drg_name in values:
        logger.info(drg_name + " DRG is available on Costs Dashboard")
        return True
    else:
        logger.info(drg_name + " DRG is not available on Costs Dashboard")
        return False


def wait_until_notification_download_link_available(repeat_count=None):
    if repeat_count is None:
        repeat_count = 30
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        status = check_element_exists(notification_download_link)
        if status:
            logger.info("Notification download link present")
            return True
        else:
            logger.info("Notification download link is not present")
            wait_until_notification_download_link_available(repeat_count)


def validate_current_month_cost_chart(budget=False):
    mouse_over(current_month_cost_circle)
    check.is_in(get_attribute_value(current_month_cost_circle, "class"), "hovered", "Cost data")

    current_month = get_full_name_month_using_index(0)
    check.is_in(get_element_text(cost_chart_current_month), current_month[:3], "Cost chart current month")
    click_costs_bar_chart_using_month(get_data("currentMonthIndex"))

    if budget:
        check.not_equal(get_attribute_value(current_month_budget_data, "aria-label"), "0", "Current month budget data")


def select_cost_by_segment_chart_dropdown(dropdown_value):
    click(cost_by_segment_chart_dropdown, 'Cost by segment chart dropdown')
    wait_for_all_elements_to_load(minichart_dropdown_options, 'Minichart Dropdown Options')
    click_with_replace_value(minichart_dropdown_option, dropdown_value, 'Minichart Dropdown Option')
    wait_for_to_load_costs_page()


def add_and_delete_segment_chart():
    click(add_chart_button, "Add chart")
    select_cost_by_segment_chart_dropdown(get_data("costPerAssetType"))
    check.equal(get_elements_count(mini_charts), 4, "Segment charts")

    click_index_based(segment_chart_close_icon, 0, "First chart close icon")
    check.equal(get_elements_count(mini_charts), 3, "Segment charts")


def configure_segment_charts(dynamic_tag):
    click(segment_charts_configure_button, "Configure segment charts button")
    wait_for_element_to_visible_with_replace_value(cost_by_segment_tags_dropdown, get_data("dynamicTags"),
                                                   "Dynamic tags")
    # Clear all values
    if is_element_present(tags_clear_icon, "Tags clear icon"):
        click(tags_clear_icon, "Clear icon")

    # Select tag
    select_from_drop_down(cost_by_segment_tags_dropdown, dynamic_tag, "Dynamic tags")
    click(save_btn, "Save")


def apply_filter(main_filter, sub_filter, timeout=driver_wait_time):
    click(filters_btn, "Filters")
    click_with_replace_value(filter_dropdown_icon, main_filter, "Main filter")

    filter_option = (By.XPATH, "//span[contains(text(), '" + main_filter + "')]/ancestor::ibm-accordion-item//span["
                                                                           "contains(text(), '" + sub_filter + "')]")
    elem = create_wait(timeout).until(EC.visibility_of_element_located(filter_option))
    elem.click()
    click(filters_apply_button, "Apply")
    wait_for_to_load_costs_page()


def save_dashboard_view():
    click(save_view_btn, "Save View")
    view_name = get_random_int('UIauto')
    type_value(saved_view_name_textbox, view_name, "View name")
    click_index_based(save_btn, 1, "Save")
    check.is_in(get_element_text(notification_message_text), get_data("SuccessMsg"), "Notification")
