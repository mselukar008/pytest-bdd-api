from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_page_operations import *
from locators.common.navigation_page_locator import *


def click_to_Open_menu():
    switch_to_default_content_iframe()
    click_using_java_script(open_main_menu, "Main Menu")


def click_to_Close_menu():
    switch_to_default_content_iframe()
    click_using_java_script(close_main_menu, "Close Menu")



def click_to_Portal():
    click(portal_path, "Portal button")


def navigate_to_mo_launchpad_page():
    click_to_Open_menu()
    click_to_Portal()


# Expands an item on the sidebar menu
def click_to_menu_expandable_option(option_text):
    if is_element_present_replace_value(option_expand_path, option_text):
        scroll_element_into_view_with_replace_value(option_expand_path, option_text)
        wait_before_click_replace_value(option_expand_path, option_text, 'Menu Expandable Option')
    if get_attribute_replace_value(option_expand_path, "aria-expanded", option_text, 'Menu Expandable Option') == "false":
        click_with_replace_value(option_expand_path, option_text, 'Menu Expandable Option')


# Selects an option in the sidebar menu to navigate to it
def click_to_menu_option(option_title):
    if is_element_present_replace_value(side_nav_menu_path, option_title):
        click_with_replace_value(side_nav_menu_path, option_title, 'Menu Option')


# Click a menu option and switch to the child frame
def switch_to_page_frame(option_title):
    click_to_menu_option(option_title)
    switch_to_iframe(mo_iframe_xpath)
    wait_for_spinner_off()


