from helpers.mo_check import mo_check as check
from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_page_operations import upload_file, switch_to_default_content_iframe
from locators.common.login_page_locator import ibm_icon
from locators.common.system_settings_locator import *
from pages.common.login_page import loader_off


# Verify page title header and navigate to Theme Tab
def verify_and_go_to_theme_settings():
    time.sleep(1)
    check.equal(get_element_text(system_settings_header_text), mo_ui_test_data["systemSettingsHeaderText"],
                "System Settings header text")
    click_on_tab_link_button(mo_ui_test_data["themeTitle"])
    check.equal(get_element_text(tab_first_title_text), mo_ui_test_data["themeTitle"], "Theme title text")


# Click on Tab link from Sysstem settings page
def click_on_tab_link_button(tab_name):
    if is_element_present_replace_value(tab_links, tab_name):
        click_with_replace_value(tab_links, tab_name, "Tab link button")


# Enable toggle to hide disabled app links on launchpad page
def hide_disabled_links():
    scroll_element_into_view(disabled_links_toggle_button)
    attr_value = get_attribute_value(disabled_links_toggle_input, "aria-checked")
    logger.info(f"Aria-checked: {attr_value}")
    if attr_value != 'true':
        click(disabled_links_toggle_button, "Disable links toggle button")
        logger.info("Toggle is enabled")
    elif attr_value == 'true':
        logger.info("Toggle is already enabled")


# Click on Save or Cancel button on Theme settings page
def click_on_save_cancel_theme_button(button_name):
    scroll_element_into_view_with_replace_value(theme_save_cancel_button, button_name, True)
    wait_for_spinner_off()
    check.equal(get_element_text(tab_first_title_text), mo_ui_test_data["themeTitle"], "Theme title text")


# Click on Reset Default link on Theme settings page
def click_on_reset_default_link():
    scroll_element_into_view(theme_restore_default_link)
    click(theme_restore_default_link, "Reset default link")
    wait_for_spinner_off()
    # Need static wait, as there is no other element to validate
    time.sleep(2)
    loader_off()
    check.equal(get_element_text(tab_first_title_text), mo_ui_test_data["themeTitle"], "Theme title text")


# Check if Choose logo button is enable or not
def is_choose_logo_button_enable():
    scroll_element_into_view(choose_logo_button)
    return is_element_enable(choose_logo_button, "Choose logo button")


# Choose logo by selecting file using given path
def apply_logo(logo_path):
    upload_file(choose_logo_button, logo_path)
    logger.info("Choosen logo successfully")


# Verify logo preview on Theme settings page
def verify_logo_preview():
    scroll_element_into_view(choose_logo_button)
    return is_element_present(choosen_logo_prev, "Logo image preview")


# Get notification message text on Theme settings page
def get_notification_msg_text():
    wait_for_element_to_visible(notification_msg_text, "Notification message")
    return get_element_text(notification_msg_text)


# Check if Theme dropdown button is enable or not
def is_theme_dropdown_enable():
    scroll_element_into_view(theme_dropdown_button)
    return is_element_enable(theme_dropdown_button, "Theme dropdown button")


# Select Theme color code using given param
def select_theme(theme_val):
    click(theme_dropdown_button, "Theme dropdown button")
    wait_for_element_to_visible_with_replace_value(theme_dropdown_option, theme_val, "Theme option")
    click_with_replace_value(theme_dropdown_option, theme_val, "Theme option")


# Enable platform management checking switch   
def enable_platform_management():
    click_on_tab_link_button(mo_ui_test_data["platformManagementTitle"])
    scroll_element_into_view(platform_management_switch)
    if not is_checkbox_checked(platform_management_switch, 'Platform Management Switch'):
        click_checkbox(platform_management_switch, True, 'Platform Management Switch')
        check.is_in(mo_ui_test_data['platformManagementOnModalTitle'],
                    get_element_text(platform_management_modal_confirm_title), 'Platform Management On Modal Title')
        click(platform_management_modal_confirm_btn, 'Confirm Enable Platform Management')
        check.is_in(mo_ui_test_data["platformManagementEnabledMsg"],
                    get_element_text(platform_management_toast_msg_txt), 'Platform Management Enabled Success Msg')
        click(platform_management_toast_close_btn, 'Toast Close Button')


# Disable platform management unchecking switch   
def disable_platform_management():
    click_on_tab_link_button(mo_ui_test_data["platformManagementTitle"])
    scroll_element_into_view(platform_management_switch)
    if is_checkbox_checked(platform_management_switch, 'Platform Management Switch'):
        click_checkbox(platform_management_switch, False, 'Platform Management Switch')
        check.is_in(mo_ui_test_data['platformManagementOffModalTitle'],
                    get_element_text(platform_management_modal_confirm_title), 'Platform Management Off Modal Title')
        click(platform_management_modal_confirm_btn, 'Confirm Disable Platform Management')
        check.is_in(mo_ui_test_data["platformManagementDisabledMsg"],
                    get_element_text(platform_management_toast_msg_txt), 'Platform Management Disabled Success Msg')
        click(platform_management_toast_close_btn, 'Toast Close Button')


def is_brand_textbox_present():
    return is_element_present(brand_textbox_button, "Brand Textbox button")


def enter_brand_name(brand_name):
    type_value_and_enter(brand_textbox_button, brand_name, "Brand Name")


def enable_notifications():
    switch_to_default_content_iframe()
    click(ibm_icon, "User Icon")
    click(notification_preferences_link, "Notification Preferences")
    wait_for_spinner_off()
    select_from_drop_down(language_dropdown, mo_ui_test_data["languageEngInd"], "Language")
    click(save_btn, "Save")
    wait_for_spinner_off()
    check.is_in(get_element_text(notification_message), mo_ui_test_data["notificationSuccessMsg"],
                "Notification message")