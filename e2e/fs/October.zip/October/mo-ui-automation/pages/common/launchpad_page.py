import pytest

from helpers.mo_check import mo_check as check
from helpers.mo_element_operations import *
from helpers.mo_json_utils import *
from locators.aiops.health_locator import *
from locators.assetlib.assetlibrary_locator import *
from locators.common.launchpad_page_locator import *
from pages.common.mo_navigation_page import *


# Verify mo Home/Launchpad page
def verify_home_page():
    assert is_element_present(app_title, "Application title") == True
    check.equal(get_element_text(hero_title_text), mo_ui_test_data["heroTitleText"], "Hero title text")


# Verify the names of all 6 tiles upon logging to dashboard
def verify_first_6_tiles():
    count = 0
    count = count + 1 if check.is_true(is_element_present(manage_provider_text, "Manage Provider"),
                                       "Manage Provider Card") else count
    count = count + 1 if check.is_true(is_element_present(manage_iam_text, "Manage IAM"), "Manage IAM Card") else count
    count = count + 1 if check.is_true(is_element_present(manage_user_access_text, "Manage user access"),
                                       "Manage user access Card") else count
    count = count + 1 if check.is_true(is_element_present(manage_provider_account_text, "Manage provider accounts"),
                                       "Manage provider accounts Card") else count
    count = count + 1 if check.is_true(
        is_element_present(manage_currency_conversion_text, "Manage currency conversion"),
        "Manage currency connversion Card") else count
    count = count + 1 if check.is_true(is_element_present(view_audit_log_text, "View audit logs"),
                                       "Manage View Audit log Card") else count
    if count == 6:
        logger.info(f"ALl {count} cards are available")
        return True
    logger.info(f"Only {count} cards are available")
    return False


# Click on Show all tasks link
def click_on_show_all_tasks_link():
    if is_element_present(show_all_tasks_link, "Show all tasks link"):
        click(show_all_tasks_link, "Show all tasks link")


# Verify the names of all 11 tiles after expanding the "Show all task" link
def verify_next_11_tiles():
    count = 0
    count = count + 1 if check.is_true(is_element_present(archive_audit_logs_text, "Archive audit logs"),
                                       "Archive audit logs Card") else count
    count = count + 1 if check.is_true(is_element_present(manage_budget, "Manage budget"),
                                       "Manage budget Card") else count
    count = count + 1 if check.is_true(is_element_present(view_budget_text, "View budget"),
                                       "View budget Card") else count
    count = count + 1 if check.is_true(is_element_present(order_new_services_text, "Order new services"),
                                       "Order new services Card") else count
    count = count + 1 if check.is_true(is_element_present(review_current_cart_text, "Review current cart"),
                                       "Review current cart Card") else count
    count = count + 1 if check.is_true(is_element_present(track_order_status_text, "Track order status"),
                                       "Track order status Card") else count
    count = count + 1 if check.is_true(is_element_present(view_ordered_service_text, "View ordered services"),
                                       "View ordered services Card") else count
    count = count + 1 if check.is_true(is_element_present(review_pending_orders_text, "Review pending orders"),
                                       "Review pending orders Card") else count
    count = count + 1 if check.is_true(is_element_present(manage_catalog_text, "Manage catalog"),
                                       "Manage catalog Card") else count
    count = count + 1 if check.is_true(is_element_present(manage_approval_policies_text, "Manage approval policies"),
                                       "Manage approval policies Card") else count
    count = count + 1 if check.is_true(is_element_present(manage_operation_policies_text, "Manage operation policies"),
                                       "Manage operation policies Card") else count
    if count == 11:
        logger.info(f"ALl {count} cards are available")
        return True
    logger.info(f"Only {count} cards are available")
    return False


# Click on Show less tasks link
def click_on_show_less_tasks_link():
    if is_element_present(show_less_tasks_link, "Show less tasks link"):
        click(show_less_tasks_link, "Show less tasks link")


# Check if Disabled app links are present or not
def is_disabled_app_links_present():
    links_count = get_elements_count(disabled_app_links)
    if links_count > 0:
        links_list = get_elements_texts(disabled_app_links)
        logger.info(f"Disabled app links are present. App links are: {links_list}")
        return True
    else:
        logger.info("Disabled app links are NOT present.")
        return False


# Validate current url substring
def validate_current_url(url):
    check.is_in(url, get_current_url(), "Current URL")


# Get Theme color code from Mini tiles
def get_mini_tile_color_code():
    wait_for_element_to_visible(first_mini_tile, "Page mini tile")
    color_code = get_css_attribute_value(first_mini_tile, "background-color")
    logger.info(f"Current theme applied : {color_code}")
    return color_code


# Click on Manage IAM tasks link
def click_on_mo_manage_iam_tile_link():
    if is_element_present(manage_iam_text, "Manage IAM link"):
        click(manage_iam_text, "Manage IAM link")
        check.is_true(is_element_present(iam_access_text, "IAM: Identity and Access Management"), "IAM title")
    navigate_to_mo_launchpad_page()


def click_on_mo_manage_user_access_tile_link():
    if is_element_present(manage_user_access_text, " Manage user access"):
        click(manage_user_access_text, " Manage user access")
        check.is_true(is_element_present(user_access_text, "User Access Management"), "User Access Management title")
    navigate_to_mo_launchpad_page()


def click_on_mo_manage_provider_account_tile_link():
    if is_element_present(manage_provider_account_text, " Manage provider accounts"):
        click(manage_provider_account_text, "Manage provider accounts")
        check.is_true(is_element_present(account_management_text, "Account Management"), "Account Management title")
    navigate_to_mo_launchpad_page()


def click_on_mo_manage_provider_tile_link():
    if is_element_present(manage_provider_text, "Manage provider"):
        click(manage_provider_text, "Manage provider")
        check.is_true(is_element_present(provider_text, "Provider"), "Provider title")
    navigate_to_mo_launchpad_page()


def click_on_mo_manage_currency_conversion_tile_link():
    if is_element_present(manage_currency_conversion_text, "Manage currency conversion"):
        click(manage_currency_conversion_text, "Manage currency conversion")
        check.is_true(is_element_present(currency_conversion_text, "Currency Conversion"), "Currency Conversion title")
    navigate_to_mo_launchpad_page()


def click_on_mo_manage_view_audit_log_tile_link():
    if is_element_present(view_audit_log_text, "View audit logs"):
        click(view_audit_log_text, "View audit logs")
        check.is_true(is_element_present(view_audit_logs_text, "Audit Logs"), "Audits title")
    navigate_to_mo_launchpad_page()
    click_on_show_less_tasks_link()


def click_on_mo_ui_test_data_manage_archive_audit_logs_tile_link():
    if is_element_present(archive_audit_logs_text, "Archive audit logs"):
        click(archive_audit_logs_text, "Archive audit logs")
        check.is_true(is_element_present(archive_audit_text, "Audit Archives"), "Audit Archives title")
    navigate_to_mo_launchpad_page()
    click_on_show_less_tasks_link()


def click_on_mo_ui_test_data_manage_budget_tile_link():
    if is_element_present(manage_budget, "Manage budget"):
        click(manage_budget, "Manage budget")
        check.is_true(is_element_present(check_budgetary_unit_text, "Budgetary Units"), "Budgetary Units text")
    navigate_to_mo_launchpad_page()
    click_on_show_less_tasks_link()


def click_on_mo_ui_test_data_view_budget_text_tile_link():
    if is_element_present(view_budget_text, "View budget"):
        click(view_budget_text, "View budget")
        check.is_true(is_element_present(check_budget_policy_text, "Budget Policies"), "Budget Policies text")
    navigate_to_mo_launchpad_page()
    click_on_show_less_tasks_link()


def click_on_mo_ui_test_data_order_new_services_text_tile_link():
    if is_element_present(order_new_services_text, "Order new services"):
        click(order_new_services_text, "Order new services")
        switch_to_iframe(mo_iframe_xpath)
        check.is_true(is_element_present(catalog_text, "Catalog"), "Catalog title")
        switch_to_default_content_iframe()
    navigate_to_mo_launchpad_page()
    click_on_show_less_tasks_link()


def click_on_mo_ui_test_data_review_current_cart_text_tile_link():
    if is_element_present(review_current_cart_text, "Review current cart"):
        click(review_current_cart_text, "Review current cart")
        switch_to_iframe(mo_iframe_xpath)
        check.is_true(is_element_present(cart_text, "Carts"), "Carts title")
        switch_to_default_content_iframe()
    navigate_to_mo_launchpad_page()
    click_on_show_less_tasks_link()


def click_on_mo_ui_test_data_track_order_status_text_tile_link():
    if is_element_present(track_order_status_text, "Track order status"):
        click(track_order_status_text, "Track order status")
        switch_to_iframe(mo_iframe_xpath)
        check.is_true(is_element_present(order_history_text, "Order History"), "Order History title")
        switch_to_default_content_iframe()
    navigate_to_mo_launchpad_page()
    click_on_show_less_tasks_link()


def click_on_mo_ui_test_data_view_ordered_service_text_tile_link():
    if is_element_present(view_ordered_service_text, "View ordered services"):
        click(view_ordered_service_text, "View ordered services")
        switch_to_iframe(mo_iframe_xpath)
        check.is_true(is_element_present(order_service_text, "Ordered Services"), "Ordered Services title")
        switch_to_default_content_iframe()
    navigate_to_mo_launchpad_page()
    click_on_show_less_tasks_link()


def click_on_mo_ui_test_data_review_pending_orders_text_tile_link():
    if is_element_present(review_pending_orders_text, "Review pending orders"):
        click(review_pending_orders_text, "Review pending orders")
        switch_to_iframe(mo_iframe_xpath)
        check.is_true(is_element_present(order_text, "Orders"), "Orders title")
        switch_to_default_content_iframe()
    navigate_to_mo_launchpad_page()
    click_on_show_less_tasks_link()


def click_on_mo_ui_test_data_manage_catalog_text_tile_link():
    if is_element_present(manage_catalog_text, "Manage catalog"):
        click(manage_catalog_text, "Manage catalog")
        switch_to_iframe(mo_iframe_xpath)
        check.is_true(is_element_present(catalog_management_text, "Catalog Management"), "Catalog Management title")
        switch_to_default_content_iframe()
    navigate_to_mo_launchpad_page()
    click_on_show_less_tasks_link()


def click_on_mo_ui_test_data_manage_approval_policies_text_tile_link():
    if is_element_present(manage_approval_policies_text, "Manage approval policies"):
        click(manage_approval_policies_text, "Manage approval policies")
        switch_to_iframe(mo_iframe_xpath)
        check.is_true(is_element_present(approval_policies_text, "Approval Policies"), "Approval Policies title")
        switch_to_default_content_iframe()
    navigate_to_mo_launchpad_page()
    click_on_show_less_tasks_link()


def click_on_mo_ui_test_data_manage_operation_policies_tile_link():
    if is_element_present(manage_operation_policies_text, "Manage operation policies"):
        click(manage_operation_policies_text, "Manage operation policies")
        switch_to_iframe(mo_iframe_xpath)
        check.is_true(is_element_present(operation_policies_text, "Operation Policies"), "Operation Policies")
        switch_to_default_content_iframe()
    navigate_to_mo_launchpad_page()
    click_on_show_less_tasks_link()


def click_on_topology_link():
    # click on topology link on launchpad
    if is_element_present(topology_link, "Topology link"):
        click(topology_link, "Topology link")
        check.is_true(is_element_present(topology_title_text, "Topology title text"), "Topology Page title")
    navigate_to_mo_launchpad_page()


def click_on_topology_from_aiops_link():
    # click on topology tile from AIOps link on launchpad
    if is_element_present(AIOps_link, "AIOps link"):
        click(AIOps_link, "AIOps link")
        check.is_true(is_element_present(topology_tile, "Topology tile"), "Topology tile text")
        click(topology_tile, "Topology tile")
        check.is_true(is_element_present(topology_title_text, "Topology title text"), "Topology Page title")
    navigate_to_mo_launchpad_page()


def click_on_application_health_from_aiops_link():
    # click on Application health tile from AIOps link on launchpad
    if is_element_present(AIOps_link, "AIOps link"):
        click(AIOps_link, "AIOps link")
        check.is_true(is_element_present(application_health_tile, "Application Health tile"), "Application Health text")
        click(application_health_tile, " Application Health")
        check.is_true(is_element_present(health_title_text, "Health title text"), "Health page title")
    #navigate_to_mo_launchpad_page()


def click_on_asset_library_link():
    # click on Asset Library link on launchpad
    if is_element_present(asset_library_link, "Asset Library link"):
        click(asset_library_link, "Asset Library link")
        check.is_true(is_element_present(asset_library_title_text, "Asset Library text"), "Asset Library Page title")
    navigate_to_mo_launchpad_page()


def verify_landing_zone_requisites():
    if not is_element_present(manage_landzone_tile, "Manage Landing Zone Tile") and not is_element_present(dashboard_landzone_tile, "Dashboard Landing Zone Tile"):
        pytest.exit("Landing Zone Feature not enabled in Tenant")
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    try:
        click_to_menu_expandable_option(mo_ui_test_data["LandingZoneBtnText"])
    except:
        pytest.exit("Landing Zone Feature not enabled in Tenant")
    click_to_Close_menu()
