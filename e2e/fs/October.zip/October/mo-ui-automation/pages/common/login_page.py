import time

from helpers.mo_api_utils import get_googleauth_passcode
from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_env import browser
from locators.common.launchpad_page_locator import app_title
from locators.common.navigation_page_locator import option_expand_path, open_main_menu
from mo_encryption_decryption import decrypt_password
from locators.common.login_page_locator import *
from helpers.mo_page_operations import switch_to_default_content_iframe

# from helpers.mo_ui_test_data_encript_decript_util import *
# import  re

# Login using Non-IBM/Non-Kyndryl ID
from pages.common.mo_navigation_page import click_to_Open_menu, click_to_Close_menu


def login_using_nonw3id(password, secret):
    counter = 15
    type_value(password_path, password, "password")
    click(sign_in_path, "Sign-In")
    if is_element_present(non_kyndryl_otp_textbox, "OTP textbox"):
        passcode = get_googleauth_passcode(secret)
        type_value(non_kyndryl_otp_textbox, passcode, "OTP")
        click(non_kyndryl_otp_verify_button, "Submit")
        while counter > 0:
            if is_element_present(non_kyndryl_otp_invalid_msg, "Error msg"):
                logger.info("OTP has been used already; Waiting for 60 seconds to generate next OTP")
                time.sleep(60)
                passcode = get_googleauth_passcode(secret)
                type_value(non_kyndryl_otp_textbox, passcode, "OTP")
                click(non_kyndryl_otp_verify_button, "Submit")
            if is_element_not_present(non_kyndryl_otp_invalid_msg, "Error msg", 60):
                break
            else:
                counter -= 1


# Login using Kyndyl ID
def login_using_kynid(username, password, secret):
    counter = 15
    if is_element_present(kyn_username_textbox, "Username"):
        type_value(kyn_username_textbox, username, "username")
        click(next_btn, "Next")
        type_value(kyn_pwd_textbox, password, "password")
        click(verify_btn, "Verify")
    else:
        return False
    if is_element_present(password_reset_reminder, "Remind me later", timeout=7):
        click(password_reset_reminder, "Password reset reminder")
    if is_element_present(authenticator_type_btn, "Authenticator type", timeout=7):
        click(authenticator_type_btn, "Select Google Authenticator")
    if is_element_present(kyn_otp_textbox, "OTP textbox"):
        passcode = get_googleauth_passcode(secret)
        type_value(kyn_otp_textbox, passcode, "OTP textbox")
        click(verify_btn, "Verify")
        while counter > 0:
            if is_element_present(kyn_otp_invalid_msg, "Error msg"):
                logger.info("The passcode you entered is incorrect; The OTP has already been used; Waiting for 60 "
                            "seconds to generate next OTP")
                if os.environ.get("JOB_INDEX"):
                    job_id = int(os.environ.get("JOB_INDEX")) + 1
                    logger.info("Waiting for otp on Job " + job_id - 1)
                    time.sleep(30 * job_id)
                else:
                    time.sleep(30)
                passcode = get_googleauth_passcode(secret)
                type_value(kyn_otp_textbox, passcode, "OTP textbox")
                click(verify_btn, "Verify")
            if is_element_not_present(kyn_otp_invalid_msg, "Error msg", 25):
                break
            else:
                counter -= 1
    else:
       return False
    return True


def log_into_server(server_url, username, password, secret_kyn, secret_non_kyn):
    logger.info("---------------------Login to the Application---------------------\n") 
    login_element_displayed = False
    # if os.environ.get("mo_ui_test_data_password"):
    #    decrypted_password = os.environ.get("mo_ui_test_data_password")
    # else:
    decrypted_password = decrypt_password(password)
    decrypted_secret_kyn = decrypt_password(secret_kyn)
    if browser in ["Firefox", "Chrome", "Ie", "Edge"]:
        load_url(server_url)
    if "kyndryl.com" in username: # and is_element_present(ibm_id_btn, "Sign in with IBMid"):
        login_element_displayed = True
        if is_element_present(kyndryl_id_btn, "Sign in with Kyndryl ID"):
            click(kyndryl_id_btn, "Sign in with Kyndryl ID")
            login_using_kynid(username, decrypted_password, decrypted_secret_kyn)
        # click(ibm_id_btn, "Sign in with IBMid")
        # type_value(username_path, username, "username")
        # click(continue_btn, "Continue")
        else:
            login_using_kynid(username, decrypted_password, decrypted_secret_kyn)
        # Verify if Sign In Page is displayed correctly
    else:
        if is_element_present(page_header, "Sign In Header"):
            logger.info("Sign In Page is Displayed")
        else:
            redirection_url = server_url + users_data["mo_ui_test_data_sign_in_direct_url"]
            # logger.info("Sign In Page is not Displayed, navigating with redirect url : " + redirection_url)
            # load_url(redirection_url)
        if is_element_present(username_path, "username"):
            login_element_displayed = True
            type_value(username_path, username, "username")
            click(continue_btn, "Continue")
            if "kyndryl.com" in username:
                login_using_kynid(username, decrypted_password, secret_kyn)
            else:
                login_using_nonw3id(decrypted_password, secret_non_kyn)
        else:
            if "kyndryl.com" not in username:
                if is_element_present(ibm_id_btn, "Sign in with IBMid"):
                    login_element_displayed = True
                    click(ibm_id_btn, "Sign in with IBMid")
                    type_value(username_path, username, "username")
                    click(continue_btn, "Continue")
                    if "kyndryl.com" in username:
                        login_using_kynid(username, decrypted_password, secret_kyn)
                    else:
                        login_using_nonw3id(decrypted_password, secret_non_kyn)
            elif is_element_present(kyndryl_id_btn, "Sign in with Kyndryl ID"):
                # click(kyndryl_id_btn, "Sign in with Kyndryl ID")
                login_element_displayed = login_using_kynid(username, decrypted_password, decrypted_secret_kyn)
            elif is_element_present(kyndryl_w3id_btn, "Sign in with Kyndryl w3id"):
                click(kyndryl_w3id_btn, "Sign in with Kyndryl w3id")
                login_element_displayed = login_using_kynid(username, decrypted_password, decrypted_secret_kyn)

            else:
                login_element_displayed = login_using_kynid(username, decrypted_password, decrypted_secret_kyn)
        if not login_element_displayed:
           return False
    loader_off()
    default_time = 30
    if is_element_present(i_accept_btn, "I accept", default_time):
        click_using_java_script(i_accept_btn, "I accept", 30)
    return True
    #for i in range(5):
    #   if is_element_present(i_accept_btn, "I accept", default_time):
    #        if i != 0:
    #            reload_page()
    #        click_using_java_script(i_accept_btn, "I accept", 30)
    #        default_time = 10
    #    else:
    #        break


def logout():
    wait_for_spinner_off()
    switch_to_default_content_iframe()
    click(ibm_icon, "User Icon")
    scroll_element_into_view(signout_btn)
    click_using_java_script(signout_btn, "Sign Out")


def loader_off():
    wait_for_element_to_invisible(loader_text, "Loading...")


def verify_em_link(app_url):
    for i in range(2):
        if is_element_present(open_main_menu, "Main Menu"):
            click_to_Open_menu()
            if is_element_present_replace_value(option_expand_path, mo_ui_test_data["enterpriseMarketplaceBtnText"]):
                click_to_Close_menu()
                break
            else:
                driver.get("https://" + app_url)
                logger.info(f"Load URL: https://{app_url}")
        else:
            driver.get("https://" + app_url)
            logger.info(f"Load URL: https://{app_url}")


def load_base_page(server_url):
    app_url = server_url
    uname = users_data['main_user']['user']
    password = users_data['main_user']['password']
    secret_non_kyn = users_data['main_user']['secret']
    secretkyn = mo_secret_kyn
    if os.environ.get("Environment"):
        app_url = os.environ.get("Environment")
        uname = os.environ.get("Email")
        password = os.environ.get("Password")
        secretkyn = os.environ.get("SecretKYN")
        load_url(app_url)
        loader_off()
        verify_em_link(app_url)
        if is_element_present(i_accept_btn, "I accept", 30):
            click_using_java_script(i_accept_btn, "I accept", 30)
        elif is_element_present(app_title, "Application Title"):
            logger.info("Application is logged in")
        else:
            log_into_server(app_url, uname, password, secretkyn, secret_non_kyn)
    else:
        load_url(app_url)
        loader_off()
        verify_em_link(app_url)
        if is_element_present(i_accept_btn, "I accept", 30):
            click_using_java_script(i_accept_btn, "I accept", 30)
        elif is_element_present(app_title, "Application Title"):
            logger.info("Application is logged in")
        else:
            log_into_server(app_url, uname, password, secretkyn, secret_non_kyn)
