

from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_json_utils import get_data, get_value
from helpers.mo_page_operations import wait_for_spinner_on
from pages.store.mo_store_utils import get_filtered_data, get_locator
from locators.common.platform_management_page_locator import *
from helpers.mo_check import mo_check as check
from ui_config import platform_mngmt_data
from tests.common_test import get_random_int

# Platform Management Constants
PF_ORGANIZATION_KEY = 'Organization'
PF_ORGANIZATION_EDIT_KEY = 'Edit Organization'
PF_TEAM_KEY = 'Team'
PF_TEAM_EDIT_KEY = 'Edit Team'
PF_USER_KEY = 'User'


def platform_mngmt_fill_parameters(data_key, confirm_callback=None):
    data_items = get_data(data_key)
    for key, data in data_items.items():
        get_filtered_data(data, key)
        if data.get('with_confirm') and confirm_callback:
            click(platform_mngmt_switch_confirm_modal_btn, 'Switch Confirm Button')
            confirm_callback()
            click(platform_mngmt_toast_close_btn, 'Toast Close Button')


def platform_mngmt_click_side_tab(tab_name, desc):
    wait_for_spinner_off()
    click_with_replace_value(platform_mngmt_side_tab, tab_name, desc)
    

def platform_mngmt_click_settings_button():
    explicit_wait(5)
    click(platform_mngmt_settings_btn, 'Settings Button')


def platform_mngmt_add_organization(org_data_key=PF_ORGANIZATION_KEY):
    click_organizations_tab()
    click(platform_mngmt_add_new_btn, 'Add New Button')
    explicit_wait(2)
    click_with_replace_value(platform_mngmt_add_new_item, 'Add Organization', 'Add Organization Item Button')
    check.is_in(platform_mngmt_data['addOrganizationPanelTitle'], get_element_text(platform_mngmt_slider_title), 'Add Organization Slider Panel Title')
    platform_mngmt_fill_parameters(org_data_key)
    click(platform_mngmt_slider_primary_btn, 'Add Organization Next Button')
    wait_for_spinner_off()
    check.is_in(platform_mngmt_data['orgCreatedSuccessMsg'], get_element_text(platform_mngmt_org_created_success_msg), 'Organization Created Success Msg')
    wait_for_spinner_off()
    
    
def platform_mngmt_add_member_to_organization(username):
    check.is_in(platform_mngmt_data['addMembersToOrgPanelTitle'], get_element_text(platform_mngmt_slider_title), 'Add Organization Members Slider Panel Title')
    with_invite = _add_member_main_flow(username)
    if not with_invite:
        check.is_in(platform_mngmt_data['memberAddedToOrgSuccessMsg'], get_element_text(platform_mngmt_toast_msg_txt), 'Member Added to Organization Msg')
    else: 
        check.is_in(platform_mngmt_data['memberInvitedToOrgSuccessMsg'], get_element_text(platform_mngmt_toast_msg_txt), 'Member Invited to Organization Msg')
    click(platform_mngmt_toast_close_btn, 'Toast Close Button')
    wait_for_spinner_off()


def _add_member_main_flow(username):
    type_value(platform_mngmt_add_member_input_dropdown, username, 'Search Member Input')
    explicit_wait(5)
    wait_for_spinner_off()
    with_invite = False
    # If account already added in the tenant only select the first user
    if is_element_not_present(platform_mngmt_invite_new_member_input, 'Add or Invite New Member Input Msg'):
        click(platform_mngmt_first_member_option_input, 'First User on Add Member Input')
    else:
        # User is new on the tenant, adds and invite user
        press_enter_key(platform_mngmt_add_member_input_dropdown, 'Search Member Input')
        with_invite = True
    wait_for_element_to_visible(platform_mngmt_slider_member_selected_row, 'At least one email in selection')
    click(platform_mngmt_add_member_select_all_btn, 'Select All Members Button')
    explicit_wait(2)
    click(platform_mngmt_slider_primary_btn, 'Add Members Button')
    wait_for_spinner_off()
    return with_invite


def platform_mngmt_validate_organization_values_in_org_details(org_name):
    check.is_in(get_element_text(platform_mngmt_item_title), org_name, 'Organization Name Title')
    

def platform_mngmt_validate_organization_in_settings(org_data_key=PF_ORGANIZATION_KEY):
    # Wait for all elements loaded
    wait_for_element_to_invisible(platform_mngmt_loading_text, 'Loading indicator')
    # Data
    org_data = get_data(org_data_key)
    # Details
    org_name_label = 'Organization Name'
    check.is_in(get_element_text_replace_value(platform_mngmt_item_details_value_txt, org_name_label, org_name_label), 
                get_value(org_data, 'Name'), org_name_label)
    desc_label = 'Description'
    check.is_in(get_element_text_replace_value(platform_mngmt_item_details_value_txt, desc_label, desc_label), 
                get_value(org_data, desc_label), desc_label)
    # Restrictions
    add_new_member_label = 'Anyone can add new members'
    check.equal(is_checkbox_checked(platform_mngmt_item_restrictions_checkbox, add_new_member_label, add_new_member_label), 
                get_value(org_data, add_new_member_label) =='On', add_new_member_label)
    create_team_label = 'Anyone can create teams'
    check.equal(is_checkbox_checked(platform_mngmt_item_restrictions_checkbox, create_team_label, create_team_label), 
                get_value(org_data, create_team_label)=='On', create_team_label)
    private_org_label = 'Private'
    visibility_value = get_value(org_data, 'Visibility')
    check.equal(is_checkbox_checked(platform_mngmt_item_restrictions_checkbox, private_org_label, private_org_label), 
                visibility_value == 'Private' or visibility_value == 'On', private_org_label)
    
    
def platform_mngmt_edit_organization(org_data_key=PF_ORGANIZATION_EDIT_KEY):
    click(platform_mngmt_edit_item_btn, 'Edit Organization Button')
    platform_mngmt_fill_parameters(org_data_key, _platform_mngmt_edit_organization_confirm_msg)
    click(platform_mngmt_update_org_btn, 'Update Organization Button')
    _platform_mngmt_edit_organization_confirm_msg()
    click(platform_mngmt_toast_close_btn, 'Toast Close Button')
    

def _platform_mngmt_edit_organization_confirm_msg():
    check.is_in(platform_mngmt_data['orgUpdatedSuccessMsg'] ,get_element_text(platform_mngmt_toast_msg_txt), 'Updated Organization Success Msg')


def platform_mngmt_select_organization_details(org_name):
    click_organizations_tab()
    platform_mngmt_search_in_table(org_name)
    platform_mngmt_table_row_option('View details')
    
    
def platform_mngmt_delete_organization(org_name):
    click_using_java_script(platform_mngmt_delete_item_btn, 'Delete Organization Button')
    check.is_in(platform_mngmt_data['modalDeleteOrgTitle'], get_element_text(platform_mngmt_modal_default_header), 'Modal Delete Org Title')
    type_value(platform_mngmt_delete_item_name_input, org_name, 'Confirm Delete Organization Name')
    click(platform_mngmt_modal_danger_btn, 'Confirm Delete')
    check.is_in(platform_mngmt_data['orgDeletedSuccessMsg'], get_element_text(platform_mngmt_toast_msg_txt), 'Organization Deleted Success Msg')
    click(platform_mngmt_toast_close_btn, 'Toast Close Button')

def platform_mngmt_validate_member_added(username, with_invite=False):
    # Click on "Members" tab if user already registered on the tenant
    if not with_invite:
        click_members_tab()
        check.is_true(is_element_present_replace_value(platform_mngmt_member_row, username), f'Member {username} present')
    else:
        # If member is new check "Pending Invitations" tab
        platform_mngmt_validate_invite_pending(username)


def platform_mngmt_validate_invite_pending(username):
    click_pending_invitations_tab()
    check.is_true(is_element_present_replace_value(platform_mngmt_invite_row, username), f'Member {username} present')    
    
    
def platform_mngmt_add_team(team_data_key=PF_TEAM_KEY):
    click_teams_tab()
    click(platform_mngmt_add_new_btn, 'Add New Button')
    explicit_wait(2)
    click_with_replace_value(platform_mngmt_add_new_item, 'Add Team', 'Add Team Item Button')
    check.is_in(platform_mngmt_data['addTeamPanelTitle'], get_element_text(platform_mngmt_slider_title), 'Add Team Slider Panel Title')
    platform_mngmt_fill_parameters(team_data_key)
    click(platform_mngmt_slider_primary_btn, 'Add Team Next Button')
    wait_for_spinner_off()
    check.is_in(platform_mngmt_data['teamCreatedSuccessMsg'], get_element_text(platform_mngmt_team_created_success_msg), 'Team Created Success Msg')
    wait_for_spinner_off()
    
    
def platform_mngmt_add_member_to_team(username):
    check.is_in(platform_mngmt_data['addMembersToTeamPanelTitle'], get_element_text(platform_mngmt_slider_title), 'Add Team Members Slider Panel Title')
    with_invite = _add_member_main_flow(username)
    if not with_invite:
        check.is_in(platform_mngmt_data['memberAddedToTeamSuccessMsg'], get_element_text(platform_mngmt_toast_msg_txt), 'Member Added to Organization Msg')
    else:
        check.is_in(platform_mngmt_data['memberInvitedToTeamSuccessMsg'], get_element_text(platform_mngmt_toast_msg_txt), 'Member Invited to Organization Msg')
    click(platform_mngmt_toast_close_btn, 'Toast Close Button')
    wait_for_spinner_off()
 
 
def platform_mngmt_validate_team_values_in_team_details(team_name, org_name):
    check.is_in(get_element_text(platform_mngmt_item_title), team_name, 'Team Name Title')   
    check.is_in(get_element_text(platform_mngmt_team_org_name_title), org_name, 'Team Organization Name Title')   


def platform_mngmt_validate_team_in_settings(team_data_key=PF_TEAM_KEY):
    # Wait for all elements loaded
    wait_for_element_to_invisible(platform_mngmt_loading_text, 'Loading indicator')
    # Data
    team_data = get_data(team_data_key)
    # Details
    org_name_label = 'Team Name'
    check.is_in(get_element_text_replace_value(platform_mngmt_item_details_value_txt, org_name_label, org_name_label), 
                get_value(team_data, 'Name'), org_name_label)
    desc_label = 'Description'
    check.is_in(get_element_text_replace_value(platform_mngmt_item_details_value_txt, desc_label, desc_label), 
                get_value(team_data, desc_label), desc_label)
    # Restrictions
    add_new_member_label = 'Anyone can add new members'
    check.equal(is_checkbox_checked(platform_mngmt_item_restrictions_checkbox, add_new_member_label, add_new_member_label), 
                get_value(team_data, add_new_member_label) =='On', add_new_member_label)
    private_org_label = 'Private'
    visibility_value = get_value(team_data, 'Visibility')
    check.equal(is_checkbox_checked(platform_mngmt_item_restrictions_checkbox, private_org_label, private_org_label), 
                visibility_value == 'Private' or visibility_value == 'On', private_org_label)
    
    
def platform_mngmt_edit_team(org_data_key=PF_TEAM_EDIT_KEY):
    click(platform_mngmt_edit_item_btn, 'Edit Team Button')
    platform_mngmt_fill_parameters(org_data_key, _platform_mngmt_edit_team_confirm_msg)
    click(platform_mngmt_update_org_btn, 'Update Team Button')
    _platform_mngmt_edit_team_confirm_msg()
    click(platform_mngmt_toast_close_btn, 'Toast Close Button')
    

def _platform_mngmt_edit_team_confirm_msg():
    check.is_in(platform_mngmt_data['teamUpdatedSuccessMsg'] ,get_element_text(platform_mngmt_toast_msg_txt), 'Updated Team Success Msg')
    

def platform_mngmt_select_team_details(team_name):
    click_teams_tab()
    platform_mngmt_search_in_table(team_name)
    platform_mngmt_table_row_option('View details')
    
    
def platform_mngmt_delete_team(team_name):
    click_using_java_script(platform_mngmt_delete_item_btn, 'Delete Team Button')
    check.is_in(platform_mngmt_data['modalDeleteTeamTitle'], get_element_text(platform_mngmt_modal_default_header), 'Modal Delete Team Title')
    type_value(platform_mngmt_delete_item_name_input, team_name, 'Confirm Delete Title Name')
    click(platform_mngmt_modal_danger_btn, 'Confirm Delete')
    check.is_in(platform_mngmt_data['teamDeletedSuccessMsg'], get_element_text(platform_mngmt_toast_msg_txt), 'Title Deleted Success Msg')
    click(platform_mngmt_toast_close_btn, 'Toast Close Button')


def platform_mngmt_generate_random_email():
    return f"{get_random_int('testauto')}@test.com"


def platform_mngmt_add_user(user_data_key=PF_USER_KEY):
    platform_mngmt_click_side_tab('Users', 'Users Tab')
    click(platform_mngmt_add_new_btn, 'Add New Button')
    explicit_wait(2)
    click_with_replace_value(platform_mngmt_add_new_item, 'Invite Users', 'Add User Item Button')
    check.is_in(platform_mngmt_data['addUserPanelTitle'], get_element_text(platform_mngmt_slider_title), 'Add User Slider Panel Title')
    user_data = get_data(user_data_key)
    platform_mngmt_fill_parameters(user_data_key)
    explicit_wait(2)
    wait_for_spinner_off()
    # User is new on the tenant, adds and invite user
    # press_enter_key(get_locator(user_data['Emails']), 'Search Emails Input')
    # wait_for_element_to_visible(platform_mngmt_slider_member_selected_row, 'At least one email in selection')
    # click(platform_mngmt_add_member_select_all_btn, 'Select All Members Button')
    # explicit_wait(2)
    #click(platform_mngmt_slider_primary_btn, 'Add User Confirm Button')
    check.is_in(platform_mngmt_data['userCreatedSuccessMsg'], get_element_text(platform_mngmt_toast_msg_txt), 'User Created Success Msg')
    click(platform_mngmt_toast_close_btn, 'Toast Close Button')
 

def platform_mngmt_search_in_table(value):
    click(platform_mngmt_table_open_search_btn, 'Table Search Icon Button')
    type_value_and_enter(platform_mngmt_table_search_input, value, 'Table Search Input')
    wait_for_spinner_on()
    wait_for_spinner_off()
    is_element_present(platform_mngmt_table_first_row_col_txt, value)
    
    
def platform_mngmt_table_row_option(option):
    click(platform_mngmt_table_row_options_btn, 'Table Options Button')
    click_with_replace_value(platform_mngmt_table_row_option_btn, option, f'Table Option: {option}')

    
def platform_mngmt_revoke_invite(username):
    click_pending_invitations_tab()
    platform_mngmt_search_in_table(username)
    platform_mngmt_table_row_option('Revoke Invite')
    revoke_alert_txt = platform_mngmt_data['modalRevokeInviteText'].format(username)
    check.is_in(revoke_alert_txt, get_element_text(platform_mngmt_modal_content_txt), 'Revoke Invite Msg')
    click(platform_mngmt_modal_danger_btn, 'Confirm Revoke Invite Button')
    confirm_msg = platform_mngmt_data['revokedInviteSuccessMsg'].format(username)
    check.is_in(confirm_msg, get_element_text(platform_mngmt_toast_msg_txt), 'Invite Revoked Success Msg')
    click(platform_mngmt_toast_close_btn, 'Toast Close Button')
    
    
def platform_mngmt_open_add_members_slider():
    click(platform_mngmt_add_new_btn, 'Add New Button')
    explicit_wait(2)
    click_with_replace_value(platform_mngmt_add_new_item, 'Add Members', 'Add Members Item Button')
    

# Breadcrumb Constants
PF_BC_ORG_DETAILS = 'Organization Details'
PF_BC_TEAM_DETAILS = 'Team Details'


def platform_mngmt_navigate_in_breadcrumb(link_text):
    wait_for_spinner_off()
    scroll_element_into_view_with_replace_value(platform_mngmt_breadcrumb_link, link_text, True)
    # click_with_replace_value(platform_mngmt_breadcrumb_link, link_text, f'Breadcrumb {link_text} link')
    
    
def click_organizations_tab():
    platform_mngmt_click_side_tab('Organizations', 'Organizations Tab')
    

def click_pending_invitations_tab():
    platform_mngmt_click_side_tab('Pending Invitations', 'Pending Invitations Tab')
    
    
def click_teams_tab():
    platform_mngmt_click_side_tab('Teams', 'Teams Tab')
    
    
def click_members_tab():
    platform_mngmt_click_side_tab('Members', 'Members Tab')
    

def click_users_tab():
    platform_mngmt_click_side_tab('Users', 'Users Tab')
    

def delete_all_table_elements_by_search(value):
    found_elements = False
    try:
        platform_mngmt_search_in_table(value)
        found_elements = True
    except:
        logger.info('Not elements to be deleted')
    if found_elements:
        click_on_multiple_check_box(platform_mngmt_table_checkbox)
        click(platform_mngmt_table_delete_btn, 'Table Delete Button')
        explicit_wait(2)
        if is_element_present(platform_mngmt_modal_delete_item_checkbox, 'Delete Confirmation Checkbox'):
            click_checkbox(platform_mngmt_modal_delete_item_checkbox, True, 'Delete Confirmation Checkbox')
            explicit_wait(2)
        click(platform_mngmt_modal_danger_btn, 'Delete Confirmation Button')
        check.is_in(platform_mngmt_data['multipleItemsPartialSuccessMsg'], get_element_text(platform_mngmt_toast_msg_txt), 'Items Delete Success Msg')
        click_optional(platform_mngmt_toast_close_btn, 'Toast Close Button')
        

def add_access_group(access_name):
    platform_mngmt_click_side_tab('Access Groups', 'Access Groups Tab')
    click(platform_mngmt_add_new_btn, 'Add New Button')
    explicit_wait(2)
    click_with_replace_value(platform_mngmt_add_new_item, 'Add an Access Group', 'Add an Access Group Button')
    explicit_wait(2)
    platform_mngmt_fill_parameters("Access Group")
    click(platform_mngmt_add_confirm_btn, 'Add Confirm Button')
    access_group_created_txt = platform_mngmt_data['accessGroupCreatedMsg'].format(access_name)
    check.is_in(access_group_created_txt, get_element_text(platform_mngmt_toast_msg_txt),
                'Access Group Created Success Msg')
    click_optional(platform_mngmt_toast_close_btn, 'Toast Close Button')


def delete_access_group(access_group_name):
    platform_mngmt_search_in_table(access_group_name)
    platform_mngmt_table_row_option('Delete')
    check.is_in(platform_mngmt_data['modalDeleteAccessGroupTitle'], get_element_text(platform_mngmt_modal_default_header),
                'Modal Delete Title')
    type_value(platform_mngmt_delete_item_name_input, access_group_name, 'Confirm Delete Access Group Name')
    click(platform_mngmt_modal_danger_btn, 'Confirm Delete')
    check.is_in(platform_mngmt_data['accessGroupDeletedMsg'], get_element_text(platform_mngmt_toast_msg_txt),
                'Access Group Deleted Success Msg')
    click_optional(platform_mngmt_toast_close_btn, 'Toast Close Button')


def add_new_connection(connection_name):
    platform_mngmt_click_side_tab('Connections', 'Connections Tab')
    wait_for_spinner_off()
    click(platform_mngmt_add_new_btn, 'Add New Button')
    explicit_wait(2)
    click_with_replace_value(platform_mngmt_add_new_item, 'Add Connection', 'Add Connection Button')
    wait_for_spinner_on()
    wait_for_spinner_off()
    platform_mngmt_fill_parameters("Connection")
    check.is_in(platform_mngmt_data['testConnectionMsg'], get_element_text(platform_mngmt_toast_msg_txt),
                'Test Connection Msg')
    click_optional(platform_mngmt_toast_close_btn, 'Toast Close Button')
    click(platform_mngmt_add_confirm_btn, 'Add Confirm Button')
    connection_created_txt = platform_mngmt_data['connectionCreatedWithName'].format(connection_name)
    check.is_in(connection_created_txt, get_element_text(platform_mngmt_toast_msg_txt),
                'Connection Created Success Msg')
    click_optional(platform_mngmt_toast_close_btn, 'Toast Close Button')


def delete_connection(connection_name):
    platform_mngmt_click_side_tab('Connections', 'Connections Tab')
    platform_mngmt_search_in_table(connection_name)
    platform_mngmt_table_row_option('Delete')
    check.is_in(platform_mngmt_data['modalDeleteConnectionTitle'],
                get_element_text(platform_mngmt_modal_default_header),
                'Modal Delete Title')
    type_value(platform_mngmt_delete_item_name_input, connection_name, 'Confirm Delete Access Group Name')
    click(platform_mngmt_modal_danger_btn, 'Confirm Delete')
    check.is_in(platform_mngmt_data['connectionDeletedMsg'], get_element_text(platform_mngmt_toast_msg_txt),
                'Connection Deleted Success Msg')
    click_optional(platform_mngmt_toast_close_btn, 'Toast Close Button')


