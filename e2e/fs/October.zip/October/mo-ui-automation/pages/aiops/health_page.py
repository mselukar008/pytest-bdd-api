from selenium.webdriver.support.select import Select

from locators.aiops.dashboard_locator import view_details_link
from locators.aiops.health_locator import *
from pages.common.mo_navigation_page import *
from helpers.mo_check import mo_check as check

resource_count = None


def open_health_page():
    scroll_element_into_view_with_replace_value(view_details_link, mo_aiops_ui_test_data["resource_health_title"])
    click_with_replace_value(view_details_link, mo_aiops_ui_test_data["resource_health_title"], "View details")
    explicit_wait(5)


def select_provider_filter(provider):
    click_with_replace_value(provider_checkbox, provider, "Provider")
    click(apply_filters_btn, "Apply filters")


def validate_petstore_app_health_table():
    check.equal(get_element_text(page_title_text), mo_aiops_ui_test_data["healthLinkText"], "Health page title")
    type_value_and_enter(app_search_btn, "petstore", "Search box")
    table_labels = get_elements_texts(app_table_labels)
    check.equal(table_labels, mo_aiops_ui_test_data["app_table_labels"], "Application table labels")

    table_data = get_elements_texts(app_table_data)
    check.equal(table_data[0], mo_aiops_ui_test_data["petstore_app_name"], "Name")
    check.equal(table_data[2], mo_aiops_ui_test_data["critical_status"], "Health")
    check.equal(table_data[3], mo_aiops_ui_test_data["azure_provider"], "Provider")
    check.equal(table_data[5], mo_aiops_ui_test_data["petstore_craig_team"], "Team")
    global resource_count
    resource_count = table_data[6]
    check.greater(int(resource_count), 0, "Resource count")


def validate_petstore_resources():
    scroll_element_into_view(app_table_menu_icon)
    click(app_table_menu_icon, "Table menu")
    click(app_view_details_link, "View details")
    explicit_wait(5)

    check.equal(get_element_text(page_title_text), mo_aiops_ui_test_data["petstore_app_name"], "App page title")
    resources_header = mo_aiops_ui_test_data["resources_title"] + "(" + str(resource_count) + ")"
    check.equal(get_element_text(resources_table_header, timeout=70), resources_header, "Resources table header")

    type_value_and_enter(resource_search_icon, mo_aiops_ui_test_data["petstore_cluster_name"], "Search box")
    click_with_replace_value(resource_link, str(mo_aiops_ui_test_data["petstore_cluster_name"]).lower(),
                             "Resource link", timeout=70)

    check.is_not_none(get_element_text(page_title_text), "Resource Page title")
    click(events_tickets_btn, "Events & Tickets")


def validate_petstore_resources_status():
    click(resources_tab, "Resources")

    scroll_element_into_view(pagination_dropdown)
    dropdown = Select(driver.find_element_by_css_selector(pagination_dropdown[1]))
    dropdown.select_by_value("50")

    type_value_and_enter(resource_search_textbox, "petstore", "Search textbox")
    explicit_wait(3)

    table_resources_count = get_elements_count(resources_health_status)
    statuses = get_elements_texts(resources_health_status)
    for status in statuses:
        check.is_not_none(status, "Health status")

    resources_text = get_element_text(resource_list_resources_tab)
    resources_num = resources_text.split("(")
    tab_resources_count = resources_num[1].split(")")
    check.greater(int(tab_resources_count[0]), 0, "Total resources count")

