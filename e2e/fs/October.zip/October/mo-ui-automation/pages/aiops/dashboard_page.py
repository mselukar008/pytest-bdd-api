from locators.aiops.dashboard_locator import *
from pages.common.mo_navigation_page import *
from helpers.mo_check import mo_check as check


def open_aiops_dashboard_sunrise_report_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_aiops_ui_test_data["aiopsIntelligentItOprBtnText"])
    click_to_menu_option(mo_aiops_ui_test_data["sunrise_report_text"])
    switch_to_iframe(mo_iframe_xpath)
    click(dashboard_link, "Dashboard")
    wait_for_spinner_off()


def validate_resource_health():
    check.is_true(is_element_present_replace_value(card_title_text, mo_aiops_ui_test_data["resource_health_title"]),
                  "Card title")
    check.is_true(is_element_present(applications_text, "Applications"), "Applications")

    statuses = mo_aiops_ui_test_data["health_statuses"]
    check.equal(get_elements_texts(health_statuses_text), statuses, "Health statuses")
    critical_issues = get_element_text_replace_value(health_statuses_value, statuses[0], "Critical issues")
    check.greater_equal(int(critical_issues), 0, "Critical issues")
    warning = get_element_text_replace_value(health_statuses_value, statuses[1], "Warning")
    check.greater_equal(int(warning), 0, "Warning")
    healthy = get_element_text_replace_value(health_statuses_value, statuses[2], "Healthy")
    check.greater_equal(int(healthy), 0, "Healthy")

    check.is_true(is_element_present(health_progress_bar, "Health bar"), "Health progress bar")
    expected_apps = int(critical_issues) + int(warning) + int(healthy)
    check.equal(get_element_text(total_apps_text), f"Total: {str(expected_apps)} applications", "Total apps")

    check.is_in(get_element_text(open_tickets_text), mo_aiops_ui_test_data["open_tickets_text"], "Open tickets")
    check.equal(get_elements_texts(priorities_text), mo_aiops_ui_test_data["priorities"], "Priorities")
    tickets = get_elements_texts(priority_tickets_text)
    for ticket in tickets:
        check.greater_equal(int(ticket), 0, "Priority tickets")
