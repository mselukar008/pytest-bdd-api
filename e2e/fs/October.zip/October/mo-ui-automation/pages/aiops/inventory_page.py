from pages.common.mo_navigation_page import *


def open_inventory_page():
    switch_to_default_content_iframe()
    click_using_java_script(open_main_menu, "Main Menu")
    click_to_menu_expandable_option(mo_aiops_ui_test_data["aiopsIntelligentItOprBtnText"])
    switch_to_page_frame(mo_aiops_ui_test_data["inventoryLinkText"])
