from locators.ccm.ccm_dashboard_locator import *
from helpers.mo_check import mo_check as check
from pages.common.mo_navigation_page import *

data = ""


def open_ccm_dashboard_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ccm_ui_test_data["ccm_text"])
    click_to_menu_option(mo_ccm_ui_test_data["dashboard_text"])
    wait_for_spinner_off()


def validate_alerts():
    check.equal(get_element_text(dashboard_title), mo_ccm_ui_test_data["dashboard_title"], "Dashboard title")
    check.equal(get_element_text_replace_value(widget_title, 1, "Alerts title"), mo_ccm_ui_test_data["alerts_title"],
                "Alerts title")

    check.is_true(is_element_present(total_alerts_text, "Total text"), "Total text")
    total_count = get_element_text(total_alerts_count)
    check.greater(int(total_count), 0, "Total alerts count")
    check.equal(get_element_text(alerts_text), mo_ccm_ui_test_data["alerts_title"].lower(), "Alerts text")

    check.is_true(is_element_present_replace_value(app_cluster_link, mo_ccm_ui_test_data["petstore_cluster_link"]),
                  "Petstore cluster link")
    cluster_count = get_element_text(cluster_alert_count)
    alert_num = cluster_count.split(" ")
    check.greater(int(alert_num[0]), 0, "Cluster alert count")
    check.is_in(alert_num[1], mo_ccm_ui_test_data["alerts_text"], "Cluster alerts text")

    alert_icon_text = get_element_text(icon_text)
    icon_text_num = alert_icon_text.split(" ")
    if is_element_present(critical_alert_icon, "Critical alert icon"):
        check.equal(icon_text_num[0], alert_num[0], "Critical icon number")
        check.equal(icon_text_num[1], mo_ccm_ui_test_data["critical_state"], "Alert status")


def validate_clusters_health_by_provider():
    check.equal(get_element_text_replace_value(widget_title, 2, "Provider clusters title"),
                mo_ccm_ui_test_data["provider_cluster_title"], "Provider clusters")

    check.is_true(is_element_present(total_provider_cluster_text, "Cluster total text"), "Cluster total text")
    total_count = get_element_text(total_provider_clusters_count)
    check.greater(int(total_count), 0, "Total clusters count")
    check.equal(get_element_text(clusters_text), mo_ccm_ui_test_data["clusters_title"], "Clusters text")

    check.is_true(is_element_present(clusters_donut_chart, "Donut chart"), "Donut chart")
    color = get_elements_attribute(clusters_donut_chart, "fill")
    if "#24A148" in color:
        check.equal(get_element_text(chart_cluster_status), mo_ccm_ui_test_data["healthy_state"], "Cluster status")
    check.equal(get_element_text(chart_total_count), total_count, "Cluster chart total count")
    check.is_not_none(get_element_text(chart_cluster_percent), "Cluster chart percentage")


def validate_clusters_health_by_region():
    check.equal(get_element_text_replace_value(widget_title, 3, "Region clusters title"),
                mo_ccm_ui_test_data["region_cluster_title"], "Region clusters title")
    actions = ActionChains(driver)
    canvas = driver.find_element(By.CSS_SELECTOR, region_map_canvas[1])
    actions.move_to_element(canvas).click(canvas).perform()
    check.is_true(check_presence_of_element_dom(region_cluster_count), "Region map")
    '''result = 0
    for count in region_count:
        result = result + int(count)
    check.equal(str(result), get_element_text(total_provider_clusters_count), "Region count")'''


def validate_clusters_table():
    check.equal(get_element_text(clusters_table_title), mo_ccm_ui_test_data["clusters_title"].lower(), "Table title")
    check.equal(get_elements_texts(clusters_table_labels), mo_ccm_ui_test_data["clusters_table_labels"],
                "Table labels")

    global data
    data = get_elements_texts(clusters_table_data)
    check.equal(data[0], mo_ccm_ui_test_data["petstore_cluster_link"], "Cluster name")
    check.equal(data[1], mo_ccm_ui_test_data["azure_connection"], "Connection")
    check.equal(data[2], mo_ccm_ui_test_data["azure_provider"], "Provider")
    check.equal(data[3], mo_ccm_ui_test_data["cluster_location"], "Location")
    check.equal(data[4], mo_ccm_ui_test_data["cluster_health"], "Health")
    check.is_true(data[5], mo_ccm_ui_test_data["alerts_title"], "Alerts")
    check.is_not_none(data[6], "Kubernetes version")


def validate_cluster_column_in_cluster_page():
    click_with_replace_value(app_cluster_link, mo_ccm_ui_test_data["petstore_cluster_link"], "Petstore cluster link")
    wait_for_spinner_off()
    check.equal(get_element_text(cluster_alerts_text), data[5], "Cluster alerts info")
    check.equal(get_elements_texts(clusters_table_labels), mo_ccm_ui_test_data["pod_alerts_table_labels"],
                "Pod alerts table labels")
    # Table data must be validated

    click_with_replace_value(side_navigation_link, mo_ccm_ui_test_data["namespace_link"], "Namespaces link")
    wait_for_spinner_off()
    check.equal(get_elements_texts(namespaces_table_names), mo_ccm_ui_test_data["namespace_names"], "Namespaces")

    click_with_replace_value(side_navigation_link, mo_ccm_ui_test_data["alerts_title"], "Alerts link")
    wait_for_spinner_off()
    click(node_alerts_tab, "Node alerts")
    # No data available here


