import collections
import time
from sys import path

import pytz
from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_json_utils import *
from pytz import timezone
from datetime import datetime
import platform

from helpers.mo_page_operations import upload_file
from locators.store.catalog_management_locator import *
from pages.common.login_page import loader_off
from pages.store.navigation_page import *
from pages.store.catalog_page import *
from os.path import abspath
from helpers.mo_check import mo_check as check
from pages.store.user_access_management_page import get_toast_notification
from tests.common_test import logout_and_login
from conftest import get_env_url


def select_group(group_name):
    click_using_java_script(groups_toggle_btn, "Expand Groups Button")
    wait_for_spinner_off()
    click(service_group_dropdown, "Group")
    type_value_and_enter(group_searchbox, group_name, "Group Name")
    click_with_replace_value(group_checkbox, group_name, 'Dropdown Value')
    wait_for_spinner_off()


def verify_provider_name(provider_name):
    click_published_tab()
    wait_for_spinner_off()
    wait_before_click(provider_toggle_button, "Expand Provider Button")
    providers = get_elements_texts(providers_list)
    check.is_in(str(providers), provider_name, "Catalog Management Providers list")
    type_value_and_enter(provider_search_textbox, provider_name, "Provider")
    wait_before_click_replace_value(provider_checkbox, provider_name, "Provider Checkbox")
    wait_for_spinner_off()
    check.equal(get_element_text(service_provider_name), provider_name, "Provider")


def select_provider(provider_name):
    loader_off()
    wait_for_spinner_off()
    explicit_wait(8)
    wait_for_element_clickable(provider_toggle_button, "Expand Provider Button")
    explicit_wait(2)
    wait_before_click(provider_toggle_button, "Expand Provider Button")
    loader_off()
    wait_for_spinner_off()
    wait_before_click(provider_search_textbox, "Provider")
    type_value_and_enter(provider_search_textbox, provider_name, "Provider")
    wait_before_click_replace_value(provider_checkbox, provider_name, "Provider Checkbox")
    wait_for_spinner_off()


def verify_if_service_present_in_draft_state_for_provider(provider_name):
    select_provider(provider_name)
    explicit_wait(3)
    check.is_true(is_element_present(service_draft_state_text, "Service in draft state"), "Service in draft state")


def get_discovery_status():
    wait_for_element_to_visible(discovery_status, "Discovery status visible")
    return get_element_text(discovery_status)


def search_service_provider(service_or_provider):
    loader_off()
    wait_for_spinner_off()
    explicit_wait(2)
    type_value_and_enter(search_service_or_provider_textbox, service_or_provider, "Service Or Provider Textbox")
    wait_for_spinner_off()
    loader_off()


def distribute_service_offering(service_provider, service_name, client_tenant_name, client_tenant2_name=None, distribute_service_on_multiple_tenants=False):
    select_provider(service_provider)
    search_service_provider(service_name)
    loader_off()
    click(sort_date_btn, "date field")
    wait_for_spinner_off()
    click(sort_date_btn, "date field")
    logger.info("Sorted the list as per latest date to get latest entry")
    wait_for_spinner_off()
    explicit_wait(2)
    click(catalog_management_table_check_box, "Click on the checkbox")
    click(distribute_service_offering_btn, "Click on the distribute service offering button")
    loader_off()
    wait_for_spinner_off()
    explicit_wait(3)
    select_option_from_dynamic_listbox(distribute_service_offerings_drop_down, client_tenant_name,
                                       "distribution offering drop down")
    wait_for_spinner_off()
    if distribute_service_on_multiple_tenants and client_tenant2_name:
        wait_for_spinner_off()
        click(distribute_service_offerings_drop_down, "distribution offering drop down")
        select_option_from_dynamic_listbox(distribute_service_offerings_drop_down, client_tenant2_name,
                                           "distribution offering drop down")
        check.equal(get_elements_count(selected_customer_tenants), 2, "Selected Customer Tenants Count")
    job_distribution_start_time = get_current_formatted_time()
    click(distribute_service_customer_ok_btn, "Click on ok button")
    loader_off()
    wait_for_spinner_off()
    return job_distribution_start_time


def view_distribution_history(job_distribution_start_time):
    loader_off()
    wait_for_spinner_off()
    click(view_distribution_history_btn, "Click on the view distribution history button")
    loader_off()
    wait_for_spinner_off()
    wait_for_element_to_visible(catalog_distribution_panel_expanded, "Catalog history panel expanded")
    wait_for_all_elements_to_load(catalog_distribution_history_table_first_row, "wait for the table to be visible")
    wait_before_click(catalog_distribution_search, "catalog distribution search box")
    type_value_and_enter(catalog_distribution_search, job_distribution_start_time, "catalog distribution search box")
    #wait_for_element_to_invisible(no_data_msg, "No data")
    loader_off()
    wait_for_spinner_off()


def validate_catalog_distribution_history_details(client_tenant_name, service_provider):
#    wait_for_element_to_invisible(no_data_msg, "No data")
    wait_for_element_to_visible(catalog_distribution_panel_expanded, "Catalog history panel expanded")
    check.equal(get_element_text(catalog_distribution_customer_name), client_tenant_name, "client tenant name")
    check.equal(get_element_text(catalog_distribution_provider_name), service_provider, "provider name")
    check.equal(get_element_text(catalog_distribution_total_count), "1", "total service count")


def view_distribution_history_status(job_distribution_start_time, counter=30):
    while counter > 0:
        loader_off()
        wait_for_spinner_off()
        explicit_wait(3)
        counter = counter - 1
        view_distribution_history(job_distribution_start_time)
        explicit_wait(2)
        job_status = get_element_text(catalog_distribution_job_status)
        click(catalog_distribution_panel_close, "close button on the view distribution history panel")
        if job_status == "Completed":
            return job_status
        elif job_status == "Failed":
            return False
    return job_status


def get_current_formatted_time():
    current_UTC_time = datetime.now()
    current_Indian_time = datetime.now(timezone("Asia/Kolkata"))
    if platform.system() == 'Windows':
        formatted_time = current_Indian_time.strftime("%b %#d, %Y, %#I:%M")
        logger.info("Formatted Indian time :: " + str(formatted_time))
    elif platform.system() == 'Linux':
        formatted_time = current_UTC_time.strftime("%b %-d, %Y, %-I:%M")
        logger.info("Formatted UTC time :: " + str(formatted_time))
    else:
        formatted_time = current_UTC_time.strftime("%b %-d, %Y, %-I:%M")
        logger.info("Formatted time :: " + str(formatted_time))
    return str(formatted_time)


def service_action(action_name):
    click(menu_button, "Menu Button")
    click_with_replace_value(action_btn, action_name, "Catalog Action")
    wait_for_spinner_off()


def click_on_edit_service():
    service_action("View Details")
    click(edit_button, "Edit Service button")


def change_group_name(group_name):
    type_value(group_field_textbox, group_name, "Edit Group name")


def save_service_details():
    wait_for_spinner_off()
    click(save_btn, "Edit Service button")
    return get_alert_notification_title()


def get_alert_notification_title():
    wait_for_spinner_off()
    return get_element_text(alert_notification_title)


def get_version_service_name_group():
    wait_for_spinner_off()
    version = get_element_text(version_text)
    service_name = get_element_text(service_group_name_text)
    return version, service_name


def get_service_configuration():
    click(configuration_parameters_button, "Configuration Parameters")
    wait_for_spinner_off()
    click(expand_all_link, "Expand All links")
    return get_elements_texts(configuration_text)


def start_catalog_discovery(provider_account, provider):
    wait_for_spinner_off()
    click(add_services_button, "Add Services Button")
    click(ok_import_service, "Ok Import Service")
    click_with_replace_value(provider_for_catalog_discovery, provider, "Provider for Catalog Discovery")
    select_from_drop_down(multiple_account_dropdown, provider_account, "Multiple Accounts Detected")
    click(multiple_account_selected_ok_button, "ok button for Multiple accounts selected")
    wait_for_spinner_off()
    explicit_wait(2)
    discovery_started = get_element_text(discovery_started_text)
    click(discovery_started_ok_button, "Discovery Started ok button")
    return discovery_started


def wait_discovery_finish(provider, counter=30):
    res = True
    while res and counter > 0:
        select_provider(provider)
        status = get_discovery_status()
        if status == "In Progress":
            logger.info("Discovery is in progress wait for some time")
            explicit_wait(4)
            counter = counter - 1
            open_catalog_management_page()
            wait_discovery_finish(provider, counter)
        else:
            res = False
    return status


def get_discovery_status_history_link():
    click(icam_history_link, "ICAM History link")
    return get_element_text(catalog_discovery_status)


def click_published_tab():
    click(published_button, "Published Tab on Catalog Management page")
    wait_for_spinner_off()


def click_retired_tab():
    click(retired_button, "Retired Tab on Catalog Management page")
    wait_for_spinner_off()


def get_catalog_management_service_name():
    loader_off()
    wait_for_spinner_off()
    return get_element_text(service_name_from_table_new)


def get_service_name_from_catalog_management(service_name):
    service_name = " " + service_name + " "
    return get_element_text_replace_value(service_name_from_table, service_name, "Service Name")


def click_service_action_ok():
    click(service_confirmation_ok_button, "Service Action ok button")


def cancel_discovery(provider_name):
    open_catalog_management_page()
    click_on_providers_chevron()
    wait_before_click(provider_search_textbox, "Provider")
    type_value_and_enter(provider_search_textbox, provider_name, "Provider")
    wait_before_click(cancel_discovery_link, "Cancel Discovery")
    wait_before_click(cancel_discovery_ok_button, "ok button for Cancel Discovery")
    return get_alert_notification_title()


def open_tab(tab):
    explicit_wait(3)
    wait_for_element_to_visible_with_replace_value(catalog_management_tabs_path, tab, "Drafts/Published/Retired Tab")
    click_using_script_replace_value(catalog_management_tabs_path, tab, "Tab")


def import_service(import_from):
    open_tab("Drafts")
    click_using_java_script(add_service_css, "Add Services")
    if import_from == "Provider Account":
        wait_for_element_to_visible(import_from_provider_account_radiobtn_css,
                                    "Import through Provider Account radio button")
        click_using_java_script(import_from_provider_account_radiobtn_css,
                                "Import through Provider Account radio button")
    elif import_from == "File":
        wait_for_element_to_visible(import_fro_file_radiobtn_css, "Import From File radio button")
        click_using_java_script(import_fro_file_radiobtn_css, "Import From File radio button")

    click_using_java_script(import_model_ok_button_css, "Import Model Ok Button")
    wait_for_spinner_off()


def select_provider_from_catalog_discovery(provider_name):
    wait_for_element_to_visible(catalog_discovery_page_title_css, "Catalog Discovery")
    provider_names_ui = get_elements_texts(catalog_discovery_provider_list_css)
    if provider_name in provider_names_ui:
        logger.info(provider_name + " is present on catalog discovery page")
        click_using_script_replace_value(catalog_discovery_provider_xpath, provider_name, "MO CONTENT FACTORY")
    else:
        logger.info(provider_name + " is not present on catalog discovery page!")


def select_value_from_multi_acc_dropdown(provider_account):
    wait_for_element_to_visible(multiple_accounts_label_xpath, "Multiple accounts detected label")
    wait_for_element_to_visible(multi_account_dropdown_css, "Multiple accounts dropdown")
    click(multi_account_dropdown_css, "Multiple accounts dropdown")
    multiple_accounts_dropdown_values_ui = get_elements_texts(multi_account_dropdown_options_text_xpath)
    if provider_account in multiple_accounts_dropdown_values_ui:
        click_using_script_replace_value(multi_account_dropdown_value_xpath, provider_account,
                                         "ibm cloud servicification account")
        click_using_java_script(multi_acc_ok_button_css, "Confirmation ok button for multiple account provider")
    else:
        logger.info(provider_account + " is not present in the multiple accounts dropdown")


def verify_discovery_started():
    wait_for_element_to_visible(discovery_started_notification_header_xpath, "Discovery Started Header")
    check.equal(get_element_text(discovery_started_notification_text_xpath), get_data("discoveryStatusMsg"),
                'Discovery has started')
    click(discovery_started_ok_button, "Discovery Started ok button")


def import_service_via_provider_account():
    # set_data_path(path)
    open_tab(get_data("catalogManagementDraftsTabLabel"))
    import_service("Provider Account")
    select_provider_from_catalog_discovery(get_data("servicificationMoFactory"))
    select_value_from_multi_acc_dropdown(get_data("servicificationProvider"))


def send_file_path_to_upload_fileBox(upload_path):
    service_zip_dir = abspath(upload_path)
    logger.info("service_zip_dir:" + service_zip_dir)
    files = os.listdir(service_zip_dir)
    if len(files) == 0:
        logger.info("No file found in " + service_zip_dir)
        return False
    else:
        file_path = service_zip_dir + os.path.sep + files[len(files) - 1]
        logger.info("File found and file path is: " + file_path)
        upload_file(upload_file_input, file_path)
    click(upload_ok_button, "Upload Button")


def click_on_providers_chevron():
    # click(expand_providers_chevron, "Expand Provider's Chevron")
    wait_for_element_clickable(expand_providers_chevron, "Expand Provider's Chevron")
    wait_before_click(expand_providers_chevron, "Expand Provider's Chevron")


def click_on_providers_history_link_based_on_name(provider_name):
    provider_name = " " + provider_name + " "
    provider_title = get_element_text_replace_value(catalog_discovery_provider, provider_name, "Provider")
    if provider_title == provider_name.strip():
        logger.info(provider_name + " is present in the provider history list")
        click_using_script_replace_value(provider_names_history, provider_name, "IBM Cloud")
        wait_for_spinner_off()
    else:
        logger.info(provider_name + " is not present in the provider history list")


def search_imported_service(service_name, tab):
    open_catalog_management_page()
    explicit_wait(5)
    click_using_script_replace_value(action_btn,tab,"tab")
    wait_for_element_to_visible(search_box_for_service, "Search box")
    type_value_and_enter(search_box_for_service, service_name, "Search box for imported service")
    logger.info("Searched for Service/provider :" + service_name)
    wait_for_spinner_off()
    wait_for_element_to_visible(table_parent_entry_xpath, "First entry in the table")
    click(sort_date_btn, "date field")
    wait_for_spinner_off()
    click(sort_date_btn, "date field")
    logger.info("Sorted the list as per latest date to get latest entry in " + tab)
    explicit_wait(5)
    #wait_for_spinner_off()


def get_text_for_searched_service():
    wait_for_element_to_visible(searched_service_status, "Service status")
    status = get_element_text(searched_service_status)
    if status != None:
        return status.strip()
    else:
        return status


def click_on_service_menu_icon(service_name):
    click_using_script_replace_value(menu_icon_based_on_service_name_xpath, service_name, "Actions icon")


def get_discovered_service_status(provider_name):
    count_status = 0
    status_text = get_element_text_index_based(service_discovery_status_xpath, 1)
    if (status_text == "In-Progress" and count_status < 50):
        open_catalog_management_page()
        open_tab("Drafts")
        click_on_providers_chevron()
        click_on_providers_history_link_based_on_name(provider_name)
        count_status = count_status + 1
        return get_discovered_service_status(provider_name)
    else:
        return status_text


def verify_failed_discovery_details():
    click(click_on_failed_discovery_view_details_link, "Failed discovery link")
    check.is_in(get_data("invalidUploadFolderFailedStatus"), get_element_text(import_failed_details_xpath),
                "Failed discovery details")
    click(close_failed_status_pop_up, "Close pop-up")


def check_service_is_present(service_name):
    text = get_element_text(blue_print_tiltle_path)
    for index, value in enumerate(text):
        if text[index] == service_name:
            return True
        else:
            return False


def get_text_for_notification_msg():
    wait.until(EC.visibility_of_element_located(success_notification_path))
    msg = get_element_text(success_notification_path)
    return msg


def verify_discovered_service_status(provider_name):
    wait.until(EC.visibility_of_all_elements_located(service_discovered_status))
    service_status = get_discovered_service_status(provider_name)
    if service_status == "Failed":
        check.equal(service_status, get_data("discoveredStatusFailed"), "Failed")
        logger.info("Service Discovery is :" + service_status)
    elif service_status == "Completed":
        check.equal(service_status, get_data("discoveredStatus"), "Completed")
        logger.info("Service Discovery is :" + service_status)


def verify_discovery_start():
    wait_for_element_to_visible(discovery_started_notification_header_xpath, "Discovery Started Header")
    check.equal(get_element_text(discovery_started_notification_text_xpath), get_data("discoveryStatusMsg"),
                'Discovery has started')
    click_using_java_script(discovery_started_modal_ok_button_xpath, "Discovery Started ok button")


def verify_discovery_completion():
    open_catalog_management_page()
    open_tab("Drafts")
    explicit_wait(2)
    wait_for_spinner_off()
    click_on_providers_chevron()
    click_on_providers_history_link_based_on_name(get_data("providerName"))
    verify_discovered_service_status(get_data("providerName"))


def verify_discovery_on_catalog(import_service_name,SOI_ID):
    open_catalog_page()
    select_provider_type(get_data("providerName"))
    click_category_type(get_data("category"))
    search_service_name_catalog(import_service_name)
    click_custom_service_name(SOI_ID)


def publish_service(service_name):
    explicit_wait(5)
    click_on_service_menu_icon(service_name)
    click_on_service_action_button(service_name, "Publish")
    publish_successful_msg = get_data("publishServiceSuccessMsg")
    check.is_in(get_text_for_notification_msg(), publish_successful_msg, "Publish Successful")
    click_on_close_notification_button()


def retire_service(service_name):
    explicit_wait(3)
    click_on_service_menu_icon(service_name)
    click_on_service_action_button(service_name, "Retire")
    wait_for_element_to_visible_with_replace_value(action_popup_heading_text_xpath, "Retire Service",
                                                   "Retire Service Popup")
    wait_for_element_to_visible(confirm_ok_button_id, "Retire Confirmation Ok Button")
    click_using_java_script(confirm_ok_button_id, "Retire Confirmation Ok Button")
    retire_successful_msg = get_data("retireServiceSuccessmsg")
    check.is_in(get_text_for_notification_msg(), retire_successful_msg, "Retire Successful")
    click_on_close_notification_button()


def unretire_service(service_name):
    explicit_wait(3)
    click_on_service_menu_icon(service_name)
    click_on_service_action_button(service_name, "Unretire")
    wait_for_element_to_visible_with_replace_value(action_popup_heading_text_xpath, "Unretire Service",
                                                   "Unretire Service Popup")
    wait_for_element_to_visible(confirm_ok_button_id, "Unretire Confirmation Ok Button")
    click_using_java_script(confirm_ok_button_id, "Unretire Confirmation Ok Button")
    unretire_successful_msg = get_data("unretireServiceSuccessMsg")
    check.is_in(get_text_for_notification_msg(), unretire_successful_msg, "Unretire Successful")
    click_on_close_notification_button()


def delete_imported_service(service_name):
    explicit_wait(3)
    click_on_service_menu_icon(service_name)
    click_on_service_action_button(service_name, "Delete")
    wait_for_element_to_visible_with_replace_value(action_popup_heading_text_xpath, "Delete Service",
                                                   "Delete Service Popup")
    wait_for_element_to_visible(confirm_ok_button_id, "Delete Confirmation Ok Button")
    click_using_java_script(confirm_ok_button_id, "Delete Confirmation Ok Button")
    delete_successful_msg = get_data("servicedeletionSuccessMsg")
    check.is_in(get_text_for_notification_msg(), delete_successful_msg, "Delete Successful")
    click_on_close_notification_button()


def export_service(service_name, file_path):
    explicit_wait(3)
    click_on_service_menu_icon(service_name)
    click_on_service_action_button(service_name, "Export")
    export_successful_msg = get_data("exportServiceSuccessMsg")
    check.is_in(get_text_for_notification_msg(), export_successful_msg, "Export Successful")
    explicit_wait(5)
    verify_exported_zip_file(file_path)
    click_on_close_notification_button()


def verify_exported_zip_file(upload_path):
    exported_service_zip_dir = abspath(upload_path)
    files = os.listdir(exported_service_zip_dir)
    if (len(files) == 0):
        logger.info("No file found in " + exported_service_zip_dir)
        return False
    else:
        file_path = exported_service_zip_dir + os.path.sep + files[len(files) - 1]
        logger.info("File found and file path is: " + file_path)


def click_on_service_action_button(service_name, action):
    if action == "Preview":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_service_name_xpath,
                                                       [service_name, "Preview"], "Preview")
        click_using_script_replace_value(action_button_based_on_service_name_xpath, [service_name, "Preview"],
                                         "Preview")
    elif action == "Publish":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_service_name_xpath,
                                                       [service_name, "Publish "], "Publish")
        click_using_script_replace_value(action_button_based_on_service_name_xpath, [service_name, "Publish"],
                                         "Publish")
    elif action == "Retire":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_service_name_xpath,
                                                       [service_name, "Retire"], "Retire")
        click_using_script_replace_value(action_button_based_on_service_name_xpath, [service_name, "Retire"], "Retire")
    elif action == "Delete":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_service_name_xpath,
                                                       [service_name, "Delete"], "Delete")
        click_using_script_replace_value(action_button_based_on_service_name_xpath, [service_name, "Delete"], "Delete")
    elif action == "Export":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_service_name_xpath,
                                                       [service_name, "Export"], "Export")
        click_using_script_replace_value(action_button_based_on_service_name_xpath, [service_name, "Export"], "Export")
    elif action == "Unretire":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_service_name_xpath,
                                                       [service_name, "Unretire"], "Unretire")
        click_using_script_replace_value(action_button_based_on_service_name_xpath, [service_name, "Unretire"],
                                         "Unretire")
    elif action == "View Details":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_service_name_xpath,
                                                       [service_name, "View Details"], "View Details")
        click_using_script_replace_value(action_button_based_on_service_name_xpath, [service_name, "View Details"],
                                         "View Details")


def click_on_edit_service_button():
    wait_for_element_to_visible(edit_service_details_button_css, "Edit Button")
    click(edit_service_details_button_css, "Edit Button")


def click_on_save_service_button():
    wait_for_element_to_visible(save_service_details_button_css, "Save Button")
    click(save_service_details_button_css, "Save Button")


def view_imported_service_details(service_name):
    explicit_wait(5)
    click_on_service_menu_icon(service_name)
    click_on_service_action_button(service_name, "View Details")


def click_on_close_notification_button():
    if is_element_present(notification_close_button, "Notification Close Button"):
    # wait_for_element_to_visible(notification_close_button, "Notification Close Button")
        click(notification_close_button, "Notification Close Button")
    else:
        logger.info("Notification is not present")


def click_on_upload_image_link():
    wait_for_element_to_visible(upload_image_link_css, "Upload link")
    click(upload_image_link_css, "Upload link")


def click_on_delete_image_link():
    wait_for_element_to_visible(delete_image_link_css, "Delete link")
    click(delete_image_link_css, "Delete link")


def upload_template_logo(img_path):
    click_on_upload_image_link()
    upload_file(upload_image_input_css, img_path)
    click_on_save_service_button()
    edit_successful_msg = get_data("editDetailSuccessMsg")
    check.is_in(get_text_for_notification_msg(), edit_successful_msg, "Upload logo Successful")
    click_on_close_notification()


def delete_template_logo():
    click_on_delete_image_link()
    click_on_save_service_button()
    edit_successful_msg = get_data("editDetailSuccessMsg")
    check.is_in(get_text_for_notification_msg(), edit_successful_msg, "Delete logo Successful")
    click_on_close_notification()


def verify_logo_is_present():
    explicit_wait(5)
    srcValue = get_attribute_value(logo_on_details_css, "src")
    if srcValue == "":
        logger.info("Logo image is NOT present on service details page")
        return False
    else:
        logger.info("Logo image is present on service details page")
        return True


def preview_service(service_name):
    click_on_service_menu_icon(service_name)
    click_on_service_action_button(service_name, "Preview")
    wait_for_element_to_visible(confirm_ok_button_id, "Continue Preview Button")
    click_using_java_script(confirm_ok_button_id, "Continue Preview Button")
    wait_for_spinner_off()


def select_category_from_dropdown(value):
    wait_for_element_to_visible(category_dropdown_css, "Category Dropdown")
    click(category_dropdown_css, "Category Dropdown")
    wait_for_element_to_visible(category_first_dropdown_css, "Categories first option")
    time.sleep(1)
    category_texts = get_elements_texts(category_dropdown_list_css)
    logger.info(category_texts)
    if value in category_texts:
        logger.info("Category: " + value + " is present in the dropdown")
        wait_for_element_to_visible_with_replace_value(new_catgeory_xpath, value, "Category")
        click_using_script_replace_value(new_catgeory_xpath, value, "New Catgeory")


def select_category(value):
    wait_for_element_to_visible(category_dropdown_css, "Category Dropdown")
    select_from_drop_down(category_dropdown_css, value, "Category dropdown")


def edit_service_details(value):
    click_on_edit_service_button()
    select_category_from_dropdown(value)
    click_on_save_service_button()
    edit_successful_msg = get_data("editDetailSuccessMsg")
    check.is_in(get_text_for_notification_msg(), edit_successful_msg, "Edit Service Details Successful")
    click_on_close_notification()


def import_service_via_file(path):
    open_catalog_management_page()
    # open_tab("draft")
    import_service("File")
    # send_file_path_to_upload_fileBox(path)
    upload_file(upload_file_input, path)
    click(upload_ok_button, "Upload Button")
    wait_for_element_to_visible(content_import_sucess_notification_path, "Content Import Sucess notification")
    check.is_in("Content import", get_element_text(content_import_sucess_notification_path), "Content Import Initiated")


def click_on_configuration_parameters_tab():
    wait_for_element_to_visible(configuration_parameters_button, "Configuration Parameters Tab")
    click(configuration_parameters_button, "Configuration Parameters Tab")


def click_on_expand_all_button():
    wait_for_element_to_visible(expand_all_link, "expand all button")
    click(expand_all_link, "expand all button")


def click_on_configuration_parameters_action(config_name):
    click_using_script_replace_value(action_button_based_on_config_parameter_xpath, config_name, "Actions icon")


def view_configuration_parameters_details(config_name):
    click_on_configuration_parameters_action(config_name)
    try:
        click_on_configuration_action_button(config_name, "View Details")
    except:
        driver.refresh()
        switch_to_iframe(mo_iframe_xpath)
        wait_for_spinner_off()
        click_on_expand_all_button()
        view_configuration_parameters_details(config_name)


def view_configuration_parameter_attribute_details(attribute_name):
    click_using_script_replace_value(action_button_based_on_attribute_xpath, attribute_name, "Attribute Actions icon")
    wait_for_element_to_visible(view_details_in_attribute, "View Details")
    click_using_script(view_details_in_attribute, "View Details")


def click_on_configuration_action_button(config_name, action):
    if action == "Add New Section":
        wait_for_element_to_visible_with_replace_value(action_based_on_config_parameter_xpath,
                                                       [config_name, "Add New Section"], "Add New Section")
        click_using_script_replace_value(action_based_on_config_parameter_xpath, [config_name, "Add New Section"],
                                         "Add New Section")
    elif action == "Add Attribute":
        wait_for_element_to_visible_with_replace_value(action_based_on_config_parameter_xpath,
                                                       [config_name, "Add Attribute"], "Publish")
        click_using_script_replace_value(action_based_on_config_parameter_xpath, [config_name, "Add Attribute"],
                                         "Add Attribute")
    elif action == "Delete":
        wait_for_element_to_visible_with_replace_value(action_based_on_config_parameter_xpath, [config_name, "Delete"],
                                                       "Delete")
        click_using_script_replace_value(action_based_on_config_parameter_xpath, [config_name, "Delete"], "Delete")
    elif action == "View Details":
        wait_for_element_to_visible_with_replace_value(action_based_on_config_parameter_xpath,
                                                       [config_name, "View Details"], "View Details")
        click_using_script_replace_value(action_based_on_config_parameter_xpath, [config_name, "View Details"],
                                         "View Details")


def click_on_section_action(section_name, action):
    if action == "Add Attribute":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_section_xpath,
                                                       [section_name, "Add Attribute"], "Publish")
        click_using_script_replace_value(action_button_based_on_section_xpath, [section_name, "Add Attribute"],
                                         "Add Attribute")
    elif action == "Delete":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_section_xpath, [section_name, "Delete"],
                                                       "Delete")
        click_using_script_replace_value(action_button_based_on_section_xpath, [section_name, "Delete"], "Delete")
    elif action == "View Details":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_section_xpath,
                                                       [section_name, "View Details"], "View Details")
        click_using_script_replace_value(action_button_based_on_section_xpath, [section_name, "View Details"],
                                         "View Details")


def get_text_for_success_notification_msg():
    wait.until(EC.visibility_of_element_located(success_notification_msg))
    msg = get_element_text(success_notification_msg)
    return msg


def click_on_close_notification():
    try:
        wait_for_element_to_visible(close_notification_css, "Close Notification")
        click(close_notification_css, "Close Notification")
    except:
        logger.info("Close notification popup has been closed already")


def select_call_to_validate(validate):
    if validate == "True":
        wait_for_element_to_visible(call_to_validate_true, "True")
        click_using_java_script(call_to_validate_true, "True")
    elif validate == "False":
        wait_for_element_to_visible(call_to_validate_false, "False")
        click_using_java_script(call_to_validate_false, "False")


# edit group name in configuration parameter and save
def edit_configuration_parameters(value):
    wait_for_element_to_visible(edit_config_group_button_xpath, "configuration edit button")
    click(edit_config_group_button_xpath, "configuration edit button")
    type_value_and_enter(edit_config_group_name_css, value, "Name")
    select_call_to_validate("True")
    wait_for_element_to_visible(save_config_group_button_css, "Save")
    click(save_config_group_button_css, "Save")
    edit_config_group_successful_msg = get_data("editConfigGroupSuccessMsg")
    check.is_in(get_text_for_success_notification_msg(), edit_config_group_successful_msg,
                "Successfully updated configuration group")
    click_on_close_notification()


def click_on_edit_config_param():
    wait_for_element_to_visible(edit_config_param_css, "Configuration edit button")
    click(edit_config_param_css, "Configuration edit button")


def edit_config_param_name(config_param_label_edit):
    wait_for_element_to_visible(config_param_name_input_xpath, "Configuration Name Input")
    type_value(config_param_name_input_xpath, config_param_label_edit, "Configuration Name")


def edit_config_param_desc(desc_edit_msg):
    wait_for_element_to_visible(config_param_desc_textarea_css, "Configuration Desc Textarea")
    type_value(config_param_desc_textarea_css, desc_edit_msg, "Configuration Desc")


def save_config_param_changes():
    wait_for_element_to_visible(save_config_param_css, "Save")
    click(save_config_param_css, "Save")
    # Not showing any notification on UI now
    # check.is_in(get_text_for_success_notification_msg(), get_data("editConfigParamSuccessMessage"), "Successfully updated configuration param")
    # click_on_close_notification()


def click_on_service_details_tab():
    wait_for_element_to_visible(service_details_button, "Configuration Parameters Tab")
    click(service_details_button, "Configuration Parameters Tab")


def click_on_edit_of_attribute():
    wait_for_element_to_visible(edit_attribute_button_css, "attribute edit button")
    click(edit_attribute_button_css, "attribute edit button")


# edit attribute in configuration parameter and save
def edit_attribute_configuration_parameters(value):
    click_on_edit_of_attribute()
    type_value_and_enter(attribute_config_name_xpath, value, "attribute Configuration Name")
    click(save_attribute_css, "Save")
    edit_attribute_successful_msg = get_data("editAttributeSuccessMsg")
    check.is_in(get_text_for_success_notification_msg(), edit_attribute_successful_msg, "Successfully edited config")
    click_on_close_notification()


def delete_attribute_configuration_parameters(attribute_name):
    scroll_element_into_view_with_replace_value(action_button_based_on_attribute_xpath, attribute_name)
    click_using_script_replace_value(action_button_based_on_attribute_xpath, attribute_name, "Attribute Actions icon")
    wait_for_element_to_visible(delete_in_attribute, "Delete")
    click_using_script(delete_in_attribute, "Delete")
    delete_confirm_ok()
    deleted_attribute_successful_msg = get_data("deletedAttributeSuccessMsg")
    check.is_in(get_text_for_success_notification_msg(), deleted_attribute_successful_msg,
                "Successfully deleted config")
    click_on_close_notification()


def delete_section_configuration_parameters(section_name):
    scroll_element_into_view_with_replace_value(section_option_button_xpath, section_name)
    click_on_section_action_button(section_name)
    click_on_section_action(section_name, "Delete")
    delete_confirm_ok()
    deleted_section_successful_msg = get_data("deletedSectionSuccessMsg")
    check.is_in(get_text_for_success_notification_msg(), deleted_section_successful_msg, "Successfully deleted section")
    click_on_close_notification()


def delete_group_configuration_parameters(config_name):
    scroll_element_into_view_with_replace_value(action_button_based_on_config_parameter_xpath, config_name)
    click_on_configuration_parameters_action(config_name)
    click_on_configuration_action_button(config_name, "Delete")
    delete_confirm_ok()
    deleted_group_successful_msg = get_data("deletedGroupSuccessMsg")
    check.is_in(get_text_for_success_notification_msg(), deleted_group_successful_msg, "Successfully deleted group")
    click_on_close_notification()


def delete_confirm_ok():
    wait_for_element_to_visible(delete_button_css, "delete button")
    click_using_java_script(delete_button_css, "delete button")


def click_on_section_action_button(section_name):
    click_using_script_replace_value(section_option_button_xpath, section_name, "Actions icon")


def click_on_add_group_button():
    wait_for_element_to_visible(add_group_button_css, "Add Group button")
    click_using_java_script(add_group_button_css, "Add Group button")


def click_on_add_section(value):
    click_on_configuration_parameters_action(value)
    click_on_configuration_action_button(value, "Add New Section")


def click_on_add_attribute_in_group(value):
    scroll_element_into_view_with_replace_value(action_button_based_on_config_parameter_xpath, value)
    click_on_configuration_parameters_action(value)
    click_on_configuration_action_button(value, "Add Attribute")


def click_on_add_attribute_in_section(value):
    scroll_element_into_view_with_replace_value(section_option_button_xpath, value)
    click_on_section_action_button(value)
    click_on_section_action(value, "Add Attribute")


def click_on_data_type_dropdown():
    wait_for_element_to_visible(attribute_data_type_xpath, "data type Dropdown")
    click_using_java_script(attribute_data_type_xpath, "data type Dropdown")


def click_on_input_type_dropdown():
    wait_for_element_to_visible(attribute_input_type_xpath, "data type Dropdown")
    click_using_java_script(attribute_input_type_xpath, "data type Dropdown")


def is_service_already_exist(service_name, tab):
    open_catalog_management_page()
    wait_for_element_to_visible(search_box_for_service, "Search box")
    type_value_and_enter(search_box_for_service, service_name, "Search box for imported service")
    logger.info("Searched for Service/provider :" + service_name)
    wait_for_spinner_off()


def add_group_configuration_parameters(value):
    wait_for_element_to_visible(add_group_button_css, "Add Group button")
    click_using_java_script(add_group_button_css, "Add Group button")
    wait_for_element_to_visible(group_name_css, "Group Name")
    type_value_and_enter(group_name_css, value, "Group Name")
    wait_for_element_to_visible(add_save_button_css, "Save button")
    click_using_java_script(add_save_button_css, "Save button")
    added_group_successful_msg = get_data("addNewGroupSuccessMsg")
    check.is_in(get_text_for_success_notification_msg(), added_group_successful_msg,
                "Successfully added configuration group")
    click_on_close_notification()


def add_section_configuration_parameters(section_name):
    # scroll_element_into_view_with_replace_value(enter_section_name_css, section_name)
    wait_for_element_to_visible(enter_section_name_css, "Section Name")
    # scroll_element_into_view(section_name)
    type_value_and_enter(enter_section_name_css, section_name, "Section Name")
    wait_for_element_to_visible(add_save_button_css, "Save button")
    click_using_java_script(add_save_button_css, "Save button")
    added_section_successful_msg = get_data("addNewSectionSuccessMsg")
    check.is_in(get_text_for_success_notification_msg(), added_section_successful_msg, "Successfully added new section")
    click_on_close_notification()


def select_from_dropdown_listbox(locator, replace_value, value, elem_name):
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1].format(replace_value))))
    wait_for_spinner_off()
    elem.click()
    logger.info(f"Clicked on {elem_name} dropdown")
    dropdown_values = (By.XPATH, "//ibm-dropdown-list//li")
    wait_for_element_to_visible(dropdown_values, "dropdown list")
    values = get_elements_texts(dropdown_values)
    for i, text in enumerate(values, start=1):
        logger.info(f"Comparing {text} with {value}")
        if text == value:
            dropdown_value = (By.XPATH, f"(//ibm-dropdown-list//li)[{i}]")
            element = wait.until(EC.visibility_of_element_located(dropdown_value))
            element.click()
            logger.info(f"Selected Value {value} from Dropdown {elem_name}")
            break
        else:
            logger.info(f"Value {value} not present in Dropdown {elem_name}")


def add_attribute_configuration_parameters(attribute_name):
    wait_for_element_to_visible(attribute_config_name_xpath, "Attribute Name")
    type_value_and_enter(attribute_config_name_xpath, attribute_name, "Attribute Name")
    click_using_java_script(attribute_required_css, "Required")
    click_using_java_script(attribute_configurable_css, "Configurable")
    select_from_dropdown_listbox(select_dropdown_xpath, get_data("dataTypeDropdown"), get_data("dataTypeDropdownValue"),
                                 "Select Data Type")
    select_from_dropdown_listbox(select_dropdown_xpath, get_data("inputTypeDropdown"),
                                 get_data("inputTypeDropdownValue"), "Select Input Type")
    type_value_and_enter(attribute_default_value, get_data("AttributeDefaultValue"), "default value")
    #wait_for_element_to_visible(save_attribute_css, "Save button")
    click_using_java_script(save_attribute_css, "Save button")
    added_attribute_successful_msg = get_data("addNewAttributeSuccessMsg")
    check.is_in(get_text_for_success_notification_msg(), added_attribute_successful_msg,
                "Successfully added new config")
    click_on_close_notification()


def deselect_required_checkbox_in_attribute():
    wait_for_element_to_visible(attribute_config_name_xpath, "Attribute Name")
    deselect_checkbox(checkbox_xpath, get_data("deselectRequired"), 'deselect Required')
    wait_for_element_to_visible(save_attribute_css, "Save button")
    click_using_java_script(save_attribute_css, "Save button")
    added_attribute_successful_msg = get_data("editAttributeSuccessMsg")
    check.is_in(get_text_for_success_notification_msg(), added_attribute_successful_msg, "Successfully edited config")
    click_on_close_notification()


# verify entity context is visible for service details
def edit_service_context_entity():
    scroll_element_into_view(entity_value_dropdown_arrow_xpath)
    wait_for_element_to_visible(edit_service_context_label_xpath, "Contexts Associated visible")
    wait_for_element_to_visible(edit_business_context_label_xpath, "business entity")
    is_element_present(entity_values_list_xpath, "already selected values ")
    is_element_present(entity_value_all_css, "entity value all org ")
    is_element_present(entity_value_admin_org_css, "entity value my org ")
    is_element_clickable(entity_clear_button_css, "clear button visible and ")
    wait_before_click(entity_clear_button_css, "clicked on clear button clear values")
    wait_for_element_to_visible(entity_empty_values_css, "empty input visible")
    wait_before_click(entity_value_dropdown_arrow_xpath, "values input dropdown arrow ")
    wait_before_click(entity_value_all_xpath, "select all org")
    wait_before_click(entity_value_adminorg_xpath, "select admin org")
    logger.info("all and my org values selected as a entity")
    wait_before_click(label_name_outside_xpath, "clicked outside area")


# verify_failed_discovery_details
def verify_failed_discovery_for_invalid_creds(provider_account):
    open_catalog_management_page()
    select_provider(provider_account)
    status = get_discovery_status_history_link()
    if status == "Failed":
        logger.info("The Catalog Discovery Status is " + status)
        check.equal(status, "Failed", "Discovery Status")
        click(click_on_failed_discovery_view_details_link, "Failed discovery link")
    else:
        logger.info("The Catalog Discovery Status is " + status)


def edit_dynamic_config_parameter():
    click(configuration_parameters_button, "Configuration Parameters")
    wait_for_spinner_off()
    click(configer_dynamic_param_yes, "Dynamic yes radio button")
    fill_order_parameter(get_data("Edit Parameters"))
    click(save_dynamic_param, "Save dynamic parameter")


def click_load_values():
    click(load_values_btn, "Load Values")


def click_add_provisioning_policy():
    click(add_provisioning_policy_btn, "Add provisioning policy")


def edit_and_load_values_location_attribute():
    click_on_expand_all_button()
    view_configuration_parameters_details("Location")
    click(edit_attribute_btn, "Edit attribute btn")
    text = {"type": "on-demand", "resource-path": "/subscriptions/{subscriptionId}/providers/Microsoft.Resources",
            "params": {"api-version": "2018-01-01"}, "method": "GET",
            "return": ["$['resourceTypes'][?(@.resourceType=='resourceGroups')]['locations'][*]"]}
    if is_element_present(attribute_derived_external_source_css, "attribute_derived_external_source"):
        click(attribute_derived_external_source_css, "attribute_derived_external_source")
    type_value(metadata_json, json.dumps(text, indent=0), "Meta Data Json")
    click_load_values()
    click_add_provisioning_policy()
    explicit_wait(2)


def add_provisioning_policy(team, add_policy, context_values):
    count = 1
    clicked = 0
    click_with_replace_value(expand_chevron, count, "Expand dropdown")
    click_with_replace_value(business_entity, team, "Business Entity")
    explicit_wait(1)
    for value in add_policy.split(","):
        count = count + 1
        select_multiple_values_from_dropdown_with_index(expand_chevron, value, count)
        if clicked != 2:
            click_with_replace_value(associate_checkbox, count - 1, "Associate CheckBox")
            clicked += 1
    click_context_value(context_values)
    click(save_context, "Save Context")
    explicit_wait(1)
    click(save_attribute_css, "Save")
    explicit_wait(1)
    click_on_close_notification()


def click_context_value(context_values):
    for val in context_values.split(","):
        logger.info(val)
        click_with_replace_value(select_context_value, val, "Context value")


def verify_added_attribute(param):
    click(location_text_box, "Location text box")
    texts = get_elements_texts(location_values)
    check.equal(collections.Counter(param), collections.Counter(texts), "attribute values are not matching")


def preview_edited_service():
    click(service_details_button, "Service Details")
    click(preview_edit_btn, "Preview Button")
    wait_for_element_to_visible(preview_continue_btn, "Continue Preview Button")
    click_using_java_script(preview_continue_btn, "Continue Preview Button")
    wait_for_spinner_off()


def select_provider_and_publish_service(provider_name, service_name):
    select_provider(provider_name)
    if is_element_present_replace_value(menu_icon_based_on_service_name_xpath, service_name):
        publish_service(service_name)


def select_provider_publish_and_retire_service(provider_name, service_name):
    # Publish service
    select_provider(provider_name)
    if is_element_present_replace_value(menu_icon_based_on_service_name_xpath, service_name):
        publish_service(service_name)

    # Retire service
    click_published_tab()
    select_provider(provider_name)
    if is_element_present_replace_value(menu_icon_based_on_service_name_xpath, service_name):
        retire_service(service_name)


def get_current_time_24hrs():
    current_utc_time = datetime.now()
    current_indian_time = datetime.now(timezone("Asia/Kolkata"))
    if platform.system() == 'Windows':
        formatted_time = current_indian_time.strftime("%#d %b %Y, %#H:%M")
        logger.info("Formatted Indian time :: " + str(formatted_time))
    elif platform.system() == 'Linux':
        formatted_time = current_utc_time.strftime("%-d %b %Y, %-I:%M")
        logger.info("Formatted UTC time :: " + str(formatted_time))
    else:
        formatted_time = current_utc_time.strftime("%-d %b %Y, %-I:%M")
        logger.info("Formatted time :: " + str(formatted_time))
    return str(formatted_time)


def distribute_from_sp_to_ct(service_provider, imported_service_name):
    click_published_tab()
    client_tenant_name = get_env_url().split(".multicloud")[0]
    global job_distribution_start_time
    job_distribution_start_time = distribute_service_offering(service_provider, imported_service_name,
                                                              client_tenant_name)
    msg = get_toast_notification()
    check.equal(msg, "Service Offering distribution request submitted successfully.", "popup message verification")
    explicit_wait(3)
    view_distribution_history(job_distribution_start_time)
    validate_catalog_distribution_history_details(client_tenant_name, service_provider)
    click(catalog_distribution_panel_close, "close button on the view distribution history panel")
    distribution_job_status = view_distribution_history_status(job_distribution_start_time)
    check.equal(distribution_job_status, "Completed", "Catalog distribution job status")

