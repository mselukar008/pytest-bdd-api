from pages.store.navigation_page import *
from helpers.mo_json_utils import *
from helpers.mo_check import mo_check as check
from pages.store.order_parameters_page import fill_order_parameter
from tests.common_test import get_random_string
from locators.store.provider_account_locator import *


def select_provider_from_pa():
    click_using_java_script(provider_type_checkbox_path, "Provider: ")


def click_provider_account_type():
    click(asset_account_path, 'Provider Account Type')
    wait_for_spinner_off()


def click_provider_account_view_details(account_name):
    type_value_and_enter(account_search_textbox, account_name, "Asset Account")
    click(provider_account_hamburger_path, 'Credential Account Hamburger')
    click_using_java_script(provider_account_view_details_path, 'Provider Account View Details')


def click_edit_credential_account():
    click(edit_cred_account_path, 'Edit Credential Account')


def click_toggle_provider_account_status():
    click_using_java_script(toggle_switch_path, "Toggle Switch")


def click_update_credential_account():
    click_using_java_script(update_cred_account_path, "Update Credential Account")


def toggle_provider_account_active_inactive(account_name, providerAccountStatus):
    open_provider_account_page()
    select_provider_from_pa()
    click_provider_account_type()
    click_provider_account_view_details(account_name)
    click_edit_credential_account()
    click_toggle_provider_account_status()
    click_update_credential_account()
    explicit_wait(10)
    check.is_in(get_element_text(provider_account_status_path), providerAccountStatus, 'Provider Account Status :')


def click_add_asset_account_button():
    click(add_asset_account_path, 'Add account button')
    wait_for_spinner_off()


def click_TA_provider_account():
    click_with_replace_value(new_asset_account_provider_text, "Terraform Automation",
                             'Add Terraform Automation Account button')


def enter_provider_account_name(pa_name):
    text_area_type_value(provider_account_name_path, pa_name, "Provider Account Name")


def click_create_account_button():
    click(create_account_button_path, "Create Asset Account Button")


def click_add_credentials_button():
    click(add_credentials_button_path, "Add Credentials button")


def enter_cred_account_name(credential_account_name):
    text_area_type_value(cred_account_name_path, credential_account_name, "Credential Account Name")


def click_cred_account_purpose():
    click(cred_account_purpose_path, "Credential Account Purpose")


def click_provision_purpose():
    click(provision_purpose_path, "Provision purpose")


def click_create_new_update_credential_in_vault():
    click(create_new_update_credential_in_vault_path, "Credential Reference ID input and entered value")


def click_team_org_checkbox():
    click_using_java_script(team_org_checkbox_path, "TeamOrg Checkbox")


def click_business_entity_team():
    click_using_java_script(business_entity_team_path, "Choose Business Entity Team")


def click_select_team_entity_and_values():
    click(select_entity_team_path, "Select Entity Team Chevron")
    click_using_java_script(team_values_path, "Team Values")


def click_search_enter_team_value(team_value):
    click_using_java_script(select_team_path, "Teams Chevron")
    type_value_and_enter(search_enter_team_value_path, team_value, "Search Team")


def click_add_button():
    click_using_java_script(add_button_path, "Add Button")


def get_notification():
    wait_for_element_to_visible(notification_title_path, "Credential Added Success Title Notification ")
    title = get_element_text(notification_title_path)
    subtitle = get_element_text(notification_subtitle_path)
    # Close Notification Message
    click(close_notification_popup, "Closed Notification Pop up")
    return title, subtitle


def get_delete_notification_title():
    wait_for_element_to_visible(notification_title_path, "Delete Notification Title")
    return get_element_text(notification_title_path)


def get_delete_toast_notification():
    wait_for_element_to_visible(delete_notification_msg, "Delete Notification Message")
    message = get_element_text(delete_notification_msg)
    return message


def click_delete_provider_account_button(account_name):
    open_provider_account_page()
    select_provider_from_pa()
    click_provider_account_type()
    type_value_and_enter(account_search_textbox, account_name, "Asset Account")
    click(provider_account_hamburger_path, 'Credential Account Hamburger')
    click_using_java_script(delete_provider_account_button_path, "Click on delete button")
    click_using_java_script(delete_confirm_button_path, "Delete confirmation box ")
    delete_success_title = get_delete_notification_title()
    check.equal(delete_success_title, get_data("successNotificationTitle"), "Account Delete Successful")
    delete_success_subtitle_msg = get_delete_toast_notification()
    check.equal(delete_success_subtitle_msg, get_data("deleteAccountNotificationMessage"),
                "Account Deletion Successful Message")


def get_all_asset_account_providers():
    click_provider_account_type()
    click_add_asset_account_button()
    providers = get_elements_texts(asset_account_providers_list)
    return providers


def create_pagerduty_asset_account(provider_account_name):
    open_provider_account_page()
    select_provider_from_pa()
    click_provider_account_type()
    click_add_asset_account_button()
    click_with_replace_value(new_asset_account_provider_text, "pagerduty", "pagerduty")
    enter_provider_account_name(provider_account_name)
    click_create_account_button()
    account_notification_title, account_notification_subtitle = get_notification()
    check.equal(account_notification_title, "Success:", "Account Added Successfully")

    # Add credentials
    click_add_credentials_button()
    enter_cred_account_name(provider_account_name)
    click_cred_account_purpose()
    click_provision_purpose()
    click_create_new_update_credential_in_vault()
    token = get_random_string(50)
    type_value(pagerduty_creds_token_textarea, token, "Token")
    click_business_entity_team()
    click_select_team_entity_and_values()
    click_search_enter_team_value("Auto-TEAM1")
    click_with_replace_value(team_name_checkbox, "Auto-TEAM1", "Team checkbox")
    click_team_org_checkbox()
    click_add_button()
    credential_notification_title, credential_notification_subtitle = get_notification()
    check.equal(credential_notification_title, "Success:", "Credential Added Successfully")


def verify_multiple_accounts_in_catalog_main_params_page():
    check.is_true(is_element_present_replace_value(credential_account_path, get_data("FirstCredentialAccount")),
                  'First Asset Account')
    check.is_true(is_element_present_replace_value(credential_account_path, get_data("SecondCredentialAccount")),
                  'Second Asset Account')
    check.is_true(is_element_present_replace_value(credential_account_path, get_data("ThirdCredentialAccount")),
                  'Third Asset Account')


def fill_asset_account_parameter_details(asset_parameter):
    fill_order_parameter(asset_parameter)


def fill_credential_account_parameter_details(credential_parameter):
    fill_order_parameter(credential_parameter)


def validate_create_asset_account(provider_account_name):
    account_notification_title, account_notification_subtitle = get_notification()
    check.equal(account_notification_title, get_data("successNotificationTitle"), "Account Added Successfully")
    exp_msg = " ".join([provider_account_name, get_data("accountSuccessNotificationSubTitle")])
    check.equal(account_notification_subtitle, exp_msg, "Account Added SubTitle")


def validate_create_credential_account():
    credential_notification_title, credential_notification_subtitle = get_notification()
    check.equal(credential_notification_title, get_data("successNotificationTitle"), "Credential Added Successfully")
    check.equal(credential_notification_subtitle, get_data("successNotificationSubTitle"))


def fill_provider_account_details(path, provider_account_name):
    set_data_path(path)
    fill_asset_account_parameter_details(get_data("New Asset Account"))
    validate_create_asset_account(provider_account_name)
    fill_credential_account_parameter_details(get_data("Credential Account"))
    validate_create_credential_account()
