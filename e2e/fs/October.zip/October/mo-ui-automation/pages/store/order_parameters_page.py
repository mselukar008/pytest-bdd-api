import re
import time

from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_json_utils import *
from helpers.mo_selenium_helper import *
from locators.store.review_order_locator import *
from pages.store.mo_store_utils import get_filtered_data
from tests.common_test import get_random_int
from copy import deepcopy


def fill_order_parameter(nested_dictionary, use_next_button=True):
    if type(nested_dictionary) is dict and nested_dictionary:
        for key, data in nested_dictionary.items():
            if type(data) is dict and data:
                for x in data:
                    explicit_wait(1)
                    wait_for_spinner_off()
                    filter_dict = get_data(x, data)
                    get_filtered_data(filter_dict, x)
                if check_element_exists(save_btn):
                    click_save_btn()
                    wait_for_spinner_off()
                else:
                    logger.info("Save Button is not present, Click Next Button")
                    if use_next_button:
                        click_next_btn()
                        wait_for_spinner_off()
                    else:
                        logger.info("Fill next Nested Dict,Next Button not clicked")
                        continue
            elif not data:
                if use_next_button:
                    click_next_btn()
                    wait_for_spinner_off()
                    continue
                else:
                    logger.info("Fill next Nested Dict,Next Button not clicked")
                    continue
            # Waits for stepper card open
            explicit_wait(1)


def click_next_btn():
    wait_for_spinner_off()
    if check_element_exists(next_btn_path):
        wait_for_element_clickable(next_btn_path, "Next button")
        click_using_script(next_btn_path, "Next button")
    else:
        logger.info("Next button is not present")


def click_previous_btn():
    wait_for_spinner_off()
    if check_element_exists(previous_btn_path):
        wait_for_element_clickable(previous_btn_path, "Previous button")
        click_using_script(previous_btn_path, "Previous button")
    else:
        logger.info("Previous button is not present")


def click_save_btn():
    wait_for_spinner_off()
    if check_element_exists(save_btn):
        wait_for_element_clickable(save_btn, "Save Button")
        click_using_java_script(save_btn, "Save button")
        logger.info("Save Button is present and Clicked")
        return True
    else:
        logger.info("Save button is not present")
        return False


def check_value_type(input_text):
    num_format = re.compile(r'^\-?[1-9][0-9]*\.?[0-9]*')
    is_number = re.match(num_format, input_text)
    if is_number:
        return True
    else:
        return False


# Allows to move forward or back in order page form
def go_next_or_previous_in_order_page(nested_dictionary, back=False):
    if type(nested_dictionary) is dict and nested_dictionary:
        for _ in nested_dictionary.items():
            if not back:
                click_next_btn()
            else:
                click_previous_btn()
            wait_for_spinner_off()


def add_to_shopping_cart(cart_name=None, snow=False):
    cart_template = deepcopy(cart_data["cartTemplate"])
    cart_locator = cart_template['Shopping Cart']['xpath']
    if not cart_name:
        cart_name = get_random_int('new-cart-')
        cart_template['Shopping Cart']['xpath'] = cart_locator.format('New Shopping Cart')
        cart_template['Cart Name']['value'] = cart_name
    else:
        cart_template.pop('Cart Name')
        cart_template['Shopping Cart']['xpath'] = cart_locator.format(cart_name)
        # Deletes the Team, env and App keys,because is not necesary when cart is given
        if snow:
            modify_main_dict_multiple_keys(['Main Parameter', 'Main Parameters'], values=['Team', 'env'],
                                           delete=True)
        else:
            modify_main_dict_multiple_keys(['Main Parameter', 'Main Parameters'], values=['Team', 'env', 'App'],
                                           delete=True)
    modify_main_dict_multiple_keys(['Main Parameter', 'Main Parameters'], values=cart_template, initial_position=1)
    return cart_name
