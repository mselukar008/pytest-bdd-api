from pages.common.mo_navigation_page import *
import re
from helpers.mo_driver_manager import logger
from helpers.mo_element_operations import *
from helpers.mo_selenium_helper import get_locator_type
from helpers.mo_json_utils import *
from ui_config import imi_config_test_data
from locators.common.launchpad_page_locator import *



def verify_cloudpak_login_lables():
   wait_for_all_elements_to_load(mcm_cloudpak_header,"log in cloudpak label")
   is_element_clickable(mcm_default_login_link,"Login type")
   authentication_type= get_element_text(mcm_default_login_link)
   time.sleep(5)
   return authentication_type

def mcm_login_user (uservalue,m_password,m_isldaplogin):
    if m_isldaplogin == 'yes':
        wait_before_click(mcm_ldap_login_link, "Ldap Authentication type  ")
        logger.info("clicked in LDAP authentication type")
        wait_for_all_elements_to_load(mcm_username, "mcm username")
        type_value(mcm_username, uservalue, " MCM Username textbox")
        is_element_present(mcm_password, "mcm password")
        type_value(mcm_password, m_password, "MCM password textbox")
        wait_before_click(mcm_login_button, "Login Button")
        time.sleep(3)
        current_url = get_current_url()
        # wait_before_click(mcm_change_auth_type,"Change your authentication"

    else:
        if m_isldaplogin == 'no':
            wait_before_click(mcm_default_login_link, "Default Authentication Login ")
            logger.info("clicked in default authentication type")
            wait_for_all_elements_to_load(mcm_username, "mcm username")
            type_value(mcm_username, uservalue, " MCM Username textbox")
            is_element_present(mcm_password, "mcm password")
            type_value(mcm_password, m_password, "MCM password textbox")
            logger.info("Thsi is default login authentication..******")
            wait_before_click(mcm_login_button, "Login Button")
            time.sleep(3)
            current_url = get_current_url()

        else:
            current_url = get_current_url()
            logger.info("Default/LDAP Authentication type is not present..")

    return current_url



def mcm_get_manage_service_url():
    time.sleep(3)
    wait_for_spinner_off()
    current_url = get_current_url()
    logger.info("loading mcm manage services url ..")
    return current_url

def mcm_get_application_url():
    time.sleep(3)
    wait_for_spinner_off()
    current_url = get_current_url()
    logger.info("loading mcm manage applications url ..")
    return current_url

def mcm_get_goverence_risk_url():
    time.sleep(3)
    wait_for_spinner_off()
    current_url = get_current_url()
    logger.info("loading mcm governance risk url..")
    return current_url

def mcm_get_clusters_url():
    time.sleep(3)
    wait_for_spinner_off()
    current_url = get_current_url()
    logger.info("loading mcm manage clusters url..")
    return current_url








