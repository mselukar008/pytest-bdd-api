from datetime import date
from locators.store.approval_policies_locator import *
from pages.common.login_page import load_base_page
from pages.store.navigation_page import click_to_approval_policies
from pages.store.order_parameters_page import *
from helpers.mo_json_utils import *


def select_start_date():
    # Current date
    current = date.today().strftime("%m/%d/%Y")
    click(start_date, "Start date")
    click(start_date_picker, "Calendar")
    logger.info("Selected Start date: " + current)


def fill_policy_parameter_details(policy_parameter):
    fill_order_parameter(policy_parameter)


def fill_rule_parameter_details(rule_parameter):
    fill_order_parameter(rule_parameter)


def fill_policy_details(path):
    set_data_path(path)
    fill_policy_parameter_details(get_data("Policy Parameters"))
    fill_rule_parameter_details(get_data("Policy Rule Parameters"))


def retire_policy(path, policy_name):
    if path is not None:
        set_data_path(path)
    load_base_page(tenant)
    click_to_approval_policies()
    type_value_and_enter(search_textbox, policy_name, "Search textbox")
    wait_for_spinner_off()
    click(action_icon, "Policy action icon")
    click(edit_policy_btn, "Edit Policy")
    click(retired_radiobutton, "Retired")
    click(update_policy_btn, "Update")
    message = get_element_text(notification_text)
    click(notification_close_icon, "notification close icon")
    return message


def delete_policy(policy_name):
    click_to_approval_policies()
    type_value_and_enter(search_textbox, policy_name, "Search textbox")
    wait_for_spinner_off()
    click(action_icon, "Policy action icon")
    click(delete_policy_btn, "Delete")
    click(delete_confirmation_btn, "Delete confirmation")
    message = get_element_text(notification_text)
    wait_for_spinner_off()
    return message


def select_external_value_dropdown():
    click(external_dropdown, "External dropdown")
    click(external_dropdown_value, 'External value')


def delete_policies_if_exists():
    num = get_number_of_elements(policy_row, "Policies")
    if num > 0:
        policies_status = get_elements_texts(policy_status_text)
        for policy_status in policies_status:
            if policy_status == "Active":
                click(action_icon, "Policy action icon")
                click(edit_policy_btn, "Edit Policy")
                click(retired_radiobutton, "Retired")
                explicit_wait(2)
                click(update_policy_btn, "Update")
                click(notification_close_icon, "notification close icon")
                explicit_wait(5)
            else:
                click(action_icon, "Policy action icon")
                click(delete_policy_btn, "Delete")
                click(delete_confirmation_btn, "Delete confirmation")
                wait_for_spinner_off()
                explicit_wait(5)
        delete_policies_if_exists()
    else:
        logger.info("No Policies found")
