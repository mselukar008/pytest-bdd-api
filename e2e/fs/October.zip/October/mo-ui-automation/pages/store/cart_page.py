from helpers.mo_page_operations import *
from locators.store.cart_locator import *
from pages.common.launchpad_page import verify_home_page
from pages.store.navigation_page import open_catalog_page
from pages.store.order_parameters_page import add_to_shopping_cart
from pages.store.review_order_page import *
from tests.common_test import get_random_int, logout_and_login
from helpers.mo_check import mo_check as check
from pages.store.mo_store_utils import *
from locators.common.navigation_page_locator import *
from copy import deepcopy


def validate_cart_context_data(cart_name, owner_key="submittedBy"):
    logger.info('Validating cart context data')
    # Validations for Owner Details
    act_owner_details = dict(zip(get_elements_texts_replace_value(cart_owner_details_labels, cart_name),
                                 get_elements_texts_replace_value(cart_owner_details_values, cart_name)))
    check.is_in(mo_ui_test_data.get(owner_key), act_owner_details.get("Owner"), 'Owner')
    check.is_in(mo_ui_test_data.get("submittedBy"), act_owner_details.get("Created by"), 'Created By')
    # Validations for Cart Context
    act_cart_context = dict(zip(get_elements_texts_replace_value(cart_context_details_labels, cart_name),
                                get_elements_texts_replace_value(cart_context_details_values, cart_name)))
    check.is_in(act_cart_context.get("Team"), mo_ui_test_data.get("TeamName"), 'Team')
    check.is_in(act_cart_context.get("Organization"), mo_ui_test_data.get("Organization"), 'Organization')
    check.is_in(act_cart_context.get("Environment"), mo_ui_test_data.get("Environment"), 'Environment')
    check.is_in(act_cart_context.get("Application"), mo_ui_test_data.get("Application"), 'Application')


def validate_cart_ordered_service_data(cart_name, service_name, exp_estimated_cost, estimated_price_key="EstimatedPrice", 
                                       is_editing=False, edit_addtl_params_key='Edit Additional Parameters', provider_account_key='providerAccount'):
    logger.info('Validating cart service data')
    # Validations for Service
    if get_attribute_replace_value(cart_accordion_open, "aria-expanded", cart_name, "Cart Items") == "false":
        click_items_accordion(cart_name)
    wait_for_spinner_off()
    act_cart_service = dict(zip(get_elements_texts_replace_value(cart_service_table_details_labels, cart_name),
                                get_elements_texts_replace_value(cart_service_table_details_values,
                                                                 [cart_name, service_name])))
    check.is_in(act_cart_service.get("Service Instance Prefix"), service_name, 'Service Instance Prefix')
    check.is_in(act_cart_service.get("Service Offering Name"), get_data("bluePrintName"), 'Service Offering Name')
    check.is_in(act_cart_service.get("Provider"), get_data("provider"), 'Provider')
    click_cart_table_action(service_name, cart_name,cart_table_action_service_details_btn, "Cart --> View Service Details")
    get_cart_service_details_config(is_editing=is_editing, edit_addtl_params_key=edit_addtl_params_key)
    close_cart_service_details_slider(service_name)
    click_cart_table_action(service_name, cart_name, cart_table_action_bill_of_materials_btn,
                            "Cart --> View Bill of Materials")
    get_cart_service_bill_of_materials(exp_estimated_cost)
    close_cart_service_details_slider(service_name)


def get_cart_service_bill_of_materials(exp_estimated_cost):
    estimated_cost = get_element_text(cart_estimated_cost_txt)
    click_using_java_script(cart_bom_more_link, "More link")
    # Monthly Cost and One time cost calculation
    monthly_cost = sum_totals_by_locator(cart_monthly_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
    one_time_cost = sum_totals_by_locator(cart_one_time_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
    total_sum = sum_string_totals([monthly_cost, one_time_cost], exp_estimated_cost)
    check.equal(estimated_cost, exp_estimated_cost, 'Total Cost')
    check.equal(estimated_cost, total_sum, 'Monthly Cost and One Time Cost')


def click_items_accordion(cart_name):
    wait_for_spinner_off()
    click_with_replace_value(cart_accordion_btn, cart_name, 'Cart Accordion Button')


def click_cart_table_action(service_name, cart_name, action_locator, elem_name):
    wait_for_spinner_off()
    explicit_wait(2)
    click_with_replace_value(cart_table_action_btn, [cart_name, service_name], 'Cart Table Action Button')
    click_using_java_script(action_locator, elem_name)


def close_cart_service_details_slider(service_name):
    click_with_replace_value(cart_slider_close_btn, service_name, 'Cart Slider Close Button')


def get_cart_service_details_config(is_editing=False, edit_addtl_params_key='Edit Additional Parameters'):
    additional_params_titles = get_elements_texts(cart_addtl_params_labels)
    additional_params_values = get_elements_texts(cart_addtl_params_values)
    actual_service_details_ui = dict(zip(additional_params_titles, additional_params_values))
    if is_editing:
        addtnl_params_json_dic_data = merge_edit_additional_parameters(edit_addtl_params_key)
    else:
        addtnl_params_json_dic_data = get_data_object("Additional Parameters")
    for key, actual_value in actual_service_details_ui.items():
        expected_value = get_value(addtnl_params_json_dic_data["Additional Parameters"], key)
        if expected_value is not None:
            # Validates if the expected value is a list of values (multiselect options) and format the values
            if type(expected_value) == list:
                expected_value, actual_value = format_detail_multiple_values(expected_value, actual_value)
            # Validates the value in case the title exists more than one time
            if additional_params_titles.count(key) > 1:
                for idx, title in enumerate(additional_params_titles):
                    if title == key and expected_value in additional_params_values[idx]:
                        actual_value = additional_params_values[idx]
                        break
            check.is_in(expected_value.lower(), actual_value.lower(), key)


def check_cart_total_price(cart_name, exp_estimated_costs):
    logger.info('Validating cart total price')
    wait_for_spinner_off()
    try:
        actual_price = get_element_text_replace_value(cart_order_total_txt, cart_name, 'Cart Order Total Text')
    except:
        if is_element_present_replace_value(cart_fetch_total_price_link, cart_name):
            click_with_replace_value(cart_fetch_total_price_link, cart_name, 'Cart Fetch Total Price Link')
        actual_price = get_element_text_replace_value(cart_order_total_txt, cart_name, 'Cart Order Total Text')
    actual_prices = get_totals_from_string(actual_price)
    if len(actual_prices) > 0:
        actual_price = sum_string_totals(actual_prices, actual_prices[0])
    if type(exp_estimated_costs) == list:
        exp_estimated_costs = sum_string_totals(exp_estimated_costs, actual_price)
    check.is_in(exp_estimated_costs, actual_price, 'Cart Total Price')


def delete_cart(cart_name):
    logger.info('Deleting cart')
    click_cart_action(cart_name, "Delete Cart")
    check.is_in(cart_data.get("deleteCartMessage"), get_element_text(cart_delete_modal_msg_txt))
    click(cart_delete_confirm_btn, 'OK')
    check.is_in(cart_data.get("cartDeletedMessage"), get_element_text(cart_delete_toast_body_txt))
    close_toast_notification()


def click_cart_action(cart_name, action_name):
    wait_for_spinner_off()
    click_with_replace_value(cart_action_btn, cart_name, 'Cart Action Button')
    click_using_script_replace_value(cart_action_option_btn, action_name, 'Cart Action Option')


def validate_added_to_cart_msg(cart_name, service_name):
    success_msg = f"{get_element_text(cart_success_msg_txt)} {get_element_text(cart_success_cart_name_txt)}"
    check.is_in(cart_data.get('addedToCartMessage').format(service_name, cart_name), success_msg)


def cart_create_and_verify_order(service_prefix, json_path, cart_name=None, modify_params=dict(), est_cost_key='TotalCost', pricing_key='Pricing'):
    service_name = get_random_int(service_prefix)
    modify_param = {'Service Instance Prefix': service_name, **modify_params}
    modify_parameter(modify_param)
    # Steps to create new order
    open_catalog_page()
    select_service_template(json_path)
    verify_catalog_details_page()
    click_on_configure_btn()
    cart_name = add_to_shopping_cart(cart_name)
    fill_order_details()
    # Check all the parameters are correct
    verify_review_order()
    exp_estimated_cost = get_data(est_cost_key)
    check.is_in(get_estimated_price_review_order(), exp_estimated_cost)
    # Validate the pricing
    validate_bom_review_order_page(pricing_key)
    click_add_to_cart()
    # Validate added to cart success message
    validate_added_to_cart_msg(cart_name, service_name)
    # wait_for_spinner_off()
    return service_name, cart_name, exp_estimated_cost, modify_param

def edit_cart_item(service_name, cart_name):
    logger.info('Editing cart item')
    click_cart_table_action(service_name, cart_name, cart_table_action_edit_btn, "Cart --> Edit Service")
    wait_for_spinner_off()
    
    
def save_edited_cart_item(cart_name):
    click(cart_edit_item_save_btn, 'Save Edited Cart Item Button')
    wait_for_spinner_off()
    validate_edited_cart_item_msg(cart_name)
    
    
def validate_edited_cart_item_msg(cart_name):
    success_msg = f"{get_element_text(cart_success_msg_txt)} {get_element_text(cart_success_cart_name_txt)}"
    check.is_in(cart_data.get('editedCartItemMessage').format(cart_name), success_msg)


def delete_cart_item(service_name, cart_name):
    logger.info('Deleting cart item')
    click_cart_table_action(service_name, cart_name, cart_table_action_delete_btn, "Cart --> Delete Service")
    check.is_in(cart_data.get("deleteCartItemMessage"), get_element_text(cart_delete_item_modal_txt))
    click(cart_delete_item_confirm_btn, 'OK')
    check.is_in(cart_data.get("cartItemDeletedMessage"), get_element_text(cart_delete_item_body_txt))
    close_toast_notification()


def cart_submit_order(cart_name):
    logger.info('Submiting cart order')
    wait_for_spinner_off()
    click_with_replace_value(cart_submit_order_btn, cart_name, 'Cart Submit Order Button')
    wait_for_spinner_off()
    click(cart_modal_submit_order_btn, "Submit Order confirmation button")


def get_cart_order_id():
    wait_for_spinner_off()
    order_id = get_element_text(cart_order_number_txt)
    logger.info("Order number: " + order_id)
    return order_id.strip()


def edit_cart_context(cart_name):
    logger.info('Editing cart context')
    click_cart_action(cart_name, 'Edit Cart Context')
    wait_for_spinner_off()
    check.is_in(cart_data.get("editCartContextTitle"), get_element_text(cart_edit_context_title))
    new_cart_name = fill_edit_cart_context()
    click(cart_edit_context_update_btn, 'Update')
    check.is_in(cart_data.get("editCartContextMessage"), get_element_text(cart_edit_context_toast_body_txt))
    close_toast_notification()
    return new_cart_name


def fill_edit_cart_context():
    edit_cart_data = deepcopy(cart_data["editCartContextTemplate"])
    edit_cart_data['Cart Name']['value'] = get_random_int(edit_cart_data['Cart Name']['value'])
    for key, data in edit_cart_data.items():
        get_filtered_data(data, key)
    return edit_cart_data['Cart Name']['value']


def empty_cart(cart_name):
    logger.info('Emptying cart')
    click_cart_action(cart_name, "Empty Cart")
    check.is_in(cart_data.get("emptyCartMessage"), get_element_text(cart_empty_modal_msg_txt))
    click(cart_empty_confirm_btn, 'OK')
    check.is_in(cart_data.get("cartEmptiedMessage"), get_element_text(cart_empty_toast_body_txt))
    close_toast_notification()
    click_items_accordion(cart_name)
    wait_for_spinner_off()
    check.equal(get_elements_count_replace_value(cart_table_empty, cart_name), 1)


def transfer_cart(cart_name):
    logger.info('Transfering cart')
    transfer_user = users_data['transfer_user']
    click_cart_action(cart_name, 'Transfer Cart')
    text_input_search(cart_transfer_input, transfer_user.get('user'), 'Transfer user account')
    click(cart_transfer_btn, 'Transfer button')
    click(cart_transfer_btn, 'Transfer button confirmation')
    # Commenting the success message validation for time being as its disaapearing quickly and not possible to capture
    # WIll uncomment once proper code is in place
    #     check.is_in(cart_data.get('transferredCartMessage').format(transfer_user.get('user')), get_element_text(cart_transfer_toast_body))
    #     close_toast_notification()
    logout_and_login(transfer_user)
    verify_home_page()
    open_catalog_page()
    wait_for_spinner_off_with_timer(200)
    # wait_for_element_to_visible(service_card, 'Catalog service cards')
    switch_to_default_content_iframe()
    click(cart_catalog_icon, 'Cart icon button')
    click(cart_sidebar_view_all_carts_btn, 'View all Carts')
    switch_to_iframe(mo_iframe_xpath)


def add_service_to_cart(json_data_path, service_name, cart_name=None, imi=None, snow=False):
    open_catalog_page()
    select_service_template(json_data_path)
    click_on_configure_btn()
    if snow:
        cart_name = add_to_shopping_cart(cart_name, snow=True)
    else:
        cart_name = add_to_shopping_cart(cart_name)
    if imi:
        fill_order_details(None, "imi")
    else:
        fill_order_details()
    click_add_to_cart()
    validate_added_to_cart_msg(cart_name, service_name)
    wait_for_spinner_off()
    return cart_name


def close_toast_notification():
    try:
        click(cart_toast_close_icon, 'Toast close button')
    except TimeoutException:
        logger.info("Timeout - Unable to click on Toast Close button")
