from locators.landingzone.landing_zone_catalog_locator import *
from locators.store.terraprovider_locator import terraform_home_page, provider_management_link
from pages.common.mo_navigation_page import *
from locators.store.catalog_management_locator import manage_catalog_button
from locators.common.platform_management_page_locator import platform_mngmt_page_header
from locators.store.budget_page_locator import budget_unit_table_options_btn, budgetary_units_table


def get_new_catalog_url(repeat=5):
    if repeat > 0:
        url = get_current_url()
        if "storeFrontV2" not in url:
            explicit_wait(5)
            repeat = repeat - 1
            logger.info("New Catalog view not loaded")
            get_new_catalog_url(repeat)
        else:
            logger.info("New Catalog view loaded")


def open_catalog_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    click_to_menu_option(mo_ui_test_data["catalogLinkText"])
    #get_new_catalog_url()
    #wait_for_loading_on()
    #wait_for_loading_off()
    wait_for_spinner_off_with_timer(120)
    switch_to_iframe(mo_iframe_xpath)


def click_to_order_history():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    switch_to_page_frame("Order History")


def open_approve_orders_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    switch_to_page_frame("Approve Orders")


def open_landing_zone_page_menu(menu):
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    click_to_menu_expandable_option(mo_ui_test_data["LandingZoneBtnText"])
    click_with_replace_value(landing_zone_dashboard_menu, menu, f"Click Menu: {menu}")

def open_ordered_services_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    switch_to_page_frame(mo_ui_test_data["orderedServicesLinkText"])
    wait_for_spinner_off()
    # Commenting below lines as they are increasing execution time
    # wait_for_spinner_on()
    # wait_for_spinner_off()


def click_to_catalog_management():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    switch_to_page_frame("Catalog Management")


def click_to_approval_policies():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    switch_to_page_frame("Approval Policies")


def click_to_operation_policies():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    switch_to_page_frame("Operation Policies")


def open_budget_management():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["adminBtnText"])
    click_to_menu_option('Budget Management')
    check_presence_of_element_dom(budgetary_units_table, 120)



def open_platform_management():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["adminBtnText"])
    click_to_menu_option(mo_ui_test_data["IAMLinkText"])
    explicit_wait(2)
    is_element_present(platform_mngmt_page_header, "Platform Management Page", 15)
    wait_for_spinner_off()


# Open Insights page
def open_insights_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["costAssetMgmntBtnText"])
    click_to_menu_option(mo_ui_test_data["insightsPageLinkText"])
    wait_for_spinner_off()


# Open Costs page
def open_costs_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["costAssetMgmntBtnText"])
    click_to_menu_option(mo_ui_test_data["costsPageLinkText"])
    wait_for_spinner_off()


# Open Assets page
def open_assets_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["costAssetMgmntBtnText"])
    click_to_menu_option(mo_ui_test_data["assetsPageLinkText"])
    wait_for_spinner_off()


# Open Dynamic Resource Groups page
def open_drg_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["costAssetMgmntBtnText"])
    click_to_menu_expandable_option(mo_ui_test_data["SettingsBtnText"])
    click_to_menu_option(mo_ui_test_data["drgPageLinkText"])
    wait_for_spinner_off()


# Open Order History page
def open_order_history_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    click_to_menu_option(mo_ui_test_data["orderHistoryLinkText"])
    switch_to_iframe(mo_iframe_xpath)
    wait_for_spinner_off()


# Open System Settings page
def open_system_settings_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["adminBtnText"])
    click_to_menu_expandable_option(mo_ui_test_data["globalSettingsBtnText"])
    click_to_menu_option(mo_ui_test_data["systemSettingsLinkText"])
    wait_for_spinner_off()


# Open UserAccess Management page
def open_user_access_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["adminBtnText"])
    click_to_menu_option(mo_ui_test_data["userAccess"])
    wait_for_spinner_off()


# Open Context Type page
def open_contexts_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["adminBtnText"])
    click_to_menu_option(mo_ui_test_data["contextType"])
    wait_for_spinner_off()


# Open Catalog Management page
def open_catalog_management_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    switch_to_page_frame(mo_ui_test_data["catalog_management"])
    wait_for_spinner_off()
    wait_for_spinner_on()
    wait_for_spinner_off()
    if is_element_present(manage_catalog_button,"Manage_Catalog_button"):
        click(manage_catalog_button,"Manage_Catalog_button")
    wait_for_spinner_off()


# Open Topology page
def open_topology_page():
    click_to_Open_menu()
    click_to_menu_expandable_option("Topology")
    click_to_menu_option("View Topology")
    wait_for_spinner_off()


def open_quotes_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    click_to_menu_option(mo_ui_test_data["quotesLinkText"])
    wait_for_spinner_off()


def open_terraform_provider_management_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    click_to_menu_option(mo_ui_test_data["terraformProviderLinkText"])
    wait_for_spinner_off()
    explicit_wait(2)
    if is_element_not_present(terraform_home_page, "Terraform Home Page"):
        click(provider_management_link, "terraform page")


def open_provider_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["adminBtnText"])
    click_to_menu_option(mo_ui_test_data["providerLinkText"])
    wait_for_spinner_off()


def open_itsm_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    click_to_menu_option(mo_ui_test_data["itsmLinkText"])
    switch_to_iframe(mo_iframe_xpath)
    wait_for_spinner_off()


def open_provider_account_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["adminBtnText"])
    click_to_menu_option(mo_ui_test_data["ProviderAccount"])
    wait_for_spinner_off()


def open_pricing_management():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["adminBtnText"])
    click_to_menu_option(mo_ui_test_data["PricingManagement"])
    wait_for_spinner_off()


def open_asset_library_page():
    click_to_Open_menu()
    click_to_menu_expandable_option("Asset Library")
    click_to_menu_option("Dashboard")
    wait_for_spinner_off()


# Open Service Chaining page
def open_service_chaining_page():
    click_to_Open_menu()
    click_to_menu_expandable_option(mo_ui_test_data["enterpriseMarketplaceBtnText"])
    click_to_menu_option("Service Chaining")
    switch_to_iframe(mo_iframe_xpath)
    wait_for_spinner_off()