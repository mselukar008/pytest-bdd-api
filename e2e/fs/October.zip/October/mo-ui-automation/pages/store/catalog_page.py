from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_exception_utils import exceptions_decorator
from helpers.mo_json_utils import *
from helpers.mo_page_operations import wait_for_spinner_on, wait_for_spinner_off_with_timer
from locators.store.catalog_page_locator import *
from helpers.mo_check import mo_check as check
from locators.store.review_order_locator import next_btn_path
from pages.store.order_parameters_page import fill_order_parameter, go_next_or_previous_in_order_page, click_next_btn
from pages.store.mo_store_utils import get_filtered_data, merge_imi_additional_parameters


def select_provider_type(provider):
    wait_for_spinner_on()
    wait_for_spinner_off()
    logger.info(f"Provider Name: {provider}")
    #scroll_element_into_view_with_replace_value(provider_path, provider)
    try:
        click_using_script_replace_value(provider_path, provider, 'Provider')
    except:
        explicit_wait(3)
        wait_for_spinner_off_with_timer(120)
        click_using_script_replace_value(provider_path, provider, 'Provider')
    wait_for_spinner_on()
    wait_for_spinner_off()


def click_category_type(category):
    logger.info(f"Category Name: {category}")
    scroll_element_into_view_with_replace_value(category_path, category)
    click_using_script_no_wait_replace_value(category_path, category, 'Category Type')
    wait_for_spinner_on()
    wait_for_spinner_off()


def click_service_name(service_name):
    found = False
    end_of_services = False
    while not found and not end_of_services:
        # If service is found click the card
        if is_element_present_replace_value(service_name_path, service_name):
            click_using_script_replace_value(service_name_path, service_name, 'Service Name')
            found = True
            continue
        # If not found scroll to bottom to load more services
        found=scroll_to_service_instance_and_click(service_name)
    # scroll_element_into_view_with_replace_value(service_name_path, service_name)
    # If footer loader is not present all services are loaded
    if not wait_for_spinner_on():
        end_of_services = True
    if not found:
        raise Exception('Service was not found')
    wait_for_spinner_off()


def click_custom_service_name(SOI_ID):
    found = False
    end_of_services = False
    while not found and not end_of_services:
        # If service is found click the card
        if is_element_present_replace_value(custom_service_name_path, SOI_ID):
            click_using_script_replace_value(custom_service_name_path, SOI_ID, 'SOI_ID')
            found = True
            continue
        # If not found scroll to bottom to load more services
        found=scroll_to_service_instance_and_click(SOI_ID)
    # scroll_element_into_view_with_replace_value(service_name_path, service_name)
    # If footer loader is not present all services are loaded
    if not wait_for_spinner_on():
        end_of_services = True
    if not found:
        raise Exception('Service was not found')
    wait_for_spinner_off()

def scroll_to_service_instance_and_click(service_name):
    found= False
    driver.execute_script("document.getElementsByClassName('content--section patterns-scrollable-list')[0].scrollBy(0, 5000);")
    wait_for_spinner_off()
    try:
        if is_element_present_replace_value(service_name_path, service_name):
            click_using_script_replace_value(service_name_path, service_name, 'Service Name')
            found = True
    except:
        logger.info("Element not visible")

    return found

def select_service_template(path):
    set_data_path(path)
    select_provider_type(get_data("provider"))
    click_category_type(get_data("Category"))    
    click(search_filter_close_button , "Search filter close button")
    click_service_name(get_data("bluePrintName"))
    wait_for_spinner_off()


def fill_order_details(path=None, imi=None):
    if path:
        set_data_path(path)
    fill_main_parameter_details(get_data("Main Parameter"))
    if imi:
        test_data = merge_imi_additional_parameters()
        fill_additional_parameter_details(test_data["Additional Parameters"])
    else:
        fill_additional_parameter_details(get_data("Additional Parameters"))


def fill_edit_order_details(path=None, edit_main_params_key='Edit Main Parameter',
                            edit_addtl_params_key='Edit Additional Parameters'):
    if path is not None:
        set_data_path(path)
    fill_main_parameter_details(get_data(edit_main_params_key))
    fill_additional_parameter_details(get_data(edit_addtl_params_key))


def click_on_configure_btn():
    click_using_java_script(configure_btn_path, "Service Configure button")


def click_on_generate_quote_btn():
    click_using_java_script(generate_quote_btn_path, "Generate Quote button")


def fill_main_parameter_details(main_parameter):
    new_main_params = main_parameter
    if "env" in new_main_params["Main Parameters"].keys():
        environment = main_parameter["Main Parameters"]["env"]["value"]
        new_main_params["Main Parameters"].update({"env": mo_ui_test_data["env"]})
        new_main_params["Main Parameters"]["env"].update({"value": environment})
    if "App" in new_main_params["Main Parameters"].keys():
        application = main_parameter["Main Parameters"]["App"]["value"]
        new_main_params["Main Parameters"].update({"App": mo_ui_test_data["App"]})
        new_main_params["Main Parameters"]["App"].update({"value": application})
    if "Team" in new_main_params["Main Parameters"].keys():
        teamName = main_parameter["Main Parameters"]["Team"]["value"]
        new_main_params["Main Parameters"].update({"Team": mo_ui_test_data["Team"]})
        new_main_params["Main Parameters"]["Team"].update({"value": teamName})
    fill_order_parameter(new_main_params)


def fill_additional_parameter_details(additional_parameters, path=None):
    if path:
        set_data_path(path)
    fill_order_parameter(additional_parameters)


# Allows to move next or previous in edit page
def go_next_or_previous_in_edit(back=False):
    go_next_or_previous_in_order_page(get_data("Edit Main Parameter"), back=back)
    go_next_or_previous_in_order_page(get_data("Edit Additional Parameters"), back=back)


# Verify all assertions from Catalog details page
@exceptions_decorator
def verify_catalog_details_page():
    check.equal(get_element_text(service_name_text), get_data("bluePrintName"), 'Service Name')
    if get_data("BasePrice"):
        check.equal(str(get_element_text(base_price_text)), get_data("BasePrice"), 'Base Price')

    check.equal(get_element_text(available_versions_label_text),
                mo_ui_test_data["availableVersionsLabelText"], 'Available Versions Label')
    headers_list = get_elements_texts(details_page_label_text)
    if headers_list:
        for header_name in [(mo_ui_test_data["associatedContextLabelText"], 'Associated Context Label'),
                            (mo_ui_test_data["featuresLabelText"], 'Features Label'),
                            (mo_ui_test_data["detailsLabelText"], 'Details Label')]:
            check.is_in(header_name[0], headers_list, header_name[1])


# Selects available version
def select_available_version(version_param_key):
    version_param = get_data(version_param_key)
    get_filtered_data(version_param, 'Available Version')
    return version_param.get('value')


# Verify selected version on text button
def validate_selected_version_button_text(version):
    wait_for_element_text(configure_btn_path, version, 'Version')
    check.is_in(version, get_element_text(configure_btn_path), 'Button Version Text')


# Validate presence of searched label and select it
def validate_and_select_label(label_value):
    scroll_element_into_view(select_label_dropdown)
    wait_before_click(select_label_dropdown, "Label dropdown")
    wait_for_element_to_visible(search_label_input, "Search label input")
    type_value_and_enter(search_label_input, label_value.lower(), "Search label input")
    wait_for_element_to_visible_with_replace_value(label_option_checkbox, label_value, "Label option checkbox")
    check.is_true(is_element_present_replace_value(label_option_checkbox, label_value))
    click_with_replace_value(label_option_checkbox, label_value, "Label option checkbox")
    wait_for_spinner_off()


def get_text_base_price():
    wait.until(EC.visibility_of_element_located(base_price_text))
    estimated_cost = get_element_text(base_price_text)
    return estimated_cost


def search_service_name_catalog(service_name):
    type_value_and_enter(search_service_name_path, service_name, "Service instance name search")
    # wait_for_element_to_visible_with_replace_value(service_tile_txt, service_name, 'Service Instance Text')


def verify_text_labels_header(test_data_path):
    set_data_path(test_data_path)
    check.equal(get_element_text(labels_header_text), get_data("labelsHeader"), 'Labels Header')
    check.equal(get_element_text(labels_dropdown_text), get_data("labelsDropdownText"), 'labels Dropdown Text')


def verify_labels_dropdown_count(test_data_path):
    set_data_path(test_data_path)
    if is_element_present(dropdown_labels, "dropdown labels"):
        click(dropdown_labels, "dropdown labels")
    time.sleep(3)
    labels_count = get_elements_count(dropdown_values_label)
    if check.greater(labels_count, 0):
        if is_element_present(dropdown_item_more, "dropdown item more"):
            click(dropdown_item_more, "Dropdown Item More")
            check.greater_equal(str(get_elements_count(dropdown_values_label)), get_data("labelCount"), 'Labels Count')

    click(dropdown_labels, "dropdown labels")
    wait_for_spinner_off()


def verify_service_on_the_label(label_value, service_title, service_count):
    validate_and_select_label(label_value)
    card_service_list = get_elements_texts(card_service_title)
    check.equal(str(len(card_service_list)), service_count)
    for title in service_title.split(","):
        check.is_in(str(card_service_list), title)


def click_on_the_close_button():
    click(close_button, "close button")
    wait_for_spinner_off()


def verify_catalog_page_detail():
    click_service_name(get_data("bluePrintName"))
    check.equal(str(get_element_text(label_detail)), get_data("vra8.5Label"), 'label_value')


def validate_group_name(group_name):
    confi_group_name = get_element_text_replace_value(config_group_name, group_name, 'config name')
    check.equal(confi_group_name, group_name, 'config name')


def validate_section_name(section_name):
    while True:
        if is_element_present_replace_value(section_name_xpath, section_name):
            check.is_in(get_element_text_replace_value(section_name_xpath, section_name, 'Section name'), section_name,
                        'Section name')
            click_using_script_replace_value(section_name_xpath, section_name, 'Section name')
            click_next_btn()
            wait_for_spinner_off()
        elif is_element_not_present(next_btn_path, "next button"):
            break
        else:
            click_next_btn()
            wait_for_spinner_off()


def fill_order_details_config(path=None, group_name=None, section_name=None):
    if path is not None:
        set_data_path(path)
    fill_main_parameter_details(get_data("Main Parameter"))
    if section_name is None:
        validate_group_name(group_name)
        fill_additional_parameter_details(get_data("Additional Parameters"))
    if group_name is not None and section_name is not None:
        validate_group_name(group_name)
        validate_section_name(section_name)


def click_service_menu_icon(service_name, duplicate_name=False):
    found = False
    end_of_services = False
    while not found and not end_of_services:
        # If service is found click the card
        if is_element_present_replace_value(service_menu_icon, service_name):
            if duplicate_name:
                click_using_script_replace_value(service_menu_for_duplicate_name_icon, service_name, 'Service Menu')
            else:
                click_using_script_replace_value(service_menu_icon, service_name, 'Service Menu')
            found = True
            continue
        # If not found scroll to bottom to load more services
        scroll_element_into_view(catalog_footer_loader)
        # If footer loader is not present all services are loaded
        if not wait_for_spinner_on():
            end_of_services = True
    if not found:
        raise Exception('Service was not found')
    wait_for_spinner_off()


def select_service_menu(path, learn=False):
    set_data_path(path)
    select_provider_type(get_data("provider"))
    click_category_type(get_data("Category"))
    if learn:
        click_service_menu_icon(get_data("bluePrintName"), duplicate_name=True)
    else:
        click_service_menu_icon(get_data("bluePrintName"))
    wait_for_spinner_off()


def click_on_generate_quote():
    click(generate_quote_btn, "Generate Quote")


def verify_edit_parameter_old_values():
    old_values_before_edit = get_elements_texts(edit_parameter_old_values)
    additional_parameter = get_data("Additional Parameters")
    edit_parameter_old_values_path = additional_parameter["Service Additional Parameters"]
    for value in old_values_before_edit :
        if value == old_values_before_edit[0] :
            check.equal(value, edit_parameter_old_values_path["AWS Region Name"]["value"],"First Old Value before Edit Service")
        elif value == old_values_before_edit[1] :
            check.equal(value, edit_parameter_old_values_path["Virtual Private Cloud"]["value"],"Second Old Value before Edit Service")
        elif value == old_values_before_edit[2] :
            check.equal(value, edit_parameter_old_values_path["Subnet Name"]["value"],"Third Old Value before Edit Service")
        else:
            check.is_in(value, edit_parameter_old_values_path["Public SSH Key Name"]["value"],"Fourth Old Value before Edit Service")


def validate_edit_service_old_values():
    check.is_true(is_element_present(edit_parameter_old_selection, "Edit Parameter Old Selection Values"),
                  "Edit Parameter Old Selection Values")
    edit_parameter_old_selection_list = get_elements_texts(edit_parameter_old_selection)
    for value in edit_parameter_old_selection_list:
        check.is_in(value, get_data("valueChangedFromText"), "Value changed from Text: ")
        logger.info("The Edit parameter old_selection values are : {}".format(value))


def verify_multiple_cloud_connections():
    click(previous_button_reviewOrder, "Review Order Previous Button")
    wait_for_spinner_off()
    click(previous_button_additionalParams, "Additional Parameter Previous Button")
    wait_for_spinner_off()
    click(connection_dropdown_arrow, "Connection Dropdown Arrow")
    check.greater(get_elements_count(connection_dropdown_item), 2, "Connection Dropdown Items")
    connection_dropdown_item_list = get_elements_texts(connection_dropdown_item)
    for value in connection_dropdown_item_list:
        logger.info("The available cloud connections are : {}".format(value))


def verify_multiple_pricing_plans(path1,path2):
    set_data_path(path1)
    small_plan_path = get_data("Additional Parameters")
    medium_plan_path = get_data("Edit Additional Parameters")
    large_plan_path = get_data("Edit Additional Parameters Version")
    onetime_charge_path = get_data("Edit Additional Parameters Onetime charge Plan")
    plan_C_slotwise_path = get_data("Edit Additional Parameters PlanC slot-wise additional Plan")
    plan_D_zero_price_path = get_data("Edit Additional Parameters Zero Price Plan")
    set_data_path(path2)
    plan_base_A_path = get_data("Additional Parameters")
    plan_base_B_path = get_data("Edit Additional Parameters")
    click(plan_dropdown_arrow, "Pricing Plan Dropdown Arrow")
    check.equal(get_elements_count(plan_dropdown_item), 8, "Pricing Plan Dropdown Items")
    pricing_plan_dropdown_item_list = get_elements_texts(plan_dropdown_item)
    if pricing_plan_dropdown_item_list :
        for pricing_plan_value in [(small_plan_path["Plan"]["Instance Plan"]["value"], 'Small Pricing Plan'),
                                   (medium_plan_path["Plan"]["Instance Plan"]["value"], 'Medium Pricing Plan'),
                                   (large_plan_path["Plan"]["Instance Plan"]["value"], 'Large Pricing Plan'),
                                   (onetime_charge_path["Plan"]["Instance Plan"]["value"], 'Onetime Charge Plan'),
                                   (plan_base_A_path["Plan"]["Instance Plan"]["value"], 'Plan A base'),
                                   (plan_base_B_path["Plan"]["Instance Plan"]["value"], 'Plan B base and additional price'),
                                   (plan_D_zero_price_path["Plan"]["Instance Plan"]["value"], 'Plan D zero price'),
                                   (plan_C_slotwise_path["Plan"]["Instance Plan"]["value"],'Plan C slot-wise additional')]:
            check.is_in(pricing_plan_value[0], pricing_plan_dropdown_item_list, pricing_plan_value[1])


def click_on_all_patterns_tab():
    wait_for_element_to_visible(all_patterns_tab, "All Patterns Tab")
    click_using_java_script(all_patterns_tab, "All Patterns Tab")


def verify_pattern_on_catalog(pattern_name):
    click_on_all_patterns_tab()
    wait_for_element_to_visible(first_pattern_on_catalog, "First Pattern")
    # created_pattern = get_element_text_replace_value(created_pattern_text, pattern_name, "Pattern Name")
    patterns = get_elements_texts(all_patterns_on_catalog)
    for value in patterns:
        if value == pattern_name:
            logger.info("Pattern sucessfully imported on catalog page:" + pattern_name)
            break
        else:
            logger.info("Pattern is not present on catalog page")


def select_pattern_from_catalog_page(pattern_name):
    # click_on_all_patterns_tab()
    # patterns = get_elements_texts(all_patterns_on_catalog)
    # for value in patterns:
    #     if value == pattern_name:
    #         logger.info("Pattern sucessfully imported on catalog page:" + pattern_name)

    scroll_element_into_view_with_replace_value(pattern, pattern_name)
    click_using_script_replace_value(pattern, pattern_name, "Pattern")


def verify_catalog_detail_page_for_pattern():
    check.equal(get_element_text(pattern_name_text), get_data("bluePrintName"), 'Pattern Name')
    headers_list = get_elements_texts(details_page_label_text)
    if headers_list:
        for header_name in [(get_data("patternLabelText"), 'Pattern Label'),
                            (get_data("detailsLabelText"), 'Details Label'),
                            (get_data("associatedContextLabelText"), 'Associated Context Label')]:
            check.is_in(header_name[0], headers_list, header_name[1])


def click_on_pattern_options(pattern_name):
    click_using_script_replace_value(pattern_options_icon, pattern_name, "Options icon")


def click_on_pattern_action(pattern_name, action):
    if action == "Learn More":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_pattern, [pattern_name, "Learn More"], "Learn More")
        click_using_script_replace_value(action_button_based_on_pattern, [pattern_name, "Learn More"], "Learn More")

    elif action == "Place Order":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_pattern, [pattern_name, "Place Order"], "Place Order")
        click_using_script_replace_value(action_button_based_on_pattern, [pattern_name, "Place Order"], "Place Order")
