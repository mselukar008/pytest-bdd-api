from locators.store.provider_page_locator import *
from pages.store.navigation_page import *


def get_all_provider_page_providers():
    scroll_element_into_view(pagination_dropdown)
    click(pagination_dropdown, "Pagination")
    click_with_replace_value(pagination_option, "30", "30")
    providers = get_elements_texts(provider_page_providers_list)
    return providers
