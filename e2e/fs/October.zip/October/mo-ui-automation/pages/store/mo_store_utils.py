import re
from helpers.mo_driver_manager import logger
from helpers.mo_element_operations import *
from helpers.mo_selenium_helper import get_locator_type
from helpers.mo_json_utils import *
from ui_config import imi_config_test_data
from helpers.mo_base_locator import css_selector
from mo_encryption_decryption import *
from conftest import get_test_file_name


# Merge main parameters with edit main parameters
def merge_edit_main_parameters(edit_main_params_key='Edit Main Parameter'):
    original = get_data("Main Parameters", get_data("Main Parameter"))
    new = get_data("Main Parameters", get_data(edit_main_params_key))
    dict_merge(original, new)
    return original


# Merge additional parameters with edit additional parameters
def merge_edit_additional_parameters(edit_addtl_params_key='Edit Additional Parameters'):
    original = get_data_object("Additional Parameters")['Additional Parameters']
    new = get_data_object(edit_addtl_params_key)[edit_addtl_params_key]
    # Remove Configure Addon config for supporting services as it is not applicable for Edit operations
    try:
        del original["Configure Add-ons"]
    except KeyError:
        logger.info("Configure Addon key not applicable")
    dict_merge(original, new)
    return {'Additional Parameters': original}


# Merge additional parameters with IMI add-on parameters
def merge_imi_additional_parameters():
    original = get_data_object("Additional Parameters")['Additional Parameters']
    new = imi_config_test_data["Configure Add-on"]
    dict_merge(original, new)
    return {'Additional Parameters': original}


# Adds all values found by a locator
def sum_totals_by_locator(locator, exp_cost, round_next_dec=True):
    costs = get_visible_elements_texts(locator)
    total = 0.00
    format_exp_cost, num_decimals = _get_number_decimals_and_value(exp_cost)
    currency = _get_currency(exp_cost)
    if costs:
        for cost in costs:
            split_cost = cost.split(' ')
            try:
                float_cost = float(split_cost[1].replace(',', '').replace(')', ''))
            except ValueError:
                logger.error('Value cannot be parsed to float')
                return None
            total += float_cost
        if str(total)[::-1].find('.') > num_decimals:
            total = truncate_float(total, num_decimals)
        if float(format_exp_cost) > total and round_next_dec:
            total = _round_to_next_decimal(total, num_decimals)
        return f"{currency} {total:,.{num_decimals}f}"


# Used to multiple values in a detail (multiselect options), sort and concat the values with comma
def format_detail_multiple_values(expected_value, actual_value):
    expected_value = [i.strip() for i in expected_value]
    expected_value.sort()
    expected_value = (',').join(expected_value)
    actual_value_list = actual_value.split(',')
    actual_value_list = [i.strip() for i in actual_value_list]
    actual_value_list.sort()
    actual_value = (',').join(actual_value_list)
    return (expected_value, actual_value)


# Takes some totals strings values and adds them
# values -> list[str] of totals
def sum_string_totals(values, actual_cost):
    total = 0.00
    format_actual_cost, num_decimals = _get_number_decimals_and_value(actual_cost)
    currency = _get_currency(actual_cost)
    for value in values:
        split_cost = value.split(' ')
        try:
            float_cost = float(split_cost[1].replace(',', ''))
        except ValueError:
            logger.error('Value cannot be parsed to float')
            return None
        total += float_cost
    if str(total)[::-1].find('.') > num_decimals:
        total = truncate_float(total, num_decimals)
    if float(format_actual_cost) > total:
        total = _round_to_next_decimal(total, num_decimals)
    return f"{currency} {total:,.{num_decimals}f}"


# Takes some totals strings values and subtract them
# values -> list[str] of totals, subtract according list order
def subtract_string_totals(values, actual_cost):
    total = 0.00
    format_actual_cost, num_decimals = _get_number_decimals_and_value(actual_cost)
    currency = _get_currency(actual_cost)
    index = 0
    for value in values:
        split_cost = value.split(' ')
        try:
            float_cost = float(split_cost[1].replace(',', ''))
        except ValueError:
            logger.error('Value cannot be parsed to float')
            return None
        if index == 0:
            total = float_cost
        else:
            total -= float_cost
        index += 1
    if str(total)[::-1].find('.') > num_decimals:
        total = truncate_float(total, num_decimals)
    if float(format_actual_cost) > total:
        total = _round_to_next_decimal(total, num_decimals)
    return f"{currency} {total:,.{num_decimals}f}"


# Gets the currency of the total
def _get_currency(value):
    split_cost = value.split(' ')
    regex = re.compile(r'[^A-Za-z]')
    currency = re.sub(regex, '', split_cost[0])
    return currency


#  Returns the number of decimals of a number
def _get_number_decimals_and_value(value):
    regex = re.compile(r'[^0-9\.]')
    format_value = re.sub(regex, '', value)
    dec_arr = format_value.split('.')
    return format_value, len(dec_arr[1])


# Adds the next decimal to a number
def _round_to_next_decimal(number, num_decimals):
    zero_dec = ('').join(['0'] * (num_decimals - 1))
    decimal = f'0.{zero_dec}1'
    number = number + float(decimal)
    return number


# Takes a string with totals and extract the multiple values
def get_totals_from_string(string_total: str):
    currency = string_total.split(' ')[0]
    regex_pattern = re.compile(r"{} [0-9]+\.[0-9]+".format(currency))
    totals = re.findall(regex_pattern, string_total)
    if not totals:
        return list()
    return totals


# Truncate a float value to avoid rounding
def truncate_float(num, n):
    integer = int(num * (10 ** n)) / (10 ** n)
    return float(integer)


# Gets and parse the locator in the dictionary
def get_locator(filter_data):
    return list({'css selector' if k in 'css' else k: v for k, v in filter_data.items() if
                 k == 'id' or k == 'css' or k == 'xpath'}.items())[0]


# Format parameters to fill the fields
def get_filtered_data(data, key):
    if data and data.get('type'):
        locator = get_locator(data)
        if data.get('type') == 'RadioButton':
            locator = (css_selector, "div[aria-label='" + key + "'] label[aria-label='" + data['value'] + "']")
        if data.get('decrypt_value'):
            data['value'] = decrypt_password(data['value'])
        fill_parameter_details(data['type'], locator,
                               data['value'], key)


# Fill data on controls according the type
def fill_parameter_details(element_type, locator, parameter_value, elem_name):
    if element_type == 'Textbox':
        type_value(locator, parameter_value, elem_name)
    if element_type == 'SliderTextbox':
        test = get_test_file_name()
        if "aws" in test:
            if "id" in locator[0]:
                id_new = locator[1].split("-")[3]
                locator = ("xpath",
                           "//label[@for='" + id_new + "']/following-sibling::div//input[contains(@class,'bx--slider-text-input')]")
                # locator = ("xpath", "(//label[text()='" + elem_name + "']/..//input)[last()]")                                        
        type_value_with_keys(locator, parameter_value, elem_name)
        # Remove the focus to update slider value
        blur_element_using_javascript(locator, elem_name)
    if element_type == 'Textarea':
        text_area_type_value(locator, parameter_value, elem_name)
    if element_type == 'Dropdown':
        scroll_element_into_view_with_replace_value(locator, parameter_value)
        select_from_drop_down_text(locator, parameter_value, elem_name)
    if element_type == 'DropdownSearch':
        scroll_element_into_view_with_replace_value(locator, parameter_value)
        select_from_drop_down_search_text(locator, parameter_value, elem_name)
    if element_type == 'MultiselectDropdown':
        scroll_element_into_view_with_replace_value(locator, parameter_value)
        select_multiple_values_from_dropdown(locator, parameter_value, elem_name)
    if element_type == 'MultiselectDropdownSearch':
        scroll_element_into_view_with_replace_value(locator, parameter_value)
        select_multiple_values_from_dropdown_search(locator, parameter_value, elem_name)
    if element_type == 'DynamicListbox':
        scroll_element_into_view_with_replace_value(locator, parameter_value)
        select_option_from_dynamic_listbox(locator, parameter_value, elem_name)
    if element_type == 'InputOptions':
        scroll_element_into_view_with_replace_value(locator, parameter_value)
        click_using_script_replace_value(locator, parameter_value, elem_name)
    if element_type == 'Button':
        scroll_element_into_view(locator)
        click(locator, elem_name)
    if element_type == 'RadioButton':
        scroll_element_into_view(locator)
        click_using_java_script(locator, elem_name)
    if element_type == 'Checkbox':
        scroll_element_into_view(locator)
        click_checkbox(locator, parameter_value, elem_name)
    if element_type == 'VerifyText':
        assert parameter_value in get_element_text(locator)
    if element_type == 'Upload File':
        # file_path = os.path.join(resource_folder, "store", "testdata", parameter_value)
        type_value(locator, parameter_value, "Upload file")
    if element_type == 'Click':
        click(locator, elem_name)
    if element_type == 'Type_delay':
        scroll_element_into_view_with_replace_value(locator, parameter_value)
        type_value_as_human(locator, parameter_value, elem_name)
        # type_value_delay(locator, parameter_value, elem_name)


# Validates if the label is present more than one time, in JSON the key must be eg. "key[0]": "value"
def check_repeated_label_values(exp_label, exp_value, actual_value, titles, values):
    regex_exp = re.compile(r'\[[0-9]+\]')
    result = regex_exp.search(exp_label)
    if actual_value is None and result:
        result = result.group(0)
        position = int(result.replace('[', '').replace(']', ''))
        aux_exp_label = re.sub(regex_exp, '', exp_label)
        index = 0
        for idx, name in enumerate(titles):
            if name == aux_exp_label:
                if exp_value in values[idx] and index == position:
                    actual_value = values[idx]
                    break
                index += 1
    return actual_value
