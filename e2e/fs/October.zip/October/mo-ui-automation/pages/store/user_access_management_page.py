
from locators.store.approval_policies_locator import *
from locators.store.user_access_management_locator import *
from pages.store.order_parameters_page import *
from helpers.mo_json_utils import *
from helpers.mo_check import mo_check as check


def open_teams_tab():
    click_user_access_main_tab('Teams')


def open_organizations_tab():
    click_user_access_main_tab('Organizations')
    
    
def open_user_access_tab():
    click_user_access_main_tab('User Access')


def click_user_access_main_tab(tab_name):
    click_with_replace_value(user_access_mngmt_tab_btn, tab_name, f"{tab_name} tab")


def create_new_team(team_name, team_id):
    click(user_access_mngmt_add_new_btn, "Add New Team")
    type_value(new_team_name_textbox, team_name, "Team Name")
    type_value(new_team_id_textbox, team_id, "team Id")
    # select_from_drop_down(new_team_organisation, "MYORG", "Organization")
    select_from_drop_down(new_team_organisation, "MYORG", "Organization")
    click(new_team_create_button, "Create New Team")
    # Validate success message for newly created team
    team_created_message = get_notification_message()
    check.is_in(get_data("teamAddedMsg"), team_created_message, "Team Created Message")
    navigate_teams_page()


def get_notification_message():
    return get_element_text(new_team_created_msg)


def get_toast_notification():
    # wait_for_spinner_off()
    # explicit_wait(1)
    wait_for_element_to_visible(notification_msg, "Notification Message")
    message = get_element_text(notification_msg)
    # Close Notification Message
    click(close_notification_popup, "Closed Notification Pop up")
    return message


def get_toast_notification_title():
    # wait_for_spinner_off()
    # explicit_wait(1)
    wait_for_element_to_visible(notification_title_msg, "Notification title Message")
    message = get_element_text(notification_title_msg)
    # Close Notification Message
    click(close_notification_popup, "Closed Notification Pop up")
    return message


def navigate_teams_page():
    wait_for_spinner_off()
    click(teams_page_link, "Teams link")


def search(value):
    # Wait for Table to load
    wait_for_spinner_off()
    wait_to_load_table("1-10")
    click(search_magnifier, "Search Magnifier")
    type_value_and_enter(search_textbox, value, "Search Textbox")
    # Wait till record displays
    wait_to_load_table("1-1")


def validate_table_details(exp_item_name, exp_item_id, item):
    search(exp_item_name)
    if item == "team":
        act_item_name = get_element_text(name_list_team_table)
        act_item_id = get_element_text(id_list_team_table)
    else:
        act_item_name = get_element_text(org_name_table_text)
        act_item_id = get_element_text(org_id_table_text)
    assert exp_item_name in act_item_name
    assert exp_item_id in act_item_id


def view_details():
    # search(value)
    click(team_menu_button, "Action button for Team")
    click(view_details_button, "View Details Button")
    wait_for_spinner_off()


def edit_team_details(edited_team_name):
    view_details()
    click(team_edit_button, "Edit Team Details")
    type_value(new_team_name_textbox, edited_team_name, "team Name")
    click(team_update_button, "Team Update Button")
    # Validate Success message for update
    update_message = get_notification_message()
    check.is_in(update_message, get_data("teamUpdatedMsg"), "Team Updated Message")
    navigate_teams_page()


def add_multiple_roles(team):
    search(team)
    view_details()
    roles = get_data("assignRoles")
    for index, role in enumerate(roles):
        select_role(role)
        if role == "Team Setup Admin" or role == "Catalog Administrator":
            select_multiple_values_from_dropdown(role_bsns_entity_value_dropdown, ["MYORG"],
                                                 "Business Entity Value")
        else:
            if role != "System Admin" and role != "Catalog Administrator":
                if role != 'Buyer':
                    click_using_java_script(role_org_entity_checkbox, "Business Entity - Organization Checkbox")
                    associate_bsns_entity("Organization", "MYORG")
                if role == 'Technical Approver' or role == 'Financial Approver' or role == 'Buyer':
                    # select env and app
                    associate_bsns_entity("Application", "awsApp")
                    associate_bsns_entity("Environment", "awsEnv")
        click(add_single_role_button, "Add/Save Role")
        # Get Notification message and validate
        role_added = get_toast_notification()
        check.is_in(role + get_data("roleAddedMsg") + team, role_added, "Role Added Message")


def associate_bsns_entity(entity, entity_value):
    wait_for_spinner_off()
    if entity == "Application":
        click_using_java_script(role_bsns_entity_app_checkbox, "Business Entity - Application Checkbox")
        select_multiple_values_from_dropdown(role_bsns_entity_value_app_dropdown, [entity_value],
                                             "Business Entity Value")
    elif entity == "Environment":
        click_using_java_script(role_bsns_entity_env_checkbox, "Business Entity - Environment Checkbox")
        select_multiple_values_from_dropdown(role_bsns_entity_value_env_dropdown, [entity_value],
                                             "Business Entity Value")
    else:
        click(role_bsns_entity_dropdown, "Business Entity")
        click(bsns_entity_org, "Organization")
        select_multiple_values_from_dropdown(role_bsns_entity_value_dropdown, [entity_value], "Business Entity Value")


def assign_user():
    click(assign_user_button, "Assign User")
    select_from_drop_down_search_text_click_checkbox(assign_user_value_dropdown, get_data("assignedUser"), "User list")
    click(assign_selected_user_button, "Assign Selected user button")
    # Validate User Added Message
    message = get_notification_message()
    check.is_in(get_data("userAddedMsg"), message, "User Added Message")


def validate_roles(exp_role_list, team):
    act_role_list = get_elements_texts(team_role_list)
    for index, exp_role in enumerate(exp_role_list):
        check.is_in(exp_role, act_role_list[index], "Role Name")
    # Validate Role Details
    click(role_menu_button, "Action button for Role")
    click(view_details_button, "View Details")
    # Validate Context Details for Buyer role
    wait_for_all_elements_to_load(role_contexts_values, "Role Contexts")
    act_context_details = dict(zip(get_elements_texts(role_context_label), get_elements_texts(role_contexts_values)))
    try:
        check.is_in(act_context_details["Application:"], get_data("teamApp"), "Application")
        check.is_in(act_context_details["Environment:"], get_data("teamEnv"), "Environment")
        check.is_in(act_context_details["Team:"], team, "Team")
        check.is_in(act_context_details["Organization:"], get_data("organization"), "Organization")
    except KeyError:
        logger.info("Unable to validate roles")
    click_index_based(close_btn, 0, "Close button")


def select_role(role_name):
    wait_for_spinner_off()
    wait_for_element_clickable(team_add_role_button, "Add Role Button")
    click(team_add_role_button, "Add Role Button")
    select_from_drop_down(team_role_name_dropdown, role_name, "Role name")


def un_assign_roles(team):
    roles = get_data("assignRoles")
    for index, role in enumerate(roles):
        wait_for_spinner_off()
        wait_for_element_clickable(role_menu_button, "Action button for Role")
        click(role_menu_button, "Action button for " + role)
        scroll_element_into_view(remove_role_button)
        click(remove_role_button, "Remove")
        click(confirm_button, "Confirm Remove")
        role_message = get_toast_notification()
        check.is_in(role + get_data("roleRemoved") + team, role_message, "Role Removed")


def un_assign_user(user):
    click(role_menu_button, "Action button for User")
    click(un_assign_user_button, "Un-assign user button")
    click(confirm_button, "Confirm Unassign user")
    user_unassigned = get_notification_message()
    check.is_in(get_data("userUnassignedMsg"), user_unassigned, "User Unassigned")
    navigate_teams_page()


def delete_team(team_name):
    search(team_name)
    delete_item(team_name)


def add_new_org(org_name_n, org_id_n):
    click(user_access_mngmt_add_new_btn, "Add New Organization")
    type_value(org_name, org_name_n, "Organization Name")
    type_value(org_id, org_id_n, "Organization id")
    click(create_btn, "Create Organization")
    org_added_msg = get_toast_notification()
    # Validate success message
    check.is_in(get_data("orgContextAdded"), org_added_msg)


def delete_item(item_name):
    click(team_menu_button, "Action button")
    click(delete_button, "Delete button")
    confirm_message = get_element_text(delete_message)
    if item_name in confirm_message:
        click(confirm_button, "Confirm Deletion")
        # Validate success message for team deletion
        message = get_toast_notification()
        check.is_in(get_data("deleteMsg"), message, "Delete")
    else:
        click(cancel_button, "Cancel Deletion")


def create_new_context(cntx_name, cntx_id):
    click(user_access_mngmt_add_new_btn, "Create New Context button")
    type_value(context_name_textbox, cntx_name, "Context Name")
    type_value(context_id_textbox, cntx_id, "Context Id")
    click(create_btn, "Create Context button")
    msg = get_toast_notification()
    check.is_in(get_data("orgContextAdded"), msg, "Context Added")


def wait_to_load_table(items_to_display):
    wait_for_element_to_visible(table_row, "Wait for at least one row to display")
    for i in range(6):
        pagination_txt = get_element_text(pagination_text)
        items_displayed = pagination_txt.split(" of")[0]
        if items_displayed != items_to_display:
            explicit_wait(2)
        else:
            break


def verify_user_access_mngmt_add_button_present():
    check.is_true(is_element_present(user_access_mngmt_add_new_btn, 'Add Button'), 'Add button present')
    

def verify_user_access_mngmt_add_button_not_present():
    check.is_true(is_element_not_present(user_access_mngmt_add_new_btn, 'Add Button'), 'Add button not present')
