from helpers.mo_element_operations import *
from helpers.mo_json_utils import *
from locators.store.pricing_management_locator import *
from pages.common.login_page import loader_off
from pages.store.order_parameters_page import fill_order_parameter
from helpers.mo_check import mo_check as check
from pytz import timezone
from datetime import datetime
import platform


# Get header title text for Pricing Management Page
def get_pricing_management_header_title_text():
    wait_for_spinner_off()
    return get_element_text(pricing_management_title_text)


def add_new_policy():
    click(add_new_policy_button, 'Pricing Policy Button')


def select_start_date():
    scroll_element_into_view(start_date_picker)
    click(start_date_picker, 'Calendar')
    type_value_and_enter(start_date_picker, get_data("start_date_value"), 'Start Date Value')
    click(selected_start_date, 'Start Date')


def fill_pricing_policy_parameter(pricing_policy_parameter):
    fill_order_parameter(pricing_policy_parameter)


def fill_pricing_policy_tag_parameters(policy_tag_parameters):
    fill_order_parameter(policy_tag_parameters)


def fill_pricing_rule_parameters(pricing_rule_parameters):
    fill_order_parameter(pricing_rule_parameters)


def fill_pricing_policy_details(path):
    set_data_path(path)
    fill_pricing_policy_parameter(get_data("Pricing Policy Parameters"))
    fill_pricing_policy_tag_parameters(get_data("Policy Tag Parameters"))
    fill_pricing_rule_parameters(get_data("Pricing Rule Parameters"))


def save_pricing_policy():
    scroll_element_into_view(save_policy_button)
    click(save_policy_button, 'Save Policy Button')


def search_pricing_policy(pricing_policy_name):
    loader_off()
    wait_for_spinner_off()
    explicit_wait(2)
    click(pricing_search_magnifier, 'Search Pricing Policy')
    type_value_and_enter(pricing_search_textbox, pricing_policy_name, 'Pricing Search Textbox')
    wait_for_spinner_off()
    loader_off()


def verify_pricing_policy_details(pricing_policy_name, status):
    explicit_wait(10)
    check.equal(get_elements_count(pricing_policy_search_entry), 1, 'Pricing Policy Entry')
    check.equal(get_element_text(pricing_policy_entry_name), pricing_policy_name, 'Pricing Policy Name')
    check.equal(get_element_text(pricing_policy_entry_status), status,
                'Pricing Policy Status')


def click_pricing_policy_hamburger_icon(policy_name):
    click_with_replace_value(pricing_policy_hamburger_icon, policy_name, 'Pricing policy Hamburger icon')


def click_pricing_policy_actions(policy_name, action):
    if action == "View Details":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_policy_name_xpath,
                                                       [policy_name, "View Details"], "View Details")
        click_using_script_replace_value(action_button_based_on_policy_name_xpath, [policy_name, "View Details"],
                                         "View Details")
    elif action == "Edit":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_policy_name_xpath,
                                                       [policy_name, "Edit"], "Edit Policy")
        click_using_script_replace_value(action_button_based_on_policy_name_xpath, [policy_name, "Edit"],
                                         "Edit Policy")
    elif action == "Delete":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_policy_name_xpath,
                                                       [policy_name, "Delete"], "Delete Policy")
        click_using_script_replace_value(action_button_based_on_policy_name_xpath, [policy_name, "Delete"],
                                         "Delete Policy")
    elif action == "Activate":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_policy_name_xpath,
                                                       [policy_name, "Activate"], "Activate Policy")
        click_using_script_replace_value(action_button_based_on_policy_name_xpath, [policy_name, "Activate"],
                                         "Activate Policy")
    elif action == "Deactivate":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_policy_name_xpath,
                                                       [policy_name, "Deactivate"], "Deactivate Policy")
        click_using_script_replace_value(action_button_based_on_policy_name_xpath, [policy_name, "Deactivate"],
                                         "Deactivate Policy")


def get_current_formatted_time():
    current_UTC_time = datetime.now()
    current_Indian_time = datetime.now(timezone("Asia/Kolkata"))
    if platform.system() == 'Windows':
        formatted_time = current_Indian_time.strftime("%B %#d, %Y")
        logger.info("Formatted Indian time :: " + str(formatted_time))
    elif platform.system() == 'Linux':
        formatted_time = current_UTC_time.strftime("%B %-d, %Y")
        logger.info("Formatted UTC time :: " + str(formatted_time))
    else:
        formatted_time = current_UTC_time.strftime("%B %-d, %Y")
        logger.info("Formatted time :: " + str(formatted_time))
    return str(formatted_time)


def validate_basic_information_details(policy_name):
    check.equal(get_element_text(pricing_policy_name_text), policy_name, 'Pricing Policy Name')
    if platform.system() == 'Windows':
        check.equal(get_element_text(pricing_policy_start_date), get_data("pricing_start_date_win"),
                    'Pricing Policy Start Date Value')
    else:
        check.equal(get_element_text(pricing_policy_start_date), get_data("pricing_start_date_lin"),
                    'Pricing Policy Start Date Value')
    check.not_equal(get_element_text(pricing_policy_end_date), None, 'Pricing Policy End Date')
    check.is_in(get_element_text(pricing_policy_created_on_date), get_current_formatted_time(),
                'Pricing Policy Created Date')
    check.is_in(get_element_text(pricing_policy_last_updated_on_date), get_current_formatted_time(),
                'Pricing Policy Updated Date')
    check.not_equal(get_element_text(pricing_policy_created_by), None, 'Pricing Policy Created By')
    check.equal(get_element_text(pricing_policy_status), get_data("pricingPolicyStatusActive"), 'Pricing Policy Status')
    check.equal(get_element_text(pricing_policy_currency), get_data("pricingPolicyDefaultCurrency"),
                'Pricing Policy Default Currency')


def validate_tag_details():
    tag_details_list = get_elements_texts(tag_details_xpath)
    if tag_details_list:
        for tag_value in [(get_data("tagKey"), 'Tag Key Details'),
                          (get_data("tagValue"), 'Tag Value Details')]:
            check.is_in(tag_value[0], tag_details_list, tag_value[1])


def validate_upcharge_pricing_rules(upcharge_pricing_rule_name):
    upcharge_pricing_rule_details_list = get_elements_texts(pricing_rule_details_xpath)
    if upcharge_pricing_rule_details_list:
        for rule_value in [(upcharge_pricing_rule_name, 'Pricing Rule Name'),
                           (get_data("pricingRuleUpchargeType"), 'Pricing Rule Type'),
                           (get_data("pricingUsageCharge"), 'Pricing Adjustment Type'),
                           (get_data("pricingUpchargeAmountPercentage"), 'Pricing Upcharge Amount Percentage')]:
            check.is_in(rule_value[0], upcharge_pricing_rule_details_list, rule_value[1])


def validate_discount_pricing_rules(discount_pricing_rule_name):
    discount_pricing_rule_details_list = get_elements_texts(pricing_rule_details_xpath)
    if discount_pricing_rule_details_list:
        for rule_value in [(discount_pricing_rule_name, 'Pricing Rule Name'),
                           (get_data("pricingRuleDiscountType"), 'Pricing Rule Type'),
                           (get_data("pricingUsageCharge"), 'Pricing Adjustment Type'),
                           (get_data("pricingDiscountAmountPercentage"), 'Pricing Discount Amount Percentage')]:
            check.is_in(rule_value[0], discount_pricing_rule_details_list, rule_value[1])
