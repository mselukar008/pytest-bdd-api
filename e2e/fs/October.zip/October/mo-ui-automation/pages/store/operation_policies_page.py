from locators.store.operation_policies_locator import *
from pages.store.order_parameters_page import *
from helpers.mo_json_utils import *


def fill_operation_policy_and_group_parameter_details(path, json_parameter):
    set_data_path(path)
    fill_order_parameter(get_data(json_parameter))


def navigate_to_operation_group_section():
    wait_for_element_to_visible(operation_policy_table_row, "at least one Table Row")
    click(operation_group_tab, "operation group section")


def navigate_to_operation_policy_section():
    wait_for_element_to_visible(operation_policy_table_row, "at least one Table Row")
    click(operation_policy_tab, "operation policy section")


def search_operation_policy(operation_policy_name):
    type_value_and_enter(search_textbox, operation_policy_name, "Search textbox")
    wait_for_spinner_off()
    wait_for_element_to_visible(operation_policy_table_row, "at least one Table Row")


def search_and_click_on_action_icon(operation_policy_name):
    search_operation_policy(operation_policy_name)
    click(action_icon, "Policy action icon")


def activate_operation_policy(path, operation_policy_name):
    search_and_click_on_action_icon(operation_policy_name)
    click(view_details_policy, "View Details Policy")
    fill_operation_policy_and_group_parameter_details(path, "operation policy active parameters")
    message = get_element_text(notification_text)
    click(notification_close_icon, "notification close icon")
    return message


def retire_operation_policy(path, operation_policy_name):
    search_and_click_on_action_icon(operation_policy_name)
    click(view_details_policy, "View Details Policy")
    fill_operation_policy_and_group_parameter_details(path, "operation policy retired parameters")
    message = get_element_text(notification_text)
    click(notification_close_icon, "notification close icon")
    return message


def delete_operation_policy(path, operation_policy_name):
    set_data_path(path)
    search_and_click_on_action_icon(operation_policy_name)
    click(delete_policy_btn, "delete operation Policy")
    click(delete_policy_continue_btn, "continue button")
    message = get_element_text(notification_text)
    click(notification_close_icon, "notification close icon")
    return message


def delete_operation_policies_if_exists():
    num = get_number_of_elements(operation_policy_table_row, "Policies")
    if num > 0:
        policies_status = get_elements_texts(operation_policy_status_text)
        for policy_status in policies_status:
            if policy_status == "Active":
                click(action_icon, "Policy action icon")
                click(view_details_policy, "Edit Policy")
                click(retired_radiobutton, "Retired")
                explicit_wait(2)
                click(update_policy_btn, "Update")
                click(notification_close_icon, "notification close icon")
                explicit_wait(5)
            else:
                click(action_icon, "Policy action icon")
                click(delete_policy_btn, "Delete")
                click(delete_confirmation_btn, "Delete confirmation")
                wait_for_spinner_off()
                click(notification_close_icon, "notification close icon")
                explicit_wait(5)
        delete_operation_policies_if_exists()
    else:
        logger.info("No Operation Policies found")
