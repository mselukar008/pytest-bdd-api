import datetime
from helpers.mo_exception_utils import exceptions_decorator
from pages.store.mo_store_utils import *
from helpers.mo_element_validation import check_element_exists
from helpers.mo_selenium_helper import *
from locators.store.approve_order_locator import *
from pages.store.navigation_page import *
from helpers.mo_json_utils import *
from helpers.mo_check import mo_check as check
from tests.common_test import set_data
from selenium.common.exceptions import StaleElementReferenceException
from pages.store.catalog_management_page import *

# Approve roles types (Constants)
ADMIN_APPROVER = 'admin'
FINANCIAL_APPROVER = 'financial'
TECHNICAL_APPROVER = 'technical'


# Validate title and sub-title text on approve order page
@exceptions_decorator
def validate_title_texts_on_approve_page():
    assert get_element_text(approve_orders_title_text).strip() == mo_ui_test_data["approveOrdersTitleText"]
    assert get_element_text(approve_orders_subtitle_text).strip() == mo_ui_test_data["approveOrdersSubTitleText"]


def search_order_in_approve(order_no):
    try:
        wait_for_element_to_visible(order_id_row_link_text, "Order ID List")
    except:
        logger.info("Order Id list not loaded completely; retrying search order")
    logger.info("Order number: {}".format(order_no))
    type_value_and_enter(search_order_path, order_no, "Search Order id")
    order_found = wait_for_order_present(order_no)
    # Terminate flow if order is not found after searching for 20 times as in above function
    assert order_found


def approve_order(order_no):
    open_approve_orders_page()
    search_order_in_approve(order_no)
    wait_for_order_present(order_no)
    click_approve_btn()
    click_approver_role()
    click_modal_approval_btn()
    click_modal_approval_ok()


def search_order_click_approve(order_no):
    open_approve_orders_page()
    search_order_in_approve(order_no)
    wait_for_order_present(order_no)
    click_approve_btn()
    explicit_wait(5)
    if is_element_present(approval_role, "Approvals"):
        logger.info("Approvals are present")
    else:
        driver.refresh()
        switch_to_iframe(mo_iframe_xpath)
        search_order_click_approve(order_no)


def click_approve_btn():
    click_using_java_script(approve_path, "Approve button")


def click_cancel_btn():
    click(modal_approval_cancel_btn, "Cancel button")


def click_deny_btn():
    click_using_java_script(deny_path, "Deny button")


def click_approver_role(max_attempts=3):
    attempt = 1
    while True:
        try:
            click_on_multiple_check_box(approval_role)
            return False
        except StaleElementReferenceException:
            if attempt == max_attempts:
                raise
            attempt += 1


def click_technical_approver_role():
    wait_before_click(technical_approval_checkbox, "Techical approval checkbox")


def click_financial_approver_role():
    wait_before_click(financial_approval_checkbox, "Financial approval checkbox")


def select_budgetary_unit_on_approve_orders(budget_unit_name):
    scroll_element_into_view(select_budget_dropdown)
    select_from_drop_down_text(select_budget_dropdown, budget_unit_name, 'Select Budget Unit Dropdown')
    wait_for_spinner_off()


def click_legal_approver_role():
    wait_before_click(legal_approval_checkbox, "Legal approval checkbox")


def click_technical_denier_role():
    click_using_java_script(technical_denial_checkbox, "Techical denial checkbox")


def click_financial_denier_role():
    click_using_java_script(financial_denial_checkbox, "Financial denial checkbox")


def click_modal_approval_btn():
    click(modal_approval_btn, "Approve button inside approval modal")


def click_modal_denial_btn():
    click(modal_denial_btn, "Deny button inside denial modal")


def approve_order_technical_financial(approver_type=ADMIN_APPROVER):
    if approver_type == ADMIN_APPROVER or approver_type == TECHNICAL_APPROVER:
        click_technical_approver_role()
    if approver_type == ADMIN_APPROVER or approver_type == FINANCIAL_APPROVER:
        click_financial_approver_role()
    click_modal_approval_btn()


def deny_order_technical_financial():
    click_technical_denier_role()
    click_financial_denier_role()
    text_area_type_value(modal_denial_comment, mo_ui_test_data['denialComment'], 'Denial comment textarea')
    click_modal_denial_btn()


def get_order_success_msg_text():
    wait_for_element_to_visible(order_success_msg_text, "Order approval success message")
    success_msg_text = get_element_text(order_success_msg_text)
    logger.info("Order success message on Approval Order flow popup: " + success_msg_text)
    return success_msg_text


def get_deny_order_success_msg_text():
    success_msg_text = get_element_text(deny_order_success_msg_text)
    logger.info("Deny order success message on Denial Order flow popup: " + success_msg_text)
    return success_msg_text


def click_modal_approval_ok():
    click(modal_approval_ok, "Approve ok button")


def click_modal_denial_ok():
    click(modal_denial_ok, "Deny ok button")


def wait_for_order_present(order_no):
    repeat = 30
    res = False
    while not res and repeat > 0:
        try:
            wait_for_element_clickable(order_id_row_link_text, 'Orders ID list on Left Panel')
        except (TimeoutException, StaleElementReferenceException):
            expected_order = ''
            logger.info("Orders ID list on Left Panel not present, retrying...")
        if check_element_exists(no_record_found_path):
            repeat = repeat - 1
            navigate_to_mo_launchpad_page()
            open_approve_orders_page()
        else:
            expected_order = get_first_order_id_link_text()
            if expected_order == order_no:
                res = True
                wait_for_spinner_off()
            repeat = repeat - 1
        if not res:
            click_on_all_orders_tab()
            try:
                wait_for_element_to_visible(order_id_row_link_text, "Order ID link")
                # logger.info("Order number: {}".format(order_no))
                type_value_and_enter(search_order_path, order_no, "Search Order id")
                wait_for_element_to_invisible(order_id_row_link_text, 'order link')
                # search_order_in_approve(order_no)
            except (TimeoutException, StaleElementReferenceException):
                type_value_and_enter(search_order_path, order_no, "Search Order id")
    wait_for_spinner_off()
    return res


# Verify all assertions on Order Details table
@exceptions_decorator
def verify_order_details_table(approval_state, order_type):
    check.equal(get_element_text(order_details_total_estimated_cost_text).strip(), get_data("EstimatedPrice"),
                'Estimated Price')

    check.equal(get_element_text(order_details_order_status_text).strip(), approval_state, 'Order Status')

    check.equal(get_element_text(order_details_order_type_text).strip(), order_type, 'Order Type')

    check.is_in(mo_ui_test_data["submittedBy"], get_element_text(order_details_submitted_by_text).strip(),
                'Submitted By')


# Verify all assertions on Service Details table
@exceptions_decorator
def verify_service_details_table(service_name):
    check.equal(get_element_text(service_details_service_instance_prefix_text).strip(), service_name, 'Instance Prefix')

    check.equal(get_element_text(service_details_service_offering_name_text).strip(), get_data("bluePrintName"),
                'Service Offering')

    check.equal(get_element_text(service_details_service_provider_text).strip(), get_data("provider"), 'Provider')

    check.equal(get_element_text(service_details_total_estimated_cost_text).strip(), get_data("EstimatedPrice"),
                'Estimated Cost')


def get_order_approval_flow_popup_table_header_text():
    header_text = get_element_text(approval_order_popup_header_text).strip()
    logger.info("Header text for Order approval flow popup: " + header_text)
    return header_text


def get_order_denial_flow_popup_table_header_text():
    header_text = get_element_text(deny_order_popup_header_text).strip()
    logger.info("Header text for Order deny flow popup: " + header_text)
    return header_text


def get_first_order_id_link_text():
    try:
        order_id_text = get_element_text(order_id_row_link_text)
        order_id = order_id_text.split('# ')[1].strip()
        logger.info("Order id link text : " + order_id)
        return order_id
    except (TimeoutException, NoSuchElementException, AttributeError, StaleElementReferenceException):
        return ""


def click_on_pending_orders_tab():
    wait_before_click(pending_orders_tab, "Pending orders tab")


def click_on_all_orders_tab():
    click_using_java_script(all_orders_tab, "All orders tab")
    wait_for_spinner_off()


def wait_for_order_status(order_no, expected_status, counter=300):
    res = True
    current_status = ""
    while res and counter > 0:
        current_status = get_element_text(order_details_order_status_text).strip()
        if current_status == mo_ui_test_data["failedState"] or current_status == mo_ui_test_data[
            "submissionFailed"] or current_status == "Completed with Failure":
            logger.info("Order status is " + current_status)
            res = False
        else:
            if current_status == expected_status:
                logger.info("Order is in expected status; Order status: " + expected_status)
                res = False
            else:
                logger.info("Current status: " + current_status + "; Expected status: " + expected_status)
                click_on_all_orders_tab()
                search_order_in_approve(order_no)
                # wait_for_spinner_off()
                # wait_for_order_present(order_no)
                time.sleep(2)
                counter = counter - 1
    return current_status


def click_on_view_details_link():
    wait_before_click(view_details_link, "View details link")


def click_on_order_details_tab():
    wait_before_click(order_details_tab, "Order details tab")


# Verify all assertions on Order Details tab from View details slider window
@exceptions_decorator
def verify_order_details_tab(order_no, approval_state, order_type, order_total):
    check.equal(get_element_text(header_title_text).strip(), order_no)

    check.equal(
        get_element_text_replace_value(order_details_left_value, mo_ui_test_data["orderIdLabel"], 'Order Id Label'),
        order_no, 'Order ID')

    check.equal(get_element_text_replace_value(order_details_left_value, mo_ui_test_data["orderTotalLabel"],
                                               'Order Total Label'), order_total, 'Order Total')

    check.equal(get_element_text_replace_value(order_details_left_value, mo_ui_test_data["orderStatusLabel"],
                                               'Order Status Label'), approval_state, 'Order Status')

    check.equal(get_element_text_replace_value(order_details_left_value, mo_ui_test_data["orderTypeLabel"],
                                               'Order Type Label'), order_type, 'Order Type')


def click_on_order_updates_tab():
    wait_before_click(order_updates_tab, "Order updates tab")


def get_current_order_status():
    order_statuses = get_elements_texts(order_status_step_text)
    current_order_status = order_statuses[-1]
    logger.info("Current order status: " + current_order_status)
    return current_order_status


# Verify all assertions on Order Updates tab for all Pending status from View details slider window
@exceptions_decorator
def verify_all_pending_order_updates_tab(skip_user=False):
    if not skip_user:
        user = MO_USER
        if os.environ.get("Environment"):
            user = os.environ.get("kyndryl_user")
        check.is_in(get_element_text(submitted_by_username).strip(), user, 'Submitted By')

    check.equal(get_current_order_status(), mo_ui_test_data["approvalInProgState"], 'Current Status')

    check.equal(get_element_text_replace_value(order_approve_status, mo_ui_test_data["technicalApprovalLabel"],
                                               'Technical Approval Label'), mo_ui_test_data["approveStatusPending"],
                'Technica Approval')

    check.equal(get_element_text_replace_value(order_approve_status, mo_ui_test_data["financialApprovalLabel"],
                                               'Financial Approval Label'), mo_ui_test_data["approveStatusPending"],
                'Financial Approval')

    expand_approval_type_tile(mo_ui_test_data["technicalApprovalLabel"])
    verify_pending_approvers_details(mo_ui_test_data["technicalApprovalLabel"])

    expand_approval_type_tile(mo_ui_test_data["financialApprovalLabel"])
    verify_pending_approvers_details(mo_ui_test_data["financialApprovalLabel"])


def expand_approval_type_tile(approval_type):
    explicit_wait(2)
    click_with_replace_value(approval_type_expand_btn, approval_type, 'Approval Type Expand Button')
    logger.info("Expanded " + approval_type + " tile..")


# Verify all assertions for pending approver details on Order Updates tab from View details slider window
@exceptions_decorator
def verify_pending_approvers_details(approval_type):
    approver_details_text = get_element_text_replace_value(approval_type_approvers_details, approval_type,
                                                           'Approval Type Text')
    check.is_in(mo_ui_test_data["approversDetailsHeader"], approver_details_text, 'Details Header')

    check.is_in(mo_ui_test_data["approversDetailsMsg"], approver_details_text, 'Details Message')


def close_view_details_slider_window():
    wait_before_click(close_slider_window_btn, "Close Order details slider window")


# Validate for one or multiple service names
def validate_service_names(service_names):
    if type(service_names) != list:
        service_names = [service_names]
    # Wait for card loader to appear
    wait_for_spinner_on()
    # After that data is loaded and wait for loader to disappear
    wait_for_spinner_off()
    service_names_ui = get_elements_texts(service_details_service_instance_prefix_text)
    for service_name in service_names:
        check.is_in(service_name, service_names_ui, "Service name on Approve orders page")


# The function approves order and wait for its completion
def approve_order_wait_for_completion(order_no, service_names, budget_unit_name=None, approver_type=ADMIN_APPROVER,
                                      approved_previously=True):
    # Validate for one or multiple service names
    if type(service_names) != list:
        service_names = [service_names]
    # Navigate to Approve orders page
    counter = 50
    res = True
    while res and counter > 0:
        open_approve_orders_page()
        search_order_in_approve(order_no)
        # wait_for_order_present(order_no)
        # Validate searched order number link text to be match with from submit order popup
        # assert get_first_order_id_link_text() == order_no
        order_found = check.equal(get_first_order_id_link_text(), order_no, "Order Found on orders page")
        try:
            approve_btn_displayed = is_element_clickable(approve_path, "Approve Button")
        except (StaleElementReferenceException, TimeoutException) as e:
            approve_btn_displayed = False
        # approve_btn_displayed = check_element_exists(approve_path)
        explicit_wait(2)
        get_elements_texts(service_details_service_offering_name_text)
        service_names_ui = get_elements_texts(service_details_service_instance_prefix_text)
        for index, service_name in enumerate(service_names):
            if service_name in service_names_ui[index]:
                service_name_status = True
            else:
                service_name_status = False
        if order_found and approve_btn_displayed and service_name_status:
            res = False
        else:
            explicit_wait(3)
            counter = counter - 1

    # # Validate for one or multiple service names
    # if type(service_names) != list:
    #     service_names = [service_names]
    # Wait for card loader to appear
    wait_for_spinner_on()
    # After that data is loaded and wait for loader to disappear
    wait_for_spinner_off()
    # service_names_ui = get_elements_texts(service_details_service_instance_prefix_text)
    # for service_name in service_names:
    #     assert service_name in service_names_ui
    order_type = get_element_text(order_details_order_type_text)
    # Select the budget if is required
    return_values = None
    if budget_unit_name:
        if order_type == 'New':
            scroll_element_into_view(select_budget_dropdown)
            select_from_drop_down_text(select_budget_dropdown, budget_unit_name, 'Select Budget Unit Dropdown')
            wait_for_spinner_off()
            return_values = validate_budget_before_approve_new_order()
    click_approve_btn()
    # Validate order approval flow popup header
    check.is_in(get_order_approval_flow_popup_table_header_text(),
                mo_ui_test_data["approvalOrderFlowPopupHeaderText"])
    approve_order_technical_financial(approver_type)
    # Validate approve order success message
    check.equal(get_order_success_msg_text(), mo_ui_test_data["approveOrderSuccessMsgText"])
    click_modal_approval_ok()
    click_on_all_orders_tab()
    try:
        search_order_in_approve(order_no)
    except:
        pass
    # wait_for_order_present(order_no)
    explicit_wait(2)
    order_status = get_element_text(order_details_order_status_text).strip()
    # Flag to indicate if has Financial or Technical approval
    if not approved_previously:
        # Validate order status to be 'Approval In Progress'
        assert order_status == mo_ui_test_data["approvalInProgState"]
        return return_values
    try:
        # Validate searched order number link text to match with from submit order popup
        assert get_first_order_id_link_text() == order_no
        # Validate order status to be 'Provisioning In Progress'
        assert order_status == mo_ui_test_data["provInProgressState"]
    except AssertionError:
        # If server is so quick, validate complete status
        assert order_status == mo_ui_test_data["completedState"]
    # Wait and validate order status to be 'Completed'
    order_status_text = wait_for_order_status(order_no, mo_ui_test_data["completedState"])
    assert order_status_text == mo_ui_test_data["completedState"]
    if order_type == 'New':
        set_data(order_status_text)
    if budget_unit_name: search_order_in_approve(order_no)
    return return_values


# The function denies order
def deny_order(order_no, service_names):
    if type(service_names) != list:
        service_names = [service_names]
    # Navigate to Approve orders page
    counter = 50
    res = True
    while res and counter > 0:
        open_approve_orders_page()
        search_order_in_approve(order_no)
        # wait_for_order_present(order_no)
        # Validate searched order number link text to be match with from submit order popup
        # assert get_first_order_id_link_text() == order_no
        order_found = check.equal(get_first_order_id_link_text(), order_no, "Order Found on orders page")
        try:
            approve_btn_displayed = is_element_clickable(approve_path, "Approve Button")
        except (StaleElementReferenceException, TimeoutException) as e:
            approve_btn_displayed = False
        # approve_btn_displayed = check_element_exists(approve_path)
        service_names_ui = get_elements_texts(service_details_service_instance_prefix_text)
        for index, service_name in enumerate(service_names):
            if service_name in service_names_ui[index]:
                service_name_status = True
            else:
                service_name_status = False
        if order_found and approve_btn_displayed and service_name_status:
            res = False
        else:
            explicit_wait(3)
            counter = counter - 1
    click_deny_btn()
    # Validate order approval flow popup header
    check.equal(get_order_denial_flow_popup_table_header_text(), mo_ui_test_data["denialOrderFlowPopupHeaderText"],
                'Denial Popup Header')
    deny_order_technical_financial()
    # Validate approve order success message
    check.equal(get_deny_order_success_msg_text(), mo_ui_test_data["denyOrderSuccessMsgText"], 'Deny Success Message')
    click_modal_denial_ok()
    click_on_all_orders_tab()
    search_order_in_approve(order_no)
    # wait_for_order_present(order_no)
    # Validate searched order number link text to be match with from submit order popup
    assert get_first_order_id_link_text() == order_no
    # Wait and validate order status to be 'Rejected'
    assert wait_for_order_status(order_no, mo_ui_test_data["rejectedState"]) == mo_ui_test_data["rejectedState"]


# Order type constants
ORDER_NEW = mo_ui_test_data["orderTypeNew"]
ORDER_EDIT_SOI = mo_ui_test_data["orderTypeEdit"]


def validate_orders_page(order_no, service_name, exp_estimated_cost, imi=None, version=None, order_type=ORDER_NEW,
                         skip_user=False,
                         skip_total_calc=False, is_editing=False, edit_addtl_params_key='Edit Additional Parameters'):
    open_approve_orders_page()
    # Validate title and subtitle on approve orders page
    validate_title_texts_on_approve_page()
    search_order_in_approve(order_no)
    # wait_for_order_present(order_no)
    wait_for_spinner_off()
    time.sleep(3)
    # Validations for order details table
    if imi:
        exp_estimated_price = get_data("EstimatedPriceWithAddOn")
        order_total = get_data("TotalCostImiAddOn")
        check.equal(get_element_text(imi_addon_text), imi_config_test_data["imi_add_on"],
                    "IMI Addon tag on orders page")
    else:
        exp_estimated_price = get_data("EstimatedPrice")
        order_total = get_data("TotalCost")

    main_param_json_dic_data = get_data("Main Parameters", get_data("Main Parameter"))
    try:
        quantity = main_param_json_dic_data["Quantity"]["value"]
    except KeyError:
        logger.info("Test Data file don't have quantity key, using default quantity as 1")
        quantity = "1"

    actual_order_details_params = dict(zip(get_elements_texts(order_details_labels),
                                           get_elements_texts(order_details_values)))
    exp_order_details_data = {"order_status": mo_ui_test_data["approvalInProgState"],
                              "order_type": order_type,
                              "blueprint_name": get_data("bluePrintName"),
                              "estimated_price": exp_estimated_price}

    exp_order_service_details_data = {"blueprint_name": get_data("bluePrintName"),
                                      "estimated_price": exp_estimated_price, "Quantity": quantity}

    verify_orders_service_details(service_name, actual_order_details_params, exp_order_details_data,
                                  skip_user=skip_user)
    # Validations for Service Details table
    actual_order_service_details_params = dict(zip(get_elements_texts(order_service_details_labels),
                                                   get_elements_texts(order_service_details_values)))
    verify_orders_service_details(service_name, actual_order_service_details_params,
                                  exp_order_service_details_data, quantity, skip_user=skip_user)
    # Validate order updates -->View Details
    click_on_view_details_link()
    verify_order_details_tab(order_no, mo_ui_test_data["approvalInProgState"],
                             order_type, order_total)

    # Validations on Order Updates--> View details: Order updates tab
    click_on_order_updates_tab()
    verify_all_pending_order_updates_tab(skip_user=skip_user)
    close_view_details_slider_window()
    # Verify service details configuration is as per input test data file
    click_service_view_details()
    validate_service_details_config(imi, version, is_editing, edit_addtl_params_key)
    # Validate Bill of Materials
    click(bill_of_materials_service_details_btn, "Bill Of Materials")
    act_estimated_cost = get_element_text(estimated_cost_txt)
    if not skip_total_calc:
        click(more_link, "More link")
        # Monthly Cost and One time cost calculation
        monthly_cost = sum_totals_by_locator(monthly_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
        one_time_cost = sum_totals_by_locator(one_time_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
        total_sum = sum_string_totals([monthly_cost, one_time_cost], exp_estimated_cost)
        check.equal(act_estimated_cost, total_sum, 'Monthly Cost and One Time Cost')
    check.equal(act_estimated_cost, exp_estimated_cost, 'Total Cost')
    close_view_details_slider_window()


def validate_budget_before_approve_new_order():
    # Budget Amount
    check.equal(get_data('OrdersPageBudgetAmount'), get_element_text(approve_budget_amount),
                'Budget Amount before approve')
    # Estimated Amount
    estimated_amount = get_element_text(approve_budget_estimated_amount)
    # Calculates Estimated Amount
    calculated_estimated_amount = sum_string_totals([get_data('TotalCost')] * get_data('BudgetDuration'),
                                                    estimated_amount)
    # Spend Amount always zero
    check.equal(get_element_text(approve_budget_spend_ammount), get_data('BudgetSpendAmount'),
                'Spend Amount before approve')
    # Calculate amount equal to estimated amount
    check.equal(calculated_estimated_amount, estimated_amount, 'Commited Amount for this order before approve')
    # -- Amounts before approve
    # Commited Amount
    commited_amount = get_element_text(approve_budget_commited_amount)
    # Pending Orders Amount
    pend_amount = get_element_text(approve_budget_pending_orders_amount)
    # Available Budget
    available_budget = get_element_text(approve_budget_available_amount)
    return commited_amount, calculated_estimated_amount, pend_amount, available_budget


def validate_budget_after_approve_new_order(before_commited_amount, calc_est_amount, before_pend_amount,
                                            before_available_budget):
    # Available amount
    available_budget = get_element_text(approve_budget_available_amount)
    calculated_available_budget = subtract_string_totals([before_available_budget, calc_est_amount], available_budget)
    check.equal(calculated_available_budget, available_budget, 'Available Budget after approve')
    # Pending Amount
    pend_amount = get_element_text(approve_budget_pending_orders_amount)
    calculated_pend_amount = subtract_string_totals([before_pend_amount, calc_est_amount], pend_amount)
    check.equal(calculated_pend_amount, pend_amount, 'Pending Amount after approve')
    # Commited Amount
    commited_amount = get_element_text(approve_budget_commited_amount)
    calculated_commited_amount = sum_string_totals([before_commited_amount, calc_est_amount], commited_amount)
    check.equal(calculated_commited_amount, commited_amount, 'Commited Amount after approve')
    # Spend Amount
    check.equal(get_element_text(approve_budget_spend_ammount), get_data('BudgetSpendAmount'),
                'Spend Amount before approve')
    return calculated_available_budget, calculated_commited_amount


def validate_budget_after_approve_delete_order(after_new_calc_avail_budget, after_new_calc_comm_amount,
                                               calc_est_amount):
    wait_for_spinner_on()
    wait_for_spinner_off()
    # Estimated Amount
    estimated_amount = get_element_text(approve_budget_estimated_amount)
    # Calculate Estimated Cost after delete one month of subscription
    calculate_estimated_cost = subtract_string_totals([calc_est_amount, get_data('TotalCost')], estimated_amount)
    check.is_in(calculate_estimated_cost, estimated_amount, 'Estimated Cost after delete one month')
    # Delete Committed Amount
    commited_amount = get_element_text(approve_budget_commited_amount)
    calculated_commited_amount = subtract_string_totals([after_new_calc_comm_amount, calculate_estimated_cost],
                                                        commited_amount)
    check.equal(calculated_commited_amount, commited_amount, 'Commited Amount after delete')
    # Delete Available Budget Amount
    available_budget = get_element_text(approve_budget_available_amount)
    calculated_available_budget = sum_string_totals([after_new_calc_avail_budget, calculate_estimated_cost],
                                                    available_budget)
    check.equal(calculated_available_budget, available_budget, 'Available Budget after delete')
    return calculated_available_budget, calculated_commited_amount


def verify_orders_service_details(service_name, actual_order_details_params, exp_order_details, quantity=None,
                                  skip_user=False):
    for order_detail_label, order_detail_value in actual_order_details_params.items():
        if order_detail_label == "Total Estimated Cost":
            if exp_order_details["estimated_price"]:
                check.is_in(exp_order_details["estimated_price"], order_detail_value.replace("(", "").replace(")", ""),
                            'Estimated Price')
        elif order_detail_label == "Status":
            check.is_in(exp_order_details["order_status"], order_detail_value, 'Order Status')
        elif order_detail_label == "Type":
            check.is_in(exp_order_details["order_type"], order_detail_value, 'Order Type')
        elif order_detail_label == "Submitted By" and not skip_user:
            user = MO_USER
            if os.environ.get("Environment"):
                user = os.environ.get("kyndryl_user")
            check.is_in(order_detail_value.replace(",", ""), user, 'Submitted By')
        elif order_detail_label == "Service Instance Prefix":
            check.is_in(service_name, order_detail_value, 'Service Instance Prefix')
        elif order_detail_label == "Service Offering Name":
            # try:
            check.is_in(exp_order_details["blueprint_name"], order_detail_value, 'Service Offering Name')
            # except:
            #     check.is_in(exp_order_details["soNames"], order_detail_value, 'Service Offering Name')
        elif order_detail_label == "Provider":
            check.is_in(get_data("provider"), order_detail_value, 'Provider')
        elif order_detail_label == "Quantity":
            check.is_in(quantity, order_detail_value, 'Quantity')


def click_service_view_details():
    click(order_table_action_icon, "Order Details Action button")
    click(view_service_details_link, "View details")


# The function validates additional parameter configuration on
# orders page -->service details -->view details --> Additional details against test data file parameters
def validate_service_details_config(imi=None, version=None, is_editing=False,
                                    edit_addtl_params_key='Edit Additional Parameters'):
    additional_params_titles = get_elements_texts(adtnl_details_params_labels_txt)
    additional_params_values = get_elements_texts(adtnl_details_params_values_txt)
    actual_service_details_ui = dict(zip(additional_params_titles, additional_params_values))
    if is_editing:
        addtnl_params_json_dic_data = merge_edit_additional_parameters(edit_addtl_params_key)
    else:
        addtnl_params_json_dic_data = get_data_object("Additional Parameters")
    for key, actual_value in actual_service_details_ui.items():
        expected_value = get_value(addtnl_params_json_dic_data["Additional Parameters"], key)
        if expected_value is not None:
            # Validates if the expected value is a list of values (multiselect options) and format the values
            if type(expected_value) == list:
                expected_value, actual_value = format_detail_multiple_values(expected_value, actual_value)
            # Validates the value in case the title exists more than one time
            if additional_params_titles.count(key) > 1:
                for idx, title in enumerate(additional_params_titles):
                    if title == key and additional_params_values[idx] in expected_value:
                        actual_value = additional_params_values[idx]
                        break
            check.is_in(expected_value.lower(), actual_value.lower(), key)
        else:
            # Validates if the label is present more than one time, in JSON the key must be 
            # eg. "key[0]": "value" in the same step object
            for _, data in addtnl_params_json_dic_data["Additional Parameters"].items():
                for param, param_obj in data.items():
                    if key in param:
                        expected_value = param_obj.get('value')
                        actual_value = check_repeated_label_values(param, expected_value, None,
                                                                   additional_params_titles, additional_params_values)
                        if actual_value:
                            check.is_in(actual_value.lower(), expected_value.lower(), param)
    if imi:
        # Validate Add On Details
        click(add_on_details_btn, "Add On Details button")
        add_on_details = dict(zip(get_elements_texts(add_on_labels), get_elements_texts(add_on_values)))
        check.equal(add_on_details["Management level"], imi_config_test_data["Management level"], "Management level")
        check.equal(add_on_details["Plan level"], imi_config_test_data["BillingPlan"], "Plan level")
        check.equal(add_on_details["Provider"], imi_config_test_data["imi_provider"], "IMI Provider")
        check.equal(add_on_details["Service Offering Name"], get_data("IMI Service offering"), "IMI Service offering")
    # Validates version
    if version:
        check.equal(version, get_element_text(mo_version_text), 'mo_ui_test_data Version')


def verify_order_status(order_no, expected_status, path=None):
    if path is not None:
        set_data_path(path)
    open_approve_orders_page()
    click_on_all_orders_tab()
    search_order_in_approve(order_no)
    wait_for_order_status(order_no, expected_status)
    order_status = get_element_text(order_details_order_status_text).strip()
    check.equal(order_status, expected_status, "Order Status")
    return order_status


# Function validates order details for d2ops and custom operations    
def validate_d2ops_order_details(order_details, skip_user=False):
    order_no = order_details["order_no"]
    service_name = order_details["service_name"]
    exp_estimated_price = order_details["estimated_price"]
    if "order_type" in order_details:
        order_type = order_details["order_type"]
    else:
        order_type = mo_ui_test_data["ordertypeAction"]
    try:
        quantity = order_details["quantity"]
    except KeyError:
        logger.info("Order Detail doesn't have quantity key, using default quantity as 1")
        quantity = "1"
    # Validations for order details table
    actual_order_details_params = dict(zip(get_elements_texts(order_details_labels),
                                           get_elements_texts(order_details_values)))
    exp_order_details_data = {"order_status": mo_ui_test_data["completedState"],
                              "order_type": order_type,
                              "estimated_price": exp_estimated_price}

    exp_order_service_details_data = {"blueprint_name": order_details["service_offering_name"],
                                      "estimated_price": exp_estimated_price}

    verify_orders_service_details(service_name, actual_order_details_params, exp_order_details_data,
                                  skip_user=skip_user)
    # Validations for Service Details table
    actual_order_service_details_params = dict(zip(get_elements_texts(order_service_details_labels),
                                                   get_elements_texts(order_service_details_values)))
    verify_orders_service_details(service_name, actual_order_service_details_params,
                                  exp_order_service_details_data, quantity, skip_user=skip_user)


def validate_bill_of_materials(exp_estimated_cost):
    # Validate Bill of Materials
    click(bill_of_materials_service_details_btn, "Bill Of Materials")
    act_estimated_cost_ui = get_element_text(estimated_cost_txt)
    act_estimated_cost = act_estimated_cost_ui.replace("(", "").replace(")", "")
    click(more_link, "More link")
    # Monthly Cost and One time cost calculation
    monthly_cost = sum_totals_by_locator(monthly_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
    one_time_cost = sum_totals_by_locator(one_time_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
    total_sum = sum_string_totals([monthly_cost, one_time_cost], exp_estimated_cost)
    check.equal(act_estimated_cost, exp_estimated_cost, 'Total Cost')
    check.equal(act_estimated_cost, total_sum, 'Monthly Cost and One Time Cost')
    close_view_details_slider_window()


def validate_alerts_for_hard_quota_threshold():
    check.is_true(is_element_present(budget_exceeds_hard_threshold, "Budget exceeds Hardthresold"),
                  "Budget exceeds Hardthresold Alert")
    check.equal((get_element_text(budget_exceeds_hard_limit_text)), mo_ui_test_data["OverUtilizedBudgetAlert"],
                "Over utilized Budget Alert")
    budget_exceed_time = get_element_text(budget_exceeds_hardlimit_time)
    formatted_budget_exceed_time_value = re.sub("as of ", "", budget_exceed_time)
    logger.info(
        f"Budget exceed actual Time value: {budget_exceed_time} : Budget exceed formatted Time value:{formatted_budget_exceed_time_value}")
    formatted_budget_exceed_time_value_list = formatted_budget_exceed_time_value.split(":")[0:2]
    logger.info(
        f"Budget exceed actual Time value: {formatted_budget_exceed_time_value} : Budget exceed formatted Time value:{formatted_budget_exceed_time_value_list}")
    formatted_budget_exceed_time_value_string = ":".join(formatted_budget_exceed_time_value_list)
    logger.info(
        f"Budget exceed actual Time value: {formatted_budget_exceed_time_value_list} : Budget exceed formatted Time value:{formatted_budget_exceed_time_value_string}")
    check.equal(formatted_budget_exceed_time_value_string, get_current_formatted_time(),
                "Budget Exceed Hard Limit Time Alert")


def get_view_details_provider(order_no):
    search_order_in_approve(order_no)
    wait_for_order_present(order_no)
    click_service_view_details()
    provider = get_element_text(view_details_provider_name)
    close_view_details_slider_window()
    return provider
