from pages.store.review_order_page import get_attribute_text
from helpers.mo_check import mo_check as check
from helpers.mo_element_operations import *
from sys import path
from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_json_utils import *
import datetime
from locators.store.catalog_management_locator import *
from pages.common.login_page import loader_off
from pages.store.navigation_page import *
from pages.store.catalog_page import *
from os.path import abspath
from helpers.mo_check import mo_check as check
from pages.store.catalog_management_page import *
from locators.store.service_chaining_locator import *


def validate_title_text_on_service_chaining_page():
    wait_for_spinner_off()
    explicit_wait(3)
    wait_for_element_to_visible(service_chaining_title, "Service Chaining Page Title")
    check.equal(get_element_text(service_chaining_title), get_data("serviceChainingTitleText"), 'Service Chaining Page Title')


def publish_pattern(pattern_name):
    click_on_pattern_action_button(pattern_name, 'Publish')
    publish_successful_msg = get_data("publishServiceSuccessMsg")
    check.is_in(get_text_for_notification_msg(), get_element_text(publish_successful_msg), "Publish Successful")
    click_on_close_notification_button()


def click_on_pattern_options_icon(pattern_name):
    click_using_script_replace_value(options_button, pattern_name, "Options icon")


def click_on_pattern_action_button(pattern_name, action):
    if action == "View":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_pattern_name,
                                                       [pattern_name, "View"], "View")
        click_using_script_replace_value(action_button_based_on_pattern_name, [pattern_name, "View"],
                                         "View")

    elif action == "Edit":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_pattern_name,
                                                       [pattern_name, "Edit"], "Edit")
        click_using_script_replace_value(action_button_based_on_pattern_name, [pattern_name, "Edit"],
                                         "Edit")

    elif action == "Preview":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_pattern_name,
                                                       [pattern_name, "Preview"], "Preview")
        click_using_script_replace_value(action_button_based_on_pattern_name, [pattern_name, "Preview"],
                                         "Preview")

    elif action == "Publish":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_pattern_name,
                                                       [pattern_name, "Publish "], "Publish")
        click_using_script_replace_value(action_button_based_on_pattern_name, [pattern_name, "Publish"],
                                         "Publish")
    elif action == "clone":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_pattern_name,
                                                       [pattern_name, "Retire"], "Retire")
        click_using_script_replace_value(action_button_based_on_pattern_name, [pattern_name, "Retire"], "Retire")
    elif action == "Delete":
        wait_for_element_to_visible_with_replace_value(action_button_based_on_pattern_name,
                                                       [pattern_name, "Delete"], "Delete")
        click_using_script_replace_value(action_button_based_on_pattern_name, [pattern_name, "Delete"], "Delete")


def select_tab(tab):
    wait_for_element_to_visible_with_replace_value(tabs_path, tab, "Drafts/Published/Retired Tab")
    click_using_script_replace_value(tabs_path, tab, "Tab")
    wait_for_element_to_visible(first_pattern, "First Pattern")


def validate_created_pattern(pattern_name, action):
    # patterns = get_elements_texts(all_patterns)
    # for value in patterns:
    while True:
        if is_element_present_replace_value(created_pattern_text, pattern_name):
            logger.info("Pattern is present :" + pattern_name)
            scroll_element_into_view_with_replace_value(created_pattern_text, pattern_name)
            click_on_pattern_options_icon(pattern_name)
            click_on_pattern_action_button(pattern_name, action)
            break
        else:
            click_using_java_script(next_button, "Next Button")


def validate_created_pattern_in_drafts(pattern_name, action):
    created_pattern = get_element_text_replace_value(created_pattern_text, pattern_name, "Pattern Name")
    if created_pattern == pattern_name:
        logger.info("Pattern is present :" + pattern_name)
        click_on_pattern_options_icon(pattern_name)
        click_on_pattern_action_button(pattern_name, action)

    else:
        click_using_java_script(next_button, "Next Button")


def get_order_number():
    # Increasing timeout to run Edit flows properly
    order_id_text = get_element_text(order_num_text,10)
    order_id = order_id_text.split(":")
    logger.info("Order id: " + order_id[1])
    logger.info("Order id: " + order_id[1].strip())
    return order_id[1].strip()






