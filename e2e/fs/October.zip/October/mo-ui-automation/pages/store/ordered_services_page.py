import time

from pages.store.approve_order_page import approve_order_wait_for_completion
from pages.store.catalog_management_page import click_on_close_notification_button
from pages.store.mo_store_utils import format_detail_multiple_values, sum_string_totals, sum_totals_by_locator, \
    merge_edit_additional_parameters
from locators.store.order_services_locator import *
from pages.store.navigation_page import *
from helpers.mo_json_utils import get_data_object, get_value, get_data
from helpers.mo_check import mo_check as check


def search_service_name(service_name):
    # Wait to load the table for first time
    wait_for_spinner_off()
    wait_for_element_to_visible(ordered_service_table_row, "at least one Table Row")
    # Search the service
    type_value_and_enter(search_service_name_path, service_name, "Service instance name search")
    # Wait for service to load in table
    wait_for_spinner_off()
    wait_for_element_to_visible_with_replace_value(service_instance_txt, service_name, 'Service Instance Text')

def search_transfer_service_name(service_name):
    # Wait to load the table for first time
    wait_for_spinner_off()
    wait_for_element_to_visible(ordered_service_table_row, "at least one Table Row")
    # Search the service
    type_value_and_enter(transfer_service_name_path, service_name, "Service instance name search")
    # Wait for service to load in table
    wait_for_spinner_off()
    wait_for_element_to_visible_with_replace_value(service_instance_txt, service_name, 'Service Instance Text')


def delete_service(service_name):
    open_ordered_services_page()
    search_service_name(service_name)
    click_action_service_instance()
    click_using_java_script(delete_service_path, "Delete Service button")
    click_using_java_script(understand_delete_service, "Confirm Delete")
    click_using_java_script(confirm_ok, "ok for Delete")
    delete_order_msg = get_element_text(delete_order_no_txt)
    delete_order = str(delete_order_msg.split(":")[1]).strip()
    logger.info("Delete Order no - " + delete_order)
    return delete_order


def delete_service_using_multi_qty(service_name,multi_qty):
    counter = int(multi_qty)
    while counter > 0:
        delete_order_no = delete_service(service_name)
        # Approve order and wait till it gets completed
        approve_order_wait_for_completion(delete_order_no, service_name)
        counter = counter - 1


def edit_service(service_name):
    open_ordered_services_page()
    search_service_name(service_name)
    click_action_service_instance()
    click_using_java_script(edit_service_btn, "Edit Service")


def edit_mo_version(service_name):
    open_ordered_services_page()
    search_service_name(service_name)
    click_action_service_instance()
    click_using_java_script(edit_mo_version_btn, "Available Version")
    wait_for_spinner_off()


def expand_service_instance():
    click_using_java_script(expand_service_instance_btn, "Expand service instance")


def click_action_service_instance():
    click_using_java_script(menu_path, "Action button for service instance")

def click_transfer_service_action_instance(service_name):
    click_using_script_replace_value(transfer_service_action_button, service_name, "Action button for transfer service instance")
def click_menu_soi_comp(column_text=None, exact_text=True):
    wait_for_spinner_off()
    if column_text and exact_text:
        click_using_script_replace_value(soi_comp_menu_btn_col_exact, column_text, 'SOI Component with exact name Menu Button')
    elif column_text:
        click_using_script_replace_value(soi_comp_menu_btn_col, column_text, 'SOI Component Menu Button')
    else:
        click_using_java_script(soi_comp_menu_btn, "Action button for first SOI component")


# Function handles positive and negative scenarios for d2ops
def soi_operation(operation_name, service_name, component_type=None, negative=None, custom_ops=None, icam=None, exact_component_name=False):
    open_ordered_services_page()
    wait_for_spinner_off()
    search_service_name(service_name)
    expand_service_instance()
    if icam:
        click_pagination_select()
    else:
        logger.info("Not required to click on pagination.")
    click_menu_soi_comp(component_type, exact_component_name)
    # Handling for IMI, click based on component type
    if operation_name == mo_ui_test_data["configureImiManagedService"]:
        exp_soi_component_details = get_data("Component Details")
        component_name = exp_soi_component_details["Component Type"]
        if type(component_name) == dict:
            component_name = component_name[test_Adapter]
        click_soi_operation([component_name, operation_name])
    else:
        click_soi_operation(operation_name, component_type, exact_component_name, icam)
    place_order_btn_present = check_element_exists(place_d2ops_btn)
    if place_order_btn_present:
        click(place_d2ops_btn, "Place an Order")
        logger.info("clicked on placed an order..")
    if negative:
        # Get warning message for operation if its not supported
        wait_for_all_elements_to_load(warning_popup_txt, 'Warning Popup Text')
        warning_msg = get_element_text(warning_popup_txt)
        click_using_java_script(warning_popup_ok_btn, "Ok button for operation warning")
        return warning_msg
    elif custom_ops:
        click_using_java_script(ok_d2ops_btn, "Confirm operation")
    else:
        click_using_java_script(ok_d2ops_btn, "Confirm operation")
        wait_for_spinner_off()
        order_no = fetch_d2ops_order_details()
        return order_no


def view_service_details(service_name):
    open_ordered_services_page()
    search_service_name(service_name)
    click_action_service_instance()
    click_using_java_script(view_service_details_btn, "View Service details")


def get_estimated_cost():
    click_using_java_script(bom_btn, "Bill of Materials")
    bom = get_element_text(estimated_cost_txt)
    return bom


def click_soi_operation(operation_name, column_text=None, exact_text=False, icam=None):
    if column_text and exact_text:
        wait_for_all_elements_to_load_replace_value(soi_operation_btn_col_exact, [column_text, operation_name],
                                                    'SOI Operation Button with exact name')
        click_using_script_replace_value(soi_operation_btn_col_exact, [column_text, operation_name],
                                         'SOI Operation Button')
    elif column_text:
        wait_for_all_elements_to_load_replace_value(soi_operation_btn_col, [column_text, operation_name],
                                                    'SOI Operation Button with column name')
        click_using_script_replace_value(soi_operation_btn_col, [column_text, operation_name], 'SOI Operation Button')
    elif icam:
        is_element_present_replace_value(soi_operation_btn_for_icam, operation_name)
        wait_for_all_elements_to_load_replace_value(soi_operation_btn_for_icam, operation_name, 'SOI Operation Button for icam')
        click_using_script_replace_value(soi_operation_btn_for_icam, operation_name, 'SOI Operation Button')
    else:
        wait_for_all_elements_to_load_replace_value(soi_operation_btn, operation_name, 'SOI Operation Button')
        # Click Menu option based on component name, operation name must be a list like [component_name, operation_name]
        if type(operation_name) == list:
            click_using_script_replace_value(soi_operation_based_on_component, operation_name, "SOI Operation button")
        else:
            click_using_script_replace_value(soi_operation_btn, operation_name, 'SOI Operation Button')
    wait_for_spinner_off()


def fetch_d2ops_order_details(repeat_count=None, custom_ops=None):
    order_id = None
    if custom_ops:
        order_id_locator = orderid_custom_ops
    else:
        order_id_locator = orderId_txt
    if repeat_count is None:
        repeat_count = 30
    while order_id is None and repeat_count > 0:
        # if repeat_count > 0:
        explicit_wait(2)
        is_btn_present = check_element_exists(fetch_order_details_btn)
        logger.info(" Is the link 'Please click here for order updates' present: " + str(is_btn_present))
        if is_btn_present:
            explicit_wait(5)
            try:
                click(fetch_order_details_btn, "Fetch order details")
            except:
                logger.info("Fetch order details button disappeared")
            is_order_id_present = check_element_exists(order_id_locator)
            if is_order_id_present:
                logger.info("Order Submitted Details displayed,Order Submitted!,breaking the loop")
                order_id = get_element_text(order_id_locator)
            else:
                logger.info("Order Submitted Details not displayed,continuing the loop")
                repeat_count = repeat_count - 1
        else:
            is_order_id_present = check_element_exists(order_id_locator)
            if is_order_id_present:
                order_id = get_element_text(order_id_locator)
            else:
                logger.info("Order Submitted Details not displayed,continuing the loop")
                repeat_count = repeat_count - 1
    if custom_ops is None:
        click(order_submitted_okD2ops_btn, "Order Submitted - ok button")
    return order_id


# To validate instance power status
def verify_instance_status(service_name, power_status):
    open_ordered_services_page()
    search_service_name(service_name)
    expand_service_instance()
    status_list = get_elements_texts(instance_state_text)
    assert power_status in status_list


def get_name_value_from_sub_table(service_name):
    open_ordered_services_page()
    search_service_name(service_name)
    expand_service_instance()
    return get_element_text(sub_table_service_name_text)


def wait_for_instance_status(power_status, counter=40):
    res = True
    while res and counter > 0:
        expand_service_instance()
        status_list = get_elements_texts(instance_state_text)
        if power_status in status_list:
            logger.info(f"Status matches the expected status {power_status}")
            res = False
        else:
            status_list = get_elements_texts(instance_state_text)
            expand_service_instance()
            counter = counter - 1
    assert power_status in status_list


def verify_soi_component_details(exp_soi_comp_details, component_name=None, expand_row=True, only_real=False,
                                 exact_component_name=False, only_dummy=False, duplicate_labels=False):
    # Skip to validate details in case is only present for real adapter (Some services in dummy adapter has only one
    # component, but real sometimes has more than one)
    if test_Adapter != 'real' and only_real:
        return None, None
    # Skip to validate details in case is only present for dummy adapter
    if test_Adapter != 'dummy' and only_dummy:
        return None, None
    # Open expand if is necessary
    if expand_row:
        expand_service_instance()
    click_menu_soi_comp(component_name, exact_component_name)
    click_soi_operation("View Component", component_name, exact_component_name)
    # Get Component Details from UI
    act_component_details = dict(zip(get_elements_texts(component_name_txt), get_elements_texts(component_value_txt)))
    # Get system tag details from UI
    try:
        system_tags_details = get_elements_texts(tags_txt)
    except:
        system_tags_details = []
    # Append Component Resource Id in last and use it in test for validation
    system_tags_details.append(act_component_details["Resource Id"])
    # Get output parameter details from UI(dict is avoided to include duplicate keys)
    if duplicate_labels:
        # following includes the duplicate lables and creates a list of tuples
        output_params = zip(get_element_text_no_wait(output_params_labels_txt),
                            get_element_text_no_wait(output_params_values_txt))
        logger.info(f"output_params with duplicate labels: {output_params}")
    else:
        output_params = dict(zip(get_element_text_no_wait(output_params_labels_txt),
                                 get_element_text_no_wait(output_params_values_txt)))
        logger.info(f"output_params: {output_params}")
    # Validation for SOI Component Details
    # Check if Real Adapter is enabled accidentally through API and user is unaware of it
    adapter = get_test_adapter()
    for exp_component_name, exp_component_value in exp_soi_comp_details.items():
        if act_component_details[exp_component_name]:
            if type(exp_component_value) == dict:
                # exp_component_value = exp_component_value[test_Adapter]
                exp_component_value = exp_component_value[adapter]
            check.is_in(exp_component_value, act_component_details[exp_component_name], exp_component_name)
    # Close Component details window
    close_details_window()
    return system_tags_details, output_params


def close_details_window():
    click(close_service_details_btn, "Close Service Details button")


def validate_service_details_ordered_services(service_name, is_editing=False,
                                              edit_addtl_params_key='Edit Additional Parameters',
                                              skip_total_calc=False):
    view_service_details(service_name)
    # Validations for Service configurations
    ui_labels = get_elements_texts(service_configurations_labels)
    ui_values = get_elements_texts(service_configurations_values)
    # Remove the label from the returned value, this because sometimes we have multiple values and
    # are separated in multiple html tags
    for index, label in enumerate(ui_labels):
        ui_values[index] = ui_values[index].replace(label, "")
    act_service_config_details = dict(zip(ui_labels, ui_values))
    if is_editing:
        addtnl_params_json_dic_data = merge_edit_additional_parameters(edit_addtl_params_key)
    else:
        addtnl_params_json_dic_data = get_data_object("Additional Parameters")
    for key, actual_value in act_service_config_details.items():
        expected_value = get_value(addtnl_params_json_dic_data["Additional Parameters"], key.replace(":", ""))
        if expected_value:
            # Validates if the expected value is a list of values (multiselect options) and format the values
            if type(expected_value) == list:
                expected_value, actual_value = format_detail_multiple_values(expected_value, actual_value)
            check.is_in(expected_value.lower(), actual_value.lower(), key)
    # Validations for Service Details Parameters
    act_service_details = dict(
        zip(get_elements_texts(service_details_labels), get_elements_texts(service_details_values)))
    check.is_in(service_name, act_service_details["Service Instance Name"], 'Service Instance Name')
    check.is_in(act_service_details["Service Offering Name"], get_data("bluePrintName"), 'Blueprint Name')
    check.is_in(act_service_details["Provider Name"], get_data("provider"), 'Provider')
    check.is_in(act_service_details["Instance Status"], mo_ui_test_data["instanceStatus"], 'Instance Status')
    # Validations for Hill-18 scenario ('hackathon-lamp' service)
    if mo_ui_test_data["completedServiceName"] in service_name:
        check.is_in(get_data("Owner"), act_service_details["Owner"], 'Owner')
        check.is_in(act_service_details["Team"], get_data("Team"), 'Team')
        check.is_in(act_service_details["Organization"], get_data("Organization"), 'Organization')
    elif mo_ui_test_data["completedIcamServiceName"] in service_name:
        check.is_in(act_service_details["Team"], mo_ui_test_data["IcamTeam"], 'Team')
        check.is_in(act_service_details["Organization"], mo_ui_test_data["IcamOrganization"], 'Organization')
        check.is_in(act_service_details["Environment"], mo_ui_test_data["IcamEnvironment"], 'Environment')
        check.is_in(act_service_details["Application"], mo_ui_test_data["IcamApplication"], 'Application')
        check.is_in(get_data("Provider Account", get_data("Main Parameter"))["value"].replace(" ", ""),
                    act_service_details["Provider Account Name"], 'Provider Account')
    else:
        user = MO_USER
        if os.environ.get("Environment"):
            user = os.environ.get("kyndryl_user")
        check.is_in(act_service_details["Owner"], user, 'Owner')
        check.is_in(act_service_details["Team"], mo_ui_test_data["TeamName"], 'Team')
        check.is_in(act_service_details["Organization"], mo_ui_test_data["Organization"], 'Organization')
        check.is_in(act_service_details["Environment"], mo_ui_test_data["Environment"], 'Environment')
        check.is_in(act_service_details["Application"], mo_ui_test_data["Application"], 'Application')
        check.is_in(get_data("Provider Account", get_data("Main Parameter"))["value"].replace(" ", ""),
                    act_service_details["Provider Account Name"], 'Provider Account')
    # Validations for Bill of Materials
    click(bom_btn, "Bill of Materials")
    act_estimated_cost = get_element_text(estimated_cost_txt)
    exp_estimated_cost = get_data("TotalCost")
    # below 2 lines go under below if stmt, to handle scenario when service has pricing warning i.e not available shows up on review order page
    # check.is_in(act_estimated_cost,exp_estimated_cost, 'Total Cost')
    # click(more_link, "More Link")
    # Monthly Cost and One time cost calculation
    if not skip_total_calc:
        check.is_in(act_estimated_cost, exp_estimated_cost, 'Total Cost')
        click(more_link, "More Link")
        monthly_cost = sum_totals_by_locator(monthly_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
        one_time_cost = sum_totals_by_locator(one_time_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
        total_sum = sum_string_totals([monthly_cost, one_time_cost], exp_estimated_cost)
        check.equal(act_estimated_cost, exp_estimated_cost, 'Total Cost')
        check.equal(act_estimated_cost, total_sum, 'Monthly Cost and One Time Cost')
    close_details_window()


def verify_soi_component_details_for_dummy(actual_tags, actual_output_params, exp_system_tags, is_editing=False,
                                           edit_addtl_params_key='Edit Additional Parameters', duplicate_labels=False):
    # Validation for system tags
    if test_Adapter != "dummy":
        return
    for index, system_tag in enumerate(actual_tags):
        try:
            act_sys_tag = system_tag.split(":")
            system_tag_name = act_sys_tag[0]
            system_tag_value = act_sys_tag[1]
            try:
                if exp_system_tags[system_tag_name]:
                    check.is_in(exp_system_tags[system_tag_name], system_tag_value, system_tag_name)
            except KeyError:
                logger.info(f"System tag {system_tag_name} is not part of validation")
        except IndexError:
            # Just pass when IndexError is thrown because actual_tags have any empty value
            pass
    # Validation for output parameters
    if is_editing:
        addtnl_params_json_dic_data = merge_edit_additional_parameters(edit_addtl_params_key)
    else:
        addtnl_params_json_dic_data = get_data_object("Additional Parameters")

    if duplicate_labels:
        # From grabed UI (label/value) list creating 2 seperate lists of keys and values to loop through them
        all_keys_from_page = []
        all_values_from_page = []
        for index, tuple in enumerate(actual_output_params):
            all_keys_from_page.append(tuple[0])
            all_values_from_page.append(tuple[1])
        # Loop through json data file in additional parameters object to compare if values from json data matches data from UI
        for x, data in addtnl_params_json_dic_data["Additional Parameters"].items():
            # to get the actual attributes mapping to UI label name and value
            for key, expected_value in data.items():
                # keys from json file match with label list from UI
                if key in all_keys_from_page:
                    # extract actual value of label from json data
                    if expected_value['value']:
                        # if json data has multiple values e.g.zone:[asia,america,uk] then loop through the values and match with UI label/multiple values e.g. zone:asia,america,uk
                        if type(expected_value['value']) == list:
                            for exp_val in expected_value['value']:
                                # looping through all labels from ui
                                for index, key_name in enumerate(all_keys_from_page):
                                    actual_key = key_name
                                    # grab ui value using index from list of all ui values
                                    actual_value = all_values_from_page[index]
                                    # compare ui label/value with json key/value
                                    if actual_key == key and exp_val == actual_value:
                                        check.is_in(exp_val.lower(), actual_value.lower(), key)
                        else:
                            # if json data for value is not a list e.g zone:asia,run below
                            for index, key_name in enumerate(all_keys_from_page):
                                actual_key = key_name
                                actual_value = all_values_from_page[index]
                                if actual_key == key and expected_value['value'] == actual_value:
                                    check.is_in(expected_value['value'].lower(), actual_value.lower(), key)
                else:
                    assert False, f'{key} does not exist'
    else:
        for key, actual_value in actual_output_params.items():
            expected_value = get_value(addtnl_params_json_dic_data["Additional Parameters"], key)
            if expected_value:
                if type(expected_value) == list:
                    for exp_val in expected_value:
                        check.is_in(exp_val.lower(), actual_value.lower(), key)
                else:
                    check.is_in(expected_value.lower(), actual_value.lower(), key)


def verify_soi_component_details_for_real(actual_tags, actual_output_params, exp_tags_key="real_adapter_tags",
                                          exp_output_params_key="real_adapter_output_params", component_status=""):
    if test_Adapter != "real":
        return
    is_tag_validated = True
    exp_tags = get_data(exp_tags_key)
    logger.info(f"exp_tags: {exp_tags}")
    exp_output_params = get_data(exp_output_params_key)
    logger.info(f"exp_output_params: {exp_tags}")
    # Skip validation for 'DELETED' components
    if component_status != "DELETED":
        # Validations for system tags of Real Adapter service
        for index, exp_tag in enumerate(exp_tags):
            for index_act, actual_tag in enumerate(actual_tags):
                is_tag_validated = False
                if exp_tag in actual_tag:
                    check.is_in(exp_tag, actual_tag)
                    is_tag_validated = True
                    break
            if not is_tag_validated:
                # Fail the validation
                check.is_false(is_tag_validated)
        # Validation for Output Parameters of Real Adapter service
        # Handling for skipping output parameter validation
        if exp_output_params is not None:
            for exp_param, exp_param_value in exp_output_params.items():
                if actual_output_params[exp_param]:
                    actual_param_value = actual_output_params[exp_param]
                    logger.info(f"exp_output_params: {actual_param_value}")
                    check.is_in(exp_param_value, actual_param_value, exp_param)


# Get EC2 URL's header text
def get_ec2_access_url(service_name):
    view_service_details(service_name)
    url = get_element_text(website_url_txt)
    driver.execute_script("window.open('" + url + "')")
    switch_to_new_window()
    # page_header = driver.title
    page_title = get_element_text(page_header)
    switch_to_parent_window()
    return page_title


def get_ec2_url_header_text_from_view_component(service_name, component_type):
    open_ordered_services_page()
    wait_for_spinner_off()
    search_service_name(service_name)
    expand_service_instance()
    click_menu_soi_comp(component_type)
    click_soi_operation(mo_ui_test_data["viewComponentBtnText"])
    ec2url = get_element_text_replace_value(output_params_value_using_label, "PublicDnsName", "Public DNS Name").strip()
    # Close Component details window
    close_details_window()
    driver.execute_script("window.open('http://" + ec2url + "');")
    switch_to_new_window()
    page_title = get_element_text(page_header)
    switch_to_parent_window()
    return page_title


def verify_service_non_editable_text():
    wait_for_spinner_off()
    edit_not_supported = get_element_text(warning_popup_txt)
    logger.info(edit_not_supported)
    click_using_java_script(warning_popup_ok_btn, "Edit Service")
    return edit_not_supported


# Click on Order history tab button
def click_on_order_history_tab():
    click(order_history_tab_button, "Order history tab button")
    wait_for_all_elements_to_load(order_history_table_rows, "Table rows")


# Validate order history tab details
def validate_order_history_tab(service_name):
    view_service_details(service_name)
    click_on_order_history_tab()
    check.equal(get_element_text(order_history_row_type).strip(), mo_ui_test_data["orderTypeNew"])
    check.equal(get_element_text(order_history_row_status).strip(), mo_ui_test_data["completedState"])
    check.equal(get_element_text(order_history_row_estimated_cost).strip(), get_data("TotalCost"))
    close_details_window()


# Validate access component text message
def validate_access_component_text(service_name, component_type):
    open_ordered_services_page()
    wait_for_spinner_off()
    search_service_name(service_name)
    expand_service_instance()
    click_menu_soi_comp(component_type)
    click_soi_operation(mo_ui_test_data["accessComponentBtnText"])
    check.is_in(get_data("accessCompText"), get_element_text(access_comp_para_text), "Access component para text")
    click(access_comp_modal_ok_btn, "Access component OK button")


def view_imi_add_on(service_name, add_on):
    open_ordered_services_page()
    wait_for_spinner_off()
    search_service_name(service_name)
    click_action_service_instance()
    click_with_replace_value(add_on_button, add_on, "Add on")
    click(view_addon_button, "View Add on")


# Validate add on details of service
def validate_add_on_details(service_name, add_on):
    view_imi_add_on(service_name, add_on)
    # Validate Add on details
    add_on_details = dict(
        zip(get_elements_texts(service_config_labels_add_on), get_elements_texts(service_config_values_add_on)))
    check.equal(add_on_details["Management level:"], imi_config_test_data["Management level"], "Management Level")
    check.equal(add_on_details["Plan level:"], imi_config_test_data["BillingPlan"], "Plan Level")
    service_details_tab_add_on_details = dict(
        zip(get_elements_texts(service_detail_add_on_label), get_elements_texts(service_detail_add_on_values)))
    check.is_in(add_on, service_details_tab_add_on_details["Service Instance Name"], "Service Instance Name")
    check.equal(service_details_tab_add_on_details["Service Offering Name"], get_data("IMI Service offering"),
                "IMI Service Offering Name")
    check.equal(service_details_tab_add_on_details["Provider Name"], imi_config_test_data["imi_provider"],
                "IMI Provider")
    # Validations for Bill of Materials
    click(bom_btn, "Bill of Materials")
    act_estimated_cost = get_element_text(estimated_cost_txt)
    exp_estimated_cost = imi_config_test_data["TotalCost"]
    check.is_in(act_estimated_cost, exp_estimated_cost, 'Total Cost')
    click(more_link, "More Link")
    # Monthly Cost and One time cost calculation
    monthly_cost = sum_totals_by_locator(monthly_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
    one_time_cost = sum_totals_by_locator(one_time_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
    total_sum = sum_string_totals([monthly_cost, one_time_cost], exp_estimated_cost)
    check.equal(act_estimated_cost, exp_estimated_cost, 'Total Cost')
    check.equal(act_estimated_cost, total_sum, 'Monthly Cost and One Time Cost')
    close_details_window()
    # Validate system tags
    if test_Adapter == 'dummy':
        exp_system_tags = imi_config_test_data["System tags dummy"]
    else:
        exp_system_tags = imi_config_test_data["System tags real"]
    exp_soi_component_details = get_data("Component Details")
    component_name = exp_soi_component_details["Component Type"]
    if type(component_name) == dict:
        component_name = component_name[test_Adapter]
    act_system_tags_details, act_output_params = verify_soi_component_details(exp_soi_component_details, component_name)
    verify_soi_component_details_for_dummy(act_system_tags_details, act_output_params, exp_system_tags)


def get_attachment_id(service_name, component_type):
    open_ordered_services_page()
    wait_for_spinner_off()
    search_service_name(service_name)
    expand_service_instance()
    click_menu_soi_comp(component_type)
    click_soi_operation("View Component", component_type)
    click(view_details_network_interface, "View Network Interface Details")
    click(view_details_attachment, "View Attachment Details")
    at_id = get_element_text(attachment_id)
    close_details_window()
    return at_id


def get_test_adapter():
    try:
        wait_for_spinner_off()
        tags = get_element_text(component_tags)
        is_using_dummy = tags.split(",")[0]
        if '"IsUsingDummy":"Yes"' in is_using_dummy:
            return "dummy"
        else:
            return "real"
    except:
        return test_Adapter


def click_pagination_select():
    try:
        wait_for_spinner_off()
        click(pagination_select, "pagination to increase list item count")
        explicit_wait(1)
        click(pagination_select_50, "50 to increase item count")
    except (TimeoutException, NoSuchElementException) as er:
        logger.info("Pagination Selection for ordered services page didn't work")


def click_on_change_owner(service_name):
    open_ordered_services_page()
    wait_for_spinner_off()
    search_service_name(service_name)
    click_action_service_instance()
    click_using_java_script(change_owner, "Change Owner button")
    wait_for_spinner_off()


def search_new_owner(new_owner):
    wait_for_spinner_off()
    type_value_and_enter(search_owner_transfer_control_name, new_owner, "owner instance name search")
    time.sleep(2)
    click_using_script_replace_value(select_owner, new_owner.strip(), "new owner")

def click_on_confirm():
    click_using_java_script(change_owner_confirm, "change owner confirm button")
    wait_for_spinner_off()
    check.is_in(mo_ui_test_data["change_owner_success_message"], get_element_text(notification_popup_message).strip())
    click_using_java_script(notification_popup_message_close_btn, "Notification close button")

def click_on_transfer_service(service_name):
    open_ordered_services_page()
    wait_for_spinner_off()
    search_service_name(service_name)
    click_action_service_instance()
    click_using_java_script(transfer_service_button, "transfer service button")


def search_new_team(new_team, transfer_notification):
    wait_for_spinner_off()
    type_value_and_enter(transfer_team_search, new_team, "team instance name search")
    click_using_script_replace_value(transfer_team, new_team, "transfer team")
    click_using_java_script(transfer_service_confirm_button, "transfer service button")
    if new_team == mo_ui_test_data["new_team"]:
        check.is_in(transfer_notification, get_element_text(notification_popup_message_resend).strip())
        click_using_java_script(notification_popup_message_close_btn, "Notification close button")
    else:
        check.is_in(transfer_notification, get_element_text(notification_popup_message_error).strip())


def click_on_transfers_tab(service_name):
    click_using_java_script(transfers_tab, "transfer  tab")
    search_transfer_service_name(service_name)
    wait_for_spinner_off()

def click_transfer_action(transfer_action):
    # click_action_service_instance()
    click_action_service_instance()
    click_using_script_replace_value(transfer_action_button, transfer_action, 'transfer action')

def transfer_accept():
    wait_for_spinner_off()
    click_using_java_script(transfer_accept_button, "transfer accept button")
    time.sleep(2)
    transfer_message = get_element_text(notification_popup_message).strip()
    order_id = transfer_message.split(".")[1].split(" ")[3]
    check.is_in(mo_ui_test_data["transfer_success_message"], transfer_message)
    return order_id

def transfer_cancel():
    click_using_java_script(transfer_cancel_button, "transfer cancel button")
    check.is_in(mo_ui_test_data["transfer_cancel_message"], get_element_text(notification_popup_message).strip())
    click_using_java_script(notification_popup_message_close_btn, "Notification close button")

def verify_transfers_service_details(service_name, transferor_name_input, transferee_name_input, transfer_status_input):
    open_ordered_services_page()
    wait_for_spinner_off()
    click_using_java_script(transfers_tab, "transfer  tab")
    click_using_java_script(completed_transfers, "completed transfers")
    wait_for_spinner_off()
    search_service_name(service_name)
    check.equal(get_element_text(transferor_name).strip(), transferor_name_input)
    check.equal(get_element_text(transferee_name).strip(), transferee_name_input)
    check.equal(get_element_text(transfer_status).strip(), transfer_status_input)


def click_on_completed_transfers(service_name):
    click_using_java_script(completed_transfers, "completed transfers")
    wait_for_spinner_off()
    search_transfer_service_name(service_name)
    wait_for_spinner_off()


def verify_resend_service(service_name, transfer_action):
    click_on_completed_transfers(service_name)
    click_action_service_instance()
    time.sleep(2)
    click_using_script_replace_value(transfer_action_button, transfer_action, 'transfer resend action')
    click_using_java_script(transfer_resend_button, "transfer resend accept button")
    check.is_in(mo_ui_test_data["transfer_cancel_message"], get_element_text(notification_popup_message_resend).strip())
    click_using_java_script(notification_popup_message_close_btn, "Notification close button")


def click_on_pending_transfer(service_name):
    open_ordered_services_page()
    click_using_java_script(transfers_tab, "transfer  tab")
    wait_for_spinner_off()
    click_using_java_script(pending_transfers, "pending transfer  tab")
    search_transfer_service_name(service_name)
    # search_service_name(service_name)
    wait_for_spinner_off()


def verify_deny_transfer_service(service_name, transfer_action):
    text_area_type_value(transfer_deny_reason_text_box, mo_ui_test_data["denyReason"], "transfer deny text box")
    click_using_java_script(transfer_deny_button, "transfer deny")
    check.is_in(mo_ui_test_data["transfer_cancel_message"], get_element_text(notification_popup_message_resend).strip())
    click_on_close_notification_button()
    time.sleep(2)
    click_on_completed_transfers(service_name)
    click_action_service_instance()
    click_using_script_replace_value(transfer_action_button, transfer_action, 'transfer resend action')
    check.is_in(mo_ui_test_data["denyReason"],
                get_element_text(deny_reason_validation).strip())
    click_using_java_script(deny_reason_ok, "click on deny reason ok")

def click_on_all_services():
    open_ordered_services_page()
    click_using_java_script(all_services_tab, "all services tab")


def click_on_all_patterns():
    open_ordered_services_page()
    click_using_java_script(all_patterns_tab, "all services tab")


def search_service_name_on_all_patterns_ordered_services(service_name, service_offering_names):
    # Wait to load the table for first time
    open_ordered_services_page()
    click_on_all_patterns()
    wait_for_spinner_off()
    wait_for_element_to_visible(ordered_service_pattern_table_row, "at least one Table Row")
    # Search the service
    # service_text = service_name.split("-")
    # service = logger.info("service: " + service_text[1])
    # type_value_and_enter(search_service_name_path, service_name, "Service instance name search")
    if is_element_present_replace_value(search_service_name_pattern, service_name):
        if is_element_present(first_SO, "First service offering"):
            service_offering_ui = get_elements_texts(pattern_service_offering_name_text)
            for value in service_offering_names:
                check.is_in(value, service_offering_ui, "Service Offering Name")
                # validate_pattern_details_ordered_services(value)
        else:
            click_using_script_replace_value(search_service_name_pattern, service_name, "Service name")
            wait_for_element_to_visible(first_SO, "First service offering")
            service_offering_ui = get_elements_texts(pattern_service_offering_name_text)
            for value in service_offering_names:
                check.is_in(value, service_offering_ui, "Service Offering Name")
                # validate_pattern_details_ordered_services(value)


def delete_pattern(service_name):
    open_ordered_services_page()
    click_on_all_patterns()
    wait_for_spinner_off()
    wait_for_element_to_visible(ordered_service_pattern_table_row, "at least one Table Row")
    click_using_script_replace_value(pattern_delete_icon, service_name, "Delete pattern button")
    click_using_java_script(understand_delete_service, "Confirm Delete")
    click_using_java_script(confirm_ok, "ok for Delete")
    delete_order_msg = get_element_text(delete_order_msg_txt)
    delete_order = str(delete_order_msg.split("[")[2]).split("]")[0].strip()
    logger.info("Delete Order no - " + delete_order)
    click_using_java_script(close_msg, "close delete success msg")
    return delete_order

def validate_pattern_details_ordered_services(service_name, is_editing=False,
                                              edit_addtl_params_key='Edit Additional Parameters',
                                              skip_total_calc=False):
    service_instances_ui = get_elements_texts(pattern_service_instance_name_text)
    for value in service_instances_ui:
        check.is_in(value, service_name, "Service Instance Name")
        click_using_java_script(view_pattern_details, "view Button")
    # Validations for Service configurations
    ui_labels = get_elements_texts(service_configurations_labels)
    ui_values = get_elements_texts(service_configurations_values)
    # Remove the label from the returned value, this because sometimes we have multiple values and
    # are separated in multiple html tags
    for index, label in enumerate(ui_labels):
        ui_values[index] = ui_values[index].replace(label, "")
    act_service_config_details = dict(zip(ui_labels, ui_values))
    if is_editing:
        addtnl_params_json_dic_data = merge_edit_additional_parameters(edit_addtl_params_key)
    else:
        addtnl_params_json_dic_data = get_data_object("Additional Parameters")
    for key, actual_value in act_service_config_details.items():
        expected_value = get_value(addtnl_params_json_dic_data["Additional Parameters"], key.replace(":", ""))
        if expected_value:
            # Validates if the expected value is a list of values (multiselect options) and format the values
            if type(expected_value) == list:
                expected_value, actual_value = format_detail_multiple_values(expected_value, actual_value)
            check.is_in(expected_value.lower(), actual_value.lower(), key)
    # Validations for Service Details Parameters
    act_service_details = dict(
        zip(get_elements_texts(service_details_labels), get_elements_texts(service_details_values)))
    check.is_in(service_name, act_service_details["Service Instance Name"], 'Service Instance Name')
    check.is_in(act_service_details["Service Offering Name"], get_data("bluePrintName"), 'Blueprint Name')
    check.is_in(act_service_details["Provider Name"], get_data("provider"), 'Provider')
    user = MO_USER
    if os.environ.get("Environment"):
        user = os.environ.get("kyndryl_user")
    check.is_in(act_service_details["Owner"], user, 'Owner')
    check.is_in(act_service_details["Team"], get_data("Team"), 'Team')
    check.is_in(act_service_details["Organization"], get_data("Organization"), 'Organization')
    check.is_in(get_data("Provider Account", get_data("Main Parameter"))["value"].replace(" ", ""),
                    act_service_details["Provider Account Name"], 'Provider Account')
    # Validations for Bill of Materials
    click(bill_of_material_tab, "Bill of Materials")
    act_estimated_cost = get_element_text(estimated_cost_txt)
    exp_estimated_cost = get_data("price")
    # Monthly Cost and One time cost calculation
    if not skip_total_calc:
        check.is_in(act_estimated_cost, exp_estimated_cost, 'Total Cost')
        click(more_link, "More Link")
        monthly_cost = sum_totals_by_locator(monthly_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
        one_time_cost = sum_totals_by_locator(one_time_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
        total_sum = sum_string_totals([monthly_cost, one_time_cost], exp_estimated_cost)
        check.is_in(act_estimated_cost, exp_estimated_cost, 'Total Cost')
        check.is_in(act_estimated_cost, total_sum, 'Monthly Cost and One Time Cost')
    close_details_window()