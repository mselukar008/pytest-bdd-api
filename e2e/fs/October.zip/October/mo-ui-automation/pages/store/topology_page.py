from pages.store.review_order_page import get_attribute_text
from helpers.mo_check import mo_check as check
from locators.store.topology_locator import *
from helpers.mo_element_operations import *
from sys import path
from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_json_utils import *
import datetime
from locators.store.catalog_management_locator import *
from pages.common.login_page import loader_off
from pages.store.navigation_page import *
from pages.store.catalog_page import *
from os.path import abspath
from helpers.mo_check import mo_check as check


def validate_title_text_on_topology_page():
    wait_for_spinner_off()
    explicit_wait(3)
    wait_for_element_to_visible(topology_title_css, "Topology Page Title")
    check.equal(get_element_text(topology_title_css), get_data("topologyTitleText"), 'Topology Page Title')


def validate_topology_page_with_no_filter():
    check.equal(get_element_text(topology_page_with_no_filter), get_data("topologyWithNoFilter"), 'Topology Page with no filter')


def click_on_topology_filter():
    click(filter_icon_css, "Topology Filter")
    wait_for_element_to_visible(filter_panel_css, "Edit Filter Option panel")


def click_on_first_clear_button():
    click_using_java_script(first_clear_button_xpath, "Reset button")


def click_on_load_tags():
    click_using_java_script(load_tags_button_css, "Load tags button")


def click_on_add_tags():
    click_using_java_script(add_tags_button_css, "Add tags button")


def click_on_clear_tag():
    click_using_java_script(clear_tag_css, "Clear tag")


def click_on_apply_button():
    click_using_java_script(apply_button_xpath, "Apply button")
    wait_for_spinner_off()


def click_on_close_button():
    click_using_java_script(close_button_xpath, "Close button")
    wait_for_spinner_off()


def validate_applied_filter_values():
    if is_element_present_replace_value(applied_filter_xpath, get_data("providerValue").lower()):
        provider = get_element_text_replace_value(applied_filter_xpath, get_data("providerValue").lower(), "Provider")
        check.is_in(provider, get_data("providerValue").lower(), "Provider")
    if is_element_present_replace_value(applied_filter_xpath, get_data("accountValue").lower()):
        account = get_element_text_replace_value(applied_filter_xpath, get_data("accountValue").lower(), "Account")
        check.is_in(account, get_data("accountValue").lower(), "Account")
    if is_element_present_replace_value(applied_filter_xpath, get_data("regionValue").lower()):
        region = get_element_text_replace_value(applied_filter_xpath, get_data("regionValue").lower(), "Region")
        check.is_in(region, get_data("regionValue").lower(), "Region")
    if is_element_present_replace_value(applied_filter_xpath, get_data("networkValue").lower()):
        network = get_element_text_replace_value(applied_filter_xpath, get_data("networkValue").lower(), "Network")
        check.is_in(network, get_data("networkValue").lower(), "Network")


def validate_no_filter():
    if check.equal(is_element_not_present(applied_filter_values_xpath, 'Filter value'), True):
        logger.info(f"Filter is not applied")
    else:
        logger.info(f"Filter is applied")


def validate_tag_in_filter(value):
    # validate tag in applied filter
    if is_element_present_replace_value(applied_filter_xpath, value):
        tag = get_element_text_replace_value(applied_filter_xpath, value, "Tag")
        check.is_in(tag, value, "Tag")


def validate_added_tag(key):
    # validate tag after clicking on add tag button
    is_element_present_replace_value(added_tag, key)
    check.is_in(get_element_text_replace_value(added_tag, key, 'applied tag'), key, "Applied tag")


def clear_provider_in_applied_filter():
    click_using_java_script(clear_provider_xpath, "Reset button")


def clear_value_in_applied_filter(value):
    wait_for_element_to_visible_with_replace_value(clear_value_in_filter_xpath, value, "clear value")
    click_with_replace_value(clear_value_in_filter_xpath, value, "clear value")


def select_tag_key_value(key, value):
    # select tag key and value, click on add tag and verify added tag values
    select_key_value_from_drop_down(tag_key_dropdown_xpath, key, "Choose the tag key")
    select_key_value_from_drop_down(tag_value_dropdown_xpath, value, "Choose the tag value")
    click_on_add_tags()
    validate_added_tag(key)


def validate_edited_filter_values():
    if is_element_present_replace_value(applied_filter_xpath, get_data("editRegionValue").lower()):
        network = get_element_text_replace_value(applied_filter_xpath, get_data("editRegionValue").lower(), "Network")
        check.is_in(network, get_data("editRegionValue").lower(), "edited Region")
    if is_element_present_replace_value(applied_filter_xpath, get_data("editNetworkValue").lower()):
        network = get_element_text_replace_value(applied_filter_xpath, get_data("editNetworkValue").lower(), "Network")
        check.is_in(network, get_data("editNetworkValue").lower(), "edited Network")


def click_again_if_not_clicked(dropdown, dropdown_values, options, value):
    click_using_java_script(dropdown, "Choose the tag Key/value")
    explicit_wait(3)
    if is_element_present(dropdown_values, "dropdown values"):
        click_using_script_replace_value(options, value, "tag Key/value")
        logger.info(f"Selected {value} from dropdown")
    else:
        click_using_java_script(dropdown, "Choose the tag key")
        explicit_wait(3)
        click_using_script_replace_value(options, value, "tag Key/value")
        logger.info(f"Selected {value} from dropdown")
