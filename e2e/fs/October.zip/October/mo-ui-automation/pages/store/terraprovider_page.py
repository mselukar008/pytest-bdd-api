from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_json_utils import *
from helpers.mo_page_operations import refresh_current_page, file_compress_zip
from locators.store.terraprovider_locator import *
from helpers.mo_check import mo_check as check
from pages.store.catalog_management_page import import_service_via_file
from pages.store.catalog_page import fill_additional_parameter_details
from pages.store.provider_account_page import create_pagerduty_asset_account
from pages.store.navigation_page import open_approve_orders_page, open_terraform_provider_management_page
from tests.common_test import get_random_int

terraform_data_path = os.path.join(test_data_path, "terraprovider", "terraform_provider_home.json")
output_zipfile_path = os.path.join(test_data_path, "terraprovider", "pagerduty_service_files",
                                   "pagerduty_business_service.zip")


def verify_default_providers_on_home_page():
    providers_count = get_elements_count(all_provider_tiles)
    check.greater_equal(providers_count, int(get_data("providersCount")), "Default providers count")
    actual_providers_list = get_elements_texts(all_provider_names_text)
    expected_providers_list = get_data("defaultProvidersList")
    for expected in expected_providers_list:
        if expected in actual_providers_list:
            logger.info(expected + " default provider is present")


def click_add_provider_btn():
    if is_element_present(add_provider_btn, "Add Provider Button"):
        click_using_java_script(add_provider_btn, "Add Provider Button")


def verify_view_and_edit_option_for_provider(provider):
    click_with_replace_value(provider_menu_icon, provider, "Provider Menu")
    option = check.is_true(is_element_present_replace_value(provider_menu_options, get_data("viewEditOption")),
                           "View and Edit")
    if option:
        click_with_replace_value(provider_menu_options, get_data("viewEditOption"), "View and Edit")
        wait_for_spinner_off()
        check.equal(get_element_text(provider_page_title), provider, "Provider title")
        click_with_replace_value(provider_page_btn, get_data("backBtn"), "Back")
        wait_for_spinner_off()


def verify_deactivated_provider_options():
    providers = get_elements_texts(all_provider_names_text)
    expected_options_list = get_data("deactivatedProviderOptions")
    for num, name in enumerate(providers, start=1):
        activate_btn = (By.XPATH, f"//span[normalize-space()='{name}']/ancestor::div/div[@class='active-btn']//button")
        menu_icon = (By.XPATH, f"(//button[@class='bx--overflow-menu'])[{num}]")
        if is_element_present(activate_btn, "Activate button"):
            scroll_element_into_view(menu_icon)
            click(menu_icon, "Provider Menu")
            actual_options_list = get_elements_texts(provider_menu_options_list)
            check.equal(actual_options_list, expected_options_list, "Default providers list")
            click(opened_provider_menu_icon, "Closed Menu")
            explicit_wait(3)
        else:
            logger.info(name + " Provider is activated")


def click_view_and_edit_provider(provider):
    click_with_replace_value(provider_menu_icon, provider, "Menu")
    click_with_replace_value(provider_menu_options, get_data("viewEditOption"), "View and Edit")
    wait_for_spinner_off()


def edit_provider_name(name):
    click(edit_provider_details_btn, "Edit provider details")
    type_value(provider_name_textbox, name, "Provider Name")
    click_with_replace_value(provider_page_btn, get_data("saveBtn"), "Save")
    wait_for_spinner_off()


def verify_activate_for_deactivated_provider():
    providers = get_elements_texts(all_provider_names_text)
    for num, name in enumerate(providers, start=1):
        activate_btn = (By.XPATH, f"//span[normalize-space()='{name}']/ancestor::div/div[@class='active-btn']//button")
        if is_element_present(activate_btn, "Activate button"):
            scroll_element_into_view(activate_btn)
            click(activate_btn, "Activate")
            check.equal(get_element_text(activate_confirmation_text), get_data("activateConfirmMsg"), "Confirmation")
            click_with_replace_value(close_ops_confirmation_icon, "activate", "Close icon")
            break
        else:
            logger.info(name + " Provider is activated")


def verify_delete_for_deactivated_provider():
    providers = get_elements_texts(all_provider_names_text)
    for num, name in enumerate(providers, start=1):
        activate_btn = (By.XPATH, f"//span[normalize-space()='{name}']/ancestor::div/div[@class='active-btn']//button")
        menu_icon = (By.XPATH, f"(//button[@class='bx--overflow-menu'])[{num}]")
        if is_element_present(activate_btn, "Activate button"):
            scroll_element_into_view(menu_icon)
            click(menu_icon, "Menu")
            click_with_replace_value(provider_menu_options, get_data("viewEditOption"), "View and Edit")
            wait_for_spinner_off()
            check.is_true(is_element_present_replace_value(provider_page_btn, get_data("deleteBtn")), "Delete")
            click_with_replace_value(provider_page_btn, get_data("deleteBtn"), "Delete")
            check.equal(get_element_text(delete_confirmation_text), get_data("deleteConfirmMsg"), "Confirmation")
            click_with_replace_value(close_ops_confirmation_icon, "delete", "Close icon")
            click(terraform_provider_linkText, "Terraform link")
            break
        else:
            logger.info(name + " Provider is activated")


def verify_activated_provider_options():
    providers = get_elements_texts(all_provider_names_text)
    expected_options_list = get_data("activatedProviderOptions")
    for num, name in enumerate(providers, start=1):
        activate_btn = (By.XPATH, f"//span[normalize-space()='{name}']/ancestor::div/div[@class='active-btn']//button")
        menu_icon = (By.XPATH, f"(//button[@class='bx--overflow-menu'])[{num}]")
        if is_element_not_present(activate_btn, "Activate button"):
            scroll_element_into_view(menu_icon)
            click(menu_icon, "Provider Menu")
            actual_options_list = get_elements_texts(provider_menu_options_list)
            check.equal(actual_options_list, expected_options_list, "Default providers list")
            click(opened_provider_menu_icon, "Closed Menu")
            explicit_wait(3)
        else:
            logger.info(name + " Provider is de-activated")


def verify_disabled_fields_for_activated_provider():
    providers = get_elements_texts(all_provider_names_text)
    for num, name in enumerate(providers, start=1):
        activate_btn = (By.XPATH, f"//span[normalize-space()='{name}']/ancestor::div/div[@class='active-btn']//button")
        menu_icon = (By.XPATH, f"(//button[@class='bx--overflow-menu'])[{num}]")
        if is_element_not_present(activate_btn, "Activate button"):
            scroll_element_into_view(menu_icon)
            click(menu_icon, "Provider Menu")
            click_with_replace_value(provider_menu_options, get_data("viewEditOption"), "View and Edit")
            wait_for_spinner_off()
            click(edit_provider_details_btn, "Edit provider details")
            check.is_false(is_element_enable(provider_name_textbox, "Provider Name"), "Provider Name")
            click_with_replace_value(provider_page_btn, get_data("cancelBtn"), "Cancel")
            check.is_false(is_element_enable(edit_connection_params_btn, "Edit Connection Parameters"),
                           "Edit Connection Parameters")
            check.is_false(is_element_enable(edit_credential_params_btn, "Edit Credential Parameters"),
                           "Edit Credential Parameters")
            click(terraform_provider_linkText, "Terraform link")
            break
        else:
            logger.info(name + " Provider is de-activated")


def verify_deactivate_for_activated_provider():
    providers = get_elements_texts(all_provider_names_text)
    for num, name in enumerate(providers, start=1):
        activate_btn = (By.XPATH, f"//span[normalize-space()='{name}']/ancestor::div/div[@class='active-btn']//button")
        menu_icon = (By.XPATH, f"(//button[@class='bx--overflow-menu'])[{num}]")
        if is_element_not_present(activate_btn, "Activate button"):
            if name == "Digital Ocean":
                continue
            scroll_element_into_view(menu_icon)
            click(menu_icon, "Menu")
            click_with_replace_value(provider_menu_options, get_data("viewEditOption"), "View and Edit")
            wait_for_spinner_off()
            check.is_true(is_element_present_replace_value(provider_page_btn, get_data("deactivateBtn")), "De-activate")
            click_with_replace_value(provider_page_btn, get_data("deactivateBtn"), "De-activate")
            check.equal(get_element_text(delete_confirmation_text), get_data("deactivateConfirmMsg"), "Confirmation")
            click_with_replace_value(close_ops_confirmation_icon, "deactivate ", "Close icon")
            click(terraform_provider_linkText, "Terraform link")
            break
        else:
            logger.info(name + " Provider is de-activated")


def click_save_btn():
    click(save_btn, "Save btn")
    if is_element_present(proceed_btn, "Proceed btn"):
        click(proceed_btn, "Proceed btn")
    wait_for_spinner_off()


def click_activate_provider(provider_name):
    click_with_replace_value(active_provider, provider_name, "Activate Button")
    click(proceed_btn, "Proceed btn")
    refresh_current_page()
    open_terraform_provider_management_page()


def click_de_activate_provider(provider):
    scroll_element_into_view_with_replace_value(provider_menu_icon, provider, "AD menu")
    click_using_script_replace_value(provider_menu_icon, provider, "AD menu")
    click_using_script_replace_value(provider_menu_options, get_data("deactivateBtn"), "De-Activate")
    click(pop_up_btn, "De-activate pop up")
    wait_for_spinner_off()


def de_activate_provider_from_details_page(provider):
    click_provider_name(provider)
    wait_for_spinner_off()
    wait_for_deactivate_btn_enable(provider)
    click_with_replace_value(provider_page_btn, get_data("deactivateBtn"), "De-activate")
    check.equal(get_element_text(delete_confirmation_text), get_data("deactivateConfirmMsg"), "Confirmation")
    click_with_replace_value(pop_up_confirmation, "De-activate", "De-activate button")
    click(provider_management_link, "terraform page")
    explicit_wait(3)


def verify_edit_provider_name_disabled(provider):
    open_approve_orders_page()
    open_terraform_provider_management_page()
    click_provider_name(provider)
    click(edit_provider_details_btn, "Edit provider details")
    wait_for_spinner_off()
    check.is_true(is_element_present(provider_name_textbox_disabled, "Disabled provider name Text Field "))
    click(provider_management_link, "terraform page")


def click_provider_name(provider):
    explicit_wait(2)
    if is_element_present_replace_value(provider_name, provider):
        click_using_script_replace_value(provider_name, provider, "Provider Name")


def delete_provider_from_details_page(provider):
    de_activate_provider_from_details_page(provider)
    click_provider_name(provider)
    check.is_true(is_element_present_replace_value(provider_page_btn, get_data("deleteBtn")), "Delete")
    click_with_replace_value(provider_page_btn, get_data("deleteBtn"), "Delete")
    check.equal(get_element_text(delete_confirmation_text), get_data("deleteConfirmMsg"), "Confirmation")
    click_with_replace_value(pop_up_confirmation, "Delete", "Delete button")


def restore_provide_name(provider):
    click(edit_provider_details_btn, "Edit provider details")
    type_value(provider_name_textbox, provider, "Provider Name")
    click_save_btn()
    check.is_true(is_element_present_replace_value(provider_name_details_page, provider),
                  "provider name changed to original")


def verify_provider_name_editable(provider, is_delete=True):
    click_provider_name(provider)
    edit_provider = get_random_int('Edit_Azurerm')
    click(edit_provider_details_btn, "Edit provider details")
    type_value(provider_name_textbox, edit_provider, "Provider Name")
    click_save_btn()
    check.is_true(is_element_present_replace_value(provider_name_details_page, edit_provider), "Edited provider name")
    if is_delete:
        delete_provider(provider)
    else:
        restore_provide_name(provider)


def edit_provider_description(provider, edit_desc=None):
    desc_value = ""
    click_provider_name(provider)
    wait_for_spinner_off()
    scroll_element_into_view(edit_provider_details_btn, "Edit provider details")
    if edit_desc is None:
        desc_value = get_desc_text()
        edit_desc = get_random_int(desc_value)
        wait_for_deactivate_btn_enable(provider)
        click_using_java_script(edit_provider_details_btn, "Edit provider details")
        type_value(edit_provider_desc_textarea, edit_desc, "Provider Description")
    else:
        click(edit_provider_details_btn, "Edit provider details")
        type_value(edit_provider_desc_textarea, edit_desc, "Provider Description")
    click_save_btn()
    return desc_value, edit_desc


def get_desc_text():
    return get_attribute_value(desc_text, 'title')


def verify_description_editable(provider, is_delete=True):
    desc_value, edit_desc = edit_provider_description(provider)
    check.is_true(is_element_present_replace_value(provider_desc_details_page, edit_desc),
                  "Edited provider description")
    if is_delete:
        delete_provider(provider)
    else:
        edit_provider_description(provider, desc_value)


def activate_provider(provider):
    explicit_wait(2)
    if is_element_present_replace_value(provider_updating_btn, provider):
        open_approve_orders_page()
        open_terraform_provider_management_page()
    if is_element_present_replace_value(provider_activate_btn, provider):
        scroll_element_into_view_with_replace_value(provider_menu_icon, provider)
        click_with_replace_value(provider_activate_btn, provider, "Activate")
        click(proceed_btn, "Proceed")
        wait_for_spinner_off()
        check.equal(get_element_text_replace_value(provider_activate_text, provider, "Provider status"),
                    get_data("updatingText"), "Provider status")
        wait_for_spinner_off()
        open_approve_orders_page()
        open_terraform_provider_management_page()
        check.is_true(is_element_not_present_replace_value(provider_activate_btn, provider, "Activate"), "Activate")
    else:
        logger.info(f"Provider{provider} already activated")


def deactivate_provider(provider):
    explicit_wait(2)
    if is_element_present_replace_value(provider_activate_btn, provider):
        logger.info(provider + " Provider is already de-activated")
    if is_element_present_replace_value(provider_updating_btn, provider):
        open_approve_orders_page()
        open_terraform_provider_management_page()
    else:
        scroll_element_into_view_with_replace_value(provider_menu_icon, provider)
        click_with_replace_value(provider_menu_icon, provider, "Menu")
        click_with_replace_value(provider_menu_options, get_data("deactivateBtn"), "De-activate")
        click_with_replace_value(provider_page_btn, get_data("deactivateBtn"), "De-activate")
        wait_for_spinner_off()
        check.equal(get_element_text_replace_value(provider_activate_text, provider, "Provider status"),
                    get_data("updatingText"), "Provider status")
        driver.refresh()
        wait_for_spinner_off()
        check.is_true(is_element_present_replace_value(provider_activate_btn, provider), "Activate button")


def delete_provider_from_home(provider):
    if is_element_present_replace_value(provider_activate_btn, provider):
        scroll_element_into_view_with_replace_value(provider_menu_icon, provider)
        click_with_replace_value(provider_menu_icon, provider, "Menu")
        if is_element_present_replace_value(provider_menu_options, get_data("deleteBtn")):
            click_with_replace_value(provider_menu_options, get_data("deleteBtn"), "Delete")
            click_with_replace_value(provider_page_btn, get_data("deleteBtn"), "Delete")
            wait_for_spinner_off()
            check.is_false(is_element_present_replace_value(provider_menu_icon, provider), "Menu Icon")
        else:
            logger.info(provider + " Provider Delete button is not present")
    else:
        logger.info(provider + " Provider is already de-activated")


def menu_option_based_on_provider(provider, option):
    click_on_provider_menu_button(provider)
    click_on_menu_options_list(option)


def click_on_provider_menu_button(provider):
    wait_for_element_to_visible_with_replace_value(provider_menu_icon, provider, "Provider name")
    click_using_script_replace_value(provider_menu_icon, provider, "Provider name")


def click_on_menu_options_list(option):
    if option == "View and Edit":
        wait_for_element_to_visible_with_replace_value(provider_menu_options, "View and Edit", "View and Edit option")
        click_using_script_replace_value(provider_menu_options, "View and Edit", "View and Edit option")
        wait_for_spinner_off()
    elif option == "Activate":
        wait_for_element_to_visible_with_replace_value(provider_menu_options, "Activate", "Activate option")
        click_using_script_replace_value(provider_menu_options, "Activate", "Activate option")
        check.equal(get_element_text(confirmation_message), get_data("activateConfirmMsg"), "Confirm activate")
        click(proceed_button, "Proceed Button")
        refresh_current_page()
    elif option == "De-activate":
        wait_for_element_to_visible_with_replace_value(provider_menu_options, "De-activate", "De-activate option")
        click_using_script_replace_value(provider_menu_options, "De-activate", "De-activate option")
        check.equal(get_element_text(confirmation_message), get_data("deactivateConfirmMsg"), "Confirm deactivate")
        click(deactivate_button, "Confirm De-activate")
        refresh_current_page()
    elif option == "Delete":
        wait_for_element_to_visible_with_replace_value(provider_menu_options, "Delete", "Delete option")
        click_using_script_replace_value(provider_menu_options, "Delete", "Delete option")
        check.equal(get_element_text(confirmation_message), get_data("deleteConfirmMsg"), "Confirm delete")
        click(delete_button, "Confirm Delete")


def verify_message_on_deactivating_provider_with_existing_orders(provider):
    set_data_path(terraform_data_path)
    scroll_element_into_view_with_replace_value(provider_menu_icon, provider)
    click_with_replace_value(provider_menu_icon, provider, "Menu")
    click_with_replace_value(provider_menu_options, get_data("deactivateBtn"), "De-activate")
    click_with_replace_value(provider_page_btn, get_data("deactivateBtn"), "De-activate")
    wait_for_spinner_off()
    check.is_in(get_element_text(notification_msg_text), get_data("deactivateFailedMsg"), "Failed message")


def edit_provider_repo_link(provider, edit_repo=None):
    click_provider_name(provider)
    repo_link = ""
    wait_for_spinner_off()
    scroll_element_into_view(edit_provider_details_btn, "Edit provider details")
    click(edit_provider_details_btn, "Edit provider details")
    if edit_repo is None:
        repo_link = get_repo_link()
        edit_repo = get_random_int(repo_link)
        type_value(repo_url_textbox, edit_repo, "Provider Repo Link")
    else:
        type_value(repo_url_textbox, edit_repo, "Provider Repo Link")
    click_save_btn()
    return repo_link, edit_repo


def get_repo_link():
    return get_attribute_value(repo_url_textbox, 'title')


def verify_repo_link_editable(provider, is_delete=True):
    repo_link, edit_repo_link = edit_provider_repo_link(provider)
    click(edit_provider_details_btn, "Edit provider details")
    check.equal(get_attribute_value(repo_url_textbox, 'title'), edit_repo_link, "Edited Repo Link")
    click_save_btn()
    click(provider_management_link, "terraform page")
    if is_delete:
        delete_provider(provider)
    else:
        edit_provider_repo_link(provider, repo_link)


def copy_provider_code(provider):
    scroll_element_into_view_with_replace_value(provider_code_value, provider)
    code = get_element_text_replace_value(provider_code_value, provider, "Provider code")
    return str(code).strip()


def update_provider_service_file(metadata_path, main_key, name_key, name_value, code_key, code_value):
    update_json_dict_in_list_single_value(metadata_path, main_key, name_key, name_value)
    update_json_dict_in_list_single_value(metadata_path, main_key, code_key, code_value)


def add_provider_if_not_present(provider, account_name=None, metadata_path=None, main_key=None, name_key=None,
                                name_value=None, code_key=None, input_files=None, output_file=None,
                                provider_data_path=None):
    if is_element_present_replace_value(provider_title, provider):
        logger.info(provider + " is already onboarded")
        activate_provider(provider)
    else:
        click_add_provider_btn()
        set_data_path(provider_data_path)
        fill_additional_parameter_details(get_data("Add Provider Details"))
        click_save_btn()
        activate_provider(provider)
        code_value = copy_provider_code(provider)
        create_pagerduty_asset_account(account_name)
        update_provider_service_file(metadata_path, main_key, name_key, name_value, code_key, code_value)
        file_compress_zip(input_files, output_file, output_zipfile_path)
        import_service_via_file(output_zipfile_path)


def delete_provider(provider):
    click_provider_name(provider)
    if is_element_present_replace_value(provider_page_btn, get_data("deactivateBtn")):
        delete_provider_from_details_page(provider)
    else:
        check.is_true(is_element_present_replace_value(provider_page_btn, get_data("deleteBtn")), "Delete")
        click_with_replace_value(provider_page_btn, get_data("deleteBtn"), "Delete")
        check.equal(get_element_text(delete_confirmation_text), get_data("deleteConfirmMsg"), "Confirmation")
        click_with_replace_value(pop_up_confirmation, "Delete", "Close icon")


def wait_for_deactivate_btn_enable(provider):
    if is_element_present(disable_deactivate_btn, "De-activate Btn"):
        open_approve_orders_page()
        open_terraform_provider_management_page()
        click_provider_name(provider)


def delete_all_created_provider():
    providers = get_elements_texts(all_providers)
    logger.info(providers)
    for provider in providers:
        if "Azurerm" in provider or "Edit" in provider:
            logger.info(provider)
            delete_provider(provider)
