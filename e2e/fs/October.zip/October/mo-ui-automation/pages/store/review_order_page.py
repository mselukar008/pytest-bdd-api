import re
from helpers.mo_check import mo_check as check
from pages.store.mo_store_utils import *
from pages.store.catalog_page import *
from locators.store.review_order_locator import *


# The function validates main and additional parameters details on review order page against test data parameters
def verify_review_order(is_editing=False, edit_main_params_key='Edit Main Parameter', edit_addtl_params_key='Edit Additional Parameters'):
    expand_more_links()
    json_value = "value"
    main_param_ui_data = dict(
        zip(get_elements_texts(main_parameter_path), get_elements_texts(main_parameter_path_value)))
    # Main Parameters Validations
    if is_editing:
        main_param_json_dic_data = merge_edit_main_parameters(edit_main_params_key)
    else:
        main_param_json_dic_data = get_data("Main Parameters", get_data("Main Parameter"))
    for key, value in main_param_ui_data.items():
        if get_json_data_key(key, main_param_json_dic_data) is not None:
            actual_data = get_data(json_value, get_json_data_key(key, main_param_json_dic_data))
            if actual_data == "NONE" and is_editing is False:
                actual_data = convert_string(actual_data)
            check.is_in(actual_data, value, key)

    additional_params_titles = get_elements_texts(additional_parameter_path)
    # Filter for break line in case a tooltip is present
    additional_params_values = [value.split('\n')[0] for value in get_elements_texts(additional_path_value)]
    ui_addtnl_params_data = dict(zip(additional_params_titles, additional_params_values))
    # Additional Parameters Validations
    if is_editing:
        addtnl_json_dic_data = merge_edit_additional_parameters(edit_addtl_params_key)
    else:
        addtnl_json_dic_data = get_data_object("Additional Parameters")
    for key, data in addtnl_json_dic_data["Additional Parameters"].items():
        for param, param_obj in data.items():
            # Handling for Empty json objects in data file
            if len(param_obj) > 0:
                exp_label = param
                # Validation to skip some controls that are deleted in the edit -> send deleted_in_edit key in true
                # inside the parameter
                if is_editing and param_obj.get('deleted_in_edit'):
                    continue
                exp_label_value = param_obj["value"]
                # Validation to skip some controls -> send skip_value key in true inside the parameter
                if param_obj.get('skip_value'):
                    continue
                actual_label_value = ui_addtnl_params_data.get(exp_label)
                if actual_label_value:
                    # Validates if the expected value is a list of values (multiselect options) and format the values
                    if type(exp_label_value) == list:
                        exp_label_value, actual_label_value = format_detail_multiple_values(exp_label_value,
                                                                                            actual_label_value)
                    # Validates if the label is present more than one time, in JSON the key must be eg. "key[0]":
                    # "value" in the same step object
                    actual_label_value = check_repeated_label_values(exp_label, exp_label_value, actual_label_value,
                                                                     additional_params_titles, additional_params_values)
                    # Validates the value in case the title exists more than one time in different step objects
                    if additional_params_titles.count(param) > 1:
                        for idx, title in enumerate(additional_params_titles):
                            if title == param and additional_params_values[idx] in exp_label_value:
                                actual_label_value = additional_params_values[idx]
                                break
                    check.is_in(actual_label_value.lower(), exp_label_value.lower(), exp_label)


# Verify the version in review order page
def verify_review_order_version(version):
    check.is_in(version, get_element_text(review_version_txt), 'Version')


def expand_more_links():
    if check_element_exists(review_more_link):
        click_multiple(review_more_link, 'more links')


# Function returns the value on the review page using field name passed
def get_main_params_value_using_field_name(field_name):
    main_param_value = get_element_text_replace_value(main_params_value_using_field_name, field_name, field_name)
    logger.info(f"Review page main parameter value for {field_name} is {main_param_value}")
    return main_param_value


# Function converts "NONE" to "!none!"
def convert_string(actual_string):
    return ''.join(("!", actual_string, "!")).lower()


def click_submit_order():
    click(submit_order_btn, "Submit Order button")
    wait_for_spinner_off()


def click_add_to_cart():
    click(add_to_cart_btn, "Add to Cart button")
    wait_for_spinner_off()


def click_cancel_service_btn():
    click_using_java_script(cancel_btn_path, "Cancel Button")
    click_using_java_script(confirm_yes_btn, "confirmation Yes Button")
    wait_for_spinner_off()


# Check if the alert message is present with text
def alert_message_present(message_text):
    assert is_element_present_replace_value(alert_message_txt, message_text)


# Function returns order id after submitting successfully
def get_order_id():
    # Increasing timeout to run Edit flows properly
    order_id = get_element_text(order_number_text,10)
    logger.info("Order number: " + order_id)
    return order_id.strip()


# Function validates Total cost and submitted by username on submit pop-up
@exceptions_decorator
def validate_order_details_on_submit():
    check.equal(get_element_text(total_estimated_cost_text).strip(), get_data("TotalCost"), 'Total Cost')
    user = MO_USER
    if os.environ.get("Environment"):
        user = os.environ.get("kyndryl_user")
    check.is_in(get_element_text(submitted_by_username).strip(), user, 'Submitted By')


def click_on_goto_service_catalog_btn():
    wait_before_click(goto_service_catalog, "Go to Service Catalog button")


# The function returns estimated price of service based on configuration from review order page
def get_estimated_price_review_order():
    exp_estimated_price = get_element_text(estimated_cost_text)
    logger.info("Estimated Cost on Review order page is " + exp_estimated_price)
    return exp_estimated_price


# The function validates pricing for each service component(price break up as per components) on review order page (
# pricing Table on right side)
def validate_bom_review_order_page(pricing_key="Pricing"):
    component_names_list = get_elements_texts(component_name_txt)
    component_prices_list = get_elements_texts(component_price_txt)
    comp_pricing_ui_data = dict(zip(component_names_list, component_prices_list))
    pricing_json_dic_data = get_data_object(pricing_key, None)
    for exp_key, exp_value in pricing_json_dic_data[pricing_key].items():
        actual_pricing = comp_pricing_ui_data.get(exp_key)
        regex_exp = re.compile(r'\[[0-9]+\]')
        # Validates if the component is present more than one time, in JSON the key must be eg. "key[0]": "value"
        if actual_pricing is None and regex_exp.search(exp_key):
            aux_exp_key = re.sub(regex_exp, '', exp_key)
            for idx, name in enumerate(component_names_list):
                if name == aux_exp_key and exp_value == component_prices_list[idx]:
                    actual_pricing = component_prices_list[idx]
                    break
        if actual_pricing:
            check.equal(actual_pricing, exp_value, exp_key)


def get_attribute_text(field_name):
    scroll_element_into_view_with_replace_value(attribute_xpath, field_name)
    attribute = get_element_text_replace_value(attribute_xpath, field_name, field_name)
    logger.info(f"Review page edited attribute is {attribute}")
    return attribute


def click_add_to_quote():
    click(add_to_quote_btn, "Add to Quote")
    wait_for_spinner_off()


def click_save():
    click(save_btn, "Save")
    wait_for_spinner_off()


# The function returns total one time cost of service based on configuration from review order page
def get_total_one_time_cost_review_order():
    total_one_time_cost = get_element_text(total_one_time_cost_text)
    logger.info("Estimated Cost on Review order page is " + total_one_time_cost)
    return total_one_time_cost


def get_estimated_price_review_order_pattern():
    exp_estimated_price = get_element_text(estimated_cost_pattern)
    logger.info("Estimated Cost on Review order page is " + exp_estimated_price)
    return exp_estimated_price
