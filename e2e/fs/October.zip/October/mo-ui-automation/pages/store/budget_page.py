
import re
from helpers.mo_element_operations import *
from helpers.mo_element_validation import is_element_not_present, is_element_enable
from helpers.mo_json_utils import dict_merge, get_data, get_data_object, get_value
from locators.store.budget_page_locator import *
from pages.store.mo_store_utils import format_detail_multiple_values, get_filtered_data
from helpers.mo_check import mo_check as check
from tests.common_test import logout_and_login
from ui_config import budgetary_data
import random

DEFAULT_BUDGET_UNIT_KEY = "Budgetary Unit"
DEFAULT_EDIT_BUDGET_UNIT_KEY = "Edit Budgetary Unit"
DEFAULT_BUDGET_KEY = "Budget"
DEFAULT_EDIT_BUDGET_KEY = "Edit Budget"
DEFAULT_EDIT_BUDGET_ONE_BY_ONE_KEY = "Edit Budget One By One"
DEFAULT_EDIT_BUDGET_UNIT_ONE_BY_ONE_KEY = "Edit Budget Unit One By One"
DEFAULT_BUDGET_SET_KEY = "Budget_set"


def click_add_new_budget_unit():
    click_using_java_script(add_new_budget_unit_btn, 'Budgetary Unit Button')


def budget_fill_parameters(data_key):
    budget_data = get_data(data_key)
    for key, data in budget_data.items():
        get_filtered_data(data, key)


def click_save_budget_unit():
    click(save_n_close_budget_unit_btn, 'Save & Close Budget Unit Button')


# Click on Save and Define Budgets button
def click_save_bu_n_define_budgets_btn():
    click(save_bu_n_define_budgets_btn, 'Save and Define budgets button')


# Click on Save Define Budgets button
def click_save_define_budgets_btn():
    click(save_define_budgets_btn, 'Save Define budgets button')


# Set Total budget amount
def set_total_budget_amount(total_budget_amt):
    wait_for_element_to_visible(total_budget_amount_textbox, "Total budget amount textbox")
    type_value(total_budget_amount_textbox, total_budget_amt, "Total budget amount textbox")


# Validate equal distribution for given total budget amount
def validate_budget_amount_even_distribution(total_budget_amount):
    budget_amt = 0
    attr_values = get_elements_attribute(budget_amounts_for_period, "title")
    for value in attr_values:
        budget_amt = int(value) + budget_amt
    if budget_amt == int(total_budget_amount):
        logger.info("Total Budget Amount is distributed evenly.")
        return True
    else:
        logger.info \
            (f"Total Budget Amount is not distributed evenly. Total Budget Amount : {total_budget_amount} | Sum of all Period Budget Amount : {budget_amt}")
        return False


# Create new budgetary unit and go to define budget set form page
def add_new_budgetary_unit_and_goto_define_budgets(budget_unit_data_key=DEFAULT_BUDGET_UNIT_KEY):
    click_add_new_budget_unit()
    wait_for_loaders_budgetary_unit()
    budget_fill_parameters(budget_unit_data_key)
    click_save_bu_n_define_budgets_btn()
    check.is_in(get_element_text(budget_success_modal_txt), budgetary_data['addedBudgetUnitMsg'], 'Budget Unit Added Success Msg')


# Create budget set and validate success message
def define_budget_set_in_bu(total_budget_amt, budget_key=DEFAULT_BUDGET_KEY):
    set_total_budget_amount(total_budget_amt)
    check.is_true(validate_budget_amount_even_distribution(total_budget_amt))
    budget_fill_parameters(budget_key)
    click_save_define_budgets_btn()
    wait_for_element_to_visible(budget_inline_msg_txt, "Success message")
    check.is_in(get_element_text(budget_inline_msg_txt), budgetary_data['budgetaryUnitAndBudgetSaveSuccessMsg'], 'Saved Budgetary unit and Budgets Msg')
    explicit_wait(2)


def add_new_budget_unit(budget_data_key=DEFAULT_BUDGET_UNIT_KEY):
    click_add_new_budget_unit()
    # wait_for_loaders_budgetary_unit()
    budget_fill_parameters(budget_data_key)
    click_save_budget_unit()
    # check.is_in(get_element_text(budget_success_notification_msg), budgetary_data['addedBudgetUnitMsg'], 'Budget Unit Added Success Msg')
    # try:
    #     click(budget_toast_close_icon, 'Toast close button')
    # except :
    #     logger.info("Exception while closing toast notification")
    explicit_wait(3)


def edit_budget_unit(edit_budget_data_key=DEFAULT_EDIT_BUDGET_UNIT_KEY):
    click_edit_budget_unit()
    wait_for_loaders_budgetary_unit()
    budget_fill_parameters(edit_budget_data_key)
    click_update_budget_unit()
    check.is_in(get_element_text(budget_success_modal_txt), budgetary_data['editedBudgetUnitMsg'], 'Budget Unit Edited Success Msg')
    click(budget_toast_close_icon, 'Toast close button')

    
def click_edit_budget_unit():
    click(budget_unit_edit_btn, 'Edit Budget Unit Button')


def click_update_budget_unit():
    click(budget_unit_update_btn, 'Update Budget Unit Button')


def close_budget_slider():
    try:
        click_using_java_script(budget_unit_slider_close_btn, 'Slider Close Button')
        explicit_wait(2)
    except:
        explicit_wait(1)


def search_budget_unit(budget_unit_name):
    explicit_wait(2)
    click(budget_unit_table_open_search_btn, 'Open Search Button')
    # Due the defect CS-3623, this is temporary solution 
    # explicit_wait(10)
    # wait_for_element_to_invisible(budget_table_loader, 'Budget Table Loader')
    # wait_for_element_to_invisible(first_empty_cell, "Empty cell value")
    if is_element_enable(budget_unit_table_search, 'Budget Unit Table Search'):
        clear_input_field_entry(budget_unit_table_search)
        # click(budget_unit_table_open_search_btn, 'Open Search Button')
    else:
        click(budget_unit_table_open_search_btn, 'Open Search Button')
    type_value_and_enter(budget_unit_table_search, budget_unit_name, 'Budget Unit Table Search')
    wait_for_element_to_invisible(first_empty_cell, "Empty cell value")
    if get_elements_count(budget_unit_table_no_data_text) > 0:
        logger.info("No Budgetary Units found in the table")
        return False
    else:
        logger.info("One or more results found in the table")
        wait_for_element_to_visible_with_replace_value(budget_unit_table_first_row_col_txt, budget_unit_name, 'Budget Table Column')
        return True


def select_budget_unit_table_option(option):
    click(budget_unit_table_options_btn, 'Budget Unit Table Options Button')
    click_with_replace_value(budget_unit_table_option_btn, option, 'Budget Unit Table View details Button')


def open_budget_unit_details_slider():
    select_budget_unit_table_option('View Details')
    wait_for_budget_spinner_off()
    explicit_wait(2)


# Open slider for Budgetary unit using name
def open_budget_unit_details_slider_with_name(budget_name):
    click_with_replace_value(budget_unit_table_option_btn_with_text, budget_name, 'Budget Unit Table Options Button')
    click_with_replace_value(budget_unit_table_option_btn, 'View Details', 'Budget Unit Table View details Button')
    wait_for_budget_spinner_off()
    explicit_wait(2)


def add_budget_to_budgetary_unit(budget_key=DEFAULT_BUDGET_KEY, skip_msg=False):
    click_slider_budgets_tab()
    click_add_budget()
    budget_fill_parameters(budget_key)
    click_create_budget()
    if not skip_msg:
        check.is_in(get_element_text(budget_success_modal_txt), budgetary_data['addedBudgetMsg'], 'Budget Added Success Msg')
        click(budget_toast_close_icon, 'Toast close button')


def edit_budget(budget_key=DEFAULT_EDIT_BUDGET_KEY):
    click_slider_budgets_tab()
    open_budget_details_slider()
    click_edit_budget()
    budget_fill_parameters(budget_key)
    click_save_edit_budget()
    check.is_in(get_element_text(budget_success_modal_txt), budgetary_data['editedBudgetMsg'], 'Budget Edited Success Msg')
    click(budget_toast_close_icon, 'Toast close button')


# Wait for budget table to load
def wait_for_budgets_table_to_load():
    wait_for_element_to_invisible(first_empty_cell, "Empty cell value")
    wait_for_all_elements_to_load(budget_table_options_btn, "Row options button")


# Click on Budgetary Unit Budgets slider tab button
def click_slider_budgets_tab():
    click(budgets_slider_tab_btn, 'Slider Budgets Tab')


def click_slider_budget_unit_details_tab():
    click(budget_unit_details_tab_btn, 'Slider Details Tab')


def click_add_budget():
    click(add_budget_btn, 'Add Budget Button')


def click_create_budget():
    click(create_budget_btn, 'Create Budget Button')


def select_budget_table_option(option):
    click(budget_table_options_btn, 'Budget Table Options Button')
    click_with_replace_value(budget_table_option_btn, option, 'Budget Table View details Button')


def open_budget_details_slider():
    select_budget_table_option('View Details')
    wait_for_budget_spinner_off()
    explicit_wait(2)


# Open slider for Budget using name
def open_budget_details_slider_with_name(budget_name):
    click_with_replace_value(budget_table_option_btn_with_text, budget_name, 'Budget Table Options Button')
    click_with_replace_value(budget_table_option_btn, 'View Details', 'Budget Table View details Button')
    wait_for_budget_spinner_off()
    explicit_wait(2)


# Validate if budget is present in table or not
def is_budget_present(budget_name):
    budget_names = get_elements_texts(budget_table_name_col_text)
    if budget_name in budget_names:
        logger.info("Budget is found in the table")
        return True
    else:
        logger.info("Budget is not found in the table")
        return False


# Show all budgets in budget table
def show_all_budgets():
    right_pagination_text = get_element_text(budget_table_pagination_right_text)
    number_of_pages = int(right_pagination_text.split(" ")[1])
    option_value = number_of_pages * 10
    click(budget_table_pagination_dropdown, "Budget table pagination dropdown")
    click_with_replace_value(budget_table_pagination_dropdown_option, option_value, "Budget table pagination dropdown option")
    wait_for_budgets_table_to_load()


def click_edit_budget():
    click(budget_edit_btn, 'Edit Budget Button')


def click_save_edit_budget():
    click(budget_edit_save_btn, 'Save Edit Budget Button')


def validate_budget_unit_details(budget_data_key=DEFAULT_BUDGET_UNIT_KEY, edit_budget_data_key=DEFAULT_EDIT_BUDGET_UNIT_KEY, is_editing=False):
    budget_params_titles = get_elements_texts(budget_unit_details_labels)
    budget_params_values = get_elements_texts(budget_unit_details_txt)
    actual_budget_details_ui = dict(zip(budget_params_titles, budget_params_values))
    if is_editing:
        budget_params_json_dic_data = budget_merge_dict(budget_data_key, edit_budget_data_key)
    else:
        budget_params_json_dic_data = get_data_object(budget_data_key)
    for key, actual_value in actual_budget_details_ui.items():
        _validate_budget_detail_parameter(budget_params_json_dic_data, budget_data_key, key, actual_value, budget_unit_detail_txt, [key, key])


def validate_budget_unit_business_entities(budget_data_key=DEFAULT_BUDGET_UNIT_KEY, edit_budget_data_key=DEFAULT_EDIT_BUDGET_UNIT_KEY, is_editing=False):
    budget_entities_params_titles = get_elements_texts(budget_unit_details_entities_labels)
    budget_entities_params_values = get_elements_texts(budget_unit_details_entities_txt)
    actual_budget_entities_details_ui = dict(zip(budget_entities_params_titles, budget_entities_params_values))
    if is_editing:
        budget_params_json_dic_data = budget_merge_dict(budget_data_key, edit_budget_data_key)
    else:
        budget_params_json_dic_data = get_data_object(budget_data_key)
    # Verify entity type
    entity_type = get_value(budget_params_json_dic_data[budget_data_key], 'Entity Type')
    check.is_in(entity_type, budget_entities_params_titles, 'Entity Type')
    # Verify associated entities
    for key, actual_value in actual_budget_entities_details_ui.items():
        _validate_budget_detail_parameter(budget_params_json_dic_data, budget_data_key, key, actual_value, budget_unit_detail_txt, [key, key])


def validate_budget_details(budget_data_key=DEFAULT_BUDGET_KEY, edit_budget_data_key=DEFAULT_EDIT_BUDGET_KEY, is_editing=False):
    budget_params_titles = get_elements_texts(budget_details_labels)
    budget_params_values = get_elements_texts(budget_details_txt)
    actual_budget_details_ui = dict(zip(budget_params_titles, budget_params_values))
    if is_editing:
        budget_params_json_dic_data = budget_merge_dict(budget_data_key, edit_budget_data_key)
    else:
        budget_params_json_dic_data = get_data_object(budget_data_key)
    for key, actual_value in actual_budget_details_ui.items():
        _validate_budget_detail_parameter(budget_params_json_dic_data, budget_data_key, key, actual_value, budget_detail_txt, [key])


def _validate_budget_detail_parameter(params_json_dic_data, data_key, key, actual_value, locator=None, get_elem_value=list()):
    expected_value = get_value(params_json_dic_data[data_key], key)
    if expected_value is not None:
        # Validates if the expected value is a list of values (multiselect options) and format the values
        if type(expected_value) == list:
            expected_value, actual_value = format_detail_multiple_values(expected_value, actual_value)
        # Waits and get value again in case value was not loaded
        aux_actual = actual_value.strip().lower()
        aux_expected = expected_value.lower()
        if (aux_actual not in aux_expected  or  not aux_expected in aux_actual) and locator:
            wait_for_element_text_with_replace_value(locator, get_elem_value ,expected_value, key)
            actual_value = get_element_text_replace_value(locator, get_elem_value, key)
            if type(expected_value) == list:
                expected_value, actual_value = format_detail_multiple_values(expected_value, actual_value)
        check.is_in(actual_value.strip().lower(), expected_value.lower(), key)


def budget_merge_dict(original_key, new_key):
    original = get_data(original_key)
    new = get_data(new_key)
    dict_merge(original, new)
    return {original_key: original}


def edit_and_validate_budget_parameters_one_by_one(budget_data_key=DEFAULT_EDIT_BUDGET_ONE_BY_ONE_KEY):
    click_slider_budgets_tab()
    open_budget_details_slider()
    budget_data = get_data(budget_data_key)
    budget_params_json_dic_data = get_data_object(budget_data_key)
    for key, data in budget_data.items():
        click_edit_budget()
        wait_for_budget_spinner_off()
        get_filtered_data(data, key)
        click_save_edit_budget()
        check.is_in(get_element_text(budget_success_modal_txt), budgetary_data['editedBudgetMsg'],
                    'Budget Edited Success Msg')
        click(budget_toast_close_icon, 'Toast close button')
        wait_for_element_text_with_replace_value(budget_detail_txt, key, data.get('value'), key)
        actual_ui_value = get_element_text_replace_value(budget_detail_txt, key, key)
        _validate_budget_detail_parameter(budget_params_json_dic_data, budget_data_key, key, actual_ui_value)


def validate_budget_exists():
    check.is_in(get_element_text(budget_error_modal_txt), budgetary_data['budgetAlreadyExistsMsg'],
                'Budget Already Exists Msg')
    click(budget_toast_close_icon, 'Toast close button')


def validate_budget_overlaps_date():
    check.is_in(get_element_text(budget_error_modal_txt), budgetary_data['budgetOverlapsMsg'],
                'Budget Overlaps Date Msg')
    click(budget_toast_close_icon, 'Toast close button')


def validate_budget_unit_with_budget_active():
    check.is_in(get_element_text(budget_inline_msg_txt), budgetary_data['budgetUnitEditWithBudgerActiveMsg'],
                'Budget Unit With Budget Active Msg')


def inactivate_budget():
    click_slider_budgets_tab()
    open_budget_details_slider()
    click_edit_budget()
    wait_for_budget_spinner_off()
    get_filtered_data(budgetary_data['budgetStatusSwitchInactive'], 'Status')
    click_save_edit_budget()
    check.is_in(get_element_text(budget_success_modal_txt), budgetary_data['editedBudgetMsg'],
                'Budget Status Inactivated Success Msg')
    click(budget_toast_close_icon, 'Toast close button')


def inactive_budgets_in_batch():
    click_slider_budgets_tab()
    wait_for_budgets_table_to_load()
    show_all_budgets_using_pagination()
    scroll_element_into_view(budget_table_select_all_checkbox)
    click(budget_table_select_all_checkbox, "Select all budgets checkbox")
    wait_for_element_clickable(budget_table_deactivate_btn, "Deactivate button")
    click(budget_table_deactivate_btn, "Deactivate button")
    wait_for_element_clickable(budget_deactivate_confirm_btn, "Deactivate confirm button")
    click(budget_deactivate_confirm_btn, "Deactivate confirm button")
    explicit_wait(2)
    wait_for_element_to_visible(budget_inline_msg_txt, "Success message")
    check.is_in(get_element_text(budget_inline_msg_txt), budgetary_data['budgetsBatchDeactivateSuccessMsg'],
                'Budgets deactivation success msg')
    wait_for_budgets_table_to_load()


def inactivate_budget_unit():
    click_slider_budget_unit_details_tab()
    click_edit_budget_unit()
    wait_for_loaders_budgetary_unit()
    get_filtered_data(budgetary_data['budgetUnitStatusSwitchInactive'], 'Status')
    click_update_budget_unit()
    check.is_in(get_element_text(budget_success_modal_txt), budgetary_data['editedBudgetUnitMsg'],
                'Budget Unit Status Inactivated Success Msg')
    click(budget_toast_close_icon, 'Toast close button')


def edit_and_validate_budget_unit_parameters_one_by_one(budget_data_key=DEFAULT_EDIT_BUDGET_UNIT_ONE_BY_ONE_KEY):
    budget_data = get_data(budget_data_key)
    budget_params_json_dic_data = get_data_object(budget_data_key)
    for key, data in budget_data.items():
        click_edit_budget_unit()
        wait_for_loaders_budgetary_unit()
        get_filtered_data(data, key)
        click_update_budget_unit()
        check.is_in(get_element_text(budget_success_modal_txt), budgetary_data['editedBudgetUnitMsg'],
                    'Budget Unit Edited Success Msg')
        explicit_wait(2)
        click(budget_toast_close_icon, 'Toast close button')
        wait_for_element_text_with_replace_value(budget_unit_detail_txt, [key, key], data.get('value'), key)
        actual_ui_value = get_element_text_replace_value(budget_unit_detail_txt, [key, key], key)
        _validate_budget_detail_parameter(budget_params_json_dic_data, budget_data_key, key, actual_ui_value)


def wait_for_budget_spinner_off():
    wait_for_element_to_invisible(budget_spinner, 'Spinner')
    explicit_wait(2)


def wait_for_budget_spinner_on():
    try:
        wait_for_element_to_visible(budget_spinner, 'Spinner')
    except:
        logger.info('Spinner is not present')


def wait_for_loaders_budgetary_unit():
    # First Loader
    wait_for_budget_spinner_off()
    # Associate Budget Loader
    wait_for_budget_spinner_on()
    wait_for_budget_spinner_off()


def validate_add_budgetary_cancel():
    click_add_new_budget_unit()
    wait_for_element_to_visible(add_budget_unit_slider, 'Add Budget Unit Slider')
    click(add_budget_unit_cancel_btn, 'Add Budget Unit Cancel Button')
    wait_for_element_to_invisible(add_budget_unit_cancel_btn, 'Add Budget Unit Slider')


def login_as_budget_viewer():
    logout_and_login(users_data['budget_viewer_user'])


def validate_invisibility_of_add_budget_unit_button():
    check.is_true(is_element_not_present(add_new_budget_unit_btn, 'Add Budget Unit Button'),
                  'Add New Budget Unit Button Invisible')


def validate_invisibility_of_edit_budget_unit_button():
    check.is_true(is_element_not_present(budget_unit_edit_btn, 'Edit Budget Unit Button'),
                  'Edit Budget Unit Button Invisible')


def validate_invisibility_of_add_budget_button():
    check.is_true(is_element_not_present(add_budget_btn, 'Add Budget Button'), 'Add New Budget Button Invisible')


def validate_invisibility_of_edit_budget_button():
    check.is_true(is_element_not_present(budget_edit_btn, 'Edit Budget Button'), 'Edit Budget Button Invisible')


def validate_budget_unit_status(status='Active'):
    actual_status = get_element_text_replace_value(budget_unit_detail_txt, ['Status', 'Status'], 'Status Value')
    check.is_in(actual_status, status, 'Budget Unit Status')


def validate_budget_amounts(budget_amount, available_amount, commited_amount, under_approval_amount):
    # UI Fields
    actual_budget_amount = get_element_text_replace_value(budget_detail_txt, 'Budget Amount', 'Budget Amount Value')
    actual_available_amount = get_element_text_replace_value(budget_detail_txt, 'Available Amount',
                                                             'Available Amount Value')
    actual_commited_amount = get_element_text_replace_value(budget_detail_txt, 'Committed Amount',
                                                            'Committed Amount Value')
    actual_under_approval_amount = get_element_text_replace_value(budget_detail_txt, 'Under Approval Amount',
                                                                  'Budget Amount Value')
    # Validations
    check.is_in(actual_budget_amount, budget_amount, 'Budget Amount')
    check.is_in(actual_available_amount, available_amount, 'Budget Available Amount')
    check.is_in(actual_commited_amount, commited_amount, 'Budget Commited Amount')
    check.is_in(actual_under_approval_amount, under_approval_amount, 'Budget Under Approval Amount')


# Show all budgets in the table by selecting appropriate pagesize
def show_all_budgets_using_pagination():
    selected_value = 1
    right_page_text = get_element_text(budget_table_right_page_text)
    no_of_pages = right_page_text.split(" ")[1]
    logger.info(f"Number of pages in budget table: {no_of_pages}")
    left_page_text = get_element_text(budget_table_left_page_text)
    page_size = left_page_text.split(" ")[0].split("-")[1]
    logger.info(f"Page size for budget table: {page_size}")
    selected_value = int(no_of_pages) * int(page_size)
    click(budget_table_page_size_dropdown_btn, "Page size dropdown button")
    click_with_replace_value(budget_table_page_size_dropdown_option, selected_value, "Page size option")
    wait_for_budgets_table_to_load()


# Validate sum of all budgets amount with total budget amount should be equal
def validate_budgets_created_budget_amount(total_budget_amount):
    budget_amt = 0
    budget_amt_values = get_elements_texts(budget_amount_col_values)
    for value in budget_amt_values:
        formatted_value = re.sub(r"/\s\s+/g", " ", value).split(" ")[1]
        budget_amt = budget_amt + int(formatted_value)
    if budget_amt == int(total_budget_amount):
        logger.info("Budgets are created with expected budget amounts.")
        return True
    else:
        logger.info(
            f"Budgets are NOT created with expected budget amounts. Total budget amount: {total_budget_amount} | Sum of each budget amount: {budget_amt}")
        return False


def click_add_budget_set_btn():
    click(budget_add_budget_set_btn, 'Add Budget Set Button')


def reformating_values_in_budget_amt_textbox(value):
    formatted_value = re.sub(r",", "", value)
    logger.info(f"Budget Actual Value: {value} : Budget formatted value:{formatted_value}")
    return float(formatted_value)


# Validate sum of all budgets amount with total budget amount should be equal
def validate_budget_set_displayed_total_amt_matches_individual_budget_amts():
    total_budget_displayed_amt = reformating_values_in_budget_amt_textbox(
        get_attribute_value(total_budget_amount_textbox, "value"))
    budget_amt_text_box1_value = reformating_values_in_budget_amt_textbox(
        get_attribute_value(budget_set_budget_amt_text_box_1, "value"))
    budget_amt_text_box2_value = reformating_values_in_budget_amt_textbox(
        get_attribute_value(budget_set_budget_amt_text_box_2, "value"))
    budget_amt_text_box3_value = reformating_values_in_budget_amt_textbox(
        get_attribute_value(budget_set_budget_amt_text_box_3, "value"))
    budget_amt_text_box4_value = reformating_values_in_budget_amt_textbox(
        get_attribute_value(budget_set_budget_amt_text_box_4, "value"))
    if total_budget_displayed_amt == (
            budget_amt_text_box1_value + budget_amt_text_box2_value + budget_amt_text_box3_value + budget_amt_text_box4_value):
        logger.info(
            f"Budgets sum matches the total amount: {total_budget_displayed_amt}  Sum of each budget amount: {budget_amt_text_box1_value} {budget_amt_text_box2_value} {budget_amt_text_box3_value} {budget_amt_text_box4_value}")
        return True, total_budget_displayed_amt, budget_amt_text_box1_value, budget_amt_text_box2_value, budget_amt_text_box3_value, budget_amt_text_box4_value
    else:
        logger.info(
            f"Budgets sum does not matches the total amount: {total_budget_displayed_amt} | Sum of each budget amount: {budget_amt_text_box1_value} {budget_amt_text_box2_value} {budget_amt_text_box3_value} {budget_amt_text_box4_value}")
        return False, total_budget_displayed_amt, budget_amt_text_box1_value, budget_amt_text_box2_value, budget_amt_text_box3_value, budget_amt_text_box4_value


# edit one of the budget amount text boxes
def edit_a_budget_amount_text_box():
    # budget_amt_text_boxes_value = get_all_elements(budget_set_amt_all_textboxes,"budget amount textbox")
    budget_amt_text_boxes_value = get_all_elements(budget_set_amt_textboxes, "budget amount textbox")
    random_amt = random.randint(0, 1000)
    # pick a random index from multiple budget amt inputboxes
    rand_index = random.randint(0, len(budget_amt_text_boxes_value) - 1)
    # pick a element against above index
    element = budget_amt_text_boxes_value[rand_index]
    # clear existing value
    element.clear()
    # insert random amt
    element.send_keys(random_amt)
    return random_amt


def budget_set_page_non_amt_fields_fill_details(budget_set_key=DEFAULT_BUDGET_SET_KEY):
    budget_fill_parameters(budget_set_key)


def click_delete_budget_unit():
    click(budget_unit_list_page_delete_btn, 'Delete Budget Button')
    explicit_wait(2)


def click_delete_from_budget_unit_confirm_pop_up(budget_name):
    click(budget_unit_list_page_confirm_pop_up_delete_btn, 'Delete from Budgetary unit confirmation pop up ')
    wait_for_element_to_visible(budget_delete_confirm_msg, "Success message")
    check.is_in(get_element_text(budget_delete_confirm_msg), budgetary_data['budgetaryunitdeleteSuccessMsg'],
                'Budgetary Unit Successfully Deleted')
    logger.info(f"budgetary unit = {budget_name} successfully deleted")


def click_searched_budget_unit_check_box():
    explicit_wait(1)
    click_using_script(budget_unit_item_check_box_from_list_page, "budgetary unit checkbox")


def delete_budgetary_unit(bu_name):
    search_budget_unit(bu_name)
    click_searched_budget_unit_check_box()
    click_delete_budget_unit()
    click_delete_from_budget_unit_confirm_pop_up(bu_name)
 

def delete_all_budgets():
    click(budget_table_select_all_checkbox_xpath, "Select All Budgets")
    click_delete_budget_unit()
    click_delete_from_budget_unit_confirm_pop_up("all")
    
    
def verify_budget_already_searched(budget_unit_name):
    if is_element_present(budget_unit_table_search, 'Budget Unit Table Search'):
        budget_name = get_attribute_value(budget_unit_table_search, "value")
        if budget_name == budget_unit_name:
            logger.info("Budget is already searched")
        else:
            clear_input_field_entry(budget_unit_table_search)
            click(budget_unit_table_open_search_btn, 'Open Search Button')
            type_value_and_enter(budget_unit_table_search, budget_unit_name, 'Budget Unit Table Search')
    wait_for_element_to_invisible(first_empty_cell, "Empty cell value")
    if get_elements_count(budget_unit_table_no_data_text) > 0:
        logger.info("No Budgetary Units found in the table")
        return False
    else:
        logger.info("One or more results found in the table")
        wait_for_element_to_visible_with_replace_value(budget_unit_table_first_row_col_txt, budget_unit_name, 'Budget Table Column')
        return True
