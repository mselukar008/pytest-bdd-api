import time

from helpers.mo_api_enums import Store
from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_json_utils import *
from helpers.mo_page_operations import *
from helpers.mo_selenium_helper import logger
from locators.store.service_now_locator import *
from pages.store.navigation_page import open_itsm_page
from ui_config import test_data_path

snow_login_path = os.path.join(test_data_path, "servicenow", "snow_login.json")
snow_data_path = os.path.join(test_data_path, "servicenow", "snow_instance_data.json")
policy_condition = None

# Set login params for non quickstart instance
def setup_snow_non_qs():
    set_data_path(snow_login_path)
    snow_url = get_data("nonqs_url")
    snow_username = get_data("nonqs_username")
    snow_password = get_data("nonqs_password")
    return snow_url, snow_username, snow_password


# Set login params for quickstart instance
def setup_snow_qs():
    set_data_path(snow_login_path)
    snow_url = get_data("qs_url")
    snow_username = get_data("qs_username")
    snow_password = get_data("qs_password")
    return snow_url, snow_username, snow_password


# Set login params for quickstart instance
def setup_snow_icds():
    set_data_path(snow_login_path)
    snow_url = get_data("icds_url")
    snow_username = get_data("icds_username")
    snow_password = get_data("icds_password")
    return snow_url, snow_username, snow_password


# Login to Snow Instance
def login_to_snow(params):
    url, username, password = params
    set_data_path(snow_login_path)
    driver.get(url + "/logout.do")
    logger.info("Pre-Condition :: Logged out from SNOW portal")
    switch_to_alert()
    driver.get(url)
    logger.info("Opened SNOW portal")
    switch_to_iframe(main_frame)
    if is_element_present(username_textbox, "Username"):
        type_value(username_textbox, username, "Username")
        type_value(password_textbox, password, "Password")
        click(login_btn, "Login")
    switch_to_default_content_iframe()
    set_data_path(snow_data_path)


# Search order on Requests page
def search_order_in_service_now(order_num):
    click(all_link, "All")
    type_value_and_enter(search_order_textbox, order_num, "search")


def open_service_requests():
    click(favorites_tab, "Favorites")
    type_value(search_filter, "Service Catalog", "search")
    scroll_element_into_view(requests_link)
    click(requests_link, "Service Catalog-Requests")
    switch_to_iframe(main_frame)
    if is_element_present(all_link, "All link"):
        logger.info("Service-Catalog Requests page is opened")
    else:
        switch_to_default_content_iframe()
        open_service_requests()


# Search for order until SR is created
def search_order_until_exists(order_num, repeat_count=None):
    if repeat_count is None:
        repeat_count = 20
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        search_order_in_service_now(order_num)
        if check_element_exists(requests_number_link):
            logger.info("Order found")
            return
        else:
            logger.info("Order not found, searching again")
            search_order_until_exists(order_num, repeat_count)


# Login and search order on Requests page
def login_snow_search_order(snow_login_params, order_num):
    login_to_snow(snow_login_params)
    open_service_requests()
    search_order_until_exists(order_num)
    click(requests_number_link, "Request number")
    set_data_path(snow_data_path)


# Wait till expected Approval state in Request page
def wait_until_expected_approval(expected_state, repeat_count=None):
    if repeat_count is None:
        repeat_count = 20
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        check_element_exists(approval_text)
        state = get_element_text(approval_text)
        if state == expected_state:
            logger.info("Approval is " + expected_state)
            return
        else:
            logger.info("Approval is not " + expected_state + " : refreshing page")
            driver.refresh()
            switch_to_iframe(main_frame)
            wait_until_expected_approval(expected_state, repeat_count)


# Wait till expected Approval controller in Request page
def wait_until_expected_approval_controller(expected_state, repeat_count=None):
    if repeat_count is None:
        repeat_count = 20
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        check_element_exists(approval_controller_text)
        state = get_element_text(approval_controller_text)
        if state == expected_state:
            logger.info("Approval controller is " + expected_state)
            return
        else:
            logger.info("Approval controller is not " + expected_state + " : refreshing page")
            driver.refresh()
            switch_to_iframe(main_frame)
            wait_until_expected_approval_controller(expected_state, repeat_count)


# Wait till expected Stage in RITM page
def wait_until_expected_stage(expected_state, repeat_count=None):
    if repeat_count is None:
        repeat_count = 20
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        check_element_exists(stage_ritm_text)
        state = get_attribute_value(stage_ritm_text, "value")
        if state == expected_state:
            logger.info("Stage is " + expected_state)
            return
        else:
            logger.info("Stage is not " + expected_state + " : refreshing page")
            driver.refresh()
            switch_to_iframe(main_frame)
            wait_until_expected_stage(expected_state, repeat_count)


# Open Service Instance CI page
def open_conf_item():
    click(conf_item_btn, "Configuration Item")
    click(open_record_btn, "Open record")


# Open Change Request page
def open_related_change_request():
    click(related_change_req_btn, "Related Change Request")
    click(open_record_btn, "Open record")


# To select dropdown value in Snow
def select_dropdown_value(values_locator, value_locator, value, elem_name):
    values = get_elements_texts(values_locator)
    for num, name in enumerate(values, start=1):
        if name == value:
            dropdown_value = driver.find_element_by_css_selector(value_locator[1].format(str(num)))
            dropdown_value.click()
            logger.info("Selected Value " + value + " from Dropdown " + elem_name)


# Select change request state along with assignment group
def select_change_request_state_with_assign_group(state_value):
    click(state_dropdown, "State")
    select_dropdown_value(state_dropdown_values, state_dropdown_value, state_value, "State")
    type_value_key_down_enter(assignment_group_text, "CAB", "Assignment group")
    click(update_btn, "Update")
    open_related_change_request()


# Change Approvals
def approve_change_request(qs=False):
    click(approvers_tab, "Approvers")
    if qs:
        links = get_number_of_elements(change_requested_link, 'Approvers')
    else:
        links = get_number_of_elements(requested_link, 'Approvers')
    for i in range(links):
        click(requested_link, "Requested link")
        type_value(approval_comments_text, "Test", "Comments")
        click(approve_btn, "Approve")
        if qs:
            if i == 0:
                break
        else:
            if i == 1:
                break


# Reject Change Approval
def reject_change_request():
    click(approvers_tab, "Approvers")
    click(requested_link, "Requested link")
    type_value(approval_comments_text, "Test", "Comments")
    click(reject_btn, "Reject")


# Select change request state
def select_change_request_state(state_value):
    click(state_dropdown, "State")
    select_dropdown_value(state_dropdown_values, state_dropdown_value, state_value, "State")
    click(update_btn, "Update")
    open_related_change_request()


# Wait until provision is complete in Snow
def wait_until_provision_task_closed(repeat_count=None):
    if repeat_count is None:
        repeat_count = 1500
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        scroll_element_into_view(provision_task_state_text)
        is_element_present(provision_task_state_text, "Provisioning task")
        explicit_wait(2)
        click(change_request_refresh_btn, "refresh state")
        explicit_wait(5)
        state = get_element_text(provision_task_state_text)
        if state == "Open":
            logger.info("Provisioning task is Open => Continue looping")
            wait_until_provision_task_closed(repeat_count)
        elif state == "In Progress":
            logger.info("Provisioning task is in progress => Continue looping")
            wait_until_provision_task_closed(repeat_count)
        elif state == "Closed":
            logger.info("Provisioning task is Closed")
            return
        else:
            logger.info("Provisioning task is Pending")
            return


# Wait until provision is complete in Snow ICDS
def wait_until_all_change_tasks_closed(repeat_count=None):
    if repeat_count is None:
        repeat_count = 1500
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        scroll_element_into_view(change_tasks_state_text)
        is_element_present(change_tasks_state_text, "Change tasks")
        click(change_request_refresh_btn, "refresh state")
        explicit_wait(2)
        state = get_elements_texts(change_tasks_state_text)
        result = all(text == "Closed" for text in state)
        if result:
            logger.info("Change tasks are Closed")
            return
        else:
            logger.info("Change tasks are in progress => Continue looping")
            wait_until_all_change_tasks_closed(repeat_count)
            color = get_attribute_value(implementation_task_style, "style")
            if color == "background-color:tomato":
                logger.info("Implementation task failed")
                return


# Check for provision
def check_if_provision_task_closed():
    click(change_tasks_tab, "Change Tasks")
    wait_until_provision_task_closed()


# Check for ICDS provision
def check_if_all_change_tasks_closed():
    click(change_tasks_tab, "Change Tasks")
    wait_until_all_change_tasks_closed()
    explicit_wait(5)


def fill_closure_information(code_value):
    scroll_element_into_view(closure_info_tab)
    click(closure_info_tab, "Closure Information")
    scroll_element_into_view(close_code_dropdown)
    click(close_code_dropdown, "Close Code")
    select_dropdown_value(close_code_dropdown_values, close_code_dropdown_value, code_value, "Close Code")
    type_value(close_notes_textbox, "Success", "Close Notes")


# Close request
def close_change_request(code_value):
    fill_closure_information(code_value)
    scroll_element_into_view(close_change_request_btn)
    switch_to_alert()
    click(close_change_request_btn, "Close Request")
    explicit_wait(6)


# Approval on Request page
def approve_request():
    click(second_tab, "Approvers tab")
    click(requested_link, "Requested link")
    type_value(approval_comments_text, "Test", "Comments")
    click(approve_btn, "Approve")
    click(first_tab, "Requested Item tab")


# Reject on Request page
def reject_request():
    click(second_tab, "Approvers tab")
    click(requested_link, "Requested link")
    type_value(approval_comments_text, "Test", "Comments")
    click(reject_btn, "Reject")
    click(first_tab, "Requested Item tab")


def get_count_of_ritm():
    count = get_elements_count(requested_item_links)
    return count


# Search Discovery and open the page
def open_discovery_schedules():
    type_value(search_filter, "Discovery Schedules", "search textbox")
    click(discovery_schedules_link, "Discovery Schedules")


def wait_until_discovery_completed(repeat_count=None):
    if repeat_count is None:
        repeat_count = 10000
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        is_element_present(discovery_state_text, "Discovery State")
        state = get_element_text(discovery_state_text)
        if state == "Starting" or state == "Active":
            logger.info("Discovery is in progress => Continue looping")
            click(sys_id_link, "refresh state")
            time.sleep(5)
            wait_until_discovery_completed(repeat_count)
        elif state == "Canceled":
            logger.info("Discovery State is Cancelled")
            return
        else:
            logger.info("Discovery State is Completed")
            return


def run_discovery(service_account):
    open_discovery_schedules()
    switch_to_iframe(main_frame)
    click_with_replace_value(snow_link_text, service_account, "Cloud Service Account")
    click_with_replace_value(snow_link_text, "Discover now", "Discover now link")
    wait_until_discovery_completed()


def open_request(order_num):
    switch_to_default_content_iframe()
    open_service_requests()
    search_order_until_exists(order_num)
    click(requests_number_link, "Request number")


def fill_change_request_values():
    click_with_replace_value(change_request_elements, "impact", "Impact dropdown")
    click_with_replace_value(change_request_dropdown_value, "impact", "Impact dropdown value")

    click_with_replace_value(change_request_elements, "urgency", "Urgency dropdown")
    click_with_replace_value(change_request_dropdown_value, "urgency", "Impact dropdown value")

    type_value_key_down_enter(assign_group_search_text, "Change", "Assignment group")
    type_value_key_down_enter(assigned_to_search_text, "Change", "Assigned to")

    click_with_replace_value(change_request_elements, "u_qsfailureprobability", "Failure probability dropdown")
    click_with_replace_value(change_request_dropdown_value, "u_qsfailureprobability",
                             "Failure probability dropdown value")

    click_with_replace_value(change_request_elements, "u_qs_exception_reason", "Exception reason dropdown")
    click(exception_reason_dropdown_value, "Exception Reason")


def fill_planning_values():
    scroll_element_into_view_with_replace_value(change_req_page_tabs, "Planning")
    click_with_replace_value(change_req_page_tabs, "Planning", "Planning tab")
    type_value_with_replace_locator_string(change_request_elements, "justification", "test", "Justification")
    type_value_with_replace_locator_string(change_request_elements, "implementation_plan", "test",
                                           "Implementation Plan")
    type_value_with_replace_locator_string(change_request_elements, "risk_impact_analysis", "test",
                                           "Risk Impact Analysis")
    type_value_with_replace_locator_string(change_request_elements, "backout_plan", "test", "Backout Plan")
    type_value_with_replace_locator_string(change_request_elements, "test_plan", "test", "Test Plan")
    type_value_with_replace_locator_string(change_request_elements, "u_qs_exception_justification", "test",
                                           "Exception Justification")


def fill_schedule_values():
    click_with_replace_value(change_req_page_tabs, "Schedule", "Schedule tab")

    click_index_based(calendar_start_date_btn, 1, "Calendar Start Date button")
    click(calendar_start_date, "Start Date")
    click(date_picker_ok_btn, "OK")

    click_index_based(calendar_end_date_btn, 1, "Calendar End Date button")
    click(calendar_end_date, "End Date")
    click(date_picker_ok_btn, "OK")


def click_request_approval_in_change_request():
    driver.refresh()
    switch_to_iframe(main_frame)
    explicit_wait(5)
    click(request_approval, "Request approval")
    explicit_wait(5)


def fill_change_request_and_assess():
    fill_change_request_values()
    fill_planning_values()
    fill_schedule_values()
    click_with_replace_value(snow_link_text, "Calculate Risk", "Calculate risk")
    explicit_wait(5)
    click_using_java_script(assess_btn, "Assess")
    switch_to_alert()
    click_request_approval_in_change_request()


def get_change_request_sys_id():
    mouse_over_right_click(cmdb_ci_form_header, "Form header")
    value = get_attribute_value(copy_sys_id_text, "href")
    sys_id = str(value[17:49])
    click(copy_sys_id_text, "Copy Sys id")
    logger.info("Sys_id is: " + sys_id)
    return sys_id


def fill_change_task_details():
    click(change_task_state_dropdown, "Change Task state")
    click(change_task_state_dropdown_value, "Change Task state value")

    type_value_key_down_enter(change_task_assign_grp_text, "Change", "Assignment group")
    type_value_key_down_enter(change_task_assigned_to_text, "Change", "Assigned to")

    click_index_based(change_task_start_date_btn, 1, "Calendar Start Date button")
    click(calendar_start_date, "Start Date")
    click(date_picker_ok_btn, "OK")

    click_index_based(change_task_end_date_btn, 1, "Calendar End Date button")
    click(calendar_end_date, "End Date")
    click(date_picker_ok_btn, "OK")

    fill_closure_information(get_data("close_code_success"))

    type_value(change_task_desc_text, "Test", "Change Task description")
    click(update_btn, "Update")


def close_notify_service_desk_task():
    click(notify_ser_desk_link, "Notify Service Desk")
    fill_change_task_details()


def close_implement_task():
    scroll_element_into_view(implement_link)
    click(implement_link, "Implement")
    fill_change_task_details()


def qs_change_approvals_normal():
    fill_change_request_and_assess()
    approve_change_request(qs=True)
    approve_change_request(qs=True)


def qs_order_completion_normal():
    check_if_provision_task_closed()
    close_implement_task()
    close_change_request(get_data("close_code_success"))


def cancel_change_order():
    mouse_over_right_click(nav_bar_title_text, "Form header")
    click(cancel_change_text, "Cancel Change")
    explicit_wait(5)
    scroll_element_into_view(notes_tab)
    click(notes_tab, "Notes")
    type_value(additional_comments_textarea, "Test Cancel Change", "Additional Comments")
    mouse_over_right_click(nav_bar_title_text, "Form header")
    click(cancel_change_text, "Cancel Change")


def open_change_task():
    click(change_tasks_tab, "Change Tasks tab")
    click(change_task_link, "Change Task link")


def open_incident():
    click(active_tasks_btn, "Active tasks")
    click(incident_link, "Incident link")


# Search Properties and open the page
def open_properties():
    type_value(search_filter, "Properties", "search textbox")
    click(properties_link, "Properties")
    switch_to_iframe(main_frame)
    if is_element_present(property_search_textbox, "Properties"):
        logger.info("Properties page is opened")
    else:
        switch_to_default_content_iframe()
        open_properties()


def search_property(property_name):
    type_value_and_enter(property_search_textbox, property_name, "Property search")
    click(property_link, "Property link")


def edit_property_value(value):
    click(property_edit_link, "Edit link")
    type_value(property_value_textarea, value, "Value")
    click(update_btn, "Update")


def set_hcms_property(property_name, value):
    open_properties()
    search_property(property_name)
    edit_property_value(value)
    switch_to_default_content_iframe()


def open_em_configuration():
    type_value(search_filter, "Enterprise Marketplace", "search textbox")
    click(em_config_link, "Enterprise Marketplace Configuration")
    switch_to_iframe(main_frame)
    if is_element_present(em_api_endpoint_textbox, "EM Configuration"):
        logger.info("EM Configuration page is opened")
    else:
        switch_to_default_content_iframe()
        open_em_configuration()


def get_api_base_url():
    api_url = Store.API_URL.get_path_name()
    return api_url


def fill_em_details():
    api_url = get_api_base_url()
    type_value(em_api_endpoint_textbox, api_url, "EM api endpoint")
    if "qs-v3-test4fra" in api_url:
        click(em_api_creds_search_icon, "Search icon")
        switch_to_new_window()
        type_value_and_enter(api_creds_table_search_textbox, get_data("em_api_creds_test4fra"), "EM api creds search")
        explicit_wait(5)
        click(api_creds_table_link, "EM api creds link")
        switch_to_parent_window(auto_close=True)
        switch_to_iframe(main_frame)


def fetch_mo_config_values():
    fill_em_details()
    click(get_config_values_checkbox, "Get Config Values")
    # Since validation cannot be done here in other ways, explicit wait of 15s is used to fetch mo config values.
    explicit_wait(15)


def enable_cd():
    if is_element_present(aws_checkbox, "AWS provider"):
        logger.info("Common Discovery is enabled")
    else:
        click(enable_cd_checkbox, "Enable Common Discovery")


def disable_cd():
    if is_element_present(aws_checkbox, "AWS provider"):
        logger.info("Common Discovery is enabled, disabling it")
        click(enable_cd_checkbox, "Common Discovery")
        enter_account_creds()
        click(order_now_btn, "Order Now")
    else:
        logger.info("Common Discovery is disabled")


def enable_cd_for_aws(resource_types):
    if is_element_present(select_aws_resources_text, "Select AWS provider"):
        logger.info("Common Discovery is enabled for AWS")
    else:
        click(aws_checkbox, "AWS provider")
        click(aws_resource_types_btn, "Edit resource types for AWS provider")
        for resource_type in resource_types:
            type_value_key_down_enter(aws_resource_types_textbox, resource_type, "Resource Types for AWS")


def enable_cd_for_azure(resource_types):
    if is_element_present(select_azure_resources_text, "Select Azure provider"):
        logger.info("Common Discovery is enabled for Azure")
    else:
        click(azure_checkbox, "Azure provider")
        click(azure_resource_types_btn, "Edit resource types for Azure provider")
        for resource_type in resource_types:
            type_value_key_down_enter(azure_resource_types_textbox, resource_type, "Resource Types for Azure")


def enable_cd_for_gcp(resource_types):
    if is_element_present(select_gcp_resources_text, "Select GCP provider"):
        logger.info("Common Discovery is enabled for GCP")
    else:
        click(gcp_checkbox, "GCP provider")
        click(gcp_resource_types_btn, "Edit resource types for GCP provider")
        for resource_type in resource_types:
            type_value_key_down_enter(gcp_resource_types_textbox, resource_type, "Resource Types for GCP")


def disable_cd_for_aws():
    if is_element_present(select_aws_resources_text, "Select AWS provider"):
        logger.info("Common Discovery is enabled for AWS, disabling it")
        click(aws_checkbox, "AWS provider")
    else:
        logger.info("Common Discovery for AWS is disabled")


def disable_cd_for_azure():
    if is_element_present(select_azure_resources_text, "Select Azure provider"):
        logger.info("Common Discovery is enabled for Azure, disabling it")
        click(azure_checkbox, "Azure provider")
    else:
        logger.info("Common Discovery for Azure is disabled")


def disable_cd_for_gcp():
    if is_element_present(select_gcp_resources_text, "Select GCP provider"):
        logger.info("Common Discovery is enabled for GCP, disabling it")
        click(gcp_checkbox, "GCP provider")
    else:
        logger.info("Common Discovery for GCP is disabled")


def enter_account_creds():
    click(account_user_dropdown, "Account User")
    click(hcmsuser_value, "hcmsuser")
    type_value(acct_password_textbox, get_data("hcmsuser_pwd"), "Password")


def enable_common_discovery_for_providers(providers):
    enable_cd()
    if "aws" in providers:
        enable_cd_for_aws(get_data("aws_resource_types"))
    if "azure" in providers:
        enable_cd_for_azure(get_data("azure_resource_types"))
    if "gcp" in providers:
        enable_cd_for_gcp(get_data("gcp_resource_types"))
    enter_account_creds()
    click(order_now_btn, "Order Now")


def disable_common_discovery_for_providers(providers):
    if "aws" in providers:
        disable_cd_for_aws()
    if "azure" in providers:
        disable_cd_for_azure()
    if "gcp" in providers:
        disable_cd_for_gcp()
    enter_account_creds()
    click(order_now_btn, "Order Now")


def wait_until_request_state_completed(repeat_count=None):
    if repeat_count is None:
        repeat_count = 20
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        check_element_exists(request_state_text)
        state = get_element_text(request_state_text)
        if state == "Closed Complete":
            logger.info("Request State is Closed Complete")
            return
        else:
            logger.info("Request State is not Closed Complete")
            driver.refresh()
            switch_to_iframe(main_frame)
            wait_until_request_state_completed(repeat_count)


def check_if_request_completed():
    click(request_url_link, "Request Link")
    wait_until_request_state_completed()


def open_application_logs():
    type_value(search_filter, "Application Logs", "search textbox")
    click(app_logs_link, "Application Logs")
    switch_to_iframe(main_frame)
    if is_element_present(logs_msg_search_textbox, "Logs message"):
        logger.info("Application logs page is opened")
    else:
        switch_to_default_content_iframe()
        open_application_logs()


def check_for_new_incoming_discovery_asset(vm_name, repeat_count=None):
    if repeat_count is None:
        repeat_count = 1000
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        type_value_and_enter(logs_msg_search_textbox, "*" + vm_name, "Search msg textbox")
        if is_element_present_replace_value(incoming_discovery_payload, vm_name):
            logger.info(vm_name + " Resource discovered")
        else:
            logger.info(vm_name + " Resource is not discovered")
            check_for_new_incoming_discovery_asset(vm_name, repeat_count)


def check_for_off_incoming_discovery_asset(vm_name, repeat_count=None):
    if repeat_count is None:
        repeat_count = 1000
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        type_value_and_enter(logs_msg_search_textbox, "*" + vm_name, "Search msg textbox")
        if is_element_present_replace_value(incoming_discovery_off_payload, vm_name):
            logger.info(vm_name + " Off VM resource discovered")
        else:
            logger.info(vm_name + " Off VM resource is not discovered")
            check_for_off_incoming_discovery_asset(vm_name, repeat_count)


def check_for_on_incoming_discovery_asset(vm_name, repeat_count=None):
    if repeat_count is None:
        repeat_count = 1000
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        type_value_and_enter(logs_msg_search_textbox, "*" + vm_name, "Search msg textbox")
        if is_element_present_replace_value(incoming_discovery_on_payload, vm_name):
            logger.info(vm_name + " On VM resource discovered")
        else:
            logger.info(vm_name + " On VM resource is not discovered")
            check_for_on_incoming_discovery_asset(vm_name, repeat_count)


def check_for_delete_incoming_discovery_asset(resource_name, repeat_count=None):
    if repeat_count is None:
        repeat_count = 1000
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        type_value_and_enter(logs_msg_search_textbox, "*" + resource_name, "Search msg textbox")
        if is_element_present_replace_value(incoming_discovery_delete_payload, resource_name):
            logger.info(resource_name + " Delete VM resource discovered")
        else:
            logger.info(resource_name + " Delete VM resource is not discovered")
            check_for_delete_incoming_discovery_asset(resource_name, repeat_count)


def format_incoming_discovery_payload(vm_name, edit=False, off=False, on=False, delete=False):
    if edit:
        text = get_element_text_replace_value(incoming_discovery_edit_payload, vm_name, "Incoming discovery payload")
    elif off:
        text = get_element_text_replace_value(incoming_discovery_off_payload, vm_name, "Incoming discovery payload")
    elif on:
        text = get_element_text_replace_value(incoming_discovery_on_payload, vm_name, "Incoming discovery payload")
    elif delete:
        text = get_element_text_replace_value(incoming_discovery_delete_payload, vm_name, "Incoming discovery payload")
    else:
        text = get_element_text_replace_value(incoming_discovery_payload, vm_name, "Incoming discovery payload")
    payload = text.split("payload")
    payload_dict = json.loads(payload[1])
    return payload_dict


def open_table_cmdb_ci_linux_server(vm_name):
    switch_to_default_content_iframe()
    type_value_and_enter(search_filter, "cmdb_ci_linux_server.LIST", "search textbox")
    switch_to_new_window()
    type_value_and_enter(cmdb_ci_linux_server_search_textbox, vm_name, "cmdb table search textbox")
    click_with_replace_value(resource_link, vm_name, "VM link")
    sys_id = get_change_request_sys_id()
    return sys_id


def open_table_cmdb_ci_cloud_object_storage_aws(bucket_name):
    switch_to_default_content_iframe()
    type_value_and_enter(search_filter, "cmdb_ci_cloud_object_storage.LIST", "search textbox")
    switch_to_new_window()
    type_value_and_enter(cmdb_ci_storage_search_textbox, bucket_name, "cmdb table search textbox")
    click_with_replace_value(snow_link_text, bucket_name, "bucket link")
    sys_id = get_change_request_sys_id()
    return sys_id


def check_for_s3_delete_call(sys_id, repeat_count=None):
    if repeat_count is None:
        repeat_count = 1000
    repeat_count = repeat_count - 1
    if repeat_count > 0:
        type_value_and_enter(logs_msg_search_textbox, "*" + sys_id, "Search msg textbox")
        if is_element_present_replace_value(delete_call_s3_payload, sys_id):
            logger.info("Received s3 bucket delete call")
        else:
            logger.info("Not received s3 bucket delete call")
            check_for_s3_delete_call(sys_id, repeat_count)


def open_itsm_catalog_mapping():
    open_itsm_page()
    set_data_path(snow_data_path)
    click_with_replace_value(itsm_menu_icon, get_data("itsm_provider"), "Menu")
    click_with_replace_value(itsm_menu_option, get_data("catalog_mapping"), "Edit Catalog Mapping")
    wait_for_spinner_off()


def select_catalog_item(catalog_item):
    click(itsm_catalog_item_dropdown, "Catalog Item dropdown")
    type_value_and_enter(itsm_catalog_item_search_textbox, catalog_item, "Search Catalog Item")
    wait_for_spinner_off()
    click_with_replace_value(catalog_item_dropdown_value, catalog_item, "Catalog Item")


def itsm_add_policy(policy_name, change_type, catalog_item):
    click(add_policy_btn, "Add Policy")
    wait_for_spinner_off()
    type_value(policy_name_text, policy_name, "Policy Name")
    if change_type == "Standard":
        click(create_change_request_checkbox, "Uncheck Change Request Approval")
    select_catalog_item(catalog_item)


def select_policy_conditions_and_save(provedit=None, day2ops=None, delete=None, aws=None, azure=None, gcp=None,
                                      ibmcloud=None, icam=None):
    global policy_condition
    provider_condition = get_data("provider_policy_condition")
    day2ops_provider = get_data("day2ops_provider_condition")
    if provedit and aws:
        policy_condition = [get_data("prov_policy_condition"), get_data("edit_policy_condition"), provider_condition]
    elif provedit and azure:
        provider_condition[4] = "azure"
        policy_condition = [get_data("prov_policy_condition"), get_data("edit_policy_condition"), provider_condition]
    elif provedit and gcp:
        provider_condition[4] = "gcp"
        policy_condition = [get_data("prov_policy_condition"), get_data("edit_policy_condition"), provider_condition]
    elif provedit and ibmcloud:
        provider_condition[4] = "ibmcloud"
        policy_condition = [get_data("prov_policy_condition"), get_data("edit_policy_condition"), provider_condition]
    elif provedit and icam:
        provider_condition[4] = "icam"
        policy_condition = [get_data("prov_policy_condition"), get_data("edit_policy_condition"), provider_condition]
    elif day2ops and aws:
        click(add_condition_btn, "Add Condition")
        policy_condition = [get_data("off_policy_condition"), get_data("on_policy_condition"),
                            get_data("reboot_policy_condition"), day2ops_provider]
    elif day2ops and azure:
        click(add_condition_btn, "Add Condition")
        day2ops_provider[4] = "azure"
        policy_condition = [get_data("off_policy_condition"), get_data("on_policy_condition"),
                            get_data("reboot_policy_condition"), day2ops_provider]
    elif day2ops and gcp:
        click(add_condition_btn, "Add Condition")
        day2ops_provider[4] = "gcp"
        policy_condition = [get_data("off_policy_condition"), get_data("on_policy_condition"),
                            get_data("reboot_policy_condition"), day2ops_provider]
    elif day2ops and ibmcloud:
        click(add_condition_btn, "Add Condition")
        day2ops_provider[4] = "ibmcloud"
        policy_condition = [get_data("off_policy_condition"), get_data("on_policy_condition"),
                            get_data("reboot_policy_condition"), day2ops_provider]
    elif day2ops and icam:
        day2ops_provider[4] = "icam"
        policy_condition = [get_data("icam_stop_condition"), get_data("icam_start_condition"), day2ops_provider]
    elif delete and aws:
        get_data("prov_policy_condition")[3] = "Delete"
        policy_condition = [get_data("prov_policy_condition"), provider_condition]
        click_index_based(delete_condition_btn, 1, "Delete")
    elif delete and azure:
        get_data("prov_policy_condition")[3] = "Delete"
        provider_condition[4] = "azure"
        policy_condition = [get_data("prov_policy_condition"), provider_condition]
        click_index_based(delete_condition_btn, 1, "Delete")
    elif delete and gcp:
        get_data("prov_policy_condition")[3] = "Delete"
        provider_condition[4] = "gcp"
        policy_condition = [get_data("prov_policy_condition"), provider_condition]
        click_index_based(delete_condition_btn, 1, "Delete")
    elif delete and ibmcloud:
        get_data("prov_policy_condition")[3] = "Delete"
        provider_condition[4] = "ibmcloud"
        policy_condition = [get_data("prov_policy_condition"), provider_condition]
        click_index_based(delete_condition_btn, 1, "Delete")
    elif delete and ibmcloud:
        get_data("prov_policy_condition")[3] = "Delete"
        provider_condition[4] = "ibmcloud"
        policy_condition = [get_data("prov_policy_condition"), provider_condition]
        click_index_based(delete_condition_btn, 1, "Delete")
    elif delete and icam:
        get_data("prov_policy_condition")[3] = "Delete"
        provider_condition[4] = "icam"
        policy_condition = [get_data("prov_policy_condition"), provider_condition]
        click_index_based(delete_condition_btn, 1, "Delete")

    click(add_condition_btn, "Add Condition")
    params_count = get_elements_count(policy_parameters_dropdown)
    param = 0
    while param < params_count:
        for conditions in policy_condition:
            for condition in conditions:
                click_index_based(policy_parameters_dropdown, param, "Policy Parameter")
                click_with_replace_value(policy_parameters_dropdown_value, condition, condition)
                wait_for_spinner_off()
                param += 1
    click(apply_btn, "Apply")
    click(save_btn, "Save")
    wait_for_spinner_off()


def delete_all_itsm_policies():
    if is_element_present(select_all_policies_checkbox, "All Policies checkbox"):
        click(select_all_policies_checkbox, "All Policies checkbox")
        click(policy_delete_btn, "Delete")
        wait_for_spinner_off()
    else:
        logger.info("No Catalog Mapping Policies found")
