from pages.store.approve_order_page import expand_approval_type_tile
from pages.store.catalog_page import click_on_all_patterns_tab
from pages.store.mo_store_utils import sum_string_totals, sum_totals_by_locator, check_repeated_label_values, format_detail_multiple_values, \
    merge_edit_additional_parameters
from helpers.mo_json_utils import *
from locators.store.approve_order_locator import *
from locators.store.order_history_locator import *
from pages.store.navigation_page import *
import time
from helpers.mo_check import mo_check as check


# This function is used to Select status from Orders Status dropdown
def select_status_from_orders_status_dropdown(value):
    wait_for_spinner_off()
    wait_for_element_to_visible(orders_status_dropdown_btn, "Orders status dropdown button")
    wait_before_click(orders_status_dropdown_btn, "Orders status dropdown button")
    wait_for_all_elements_to_load_replace_value(orders_status_option, value, 'Orders Status Option')
    click_with_replace_value(orders_status_option, value, 'Orders Status Option')
    wait_for_spinner_off()


# This function is used to Select period from Orders Period dropdown
def select_period_from_orders_period_dropdown(value):
    wait_for_element_to_visible(orders_period_dropdown_btn, "Orders period dropdown button")
    wait_before_click(orders_period_dropdown_btn, "Orders period dropdown button")
    wait_for_all_elements_to_load_replace_value(orders_period_option, value, 'Orders Period Option')
    click_with_replace_value(orders_period_option, value, 'Orders Period Option')
    wait_for_spinner_off()


# Wait for order history page to load by validating orders row to be visible
def wait_for_order_history_page_to_load():
    wait_for_spinner_on()
    wait_for_spinner_off()
    select_period_from_orders_period_dropdown(mo_ui_test_data["allOrdersOption"])
    wait_for_element_to_visible(order_history_order_card, "at least one Order Card")


# Search order in Order history page
def search_order_in_history(order_no):
    # Wait to load the cards for first time
    wait_for_element_to_visible(order_history_order_card, "at least one Order Card")
    # search thr order
    type_value(search_order_path, order_no, "Search Order")
    # Waits for the spinner to appears
    wait_for_spinner_on()


# Get service name list from all rows
def get_all_rows_service_names():
    wait_for_spinner_off()
    return get_elements_texts(all_rows_service_names)


# Validate service names in searched results
def validate_service_names_in_searched_results(service_names):
    for name in service_names:
        logger.info("Name: {}".format(name))
        search_order_in_history(name)
        check.is_true(any(name in string for string in get_all_rows_service_names()))


def wait_for_status_completed(order_no):
    repeat = 5
    res = True
    search_order_in_history(order_no)
    while res and repeat > 0:
        wait_before_click(order_details_path, "Order Details")
        time.sleep(2)
        if get_element_text(order_status) in "Completed":
            res = False
        else:
            res = True
            repeat = repeat - 1
            time.sleep(2)


def wait_for_order_status_order_history(order_no, expected_status):
    repeat = 25
    res = True
    navigate_to_mo_launchpad_page()
    open_order_history_page()
    search_order_in_history(order_no)
    wait_for_spinner_off()
    while res and repeat > 0:
        wait_before_click(order_details_path, "Orders status")
        time.sleep(2)
        if get_element_text(order_status) in expected_status:
            res = False
        else:
            res = True
            repeat = repeat - 1
            time.sleep(2)
            navigate_to_mo_launchpad_page()
            open_order_history_page()
            search_order_in_history(order_no)
            wait_for_spinner_off()


def get_service_name(order_no):
    click_to_order_history()
    wait_for_spinner_off()
    search_order_in_history(order_no)
    wait_for_status_completed(order_no)
    click_to_order_history()
    search_order_in_history(order_no)
    wait_for_spinner_off()
    wait_before_click(order_details_path)
    # wait_before_click(order_details_path)
    return get_element_text(service_instance_name)


def click_action_btn(service_name=None):
    wait_for_spinner_off()
    if service_name:
        click_with_replace_value(action_btn_by_service, service_name, 'Action Button By Service')
    else:
        click(action_btn, "order history --> Service instance action button")


# The function validates additional parameter configuration on order history-->service details tab against test data
# file parameters
def get_service_details_config(is_editing=False, imi=None, edit_addtl_params_key='Edit Additional Parameters', version=None):
    additional_params_titles = get_elements_texts(adtnl_details_params_labels_txt)
    additional_params_values = get_elements_texts(adtnl_details_params_values_txt)
    actual_service_details_ui = dict(zip(additional_params_titles, additional_params_values))
    if is_editing:
        addtnl_params_json_dic_data = merge_edit_additional_parameters(edit_addtl_params_key)
    else:
        addtnl_params_json_dic_data = get_data_object("Additional Parameters")
    for key, actual_value in actual_service_details_ui.items():
        expected_value = get_value(addtnl_params_json_dic_data["Additional Parameters"], key)
        if expected_value is not None:
            # Validates if the expected value is a list of values (multiselect options) and format the values
            if type(expected_value) == list:
                expected_value, actual_value = format_detail_multiple_values(expected_value, actual_value)
            # Validates the value in case the title exists more than one time
            if additional_params_titles.count(key) > 1:
                for idx, title in enumerate(additional_params_titles):
                    if title == key and additional_params_values[idx] in expected_value:
                        actual_value = additional_params_values[idx]
                        break
            check.is_in(actual_value.lower(), expected_value.lower(), key)
        else:
            # Validates if the label is present more than one time, in JSON the key must be
            # eg. "key[0]": "value" in the same step object
            for _, data in addtnl_params_json_dic_data["Additional Parameters"].items():
                for param, param_obj in data.items():
                    if key in param:
                        expected_value = param_obj.get('value')
                        actual_value = check_repeated_label_values(param, expected_value, None,
                                                                        additional_params_titles, additional_params_values)
                        if actual_value:
                            check.is_in(actual_value.lower(), expected_value.lower(), param)
    if imi:
        # Validate Add On Details
        click(add_on_details_btn, "Add On Details button")
        add_on_details = dict(zip(get_elements_texts(add_on_labels), get_elements_texts(add_on_values)))
        check.equal(add_on_details["Management level"], imi_config_test_data["Management level"], "Management level")
        check.equal(add_on_details["Plan level"], imi_config_test_data["BillingPlan"], "Plan level")
        check.equal(add_on_details["Provider"], imi_config_test_data["imi_provider"], "IMI Provider")
        check.equal(add_on_details["Service Offering Name"], get_data("IMI Service offering"), "IMI Service offering")
    # Validates version
    if version:
        check.equal(version, get_element_text(kyndryl_version_text_order_history_page), 'mo Version')


def close_service_details_slider():
    click(close_service_details_btn, "Close button")


# The function validates estimated price, BOM and service configuration  on order history page
def validate_service_details_bill_of_materials(exp_estimated_cost, config_name, is_editing=False, service_name=None, imi=None,
                                               edit_addtl_params_key='Edit Additional Parameters', version=None, skip_total_calc=False):
    if imi:
        check.equal(get_element_text(imi_addon_text), imi_config_test_data["imi_add_on"], "IMI tag text")
    click_action_btn(service_name)
    if config_name == "Service Details":
        click_using_java_script(service_details_btn, "order history -->Service Details")
        get_service_details_config(is_editing, imi, edit_addtl_params_key, version)
        click_index_based(bill_of_materials_service_details_btn, 0, "Bill Of Materials")
    elif config_name == "Bill Of Materials":
        click_using_java_script(bill_of_materials_btn, "order history -->Bill of Materials")
    estimated_cost = get_element_text(estimated_cost_txt)

    # Monthly Cost and One time cost calculation
    if not skip_total_calc:
        click_using_java_script(more_link, "More link")
        monthly_cost = sum_totals_by_locator(monthly_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
        one_time_cost = sum_totals_by_locator(one_time_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
        logger.info(f"Monthly Cost: {monthly_cost}")
        logger.info(f"One time Cost: {one_time_cost}")
        total_sum = sum_string_totals([monthly_cost, one_time_cost], exp_estimated_cost)
        logger.info(f"Total Sum Cost: {total_sum}")
        logger.info(f"Estimated Cost: {estimated_cost}")
        check.equal(estimated_cost, total_sum, 'Monthly Cost and One Time Cost')
    logger.info(f"Exp Estimated Cost: {exp_estimated_cost}")
    check.equal(estimated_cost, exp_estimated_cost, 'Total Cost')
    close_service_details_slider()


# Click on Order details link from order row
def click_on_order_details_link():
    click(first_order_details_link, "Order details link")
    wait_for_spinner_off()


# Validate order details tab info specific to Hill-30 scenario
def validate_order_details_tab_info(order_status):
    wait_for_element_to_visible(order_details_tab, "Order details tab")
    click(order_details_tab, "Order details tab")
    check.not_equal(get_element_text_replace_value(order_details_left_value, mo_ui_test_data["orderIdLabel"], "Order details left"), None, "Order ID")
    check.not_equal(get_element_text_replace_value(order_details_left_value, mo_ui_test_data["orderTotalLabel"], "Order details left"), None, "Order Total")
    check.not_equal(get_element_text_replace_value(order_details_left_value, mo_ui_test_data["createdDateLabel"], "Order details left"), None, "Created Date")
    check.not_equal(get_element_text_replace_value(order_details_left_value, mo_ui_test_data["orderTypeLabel"], "Order details left"), None, "Order Type")
    check.equal(get_element_text_replace_value(order_details_left_value, mo_ui_test_data["orderStatusLabel"], "Order details left"), order_status, "Order Status")
    check.equal(get_element_text_replace_value(order_details_right_value, mo_ui_test_data["teamLabel"], "Order details right"), mo_ui_test_data["teamHackathon"], "Order Team")
    check.equal(get_element_text_replace_value(order_details_right_value, mo_ui_test_data["orgLabel"], "Order details right"), mo_ui_test_data["orgABC"], "Order Organization")


# Get submitted by timestamp from Order updates tab
def get_submitted_by_timestamp_from_order_updates():
    timestamp_text = get_element_text(submitted_on_timestamp_text)
    timestamp = timestamp_text.split("on ")[1]
    logger.info("Timestamp for submitted by: {}".format(timestamp))
    return timestamp


# Get approval status from Order updates tab
def get_approval_status_from_order_updates(approval_type):
    status = get_element_text_replace_value(order_approve_status, approval_type, "Order approve status")
    logger.info("Order status for "+approval_type+" approval: "+status)
    return status


# Click Order updates tab button
def click_on_order_updates_tab():
    wait_for_element_to_visible(order_updates_tab_button, "Order updates tab")
    click(order_updates_tab_button, "Order updates tab")


# Validate Order updates tab info
def validate_order_updates_tab_info():
    click_on_order_updates_tab()
    check.not_equal(get_element_text(submitted_by_username_text), None, "Submitted by username")
    check.not_equal(get_submitted_by_timestamp_from_order_updates(), None, "Submitted by timestamp")


# Validate approval details using order status specific to Hill-30 scenario
def validate_approval_details_using_order_status(order_status):
    tech_status = get_approval_status_from_order_updates(mo_ui_test_data["technicalApprovalLabel"])
    fin_status = get_approval_status_from_order_updates(mo_ui_test_data["financialApprovalLabel"])

    if order_status == mo_ui_test_data["approvalInProgState"]:
        check.equal(tech_status, mo_ui_test_data["approveStatusPending"], "Technical Approval Status")
        check.equal(fin_status, mo_ui_test_data["approveStatusApproved"], "Financial Approval Status")
        expand_approval_type_tile(mo_ui_test_data["technicalApprovalLabel"])
        tech_details = get_element_text_replace_value(approval_type_approvers_details, mo_ui_test_data["technicalApprovalLabel"], "Approval type approvers details")
        check.is_in(mo_ui_test_data["approversDetailsHeader"], tech_details, "Approvers Details Header")
        check.is_in(mo_ui_test_data["approversDetailsMsg"], tech_details, "Approvers Details Message")
        expand_approval_type_tile(mo_ui_test_data["financialApprovalLabel"])
        fin_details = get_element_text_replace_value(approval_type_approvers_details, mo_ui_test_data["financialApprovalLabel"], "Approval type approvers details")
        check.is_in(mo_ui_test_data["approvedDetailsHeader"], fin_details, "Approved Details Header")

    elif order_status == mo_ui_test_data["approveStatusRejected"]:
        check.equal(tech_status, mo_ui_test_data["approveStatusRejected"], "Technical Approval Status")
        check.equal(fin_status, mo_ui_test_data["approveStatusApproved"], "Financial Approval Status")
        expand_approval_type_tile(mo_ui_test_data["technicalApprovalLabel"])
        tech_details = get_element_text_replace_value(approval_type_approvers_details, mo_ui_test_data["technicalApprovalLabel"], "Approval type approvers details")
        check.is_in(mo_ui_test_data["rejectedDetailsHeader"], tech_details, "Rejected Details Header")
        check.is_in(mo_ui_test_data["rejectedDetailsMsg"], tech_details, "Rejected Details Message")
        expand_approval_type_tile(mo_ui_test_data["financialApprovalLabel"])
        fin_details = get_element_text_replace_value(approval_type_approvers_details, mo_ui_test_data["financialApprovalLabel"], "Approval type approvers details")
        check.is_in(mo_ui_test_data["approvedDetailsHeader"], fin_details, "Approved Details Header")

    elif order_status == mo_ui_test_data["completedState"]:
        check.equal(tech_status, mo_ui_test_data["approveStatusApproved"], "Technical Approval Status")
        check.equal(fin_status, mo_ui_test_data["approveStatusApproved"], "Financial Approval Status")
        expand_approval_type_tile(mo_ui_test_data["technicalApprovalLabel"])
        tech_details = get_element_text_replace_value(approval_type_approvers_details, mo_ui_test_data["technicalApprovalLabel"], "Approval type approvers details")
        check.is_in(mo_ui_test_data["approvedDetailsHeader"], tech_details, "Approved Details Header")
        expand_approval_type_tile(mo_ui_test_data["financialApprovalLabel"])
        fin_details = get_element_text_replace_value(approval_type_approvers_details, mo_ui_test_data["financialApprovalLabel"], "Approval type approvers details")
        check.is_in(mo_ui_test_data["approvedDetailsHeader"], fin_details, "Approved Details Header")


# Close order details slider window
def close_order_details_slider_window():
    if is_element_present(order_details_close_slider_button, "Close order details slider window"):
        click(order_details_close_slider_button, "Close order details slider window")


# Click on cancel order button
def click_on_cancel_order_button():
    wait_for_spinner_off()
    wait_for_element_to_visible(cancel_order_button, "Cancel order button")
    click(cancel_order_button, "Cancel order button")


# Search, cancel order and validate messages
def search_order_cancel_and_validate_messages(order_no):
    search_order_in_history(order_no)
    click_on_cancel_order_button()
    check.equal(get_element_text(cancel_order_modal_text), get_data("cancelOrderMsg"),
                "Cancel order modal text")
    click(cancel_order_modal_yes_button, "Cancel order yes button")
    wait_for_element_to_visible(cancel_order_modal_ok_button, "Cancel order ok buton")
    check.is_in(get_data("cancelOrderSuccessMsg"), get_element_text(cancel_order_modal_success_msg),
                "Cancel order modal success msg")
    check.is_in(order_no, get_element_text(cancel_order_modal_success_msg), "Cancel order modal success msg")
    click(cancel_order_modal_ok_button, "Cancel order ok button")


# Validate Order status and label color for searched order
def validate_order_status_and_color(status, color):
    check.is_in(color, get_attribute_value(first_order_status_text, "class"), "Order label color")
    check.equal(status, get_element_text(first_order_status_text).strip(), "Order label status text")


def cancel_scenario_place_order(order_no, expected_status):
    click_to_order_history()
    wait_for_spinner_off()
    search_order_in_history(order_no)
    click_cancel_order_button()
    click_on_place_order_cancelyes_button()
    click_cancel_order_ok_button()
    wait_for_order_status_order_history(order_no, expected_status)
    check.is_in(expected_status, get_element_text(order_status), "Order is successfully canceled : ")


def cancel_scenario_for_failed_order(order_no, expected_status):
    click_to_order_history()
    wait_for_spinner_off()
    search_order_in_history(order_no)
    wait_for_spinner_off()
    click_on_order_table_details_expand_arrow()
    click_action_btn()
    click_cancel_order_button()
    click_order_table_actions_cancel_yes_button_for_place_order()
    click_cancel_order_ok_button()
    wait_for_order_status_order_history(order_no, expected_status)
    check.is_in(expected_status, get_element_text(order_status_in_table), "Order is successfully canceled : ")


# Validate order updates tab info
def click_cancel_order_button():
    wait_for_spinner_off()
    cancel_button_present = is_element_present(buttonCancel, "cancel button")
    explicit_wait(2)
    if cancel_button_present:
        wait_before_click(buttonCancel, "cancel button")
    else:
        wait_before_click(order_table_actions_cancel, "cancel button")


def click_order_table_actions_cancel_yes_button_for_place_order():
    wait_for_element_to_visible(order_table_actions_cancelyes_btn_for_place_order, "cancel's yes option")
    click(order_table_actions_cancelyes_btn_for_place_order, "cancel's yes option")


def click_on_order_table_details_expand_arrow():
    wait_for_spinner_off()
    wait_for_element_clickable(order_table_details_expand_arrow, "Order details expand arrow")
    time.sleep(1)
    click(order_table_details_expand_arrow, "Expanded the row")


def click_on_place_order_cancelyes_button():
    cancel_button_yes_present = is_element_present(order_table_actions_cancelyes_btn, "Cancel yes option")
    if cancel_button_yes_present:
        wait_before_click(order_table_actions_cancelyes_btn, "Cancel yes option")
    else:
        wait_before_click(order_table_actions_cancelyes_btn_for_place_order, "Cancel yes option")


def click_cancel_order_ok_button():
    cancel_button_for_failed_order_present = check_element_exists(button_cancel_order_ok_for_failed_order)
    if cancel_button_for_failed_order_present:
        wait_before_click(button_cancel_order_ok_for_failed_order, "Cancel's OK option for failed order")
    else:
        wait_before_click(button_cancel_order_ok, "Cancel's OK option for placed order")


def click_on_order_table_actions_retry():
    wait_for_element_to_visible(order_table_actions_retry_option, "Retry option")
    wait_before_click(order_table_actions_retry_option, "Retry option")


def click_retry_order_ok_button_for_failed_order():
    wait_for_element_to_visible(modal_retry_order, "Click Retry Modal")
    wait_before_click(modal_retry_order, "Click Retry Modal")
    wait_for_element_to_visible(button_retry_order_ok, "Retry's OK Button")
    wait_before_click(button_retry_order_ok, "Retry's OK Button")


def retry_order_and_wait_for_failed(order_no, expected_status):
    wait_for_spinner_off()
    retry_order(order_no)
    click_retry_order_ok_button_for_failed_order()
    wait_for_order_status_order_history(order_no, expected_status)
    check.is_in(expected_status, get_element_text(order_status), "Order status is : ")

def retry_order_and_edit_service(order_no):
    retry_order(order_no)
    click_retry_order_edit_button()
    wait_for_spinner_off()
    check.is_in(get_element_text(retry_order_breadcrumb_txt), 'Retry Order', 'Retry Order Breadcrumb Text')


def click_retry_order_edit_button():
    click(retry_order_edit_btn, 'Retry Edit Button')


def check_retry_order_button_status(order_no):
    click_to_order_history()
    wait_for_spinner_off()
    search_order_in_history(order_no)
    wait_for_spinner_off()
    click_on_order_table_details_expand_arrow()
    click_action_btn()
    status = is_element_enable(order_table_actions_retry_option, "Retry Order Button")
    if status == True:
        logger.info("Retry button is enabled")
        return mo_ui_test_data["enabledLabel"]
    elif status == False:
        logger.info("Retry button is disabled")
        return mo_ui_test_data["disabledLabel"]


def execute_before_retry(order_no):
    while check_retry_order_button_status(order_no) != "Enabled":
        time.sleep(1)


def retry_order(order_no):
    execute_before_retry(order_no)
    click_to_order_history()
    wait_for_spinner_off()
    search_order_in_history(order_no)
    wait_for_spinner_off()
    click_on_order_table_details_expand_arrow()
    click_action_btn()
    click_on_order_table_actions_retry()
    check.is_in(get_element_text(retry_modal_header_txt), mo_ui_test_data['retryModalHeader'], 'Retry Modal Header')
    check.is_in(get_element_text(retry_modal_edit_msg), mo_ui_test_data['retryModalEditMsg'], 'Retry Modal Edit Msg')
    check.is_in(get_element_text(retry_modal_edit_note), mo_ui_test_data['retryModalEditNote'], 'Retry Modal Edit Note')


def open_service_details_bom(config_name, service_name):
    click_action_btn(service_name)
    if config_name == "Service Details":
        click_using_java_script(service_details_btn, "order history -->Service Details")
    elif config_name == "Bill Of Materials":
        click_using_java_script(bill_of_materials_btn, "order history -->Bill of Materials")



def get_service_details_ui():
    additional_params_titles = get_elements_texts(adtnl_details_params_labels_txt)
    additional_params_values = get_elements_texts(adtnl_details_params_values_txt)
    service_details_ui = dict(zip(additional_params_titles, additional_params_values))
    return service_details_ui


def validate_bom(exp_estimated_cost):
    # Validate Bill of Materials
    click_index_based(bill_of_materials_service_details_btn, 1, "Bill Of Materials")
    estimated_cost = get_element_text(estimated_cost_txt)
    click_using_java_script(more_link, "More link")
    # Monthly Cost and One time cost calculation
    monthly_cost = sum_totals_by_locator(monthly_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
    one_time_cost = sum_totals_by_locator(one_time_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
    total_sum = sum_string_totals([monthly_cost, one_time_cost], exp_estimated_cost)
    check.equal(estimated_cost, exp_estimated_cost, 'Total Cost')
    check.equal(estimated_cost, total_sum, 'Monthly Cost and One Time Cost')
    close_service_details_slider()


def get_service_status(service_name, add_on=False):
    explicit_wait(5)
    click_with_replace_value(expand_service_name_arrow, service_name, "arrow icon")
    wait_for_spinner_off()
    if add_on:
        status = get_element_text_replace_value(status_service_name_addon_text, service_name, "Order Status")
    else:
        status = get_element_text_replace_value(status_service_name_text, service_name, "Order Status")
    return status


def view_failures():
    click(view_failure_link, "View Failures")
    wait_for_spinner_off()
    failure_reason = get_element_text(failure_reason_text)
    return failure_reason


def validate_multi_qty_status(order_no,multi_qty):
    click_to_order_history()
    wait_for_spinner_off()
    search_order_in_history(order_no)
    wait_for_spinner_off()
    click_on_order_table_details_expand_arrow()
    counter = int(multi_qty)
    for i in range(1,counter + 1):
        order_index = str(i)
        order_value = get_element_text_replace_value(multiqty_order_status, order_index, "Order index")
        if order_value == "Completed":
            logger.info(str(i) +" Order status is : " + order_value)
            explicit_wait(5)
        else:
            logger.info(str(i) + " Order status is : " + order_value)


def get_service_details_provider(order_id):
    search_order_in_history(order_id)
    click_action_btn()
    click_using_java_script(service_details_btn, "order history -->Service Details")
    provider = get_element_text(service_details_provider_name)
    close_service_details_slider()
    return provider


# Search Pattern order in Order history page
def search_pattern_order_in_history(order_no):
    # Wait to load the cards for first time
    click_on_all_patterns_tab()
    wait_for_element_to_visible(order_history_order_card, "at least one Order Card")
    # search the order
    type_value(search_order_path, order_no, "Search Order")
    # Waits for the spinner to appears
    wait_for_spinner_on()


def validate_pattern_details_bill_of_materials(exp_estimated_cost, config_name, is_editing=False, service_name=None,
                                               imi=None,
                                               edit_addtl_params_key='Edit Additional Parameters', version=None,
                                               skip_total_calc=False):
    if imi:
        check.equal(get_element_text(imi_addon_text), imi_config_test_data["imi_add_on"], "IMI tag text")
    click_action_btn(service_name)
    if config_name == "Pattern Details":
        click_using_java_script(pattern_details_btn, "order history -->Pattern Details")
        get_service_details_config(is_editing, imi, edit_addtl_params_key, version)
        click_using_java_script(bill_of_materials_pattern_details_btn, "Bill Of Materials")
    elif config_name == "Bill Of Materials":
        click_using_java_script(bill_of_materials_btn, "order history -->Bill of Materials")
    estimated_cost = get_element_text(estimated_cost_txt)

    # Monthly Cost and One time cost calculation
    if not skip_total_calc:
        click_using_java_script(more_link, "More link")
        monthly_cost = sum_totals_by_locator(monthly_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
        one_time_cost = sum_totals_by_locator(one_time_cost_bom_table_txt, exp_estimated_cost, round_next_dec=False)
        logger.info(f"Monthly Cost: {monthly_cost}")
        logger.info(f"One time Cost: {one_time_cost}")
        total_sum = sum_string_totals([monthly_cost, one_time_cost], exp_estimated_cost)
        logger.info(f"Total Sum Cost: {total_sum}")
        logger.info(f"Estimated Cost: {estimated_cost}")
        check.equal(estimated_cost, total_sum, 'Monthly Cost and One Time Cost')
    logger.info(f"Exp Estimated Cost: {exp_estimated_cost}")
    check.equal(estimated_cost, exp_estimated_cost, 'Total Cost')
    click(close_pattern_details_btn, "Close button")


def validate_retry_order(service_name, order_no):
    click_to_order_history()
    search_pattern_order_in_history(order_no)
    click_action_btn(service_name)
    click_using_java_script(retry_button, "Retry")
    check.is_in(get_element_text(retry_confirm), get_data("retryPatternOrder"), "Retry Success")
    click_using_java_script(retry_button, "Retry button")
    check.is_in(get_element_text(retry_success_msg), get_data("retrySuccessMsg"), "Retry Success")
    # click_to_order_history()
    # search_pattern_order_in_history(order_no)
    # order_status = get_element_text(order_history_order_status_text).strip()
    order_status = get_element_text(order_history_order_status_text)
    assert get_element_text(order_id) == order_no
    # Validate order status to be 'Provisioning In Progress'
    try:
        assert order_status == mo_ui_test_data["provInProgressState"]
    except AssertionError:
    # If server is so quick, validate complete status
        assert order_status == mo_ui_test_data["completedState"]
    # Wait and validate order status to be 'Completed'
    order_status_text = wait_for_order_status_on_order_history(order_no, mo_ui_test_data["completedState"])
    assert order_status_text == mo_ui_test_data["completedState"]


def wait_for_order_status_on_order_history(order_no, expected_status, counter=300):
    res = True
    current_status = ""
    while res and counter > 0:
        current_status = get_element_text(order_history_order_status_text)
        if current_status == mo_ui_test_data["failedState"] or current_status == mo_ui_test_data[
            "submissionFailed"] or current_status == "Completed with Failure":
            logger.info("Order status is " + current_status)
            res = False
        else:
            if current_status == expected_status:
                logger.info("Order is in expected status; Order status: " + expected_status)
                res = False
            else:
                logger.info("Current status: " + current_status + "; Expected status: " + expected_status)
                click_to_order_history()
                search_pattern_order_in_history(order_no)
                # wait_for_spinner_off()
                # wait_for_order_present(order_no)
                time.sleep(2)
                counter = counter - 1
    return current_status
