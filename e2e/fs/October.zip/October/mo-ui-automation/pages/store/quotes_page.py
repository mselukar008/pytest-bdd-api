from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_json_utils import get_data
from helpers.mo_page_operations import switch_to_iframe
from locators.common.navigation_page_locator import mo_iframe_xpath
from locators.store.quotes_page_locator import *
from helpers.mo_check import mo_check as check


def verify_new_quote(quote_name):
    wait_for_spinner_off()
    is_element_present_replace_value(quote_name_text, quote_name)


def get_quote_status(quote_name):
    status = get_element_text_replace_value(quote_status_text, quote_name, "Quote Status")
    return status


def click_quote_menu_icon(quote_name):
    click_with_replace_value(quote_menu_btn, quote_name, "Quote Menu")


def view_details(quote_name):
    click_quote_menu_icon(quote_name)
    click_with_replace_value(quote_menu_options_btn, "View Details", "View Details")
    wait_for_spinner_off()


def edit_quote_item():
    scroll_element_into_view(quote_item_menu)
    click(quote_item_menu, "Quote Item Menu")
    click(edit_quote_item_btn, "Edit Quote Item")
    wait_for_spinner_off()
    switch_to_iframe(mo_iframe_xpath)
    wait_for_spinner_off()


def close_view_details_slider_window():
    wait_before_click(close_slider_window_btn, "Close Order details slider window")

def verify_service_details():
    scroll_element_into_view(quote_item_menu)
    click(quote_item_menu, "Quote Item Menu")
    click(view_service_details_btn, "View Service Details")
    wait_for_spinner_off()
    check.is_in(get_element_text_replace_value(service_details_label_value, "Aws region", "Region"),
                get_data("updated_region"))
    close_view_details_slider_window()
    click(quotes_link, "Quotes")
    wait_for_spinner_off()


def move_to_review(quote_name):
    click_quote_menu_icon(quote_name)
    click_using_script_replace_value(quote_menu_options_btn, "Move to Review", "Move to Review")
    wait_for_spinner_off()


def move_to_ready(quote_name):
    click_quote_menu_icon(quote_name)
    click_using_script_replace_value(quote_menu_options_btn, "Move to Ready", "Move to Ready")
    click(continue_btn, "Continue")
    wait_for_spinner_off()


def make_inactive(quote_name):
    click_quote_menu_icon(quote_name)
    click_using_script_replace_value(quote_menu_options_btn, "Make Inactive", "Make Inactive")
    click(continue_btn, "Continue")
    wait_for_spinner_off()


def delete_quote(quote_name):
    click_quote_menu_icon(quote_name)
    click_using_script_replace_value(quote_menu_options_btn, "Delete", "Delete")
    click(delete_btn, "Delete")
    wait_for_spinner_off()



