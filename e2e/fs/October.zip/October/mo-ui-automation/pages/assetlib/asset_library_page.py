from helpers.mo_page_operations import switch_to_iframe, refresh_current_page
from locators.assetlib.assetlibrary_locator import *
from locators.common.navigation_page_locator import mo_iframe_xpath
from pages.store.catalog_page import *
from pages.store.mo_store_utils import get_filtered_data
from tests.common_test import delete_all_downloaded_files

assetlib_data_path = os.path.join(assetlib_data_path, "assetlibrary.json")


def validate_title_on_asset_library_page():
    wait_for_spinner_off()
    wait_for_element_to_visible(asset_library_title_text, "Asset Library Page title")
    check.is_true(is_element_present(asset_library_title_text, "Asset Library text"), "Asset Library Page title")


def click_on_view_quick_links():
    click_using_java_script(view_quick_links, "View Quick Links")
    wait_for_element_to_visible(quick_links_section, "Quick links section")


def click_on_edit_template():
    click_using_java_script(edit_details_button, "Edit Details button")


def click_on_known_issue_link():
    click_using_java_script(view_issue_report, 'view issue report')


def edit_details(value1, value2):
    scroll_element_into_view_with_replace_value(readiness_dropdown, value1)
    select_option_from_dynamic_listbox(readiness_dropdown, value1, 'Readiness for production')
    scroll_element_into_view_with_replace_value(label_dropdown, value2)
    select_option_from_dynamic_listbox(label_dropdown, value2, 'Template Label')
    click_using_java_script(save_button, "save button")


def click_on_save_button():
    scroll_element_into_view(save_button)
    click_using_java_script(save_button, "Save button")


def validate_quick_links():
    check.is_true(is_element_present(service_catalog, "service catalog"), "service catalog in quick links")
    check.is_true(is_element_present(official, "official"), "official in quick links")
    check.is_true(is_element_present(partner, "partner"), "partner in quick links")
    check.is_true(is_element_present(community, "community"), "community in quick links")


def validate_explore_catalog():
    click_using_java_script(explore_catalog_link, "explore catalog Link")
    wait_for_spinner_off()
    switch_to_iframe(mo_iframe_xpath)
    check.is_true(is_element_present(catalog_page_title, "catalog text"), "catalog Page title")


def validate_explore_templates(title):
    wait_for_element_to_visible(quick_links_section, "Quick links section")
    click_with_replace_value(explore_templates_link_based_on_title, title, "explore catalog Link")
    check.equal(title, get_element_text(applied_label), "applied label")
    click_on_view_quick_links()


def validate_applied_filter(title):
    click_with_replace_value(label, title, "selected label")
    check.equal(title, get_element_text(applied_label), "applied label")
    check.equal(title, get_element_text_replace_value(service_label, title, "applied label"))


def add_template_fill_parameters(data_key):
    template_data = get_data(data_key)
    for key, data in template_data.items():
        if key in "File to Upload":
            data["value"] = os.path.join(resource_folder, "assetlib", "testdata", data["value"])
        get_filtered_data(data, key)


def click_on_add_template():
    click_using_java_script(download_add_template_button, 'Add Template')


def click_technology_type(technology):
    logger.info(f"Technology Name: {technology}")
    # scroll_element_into_view_with_replace_value(category_path, category)
    click_using_script_no_wait_replace_value(technology_path, technology, 'Technology Type')
    wait_for_spinner_on()
    wait_for_spinner_off()


def select_template(path):
    set_data_path(path)
    click(filter_close_button, "Search filter close button")
    select_provider_type(get_data("Provider"))
    # click(filter_close_button, "Search filter close button")
    click_technology_type(get_data("Technology"))
    click(filter_close_button , "Search filter close button")
    click_service_name(get_data("TemplateName"))
    wait_for_spinner_off()


def download_template():
    delete_all_downloaded_files()
    click_using_java_script(download_button, "download")
    check.equal(get_element_text(success_notification), get_data("download_notification"), 'Download success message')


def click_on_export_all_button():
    click_using_java_script(export_all_button, "export all button")
    # Static wait to download zip file completely
    time.sleep(10)


def is_file_downloaded():
    # logger.info(os.listdir())
    logger.info(os.listdir(output_folder))
    if any(File.endswith(".zip") for File in os.listdir(output_folder)):
        logger.info("File is downloaded")
        return True
    else:
        logger.info("File not found")
        return False


def get_reliability_details():
    # scroll_element_into_view(first_entry_table)
    reliability_details = get_elements_texts(details_title)
    for key in reliability_details:
        logger.info(f"reliability values: {key}")


def search_added_template_on_dashboard(path):
    set_data_path(path)
    select_provider_type(get_data("addedProvider"))
    click_technology_type(get_data("addedTechnology"))
    click(filter_close_button, "Search filter close button")
    click_service_name(get_data("editedTemplate"))
    explicit_wait(2)
    # wait_for_spinner_off()


def validate_readiness_details(value):
    labels = get_elements_texts_replace_value(readiness, value)
    for key in labels:
        if key == value:
            logger.info(f"labels are get edited with: {key}")


def validate_label_details(value):
    labels = get_elements_texts_replace_value(applied_label_details, value)
    for key in labels:
        if key == value:
            logger.info(f"labels are get edited with: {key}")


def edit_fill_parameters(data_key):
    template_data = get_data(data_key)
    for key, data in template_data.items():
        get_filtered_data(data, key)


# validate success message from Notification
def validate_success_message_from_notification():
    # explicit_wait(300)
    # wait for 5 minutes and keep clicking on a button to avoid session timeout
    for i in range(30):
        refresh_current_page()
        time.sleep(10)
    # Open notification side panel
    click(notification_button, "Notification icon button")
    check.is_in(get_element_text(notification_info), get_data("notificationInfo"))
    # Close notification side panel
    click(notification_button, "Notification icon button")


def clear_notification():
    explicit_wait(2)
    click(notification_button, "Notification icon button")
    if is_element_present(clear_notification_button, "clear button"):
        click_using_java_script(clear_notification_button, "clear button")
    click(notification_button, "Notification icon button")
