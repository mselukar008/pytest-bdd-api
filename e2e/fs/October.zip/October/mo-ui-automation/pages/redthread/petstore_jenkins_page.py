from helpers.mo_element_operations import *
from helpers.mo_element_validation import *
from helpers.mo_json_utils import *
from locators.redthread.jenkins_locator import *
from helpers.mo_check import mo_check as check
from mo_encryption_decryption import decrypt_password

petstore_data_path = os.path.join(redthread_data_path, "petstore_data.json")


def login_to_jenkins():
    set_data_path(petstore_data_path)
    driver.get(get_data("jenkins_url"))
    password = get_data("jenkins_password")
    decrypted_password = decrypt_password(password)
    type_value(username_textbox, get_data("jenkins_username"), "Username")
    type_value(password_textbox, decrypted_password, "Password")
    click(sign_in_btn, "Sign In")


def open_petstore_job():
    click(petstore_job_link, "Petstore Job")


def open_new_build_console_output_and_get_id():
    # global build_id
    before_new_build = get_elements_count(job_builds_link)
    counter = 20
    i = 0
    while i < counter:
        explicit_wait(60)
        driver.refresh()
        after_refresh_build = get_elements_count(job_builds_link)
        if after_refresh_build > before_new_build:
            logger.info("New Pet Store build completed")
            explicit_wait(3)
            # build_id = get_element_text(job_build_id)
            click_index_based(job_builds_link, 0, "New build")
            while is_element_present(build_status_icon, "Build In Progress"):
                explicit_wait(3)
                logger.info("Build is in progress")
                driver.refresh()
            click(console_output_link, "Console Output")
            i = counter
        else:
            logger.info("New Pet Store build is not triggered")
            i += 1


def get_console_output_logs():
    console_logs = get_element_text(console_logs_text)
    return console_logs


def validate_console_output_logs(console_logs):
    check.is_in(console_logs, "Finished: SUCCESS", "logs")
    check.is_in(console_logs, "BUILD SUCCESSFUL", "logs")
    check.is_in(console_logs, "Build publishment status code : 200", "logs")
    check.is_in(console_logs, "Test publishment status code : 200", "logs")
    check.is_in(console_logs, "Deploy publishment status code : 200", "logs")
    check.is_in(console_logs, "Monitoring successfully installled", "logs")