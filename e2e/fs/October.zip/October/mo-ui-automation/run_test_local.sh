#!/bin/bash
VIRTUAL_ENV_NAME=venv
if [[ "$OSTYPE" == "darwin"* ]]; then
    source $VIRTUAL_ENV_NAME/bin/activate
else
    source $VIRTUAL_ENV_NAME/scripts/activate
fi
echo '#### Run tests ####'
suit_list=$(grep "mo.suitlist" config.ini);
suit_list=${suit_list#*=}
echo $suit_list
suit_name=""

if [ -z "$suit_list" ]; then
  echo "Execute all tests"
else
    suit_arr=($(echo "$suit_list" | tr ";" "\n"))
    for i in "${suit_arr[@]}"
    do
      # shellcheck disable=SC2116
      suit_name+=$(echo "tests/store/$i ")
    done
fi
echo $suit_name
pytest -vv -rA $suit_name
deactivate
