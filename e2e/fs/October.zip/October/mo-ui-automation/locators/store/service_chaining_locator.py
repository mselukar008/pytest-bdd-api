from helpers.mo_base_locator import *


service_chaining_title = (xpath, "//h1[normalize-space()='Service Chaining']")
options_button = (xpath, "//ibm-tile[@title='{0}']//button[@aria-label='Overflow']")
action_button_based_on_pattern_name = (xpath, "//*[@class='bx--overflow-menu-options__btn ']//*[contains(text(),'{1}')]/parent::button")
created_pattern_text = (xpath, "(//div[@title='{0}'])[1]")
all_patterns = (xpath, "//*[@class='pattern-name']")
first_pattern = (xpath, "(//div/pattern-tile//div)[1]")
next_button = (xpath, "//span[normalize-space()='Next']/..")
tabs_path = (xpath, "//button[contains(text(),'{0}')]")
prefix = (xpath, "//input[@placeholder='Please insert Pattern Instance Prefix']")
order_num_text = (xpath, "//*[normalize-space()='Order Number :']/..")









