from helpers.mo_base_locator import *

new_policy_btn = (css_selector, "#addPolicy")
start_date = (css_selector, "#date--range-picker-from-duration")
start_date_picker = (xpath, '//div[@class="dayContainer"]/span[@class = "flatpickr-day today"]')
apply_rule_btn = (css_selector, "#applyRule")
policy_rule_text = (css_selector, "[class='cell--truncate bx--tooltip__trigger']")
create_policy_btn = (xpath, '//button[normalize-space()="Create Policy"]')
notification_text = (css_selector, '.bx--toast-notification__subtitle')
notification_close_icon = (css_selector, '.bx--toast-notification__close-icon')
search_textbox = (css_selector, '.bx--search-input')
action_icon = (css_selector, '.bx--overflow-menu__icon')
edit_policy_btn = (xpath, '//button[normalize-space()="Edit Policy"]')
retired_radiobutton = (xpath, '//label[normalize-space()="Retired"]')
update_policy_btn = (css_selector, '#submitPolicy')
delete_policy_btn = (xpath, '//button[normalize-space()="Delete"]')
delete_confirmation_btn = (css_selector, '#approval-policy-component-delete-modal_carbon-button_ok')
no_data_text = (xpath, '//strong[contains(text(),"No Data Available")]')
add_rule_btn = (css_selector, "#rulesTable + lib-app-rule-panel + button")
values_dropdown = (css_selector, "[id^=dropdown-option__]")
external_dropdown = (css_selector, '#bx--dropdown-single-parent_legalexternal, '
                                   '#bx--dropdown-single-parent_financialexternal, '
                                   '#bx--dropdown-single-parent_technicalexternal')
external_dropdown_value = (css_selector, '[id^="dropdown-option_legalexternal_s"], '
                                         '[id^="dropdown-option_financialexternal_s"], '
                                         '[id^="dropdown-option_technicalexternal_s"], '
                                         '[id="dropdown-option_technicalexternal_itsm"], '
                                         '[id="dropdown-option_legalexternal_itsm"], '
                                         '[id="dropdown-option_financialexternal_itsm"]')
policy_row = (css_selector, "tbody tr.bx--table-row.bx--parent-row")
policy_status_text = (css_selector, "tr td:nth-child(3) span")

