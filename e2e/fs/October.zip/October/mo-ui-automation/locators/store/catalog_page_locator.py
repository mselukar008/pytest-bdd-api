from helpers.mo_base_locator import *

category_path = (xpath, "//span[contains(text(), '{}')]")
provider_path = (xpath, "//span[contains(text(), '{}')]")
service_name_path = (xpath, "//h3[normalize-space()='{}']")
custom_service_name_path = (xpath, "//*[contains(@class,'{}')]")
configure_btn_path = (css_selector, "#configure-service, #configure-service-btn, #configure-pattern-btn")
generate_quote_btn_path = (css_selector, "#generate-quote-btn")
team_path = (xpath, "//span[normalize-space()='{}']")
account_path = (xpath, "//label[@for='radio-button-providerAccount_AWSQA-TEAM1_/ AWSQA-TEAM1']//span[@class='bx--radio-button__appearance']")
service_name_id = (id, "text-input-main_params-serviceName")
select_label_dropdown = (css_selector, ".bx--dropdown.bx--dropdown-multi-parent_")
search_label_input = (css_selector, ".multiselect-search-wrapper .bx--search-input")
label_option_checkbox = (xpath, "//label[@class='bx--checkbox-label' and normalize-space()='{}']")
service_template_cards = (css_selector, "div.service-box")
service_menu_icon = (xpath, "//h3[normalize-space()='{}']")
generate_quote_btn = (xpath, "//button[contains(text(),'Generate Quote')]")
service_menu_for_duplicate_name_icon = (xpath, "(//h4[normalize-space()='{}']/ancestor::div/div[@class='cart-overflow-menu']//button)[2]")
catalog_providers_list = (css_selector, ".bx--checkbox-label-text")
search_filter_close_button =(xpath, "//*[@id='filter-accordion']/button")
pattern_name_text = (css_selector, "h1[title='Azure JSON Use-case 1']")
all_patterns_tab = (css_selector, "button[title='All Patterns']")
all_patterns_on_catalog = (xpath, "//*[@class='card-service-title']")
first_pattern_on_catalog = (xpath, "(//h3[@class='card-service-title'])[1]")
pattern = (xpath, "//h3[normalize-space()='{0}']")
pattern_options_icon = (xpath, "//h3[normalize-space()='{0}']/../..//button[@aria-label='Overflow']")
action_button_based_on_pattern = (xpath, "//*[@class='bx--overflow-menu-options__btn ']//div[normalize-space()='{1}']")


# Locators for details page
service_name_text = (css_selector, "h1.ibm--page-header__title")
base_price_text = (css_selector, ".rdiv1 p > strong")
details_page_label_text = (css_selector, "span.details-title")
available_versions_label_text = (css_selector, ".cdiv1 .details-title")
features_label_text = (css_selector, "[name='star--outline'] ~ .details-title")
details_label_text = (css_selector, "[name='document'] ~ .details-title")
service_card = (xpath, "//app-service-card")
catalog_footer_loader = (xpath, "//div[@class='services-wrapper']//div[@class ='center']")

search_service_name_path = (xpath, "//input[@class='bx--search-input']")
service_tile_txt = (xpath, "//*[contains(text(), '{}')]")

# Label Locators 
labels_header_text = (css_selector, ".label-header-title")
labels_dropdown_text = (css_selector, ".bx--search__wrapper li")
dropdown_labels = (css_selector, "button.bx--search__wrapper")
dropdown_values_label = (css_selector, "[id^=dropdown-option__]")
dropdown_item_more = (css_selector, ".bx--dropdown-item.bx--dropdown-item--more")
card_service_title = (css_selector, ".card-service-title")
close_button = (css_selector, ".close")
label_detail = (css_selector, "div.tag-text")
config_group_name = (xpath, "//h2[contains(text(),'{}')]")
section_name_xpath = (xpath, "//button[contains(text(),'{}')]")
attribute_name_xpath = (xpath, "//label[contains(text(),'{}')]")

# pricing parameters for ICAM
cpu_value = (css_selector, "#text-input-CPU")
ram_value = (css_selector, "#text-input-RAM")
disk_value = (css_selector, "#text-input-Disk")

# Regex parameter for ICAM
sshkey_value = (css_selector, "#text-areapublic_ssh_key")
sshKey_name = (css_selector, "#text-input-public_ssh_key_name")
sshKey_error = (xpath, "//*[@class='bx--form-requirement required']")
regex_param_custom_template = (css_selector, "#text-input-Regex_param")
regex_param_custom_template_error = (xpath, "//*[@class='bx--form-requirement']")

# ICAM invisible param list
sharedparam_awsdata_label = (css_selector,"#aws-data div div label")
userpassword_label = (css_selector,"#additional-params_dynamic-form form form-password div carbon-text-input div label")
samplehidden_param_label = (xpath,"//label[@for='text-input-sample_hidden_param']")

unable_to_configure_msg = (css_selector, "div.bx--modal-content > p")
read_write_tag = (css_selector,"input#text-input-tag\:read-write-tag")
read_only_tag = (css_selector,"input#text-input-tag\:read-only-tag")

previous_button_reviewOrder = (css_selector,"#previous-button-reviewOrder")
edit_parameter_old_selection = (css_selector, "span.old-selection")
edit_parameter_old_values = (css_selector,"span.old-selection span")
previous_button_additionalParams = (css_selector,"#previous-button-additionalParams")
connection_dropdown_arrow = (css_selector, "#bx--dropdown-single-parent_Connection > span.bx--dropdown__arrow")
connection_dropdown_item =(css_selector, "#bx--dropdown-single-parent_Connection li.bx--dropdown-item")
plan_dropdown_arrow = (css_selector, "#bx--dropdown-single-parent_instance_plan > span.bx--dropdown__arrow")
plan_dropdown_item = (css_selector, "#bx--dropdown-single-parent_instance_plan li.bx--dropdown-item")
