from helpers.mo_base_locator import *

quote_name_text = (xpath, "//span[contains(text(), '{}')]")
quote_status_text = (xpath, "//span[contains(text(), '{}')]/parent::td/following-sibling::td[2]/span")
quote_menu_btn = (xpath, "//span[contains(text(), '{}')]/parent::td/following-sibling::td[7]//button")
quote_menu_options_btn = (xpath, "//div[contains(text(), '{}')]")
quote_item_menu = (css_selector, "[id^='quote-item-list-overflow-menu'] button")
edit_quote_item_btn = (css_selector, "#edit-quote")
view_service_details_btn = (css_selector, "#view-service-details-flagON")
service_details_label_value = (xpath, "//label[contains(text(), '{}')]/parent::div")
quotes_link = (link_text, "Quotes")
continue_btn = (xpath, "//button[contains(text(), 'Continue')]")
delete_btn = (xpath, "//button[contains(text(), 'Delete')]")
close_slider_window_btn = (css_selector, "button.bx--link.bx--slide-over-panel--close")