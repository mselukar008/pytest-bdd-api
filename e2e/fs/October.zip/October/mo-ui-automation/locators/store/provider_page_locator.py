from helpers.mo_base_locator import *

provider_page_providers_list = (css_selector, ".table-col-name [class^='ellipsis']")
pagination_dropdown = (css_selector, "[id^='pagination-select-items']")
pagination_option = (xpath, "//option[contains(text(), '{}')]")
