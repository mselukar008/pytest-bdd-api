from helpers.mo_base_locator import *

asset_bar_chart_title_text = (css_selector, ".asset-count-chart h4")
asset_bar_chart_x_axis_labels = (css_selector, "g[aria-label='bottom ticks'] g.tick text")
asset_month_bar_chart = (css_selector, "g.bx--cc--simple-bar path:nth-of-type({})")
assets_utilization_heatmap_title_text = (css_selector, ".asset-vs-utilization h4")
assets_utilization_heatmap_utilization_legends = (css_selector, ".utilization-legend")
assets_utilization_heatmap_asset_status_legends = (css_selector, ".assetStatus-legend")