from helpers.mo_base_locator import *

asset_bar_chart_title_text = (css_selector, ".asset-count-chart h4")
