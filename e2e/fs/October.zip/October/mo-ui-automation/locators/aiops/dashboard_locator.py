from helpers.mo_base_locator import *

dashboard_link = (css_selector, ".dashboardLink")
card_title_text = (css_selector, "[title='{}']")
applications_text = (xpath, "//p[contains(text(), 'Applications')]")
health_statuses_text = (css_selector, ".HealthbusinessStatusWrapper .progressTxtCardHealth.cursorDefult")
health_statuses_value = (xpath, "//a[contains(text(), '{}')]/ancestor::div/p[contains(@class, 'progressNbr')]")
health_progress_bar = (css_selector, ".progress-bar.progress-bar-crtcl")
total_apps_text = (css_selector, ".totalHealthNbr")
open_tickets_text = (css_selector, ".OpenTicketsPriorityHeading")
priorities_text = (css_selector, ".businessStatusWrapper .progressTxtCardHealth.cursorDefult")
priority_tickets_text = (css_selector, ".progressNbr.OpenTicketsPriority")
view_details_link = (xpath, "//span[contains(text(), '{}')]/ancestor::div[@class='cardPadding']"
                            "//a[@class='hand-cursor txtHover']")
