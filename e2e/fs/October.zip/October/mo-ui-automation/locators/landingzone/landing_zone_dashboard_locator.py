from helpers.mo_base_locator import *
view_and_approve_requests_tab = (xpath, "//a[@title='View & Approve Requests']")
last_service_card = (xpath, "//div[contains(text(),'Pending Approval')]//parent::div//following-sibling::ibm-tile[last()]")
back_button = (xpath, "//button[normalize-space()='Back']")
iam_users_header = (xpath, "//div[@class='count-head' and contains(text(),'IAM Users')]")
deny_last_request = (xpath, "//div[contains(text(),'Pending Approval')]//parent::div//following-sibling::ibm-tile[last()]//button[contains(text(),'Deny')]")
approve_last_request = (xpath, "//div[contains(text(),'Pending Approval')]//parent::div//following-sibling::ibm-tile[last()]//button[contains(text(),'Approve')]")
deny_modal_button = (xpath, "//div[@class='bx--modal-container']//button[normalize-space()='Deny']")
deny_last_request = (xpath, "//div[contains(text(),'Pending Approval')]//parent::div//following-sibling::ibm-tile[last()]//button[contains(text(),'Deny')]")
approve_modal_button = (xpath, "//div[@class='bx--modal-container']//button[normalize-space()='Approve']")
deny_modal_button = (xpath, "//div[@class='bx--modal-container']//button[normalize-space()='Deny']")
approved_request_checkbox = (xpath, "//label[@for='checkbox-approved_request']")
deny_request_checkbox = (xpath, "//label[@for='checkbox-denied_request']")
approve_text_visible = (xpath, "//div[contains(text(),'Approved')]//parent::div//following-sibling::ibm-tile[last()]//*[contains(text(),'Approved')]")
denied_text_visible = (xpath, "//div[contains(text(),'Denied')]//parent::div//following-sibling::ibm-tile[last()]//*[contains(text(),'Denied')]")

# Service card details before Approval

pending_base = "//div[contains(text(),'Pending Approval')]/following-sibling::ibm-tile[last()]"
pending_request_for_card_details = (xpath, pending_base + "//div[contains(text(),'{}')]")
pending_requestor_card_details = (xpath, pending_base + "//div[contains(text(),'Requester')]/following-sibling::div[1]")
pending_owner_card_details = (xpath, pending_base + "//div[contains(text(),'Owner')]/following-sibling::div[1]")
pending_project_card_details = (xpath, pending_base + "//div/ibm-tag[contains(text(),'{}')]")
pending_requested_policies_card_details = (xpath, pending_base + "//ibm-tag[contains(@class,'bx--tag--teal')]")
pending_last_service_card_date_time = (xpath, pending_base + "//div[contains(text(),'Requested on')]/following-sibling::div[1]")
pending_budget_card_details = (xpath, pending_base + "//div[contains(text(),'USD')]")
pending_threshold_card_details = (xpath, pending_base + "//span[contains(text(),'{}')]")
pending_budget_policies_card_details = (xpath, pending_base + "//ibm-tag[contains(@class,'bx--tag--red budget-action-tag')]")
pending_requested_duration_card_details = (xpath, pending_base + "//child::div[normalize-space()='Requested Duration']//following-sibling::div[1]")
pending_export_icon_last_card = (xpath, pending_base + "//*[@id='icon' and contains(@class,'export-icon')]")

# Service card details after approval
approved_base = "//div[contains(text(),'Approved')]/following-sibling::ibm-tile[last()]"
request_for_card_details = (xpath, approved_base + "//div[contains(text(),'{}')]")
requestor_card_details = (xpath, approved_base + "//div[contains(text(),'Requester')]/following-sibling::div[1]")
owner_card_details = (xpath, approved_base + "//div[contains(text(),'Owner')]/following-sibling::div[1]")
project_card_details = (xpath, approved_base + "//div/ibm-tag[contains(text(),'{}')]")
requested_policies_card_details = (xpath, approved_base + "//ibm-tag[contains(@class,'bx--tag--teal')]")
last_service_card_date_time = (xpath, approved_base + "//div[contains(text(),'Requested on')]/following-sibling::div[1]")
budget_card_details = (xpath, approved_base + "//div[contains(text(),'USD')]")
threshold_card_details = (xpath, approved_base + "//span[contains(text(),'{}')]")
budget_policies_card_details = (xpath, approved_base + "//ibm-tag[contains(@class,'bx--tag--red budget-action-tag')]")
requested_duration_card_details = (xpath, approved_base + "//child::div[normalize-space()='Requested Duration']//following-sibling::div[1]")
export_icon_last_card = (xpath, approved_base + "//*[@id='icon' and contains(@class,'export-icon')]")
