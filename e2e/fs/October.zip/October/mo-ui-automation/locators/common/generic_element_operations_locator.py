from helpers.mo_base_locator import *

# Spinner and Loader
spinner = (xpath, "//*[@class='bx--loading__svg']")
loader_title = (xpath, "//title[contains(text(),'Loading')]")