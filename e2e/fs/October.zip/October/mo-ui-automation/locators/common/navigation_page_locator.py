from helpers.mo_base_locator import *

# Main Menu

open_main_menu = (css_selector, "button[title='Open menu']")
close_main_menu = (css_selector, "button[title='Close menu']")

# Portal
portal_path = (xpath, "//li[@class='bx--side-nav__item']//span[@class='bx--side-nav__link-text'][normalize-space()='Portal']")

# Menu Options
option_expand_path = (xpath, "//button[span[text()='{}']]")
side_nav_menu_path = (xpath, "//li[@class='bx--side-nav__menu-item']/a[@title='{}']/span")
home_page_path = (xpath, "//a[@title='IBM Services for Multicloud Management']")

# Switch to frame
mo_iframe_xpath = (xpath, "//iframe[@id='mo-iframe']")
