from helpers.mo_base_locator  import *

# Sign in
page_header = (xpath, "//div[@class='card-container-title']")
username_path = (xpath, "//input[@id='username']")
continue_btn = (xpath, "//button[normalize-space()='Continue']")
email_path = (xpath, "//input[@type='email']")
password_path = (xpath, "//input[@type='password']")
sign_in_path = (css_selector, "#signinbutton")
i_accept_btn = (css_selector, "#privacy-accept")
w3id_link = (xpath, "//span[@class='optionLabel' and text()='w3id Credentials']")
kyn_username_textbox = (css_selector, "input[type='text']")
next_btn = (css_selector, "input[value='Next']")
kyn_pwd_textbox = (css_selector, "input[type='password']")
verify_btn = (css_selector, "input[value='Verify']")
kyn_otp_textbox = (css_selector, "input[type='text']")
non_kyndryl_otp_textbox = (css_selector, "input#otp")
non_kyndryl_otp_verify_button = (css_selector, "button[type='submit']")
non_kyndryl_otp_invalid_msg = (css_selector, "div[data-invalid]")
otp_submit_btn = (css_selector, "#submit_btn")
kyn_totp_btn = (css_selector, "#totp")
kyn_otp_invalid_msg = (css_selector, "div[role='alert']")
kyn_otp_submit_btn = (css_selector, "#otp-login-button")
cus_login_ibm_btn = (xpath, "//button[normalize-space()='Sign in with IBMW3']")
cus_login_kyn_btn = (xpath, "//button[contains(normalize-space(), 'Sign in with Kyndryl')]")
login_btn = (xpath, "//button[contains(text(), 'Login')]")
loader_text = (css_selector, ".loader")
sign_in_options_card = (css_selector, ".card-container-title")
kyndryl_w3id_btn = (xpath, "//button[contains(text(), 'Kyndryl w3id')]")
kyndryl_id_btn = (xpath, "//button[contains(text(), 'Kyndryl ID')]")
ibm_id_btn = (xpath, "//button[contains(text(), 'IBMid')]")
password_reset_reminder = (css_selector, "a[data-se='skip']")
authenticator_type_btn = (css_selector, "div[data-se='google_otp']")

# Logout
ibm_icon = (css_selector, "[title='User']")
signout_btn = (xpath, "//button[normalize-space()='Logout']")

# Developer Console
developer_console_link = (xpath, "//a[contains(text(), 'Developer Console')]")
bearer_token_tab = (xpath, "//button[contains(text(), 'Bearer Token')]")
display_btn = (xpath, "//button[contains(text(), 'Display')]")
bearer_token_text = (css_selector, ".bx--snippet-container")

