from helpers.mo_base_locator import *

dashboard_title = (css_selector, ".dashboard-view")
widget_title = (xpath, "(//div[@class='overview-widget-header']/h3)[{}]")
total_alerts_text = (xpath, "//cluster-dash-alerts//div[contains(text(), 'Total')]")
total_alerts_count = (css_selector, "cluster-dash-alerts .total-text strong")
alerts_text = (css_selector, "cluster-dash-alerts .total-text span.rel-label")
app_cluster_link = (link_text, "{}")
cluster_alert_count = (css_selector, ".alert-count")
critical_alert_icon = (css_selector, ".bx--btn__icon.critical")
icon_text = (css_selector, ".icon-text")

total_provider_cluster_text = (xpath, "//widget-clusters-health-status//div[contains(text(), 'Total')]")
total_provider_clusters_count = (css_selector, "widget-clusters-health-status .total-text strong")
clusters_text = (css_selector, "widget-clusters-health-status .total-text span.rel-label")
clusters_donut_chart = (css_selector, "[id^='donut_path_#24A148']")
chart_total_count = (css_selector, "#middleTotal")
chart_cluster_status = (css_selector, "#middleText")
chart_cluster_percent = (css_selector, "#middlePercentage")

region_map_canvas = (css_selector, ".ie-canvas")
region_cluster_count = (css_selector, ".geo-text")

clusters_table_title = (css_selector, ".bx--data-table-header__title")
clusters_table_labels = (css_selector, ".bx--table-header-label")
clusters_table_data = (css_selector, "ibm-table tbody tr:nth-child(1) td")

cluster_alerts_text = (css_selector, ".cluster-info-alerts")
side_navigation_link = (css_selector, "[title='{}']")
namespaces_table_names = (css_selector, "ibm-table tbody tr td:nth-child(1)")
node_alerts_tab = (css_selector, "[title^='Node alerts']")

pod_search_icon = (css_selector, "[role='search']")
pod_search_textbox = (css_selector, ".bx--search-input")
pod_log_link = (link_text, "Log")
