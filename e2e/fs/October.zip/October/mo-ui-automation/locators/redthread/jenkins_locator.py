from helpers.mo_base_locator import *

username_textbox = (css_selector, "#j_username")
password_textbox = (css_selector, "input[name='j_password']")
sign_in_btn = (css_selector, "button[name='Submit']")
petstore_job_link = (css_selector, "a[href='job/uiauto_redthread_petstore_deployment/']")
job_build_id = (css_selector, "a.model-link.inside.build-link.display-name")
job_builds_link = (xpath, "//a[@class='model-link inside build-link']")
console_output_link = (xpath, "//a[contains(@href, 'console')]")
console_logs_text = (css_selector, ".console-output")
build_status_icon = (css_selector, "[tooltip='In progress']")
