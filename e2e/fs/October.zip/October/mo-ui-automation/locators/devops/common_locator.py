from helpers.mo_base_locator import *

app_filter_btn = (css_selector, "button[aria-label='Application filter']")
applications_dropdown = (css_selector, ".bx--accordion__heading")
application_name_checkbox = (xpath, "//span[normalize-space()='{}']")
button_text = (xpath, "//button[normalize-space()='{}']")
header_title_text = (xpath, "//strong[@class='header-data__item__title']")
header_data_text = (css_selector, ".header-data__item__stat.flex-space-between")
filter_arrow_icon = (css_selector, "#businessService [ibmIcon='chevron--down']")