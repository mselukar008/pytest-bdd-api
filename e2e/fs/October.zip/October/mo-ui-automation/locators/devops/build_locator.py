from helpers.mo_base_locator import *

tile_header_text = (xpath, "(//h4[@class='tile-header'])[{}]")
bar_chart_duration = (xpath, "//*[@class='bars'][2]/*")
bar_chart_total_builds = (xpath, "//*[@aria-label='left axis']/*[@class='ticks']/*[@class='tick']")
bar_duration_current_date = (xpath, "(//*[@aria-label='bottom ticks']/*[@class='tick'])[8]")
current_status_bar = (xpath, "(//*[@class='bars']/*)[8]")
arc_chart = (css_selector, "[class='bx--cc--gauge'] [class^='arc']")
arc_passed_percent = (css_selector, "text.gauge-value-number")
arc_failed_percent = (css_selector, "text.gauge-delta-number")
longest_builds_meter_title = (css_selector, ".meter-title")
longest_builds_meter_progress = (css_selector, ".meter-progress")
longest_builds_meter_count = (css_selector, ".meter-count")
technical_service_title = (css_selector, ".bx--data-table-header__title")
table_labels_text = (css_selector, ".bx--table-header-label")
table_data_text = (css_selector, "td[ibmtabledata]")
header_build_data_text = (xpath, "(//*[@class='header-data__item__stat flex-space-between'])[2]")
header_build_subtitle_text = (xpath, "(//span[@class='header-data__item__subtitle'])[2]")
table_menu_icon = (css_selector, ".bx--overflow-menu__icon")
view_details_option = (css_selector, ".bx--overflow-menu-options__option-content")
build_detail_title = (css_selector, ".side-panel__title")
details_tab = (css_selector, "[title = 'Details']")
analysis_history_tab = (css_selector, "[title = 'Analysis history']")
details_tile_header = (xpath, "(//h4[@class='details-tile-header inline'])[{}]")
detail_bar_charts_left_axis = (xpath, "//ibm-tabs//h4[contains(text(), '{}')]/ancestor::ibm-tile/div"
                                      "//*[@aria-label='left ticks']/*[@class='tick']")
detail_bar_charts_bottom_axis = (xpath, "//ibm-tabs//h4[contains(text(), '{}')]/ancestor::ibm-tile/div"
                                        "//*[@aria-label='bottom ticks']/*[@class='tick']")
detail_bar_charts_current_date = (xpath, "(//ibm-tabs//h4[contains(text(), '{}')]/ancestor::ibm-tile/div"
                                         "//*[@aria-label='bottom ticks']/*[@class='tick'])[8]")
detail_bar_charts_status_current_bar = (xpath, "(//ibm-tabs//h4[contains(text(), 'Build status')]/ancestor::ibm-tile/div"
                                        "//*[@class='bars']/*)[8]")
details_bar_charts_duration_current_bar = (xpath, "(//ibm-tabs//h4[contains(text(), 'Build duration')]/ancestor::ibm-tile/div"
                                                  "//*[@class='bars']/*)[8]")
analysis_history_table_title = (css_selector, "#build-details-tableheader .bx--data-table-header__title")
table_search_icon = (css_selector, "div[role='search']")
table_search_text = (css_selector, ".bx--search-input")
table_search_tag_label = (css_selector, ".bx--data-table-header__title .bx--tag__label")
analysis_history_table_labels = (xpath, "//*[@id='build-details-tableheader']/following-sibling::ibm-table-container"
                                        "//div[@class='bx--table-header-label']")
analysis_history_table_data = (xpath, "//*[@id='build-details-tableheader']/following-sibling::ibm-table-container"
                                      "//tr[1]/td")
table_build_url_link = (xpath, "//a[@aria-label='URL']")

