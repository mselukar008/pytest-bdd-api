from helpers.mo_base_locator import *

defects_issues_dropdown = (css_selector, ".dropdown__org.ticket_type .bx--list-box.bx--dropdown")
dropdown_options = (xpath, "//div[contains(text(), '{}')]/parent::li")
development_activity_title = (css_selector, ".tile-header")
development_activity_graph = (xpath, "//h4[contains(text(), 'Development activity')]/ancestor::ibm-tile/div[2]"
                                     "//*[@class='bx--cc--scatter-stacked']/*")
bottom_axis_last_date = (xpath, "//*[@class='axis bottom']/*[@class='ticks']/*[@class='tick'][9]")
days_axis_last_date_dot = (xpath, "(//h5[contains(text(), 'Development')]/ancestor::ibm-tile/div//*["
                                  "@class='dots']/*)[2]")
days_axis_total_count = (xpath, "//*[@class='axis bottom']/*[@class='ticks']/*[@class='tick']")
defects_axis_total_count = (xpath, "//*[@class='axis left']/*[@class='ticks']/*[@class='tick']")
applications_title = (css_selector, "h4[class='title']")
applications_meter_title = (xpath, "//a[contains(@class, 'meter-title')]")
app_meter_count = (css_selector, ".meter-count")
app_meter_progress = (css_selector, ".meter-progress")
tech_service_tag_label = (css_selector, "#develop-landing-table .bx--tag__label")
tech_service_title = (xpath, "//h4[contains(text(),'Technical services')]")
tech_service_table_labels = (css_selector, "ibm-table th")
tech_service_table_data = (css_selector, "ibm-table tbody td")
tech_service_table_data_links = (xpath, "//ibm-table//tbody//td/a")
tech_service_table_menu_icon = (css_selector, ".bx--overflow-menu__icon")
table_menu_option = (css_selector, ".bx--overflow-menu-options__btn")
develop_activity_panel_titles = (css_selector, ".side-panel__title")
panel_details_summary_headers = (css_selector, "#details-summary-header-container-id h4")
panel_summary_status = (xpath, "//h4[contains(text(), '{}')]/ancestor::div/div[@id='data-id']//ibm-tag")
panel_defects_links = (xpath, "//h4[contains(text(), 'Defects summary')]/ancestor::div/div[@id='data-id']//a")
panel_issues_links = (xpath, "//h4[contains(text(), 'Issues summary')]/ancestor::div/div[@id='data-id']//a")
panel_tiles_header = (css_selector, ".details-tile-header")
panel_tiles_graph_data = (xpath, "//span[contains(text(), '{}')]/ancestor::ibm-tile/div[2]//*["
                                 "@class='bx--cc--scatter']/*")
panel_days_axis_total_count = (xpath, "//span[contains(text(), '{}')]/ancestor::ibm-tile//*[@class='axis bottom']/*["
                                      "@class='ticks']/*[@class='custom-tick']")
panel_left_axis_total_count = (xpath, "//span[contains(text(), 'Issues')]/ancestor::ibm-tile//*[@class='axis left']"
                                      "/*[@class='ticks']/*[@class='tick']")
panel_tabs = (xpath, "//button[contains(text(), '{}')]")
panel_defects_tab_header = (css_selector, "#develop-details-defectsheader h4")
panel_defects_table_lables = (xpath, "//*[@id='develop-details-defectsheader']/parent::div//div"
                                     "[@class='bx--table-header-label']")
panel_defects_table_data = (xpath, "//*[@id='develop-details-defectsheader']/parent::div//ibm-table//tr[1]/"
                                   "td[@ibmtabledata]")
panel_defect_link = (xpath, "//*[@id='develop-details-defectsheader']/parent::div//ibm-table//tr[1]/"
                            "td[@ibmtabledata]/a")
panel_issues_tab_header = (css_selector, "#develop-details-issuesheader h4")
panel_issues_table_labels = (xpath, "//*[@id='develop-details-issuesheader']/parent::div//div"
                                    "[@class='bx--table-header-label']")
panel_issues_table_data = (xpath, "//*[@id='develop-details-issuesheader']/parent::div//ibm-table//tr[1]/"
                                  "td[@ibmtabledata]")
panel_issue_link = (xpath, "//*[@id='develop-details-issuesheader']/parent::div//ibm-table//tr[1]/"
                           "td[@ibmtabledata]/a")

github_issue_number = (css_selector, ".f1-light.color-fg-muted")
github_issue_name = (css_selector, "bdi.js-issue-title.markdown-title")
github_issue_status = (css_selector, "[title^='Status:']")
