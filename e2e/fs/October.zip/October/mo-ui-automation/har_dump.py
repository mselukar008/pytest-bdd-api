"""
This inline script can be used to dump flows as HAR files. (MITMPROXY)

example cmdline invocation:
mitmdump -s ./har_dump.py --set hardump=./dump.har

filename endwith '.zhar' will be compressed:
mitmdump -s ./har_dump.py --set hardump=./dump.zhar

mitmproxy documentation: https://docs.mitmproxy.org/stable/
hooks (load, running, request, response, done,...) documentation: https://docs.mitmproxy.org/stable/api/events.html 
"""

import json
import base64
import zlib
import os
import typing  # noqa
from datetime import datetime
from datetime import timezone
import mitmproxy
from mitmproxy import connection
from mitmproxy import version
from mitmproxy import ctx
from mitmproxy.utils import strutils
from mitmproxy.net.http import cookies
from mitmproxy.http import HTTPFlow
from mitmproxy.addonmanager import Loader
from http.client import responses

HAR: typing.Dict = {}
import random, string
headers_ids = []

# A list of server seen till now is maintained so we can avoid
# using 'connect' time for entries that use an existing connection.
SERVERS_SEEN: typing.Set[connection.Server] = set()

num_req = 0
num_res = 0
num_errors = 0
total_responses_dict = {
    'num_req': num_req,
    'num_res': num_res, 
    'num_errors': num_errors
}


def load(l: Loader):
    """Set the accepted parameters for the addon calling --set flag

    Args:
        l (Loader): addon loader
    """    
    l.add_option(
        "hardump", str, "", "HAR dump path."
    )
    l.add_option(
         "req_header_keys", str, "", "Request header keys to be sent" # ej: key1,key1, ...
    )
    l.add_option(
         "req_header_vals", str, "", "Request header values to be sent" # ej: value1,value2, ... Need to match with number of header keys
    )


def configure(updated):
    """Set the main structure of the har, called when proxy configuration was updated

    Args:
        updated (bool): check if configuration was updated
    """    
    HAR.update({
        "log": {
            "version": "1.2",
            "creator": {
                "name": "mitmproxy har_dump",
                "version": "0.1",
                "comment": "mitmproxy version %s" % version.MITMPROXY
            },
            "entries": []
        }
    })
    
def gen_random_id():
    """Generate a random id to identify the transaction

    Returns:
        str: random id generated
    """    
    return ''.join(random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(16))
    

def running():
    """Set a json file with the number of requests, responses and errors, called when proxy is up and running
    """    
    total_responses_dict["num_req"] = num_req
    total_responses_dict["num_res"] = num_res
    save_total_responses_file()


def error(flow: HTTPFlow):
    """Capture the error response when request get error

    Args:
        flow (HTTPFlow): error response flow
    """    
    proxy_header = flow.request.headers.get('mitmproxy-id')
    if proxy_header and proxy_header in headers_ids:
        global num_errors
        num_errors+=1
        total_responses_dict["num_errors"] = num_errors
        save_total_responses_file()
        build_har(flow)
    write_har()

def request(flow: HTTPFlow):
    """Capture the request

    Args:
        flow (HTTPFlow): request flow
    """    
    global num_req
    num_req+=1
    total_responses_dict["num_req"] = num_req
    save_total_responses_file()
    # Add headers to the request
    if ctx.options.req_header_keys != '':
        headers = zip(ctx.options.req_header_keys.split(','), ctx.options.req_header_vals.split(','))
        for header in headers:
            flow.request.data.headers[header[0].lower()] = header[1]
    proxy_id = gen_random_id()
    # Header to identify the request in the response hook
    flow.request.headers['mitmproxy-id'] = proxy_id
    headers_ids.append(proxy_id)
    
    

def response(flow: HTTPFlow):
    """Capture the response when a response has been received from server

    Args:
        flow (HTTPFlow): response flow
    """   
    proxy_header = flow.request.headers.get('mitmproxy-id')
    if proxy_header and proxy_header in headers_ids:
        global num_res
        num_res+=1
        total_responses_dict["num_res"] = num_res
        save_total_responses_file()       
        build_har(flow)
    write_har()

def build_har(flow: HTTPFlow):
    """Create the structure of one har transaction

    Args:
        flow (HTTPFlow): request transaction done

    """    
    # -1 indicates that these values do not apply to current request
    ssl_time = -1
    connect_time = -1
    if flow.server_conn and flow.server_conn not in SERVERS_SEEN:
        connect_time = (flow.server_conn.timestamp_tcp_setup -
                        flow.server_conn.timestamp_start)

        if flow.server_conn.timestamp_tls_setup is not None:
            ssl_time = (flow.server_conn.timestamp_tls_setup -
                        flow.server_conn.timestamp_tcp_setup)

        SERVERS_SEEN.add(flow.server_conn)

    # Calculate raw timings from timestamps. DNS timings can not be calculated
    # for lack of a way to measure it. The same goes for HAR blocked.
    # mitmproxy will open a server connection as soon as it receives the host
    # and port from the client connection. So, the time spent waiting is actually
    # spent waiting between request.timestamp_end and response.timestamp_start
    # thus it correlates to HAR wait instead.
    timing_receive = 0
    timing_wait =  0
    timing_send = 0
    if flow.response:
        timing_send = flow.request.timestamp_end - flow.request.timestamp_start
        timing_receive = flow.response.timestamp_end - flow.response.timestamp_start if flow.response.timestamp_end else 0
        timing_wait = flow.response.timestamp_start - flow.request.timestamp_end
    timings_raw = {
        'send': timing_send,
        'receive': timing_receive,
        'wait': timing_wait,
        'connect': connect_time,
        'ssl': ssl_time,
    }

    # HAR timings are integers in ms, so we re-encode the raw timings to that format.
    timings = {
        k: int(1000 * v) if v != -1 else -1
        for k, v in timings_raw.items()
    }

    # full_time is the sum of all timings.
    # Timings set to -1 will be ignored as per spec.
    full_time = sum(v for v in timings.values() if v > -1)

    started_date_time = datetime.fromtimestamp(flow.request.timestamp_start, timezone.utc).isoformat()

    # Response body size and encoding
    response_body_size = 0
    response_body_compression = 0
    if flow.response:
        response_body_size = len(flow.response.raw_content) if flow.response.raw_content else 0
        response_body_decoded_size = len(flow.response.content) if flow.response.content else 0
        response_body_compression = response_body_decoded_size - response_body_size
        
    try:
        status_text = responses[flow.response.status_code]
    except:
        status_text = ""

    entry = {
        "startedDateTime": started_date_time,
        "time": full_time,
        "request": {
            "method": flow.request.method,
            "url": flow.request.url,
            "httpVersion": flow.request.http_version,
            "cookies": format_request_cookies(flow.request.cookies.fields),
            "headers": name_value(flow.request.headers),
            "queryString": name_value(flow.request.query or {}),
            "headersSize": len(str(flow.request.headers)),
            "bodySize": len(flow.request.content) if flow.request.content else 0,
        },
        "response": {
            "status": flow.response.status_code if flow.response else 0,
            "statusText": status_text,
            "httpVersion": flow.response.http_version if flow.response else 'unknown',
            "cookies": format_response_cookies(flow.response.cookies.fields) if flow.response else [],
            "headers": name_value(flow.response.headers) if flow.response else [],
            "content": {
                "size": response_body_size,
                "compression": response_body_compression,
                "mimeType": flow.response.headers.get('Content-Type', '') if flow.response else ''
            },
            "redirectURL": flow.response.headers.get('Location', '') if flow.response else '',  
            "headersSize": len(str(flow.response.headers)) if flow.response else 0,
            "bodySize": response_body_size
        },
        "cache": {},
        "timings": timings,
    }
    
    if flow.error:
        entry['response']['_error'] = str(flow.error)

    if flow.response and not flow.error:
        # Store binary data as base64
        if strutils.is_mostly_bin(flow.response.content):
            entry["response"]["content"]["text"] = base64.b64encode(flow.response.content).decode()
            entry["response"]["content"]["encoding"] = "base64"
        else:
            entry["response"]["content"]["text"] = flow.response.get_text(strict=False)

        if flow.request.method in ["POST", "PUT", "PATCH"]:
            params = [
                {"name": a, "value": b}
                for a, b in flow.request.urlencoded_form.items(multi=True)
            ]
            def _filter_params(params):
                for param in params:
                    if param['name'] == "password":
                        param['value'] = "********"
                return params
            
            entry["request"]["postData"] = {
                "mimeType": flow.request.headers.get("Content-Type", ""),
                "text": flow.request.get_text(strict=False),
                "params": _filter_params(params)
            }

    if flow.server_conn.connected:
        entry["serverIPAddress"] = str(flow.server_conn.peername[0])

    HAR["log"]["entries"].append(entry)

def done():
    """
        Called once on script shutdown, after any other events.
    """
    write_har()


def write_har():
    """Create the harfile and logs the transactions
    """    
    if ctx.options.hardump:
        json_dump: str = json.dumps(HAR, indent=2)
        if ctx.options.hardump == '-':
            mitmproxy.ctx.log(json_dump)
        else:
            raw: bytes = json_dump.encode()
            if ctx.options.hardump.endswith('.zhar'):
                raw = zlib.compress(raw, 9)

            with open(os.path.expanduser(ctx.options.hardump), "wb") as f:
                f.write(raw)

            mitmproxy.ctx.log("HAR dump finished (wrote %s bytes to file)" % len(json_dump))


def format_cookies(cookie_list):
    rv = []

    for name, value, attrs in cookie_list:
        cookie_har = {
            "name": name,
            "value": value,
        }

        # HAR only needs some attributes
        for key in ["path", "domain", "comment"]:
            if key in attrs:
                cookie_har[key] = attrs[key]

        # These keys need to be boolean!
        for key in ["httpOnly", "secure"]:
            cookie_har[key] = bool(key in attrs)

        # Expiration time needs to be formatted
        expire_ts = cookies.get_expiration_ts(attrs)
        if expire_ts is not None:
            cookie_har["expires"] = datetime.fromtimestamp(expire_ts, timezone.utc).isoformat()

        rv.append(cookie_har)

    return rv


def format_request_cookies(fields):
    return format_cookies(cookies.group_cookies(fields))


def format_response_cookies(fields):
    return format_cookies((c[0], c[1][0], c[1][1]) for c in fields)


def name_value(obj):
    """
        Convert (key, value) pairs to HAR format.
    """
    return [{"name": k, "value": v} for k, v in obj.items()]


def save_total_responses_file():
    file_name = ctx.options.hardump.replace('.har', '_total_res.json')
    with open(os.path.expanduser(file_name), "w") as f:
        f.write(json.dumps(total_responses_dict))
