#!/bin/sh

DIR=$1
BATCH_SIZE=$2
SUBFOLDER_NAME=$3
COUNTER=1

# rm "$DIR/__init__.py"
# cd ..
mkdir -p ui-automation-results
mkdir -p ui-automation-results/JunitReports

if [ $BATCH_SIZE -eq 0 ]
then
	mkdir ui-automation-results/JunitReports/${SUBFOLDER_NAME}
	touch ui-automation-results/JunitReports/${SUBFOLDER_NAME}/__init__.py
	mkdir ui-automation-results/${SUBFOLDER_NAME}
	touch ui-automation-results/${SUBFOLDER_NAME}/__init__.py		
else
	while [ `find $DIR -maxdepth 1 -type f| wc -l` -gt $BATCH_SIZE ] ; do
	  NEW_DIR=$DIR/${SUBFOLDER_NAME}${COUNTER}
	  JUNIT=ui-automation-results/JunitReports/${SUBFOLDER_NAME}${COUNTER}
	  UIAUTO=ui-automation-results/${SUBFOLDER_NAME}${COUNTER}
	  mkdir -p $NEW_DIR  
	  touch $NEW_DIR/__init__.py
	  mkdir -p $JUNIT
	  touch $JUNIT/__init__.py
	  mkdir -p $UIAUTO
	  touch $UIAUTO/__init__.py
	  find $DIR -maxdepth 1 -type f | head -n $BATCH_SIZE | xargs -I {} mv {} $NEW_DIR
	  
	  let COUNTER++
	if [ `find $DIR -maxdepth 1 -type f| wc -l` -le $BATCH_SIZE ] ; then
	 mkdir -p $NEW_DIR
	 touch $NEW_DIR/__init__.py
	 mkdir -p $JUNIT
	 touch $JUNIT/__init__.py
	 mkdir -p $UIAUTO
	 touch $UIAUTO/__init__.py
	 find $DIR -maxdepth 1 -type f | head -n $BATCH_SIZE | xargs -I {} mv {} $NEW_DIR
	 
	fi
	done
	DIR=$DIR/*/
fi

declare -a array1=( $(ls -d $DIR | grep -v '__pycache__' | grep -v 'obsolete'))
dest=( "${array1[@]}" )
printf '%s\n' "${dest[@]}" | jq -R . | jq -cs .
