#!/bin/bash
echo '#### Run tests ####'
cbsuitlist=$(grep "cb.suitlist" config.ini);
cbsuitlist=${cbsuitlist#cb.suitlist=}
echo "######### suitlist=$cbsuitlist"
# cd cb_consume_ui_automation/tests
echo "Path changed"
pytest -vv -rA --show-capture=stderr --reruns 1

