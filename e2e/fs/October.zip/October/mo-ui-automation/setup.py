from setuptools import setup

setup(
    name='cb_consume_ui_automation',
    version='1.0',
    install_requires=[
        'requests==2.22.0',
        'pycryptodome==3.9.0',
        'python-jose==3.0.1',
        'pytest==7.2.0',
        'pytest-html==2.0.0',
        'pytest-dependency==0.4.0',
        'sortedcontainers==2.1.0',
        'numpy>=1.21',
        'pytz==2019.2',
        'selenium==3.141.0',
        'paramiko==2.6.0',
        'pytest-xdist==1.29.0'

    ]
)
