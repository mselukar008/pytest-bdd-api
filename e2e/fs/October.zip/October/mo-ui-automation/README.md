# Modern Ops UI AUTOMATION
Modern Ops UI Automation using Python, Selenium and Pytest

## Pre-requisites:
- Install Python 3.7 and up
    - for required packages read [requirements.txt](https://github.kyndryl.net/CTO-IST/mo-ui-automation/blob/premaster/requirements.txt)
    and for installation run this command on terminal: 
    ```bash
    pip install -r requirements.txt
    ```
- Google Chrome

## Understanding folder structure:
### Structure of framework:

* config.ini : is the configuration file that contains the details of tenant, username, password, browser type, headless or headed execution and har collection   
* conftest.py : is the starting point of framework execution  
* test cases are created under the tests folder  
* test data files are store under resourses/provider folder and then data file name  
* Core functionalities like selenium wrapper methods, json utilities, logs, base locators are under helper folder  
* page object action methods are there under pages folder  
* locators are available under locators folder  
* html report will be store in report folder  
* logs will be there in logs folder with timestamp  
* screenshots will be there in screenshot folder with the name of failed test case  

## Dummy Adapter:
### How to enable/disable dummy adapter in config.ini file

1. First lets verify that the credentials in `credentials.json` file are up-to-date.

2. Then we need to modify the `config.ini` file.
Look for these values and change accordingly
   ```ini
   MO.tenant.adapter=dummy
   ```
   > *posible values are: `dummy` or `real`*

3. Then choose one or several provider accounts, to update the dummy adapter to
   ```ini
   MO.tenant.providers_adapters=ibmcloud
   ```

   > posible values are:
   > `alicloud`,`aws`,`azure`,`gcp`,`ibmcloud`,`icam`,`icd`,`imi`,`softlayer`,`vra`
   >
   > Note: if selecting many providers, these should be comma separated values
   > *i.e.:* `mo.tenant.providers_adapters=ibmcloud,aws,gcp`

4. Then proceed to run tests.


### How to enable/disable dummy adapter in terminal with `curl`

1. First we need to decrypt the `apikey` located in `credentials.json` file
   ```bash
   python3 mo_encryption_decryption.py -d apikey
   ```
   > Replace *apikey* appropriately.

2. Then we just need to do a POST request to the appropriate endpoint
   ```bash
   # To enable dummy adapter use:
   curl -X POST --header "username: [user_id]" --header "apikey: [decrypted_apikey]" https://[tenant_api_url]/adapter/switchdummy/[provider_account]/enable

   # To disable dummy adapter use:
   curl -X POST --header "username: [user_id]" --header "apikey: [decrypted_apikey]" https://[tenant_api_url]/adapter/switchdummy/[provider_account]/disable
   ```
   > Note the [provider_account] value in the URL we need to replace this (*including the [ ]* ) with one of this allowed values (*only use one at a time*):
   > `alicloud`,`aws`,`azure`,`gcp`,`ibmcloud`,`icam`,`icd`,`imi`,`softlayer`,`vra`

3. Finally we can check the status with a GET request
   ```bash
   curl -H "username: [user_id]" -H "apikey: [decrypted_apikey]" https://[tenant_api_url]/adapter/switchdummy/status
   ```
   > Replace values between `[ ]` inclusively. Values are in `credentials.json` file.

4. Then proceed to run tests.

### How to enable/disable dummy adapter with postman

1. First lets review that the credentials in `credentials.json` file, are up-to-date.
2. To populate data in postman, we use values from `credentials.json` and `config.ini`.
3. We first need to decrypt the `apikey` found in `credentials.json`
   - Run this script to decrypt the `apikey`.
   ```bash
   python3 mo_encryption_decryption.py -d apikey
   ```
     *Replace* `apikey` *value above appropriately.*

4. Now the Postman flow to `enable` the dummy adapter:
   + Open Postman app.
   + Create a new `HTTP Request`. *i.e.:* `File` -> `New...` -> `HTTP Request`
   + From dropdown we select `POST`
   + In the *Enter request URL* field we put the value of `mo.tenant.api_url` found in `config.ini` file and append the following string:
     - `/adapter/switchdummy/[provider_account]/enable`
     - > Note the *[provider_account]* value in the string above; we need to replace this (*including the [ ]* ) with one of this allowed values (*only use one at a time*):
     `alicloud`,`aws`,`azure`,`gcp`,`ibmcloud`,`icam`,`icd`,`imi`,`softlayer`,`vra`
   + Then in the `Headers` tab. We add two new `Key` : `Value` pairs. Values are located in `credentials.json` file.
   + The new values would be: 
     - Key: `username` and Value: *`user_id`* *located in `credentials.json`*
     - Key: `apikey` and Value: *`decrypted-apikey`* *Value obtained in step 3. above*
5. Then hit Send
6. To `disable` dummy adapter we execute from step 4. and just change the final part of the appended string to `disable`.
   - i.e.: `/adapter/switchdummy/[provider_account]/disable`.
7. And hit Send
8. To check the the status we use a GET request with the same `Headers` values from final substep from step 4. above.
   - And change the appended string to `/adapter/switchdummy/status`
9. And hit Send
#### Note: on all dummy adapters steps above, when running the framework the `config.ini` file takes precedence.

#

## How to Run the Framework
### How to encrypt and decrypt the password

1. Add MO_UI_AUTO_SECRET environment variable to your system
    - Mac OS:
        Open terminal an run the next commands:
        ```bash
        open ~/.zshrc
        ```
        or
         ```bash
        open ~/.bash_profile
        ```

        Add the env variable to the file:
        ```txt
        export MO_UI_AUTO_SECRET=<secret> 
        ```    

    - Linux
        Open terminal an run the next commands:
        ```bash
        vi ~/.bash_profile
        ```

        Add the env variable to the file:
        ```txt
        export MO_UI_AUTO_SECRET=secret 
        ```    

    - Windows
        
       Refer to this link: https://docs.oracle.com/en/database/oracle/machine-learning/oml4r/1.5.1/oread/creating-and-modifying-environment-variables-on-windows.html#GUID-DD6F9982-60D5-48F6-8270-A27EC53807D0

2. Restart all terminals and IDEs

3. To encrypt password run the next command:

    ```bash
    python3 mo_encryption_decryption.py <password> 
    ```   
4. To decrypt password run the next command:
    ```bash
    python3 mo_encryption_decryption.py <token> -d
    ```   

All the secret password are stored in credentials.json

**NOTE:** The secret value will be provided

### How to run all the tests in this repo
pytest -vv -rA  -n  <no. of browser>  
it will run the all the tests in project in parallel mode where n is the no. of instance of the browser  

pytest -vv -rA  
it will run the all the tests in project in sequential mode  

### How to run 1 test- After a relative test module path add 2 colons and the test name:
pytest -vv -rA tests/aws/name of the .py file::name of test case
### How to run 1 provider all tests
pytest -vv -rA tests/aws
### How to run 1 provider one file all tests
pytest -vv -rA tests/aws/name of test .py file

## Jenkins Run
 You can choose the tenant and one specific provider or all provider
