import json
import os

from helpers.mo_api_client import *
from helpers.mo_api_enums import Store, ServiceNow
from helpers.mo_driver_manager import logger
from helpers.mo_env import tenant
from helpers.mo_json_utils import set_data_path, get_data, get_json_object
from ui_config import test_data_path, users_data
from mo_encryption_decryption import decrypt_password, main

normal_data_path = os.path.join(test_data_path, "servicenow", "change_type_normal.json")
standard_data_path = os.path.join(test_data_path, "servicenow", "change_type_standard.json")
snow_api_data_path = os.path.join(test_data_path, "servicenow", "snow_api_data.json")
snow_login_path = os.path.join(test_data_path, "servicenow", "snow_login.json")
user_id = None
apikey = None


def set_snow_userid_apikey(api_host_url):
    global user_id, apikey
    if "v2-v2-devfra-rel" in api_host_url:
        snow_user = users_data['snow_qs_v2_user']
        user_id = snow_user.get('user_id')
        apikey = decrypt_password(snow_user.get('apikey'))
    if "test1-aws-release-snowui-v3" in api_host_url:
        snow_user = users_data['snow_v3_test1_aws_user']
        user_id = snow_user.get('user_id')
        apikey = decrypt_password(snow_user.get('apikey'))
    if "test1-aws-release-snowui-v2" in api_host_url:
        snow_user = users_data['snow_v2_test1_aws_user']
        user_id = snow_user.get('user_id')
        apikey = decrypt_password(snow_user.get('apikey'))
    if "ct-dev2fra-release-snowui-v3" in api_host_url:
        snow_user = users_data['snow_v3_ct_dev2fra_user']
        user_id = snow_user.get('user_id')
        apikey = decrypt_password(snow_user.get('apikey'))
    return user_id, apikey


def order_status_api_call_get(order_number):
    api_host_url = Store.ORDER_STATUS.get_path_name(order_number)
    main_user = users_data['main_user']
    username = main_user.get('user_id')
    api_key = decrypt_password(main_user.get('apikey'))
    logger.info("api_host_url  :: " + api_host_url)
    logger.info("username :: " + username)
    logger.info("api_key :: " + api_key)
    json_data = get_call(api_host_url, username, api_key)
    logger.info("JSON_DATA")
    logger.info(json_data)


def change_type_normal_post(del_icam=False):
    api_host_url = Store.CHANGE_TYPE.get_path_name()
    username, api_key = set_snow_userid_apikey(api_host_url)
    logger.info("api_host_url  :: " + api_host_url)
    with open(normal_data_path, 'r') as f:
        distros_dict = json.load(f)
        if del_icam:
            del distros_dict["configurationvalue"]["mappingpolicies"][15]
    payload = json.dumps(distros_dict)
    response = post_call(api_host_url, payload, username, api_key)
    response_data, response_code = response
    logger.info("Response code: " + str(response_code))
    return response_code


def change_type_standard_post():
    api_host_url = Store.CHANGE_TYPE.get_path_name()
    username, api_key = set_snow_userid_apikey(api_host_url)
    logger.info("api_host_url  :: " + api_host_url)
    with open(standard_data_path, 'r') as f:
        distros_dict = json.load(f)
    payload = json.dumps(distros_dict)
    response = post_call(api_host_url, payload, username, api_key)
    response_data, response_code = response
    logger.info("Response code: " + str(response_code))
    return response_code


def enable_external_approval():
    api_host_url = Store.EXTERNAL_APPROVAL.get_path_name()
    username, api_key = set_snow_userid_apikey(api_host_url)
    logger.info("api_host_url  :: " + api_host_url)
    set_data_path(snow_api_data_path)
    payload = json.dumps(get_data("external_approval_true"))
    response = post_call(api_host_url, payload, username, api_key)
    response_data, response_code = response
    result = response_data.get("result")
    logger.info(result)
    return result


def disable_external_approval():
    api_host_url = Store.EXTERNAL_APPROVAL.get_path_name()
    username, api_key = set_snow_userid_apikey(api_host_url)
    logger.info("api_host_url  :: " + api_host_url)
    set_data_path(snow_api_data_path)
    payload = json.dumps(get_data("external_approval_false"))
    response = post_call(api_host_url, payload, username, api_key)
    response_data, response_code = response
    result = response_data.get("result")
    logger.info(result)
    return result


def move_change_request_to_implement(sys_id):
    snow_api = get_json_object(snow_api_data_path)
    api_data = snow_api['change_request_to_implement']
    host = api_data.get('host')
    path = api_data.get('path')
    payload = json.dumps(api_data.get('data'))
    url = host + path + sys_id
    logger.info("URL to set Change Request to Implement State: " + url)
    response = put_call(url, payload, snow=True)
    response_data, response_code = response
    logger.info("Response code: " + str(response_code))
    return response_code


def get_api_base_url():
    api_url = Store.API_URL.get_path_name()
    return api_url


def trigger_cd_ondemand_request(bearer_token, aws=False, gcp=False, azure=False):
    global response, data
    snow_api = get_json_object(snow_api_data_path)
    if aws:
        data = snow_api['cd_ondemand_request_aws']
    elif gcp:
        data = snow_api['cd_ondemand_request_gcp']
    elif azure:
        data = snow_api['cd_ondemand_request_azure']
    if os.environ.get("Environment"):
        app_url = os.environ.get("Environment")
        request_url = "https://" + app_url + data.get('path')
    else:
        app_url = tenant
        request_url = "https://" + app_url + data.get('path')
    logger.info("Common Discovery On-demand request  :: " + request_url)
    username, api_key = set_snow_userid_apikey(request_url)
    payload = json.dumps(data.get('body'))
    response = post_call(request_url, payload, username, None, bearer_token)
    response_data, response_code = response
    return response_code


def budget_clean_up():
    budget_update_payload = '"name": "{}", "budgetTotal": {}, "hardThresholdTotal": {}, "softThresholdTotal": {}, "hard_threshold_type": "{}", "soft_threshold_type": "{}", "hard_threshold_enabled": "{}", "soft_threshold_enabled": "{}", "status": "Inactive"'
    budgetary_unit_update_payload = '"name":"{}","status":"Inactive","budgetcode":"{}","description":"{}","externalrefid":"{}","budgetperiod":"{}"'
    budgetary_units_url = Store.GET_BUDGETARY_UNITS.get_path_name("Active")
    main_user = users_data['main_user']
    username = main_user.get('user_id')
    api_key = decrypt_password(main_user.get('apikey'))
    budgetary_units = get_call(budgetary_units_url, username, api_key)
    for budget_unit in budgetary_units["response"]:
        name = budget_unit["name"]
        budget_code = budget_unit["budgetcode"]
        description = budget_unit["description"]
        externalrefid = budget_unit["externalrefid"]
        budgetperiod = budget_unit["budgetperiod"]
        context = budget_unit["context"]
        context_string = '"org":"{}","env":"{}","app":"{}"'
        context_string.format(context["org"],context["env"],context["app"])
        update_budgetary_unit_payload = '{' + budgetary_unit_update_payload.format(name,budget_code,description,externalrefid,budgetperiod) + ',"context":{' + context_string.format(context["org"],context["env"],context["app"]) + '},"unassignedcontext": {},"contacts": []}'

        logger.info(budget_code)
        url = Store.GET_BUDGET.get_path_name()
        get_budget_url = url.format(budget_code)
        associated_budgets = get_call(get_budget_url, username, api_key)
        for budget in associated_budgets["response"]:
            id = budget["id"]
            status = budget["status"]
            url = Store.UPDATE_DELETE_BUDGET.get_path_name()
            update_delete_budget_url = url.format(budget_code, id)
            if status in "Active":
                name = budget["name"]
                budget_total = budget["budgetTotal"]
                hardThresholdTotal = budget["hardThresholdTotal"]
                softThresholdTotal = budget["softThresholdTotal"]
                hard_threshold_type = budget["hard_threshold_type"]
                soft_threshold_type = budget["soft_threshold_type"]
                hard_threshold_enabled = budget["hard_threshold_enabled"]
                soft_threshold_enabled = budget["soft_threshold_enabled"]
                payload = '{' + budget_update_payload.format(name, budget_total, hardThresholdTotal, softThresholdTotal, hard_threshold_type, soft_threshold_type, hard_threshold_enabled, soft_threshold_enabled) + '}'
                # Make budget Inactive
                try:
                    put_call(update_delete_budget_url, payload, username, api_key)
                except:
                    logger.info("Exception while updating budget")
            # Delete budget
            # try:
            #     delete_call(update_delete_budget_url, username, api_key)
            # except:
            #     logger.info("Exception while deleting budget")

        if len(associated_budgets["response"]) == 0:
            # Delete Budgetary unit
            delete_call(Store.UPDATE_DELETE_BUDGETARY_UNIT.get_path_name().format(budget_code), username, api_key)
        # Make Budgetary unit inactive
        try:
            put_call(Store.UPDATE_DELETE_BUDGETARY_UNIT.get_path_name().format(budget_code), update_budgetary_unit_payload, username, api_key)
        except:
            logger.info("Exception while updating budgetary unit")
        # Delete budgetary unit
        # try:
        #     delete_call(Store.UPDATE_DELETE_BUDGETARY_UNIT.get_path_name().format(budget_code), username, api_key)
        # except:
        #     logger.info("Exception while deleting budget")


def delete_carts():
    for i in range(5):
        get_shopping_carts_url = Store.GET_SHOPPING_CART.get_path_name()
        main_user = users_data['main_user']
        username = main_user.get('user_id')
        api_key = decrypt_password(main_user.get('apikey'))
        carts = get_call(get_shopping_carts_url, username, api_key)
        if len(carts["bags"]) != 0:
            for cart in carts["bags"]:
                id = cart["bagId"]
                delete_cart_url = Store.DELETE_SHOPPING_CART.get_path_name().format(id)
                try:
                    delete_call(delete_cart_url, username, api_key)
                except:
                    logger.info("Exception while deleting shopping cart")
        else:
            break
