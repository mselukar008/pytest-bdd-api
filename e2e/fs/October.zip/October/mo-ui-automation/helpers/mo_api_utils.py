import requests
from helpers.mo_json_utils import *
from helpers.mo_selenium_helper import logger
from ui_config import *
import pyotp

global urls_path
urls_path = os.path.join(test_data_path, "app_urls.json")


def rest_client(http_method, link):
    try:
        response = requests.request(http_method, link)
        logger.info(response)
        response.raise_for_status()
        return response.json()

    except requests.exceptions.HTTPError as errh:
        print(errh)
    except requests.exceptions.ConnectionError as errc:
        print(errc)
    except requests.exceptions.Timeout as errt:
        print(errt)
    except requests.exceptions.RequestException as err:
        print(err)


def get_googleauth_passcode(key):
    set_data_path(urls_path)
    # passcode_url = get_json_data_key('generate_passcode_url')
    totp = pyotp.TOTP(key)
    passcode = totp.now()
    # logger.info("URL to fetch the passcode :: " + passcode_url + "***************")
    # res = rest_client("GET", passcode_url + key)
    # passcode = res.get('passcode')
    logger.info("Passcode: " + passcode)
    return passcode
