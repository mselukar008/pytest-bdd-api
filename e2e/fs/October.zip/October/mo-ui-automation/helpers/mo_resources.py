import os

root_folder = os.getcwd()
resource_folder = os.path.join(root_folder, "resources")
output_folder_name = "downloaded_files"
har_folder_name = "hars"
screenshot_folder_name = "screenshots"
screenrecorder_folder_name = "screenrecorder"
secret_key_file = "secret.key"
output_folder = os.path.join(root_folder, output_folder_name)
har_folder = os.path.join(root_folder, har_folder_name)
screenshot_folder = os.path.join(root_folder, screenshot_folder_name)
screenrecorder_folder = os.path.join(root_folder, screenrecorder_folder_name)
secret_key_path = os.path.join(root_folder, secret_key_file)


