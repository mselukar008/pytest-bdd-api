from helpers.mo_page_operations import wait_for_load
from helpers.mo_selenium_helper import wait, driver
from helpers.mo_driver_manager import *
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support import expected_conditions as EC


@wait_for_load
def is_element_present(locator, elem_name, timeout=driver_wait_time, stop_on_fail=False):
    try:
        create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1])))
    except (NoSuchElementException, TimeoutException) as ex:
        logger.info(f"Element {elem_name} is not present")
        if stop_on_fail:
            raise ex
        return False
    logger.info(f"Element {elem_name} is present")
    return True


@wait_for_load
def is_element_not_present(locator, elem_name, timeout=driver_wait_time, stop_on_fail=False):
    try:
        create_wait(timeout).until(EC.invisibility_of_element_located((locator[0], locator[1])))
    except (NoSuchElementException, TimeoutException) as ex:
        logger.info(f"Element {elem_name} is present")
        if stop_on_fail:
            raise ex
        return False
    logger.info(f"Element {elem_name} is not present")
    return True


@wait_for_load
def is_element_present_replace_value(locator, value, timeout=driver_wait_time, stop_on_fail=False):
    if not type(value) is list: value = [value]
    logger.info(f"Checking element with value: '{value}' is present")
    try:
        create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1].format(*value))))
    except (NoSuchElementException, TimeoutException) as ex:
        logger.info(f"Element with value: '{value}' is not present")
        if stop_on_fail:
            raise ex
        return False
    logger.info(f"Element with value: '{value}' is present")
    return True


@wait_for_load
def is_element_not_present_replace_value(locator, value, elem_name, timeout=driver_wait_time, stop_on_fail=False):
    try:
        create_wait(timeout).until(EC.invisibility_of_element_located((locator[0], locator[1].format(*value))))
    except (NoSuchElementException, TimeoutException) as ex:
        logger.info(f"Element {elem_name} is present")
        if stop_on_fail:
            raise ex
        return False
    logger.info(f"Element {elem_name} is not present")
    return True


@wait_for_load
def check_element_exists(locator, timeout=driver_wait_time):
    try:
        elem = create_wait(timeout).until(EC.element_to_be_clickable((locator[0], locator[1])))
    except (NoSuchElementException, TimeoutException) as error:
        logger.info(f"Element is not present on the page")
        return False
    return True


@wait_for_load
def is_element_enable(locator, elem_name, timeout=driver_wait_time):
    time.sleep(1)
    try:
        elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1])))
        ele_status = elem.is_enabled()
        if ele_status:
            logger.info(f"Element {elem_name} is present and enabled")
        else:
            logger.info(f"Element {elem_name} is present but disabled")
        return ele_status
    except (NoSuchElementException, TimeoutException) as error:
        logger.info(f"Element {elem_name} is not present on the page")
        return False


# Validates if checkbox is checked or not
@wait_for_load
def is_checkbox_checked(locator, elem_name, replace_value=list(), timeout=driver_wait_time):
    if type(replace_value) != list: replace_value = [replace_value]
    elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1].format(*replace_value))))
    checked = elem.is_selected()
    if checked:
        logger.info(f'Element {elem_name} is checked')
    else:
        logger.info(f'Element {elem_name} is not checked')
        return False
    return checked


@wait_for_load
def is_element_clickable(locator, elem_name, stop_on_fail=False, timeout=driver_wait_time):
    try:
        create_wait(timeout).until(EC.element_to_be_clickable((locator[0], locator[1])))
    except (NoSuchElementException, TimeoutException) as ex:
        logger.info(f"Element {elem_name} is not clickable")
        if stop_on_fail:
            raise ex
        return False
    logger.info(f"Element {elem_name} is present and Clickable")
    return True


@wait_for_load
def check_presence_of_element_dom(locator, timeout=driver_wait_time):
    try:
        elem = create_wait(timeout).until(EC.presence_of_all_elements_located((locator[0], locator[1])))
    except (NoSuchElementException, TimeoutException) as error:
        logger.info(f"Element is not present on the page")
        return False
    return True
