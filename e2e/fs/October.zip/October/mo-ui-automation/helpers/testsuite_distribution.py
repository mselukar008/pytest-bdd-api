import os
import shutil
import json


def distribute_tests(suite_list, test_path, provider):
    # suite_list = "Compute-Storage-App:test_gcp_cloud_storage.py,test_gcp_persistent_disk.py,test_gcp_compute_engine.py,test_gcp_pubsub.py;" \
    #              "DB-Network-App:test_gcp_cloud_spanner.py,test_gcp_tcp_load_balancing.py,test_gcp_udp_load_balancing.py,test_gcp_cloud_dns.py,test_gcp_vpc.py;" \
    #              "Special-Features:test_gcp_user_access_management.py,test_gcp_shopping_cart.py,test_gcp_budgetary_unit_single_user.py,test_gcp_budgatary_unit_multi_user.py"
    root_folder = os.getcwd()    
    source_folder_path = os.path.join(root_folder, test_path)
    suites = suite_list.split(";")
    # Create Results folder
    ui_automation_results_folder = os.path.join(root_folder, "ui-automation-results")
    if not os.path.exists(ui_automation_results_folder):
        os.makedirs(ui_automation_results_folder)
    junit_results_folder = os.path.join(ui_automation_results_folder, "JunitReports")
    if not os.path.exists(junit_results_folder):
        os.makedirs(junit_results_folder)

    suite_array = []
    for i in range(len(suites)):
        suite_name = suites[i].split(":")[0]
        suite_to_execute = suites[i].split(":")[1].split(",")
        # Create folder as per suite name
        new_folder_path = os.path.join(source_folder_path, suite_name)
        os.mkdir(new_folder_path)
        junit = os.path.join(junit_results_folder, suite_name)
        os.mkdir(junit)
        open(os.path.join(junit, "__init__.py"), 'a').close()
        ui_auto = os.path.join(ui_automation_results_folder, suite_name)
        os.mkdir(ui_auto)
        open(os.path.join(ui_auto, "__init__.py"), 'a').close()
        suite_array.append(new_folder_path + "/")
        # Copy the files from source folder to newly created folder
        for j in range(len(suite_to_execute)):
            file_name = suite_to_execute[j]
            shutil.move(os.path.join(source_folder_path, file_name), new_folder_path)
    y = json.dumps(suite_array)
    print(y)
    return y    


def main(args):
    distribute_tests(args.test_suite_list, args.suite_path, args.provider)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_suite_list")
    parser.add_argument("--suite_path")
    parser.add_argument("--provider", required=False)
    main(parser.parse_args())
