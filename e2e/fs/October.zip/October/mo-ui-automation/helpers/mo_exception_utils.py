from helpers.mo_driver_manager import *
from selenium.common.exceptions import *


def exceptions_decorator(function):
    def catch_exceptions(*args, **kwargs):
        try:
            value = function(*args, **kwargs)
            return value
        except(NoSuchElementException, TimeoutException, StaleElementReferenceException) as e:
            logger.info(f"test execution failed while finding the element{e.message}")

    return catch_exceptions
