import os
import sys
import platform
from configparser import ConfigParser
from enum import Enum
from helpers.mo_resources import root_folder

current_os = platform.system()

config = ConfigParser(comment_prefixes='/', allow_no_value=True)
if current_os == "Linux":
    config.read('config.ini')
else:
    config.read(os.path.join(root_folder, "config.ini"))


class SystemProperties(Enum):
    MO_TENANT_URL = ('mo.tenant.url', '')
    MO_CT_TENANT_URL = ('mo.ct_tenant.url', '')
    MO_CT_TENANT2_URL = ('mo.ct_tenant2.url', '')
    MO_SP_TENANT_URL = ('mo.sp_tenant.url', '')
    MO_TOPOLOGY_TENANT_URL = ('mo.topology_tenant.url', '')
    MO_TENANT_API_URL = ('mo.tenant.api_url', '')
    MO_HILLS_UNRESTRICTED_TENANT_URL = ('mo.hills_unrestricted_tenant.url', '')
    MO_BROWSER = ('mo.browser', 'chrome')
    MO_BROWSER_MODE = ('mo.browser_mode', '')
    MO_COLLECT_HAR = ('collect_har', 'false')
    MO_COLLECT_VIDEO = ('collect_video', '')
    MO_SECRET_IBM = ('mo.tenant.secretibm', '')
    MO_SECRET_KYN = ('mo.tenant.secretkyn', '')
    MO_ADAPTER = ('mo.tenant.adapter', '')
    MO_CURRENCY = ('mo.tenant.currency', '')
    MO_PROVIDERS_ADAPTERS = ('mo.tenant.providers_adapters', '')
    MO_KYN_ID = ('mo.kyn_id', '')
    MO_SLACK_WEBHOOK = ('mo.slack_webhook', '')
    MO_SKIP_LOGIN = ('mo.skip_login','true')
    MO_USER = ('mo.tenant.user','true')


    def __init__(self, property_name, default_value):
        self.property_name = property_name
        self.default_value = default_value

    def raw_value(self):
        try:
            return sys._xoptions[self.property_name]
        except KeyError:
            # check in config file
            return config['SystemProperties'].get(self.property_name, None)

    def value(self):
        rv = self.raw_value()
        return self.default_value if rv is None else rv

    def bool_value(self) -> bool:
        rv = self.raw_value()
        if rv and 'true' == rv:
            return True
        if rv and 'false' == rv:
            return False
        return bool(self.default_value)
