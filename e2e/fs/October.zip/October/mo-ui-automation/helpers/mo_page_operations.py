import time
import zipfile

from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from helpers.mo_selenium_helper import wait, driver
from helpers.mo_driver_manager import *
from selenium.webdriver.support import expected_conditions as EC
from locators.common.generic_element_operations_locator import *


class WaitForDocReady(object):
    def __call__(self, driver):
        page_state = driver.execute_script('return document.readyState;')
        return page_state == "complete"


class WaitForJQuery(object):

    # def __init__(self):
    # logger.info("Custom EC: WaitForJQuery")

    def __call__(self, driver):
        return driver.execute_script("return jQuery.active") == 0


def wait_for_load(function):
    def wait_check_js(*args, **kwargs):
        wait.until(WaitForDocReady())
        # if driver.execute_script("return typeof jQuery != 'undefined'"):
        #     wait.until(WaitForJQuery())
        value = function(*args, **kwargs)
        return value

    return wait_check_js


@wait_for_load
def upload_file(locator, file_path):
    logger.info("Trying to Upload to path: {0}  >> file:{1}".format(locator, file_path))
    elem = wait.until(EC.presence_of_element_located((locator[0], locator[1])))
    driver.execute_script(
        'arguments[0].style = ""; arguments[0].style.display = "block"; arguments[0].style.visibility = "visible";',
        elem)
    time.sleep(2)
    elem.send_keys(file_path)


@wait_for_load
def refresh_current_page():
    driver.refresh()


@wait_for_load
def switch_to_iframe(locator):
    logger.info("Switch to main iframe")
    # logger.info("Switch to iframe: {0}".format(locator))
    wait.until(EC.frame_to_be_available_and_switch_to_it((locator[0], locator[1])))


@wait_for_load
def switch_to_parent_iframe():
    logger.info("Switch to parent iframe:")
    driver.switch_to.parent_frame()


@wait_for_load
def switch_to_default_content_iframe():
    logger.info("Switch to default content iframe")
    driver.switch_to.default_content()


# Wait for the spinner to disappears
def wait_for_spinner_off():
    try:
        wait.until(EC.invisibility_of_element_located((spinner[0], spinner[1])))
        return True
    except TimeoutException:
        logger.info("Spinner is not disappeared after time limit")
        return False


# Wait for the spinner to appears
def wait_for_spinner_on():
    try:
        wait.until(EC.visibility_of_element_located((spinner[0], spinner[1])))
        return True
    except TimeoutException:
        logger.info("Spinner is not appeared after time limit")
        return False


def file_compress_zip(input_files, output_file, output_zipfile_path):
    compression = zipfile.ZIP_DEFLATED
    logger.info(f"Input Files passed for zipping - {input_files}")
    logger.info(f'Output Zip File - {output_file}')
    zf = zipfile.ZipFile(output_zipfile_path, mode="w")
    try:
        for file_to_write in input_files:
            logger.info(f'Processing file {file_to_write}')
            zf.write(file_to_write, os.path.basename(file_to_write), compress_type=compression)
    except FileNotFoundError as e:
        logger.info(f'Exception occurred during zip process - {e}')
    finally:
        zf.close()


def wait_for_loading_on():
    try:
        wait.until(EC.visibility_of_element_located((loader_title[0], loader_title[1])))
        return True
    except TimeoutException:
        logger.info("Loader is not appeared after time limit")
        return False


def wait_for_loading_off():
    try:
        wait.until(EC.invisibility_of_element_located((loader_title[0], loader_title[1])))
        return True
    except TimeoutException:
        logger.info("Loader is not disappeared after time limit")
        return False
   

# Pass time_out in seconds and should be multiple of 5
# e.g.5,10,15,20 etc.
def wait_for_spinner_off_with_timer(time_out):
    counter = time_out // 5
    for i in range(counter):
        try:
            create_wait(5).until(EC.invisibility_of_element_located((spinner[0], spinner[1])))
            return True
        except TimeoutException:
            logger.info("Spinner is not disappeared after time limit")
            if i > counter - 1:
                return False

# Wait for the updating to disappears
# def wait_for_updating_off():
#     try:
#         wait.until(EC.invisibility_of_element_located((By.CSS_SELECTOR, ".bx--loading__svg")))
#         return True
#     except TimeoutException:
#         logger.info("Spinner is not disappeared after time limit")
#         return False
