from helpers.mo_system_properties import SystemProperties

step_seperator = "---------------------------------------------------------------------------------------------------------------------------"
step_deco = "----------------------------------------"

tenant = SystemProperties.MO_TENANT_URL.value()
ct_tenant = SystemProperties.MO_CT_TENANT_URL.value()
ct_tenant2 = SystemProperties.MO_CT_TENANT2_URL.value()
sp_tenant = SystemProperties.MO_SP_TENANT_URL.value()
topology_tenant = SystemProperties.MO_TOPOLOGY_TENANT_URL.value()
api_tenant = SystemProperties.MO_TENANT_API_URL.value()
hills_unrestricted_tenant = SystemProperties.MO_HILLS_UNRESTRICTED_TENANT_URL.value()
mo_secret_ibm = SystemProperties.MO_SECRET_IBM.value()
mo_secret_kyn = SystemProperties.MO_SECRET_KYN.value()
browser = SystemProperties.MO_BROWSER.value()
browser_mode = SystemProperties.MO_BROWSER_MODE.value()
# collect_har = SystemProperties.MO_COLLECT_HAR.value()
collect_har_file = SystemProperties.MO_COLLECT_HAR.value()
# collect_video = SystemProperties.MO_COLLECT_VIDEO.value()
collect_video_file = SystemProperties.MO_COLLECT_VIDEO.value()
tenant_test_adapter = SystemProperties.MO_ADAPTER.value()
tenant_currency = SystemProperties.MO_CURRENCY.value()
providers_adapters = SystemProperties.MO_PROVIDERS_ADAPTERS.value()
kyndryl_id = SystemProperties.MO_KYN_ID.value()
slack_webhook = SystemProperties.MO_SLACK_WEBHOOK.value()
skip_login = SystemProperties.MO_SKIP_LOGIN.value()
MO_USER = SystemProperties.MO_USER.value()

