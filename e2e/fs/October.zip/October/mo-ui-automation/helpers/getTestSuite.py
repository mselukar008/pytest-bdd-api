from mo_json_utils import *


def get_tests_suite_for_execution(provider, suite_name, mo_app):
    test_config = "tests/tests_config.json"
    test_dir = "tests/" + mo_app + "/" + provider + "/"
    set_data_path(test_config)
    suite_list = None
    if suite_name == "":
        test_dir = test_dir.replace(":", "/")
        print(test_dir)
        return test_dir
    if ":" in provider:
        test_dir = test_dir.replace(":", "/")
        test_data = None
        test_data_orgnl = None
        for pr in provider.split(":"):
            if test_data is None:
                test_data = get_data("Test Config")[pr]
            else:
                test_data = test_data[pr]
        test_data_orgnl = test_data
        test_dir_orgnl = test_dir
        for suite in suite_name.split(","):
            if suite in "homo" or suite in "hetero" or suite in "mq":
                test_data = test_data["cart"]
                test_dir = test_dir + "cart/"
            if suite_list is None:
                suite_list = test_dir + str(test_data[suite])
            else:
                suite_list = suite_list + " " + test_dir + str(test_data[suite])
            test_data = test_data_orgnl
            test_dir = test_dir_orgnl
    else:
        for suite in suite_name.split(","):
            if suite_list is None:
                suite_list = test_dir + str(get_data("Test Config")[provider][suite])
            else:
                suite_list = suite_list + " " + test_dir + str(get_data("Test Config")[provider][suite])
    print(suite_list)
    return suite_list


def main(args):
    get_tests_suite_for_execution(args.provider, args.suite_name, args.mo_app)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--provider")
    parser.add_argument("--suite_name", required=False)
    parser.add_argument("--mo_app", required=False)
    main(parser.parse_args())
