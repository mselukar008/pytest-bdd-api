import warnings
from selenium.webdriver import Proxy
from selenium.webdriver.common.proxy import ProxyType
from webdriver_manager.chrome import ChromeDriverManager
from helpers.mo_system_properties import current_os
from proxy_server import ProxyServer
from ui_config import *
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.ui import WebDriverWait
import logging

driver_wait_time = int(driver_max_wait_time)
driver = None
wait = None
url = ""
server = None
proxy_server: ProxyServer = None

logger = logging.getLogger(__name__)


def create_driver():
    web_driver = None
    browser_type = browser.lower()
    if os.environ.get("Browser"):
        browser_type = os.environ.get("Browser").lower()
    if browser_type == "firefox":
        cap = DesiredCapabilities().FIREFOX
        cap["marionette"] = True
        firefox_options = webdriver.FirefoxOptions()
        firefox_options.set_preference("dom.disable_beforeunload", True)
        web_driver = webdriver.Firefox(options=firefox_options)
    elif browser_type == "chrome":
        chrome_options = set_chrome_options()
        capabilities = webdriver.DesiredCapabilities.CHROME
        if os.environ.get("collect_har") == "yes" or collect_har == "yes":
            proxy_url = f"{proxy_server.address}:{proxy_server.port}"
            proxy_chrome = Proxy({
                'proxyType': ProxyType.MANUAL,
                'httpProxy': proxy_url,
                'sslProxy': proxy_url,
                'noProxy': ''
            })
            proxy_chrome.to_capabilities(capabilities)
        if browser_mode == "headless":
            #chrome_options.headless = True
            chrome_options.add_argument("--headless")
            chrome_options.add_argument("--window-size=1920,1080")
        warnings.filterwarnings(action="ignore", message="unclosed", category=ResourceWarning)
        web_driver = webdriver.Chrome(options=chrome_options)

    web_driver.execute_script("document.body.style.zoom='100%'")
    return web_driver


def create_wait(timeout=driver_max_wait_time):
    web_driver_wait = WebDriverWait(driver, timeout)
    return web_driver_wait


class create_driver_instance:

    def get_driver(self):
        global driver
        global proxy_server
        if not driver:
            if os.environ.get("collect_har") == "yes" or collect_har == "yes":
                proxy_server = ProxyServer()
                proxy_server.start_capture("login")
            driver = create_driver()

        return driver

    def get_wait(self):
        global wait
        if not wait:
            wait = create_wait()
        return wait


def capture_screenshot(image_name):
    driver.get_screenshot_as_file(image_name)


def kill_driver_instance():
    global driver
    driver.close()
    driver.quit()


def create_action_chains():
    return ActionChains(driver)


def load_url(app_url):
    logger.info(f"Driver wait time:::{driver_wait_time}")
    try:
        driver.get("https://" + app_url)
    except:
        logger.info("Loading BaseURL again..")
        driver.get("https://" + app_url)
    logger.info(f"Load URL: https://{app_url}")
    driver.maximize_window()


def reload_url(app_url):
    logger.info("RELOADING TO BASE PAGE: " + app_url)
    driver.get(app_url)
    driver.maximize_window()


def get_current_url():
    return driver.current_url


def set_chrome_options():
    options = webdriver.ChromeOptions()
    if current_os == "Linux":
        options.binary_location = "/usr/bin/google-chrome"
        options.add_argument('--disable-dev-shm-usage')
    # options.add_argument("--disable-blink-features")
    user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5615.50 ' \
                 'Safari/537.36 '
    options.add_argument(f'user-agent={user_agent}')
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--disable-setuid-sandbox")
    options.add_argument("--disable-notifications")
    options.add_argument("--disable-popup-blocking")
    options.add_argument("--allow-insecure-localhost")
    options.add_argument('ignore-certificate-errors')
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    preferences = {
        "profile.default_content_setting_values.automatic_downloads": 1,
        "download.default_directory": output_folder,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    }
    options.add_experimental_option("prefs", preferences)
    return options


def set_firefox_preferences():
    profile = webdriver.FirefoxProfile()
    profile.set_preference("network.proxy.type", 4)
    profile.set_preference("browser.download.folderList", 2)
    profile.set_preference("browser.download.manager.showWhenStarting", False)
    profile.set_preference("browser.download.dir", output_folder)
    profile.set_preference("browser.helperApps.neverAsk.saveToDisk", "application/octet-stream")
    profile.update_preferences()
    return profile


def delete_cookies():
    send_command = ('POST', '/session/$sessionId/chromium/send_command')
    driver.command_executor._commands['SEND_COMMAND'] = send_command
    driver.execute('SEND_COMMAND', dict(cmd='Network.clearBrowserCookies', params={}))
