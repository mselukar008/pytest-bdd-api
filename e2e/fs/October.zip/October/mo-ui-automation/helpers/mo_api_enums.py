"""
    * Please keep class names alphabetical
    * Please keep variables in classes alphabetical
"""
import os
from enum import Enum


from helpers.mo_env import tenant


class Version:
    V1 = "v1",
    V2 = "v2",
    V3 = "v3",
    V4 = "v4",
    V5 = "v5",
    NA = ""


class Aiops(Enum):
    HEALTH = ""


class ServiceNow(Enum):
    SERVICE_REQUEST = ""


class Store(Enum):
    ORDER_STATUS = (tenant, Version.V5, '/api/orders?searchText={}')
    CHANGE_TYPE = (tenant, Version.NA,  '/core/configuration/v1/configvalues')
    EXTERNAL_APPROVAL = (tenant, Version.NA, '/order_workflow/api/configuration/v2')
    GET_BUDGETARY_UNITS = (tenant, Version.NA, '/budgetmanagement/v1/budgetaryunits?limit=10&offset=0&sort_order=asc&sort_by=name&status={}')
    GET_BUDGET = (tenant, Version.NA, '/budgetmanagement/v1/{}/budget?limit=10&offset=0&sort_order=asc&sort_by=name')
    UPDATE_DELETE_BUDGET = (tenant, Version.NA, '/budgetmanagement/v1/{}/budget/{}')
    UPDATE_DELETE_BUDGETARY_UNIT = (tenant, Version.NA, '/budgetmanagement/v1/budgetaryunits/{}')
    GET_SHOPPING_CART = (tenant, Version.NA, '/shoppingbag/v1/bags?bagStatus=noncheckedout&sort=createdAt&sortOrder=desc')
    DELETE_SHOPPING_CART = (tenant, Version.NA, '/shoppingbag/v1/bags/{}')  
    API_URL = (tenant, Version.NA, '')

    def __init__(self, base_url, version, path):
        if os.environ.get("Environment"):
            base_url = os.environ.get("Environment")
        self.base_url = base_url
        self.version = version
        self.path = path

    def get_path_name(self, param=None):
        array_url = self.base_url.split(".")
        array_url[0] = "https://" + array_url[0] + "-api"
        api_url = '.'.join(str(url) for url in array_url)
        if param:
            path = self.path.format(param)
        else:
            path = self.path
        if self.version == "":
            return ''.join((api_url, path))
        return ''.join((api_url, self.version, path))
