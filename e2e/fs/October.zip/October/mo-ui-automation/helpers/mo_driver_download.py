import re
import subprocess
from sys import platform

from helpers.mo_env import *
from helpers.mo_selenium_helper import logger
from ui_config import *


def get_existing_driver_version(driver_with_path):
    out = subprocess.run([driver_with_path, "--version"], stdout=subprocess.PIPE)
    version = str(out.stdout, 'utf-8').rstrip()
    version_split = re.findall(r"[-+]?\d*\.\d+|\d+", version)
    driver_version = version_split[0] + version_split[1]
    return driver_version


def download_firefox_driver(link, file_name):
    init_http_proxy = False
    init_https_proxy = False
    init_http_proxy_value = None
    init_https_proxy_value = None
    if "http_proxy" in os.environ:
        init_http_proxy = True
        init_http_proxy_value = os.environ["http_proxy"]
        logger.info("Existing http_proxy value: {}".format(init_http_proxy_value))
    if "https_proxy" in os.environ:
        init_https_proxy = True
        init_https_proxy_value = os.environ["https_proxy"]
        logger.info("Existing https_proxy value: {}".format(init_https_proxy_value))

    logger.info("Setting proxy")
    os.environ["http_proxy"] = "www-proxy-hqdc.us.oracle.com:80"
    os.environ["https_proxy"] = "www-proxy-hqdc.us.oracle.com:80"

    logger.info("Downloading Firefox driver")
    logger.info("Changing current directory to: {}".format(driver_path))
    os.chdir(driver_path)
    logger.info("Downloading driver")
    os.system('curl -OL {download_link}'.format(download_link=link))
    logger.info("Download completed... extracting")
    os.system('tar -xvf  {file}'.format(file=file_name))
    logger.info("Extracted driver.. deleting downloaded file")
    os.system('rm {file}'.format(file=file_name))

    logger.info("Unset proxy")
    os.environ["http_proxy"] = ""
    os.environ["https_proxy"] = ""

    if init_http_proxy:
        logger.info("Setting http_proxy to earlier value: {}".format(init_http_proxy_value))
        os.environ["http_proxy"] = init_http_proxy_value
    if init_https_proxy:
        logger.info("Setting https_proxy to earlier value: {}".format(init_https_proxy_value))
        os.environ["https_proxy"] = init_https_proxy_value


def download_browser_driver_for_mac():
    if browser.lower() == "firefox":
        download_needed = False
        # get firefox browser version
        logger.info("Getting installed Firefox version")
        out = subprocess.run(["mdfind", "{query}".format(query='kMDItemFSName = Firefox.app')], stdout=subprocess.PIPE)
        firefox_path = str(out.stdout, 'utf-8').rstrip()
        firefox_executable_path = os.path.join(firefox_path, "Contents/MacOS/firefox")

        if len(firefox_path) == 0:
            logger.error("Firefox browser not found in: {}".format(firefox_executable_path))
            assert False

        logger.info("Checking for Firefox version at: {}".format(firefox_executable_path))
        out = subprocess.run([firefox_executable_path, '--version'], stdout=subprocess.PIPE)
        read_version = str(out.stdout, 'utf-8').rstrip()
        firefox_version_number = float(re.findall(r"[-+]?\d*\.\d+|\d+", read_version)[0])

        logger.info("Expected Firefox browser version is 60 and above")
        logger.info("Got Firefox browser version: {}".format(firefox_version_number))

        if firefox_version_number >= 60.0:
            expected_driver_version = "0.26.0"
            logger.info("Expected Firefox driver version: {}".format(expected_driver_version))
        else:
            logger.info("Firefox version {} driver download not supported".format(firefox_version_number))
            return

        ff_driver_path = os.path.join(driver_path, 'geckodriver')
        existing_driver_version = "0"
        if os.path.exists(ff_driver_path):
            existing_driver_version = get_existing_driver_version(ff_driver_path)
            logger.info("Existing Firefox driver version: {}".format(existing_driver_version))
            if existing_driver_version != expected_driver_version:
                download_needed = True
                logger.info("Deleting existing Firefox driver")
                os.system('rm {}'.format(ff_driver_path))
        else:
            logger.info("No existing driver")
            download_needed = True
        if download_needed:
            link = "https://github.com/mozilla/geckodriver/releases/download/v0.26.0/geckodriver-v0.26.0-macos.tar.gz"
            file_name = "geckodriver-v0.26.0-macos.tar.gz"
            download_firefox_driver(link, file_name)

    elif browser.lower() == "chrome":
        download_needed = False
        # get chrome browser version
        logger.info("Getting installed Chrome browser version")
        out = subprocess.run(["mdfind", "{query}".format(query='kMDItemFSName = *Chrome.app')], stdout=subprocess.PIPE)
        chrome_path = str(out.stdout, 'utf-8').rstrip()
        chrome_executable_path = os.path.join(chrome_path, "Contents/MacOS/Google Chrome")

        if len(chrome_path) == 0:
            logger.error("Firefox browser not found in: {}".format(chrome_executable_path))
            assert False

        logger.info("Checking for Chrome version at: {}".format(chrome_executable_path))
        out = subprocess.run([chrome_executable_path, '--version'], stdout=subprocess.PIPE)
        read_version = str(out.stdout, 'utf-8').rstrip()
        read_version_split = re.findall(r"[-+]?\d*\.\d+|\d+", read_version)
        chrome_version_number = read_version_split[0] + read_version_split[1]

        logger.info("Got Chrome browser version: {}".format(chrome_version_number))

        chrome_driver_path = os.path.join(driver_path, 'chromedriver')
        if os.path.exists(chrome_driver_path):
            existing_driver_version = get_existing_driver_version(chrome_driver_path)
            logger.info("Existing Chrome driver version: {}".format(existing_driver_version))
            if not chrome_version_number == existing_driver_version:
                download_needed = True
                logger.info("Deleting existing Chrome driver")
                os.system('rm {}'.format(chrome_driver_path))
            else:
                logger.info("Existing Chrome driver can be used")
                return
        else:
            logger.info("No existing driver")
            download_needed = True
        if download_needed:
            init_http_proxy = False
            init_https_proxy = False
            if "http_proxy" in os.environ:
                init_http_proxy = True
                init_http_proxy_value = os.environ["http_proxy"]
            if "https_proxy" in os.environ:
                init_https_proxy = True
                init_https_proxy_value = os.environ["https_proxy"]

            # getting expected driver version
            page = urllib.request.urlopen('https://chromedriver.storage.googleapis.com')
            content = str(page.read(), 'utf-8')
            found = re.findall(r"<Key>" + chrome_version_number + "\\.([0-9]+)/chromedriver_mac64.zip</Key>", content)
            max_version_found = (max([int(i) for i in found]))
            download_driver_version = chrome_version_number + "." + str(max_version_found)

            logger.info("Expected Chrome driver version: {}".format(download_driver_version))

            logger.info("Downloading Chrome driver")
            os.chdir(driver_path)
            os.system(
                'curl -OL https://chromedriver.storage.googleapis.com/' + download_driver_version + '/chromedriver_mac64.zip')
            logger.info("Download completed... extracting")
            os.system('unzip  chromedriver_mac64.zip')
            os.system('rm chromedriver_mac64.zip')

            logger.info("Unset proxy")
            os.environ["http_proxy"] = ""
            os.environ["https_proxy"] = ""

            if init_http_proxy:
                os.environ["http_proxy"] = init_http_proxy_value
            if init_https_proxy:
                os.environ["https_proxy"] = init_https_proxy_value
    else:
        logger.info("Browser specified is not Firefox or Chrome")
        logger.info("Auto-download of driver is not supported")


def download_browser_driver_for_linux():
    if browser.lower() == "firefox":
        download_needed = False
        # get firefox browser version
        logger.info("Getting installed Firefox version")
        out = subprocess.run(["firefox", "-v"], stdout=subprocess.PIPE)
        read_version = str(out.stdout, 'utf-8').rstrip()

        if "not found" in read_version:
            logger.error("Firefox browser not found ")
            assert False

        firefox_version_number = float(re.findall(r"Firefox ([-+]?\d*\.\d+|\d+)", read_version)[0])

        logger.info("Expected Firefox browser version is 60 and above")
        logger.info("Got Firefox browser version: {}".format(firefox_version_number))

        if firefox_version_number >= 60.0:
            expected_driver_version = "0.26.0"
            logger.info("Expected Firefox driver version: {}".format(expected_driver_version))
        else:
            logger.info("Firefox version {} driver download not supported".format(firefox_version_number))
            return

        ff_driver_path = os.path.join(driver_path, 'geckodriver')
        existing_driver_version = "0"
        if os.path.exists(ff_driver_path):
            existing_driver_version = get_existing_driver_version(ff_driver_path)
            logger.info("Existing Firefox driver version: {}".format(existing_driver_version))
            if existing_driver_version != expected_driver_version:
                download_needed = True
                logger.info("Deleting existing Firefox driver")
                os.system('rm {}'.format(ff_driver_path))
        else:
            logger.info("No existing driver")
            download_needed = True
        if download_needed:
            link = "https://github.com/mozilla/geckodriver/releases/download/v0.26.0/geckodriver-v0.26.0-linux64.tar.gz"
            file_name = "geckodriver-v0.26.0-linux64.tar.gz"
            download_firefox_driver(link, file_name)
    else:
        logger.info("Browser is not Firefox")
        logger.info("Auto-download of driver is not supported")
        return


def download_browser_driver():
    logger.info("Drivers are expected in folder: {}".format(driver_path))
    logger.info("Auto download for drivers enabled for:")
    logger.info("Platform: Linux  ||  Browser: Firefox")
    logger.info("Platform: Mac  ||  Browser: Firefox, Chrome")
    logger.info("Assumption: Browser is installed in default location for Mac")
    if not os.path.exists(driver_path):
        logger.info("Creating directory for browser driver: {}".format(driver_path))
        os.makedirs(driver_path)
    current_os = platform.system()
    if current_os == "Linux":
        logger.info("This is Linux")
        download_browser_driver_for_linux()
    if current_os == "Darwin":
        logger.info("This is mac")
        download_browser_driver_for_mac()
    if current_os == "Windows":
        logger.info("This is Windows")
        logger.info("Not supporting auto-download for Windows now")
        return
