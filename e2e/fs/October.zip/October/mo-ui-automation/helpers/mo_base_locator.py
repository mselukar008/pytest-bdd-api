from selenium.webdriver.common.by import By

# LOCATOR TYPE
class_name = By.CLASS_NAME
id = By.ID
xpath = By.XPATH
name = By.NAME
css_selector = By.CSS_SELECTOR
link_text = By.LINK_TEXT
tag_name = By.TAG_NAME
