import json
from collections.abc import Mapping
import logging

logger = logging.getLogger(__name__)

data_path = None
dic_data = None
modify_data = dict()


def set_data_path(file_path):
    global data_path
    data_path = file_path
    global dic_data
    dic_data = get_json_object(data_path)
    if type(modify_data) == dict and len(modify_data.items()):
        modify_main_dict_value_param()


def get_json_object(file_path):
    with open(file_path, 'r') as f:
        distros_dict = json.load(f)
    return distros_dict


def parse_json_recursively(json_object, target_key):
    my_dict = {}
    if type(json_object) is dict and json_object:
        for key in list(json_object.keys()):
            if key == target_key:
                my_dict[key] = json_object[key]
            parse_json_recursively(json_object[key], target_key)
    elif type(json_object) is list and json_object:
        for item in json_object:
            parse_json_recursively(item, target_key)

    return my_dict


def fetch_data(target_key, nested_dictionary):
    for key, dic_value in nested_dictionary.items():
        if type(dic_value) is dict and dic_value:
            if key == target_key:
                return dic_value
        if type(dic_value) is dict and dic_value:
            for x in dic_value:
                if x == target_key:
                    return dic_value[x]
        elif type(dic_value) is str and dic_value:
            for key_string, value_string in nested_dictionary.items():
                if key_string == target_key:
                    return value_string
            return None
    return dic_value


def get_data(target_key, nested_dictionary=None):
    global dic_data
    if dic_data is None and nested_dictionary is None:
        dic_data = get_json_object(data_path)
    if nested_dictionary:
        test_data = fetch_data(target_key, nested_dictionary)
        return test_data
    if dic_data:
        test_data = fetch_data(target_key, dic_data)
        return test_data


def get_json_data_key(target_key, nested_dictionary=None):
    if nested_dictionary is None:
        nested_dictionary = parse_json_recursively(dic_data, target_key)
        for key, data in nested_dictionary.items():
            if type(data) is not dict and data:
                return data
            else:
                return nested_dictionary
    elif nested_dictionary:
        for key, dic_value in nested_dictionary.items():
            if key == target_key:
                return dic_value


# Function returns value from json object based on key
def get_value(json_object, exp_key, similar=False):
    for key, data in json_object.items():
        if (key.lower() == exp_key.lower() or (exp_key.lower() in key.lower() and similar)) and type(
                data) == dict and data.get('value'):
            # Skip the value and return None if flag is true
            if data.get('skip_value'):
                return None
            return data.get('value')
        # Handling for Empty json objects in data file
        elif type(data) == dict and len(data):
            aux_value = get_value(data, exp_key)
            if aux_value is not None:
                return aux_value
    return None


# Function returns dictionary of all child objects from json based on parent object, old version of get_data method
def get_data_object(target_key, nested_dictionary=None):
    if nested_dictionary is None:
        nested_dictionary = parse_json_recursively(dic_data, target_key)
        for key, data in nested_dictionary.items():
            if type(data) is not dict and data:
                return data
            else:
                return nested_dictionary
    elif nested_dictionary is not None:
        test_data = fetch_data(target_key, nested_dictionary)
        return test_data


# Merge two dictionaries with nested dictionaries (original parameter is modified with new values)
def dict_merge(original, new):
    for key, _ in new.items():
        if (key in original and isinstance(original[key], dict)
                and isinstance(new[key], Mapping)):
            dict_merge(original[key], new[key])
        else:
            original[key] = new[key]


# Modify multiple values in a dict
def modify_main_dict_multiple_keys(keys: list, values, delete=False, initial_position=-1):
    position_index = initial_position
    # In case of add or update send a dictionary
    if type(values) == dict:
        for key, value in values.items():
            modify_main_dict([*keys, key], value, delete=delete, position=position_index)
            if initial_position > -1:
                position_index += 1
    # In case of delete send a list of keys to delete
    elif type(values) == list:
        for value in values:
            modify_main_dict([*keys, value], None, delete=delete, position=position_index)
            if initial_position > -1:
                position_index += 1


# Adds, Updates or Removes a key value in the dict data, needs to send the route of the key in a list
# (must be in order), eg: ['Main Parameter','Main Parameters','Team']
def modify_main_dict(keys: list, new_value=None, delete=False, position=-1):
    global dic_data
    aux_dict = dic_data
    for key in keys[:-1]:
        if key in aux_dict:
            aux_dict = aux_dict[key]
        else:
            aux_dict = aux_dict.setdefault(key, {})
    if keys[-1] in aux_dict and delete:
        del aux_dict[keys[-1]]
    elif position > -1:
        # Inserts the new key in specific position
        position_dict = dict()
        index = 0
        for key, value in aux_dict.items():
            if index == position:
                position_dict = {**position_dict, keys[-1]: new_value}
            position_dict = {**position_dict, key: value}
            index += 1
        aux_dict.clear()
        aux_dict.update(position_dict)
    else:
        aux_dict[keys[-1]] = new_value
    return dic_data


def modify_parameter(param):
    global modify_data
    modify_data = param


# Modify the 'value' key inside of the dic_data
def modify_main_dict_value_param():
    for modify_key, modify_value in modify_data.items():
        modify_key_list = modify_key.split('.')
        # If separated with dots, find by an especific route. Eg: 'Edit Budgetary Unit.Name'
        if len(modify_key_list) > 1:
            modify_main_dict([*modify_key_list, 'value'], modify_value)
            continue
        # First key found
        key_found = search_dict_key(dic_data, modify_key, contains_key='value')
        if type(key_found) == dict:
            key_found['value'] = modify_value


# Search a given key inside dictionary recursively
def search_dict_key(target_dict, search_key, contains_key=None):
    for key, value in target_dict.items():
        if key == search_key and contains_key and type(value) == dict and value.get(contains_key):
            return target_dict[key]
        elif key == search_key and not contains_key:
            return target_dict[key]
        elif type(value) == dict:
            key_found = search_dict_key(target_dict[key], search_key, contains_key)
            if key_found:
                return key_found
    return None


# Update JSON file value using a specific key
def update_json_file_single_value(json_file_path, key, value):
    with open(json_file_path, 'r') as file:
        json_data = json.load(file)
        json_data[key] = value
    with open(json_file_path, 'w') as file:
        # 'indent' attribute is used to keep indentation in json file
        json.dump(json_data, file, indent=4)
        logger.info(f"Updated {key} with {value} in json")


# Update dictionary in a list of json file
def update_json_dict_in_list_single_value(json_file_path, main_key, key, value):
    with open(json_file_path, 'r') as file:
        json_data = json.load(file)
        main = json_data[main_key]
        for i in range(len(main)):
            main[0][key] = value
    with open(json_file_path, 'w') as file:
        json.dump(json_data, file, indent=4)
        logger.info(f"Updated {key} with {value} in json")
