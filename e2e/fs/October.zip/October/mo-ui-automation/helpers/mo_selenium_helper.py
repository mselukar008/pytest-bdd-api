import inspect
from selenium.webdriver.common.by import By
from helpers.mo_driver_manager import create_driver_instance
import logging

logger = logging.getLogger(__name__)

driver = create_driver_instance().get_driver()
wait = create_driver_instance().get_wait()


def current_test_name():
    for stack in inspect.stack():
        if stack.function.startswith("test_"):
            return stack.function
    else:
        return "Dummy"


def get_locator_type(value):
    if value == 'xpath':
        return By.XPATH
    if value == 'css':
        return By.CSS_SELECTOR
    if value == 'id':
        return By.ID
