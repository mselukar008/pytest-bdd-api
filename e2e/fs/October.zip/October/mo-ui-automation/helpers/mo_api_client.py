import json
import requests
from urllib3 import Retry
from helpers.mo_driver_manager import logger
from pages.store.service_now_page import setup_snow_qs
import logging
logging.getLogger("urllib3.connectionpool").setLevel(logging.ERROR)

session = requests.Session()
retries = Retry(total=5, connect=10, backoff_factor=1,
                status_forcelist=[500, 502, 503, 504])
adapter = requests.adapters.HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)


def create_headers(username=None, apikey=None, bearer_token=None):
    if username and apikey:
        headers = {
            'username': username,
            'apikey': apikey,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    elif username and bearer_token:
        headers = {
            'username': username,
            'Authorization': f'Bearer {bearer_token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    else:
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    return headers


def get_call(host_url, username=None, apikey=None, bearer_token=None, raise_exception=True):
    headers = create_headers(username, apikey, bearer_token)
    json_resp = session.get(url=host_url, headers=headers)
    logger.info("json_resp.status_code " + str(json_resp.status_code))
    if json_resp.status_code != 200 and raise_exception:
        logger.info("Status code " + str(json_resp.status_code))
        raise Exception("Didn't receive the response")
    json_data = parse_response(json_resp.text)
    return json_data


def post_call(host_url, json_payload, username=None, apikey=None, bearer_token=None, raise_exception=True):
    headers = create_headers(username, apikey, bearer_token)
    json_resp = session.post(url=host_url, data=json_payload, headers=headers)
    if (json_resp.status_code != 200 and json_resp.status_code != 201 and json_resp.status_code != 202) and raise_exception:
        logger.info("Status code " + str(json_resp.status_code))
        raise Exception("Didn't receive the response")
    json_data = parse_response(json_resp.text)
    return json_data, json_resp.status_code


def put_call(host_url, json_payload, username=None, apikey=None, bearer_token=None, raise_exception=True, snow=False):
    headers = create_headers(username, apikey, bearer_token)
    if snow:
        url, username, password = setup_snow_qs()
        json_resp = session.put(url=host_url, data=json_payload, headers=headers, auth=(username, password))
    else:
        json_resp = session.put(url=host_url, data=json_payload, headers=headers)
    if (json_resp.status_code != 200 and json_resp.status_code != 201 and json_resp.status_code != 202) and raise_exception:
        logger.info("Status code " + str(json_resp.status_code))        
        raise Exception("Didn't receive the response")
    json_data = parse_response(json_resp.text)
    return json_data, json_resp.status_code


def delete_call(host_url, username=None, apikey=None, bearer_token=None, raise_exception=True):
    headers = create_headers(username, apikey, bearer_token)
    json_resp = session.delete(url=host_url, headers=headers)
    if  json_resp.status_code != 200 and raise_exception:
        logger.info("Status code " + str(json_resp.status_code))
        logger.info("Message " + str(json_resp.text))
        raise Exception("Didn't receive the response")
    json_data = parse_response(json_resp.text)
    return json_data


#Parse json if is posible, else return text
def parse_response(response_text):
    try:
        return json.loads(response_text)
    except:
        return response_text
