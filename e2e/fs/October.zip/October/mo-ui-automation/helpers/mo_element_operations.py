import time
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import *
from selenium.webdriver.remote.webelement import WebElement
from helpers.mo_selenium_helper import wait, driver
from helpers.mo_driver_manager import *
from helpers.mo_element_validation import is_element_present
from helpers.mo_page_operations import wait_for_load, wait_for_spinner_off
from selenium.webdriver.support import expected_conditions as EC


@wait_for_load
def click(locator, elem_name, timeout=driver_wait_time):
    wait_for_spinner_off()
    elem = create_wait(timeout).until(EC.element_to_be_clickable((locator[0], locator[1])))
    elem.click()
    logger.info(f"Clicked on {elem_name}")


@wait_for_load
def click_multiple(locator, elem_name, timeout=driver_wait_time):
    # Click in all elements with same locator
    elements = create_wait(timeout).until(EC.presence_of_all_elements_located((locator[0], locator[1])))
    for elem in elements:
        if elem.is_displayed():
            elem.click()
    logger.info(f"Clicked on elements {elem_name}")


def click_index_based(xpath_locator, index, elem_name):
    try:
        elems = driver.find_elements(By.XPATH, xpath_locator[1])
    except (NoSuchElementException, TimeoutException):
        return 0
    elems[index].click()
    logger.info(f"Clicked on {elem_name}")


@wait_for_load
def click_with_replace_value(locator, value, elem_name, timeout=driver_wait_time):
    if not type(value) is list: value = [value]
    elem = create_wait(timeout).until(EC.element_to_be_clickable((locator[0], locator[1].format(*value))))
    elem.click()
    logger.info(f"Clicked on : {elem_name} with replace value: {value}")


@wait_for_load
def scroll_element_into_view(locator, is_click=False, timeout=driver_wait_time):
    logger.info("Scrolling element into view")
    elem = create_wait(timeout).until(EC.presence_of_element_located((locator[0], locator[1])))
    driver.execute_script("arguments[0].scrollIntoView();", elem)
    if is_click:
        driver.execute_script("arguments[0].scrollIntoView();", elem)


@wait_for_load
def scroll_and_get_element_text(locator, is_click=False, timeout=driver_wait_time):
    logger.info("Scrolling element into view")
    elem = create_wait(timeout).until(EC.presence_of_element_located((locator[0], locator[1])))
    driver.execute_script("arguments[0].scrollIntoView();", elem)
    if is_click:
        driver.execute_script("arguments[0].scrollIntoView();", elem)
    explicit_wait(1)
    actual_text = elem.text
    logger.info(f"Text returned from element locator is {actual_text}")
    return actual_text


@wait_for_load
def scroll_and_get_text_with_replace_value(locator, value, elem_name, is_click=False, timeout=driver_wait_time):
    if not type(value) is list: value = [value]
    logger.info(f"Scrolling to view next element for subsequent action(s)..")
    elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1].format(*value))))
    driver.execute_script("arguments[0].scrollIntoView();", elem)
    if is_click:
        driver.execute_script("arguments[0].click();", elem)
        logger.info(f"Clicked on {value}")
    time.sleep(1)
    actual_text = elem.text
    logger.info(f"Element: {elem_name} replaced with value: {value} has Text: {actual_text}")
    return actual_text


@wait_for_load
def scroll_to_bottom():
    logger.info("Scrolling to bottom of the page")
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")


def scroll_up():
    driver.execute_script("scrollBy(0,-2000)")


@wait_for_load
def actions_move_to_element(actions, locator, timeout=driver_wait_time):
    elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1])))
    actions.move_to_element(elem).perform()


@wait_for_load
def actions_move_element(actions, elem):
    actions.move_to_element(elem).perform()


@wait_for_load
def actions_move_to_element_and_click(actions, elem):
    actions.move_to_element(elem).click(elem).perform()


@wait_for_load
def actions_move_to_element_and_click_with_replace_value(actions, locator, value, timeout=10):
    if not type(value) is list: value = [value]
    elem = create_wait(timeout).until(EC.presence_of_element_located((locator[0], locator[1].format(*value))))
    actions.move_to_element(elem).click(elem).perform()


@wait_for_load
def get_elements_count(locator, timeout=driver_wait_time):
    try:
        elems = create_wait(timeout).until(EC.visibility_of_all_elements_located((locator[0], locator[1])))
        actual_count = len(elems)
    except (NoSuchElementException, TimeoutException):
        return 0
    logger.info(f"Elements count: {actual_count}")
    return actual_count


@wait_for_load
def get_elements_count_replace_value(locator, value, timeout=driver_wait_time):
    if not type(value) is list: value = [value]
    logger.info(f"Get elements count given xpath: {locator} replace with: {value} and with no wait")
    try:
        elems = create_wait(timeout).until(
            EC.visibility_of_all_elements_located((locator[0], locator[1].format(*value))))
        actual_count = len(elems)
    except (NoSuchElementException, TimeoutException):
        return 0
    logger.info(f"Elements count: {actual_count}")
    return actual_count


@wait_for_load
def get_elements_count_given_xpath_no_wait(locator):
    logger.info(f"Get elements count given xpath: {locator} and with no wait")
    try:
        elems = driver.find_elements(By.XPATH, locator[1])
    except (NoSuchElementException, TimeoutException):
        return 0
    return len(elems)


@wait_for_load
def get_elements_count_replace_value_given_xpath_no_wait(locator, value):
    if not type(value) is list: value = [value]
    logger.info(f"Get elements count given xpath: {locator} replace with: {value} and with no wait")
    xpath = locator[1].format(*value)
    try:
        elems = driver.find_elements(By.XPATH, xpath)
    except (NoSuchElementException, TimeoutException):
        return 0
    return len(elems)


@wait_for_load
def get_element_text(locator, timeout=driver_wait_time):
    elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1])))
    actual_text = elem.text
    logger.info(f"Text returned from element locator is {actual_text}")
    return actual_text


@wait_for_load
def clear_input_field_entry(locator, timeout=driver_wait_time):
    elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1])))
    elem.clear()
    time.sleep(2)


@wait_for_load
def type_value(locator, value, elem_name, timeout=driver_wait_time):
    wait_for_spinner_off()
    elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1])))
    elem.clear()
    elem.send_keys(value)
    if not "password" in elem_name:
        logger.info(f"Entered text {value} in textbox {elem_name}")
    else:
        logger.info(f"Entered password ********** in textbox {elem_name}")


@wait_for_load
def type_value_delay(locator, value, elem_name, timeout=driver_wait_time):
    wait_for_spinner_off()
    value_array = [char for char in value]
    elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1])))
    elem.clear()
    for val in value_array:
        elem.send_keys(val)
        explicit_wait(1)

    logger.info(f"Entered text {value} in textbox {elem_name}")

@wait_for_load
def type_value_as_human(locator, text, elem_name, typing_interval=0.5, timeout=driver_wait_time):
    """Allow to type a value on input text element doing a wait between every letter type
    (simulating human typing) using selenium

    Args:
        locator (tuple): tuple with locator type and locator string
        text (str): value to type inside input
        elem_name (str): description of the element
        typing_interval (float): interval to type every letter of the text
        wait_time (float, optional): custom wait time for the elements, skips driver default wait time
    """
    # _setup_wrapper(wait_time, wait_for_load=True)
    # elem = _driver_wait.until(EC.visibility_of_element_located((locator[0], locator[1])),
    #                           wait_msg.format(locator))
    elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1])))
    elem.clear()
    for letter in text:
        elem.send_keys(letter)
        time.sleep(typing_interval)
    elem.send_keys(Keys.TAB)
    if not "password" in elem_name:
        logger.info(f"Entered text {text} in textbox {elem_name}")
    else:
        logger.info(f"Entered password ********** in textbox {elem_name}")

@wait_for_load
def click_checkbox(locator, value, elem_name):
    checked_txt = ""
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    if type(value) == str:
        value = value.lower()
    # In case of a switch element
    if value == 'on' or value == 'active' or value == 'true' or value == True:
        value = True
    else:
        value = False
    if (elem.is_selected() and not value) or (not elem.is_selected() and value):
        driver.execute_script("arguments[0].click();", elem)
    else:
        checked_txt = "already "
    checked_txt += "checked" if value else "unchecked"
    logger.info(f"{elem_name} {checked_txt}")


@wait_for_load
def type_value_with_keys(locator, value, elem_name):
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    if current_os == "Darwin":
        elem.send_keys(Keys.COMMAND, 'A', Keys.DELETE)
    else:
        elem.send_keys(Keys.CONTROL, 'A', Keys.DELETE)
    elem.send_keys(value)
    logger.info(f"Entered text {value} in textbox {elem_name}")


@wait_for_load
def text_area_type_value(locator, value, elem_name):
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    elem.clear()
    elem.click()
    elem.send_keys(value)
    logger.info(f"Entered text {value} in textarea {elem_name}")


@wait_for_load
def type_value_with_replace_locator_string(locator, replace_string, value, elem_name):
    if not type(replace_string) is list: replace_string = [replace_string]
    logger.info(f"Type Value: {value} in: {elem_name} with replace: {replace_string}")
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1].format(*replace_string))))
    elem.clear()
    elem.send_keys(value)


@wait_for_load
def type_value_with_replace_locator_string_and_enter(locator, replace_string, value, elem_name):
    if not type(replace_string) is list: replace_string = [replace_string]
    logger.info(f"Type Value: {value} in: {elem_name} with replace: {replace_string}")
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1].format(*replace_string))))
    elem.clear()
    elem.send_keys(value + Keys.ENTER)


@wait_for_load
def type_value_and_enter(locator, value, elem_name):
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    elem.clear()
    elem.send_keys(value + Keys.ENTER)
    logger.info(f"Entered text {value} in textbox {elem_name}")


@wait_for_load
def type_value_key_down_enter(locator, value, elem_name):
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    elem.clear()
    elem.send_keys(value)
    time.sleep(4)
    elem.send_keys(Keys.DOWN + Keys.ENTER)
    logger.info(f"Entered text {value} in textbox {elem_name}")


@wait_for_load
def press_enter_key(locator, elem_name):
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    elem.send_keys(Keys.ENTER)
    logger.info(f"Pressing Enter in element {elem_name}")


@wait_for_load
def select_from_drop_down(locator, value, elem_name, timeout=driver_wait_time):
    # Selects value from the drop-down using aria-label attribute only
    elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1])))
    elem.click()
    time.sleep(2)
    # Replacing area-label by text as in most dropdown, area label is not available causing timeout issue.
    aria_label = (By.XPATH, "//*[contains(text(), '" + value + "')]")
    # aria_label = (By.XPATH, f"//*[@aria-label='{value}']")
    elem = create_wait(timeout).until(EC.visibility_of_element_located(aria_label))
    elem.click()
    logger.info(f"Selected {value} from dropdown {elem_name}")


@wait_for_load
def select_from_drop_down_replace_value(locator, replace_value, value, elem_name):
    logger.info(f"Select from drop down of: {elem_name} with replace string: {replace_value} Value: {value}")
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1].format(replace_value))))
    elem.click()
    time.sleep(2)
    aria_label = (By.XPATH, f"//*[@aria-label='{value}']")
    elem = wait.until(EC.visibility_of_element_located(aria_label))
    elem.click()


@wait_for_load
def get_number_of_elements(locator, elem_name):
    try:
        elems = wait.until(EC.visibility_of_all_elements_located((locator[0], locator[1])))
        logger.info(f"Got number of elements of: {elem_name} as: {len(elems)}")
    except (NoSuchElementException, TimeoutException):
        return 0
    return len(elems)


@wait_for_load
def get_attribute_value(locator, attribute_name):
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    attribute_value = elem.get_attribute(attribute_name)
    logger.info(f"Attribute -> {attribute_name} | Value -> {attribute_value}")
    return attribute_value


# Get CSS/Style Attribute value for the given Attribute key
@wait_for_load
def get_css_attribute_value(locator, attribute_name):
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    attribute_value = elem.value_of_css_property(attribute_name)
    logger.info(f"Attribute -> {attribute_name} | Value -> {attribute_value}")
    return attribute_value


@wait_for_load
def get_element(locator):
    elem = wait.until(EC.presence_of_element_located((locator[0], locator[1])))
    logger.info(f"Getting the reference of Webelement with locator : {locator}")
    return elem


# get all elements of a locator
def get_all_elements(locator, logger_element_info):
    elem = wait.until(EC.presence_of_all_elements_located((locator[0], locator[1])))
    logger.info(f"Number of elements found are {len(elem)}: for {logger_element_info}")
    return elem


@wait_for_load
def scroll_to_element_height(locator, num_of_time_to_scroll=1):
    logger.info("Scrolling element into view")
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    while num_of_time_to_scroll > 0:
        driver.execute_script("arguments[0].scrollTop=arguments[0].scrollTop + arguments[0].scrollHeight", elem)
        num_of_time_to_scroll = num_of_time_to_scroll - 1


@wait_for_load
def scroll_element_into_view_with_replace_value(locator, value, is_click=False):
    timeout = driver_wait_time
    if not type(value) is list: value = [value]
    logger.info(f"Scrolling to view next element for subsequent action(s)..")
    elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1].format(*value))))
    # actions = create_action_chains()
    # actions_move_element(actions, elem)
    driver.execute_script("arguments[0].scrollIntoView();", elem)
    if is_click:
        driver.execute_script("arguments[0].click();", elem)
        logger.info(f"Clicked on {value}")


@wait_for_load
def click_first_visible_element(locator, elem_name):
    elems = wait.until(EC.presence_of_all_elements_located((locator[0], locator[1])))
    for elem in elems:
        if elem.is_displayed() or elem.is_enabled():
            elem.click()
    logger.info(f"Clicked on {elem_name}")


@wait_for_load
def click_first_visible_element_replace_value(locator, value, elem_name):
    if not type(value) is list: value = [value]
    logger.info(f"Clicked first visible element: {elem_name} with replace value: {value}")
    elems = wait.until(EC.presence_of_all_elements_located((locator[0], locator[1].format(*value))))
    for elem in elems:
        if elem.is_displayed():
            elem.click()
            return


@wait_for_load
def get_attribute_replace_value(locator, attribute_name, value, elem_name):
    if not type(value) is list: value = [value]
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1].format(*value))))
    attribute_value = elem.get_attribute(attribute_name)
    logger.info(f"Element: {elem_name} has attribute value: {attribute_value} with replace value: {value}")
    return attribute_value


@wait_for_load
def get_element_text_replace_value(locator, value, elem_name):
    if not type(value) is list: value = [value]
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1].format(*value))))
    actual_text = elem.text
    logger.info(f"Element: {elem_name} replaced with value: {value} has Text: {actual_text}")
    return actual_text


@wait_for_load
def get_element_text_replace_value_without_load_check(locator, value, elem_name):
    # getting element text without wait, supports only xpath
    if not type(value) is list: value = [value]
    elem = driver.find_element(By.XPATH, locator[1].format(*value))
    actual_text = elem.text
    logger.info(f"(No page load check) Element: {elem_name} replaced with value: {value} has Text: {actual_text}")
    return actual_text


@wait_for_load
def get_elements_texts(locator):
    elems = wait.until(EC.visibility_of_all_elements_located((locator[0], locator[1])))
    texts = []
    for elem in elems:
        texts.append(elem.text.strip())
    # logger.info(f"Got texts: {texts}")
    return texts


@wait_for_load
def get_elements_attribute(locator, attribute_name):
    elems = wait.until(EC.visibility_of_all_elements_located((locator[0], locator[1])))
    values = []
    for elem in elems:
        values.append(elem.get_attribute(attribute_name))
    logger.info(f"Got attribute values for attribute {attribute_name}: {values}")
    return values


@wait_for_load
def get_visible_elements_texts(locator, timeout=driver_wait_time):
    elems = create_wait(timeout).until(EC.presence_of_all_elements_located((locator[0], locator[1])))
    texts = []
    for elem in elems:
        if elem.is_displayed():
            texts.append(elem.text)
    # logger.info(f"Got texts: {texts}")
    return texts


@wait_for_load
def get_elements_texts_replace_value(locator, value, timeout=driver_wait_time):
    if not type(value) is list: value = [value]
    elems = create_wait(timeout).until(EC.visibility_of_all_elements_located((locator[0], locator[1].format(*value))))
    texts = []
    for elem in elems:
        texts.append(elem.text)
    # logger.info(f"Got texts: {texts}")
    return texts


# Return text of element without waiting for its visibility, useful where page is already loaded with all elements
@wait_for_load
def get_element_text_no_wait(locator):
    # getting element text without wait, supports only xpath
    elems = driver.find_elements(By.XPATH, locator[1])
    texts = []
    for elem in elems:
        texts.append(elem.text.strip())
    logger.info(f"(No wait) Got texts: {texts}")
    return texts


@wait_for_load
def select_from_drop_down_text(locator, value, elem_name, timeout=driver_wait_time):
    # Selects value from the drop-down using text as well as button text;
    elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1])))
    wait_for_spinner_off()
    explicit_wait(5)
    elem.click()
    logger.info(f"Clicked on {elem_name} dropdown")
    time.sleep(3)

    try:
        aux_locator = locator[1]
        if locator[0] == 'id':
            aux_locator = f"//*[@id='{locator[1]}']"
        dropdown = (By.XPATH, f"{aux_locator}//li/button")
        values = get_elements_texts(dropdown)
        value_found = False
        for num, name in enumerate(values, start=1):
            if name == value:
                value_found = True
                try:
                    dropdown_value = (By.XPATH, f"({aux_locator}//li/button)[{num}]")
                    element = wait.until(EC.visibility_of_element_located(dropdown_value))
                    element.click()
                except (TimeoutException, NoSuchElementException):
                    dropdown_value = (By.XPATH, f"({aux_locator}//li/button[{num}])[last()]")
                    element = wait.until(EC.visibility_of_element_located(dropdown_value))
                    element.click()
                logger.info(f"Selected Value {value} from Dropdown {elem_name}")
                break
        if not value_found:
            logger.info(f"Trying to select: {value}, not found in Dropdown: {elem_name}")
            raise ValueError(f"Trying to select: {value}, not found in Dropdown: {elem_name}")
    except (TimeoutException, NoSuchElementException):
        elem_text = (By.XPATH, f"//li//*[contains(text(),'{value}')]")
        elem = wait.until(EC.visibility_of_any_elements_located(elem_text))
        wait_for_spinner_off()
        time.sleep(1)
        elem[0].click()


@wait_for_load
def select_from_drop_down_search_text(locator, value, elem_name):
    dropdown = (By.XPATH, f"//*[@id='{locator[1]}']/div")
    elem = wait.until(EC.visibility_of_element_located(dropdown))
    wait_for_spinner_off()
    elem.click()
    logger.info("Clicked on " + elem_name + " dropdown")
    time.sleep(3)

    dropdown_values = (By.XPATH, f"//*[@id='{locator[1]}']//ul//li/button")
    values = get_elements_texts(dropdown_values)
    for num, name in enumerate(values, start=1):
        if name == value:
            dropdown_value = (By.XPATH, f"(//*[@id='{locator[1]}']//ul//li/button)[{num}]")
            element = wait.until(EC.visibility_of_element_located(dropdown_value))
            element.click()
            logger.info(f"Selected Value {value} from Dropdown {elem_name}")


@wait_for_load
def select_multiple_values_from_dropdown(locator, values, elem_name):
    dropdown = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    wait_for_spinner_off()
    dropdown.click()
    logger.info(f"Clicked on {elem_name} multi-select dropdown")

    for i in values:
        # Search by the text inside the dropdown option
        elem = (By.XPATH, f"//*[contains(@id,'dropdown-option__')]/*[normalize-space()='{i}']")
        dropdownvalue = wait.until(EC.visibility_of_any_elements_located(elem))
        dropdownvalue[0].click()
        logger.info(f"Selected {i} from multi-select dropdown")
    dropdown.click()


@wait_for_load
def select_multiple_values_from_dropdown_search(locator, values, elem_name):
    dropdown = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    wait_for_spinner_off()
    dropdown.click()
    logger.info(f"Clicked on {elem_name} multi-select dropdown")

    for i in values:
        # Search by the text inside the dropdown option
        elem = (By.XPATH, f"//*[contains(@id,'dropdown-option__')]/*[normalize-space()='{i}']")
        dropdownvalue = wait.until(EC.visibility_of_any_elements_located(elem))
        dropdownvalue[0].click()
        logger.info(f"Selected {i} from multi-select dropdown")
    elem1 = (By.CSS_SELECTOR, f"#{locator[1]}  .bx--tag--filter")
    selected_value = wait.until(EC.visibility_of_any_elements_located(elem1))
    selected_value[0].click()
    logger.info("Closed dropdown values list")


@wait_for_load
def select_option_from_dynamic_listbox(locator, value, elem_name):
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    wait_for_spinner_off()
    elem.click()
    logger.info(f"Clicked on {elem_name} dropdown")
    time.sleep(3)

    dropdown_values = (By.XPATH, "//ibm-dropdown-list//li")
    values = get_elements_texts(dropdown_values)
    for num, name in enumerate(values, start=1):
        logger.info(f"Comparing {name} with {value}")
        if value in name:
            dropdown_value = (By.XPATH, f"(//ibm-dropdown-list//li)[{num}]")
            element = wait.until(EC.visibility_of_element_located(dropdown_value))
            element.click()
            logger.info(f"Selected Value {value} from Dropdown {elem_name}")
            break
    elem.click()
    logger.info(f"Closed {elem_name} dropdown")

# Search and select a value inside input text search
@wait_for_load
def text_input_search(locator, value, elem_name):
    input = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    logger.info(f"Search {value} on {elem_name}")
    input.send_keys(value)
    option_locator = f"//*[contains(text(), '{value}')]"
    option = wait.until(EC.visibility_of_any_elements_located((By.XPATH, option_locator)))
    option[0].click()
    logger.info(f"Selected value: {value} on {elem_name}")


@wait_for_load
def mouse_over_click_using_offset_with_replace_value(locator, value, x, y, elem_name):
    if not type(value) is list: value = [value]
    actions = create_action_chains()
    elem = wait.until(EC.element_to_be_clickable((locator[0], locator[1].format(*value))))
    actions.move_to_element_with_offset(elem, x, y).click().perform()
    logger.info(f"Clicked on {elem_name} with replace value: {value} and offset x: {x} and y: {y}")


@wait_for_load
def mouse_over_click_using_offset(locator, x, y, elem_name):
    actions = create_action_chains()
    elem = wait.until(EC.element_to_be_clickable((locator[0], locator[1])))
    actions.move_to_element_with_offset(elem, x, y).click().perform()
    logger.info(f"Clicked on {elem_name} with offset x: {x} and y: {y}")


@wait_for_load
def mouse_over_click(locator):
    actions = create_action_chains()
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    actions.move_to_element(elem).click().perform()


@wait_for_load
def mouse_over_right_click(locator, elem_name):
    actions = create_action_chains()
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    actions.move_to_element(elem).context_click().perform()
    logger.info("Right clicked on " + elem_name)


@wait_for_load
def mouse_over(locator):
    actions = create_action_chains()
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    actions.move_to_element(elem).perform()


@wait_for_load
def deselect_checkbox(locator, value, elem_name):
    if not type(value) is list: value = [value]
    logger.info(f"Deselect checkbox: {elem_name} replace with {value}")
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1].format(*value))))
    elem.click()


@wait_for_load
def click_using_script(locator, elem_name):
    logger.info("Clicked on " + elem_name)
    elem = driver.find_element(By.XPATH, locator[1])
    driver.execute_script("arguments[0].click();", elem)
    time.sleep(1)


@wait_for_load
def click_using_java_script(locator, elem_name, timeout=30):
    elem = create_wait(timeout).until(EC.visibility_of_any_elements_located((locator[0], locator[1])))
    driver.execute_script("arguments[0].click();", elem[0])
    time.sleep(1)
    logger.info(f"Clicked on {elem_name}")


# Remove the focus of an element
def blur_element_using_javascript(locator, elem_name):
    wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    driver.execute_script("document.activeElement.blur();", None)
    logger.info(f"Blur element {elem_name}")


@wait_for_load
def click_using_script_replace_value(locator, value, elem_name):
    if not type(value) is list: value = [value]
    elem = driver.find_element(By.XPATH, locator[1].format(*value))
    driver.execute_script("arguments[0].click();", elem)
    time.sleep(1)
    logger.info(f"Clicked using js script on: {elem_name} with replace value: {value}")


@wait_for_load
def click_last_visible_element(locator, elem_name):
    logger.info(f"Click last visible element: {elem_name}")
    elems = driver.find_elements(By.XPATH, locator[1])
    driver.execute_script("arguments[0].click();", elems[-1])


@wait_for_load
def scroll_element_click(locator, value, elem_name):
    if not type(value) is list: value = [value]
    logger.info(f"Scroll element {elem_name} into view replace with {value}")
    elem = wait.until(EC.presence_of_element_located((locator[0], locator[1].format(*value))))
    driver.execute_script("arguments[0].scrollIntoView();", elem)
    time.sleep(1)
    driver.execute_script("arguments[0].click();", elem)


@wait_for_load
def click_on_multiple_check_box(locator):
    elems = wait.until(EC.visibility_of_all_elements_located((locator[0], locator[1])))
    time.sleep(1)
    for elem in elems:
        driver.execute_script("arguments[0].click();", elem)


@wait_for_load
def wait_before_click(locator, elem_name):
    timeout = driver_wait_time
    elem = create_wait(timeout).until(EC.element_to_be_clickable((locator[0], locator[1])))
    time.sleep(1)
    elem.click()
    logger.info(f"Clicked on {elem_name}")


@wait_for_load
def wait_before_click_replace_value(locator, value, elem_name):
    if not type(value) is list: value = [value]
    elem = wait.until(EC.element_to_be_clickable((locator[0], locator[1].format(*value))))
    time.sleep(1)
    elem.click()
    logger.info(f"Clicked on {elem_name} with replace value: {value}")


@wait_for_load
def wait_for_all_elements_to_load(locator, elem_name):
    timeout = 30
    logger.info(f"Wait for all child elements to load: {elem_name}")
    create_wait(timeout).until(EC.presence_of_all_elements_located((locator[0], locator[1])))


@wait_for_load
def wait_for_all_elements_to_load_replace_value(locator, value, elem_name):
    if not type(value) is list: value = [value]
    logger.info(f"Wait for all child elements to load: {elem_name} with replace text: {value}")
    time.sleep(1)
    wait.until(EC.presence_of_all_elements_located((locator[0], locator[1].format(*value))))


@wait_for_load
def wait_for_element_to_visible_with_replace_value(locator, value, elem_name):
    if not type(value) is list: value = [value]
    time.sleep(1)
    wait.until(EC.visibility_of_element_located((locator[0], locator[1].format(*value))))
    logger.info(f"Wait for element visible : {elem_name} with replace text: {value}")


@wait_for_load
def wait_for_element_to_visible(locator, elem_name, timeout=driver_wait_time):
    logger.info(f"Wait for {elem_name} to be visible")
    create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1])))
    logger.info(f"Element: {elem_name} is visible")


@wait_for_load
def wait_for_element_to_invisible(locator, elem_name, timeout=driver_wait_time):
    logger.info(f"Wait for {elem_name} to be invisible")
    create_wait(timeout).until(EC.invisibility_of_element_located((locator[0], locator[1])))
    logger.info(f"Element: {elem_name} is invisible")


def wait_for_all_elements_to_load_no_jquery_check(locator):
    logger.info(f"Wait for all child elements to load: {locator}")
    time.sleep(1)
    wait.until(EC.presence_of_all_elements_located((locator[0], locator[1])))


@wait_for_load
def wait_for_element_clickable(locator, value):
    timeout = driver_wait_time
    create_wait(timeout).until(EC.element_to_be_clickable((locator[0], locator[1])))
    logger.info(f"Waiting for {value} to be clickable")


# click on element inside shadow DOM
def click_in_shadow_dom(locator, elem_name, timeout=driver_wait_time):
    explicit_wait(timeout)
    shadow_host = driver.find_element(By.TAG_NAME, "associate-context-cam")
    shadow_root_dict = driver.execute_script('return arguments[0].shadowRoot', shadow_host)
    shadow_root_id = shadow_root_dict["shadow-6066-11e4-a52e-4f735466cecf"]
    shadow_root = WebElement(driver, shadow_root_id, w3c=True)
    shadow_elem = shadow_root.find_element(By.CSS_SELECTOR, locator)
    shadow_elem.click()
    logger.info(f"Clicked on: {elem_name}")


def click_with_replace_value_in_shadow_dom(locator, value, elem_name, timeout=driver_wait_time):
    explicit_wait(timeout)
    if not type(value) is list: value = [value]
    shadow_host = driver.find_element(By.TAG_NAME, "associate-context-cam")
    shadow_root_dict = driver.execute_script('return arguments[0].shadowRoot', shadow_host)
    shadow_root_id = shadow_root_dict["shadow-6066-11e4-a52e-4f735466cecf"]
    shadow_root = WebElement(driver, shadow_root_id, w3c=True)
    shadow_elem = shadow_root.find_element(By.CSS_SELECTOR, locator.format(*value))
    shadow_elem.click()
    logger.info(f"Clicked on : {elem_name} with replace value: {value}")


def type_value_in_shadow_dom(locator, value, elem_name):
    wait_for_spinner_off()
    shadow_host = driver.find_element(By.TAG_NAME, "associate-context-cam")
    shadow_root_dict = driver.execute_script('return arguments[0].shadowRoot', shadow_host)
    shadow_root_id = shadow_root_dict["shadow-6066-11e4-a52e-4f735466cecf"]
    shadow_root = WebElement(driver, shadow_root_id, w3c=True)
    shadow_elem = shadow_root.find_element(By.CSS_SELECTOR, locator)
    shadow_elem.send_keys(value)
    logger.info(f"Entered text {value} in textbox {elem_name}")


def get_elements_count_for_shadow_dom(locator):
    shadow_host = driver.find_element(By.TAG_NAME, "associate-context-cam")
    shadow_root_dict = driver.execute_script('return arguments[0].shadowRoot', shadow_host)
    shadow_root_id = shadow_root_dict["shadow-6066-11e4-a52e-4f735466cecf"]
    shadow_root = WebElement(driver, shadow_root_id, w3c=True)
    try:
        shadow_elems = shadow_root.find_elements(By.CSS_SELECTOR, locator)
        actual_count = len(shadow_elems)
    except (NoSuchElementException, TimeoutException):
        return 0
    logger.info(f"Elements count: {actual_count}")
    return actual_count


def is_element_visible_in_shadow_dom(locator, elem_name, timeout=driver_wait_time):
    explicit_wait(timeout)
    shadow_host = driver.find_element(By.TAG_NAME, "associate-context-cam")
    shadow_root_dict = driver.execute_script('return arguments[0].shadowRoot', shadow_host)
    shadow_root_id = shadow_root_dict["shadow-6066-11e4-a52e-4f735466cecf"]
    shadow_root = WebElement(driver, shadow_root_id, w3c=True)
    shadow_elem = shadow_root.find_element(By.CSS_SELECTOR, locator)
    shadow_elem.is_displayed()
    logger.info(f"Element: {elem_name} is visible")


def scroll_to_element_with_replace_value_in_shadow_dom(locator, value, is_click=False):
    if not type(value) is list: value = [value]
    shadow_host = driver.find_element(By.TAG_NAME, "associate-context-cam")
    shadow_root_dict = driver.execute_script('return arguments[0].shadowRoot', shadow_host)
    shadow_root_id = shadow_root_dict["shadow-6066-11e4-a52e-4f735466cecf"]
    shadow_root = WebElement(driver, shadow_root_id, w3c=True)
    logger.info(f"Scrolling to view next element for subsequent action(s)..")
    shadow_elem = shadow_root.find_element(By.CSS_SELECTOR, locator.format(*value))
    driver.execute_script("arguments[0].scrollIntoView();", shadow_elem)
    if is_click:
        driver.execute_script("arguments[0].click();", shadow_elem)
        logger.info(f"Clicked on {value}")


@wait_for_load
def get_canvas_image(locator):
    elem = wait.until(EC.visibility_of_element_located((locator[0], locator[1])))
    # get the canvas as a PNG base64 string
    canvas_image = driver.execute_script("return arguments[0].toDataURL('image/png').substring(21);", elem)
    return canvas_image


@wait_for_load
def click_using_script_no_wait(locator, elem_name):
    logger.info(f"Click using script: {elem_name}")
    elem = driver.find_element(By.XPATH, locator[1])
    driver.execute_script("arguments[0].click();", elem)


@wait_for_load
def click_using_script_no_wait_replace_value(locator, value, elem_name):
    elem = driver.find_element(By.XPATH, locator[1].format(value))
    driver.execute_script("arguments[0].click();", elem)
    logger.info(f"Clicked on: {elem_name} with replace value: {value}")


def switch_to_new_window():
    parent_handle = driver.current_window_handle
    tabs = driver.window_handles
    for x in range(len(tabs)):
        if tabs[x] != parent_handle:
            driver.switch_to.window(tabs[x])


def switch_to_parent_window(auto_close=False):
    if auto_close:
        tabs = driver.window_handles
        driver.switch_to.window(tabs[0])
    else:
        # Close window where driver is set and then switch back to parent window
        driver.close()
        tabs = driver.window_handles
        driver.switch_to.window(tabs[0])


# Used if is necessary to make the code waits a certain time
def explicit_wait(seconds=1):
    time.sleep(seconds)


# Waits for text to be present in the element
@wait_for_load
def wait_for_element_text(locator, text, elem_name):
    logger.info(f'Waiting for text: {text} in element: {elem_name}')
    wait.until(EC.text_to_be_present_in_element((locator[0], locator[1]), text))


# Waits for text to be present in the element with value
@wait_for_load
def wait_for_element_text_with_replace_value(locator, value, text, elem_name):
    if not type(value) is list: value = [value]
    logger.info(f'Waiting for text: {text} in element: {elem_name}')
    wait.until(EC.text_to_be_present_in_element((locator[0], locator[1].format(*value)), text))


@wait_for_load
def get_element_text_index_based(locator, index):
    elem = driver.find_element(By.XPATH, locator[index])
    actual_text = elem.text
    logger.info(f"Text returned from element locator is {actual_text}")
    return actual_text


# Method is used to click on dropdown, search text inside it and select checkbox based on filtered results
@wait_for_load
def select_from_drop_down_search_text_click_checkbox(locator, value, elem_name):
    dropdown = (By.XPATH, locator[1])
    elem = wait.until(EC.visibility_of_element_located(dropdown))
    wait_for_spinner_off()
    elem.click()
    logger.info("Clicked on " + elem_name + " dropdown")
    # time.sleep(3)
    explicit_wait(3)
    # Search for text inside dropdown
    search_box = (By.CSS_SELECTOR, "[role='searchbox']")
    if is_element_present(search_box, "Searchbox"):
        elem = wait.until(EC.visibility_of_element_located(search_box))
        elem.click()
        elem.send_keys(value)
        elem.send_keys(Keys.ENTER)
        # wait_for_spinner_off()
    # Select dropdown value based on filtered results
    dropdown_values = (By.XPATH, "//*[contains(text(), ' " + value + " ')]")
    values = get_elements_texts(dropdown_values)
    for num, name in enumerate(values, start=1):
        if value in name:
            dropdown_value = (By.XPATH, "//*[contains(text(), ' " + value + " ')]")
            element = wait.until(EC.visibility_of_element_located(dropdown_value))
            element.click()
            logger.info("Selected Value " + value + " from Dropdown " + elem_name)
            break


@wait_for_load
def select_multiple_values_from_dropdown_with_index(locator, values, index=0, elem_name="Dropdown"):
    dropdown = wait.until(EC.visibility_of_element_located((locator[0], locator[1].format(index))))
    wait_for_spinner_off()
    dropdown.click()
    logger.info(f"Clicked on {elem_name} multi-select dropdown")
    explicit_wait(1)
    elem = (By.XPATH, f"//*[contains(@id,'dropdown-option__')]/*[normalize-space()='{values}']")
    logger.info(elem)
    dropdown_value = wait.until(EC.visibility_of_element_located(elem))
    dropdown_value.click()
    logger.info(f"Selected {values} from multi-select dropdown")
    explicit_wait(1)
    dropdown.click()


def switch_to_alert():
    try:
        WebDriverWait(driver, 6).until(EC.alert_is_present())
        alert = driver.switch_to_alert()
        alert.accept()
        logger.info("Alert accepted")

    except TimeoutException:
        logger.info("No Alert")

        
def reload_page():
    driver.refresh()
    wait_for_spinner_off()


def select_key_value_from_drop_down(locator, value, elem_name, timeout=driver_wait_time):
    # Select key and value from dropdown for topology
    elem = create_wait(timeout).until(EC.visibility_of_element_located((locator[0], locator[1])))
    elem.click()
    time.sleep(2)
    elem_list = (By.CSS_SELECTOR, "div.bx--list-box__menu-item__option")
    if is_element_present(elem_list, "list of elements"):
        aria_label = (By.XPATH, f"//*[contains(text(), '{value}')]")
        elem = create_wait(timeout).until(EC.visibility_of_element_located(aria_label))
        elem.click()
        logger.info(f"Selected {value} from dropdown {elem_name}")
    else:
        elem.click()
        time.sleep(2)
        aria_label = (By.XPATH, f"//*[contains(text(), '{value}')]")
        elem = create_wait(timeout).until(EC.visibility_of_element_located(aria_label))
        elem.click()
        logger.info(f"Selected {value} from dropdown {elem_name}")
      
               
@wait_for_load
def click_optional(locator, elem_name, timeout=driver_wait_time):
    try:
        elem = create_wait(timeout).until(EC.element_to_be_clickable((locator[0], locator[1])))
        elem.click()
        logger.info(f"Clicked on {elem_name}")
    except TimeoutException:
        logger.info("Unable to click on :" + elem_name)


@wait_for_load
def set_toggle_switch(locator, value):
    elem_list = wait.until(EC.visibility_of_all_elements_located((locator[0], locator[1])))
    for elem in elem_list:
        current_value = elem.get_attribute('aria-checked')
        if value.lower() == 'on' and current_value == 'false':
            elem.click()
        elif value.lower() == 'off' and current_value == 'true':
            elem.click()
        else:
            pass


