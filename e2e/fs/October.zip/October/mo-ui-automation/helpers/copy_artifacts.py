import os
import shutil

from helpers.mo_resources import root_folder


def copy_artifacts():
    destination_folder = os.path.join(root_folder, "ui-automation-results")
    # Move html and xml files
    shutil.move(os.path.join(root_folder, "junitresults.xml"), os.path.join(destination_folder, "JunitReports"))
    shutil.move(os.path.join(root_folder, "report", "report.html"), destination_folder)
    # fetch all files
    for file_name in os.listdir():
        if file_name == "screenshots" or file_name == "screenrecorder" or file_name == "hars":
            source_folder = os.path.join(root_folder, file_name)
            shutil.move(source_folder, destination_folder)
            print('Moved:', file_name)


def main():
    copy_artifacts()


if __name__ == "__main__":
    main()
