import logging
import os
import SoftLayer
from mo_encryption_decryption import decrypt_password, encrypt_password
from configparser import ConfigParser

client = None


def get_host_name(slave_name):
    agent_name = slave_name.replace("auto", "")
    return "".join(("long-qa-jenkins", f"{agent_name[0: -2]}{agent_name[-1]}"))


def is_ip(address):
    return address.replace('.', '').isnumeric()


def turn_on_vm(address):
    if is_ip(address):
        vm_id = get_vm_id_from_ip(address)
    else:
        host_name = get_host_name(address)
        vm_id = get_vm_id_from_host_name(host_name)
    if get_vms_status(vm_id) != 'RUNNING':
        print(f'Turning ON VM with Id: {vm_id}')
        response = client.call('SoftLayer_Virtual_Guest', 'powerOn', id=vm_id)
        if response:
            print('VM turned ON')
        else:
            logging.error('Error occurred during turning ON VM')


def turn_off_vm(address):
    if is_ip(address):
        vm_id = get_vm_id_from_ip(address)
    else:
        host_name = get_host_name(address)
        vm_id = get_vm_id_from_host_name(host_name)
    if get_vms_status(vm_id) != 'SUSPENDED':
        print(f'Turning OFF VM with Id: {vm_id}')
        response = client.call('SoftLayer_Virtual_Guest', 'powerOff', id=vm_id)
        if response:
            print('VM turned OFF')
        else:
            logging.error('Error occurred during turning OFF VM')


def get_vm_id_from_host_name(host_name):
    manager = SoftLayer.VSManager(client)
    response = list(manager.list_instances(hostname=host_name))
    print(f'Getting Id for IP {host_name}')
    if len(response):
        id = response[0].get('id')
        print(f'Id for Host Name:: {host_name} is {id}')
        return id
    return None


def get_vm_id_from_ip(ip_address):
    manager = SoftLayer.VSManager(client)
    response = list(manager.list_instances(public_ip=ip_address))
    print(f'Getting Id for IP {ip_address}')
    if len(response):
        id = response[0].get('id')
        print(f'Id for ip address:: {ip_address} is {id}')
        return id
    return None


def create_client(username=None, api_key=None):
    global client
    if username and api_key:
        client = SoftLayer.create_client_from_env(username=username, api_key=api_key)
    else:
        config = process_config('ist_provider_creds.conf', secret=os.getenv('MO_API_AUTOMATION_SECRET'),
                                decrypt=True) if "ist_provider_creds.conf" else None
        client = SoftLayer.create_client_from_env(username=config._sections['ibmcloud']['_username'],
                                                  api_key=config._sections['ibmcloud']['_apiKey'])


def process_text(text: str, secret: str, is_encrypted: bool) -> str:
    if is_encrypted:
        text = decrypt_password(text, secret)
    else:
        text = encrypt_password(text, secret)
    return text


def process_config(file_path: str, secret: str, decrypt: bool, save: bool = False) -> ConfigParser:
    config = ConfigParser()
    config.optionxform = str
    config.read(file_path)
    for section in config.sections():
        for k, v in config[section].items():
            if k.startswith('_'):
                config[section][k] = process_text(v, secret, decrypt)
    if save:
        with open(file_path, mode='w') as f:
            config.write(f)
    return config


def main(parser):
    config = process_config('ist_provider_creds.conf', parser.secret,
                            decrypt=True) if "ist_provider_creds.conf" else None
    if parser.username and parser.secret:
        create_client(decrypt_password(parser.username), decrypt_password(parser.apikey))
    else:
        create_client(config._sections['UI-Automation']['_username'], config._sections['UI-Automation']['_apiKey'])
    if parser.mode == 'ON':
        turn_on_vm(parser.host)
    else:
        turn_off_vm(parser.host)


def get_vms_status(vm_id):
    if vm_id is not None:
        response = client.call('SoftLayer_Virtual_Guest', 'getDeviceStatus', id=vm_id)
        print(f"VM: {vm_id}, is currently: {response['name']} ")
        return response.get('keyName')
    else:
        logging.error(f'Not able to find status for VM with IP {vm_id}')


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--host', type=str, help='IPs of virtual servers')
    parser.add_argument('--secret', default=os.getenv('MO_API_AUTOMATION_SECRET'),
                        help='Key to decrypt the credentials')
    parser.add_argument('-m', '--mode', type=str, choices=['ON', 'OFF'])
    parser.add_argument('--username', help='Username for ibmcloud')
    parser.add_argument('--apikey', help='Api key for ibmcloud')
    exit(main(parser.parse_args()))
