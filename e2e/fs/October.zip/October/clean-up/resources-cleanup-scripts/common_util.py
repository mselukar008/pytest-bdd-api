
import json
import os

import api_util
from logger_util import logger
import configparser
from datetime import datetime
from azure.identity import ClientSecretCredential
# from azure.common.credentials import ServicePrincipalCredentials
from azure.mgmt.resource import ResourceManagementClient
import adal
import requests
from mo_encryption_decryption import decrypt_password
from azure.mgmt.costmanagement import CostManagementClient
from azure.mgmt.costmanagement.models import QueryDefinition, QueryDataset, QueryFilter, QueryComparisonExpression, \
    QueryAggregation
from datetime import date
today = date.today()
date = today.strftime("%B %d, %Y")
from time import sleep
import tabulate
users_info_dict = {}

def get_azure_credentials(account='mo'):
    global users_info_dict
    now = datetime.now()
    dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    logger.info(f"********* Date and Time = {dt_string} *********")
    logger.info(
        "================================================================================================")
    if os.environ.get("keywords"):
        keywords = os.environ.get("keywords").split(',')
        logger.info("Loaded the configurations from Jenkins Variables..")
    else:
        config = configparser.ConfigParser()
        config.read('azure-config.ini')
        keywords = config['KEYWORDS']['keywords'].split(',')
        logger.info("Loaded the configurations from Local Variables..")

    # Loading credentials info from json file
    json_file = open("azure-credentials.json", "r")
    creds = json.load(json_file)
    # Creating dictionary item for each azure subscription in json data
    cred_object = creds['azure_subscriptions']
    if account in 'devsecops':
        cred_object = creds['azure_subscriptions_devsecops']

    for index, user in enumerate(cred_object):
        temp_list = []
        temp_list.extend([user['sub_id'], user['client_id'], user['client_secret_key'], user['tenant_id'], user['sub_name']])
        key = 'User_' + str(index)
        users_info_dict = create_user_info_dict(users_info_dict, key, temp_list)

    logger.info(
        "===============================================================================================")
    logger.info(f"List of Azure Subscriptions:\n")
    for key, values in users_info_dict.items():
        logger.info(f"{key} :: Subscription ID: {values[0]}\tClient ID: {values[1]}")
    logger.info(f"List of keywords to delete resource groups: {keywords}")
    return users_info_dict


def create_user_info_dict(users_info_dict, key, list_of_values):
    if key not in users_info_dict:
        users_info_dict[key] = list()
    users_info_dict[key].extend(list_of_values)
    return users_info_dict


def create_teams_payload_azure(billing_info):
    header = "#############################<br>**Azure Subscription-wise Invoice Details**<br>#############################<br>"
    teams_payload = '{"text": "' + header + billing_info + '"}'
    logger.info(f"Teams Payload: {teams_payload}")
    print(f"{teams_payload}")
    return teams_payload
