"""
common functions for API functions.
"""
from urllib3 import disable_warnings
from urllib3.exceptions import InsecureRequestWarning
disable_warnings(InsecureRequestWarning)
import json
import requests


def post_request(url, headers, payload):
    response = requests.post(url=url, json=json.loads(payload), headers=headers)
    if response.text == '1':
        print('\n Successfully posted report on teams channel')
    else:
        print('\n Something went wrong. Unable to post report teams;Response:', response)


def post(url, body, headers):
    """
    common function for Post API.
    """
    resp = requests.post(url, body, headers=headers, verify=False)
    try:
        output = json.loads(resp.text)
        return resp.status_code, output
    except ValueError:
        return resp.status_code, None


def get(url, headers):
    """
    common function for Get API.
    """
    resp = requests.get(url, headers=headers, verify=False)
    try:
        output = json.loads(resp.text)
        return resp.status_code, output
    except ValueError:
        return resp.status_code, None


def delete(url, headers):
    """
    common function for delete API.
    """
    resp = requests.delete(url, headers=headers, verify=False)
    try:
        return resp.status_code
    except ValueError:
        return resp.status_code
