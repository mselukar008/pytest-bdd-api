import logging
import sys
from datetime import datetime

FILENAME = sys.argv[0].split(".")[0]
LOG_FILENAME = datetime.now().strftime("logs/result-" + FILENAME + "-%H-%M-%S-%d-%m-%Y.log")

# Create and configure logger
logging.basicConfig(
    format='%(asctime)s - %(filename)s::%(funcName)s::%(lineno)d - %(message)s',
    level=logging.INFO,
    handlers=[
        # logging.FileHandler(LOG_FILENAME, mode='w')
        logging.StreamHandler(sys.stdout)
    ]
)

# Create an object 
logger = logging.getLogger()
