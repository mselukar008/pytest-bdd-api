import datetime
import api_util
from google.cloud import bigquery


def get_gcp_usage(project_id, teams_channel_url):
    # Construct a BigQuery client object.
    client = bigquery.Client()
    # Get current month and year
    x = datetime.datetime.now()
    date = x.strftime("%Y%m")
    total_spend = ""
    # Compose bigquery for fetching total cost based on project id
    query = """
       SELECT
  invoice.month,
  SUM(cost)
    + SUM(IFNULL((SELECT SUM(c.amount)
                  FROM   UNNEST(credits) c), 0))
    AS total,
  (SUM(CAST(cost * 1000000 AS int64))
    + SUM(IFNULL((SELECT SUM(CAST(c.amount * 1000000 as int64))
                  FROM UNNEST(credits) c), 0))) / 1000000
    AS total_exact
    FROM `cost-asset-analytics.BillingActiveExport.gcp_billing_export_v1_008C93_7B2B98_816781` where project.id ='""" + project_id + """'
    AND invoice.month = '""" + date + """'
    GROUP BY 1
    ORDER BY 1 DESC
    """
    query_job = client.query(query)  # Make an API request.
    for row in query_job:
        # Row values can be accessed by field name or index.
        # print("total={}".format(row[0], row["total"]))
        total_spend = "{:.2f}".format(float(row[2]))
    # print("The total spend for the month is :" + str(total_spend))
    #     p1 = '{"blocks":[{"type": "header","text": {"type": "plain_text","text": "GCP Account Usage Details"}},{"type": "divider"},{'
    #     p2 = '"type": "section","fields": [{"type": "mrkdwn","text": "*Project Name*:'
    #     p3 = f'{project_id}\\n'
    #     p4 = f'*Total Spend Amount*: USD {total_spend}"'
    #     p5 = '}]}]}'
    
    #     p1 = f"**GCP Account Usage Details:**<br><br>"
    #     p2 = f"**Project Name:** {project_id}<br>"
    #     p3 = f"**Total Spend Amount:** USD {total_spend}<br>"
    #     payload = '{"text":"' + p1 + p2 + p3 + '"}'
    #     print(payload)
    #     return payload
    
    s1 = '{"type": "message", "attachments": [{"contentType": "application/vnd.microsoft.teams.card.o365connector","content": {"@type": "MessageCard","@context": "https://schema.org/extensions", "summary": "Summary","themeColor": "blue;", "title": "GCP Account Usage Details","sections":'
    s2 = f'[{{"text": "<strong>Project Name:</strong> {project_id}"}},'
    s3 = f'{{"text": "<strong>Total Spend Amount:</strong> $ {total_spend}"}}]}}}}]}}'
    payload = s1 + s2 + s3
    print(payload)
    # Post message to teams channel
    headers = {"Content-Type": "application/json"}
    api_util.post_request(teams_channel_url, headers, payload)
    return payload


def main(args):
    get_gcp_usage(args.project_id, args.slack_url)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--project_id")
    parser.add_argument("--slack_url", required=False)
    main(parser.parse_args())
