#!/bin/bash
#set -x

deleteAll(){
    type=$1
    Name=$2
    listType=$3

    echo -e "---------------Deleting $Name--------------------"
    total=`gcloud $type $listType list | grep -v NAME | wc -l` 
    #if [ $total -gt 0 ]; then
   #     total=$(($total-1))
   # fi

    echo -e "Number of $Name : " `expr $total`

    for instance in `gcloud $type $listType list | cut -f1 -d' ' | grep -v NAME`
    do
        echo -e "Deleting $Name '$instance'"
        gcloud $type $listType delete $instance -q
    done 

}

deleteAllVMs(){

    type=$1
    Name=$2

    echo -e "---------------Deleting $Name--------------------"

    total=`gcloud compute $type list | grep -v NAME | wc -l` 
    #if [ $total -gt 0 ]; then
    #    total=$(($total-1))
    #fi

    echo -e "Number of $Name : " `expr $total`
    
    gcloud compute $type list | awk '{print $1 " " $2}' | grep -v NAME > withRegions.txt

    while read LINE
    do 
        INSTANCE=`echo $LINE | cut -f1 -d ' '`
        REGION=`echo $LINE |  cut -f2 -d ' '`


	gcloud compute $type update $INSTANCE --no-deletion-protection --zone=$REGION

        echo -e "Deleting $Name : $INSTANCE with Zone : $REGION"
        gcloud compute $type delete $INSTANCE --quiet  --zone=$REGION 

    done < withRegions.txt

    rm -rf withRegions.txt 

}


deleteAllWithName(){

    type=$1
    Name=$2
    listType=$3
    ignore=$4

    echo -e "---------------Deleting $Name--------------------"
    total=`gcloud $type $listType list --format="table(name)" | egrep -v $ignore | wc -l` 
    #if [ $total -gt 0 ]; then
    #    total=$(($total-1))
    #fi

    echo -e "Number of $Name : " `expr $total`
    if [ $total -gt 0 ]; then
    	gcloud $type $listType delete `gcloud $type $listType list --format="table(name)" | egrep -v $ignore` -q
    fi
}

deleteAllBuckets(){

    echo -e "---------------Deleting Buckets--------------------"
    for instance in `gsutil ls | grep -v psl-gcp--svc-keys`
    do    
        echo -e "Deleting Bucket $instance"    
        gsutil rm -r $instance
    done
}

deleteAllDNS(){

    echo -e "---------------Deleting DNS--------------------"
    touch empty-file
    for instance in `gcloud dns managed-zones list | cut -f1 -d' ' | grep -v NAME`
    do    
        echo -e "Deleting DNS $instance"    
        gcloud dns record-sets import -z "$instance" --delete-all-existing empty-file
        gcloud dns managed-zones delete $instance
    done
    rm empty-file
}

deleteAllWithZones(){

    type=$1
    Name=$2
    ignore=$3

    echo -e "---------------Deleting $Name--------------------"

    total=`gcloud compute $type list | egrep -v $ignore | wc -l` 
    #if [ $total -gt 0 ]; then
   #     total=$(($total-1))
   # fi

    echo -e "Number of $Name : " `expr $total`
    
    gcloud compute $type list | awk '{print $1 " " $2}' | egrep -v $ignore > withRegions.txt

    while read LINE
    do 
        INSTANCE=`echo $LINE | cut -f1 -d ' '`
        REGION=`echo $LINE |  cut -f2 -d ' '`

        echo -e "Deleting $Name : $INSTANCE with Region : $REGION"
        gcloud compute $type delete $INSTANCE --quiet  --zone=$REGION 

    done < withRegions.txt

    rm -rf withRegions.txt
}

deleteAllWithRegions(){

    type=$1
    Name=$2
    ignore=$3

    echo -e "---------------Deleting $Name--------------------"

    total=`gcloud compute $type list | egrep -v $ignore | wc -l` 
    #if [ $total -gt 0 ]; then
    #    total=$(($total-1))
    #fi

    echo -e "Number of $Name : " `expr $total`
    
    gcloud compute $type list | awk '{print $1 " " $2}' | egrep -v $ignore > withRegions.txt

    while read LINE
    do 
        INSTANCE=`echo $LINE | cut -f1 -d ' '`
        REGION=`echo $LINE |  cut -f2 -d ' '`

        echo -e "Deleting $Name : $INSTANCE with Region : $REGION"
        gcloud compute $type delete $INSTANCE --quiet  --region=$REGION 

    done < withRegions.txt

    rm -rf withRegions.txt
}


#Clean Spanner
deleteAll spanner Spanner instances
   
#Clean Bigtable
deleteAll "beta bigtable" Bigtable instances

#Clean DNS
deleteAllDNS

#Clean Buckets
#deleteAllBuckets

#Clean Deployment
gcloud deployment-manager deployments delete `gcloud deployment-manager deployments list --simple-list` -q --async

#Clean Instance Templates
deleteAll "compute" Template instance-templates

#Clean Instances
deleteAllVMs instances "Instances"

#Clean Disks
deleteAllWithZones disks "Disks" "NAME"

#Clean All Health Checks
deleteAll "compute" HealthCheck health-checks
deleteAll "compute" "HTTP HealthCheck" http-health-checks
deleteAll "compute" "HTTPs HealthCheck" https-health-checks

#Clean Firewalls
deleteAllWithName compute Firewall-Rules firewall-rules "NAME|default-allow"

#Clean All VPCs except default|deployment-manager-vpc|deployment-manager-vpc-2
deleteAllWithRegions "networks subnets" "Sub-Networks" "NAME|default"
deleteAllWithName compute Networks networks "NAME|default"

#Clean External IP Address
deleteAllWithRegions addresses "External IP Address"  "NAME"

#Clean Forward Rules
deleteAllWithRegions forwarding-rules "Fowarding Rules" "NAME"

#Backend Service



#Backend Bucket



#Clean UDP / TCP Target Pools
deleteAllWithRegions target-pools "Target Pools" "NAME"

#Clean up Pub / Sub
deleteAllWithName pubsub Subscriptions subscriptions "NAME"
deleteAllWithName pubsub Topics topics "NAME"
