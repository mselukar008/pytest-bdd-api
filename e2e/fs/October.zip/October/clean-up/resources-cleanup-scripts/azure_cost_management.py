import json
import os
from logger_util import logger
from azure.core.exceptions import HttpResponseError

import api_util
import common_util
from logger_util import logger
import configparser
from datetime import datetime
from azure.identity import ClientSecretCredential
# from azure.common.credentials import ServicePrincipalCredentials
from azure.mgmt.resource import ResourceManagementClient
import adal
import requests
from mo_encryption_decryption import decrypt_password
from azure.mgmt.costmanagement import CostManagementClient
from azure.mgmt.costmanagement.models import QueryDefinition, QueryDataset, QueryFilter, QueryComparisonExpression, \
    QueryAggregation
from datetime import date
today = date.today()
date = today.strftime("%B %d, %Y")
from time import sleep
import tabulate

tabular_result = []
fraction_values = []


def cost_management(sub_id, client_id, client_secret_key, tenant_id, sub_name):
    logger.info(
        "==============================================================================================")
    logger.info("Initializing Azure Cost Management client..")
    credentials = ClientSecretCredential(
        client_id=client_id,
        client_secret=decrypt_password(client_secret_key),
        tenant_id=tenant_id
    )
    client = CostManagementClient(credential=credentials, subscription_id=sub_id)
    query_definition_total_current_cost = get_query_definition("BillingMonthToDate")
    # query_definition_last_week_cost = get_query_definition("TheLastWeek")
    # query_definition_this_week_cost = get_query_definition("WeekToDate")

    scope = "/subscriptions/" + sub_id
    for i in range(5):
        try:
            result_total_current_cost = client.query.usage(scope=scope, parameters=query_definition_total_current_cost)
            sorted_result = sorted(result_total_current_cost.rows, key=lambda kv: kv[1])
            total_current_cost = sorted_result[0][0]
            sleep(10)
            # result_last_week_cost = client.query.usage(scope=scope, parameters=query_definition_last_week_cost)
            # sorted_result = sorted(result_last_week_cost.rows, key=lambda kv: kv[1])
            # last_week_cost = sorted_result[0][0]
            # sleep(1)
            # result_this_week_cost = client.query.usage(scope=scope, parameters=query_definition_this_week_cost)
            # sorted_result = sorted(result_this_week_cost.rows, key=lambda kv: kv[1])
            # this_week_cost = sorted_result[0][0]
            # percent_fraction = (((this_week_cost / last_week_cost) - 1) * 100)
            # fraction_values.append(percent_fraction)
            # sleep(1)
            # data = [date, "Azure Weekly-Cost", sub_name, total_current_cost, last_week_cost,
            #         this_week_cost, percent_fraction]
            data = [date, "Azure Monthly-Cost", sub_name, total_current_cost]
            tabular_result.append(data)
            logger.info(f"Actual Cost for the Subscription {sub_name} is {total_current_cost}")
            return total_current_cost
        except HttpResponseError:
            logger.info('HttpResponseError with code 429, re-trying')
            sleep(5)


def get_query_definition(value) -> QueryDefinition:
    query_dataset = QueryDataset(
        granularity="Accumulated",
        aggregation={"totalCost": QueryAggregation(name="PreTaxCost", function="Sum")}
    )
    return QueryDefinition(type="ActualCost", timeframe=value, dataset=query_dataset)


def main(args):
    # Returns list of dictionary items indexed as 0 -> Sub ID, 1 -> Client ID, 2 -> Client Secret Key, 3 -> Tenant ID
    creds_dict = common_util.get_azure_credentials(account=args.account)
    for key, values in creds_dict.items():
        cost_management(values[0], values[1], values[2], values[3], values[4])

    # define header names
    col_names = ["Date", "Type", "Subscription", "This-Month Amount (€)",
                 "Last-Week Amount (€)", "This-Week Amount (€)", "% Utilization compared to Last-Week"]

    # display table
    cost_table = tabulate.tabulate(tabular_result, headers=col_names, tablefmt="fancy_grid")
    print(cost_table)
    with open('./result/acm.txt', 'a', encoding='utf-8') as file:
        file.write(cost_table)

    # for i in fraction_values:
    #     if i > threshold:
    #         raise Exception("Cost Exceeded! Take Action!")

    print('Workflow Succeeded, Cost data is published!!')
    # Get Teams payload to upload results
    # payload = az_delete.create_teams_payload(sub_billing_info)
    # Post to teams channel
    headers = {"Content-Type": "application/json"}
    # api_util.post_request(args.slack_url, headers, payload)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--slack_url", required=False)
    parser.add_argument("--account", required=True)
    main(parser.parse_args())
