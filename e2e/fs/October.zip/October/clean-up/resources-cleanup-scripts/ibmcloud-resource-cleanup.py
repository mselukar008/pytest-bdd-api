"""
@author Padmakar Selokar

Fetch the billing items and clean up the resources which are created in Automation Testing
"""

import json

import api_util
from logger_util import logger
import configparser
import os
from mo_encryption_decryption import *
from datetime import datetime
import SoftLayer


class bills():
    user_list = []
    keywords = []
    key_vm = "guest_core"
    key_bm = "server"
    key_dvh = "dedicated_virtual_hosts"
    key_long = "long"
    key_dnd = "dnd"
    key_do_not_delete = "donotdelete"
    account_id = ""
    mask = ""
    users_info_dict = {}
    invoice_amount = 0
    billing_acc = ""
    username = ""
    user_billing_info = ""
    teams_payload = ""

    def load_users_and_account(self):
        now = datetime.now()
        dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
        logger.info(f"********* Date and Time = {dt_string} *********")
        logger.info(
            "====================================================================================")
        if os.environ.get("keywords"):
            self.user_list = os.environ.get("users").split(',')
            self.keywords = os.environ.get("keywords").split(',')
            logger.info("Loaded the configurations from Jenkins Variables..")
        else:
            config = configparser.ConfigParser()
            config.read('ibmcloud-config.ini')
            self.user_list = config['USERS']['users'].split(',')
            self.keywords = config['KEYWORDS']['keywords'].split(',')
            logger.info("Loaded the configurations from Local Variables..")

        # Loading credentials info from json file
        json_file = open("ibmcloud-credentials.json", "r")
        creds = json.load(json_file)
        # Creating dictionary item for each user in json data
        for index, user in enumerate(creds['ibmcloud_users']):
            temp_list = []
            temp_list.extend([user['username'], user['password'], user['account_id']])
            key = 'User_' + str(index)
            self.users_info_dict = self.create_user_info_dict(self.users_info_dict, key, temp_list)

        logger.info(
            "================================================================================")
        logger.info(f"List of users who provisioned services: {self.user_list}\n")
        logger.info(f"List of keywords to delete/cancel services: {self.keywords}\n")
        logger.info(f"List of IBM Cloud Users:\n")
        for key, values in self.users_info_dict.items():
            logger.info(f"{key} :: Username: {values[0]}\tAccount ID: {values[2]}")
        return self.users_info_dict

    def create_user_info_dict(self, users_info_dict, key, list_of_values):
        if key not in users_info_dict:
            users_info_dict[key] = list()
        users_info_dict[key].extend(list_of_values)
        return users_info_dict

    def initialize_sl_client(self, sl_username, sl_password):
        logger.info(
            "=====================================================================================")
        logger.info("Initializing IBM Cloud client..")
        self.client = SoftLayer.Client(username=sl_username, api_key=decrypt_password(sl_password))
        self.sl_billing_item_service = self.client['SoftLayer_Billing_Item']
        self.sl_account_service = self.client['SoftLayer_Account']
        self.sl_cancellation_service = self.client['SoftLayer_Billing_Item_Cancellation_Request']
        logger.info(
            "================================================================================")

    def apply_filter(self, item):
        to_process_flag = False
        host_name = ""
        domain_name = ""
        username = item['orderItem']['order']['userRecord']['username']
        if ('hostName' in item['orderItem']):
            host_name = item['orderItem']['hostName']
        if ('domainName' in item['orderItem']):
            domain_name = item['orderItem']['domainName']
        for kw in self.keywords:
            # Check for given keywords
            if kw in host_name or kw in domain_name or username in self.user_list:
                # Check for 'long' and 'dnd' keyword case-insensitively
                if self.key_long.casefold() not in host_name.casefold() or self.key_long.casefold() not in domain_name.casefold() \
                        or self.key_dnd.casefold() not in host_name.casefold() or self.key_dnd.casefold() not in domain_name.casefold() \
                        or self.key_do_not_delete.casefold() not in host_name.casefold() or self.key_do_not_delete.casefold() not in domain_name.casefold():
                    to_process_flag = True
        return to_process_flag

    def bills_by_user(self, sl_username):

        """
        Not all billing items have a user record, these are collected under the master account
        http://sldn.softlayer.com/reference/services/SoftLayer_Account/getNextInvoiceTopLevelBillingItems returns
        http://sldn.softlayer.com/reference/datatypes/SoftLayer_Billing_Item -> taps orderItem for
        http://sldn.softlayer.com/reference/datatypes/SoftLayer_Billing_Order_Item -> taps order for 
        http://sldn.softlayer.com/reference/datatypes/SoftLayer_Billing_Order -> taps userRecord for
        http://sldn.softlayer.com/reference/datatypes/SoftLayer_User_Customer
        """

        logger.info(f"Fetching services for user: {sl_username}")
        logger.info(
            "=============================================================================================")

        self.mask = "mask[orderItem[order[id,userRecord[displayName,username]]]]"

        billingItems = self.sl_account_service.getNextInvoiceTopLevelBillingItems(mask=self.mask)
        self.users = {}
        for item in billingItems:
            if 'orderItem' in item:
                if (self.apply_filter(item)):
                    username = item['orderItem']['order']['userRecord']['username']
                    del item['orderItem']
                    if username not in self.users:
                        self.users[username] = []
                    self.users[username].append(item)

        # Prints everything out, and finds the sum of items.
        for user in self.users:
            servers = []
            everything_else = []
            total_cost = 0
            for item in self.users[user]:
                # This doens't include Tax fees, or setup fees
                cost = float(item['recurringFee']) + float(item['oneTimeFee'])
                if ('hostName' in item) and ('domainName' in item) and ('description' in item):
                    fqdn = "ID-%s | %s.%s ( %s ) : %s $%s" % (
                        item['id'], item['hostName'], item['domainName'], item['categoryCode'], item['description'],
                        cost)
                    servers.append(fqdn)
                else:
                    item = "ID-%s | %s ( %s ) - $%s" % (item['id'], item['description'], item['categoryCode'], cost)
                    everything_else.append(item)
                total_cost = total_cost + cost
            logger.info(f"{user} - {total_cost}")
            for server in servers:
                logger.info(f"\t{server}")
            for thing in everything_else:
                logger.info(f"\t{thing}")

        logger.info(
            "===========================================================================================")

    def delete_resources(self, sl_username, sl_account_id):
        logger.info("Deleting services..")
        logger.info(
            "===========================================================================================")
        for user in self.users:
            for item in self.users[user]:
                # this doens't include Tax fees, or setup fees
                cc = item['categoryCode']
                if (cc in [self.key_vm, self.key_bm, self.key_dvh]):
                    self.delete_item(item)
                else:
                    self.delete_service(item)
                self.cancel_immediate_request(sl_account_id, item)
        logger.info(f"Delete process complete for user: {sl_username}")

    def delete_item(self, item):
        try:
            logger.info("************************************************")
            result = self.sl_billing_item_service.cancelItem(id=item['id'])
            logger.info(f"Cancel Item: {result}")
        except SoftLayer.SoftLayerAPIError as e:
            self.print_error(e, item)

    def delete_service(self, item):
        try:
            logger.info("************************************************")
            result = self.sl_billing_item_service.cancelService(id=item['id'])
            logger.info(f"Cancel Service: {result}")
        except SoftLayer.SoftLayerAPIError as e:
            self.print_error(e, item)

    def cancel_immediate_request(self, account_id, item):
        cancelTemplate = {
            'accountId': account_id,
            'items': [
                {
                    'billingItemId': item['id'],
                    'immediateCancellationFlag': True
                }
            ]
        }

        try:
            logger.info("************************************************")
            result = self.sl_cancellation_service.createObject(cancelTemplate)
            logger.info(f"Create Cancellation Request: {result}")
        except SoftLayer.SoftLayerAPIError as e:
            self.print_error(e, item)

    def get_user_billing_info(self):
        currentUsername = self.sl_account_service.getCurrentUser(self.mask)
        # Get Account ID for current user
        self.billing_acc = currentUsername['accountId']
        # Get Username for current user
        self.username = currentUsername['username'].split("@")[0]
        # Get Next Invoice Amount for current user
        self.invoice_amount = self.sl_account_service.getNextInvoiceTotalAmount(self.mask)
        logger.info(f"Next Invoice Amount for IBM Cloud User '{self.username}': USD {self.invoice_amount}")
        # Create and merge Teams payload having invoice info for all users
        self.user_billing_info = self.user_billing_info + f"<br>**Billing Account:** {self.billing_acc}<br>**Username:** {self.username}<br>**Next Invoice Amount:** USD {self.invoice_amount}<br>"
        return self.user_billing_info

    def create_teams_payload(self, user_billing_info):
        header = "#############################<br>**IBM Cloud Account-wise Invoice Details**<br>#############################<br>"
        self.teams_payload = '{"text": "' + header + user_billing_info + '"}'
        logger.info(f"Teams Payload: {self.teams_payload}")
        print(f"{self.teams_payload}")
        return self.teams_payload

    def print_error(self, e, item):
        isKnownError = False
        ignore_errors = ['This billing item is already canceled', 'already exists in another cancellation request',
                         'A cancellation ticket already exists ']
        for error_to_be_ignored in ignore_errors:
            if (error_to_be_ignored in e.reason or error_to_be_ignored in e.faultString):
                logger.info(f"Service already cancelled for billing id = {item['id']}")
                isKnownError = True
                break
        if (isKnownError == False):
            logger.info(
                f"Unable to cancel the billing item: {item['id']} \nfaultCode= {e.faultCode}, \nfaultString= {e.faultString}")


def main(args):
    billsObj = bills()
    # Returns list of dictionary items indexed as 0 -> Username, 1 -> Password, 2 -> Account_id
    users_dict = billsObj.load_users_and_account()
    for key, values in users_dict.items():
        # Intialize IBM Cloud Client
        billsObj.initialize_sl_client(values[0], values[1])
        # Filter services by given users and keywords
        billsObj.bills_by_user(values[0])
        # Delete services for a given user and account id
        billsObj.delete_resources(values[0], values[2])
        # Get billing info for each user
        billing_info = billsObj.get_user_billing_info()
    # Get Teams payload to upload results
    payload = billsObj.create_teams_payload(billing_info)
    # Post to teams channel
    headers = {"Content-Type": "application/json"}
    api_util.post_request(args.slack_url, headers, payload)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--slack_url", required=False)
    main(parser.parse_args())
