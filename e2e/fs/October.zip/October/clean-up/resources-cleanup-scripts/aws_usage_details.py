import boto3
import datetime
import calendar
import api_util


def get_aws_usage_details(account_id, teams_channel_url, provider):
    client = boto3.client('budgets')
    response = client.describe_budgets(
        AccountId=account_id
    )
    budget_name = response["Budgets"][0]["BudgetName"]
    budget_amount = float(response["Budgets"][0]["BudgetLimit"]["Amount"])
    actual_spend = float(response["Budgets"][0]["CalculatedSpend"]["ActualSpend"]["Amount"])
    forecasted_spend = float(response["Budgets"][0]["CalculatedSpend"]["ForecastedSpend"]["Amount"])
    # current_vs_budgeted = "{:.2f}".format(100 + 100 * abs((actual_spend - budget_amount) / budget_amount))
    forecasted_vs_budgeted = "{:.2f}".format(100 + 100 * abs((forecasted_spend - budget_amount) / budget_amount))
    if actual_spend > budget_amount:
        note = "<strong style='color:Tomato;'>Note: Budget quota is Exceeded;</strong>"
        current_vs_budgeted = "{:.2f}".format(100 + 100 * abs((actual_spend - budget_amount) / budget_amount))
    else:
        note = "<strong style='color:green;'>Note:Budget Threshold is ok and under limit for the account</strong>"
        current_vs_budgeted = "{:.2f}".format((actual_spend * 100) / budget_amount)
    # Slack message Format     
    #     p1 = '{"blocks":[{"type": "header","text": {"type": "plain_text","text": "AWS Account Usage Details"}},{"type": "divider"},{'
    #     p2 = '"type": "section","fields": [{"type": "mrkdwn","text": "*Budget Name*:'
    #     p3 = f'{budget_name}\\n'
    #     p4 = f'*Budget Amount*: {budget_amount}\\n*Actual Spend*: {actual_spend}\\n*ForecastedSpend*: {forecasted_spend}\\n*Current Vs Budgeted*: {current_vs_budgeted}%\\n*Forecasted Vs Budgeted*: {forecasted_vs_budgeted}%\\n*Note*: *{note}*"'
    #     p5 = '}]},{"type": "divider"},{"type": "section","fields": [{"type": "mrkdwn","text": "*User Level Break Up*' + cost_usages(account_id)
    #     p6 = '"}]}]}'
    #     payload = p1 + p2 + p3 + p4 + p5 + p6
    #     Teams text message format
    #     p1 = f"**AWS Account Usage Details:**<br><br>"f"**Budget Name:** {budget_name}<br>"
    #     p2 = f"**Budget Amount:** {budget_amount}<br>"
    #     p3 = f"**Actual Spend:** {actual_spend}<br>"f"**ForecastedSpend:** {forecasted_spend}<br>"
    #     p4 = f"**Current Vs Budgeted:** {current_vs_budgeted}<br>"
    #     p5 = f"**Forecasted Vs Budgeted:** {forecasted_vs_budgeted}%<br>"f"**Note:** {note}<br><br>"
    #     p6 = f"**User Level Break Up:**<br>" + cost_usages(account_id)
    #     payload = '{"text":"' + p1 + p2 + p3 + p4 + p5 + p6 + '"}'
    # Print html message to teams channel
    s1 = '{"type": "message", "attachments": [{"contentType": "application/vnd.microsoft.teams.card.o365connector","content": {"@type": "MessageCard","@context": "https://schema.org/extensions", "summary": "Summary","themeColor": "blue;", '
    s6 = f'"title": "AWS {provider} Usage Details","sections":'
    s2 = f'[{{"text": "<strong>Budget Name:</strong> {budget_name}<br><strong>Budget Amount:</strong> ${budget_amount}<br>'
    sa = f'<strong>Actual Spend:</strong> ${actual_spend}<br><strong>Forecasted Spend:</strong> ${forecasted_spend}<br><strong>Current Vs Budgeted:</strong> {current_vs_budgeted}%<br>'
    s3 = f'<strong>Forecasted Vs Budgeted:</strong> {forecasted_vs_budgeted}%"}},'
    s4 = f'{{"text": "{note}"}},{{"text": "<html><head><style>table {{font-family: arial,sans-serif;border: 3px solid blue;   border-collapse: collapse;   width: 100%; }}  td, th {{border: 2px solid black;border-color: #96D4D4;text-align: left;padding: 5px; }}tr:nth-child(even){{background-color: #D6EEEE; }} </style></head><body><h2>User Level Break Up</h2><table><tr><th>User</th><th>Usage in USD</th></tr> '
    s5 = cost_usages(account_id) + '</table></body></html>"}]}}]}'
    # payload = '{"text":"' + s1 + s2 + + sm + sa + s3 + s4 + s5 + '"}'
    payload = s1 + s6 + s2 + sa + s3 + s4 + s5
    print(payload)
    headers = {"Content-Type": "application/json"}
    api_util.post_request(teams_channel_url, headers, payload)
    return payload


def cost_usages(account_id):
    # Fetch the date of 14 days ago    
    # start_date = str(datetime.date.today() - datetime.timedelta(days=14))
    # end_date = str(datetime.date.today())

    currentDate = datetime.date.today()
    start_date = str(datetime.date(currentDate.year, currentDate.month, 1))
    end_date = str(
        datetime.date(currentDate.year, currentDate.month, calendar.monthrange(currentDate.year, currentDate.month)[1]))

    client = boto3.client('ce')
    response = client.get_cost_and_usage(
        TimePeriod={
            'Start': start_date,
            'End': end_date
        },
        Granularity='MONTHLY',
        Filter={
            "And": [{
                "Dimensions": {
                    "Key": "LINKED_ACCOUNT",
                    "Values": [account_id]
                }
            }, {
                "Not": {
                    "Dimensions": {
                        "Key": "RECORD_TYPE",
                        "Values": ["Credit", "Refund"]
                    }
                }

            }]
        },
        Metrics=["BlendedCost"],
        GroupBy=[
            {
                'Type': 'TAG',
                'Key': 'aws:createdBy'
            }
        ]
    )
    per_user_cost_usages = ""
    for data in enumerate(response["ResultsByTime"][0]["Groups"]):
        expression = data[1]
        tag = expression["Keys"][0].split(":")
        iam_user = tag[len(tag) - 1].split("@")
        usage = "{:.2f}".format(float(expression["Metrics"]["BlendedCost"]["Amount"]))
        # Format text
        if float(usage) > 25:
            user_usage = "<tr><td style='color:Tomato;'>" + iam_user[
                0] + "</td><td style='color:Tomato;'>$ " + usage + "</td></tr>"
        else:
            user_usage = '<tr><td>' + iam_user[0] + '</td><td>$ ' + usage + '</td></tr>'
        if len(iam_user[0]) < 15:
            char_to_add = 15 - len(iam_user[0])
            for x in range(char_to_add):
                iam_user[0] = iam_user[0] + "_"
        elif len(iam_user[0]) > 15:
            iam_user[0] = iam_user[0][:15]
        # per_user_cost_usages = per_user_cost_usages + "<br>" + iam_user[0] + " | USD " + "{:.2f}".format(float(usage))
        per_user_cost_usages = per_user_cost_usages + user_usage
        # print(iam_user[0] + " | $ " + usage)
    # print(per_user_cost_usages)
    return per_user_cost_usages


def main(args):
    get_aws_usage_details(args.account_id, args.slack_url, args.provider)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--account_id")
    parser.add_argument("--slack_url", required=False)
    parser.add_argument("--provider", required=False)
    main(parser.parse_args())
