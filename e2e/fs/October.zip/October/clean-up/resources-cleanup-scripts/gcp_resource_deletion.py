#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Delete GCP resource groups
"""

import json
import logging
import api_util
import sys

"Command to Run : python resource_group_deletion.py -o <arg>(arg could be list or delete)"

# PROVIDER_DATA_CONFIG = json.loads(open('ProviderData.json').read())
# Please Provide Slack Channel name in ProviderData.json file to Post the results into Slack Channel
# Slack_channel = PROVIDER_DATA_CONFIG['slack_channel']
# skip_delete = PROVIDER_DATA_CONFIG['skip_delete']
skip_delete = ["preseed", "dontdelete", "donotdelete", "dnd"]
# Please Provide Slack URL to Post the results into Slack Channel
SLACK_URL = ""
project_name = sys.argv[1]
refresh_token = sys.argv[2]
client_id = sys.argv[3]
client_secret = sys.argv[4]
# Please provide either list or delete
option_to_perform = sys.argv[5]
teams_webhook = sys.argv[6]

logging.basicConfig(
    format="%(asctime)s [%(levelname)2s] %(filename)s:%(lineno)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.INFO,
)


def generate_bearer_token():
    url = "https://oauth2.googleapis.com/token"
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    data = f'access_type=offline&refresh_token={refresh_token}&client_id={client_id}&client_secret={client_secret}&grant_type=refresh_token'
    resp, output = api_util.post(url, data, headers)
    # print("Response: ",output)
    return output['access_token']


def list_gcp_resources():
    """
        Script to list resources
        """

    # Get Resources Names
    url = f'https://www.googleapis.com/deploymentmanager/v2/projects/{project_name}/global/deployments'
    bearer_token = f'Bearer {generate_bearer_token()}'
    headers = {'Authorization': bearer_token}
    (resp, resp_body) = api_util.get(url, headers)
    if resp == 200:
        resources = resp_body
        if resources:
            for i in resources['deployments']:
                asset_name = i['name']
                logging.info(f"Resource Available: {asset_name}")
        else:
            logging.info("No Resource Available")


def delete_gcp_resources():
    """
    Script to delete resources
    """
    # Authorization API

    url = f'https://www.googleapis.com/deploymentmanager/v2/projects/{project_name}/global/deployments'
    bearer_token = f'Bearer {generate_bearer_token()}'
    # print("Token",bearer_token)
    headers = {'Authorization': bearer_token}
    (resp, resp_body) = api_util.get(url, headers)
    if resp == 200:
        resources = resp_body
        # print(f"Response:{resp},{resp_body}")
        if resources:
            for i in resources['deployments']:
                asset_name = i['name']
                logging.info(asset_name)
                re = any(substring in asset_name for substring in skip_delete)
                if re:
                    logging.info(f"Cannot delete assets with {skip_delete} prefixes")
                else:
                    logging.info(f"{url} / {asset_name}")
                    urldelete = url + '/' + asset_name
                    resp = api_util.delete(urldelete, headers)
                    logging.info(f"Response of delete API execution: {resp}")
            # Please uncomment below function to post the results into Slack channel
            # post_result_to_slack(Slack_channel, SLACK_URL, asset_name)
        else:
            logging.info("********No Assets are present in the portal*******")
        #  Post Clean up result to Teams channel
        post_resource_details_teams(resources)
    else:
        logging.info("Authorisation failed, please verify your credentials")


def post_result_to_slack(Slack_channel, SLACK_URL, resource_group_length):
    """
        Post the results to Slack channel
        """
    url = SLACK_URL

    headers = {'accept': 'application/json', 'Content-Type': 'application/json'}

    body = {
        "channel": Slack_channel,
        "username": "GCP Resource info",
        "attachments": [
            {
                "color": "#080888",
                "title": "GCP Resource info BOT",
                "fields": [
                    {
                        "value": "Available GCP resource information: " +
                                 str(resource_group_length)
                    },
                ]
            }
        ]
    }
    try:
        resp, body = api_util.post(url, json.dumps(body), headers=headers)
        return resp, body
    except Exception as exception:
        print("Failed to post results in slack, please verify your slack URL")
        print(exception)


def resource_operation(action):
    if action.lower() == "list":
        list_gcp_resources()
    elif action.lower() == "delete":
        delete_gcp_resources()
    else:
        logging.info("please provide accepted arguments list or delete")
        exit(1)


def post_resource_details_teams(resources):
    s1 = '{"type": "message", "attachments": [{"contentType": "application/vnd.microsoft.teams.card.o365connector","content": {"@type": "MessageCard","@context": "https://schema.org/extensions", "summary": "Summary","themeColor": "blue;", "title": "GCP Resource Details","sections":'
    s2 = f'[{{"text": "<strong>Project Name:</strong> {project_name}"}},'
    s3 = f'{{"text": "<html><head><style>table {{font-family: arial,sans-serif;border: 3px solid blue;   border-collapse: collapse;   width: 100%; }}  td, th {{border: 2px solid black;border-color: #96D4D4;text-align: left;padding: 5px; }}tr:nth-child(even){{background-color: #D6EEEE; }} </style></head><body><h2>Available Resources for Clean up</h2><table><tr><th>Resource</th></tr> '
    resources_to_delete = ""
    if resources:
        for i in resources['deployments']:
            asset_name = '<tr><td>' + i['name'] + '</td></tr>'
            resources_to_delete = resources_to_delete + asset_name
    else:
        resources_to_delete = '<tr><td> No resource To Delete </td></tr>'
    s4 = resources_to_delete + '</table></body></html>"}]}}]}'
    # s4 = f'{{"text": "<strong>Total Spend Amount:</strong> $ {total_spend}"}}]}}}}]}}'
    payload = s1 + s2 + s3 + s4
    print(payload)
    # Post message to teams channel
    headers = {"Content-Type": "application/json"}
    api_util.post_request(teams_webhook, headers, payload)
    return payload


if __name__ == '__main__':
    resource_operation(option_to_perform)
