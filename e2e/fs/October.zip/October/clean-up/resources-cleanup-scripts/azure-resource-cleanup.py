"""
@author Padmakar Selokar

Fetch the billing items and clean up the resources which are created in Automation Testing
"""

import json
import os
import common_util
import api_util
from logger_util import logger
import configparser
from datetime import datetime
from azure.identity import ClientSecretCredential
from azure.mgmt.resource import ResourceManagementClient
import adal
import requests
from mo_encryption_decryption import decrypt_password

from datetime import date
today = date.today()
date = today.strftime("%B %d, %Y")
import azure_cost_management


class azure_deletion():
    dnd_key = 'dnd'
    long_key = 'long'
    do_not_delete_key = 'donotdelete'
    keywords = []
    users_info_dict = {}
    billing_info = ""
    teams_payload = ""
    authentication_endpoint = 'https://login.microsoftonline.com/'
    resource_url = 'https://management.core.windows.net/'
    
    def initialize_azure_client(self, sub_id, client_id, client_secret_key, tenant_id):
        logger.info(
            "==============================================================================================")
        logger.info("Initializing Azure client..")
        credentials = ClientSecretCredential(
            client_id=client_id,
            client_secret=decrypt_password(client_secret_key),
            tenant_id=tenant_id
        )
        self.client = ResourceManagementClient(credentials, sub_id)

    def separate_resource_group(self, sub_id):
        logger.info(f"Fetching resource groups for subscription id: {sub_id}")
        logger.info(
            "========================================================================================================")
        all_resource_groups = self.client.resource_groups.list()
        resource_group_list = []
        dnd_resource_group_list = []

        for item in all_resource_groups:
            rg_name = item.name
            # Check for 'dnd' or 'long 'in RG name case-insensitively
            if self.dnd_key.casefold() in rg_name.casefold() or self.long_key.casefold() in rg_name.casefold() or self.do_not_delete_key.casefold() in rg_name.casefold():
                dnd_resource_group_list.append(rg_name)
            else:
                # Check for keywords in RG name
                for key in self.keywords:
                    if key in rg_name:
                        resource_group_list.append(rg_name)
        return dnd_resource_group_list, resource_group_list

    def delete_resource_groups(self, resource_group_list):
        logger.info("Deleting resource groups..")
        if resource_group_list:
            for rg in resource_group_list:
                logger.info(f"Deleting Resource group: {rg}")
                try:
                    self.client.resource_groups.delete(rg)
                    logger.info("Resource group deleted successfully")
                except:
                    logger.info("Unable to delete the resource group. Please check, if the RG is locked")
            logger.info("Deletion process is complete")
        else:
            logger.info("No resource group found to delete")
        logger.info(
            "========================================================================================")

    def get_access_token(self, client_id, client_secret_key, tenant_id):
        # Create access token using tenant_id, client_id and client_secret_key
        context = adal.AuthenticationContext(self.authentication_endpoint + tenant_id)
        token_response = context.acquire_token_with_client_credentials(self.resource_url, client_id,
                                                                       decrypt_password(client_secret_key))
        access_token = token_response.get('accessToken')
        return access_token

    def get_subscription_usage_details(self, sub_id, access_token, actual_cost):
        total_usage_cost = 0
        subscription_name=''

        # Create endpoint by passing subscription id
        endpoint = 'https://management.azure.com/subscriptions/' + sub_id + '/providers/Microsoft.Consumption/usageDetails?api-version=2021-10-01'
        # Pass access token created in headers
        headers = {"Authorization": 'Bearer ' + access_token}

        response = requests.get(endpoint, headers=headers).json()
        # Check for length of items in response body
        response_items_len = len(response["value"])
        # Get subscription name from response body
        subscription_name = response["value"][0]["properties"]["subscriptionName"]
        if response_items_len:
            # Calculate cost for complete subscription by looping through each usage item block
            for sub in response["value"]:
                total_usage_cost = total_usage_cost + sub["properties"]["cost"]
            # Truncate float value upto 3 decimal
            total_usage_cost = float("{:.3f}".format(total_usage_cost))
            logger.info(f"Total Amortized Usage cost for subscription '{subscription_name}': USD {total_usage_cost}")
            # Create and merge Teams payload having billing info for all subscriptions
            actual_cost = "{:.3f}".format(actual_cost)
            self.billing_info = self.billing_info + f"<br>**Subscription Name:** {subscription_name}<br>**Amortized Cost:** USD {total_usage_cost}<br>**Actual Cost:** USD {actual_cost}<br>"
        else:
            self.billing_info = self.billing_info + f"<br>**Subscription Name:** {subscription_name}<br>*There are no items to calculate total usage cost*<br>"
            logger.info("There are no items to calculate total usage cost")
        logger.info(
            "================================================================================================")
        return self.billing_info


def main(args):
    az_delete = azure_deletion()
    # Returns list of dictionary items indexed as 0 -> Sub ID, 1 -> Client ID, 2 -> Client Secret Key, 3 -> Tenant ID    
    creds_dict = common_util.get_azure_credentials(account=args.account)
    for key, values in creds_dict.items():
        # Get Actual Cost
        actual_cost = azure_cost_management.cost_management(values[0], values[1], values[2], values[3], values[4])
        # Intialize Azure Client
        az_delete.initialize_azure_client(values[0], values[1], values[2], values[3])
        # Seperate resource groups
        dnd_resource_group_list, resource_group_list = az_delete.separate_resource_group(values[0])
        logger.info(f"Resource groups not to be delete:\n{dnd_resource_group_list}")
        logger.info(f"Resource groups to be delete:\n{resource_group_list}")
        # Delete resource groups
        az_delete.delete_resource_groups(resource_group_list)
        # Get access token to call azure API
        auth_token = az_delete.get_access_token(values[1], values[2], values[3])
        # Get total usage cost for a given subscription
        sub_billing_info = az_delete.get_subscription_usage_details(values[0], auth_token, actual_cost)

    # Get Teams payload to upload results    
    payload = common_util.create_teams_payload_azure(sub_billing_info)
    # Post to teams channel
    headers = {"Content-Type": "application/json"}
    api_util.post_request(args.slack_url, headers, payload)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--slack_url", required=False)
    parser.add_argument("--account", required=True)
    main(parser.parse_args())
