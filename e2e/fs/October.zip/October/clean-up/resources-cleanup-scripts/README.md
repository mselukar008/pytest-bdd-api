Scripts to delete cloud resources created while automation testing

**\*** **IBM Cloud** **\***

1. Install the requirements : `pip install -r requirements.txt`
2. Update the list of users and list of keywords for which the cleanup of resources need to be done in file `ibmcloud-config.ini`.
3. If you need to update IBM Cloud Account details and add/remove users, please update it in JSON file `ibmcloud-credentials.json`
4. Run the script : `python ibmcloud-resource-cleanup.py`
5. This script will delete Classic infra resources for the given IBM Cloud accounts and post the Next Invoice Billing info for those users on slack channel
6. This script won't delete the resources having **'long'** string in their host name or domain name

**NOTE:** The Password for IBM Cloud users in JSON file are need to encrypted using following command:
`python mo_encryption_decryption.py <password>`

**\*** **Azure** **\***

1. Install the requirements : `pip install -r requirements.txt`
2. Update the list of keywords for which the cleanup of resources need to be done in file `azure-config.ini`.
3. If you need to update Azure Subscription details and add/remove users, please update it in JSON file `azure-credentials.json`
4. Run the script : `python azure-resource-cleanup.py`
5. This script will delete resource groups for the given Azure Subscriptions and list of keywords and then post the Current Invoice info for those subscriptions on slack channel
6. This script won't delete the resource groups having **'dnd'** string in their name and the locked resource groups for Delete operation

**NOTE:** The Client Secret Key for Azure Subscriptions in JSON file are need to encrypted using following command:
`python mo_encryption_decryption.py <password>`

**\*** **AWS** **\***

1. Configure AWS Credentials on system. Please refer this guide for complete aws profile setup - https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-quickstart.html
   - Hit this command on terminal - aws configure; it will ask for below inputs, just provide and hit enter.
     - AWS Access Key ID [None]: AKIAIOSFODNN7EXAMPLE
     - AWS Secret Access Key [None]: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
     - Default region name [None]: us-east-1
     - Default output format [None]: json


    * After installation, check aws version using command aws --vesrion and make sure valid output is displayed.
    * Once aws iam user account is ready from above steps, please install aws cli latest version. PLease refer this guide - https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html

2. Clone the repo and run `pip install -r requirements.txt`
3. Make the script executable and run - `./aws-resource-cleanup.sh AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY`
4. This script won't delete the resource groups having **'dnd' and 'DND'** string in their name

**\*** **GCP** **\***

1. Make sure you have access to valid Google project, please refer - https://cloud.google.com/run/docs/setup
2. Keep gcp account credentials handy, set up google sdk and cli. Refer - https://cloud.google.com/sdk/docs/install-sdk
3. After SDK installation, Initializing the gcloud CLI by hitting command- gcloud init
4. Provide necessary details and set up the Google account.Clone the repo.
5. Automatic Bearer Token Generation - Steps to Generate Bearer Token Automatically(One time activity):
   1. Login to Google Cloud Console
   2. Go to API & Services
   3. Create OAuth Consent Screen and Add Credential for OAuth 2.0 Client ID by following https://theonetechnologies.com/blog/post/how-to-get-google-app-client-id-and-client-secret
   4. Make sure to add domains ( www.googleapis.com , google.com) and Test user while creating OAuth Consent Screen.
   5. Go to OAuth 2.0 Client ID for Web application 
   6. Under Authorized redirect URIs and Authorized JavaScript origins, add a line with: https://developers.google.com/oauthplayground
   7. On the Client ID page, take note of the client ID and client secret.(Also keep that handy to pass in the command)
   8. Go to the https://developers.google.com/oauthplayground/
   9. Click the gear icon in the upper right corner and check the box labeled Use your own OAuth credentials (if it isn't already checked).
   10. Make sure that:<br>OAuth flow is set to Server-side.<br>Access type is set to Offline (this ensures you get a refresh token and an access token, instead of just an access token).
   11. Enter the OAuth2 client ID and OAuth2 client secret you obtained above.
   12. In the section labeled Step 1 - Select & authorize APIs <br>Authroize API for cloud deployment manager
   13. Exchange Authorization code for token
   14. Get access token and refresh token [Keep refresh token handy to pass in the command]
   15. Copy Project Name from the Google Cloud Console
6. Run python gcp_resource_deletion.py <project_name> <refresh_token> <client_id> <client_secret> <option_to_perform>
7. Whenever the scrip triggers it will generate the bearer token automatically.
8. To List the Resources: ```python gcp_resource_deletion.py <project_name> <refresh_token> <client_id> <client_secret> list```
9. To Delete the Resources: ```python gcp_resource_deletion.py <project_name> <refresh_token> <client_id> <client_secret> delete```
 Please find more details on : https://developers.google.com/google-ads/api/docs/oauth/playground <br> https://www.daimto.com/how-to-get-a-google-access-token-with-curl/ <br> https://developers.google.com/identity/protocols/oauth2/scopes

10. To Delete all resources from console, run -```./gcp-resource-cleanup.sh ```
