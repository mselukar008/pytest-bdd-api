#!/bin/bash

##getting the arguments passed
access_key_id=$1
secret_access_key=$2

##update secret key and access key for aws account of particular user
# aws configure set aws_access_key_id $access_key_id
# aws configure set aws_secret_access_key $secret_access_key

date=$(date +"%Y-%m-%d")
directory=$(mkdir -p logs/$date)
declare -a regions=("us-east-1" "us-east-2" "ap-northeast-1" "ap-northeast-2" "ap-south-1" "ap-southeast-1" "ap-southeast-2" "ca-central-1" "eu-central-1" "eu-west-1" "eu-west-2" "eu-west-3" "sa-east-1" "us-west-1" "us-west-2")

for region in "${regions[@]}"
do
stackList=$(aws cloudformation describe-stacks --region "$region" --query "Stacks[*].StackName")
now=$(date +"%Y-%m-%d %T")
filename="stackList_'$now'_'$region'.txt"
startWith=("dnd" "DND" "donotdelete")

echo "$stackList" > "$filename"

while read -r line; do
    if [[ "$line" == \"* ]];  
      then
	stackName=$(echo $line | cut -d'"' -f 2)
	flag="false"
	for each in "${startWith[@]}"
	   do
        	if [[ "$stackName" == "$each"* ]]; 
        	then
		    flag="true"
		fi
	   done
	   if  [[ "$flag" == "false" ]];
          then
            deleteResponse=$(aws cloudformation delete-stack --stack-name "$stackName" --region "$region")
            echo "$stackName" stack deletion initiated
       fi    
    fi  
done < "$filename"
done
