// @ts-check
const { defineConfig } = require('@playwright/test');

//Load ENvironment variables for local test execution
if (process.env.CI === undefined) {
  require('dotenv').config({ path: './.env.development' });
}
const test_suite_list = require('./helpers/util').generateRuntimeSpecString(process.env.TEST_SUITE_LIST);

// @ts-ignore
module.exports = defineConfig({    
  testDir: './e2e/tests',  
  // testMatch: 'test_suite_list.spec.js',
  testMatch: test_suite_list,
  reporter: [
    ['html', { open : 'never' }],
    ['junit', { outputFile: './test-results/results.xml' }],
    ['./helpers/customReporter.js']
    
  ],  
  /* Maximum time one test can run for. */
  timeout: 5 * 60 * 1000,
  expect: {
    /**
     * Maximum time expect() should wait for the condition to be met.
     * For example in `await expect(locator).toHaveText();`
     */
    timeout: 15000
  },
  //Limit the number of failures on build
  maxFailures : process.env.CI ? 2 : 10,
  /* Run tests in files in parallel */
  fullyParallel: process.env.RUN_IN_PARALLEL === 'true' ? true : false,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 1 : 0,
  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? 1 : Number(process.env.WORKERS),
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* Maximum time each action such as `click()` can take. Defaults to 0 (no limit). */
    actionTimeout: 60000,
    baseURL: process.env.ENVIRONMENT_URL,   
    browserName: process.env.BROWSER_PF,
    channel: process.env.BROWSER,
    headless: process.env.HEADLESS === 'true' ? true : false,
    viewport: { width: 1280, height: 720 },
    ignoreHTTPSErrors: true,
    screenshot: 'only-on-failure',
    trace: process.env.COLLECT_TRACE,
    //video: process.env.COLLECT_VIDEO,    
    contextOptions :  {
      recordVideo:{
        mode: process.env.COLLECT_VIDEO,
        dir:'./test-results/videos'
      }
    }
  },
  /* Folder for test artifacts such as screenshots, videos, traces, etc. */
  outputDir: './test-results/'
});

