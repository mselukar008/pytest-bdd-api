
function generateRuntimeSpecString(suitesList) {
	const path = require('path');
	const testFolder = path.resolve("e2e","tests")
	let specArray = [];	
	const suitesArray = suitesList.split(",");
	const suitesLength = suitesArray.length;	
	for (let i = 0; i < suitesLength; i++) {		
		if (suitesArray[i] === "home")			
			specArray.splice(i, 0, path.resolve(testFolder,"home.spec.js"));
		if (suitesArray[i] === "launchpad")			
			specArray.splice(i, 0, path.resolve(testFolder,"launchpad.spec.js"));
					
	}	
	return specArray;
}

module.exports = { 	
	generateRuntimeSpecString:generateRuntimeSpecString	
}