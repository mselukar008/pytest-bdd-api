import logger from "./logGenerator";
/**
 * Add Customised code in commented method as per requirements
 */
class MyReporter {

    onBegin(config, suite) {       
        logger.getApplicationLogger().info("=============================Test Suite : " + suite.suites[0].suites[0].suites[0].title + " ===============")
    }    
    
    onTestBegin(test) { 
        if(process.env.SKIP_TESTS_ON_FAILURE === true){
            test.skip();
        }
        // logger.getApplicationLogger().info("==============================Starting Execution for Test case : " + test.title);
    }
    
    // async onTestEnd(test, result) {       
    //     logger.getApplicationLogger().info("==============================Completed Test Case Execution : " + test.title  + " : " + result.status.toUpperCase());
    // }
    
    async onEnd(result) {
        logger.getApplicationLogger().info(`Finished the run: ${result.status.toUpperCase()}`);        
        const intUtil = require('../helpers/integrationUtils')  
        //Post Reports to Teams/Slack
        if(process.env.POST_TO_TEAMS == "yes"){
            await intUtil.postResultsToTeams("PW BUILD")
        }
    }

    // onStdOut(string, TestCase, TestResult) {      
    //     logger.getApplicationLogger().info(string)
    // };

    // onStdErr(string, TestCase, TestResult) {      
    //     logger.getApplicationLogger().info(string)
    // };

    printsToStdio(){
        return false
    }
}
    
export default MyReporter;

