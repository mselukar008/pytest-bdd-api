const fs = require('fs');
const xml2js = require('xml2js');
const slackDetails = require('../testData/utils/integration.json');
const apiUtl = require('../helpers/apiUtil');
const util = require('util');

async function postResultsToSlack(build_url) {
    const payload = await generatePayloadSlack(build_url);
    await apiUtl.runpostApi(process.env.SLACK_WEBHOOK, payload)
}

async function postResultsToTeams(build_url) {
    const payload = await generatePayloadTeams(build_url);
    await apiUtl.runpostApi(process.env.TEAMS_WEBHOOK, payload)
}

async function getDataFromJunitXml() {
    const parser = new xml2js.Parser();
    const data = await fs.promises.readFile('./test-results/results.xml')
    const result = await util.promisify(parser.parseString.bind(parser))(data);
    return result;
}

async function generatePayloadTeams(build_url) {    
    const result = await getDataFromJunitXml();
    const lenSuite = result.testsuites.testsuite.length;
    let finalTestSuiteSummaryToPost = "Feature-wise Summary: <br>";
    let totalPassed = 0;
    let totalFailed = 0;
    let totalSkipped = 0;
    for (let j = 0; j < lenSuite; j++) {
        let testSuiteName = result.testsuites.testsuite[j].$.name;
        let testSuiteSummary = testSuiteName;
        let totalTestCase = result.testsuites.testsuite[j].testcase.length;
        let failed = 0;
        let passed = 0;
        let skipped = 0;

        for (let i = 0; i < totalTestCase; i++) {
            if ((result.testsuites.testsuite[j].testcase[i].failure)) {
                failed = Number(failed) + 1;
            }
            else if ((result.testsuites.testsuite[j].testcase[i].skipped)) {
                skipped = Number(skipped) + 1;
            }
            else {
                passed = Number(passed) + 1;
            }
        }
        totalFailed = totalFailed + failed;
        totalPassed = totalPassed + passed;
        totalSkipped = totalSkipped + skipped;
        testSuiteSummary = testSuiteSummary + "   -  " + "Passed: " + passed.toString() + " Failed: " + failed.toString() + " Skipped: " + skipped.toString() + " <br>";
            
        finalTestSuiteSummaryToPost = finalTestSuiteSummaryToPost + testSuiteSummary;
    }
    let totalCount = totalFailed + totalPassed + totalSkipped;
    const provider = "Sample Application"
    const pass_percent = Math.round(parseFloat(parseInt(totalPassed) * 100 / parseInt(totalCount)), 2).toString();
    const summary = `**UI Automation Test results:** <br><br> **Provider:** ${provider}<br> **Environment:** ${process.env.ENVIRONMENT_URL}<br> **Build:** ${build_url}<br><br> **Total TestCases Executed:** ${totalCount}<br> **Passed:** ${totalPassed}<br> **Failed:** ${totalFailed}<br> **Skipped:** ${totalSkipped}<br> **Pass Percentage:** ${pass_percent}%<br><br> **Feature-wise Summary:**<br> ` + '<br>'
    const body = summary + finalTestSuiteSummaryToPost    
    return body;
}

async function generatePayloadSlack(build_url) {   
    const result = getDataFromJunitXml();
    let testExecutiontitle = "UI Automation Test Results:\n URL: " + process.env.ENVIRONMENT_URL + " \n Build: " + build_url;
    let lenSuite = result.testsuites.testsuite.length; 
    let finalTestSuiteSummaryToPost = "Feature-wise Summary:\n";
    let totalPassed = 0;
    let totalFailed = 0;
    let totalSkipped = 0;
    for (let j = 0; j < lenSuite; j++) {
        let testSuiteName = result.testsuites.testsuite[j].$.name;
        let testSuiteSummary = testSuiteName;
        let totalTestCase = result.testsuites.testsuite[j].testcase.length;
        let failed = 0;
        let passed = 0;
        let skipped = 0;

        for (let i = 0; i < totalTestCase; i++) {
            if ((result.testsuites.testsuite[j].testcase[i].failure)) {
                failed = Number(failed) + 1;
            }
            else if ((result.testsuites.testsuite[j].testcase[i].skipped)) {
                skipped = Number(skipped) + 1;
            }
            else {
                passed = Number(passed) + 1;
            }
        }
        totalFailed = totalFailed + failed;
        totalPassed = totalPassed + passed;
        totalSkipped = totalSkipped + skipped;
        testSuiteSummary = testSuiteSummary + "   -  " + "_Passed: " + passed.toString() + "_" + "`Failed: " + failed.toString() + "` " + "_Skipped: " + skipped.toString() + "_" +
            "\n";
        finalTestSuiteSummaryToPost = finalTestSuiteSummaryToPost + testSuiteSummary;
    }
    let totalCount = totalFailed + totalPassed + totalSkipped;
    let body = "testExecutiontitle \ntotalCount \ntotalPassed \ntotalFailed \ntotalSkipped \nfinalTestSuiteSummaryToPost";

    body = body.replace("testExecutiontitle", testExecutiontitle.toString() + "\n");
    body = body.replace("totalCount", "Total TestCases Executed : " + totalCount.toString());
    body = body.replace("totalPassed", "Passed : " + totalPassed.toString());
    body = body.replace("totalFailed", "Failed : " + totalFailed.toString());
    body = body.replace("totalSkipped", "Skipped : " + totalSkipped.toString() + "\n");
    body = body.replace("finalTestSuiteSummaryToPost", finalTestSuiteSummaryToPost.toString() + "\n");
    return body;
}

module.exports = {   
    postResultsToTeams: postResultsToTeams,
    postResultsToSlack: postResultsToSlack
};