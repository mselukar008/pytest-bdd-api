const base = require('@playwright/test');
const loginApp = require('./globalLogin');
const { homePage } = require('../e2e/page/home.pageObject');
const { catalogPage } = require('../e2e/page/catalog.pageObject');
const fs = require('fs');
const path = require('path');
const util = require('./util');
let skip_test = false;
import logger from "./logGenerator";
import { PlaywrightHar } from 'playwright-har';
import test from "@playwright/test";

exports.test = base.test.extend({             
    loggedIn: [async ({ browser }, use, workerInfo) => {        
        logger.getApplicationLogger().info('======================Test Environment Details ==================================')
        logger.getApplicationLogger().info(`Environment :  ${process.env.ENVIRONMENT_URL}`);
        logger.getApplicationLogger().info(`User :  ${process.env.UI_AUTOMATION_USER}`);       
        logger.getApplicationLogger().info(`Collect_Har :  ${process.env.COLLECT_HAR}`);
        logger.getApplicationLogger().info(`Collect_Video :  ${process.env.COLLECT_VIDEO}`);
        logger.getApplicationLogger().info(`Post to Teams :  ${process.env.POST_TO_TEAMS}`);
        logger.getApplicationLogger().info(`Post to DI :  ${process.env.POST_TO_DI}`);
        logger.getApplicationLogger().info(`Browser Channel :  ${process.env.BROWSER_PF}`);
        logger.getApplicationLogger().info(`Browser :  ${process.env.BROWSER}`);
        logger.getApplicationLogger().info("==================Global Login =========================")        
        const page = await login(browser, process.env.ENVIRONMENT_URL, process.env.UI_AUTOMATION_USER, process.env.UI_AUTOMATION_PWD, process.env.GOOGLE_AUTH_SECRET);
        await use(page);                            
    }, { scope: 'worker', auto : true }],   
    page: async ({ loggedIn, browser }, use, testInfo) => {
        const page = loggedIn;       
        // Use signed-in page in the test. 
        logger.getApplicationLogger().info("==============================Starting Execution for Test case : " + testInfo.title);       
        //Navigate to home page before starting new test case
        await page.goto('/launchpad');
        //Start capturing har file for each test case
        const playwrightHar = new PlaywrightHar(page);
        await playwrightHar.start();       
        await use(page); 
        //Stop har file recording after each test case
        const specName = testInfo.title.replace(/\W/g, '-');        
        const har_path = testInfo.outputPath(specName + ".har").toString();
        await playwrightHar.stop(har_path); 
        
        //Remove har file if user don't want to store
        if(process.env.COLLECT_HAR == 'off'){
            fs.rmSync(har_path)
        }

        if(testInfo.status != testInfo.expectedStatus){
            if(process.env.COLLECT_HAR == 'retain-on-failure'){                
                await testInfo.attach("HAR File", { path : har_path })
            }else{
                fs.rmSync(har_path)
            }
            if(testInfo.title.includes("@critical")){
                process.env.SKIP_TESTS_ON_FAILURE = true;                         
            }  
        }
        
        logger.getApplicationLogger().info("==============================Completed Test Case Execution : " + testInfo.title  + " : " + testInfo.status.toUpperCase());
    }, 
        
    homePageObj: async ({ page }, use) => {        
        const homePageObj = new homePage(page);
        await use(homePageObj);        
    },
    catalogPageObj: async ({ page }, use) => {        
        const catalogPageObj = new catalogPage(page);
        await use(catalogPageObj);        
    },

});

exports.expect = base.expect
