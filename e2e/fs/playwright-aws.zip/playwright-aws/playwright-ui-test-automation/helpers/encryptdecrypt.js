var CryptoJS = require("crypto-js");

//Encrypting text
function encrypt(text) {
    var ciphertext = CryptoJS.AES.encrypt(text, 'secret key 123').toString()
    return ciphertext;    
}

// Decrypting text
function decrypt(text) {   
    var bytes  = CryptoJS.AES.decrypt(text, 'secret key 123');
    var originalText = bytes.toString(CryptoJS.enc.Utf8);
    return originalText;    
}

module.exports = {
    encrypt: encrypt,
    decrypt: decrypt
}
