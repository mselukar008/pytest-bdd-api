let suitesList  = process.env.TEST_SUITE_LIST	
let suitesArray = suitesList.split(",");
let suitesLength = suitesArray.length;


for (var i = 0; i < suitesLength; i++) {		
	if (suitesArray[i] == "home")			
		require('./home.spec.js');
		// test.describe("Sample Suite", require('./sample.spec.js'))
	if (suitesArray[i] == "launchpad")			
		require('./launchpad.spec.js');		
}
	
