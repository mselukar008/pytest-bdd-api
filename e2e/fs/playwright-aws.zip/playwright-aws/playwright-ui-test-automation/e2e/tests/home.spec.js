const { test, expect } = require('../../helpers/fixture');
const genericTestData  = require('../../testData/genericData.json');

test.describe("Home Page Test Cases", () => {    
    /**
     * Test Cases
     */ 
    
    test('@critical Validate Service Details and Navigation to Catalog', async ({ homePageObj, catalogPageObj }) => {        
        const [title, subtitle, pageSections] = await homePageObj.getPageDetails();
        //Soft assertions of playwright
        expect.soft(title).toEqual(genericTestData.samplePageTitle)
        expect.soft(subtitle).toEqual(genericTestData.samplePageSubTitle)
        //Hard assertions of playwright
        expect(pageSections[0]).toEqual(genericTestData.homePageSection1)
        expect(pageSections[1]).toEqual(genericTestData.homePageSection2)
        expect(pageSections[2]).toEqual(genericTestData.homePageSection3)
        expect(pageSections[3]).toEqual(genericTestData.homePageSection4)
        expect(pageSections[4]).toEqual(genericTestData.homePageSection5)
        await homePageObj.navigateToMcmpApplication(genericTestData.marketPlaceText, genericTestData.catalogText)
        const catalogTitle = await catalogPageObj.getPageDetails()
        expect(catalogTitle).toEqual(genericTestData.catalogMainTitle)
    })

    test('Validate home page', async ({ homePageObj, catalogPageObj }) => {        
        const [title, subtitle, pageSections] = await homePageObj.getPageDetails();
        //Soft assertions of playwright
        expect.soft(title).toEqual(genericTestData.samplePageTitle)
        expect.soft(subtitle).toEqual(genericTestData.samplePageSubTitle)
        //Hard assertions of playwright
        expect(pageSections[0]).toEqual(genericTestData.homePageSection1)
        expect(pageSections[1]).toEqual(genericTestData.homePageSection2)
        expect(pageSections[2]).toEqual(genericTestData.homePageSection3)
        expect(pageSections[3]).toEqual(genericTestData.homePageSection4)
        expect(pageSections[4]).toEqual(genericTestData.homePageSection5)        
    })
 })

