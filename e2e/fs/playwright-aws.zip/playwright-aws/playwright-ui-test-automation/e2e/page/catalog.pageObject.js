"use strict";
const { commonMethods } = require('../../helpers/commonMethods');
let page, 
commonUiMethods = new commonMethods(page);

/**
 * Define Locators on page like xpath,css etc.
 * Naming convention --> elementNameElementTypeLocatorType 
 */

var locatorsConfig = {    
    pageSubTitleTextCss: "h1[class*='title']",
    pageTitleTextCss: ".header_nav span:nth-child(2)", 
};

exports.catalogPage = class catalogPage{    
    constructor(Page) {        
        page = Page; 
        commonUiMethods = new commonMethods(page);     
    };
    
    /**
     * Sample Page object methods utilising locators and commonUiMethods
     * 
     */

    async getPageDetails(){
        const title = await commonUiMethods.getText(locatorsConfig.pageTitleTextCss, "Catalog Main Title")
        return title;
    }

}