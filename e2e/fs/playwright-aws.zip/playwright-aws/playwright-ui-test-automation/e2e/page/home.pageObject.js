"use strict";

const { expect } = require('@playwright/test');
const { commonMethods } = require('../../helpers/commonMethods');
let page, 
commonUiMethods = new commonMethods(page);

/**
 * Define Locators on page like xpath,css etc.
 * Naming convention --> elementNameElementTypeLocatorType 
 */

var locatorsConfig = {    
    pageTitleTextCss: ".header_nav span:nth-child(2)", 
    pageSubtitleTextCss : "h1",
    pageSectionsTextCss : "h3",
    taskNameLinkByText : "//div[contains(text(), '%s')]",
    hamburgerBtnCss : 'ibm-hamburger button',
    hamburgerMainOptionCss: 'button:has-text("%s")',
    hamburgerSubOptionCss: 'a[role="menuitem"]:has-text("%s")',

};

exports.homePage = class homePage{
    
    constructor(Page) {        
        page = Page; 
        commonUiMethods = new commonMethods(page);     
    };
    
    /**
     * Sample Page object methods utilising locators and commonUiMethods
     * 
     */

    async getPageDetails(){
        const title = await commonUiMethods.getText(locatorsConfig.pageTitleTextCss, "Main Title")
        const subtitle = await commonUiMethods.getText(locatorsConfig.pageSubtitleTextCss, "Page Subtitle")
        const pageSections = await commonUiMethods.getTextArray(locatorsConfig.pageSectionsTextCss, "Page Sub-Sections")
        return [title, subtitle, pageSections]
    }

    /**
     * 
     * @param {*} taskName Task name to be clicked from home page
     */
    async selectMcmpApplication(applicationName){
        await commonUiMethods.click(locatorsConfig.taskNameLinkByText.replace("%s", applicationName), "Task")
    }

    async navigateToMcmpApplication(mainMenu, application) {      
        await commonUiMethods.click(locatorsConfig.hamburgerBtnCss, "Hamburger Button");
        await commonUiMethods.click(locatorsConfig.hamburgerMainOptionCss.replace("%s", mainMenu), "MCMP Option : " + mainMenu);        
        await commonUiMethods.click(locatorsConfig.hamburgerSubOptionCss.replace("%s", application), "MCMP Application : " + application);
    };    
}