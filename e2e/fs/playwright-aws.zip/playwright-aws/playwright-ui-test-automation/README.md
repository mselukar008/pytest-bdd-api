# UI Test Automation using Playwright and Node.js
### Features
- Supports all modern browsers and OS platforms.
- Lightweight and superfast test execution saving manual testing efforts.
- Generates test outputs like failed test case screenshot, har file, trace file, junit.xml and html report which user can use to identify application issues quickly.
- Customised wrapper functions on top of playwright api's that reduce the complexity of page object functions and test case steps.
- Combination of hard and soft assertions to meet validation requirements.
- Separate log files for each thread, consolidated junit.xml and html report in case of parallel run
- The default behaviour of playwright for spinning the browser in each test case is overriden by custom logic. We have single sign in for all the test suites and test case saving the execution time for login.
- Use of fixtures to increase code reusability and easy maintainance
- Easy integration with CI tools (AWS is integrated)
- Effective use of Page Object Model for writing test cases.
- Using Playwright test runner which itself has lot of inbuilt features for simplifying test automation
- Mechanism to launch authenticated browser for signing in with valid users.
- Integration with Teams/Slack for sharing test summary of regression runs.
- API utils to accomodate the test cases that travels though UI and API validations.
- Set the failure limit for test run beyond which tests can be skipped.

**Table of Contents**
-  [Pre-requisites](#pre-requisites)
-  [Environment Set Up](#environment-set-up)
-  [Playwright Config.js](#playwright-config)
-  [Framework utilities](#framework-utilities)
-  [Test Cases and Page Object Model](#test-cases-and-page-object-model)
-  [Test Execution](#test-execution)
-  [Reports And Artifacts](#reports-and-artifacts)
-  [Sequential and Parallel Test Run](#sequential-and-parallel-test-run)
-  [Debugging](#debugging)
-  [Continuos Integration with AWS CI](#continuos-integration-with-aws-ci)

### Pre-requisites
- IDE - VS Code
- NodeJs - 16 or higher version
- Refer package.json for dependencies and run below command on terminal from root folder:  `npm install`
- For any issue with browser, run  `npx playwright install`
- In VS Code install plugin - `Playwright Test for VSCode`
    
### Environment Set Up
- Test execution parameters are mapped as Environment variables and stored in .env.development file in project root folder.
- For locally running the tests, update the parameters in this file.
- `ENVIRONMENT_URL` : Application url
- `UI_AUTOMATION_PWD` and `GOOGLE_AUTH_SECRET` are encrypted strings. Encrypt the strings using `npx run-func .\helpers\encryptdecrypt.js encrypt "PASSWORD"`
- `TEST_SUITE_LIST` : Add comma separated value of suit list here. The name of suite can be mapped with path of spec file in .\helpers\utils file under generateRuntimeSpecString function. Please refer the function to understand mapping.
- `HEADLESS` : If you want to see the progress of running test case on UI, set the value as false, otherwise make it true.
- `COLLECT_HAR`, `COLLECT_VIDEO`, `COLLECT_TRACE` : These are used for tracking the evidences of failed test cases with options as `on`, `off`, `retain-on-failure`.Default is `retain-on-failure` which means collect these details only for failed test cases.
- `POST_TO_TEAMS`, `POST_TO_DI` are used to post the summary of test execution on teams/slack channels. Default is set to no
- `BROWSER_PF` specifies the browser platform's like chromium,firefox and webkit. Use chromium for chrome and msedge browser
- `BROWSER` : Name of browser(chrome,msedge,firefox etc)
- `WORKERS` : Controls sequential and parallel run. Value as 1 confirms sequential  and greater than 1 is for parallel run
- `RUN_IN_PARALLEL` : Run test suites in parallel, set to true else for sequential set to false

 
### Playwright Config
- This file is the starting point for framework. It contains playwright configurations like browser type, headless or headed execution, test file to run ,timeout, baseUrl of environment etc. Refer official documentation for more details
- Most of the values in config file are replaced by environment variables.
- `testMatch` : The value is array of absolute path of spec files as defined in `TEST_SUITE_LIST` environment variable. 
- `reporter` : Supports html,junit,json,line and custom reporting is used to customise the test hooks like beforeTest, afterTest, beforeRun, afterRun
- `timeout`: Maximum time one test case can run for
- `maxFailures` : Limit the number of failures on build
- `fullyParallel` : Controls parallel and sequential test run
- `retries` : Retry test run for failed test case
- `workers` : Controls parallel and sequential test run in combination with `fullyParallel`
- `use` : browser specific options


### Framework Utilities
- `apiUtil` : All api methods (get,post,delete) along with application specific api functions like generating google authentication code
- `commonMethods` : Wrapper functions(click,select,wait etc) on top of playwright with some customization. These functions are used in page objects for performing native ui actions.
- `customReporter` : Custom logic for test hooks(beforeTest,afterTest) can be added here
- `encryptdecrypt` : Securing secret strings using encryption/decryption mechanism
    - Encryption : `npx run-func .\helpers\encryptdecrypt.js encrypt "PASSWORD"`
    - Decryption : `npx run-func .\helpers\encryptdecrypt.js decrypt "ENCRYPTED PASSWORD"`
- `fixture` : The most important file that drives the entire framwork
    - Fixtures are defined with worker and test scope
    - `loggedIn` is a worker fixture that runs once before starting any new test run. For parallel run with 2 workers, this function will run for each worker. As we are working with single sign in approach, one time login will be done and page fixture is returned.
    - `page` : Test scoped fixture, playwright provides standard fixture like page, it is overriden by page fixture returned from `loggedIn` fixture so that user can make use of logged in session. Also, the `beforeTest` and `afterTest` code is written in here that runs before and after each test case.
    - `homePageObj` : Test scoped fixture, fixture for home page object, here we initialize page object and use in test cases wherever required.Use of page fixture is mandatory for all page object fixtures.
- `globalLogin` : Login code for different scenarios like 
    - Login with authenticated user
    - Login with google authentication
    - Normal login with simple username and password
- `integrationUtils` : Utils functions for sending test summary reports to teams/slack.
- `logGenerator` : Logging configuration using log4js module.
- `util` : Common util functions that can be used accross the framework.

### Test Cases and Page Object Model
- Test cases are written using page object methods.
- For each page, page object is created that contains methods for elements on page.
- Locator for element is defined using xpath,css or playwrite methods and native method like click,select etc is called from `commonMethods` file.
- `test` fixture is imported from `.\helpers\fixtures` for writing test cases. This will facilitate the page objects fixtures defined in fixture file. Refer sample test cases to understand.
- Each step in test case is an operation on respective page object which is written in terms of function.
- All tests are stored under `.e2e\tests\` folder. This is mentioned in config file for `testDir` option.

### Test Execution
- Update `TEST_SUITE_LIST` environment variable with list of suites, see if you want to update other environment variables.
- `package.json` : Script object is updated with playwright run command and pointing to default playwright.config.js file.Hit `npm test` command to run all tests
- `npx playwright test` runs all tests from test suite list
- `npx playwright test test.spec.js test2.spec.js` for running multiple tests.
- Using `Playwright Test for VSCode` : If plugin is installed in VS code, you can see Testing option where you see all listed test suites. You can run all test suites at once, one by one or single test case from suite using the plugin.

### Debugging
- Use Playwright Test for VSCode plugin for debugging test cases. Apply breakpoints in functions to check failed steps and other details.

### Reports And Artifacts
- The output of test run is captured under `.\test-results\`  which is mentioned in config file for `outputDir` 
- The output folder contais `junit.xml, har file, trace file, execution logs, videos` etc.
- `playwright-report` contains html report that dispalys all details from test suite

### Sequential and Parallel Test Run
- Default mode of run is sequential with 1 worker.
- For parallel run, update `WORKERS` and `RUN_IN_PARALLEL` variables.
- Hit `npm test` command
- After parallel run, execution logs will be in separate files and html,xml files will be in consolidated form. You can view these files from `outputDir` folder.
