const { test, expect } = require('@playwright/test');
const { catalogPage } = require('../page/catalog.pageObject')
const login = require('../../helpers/globalLogin')
const genericTestData  = require('../../testData/genericData.json');
import config from '../../credentials.json';


test.describe("Kyndryl Bridge-Catalog", async() => {

    let page;
    let catalog;

    test.beforeAll(async ({ browser }) => {        
        page = await loginStore(browser, "/platform/catalog", config.userName, config.password);
        catalog = new catalogPage(page);
    });

    test.afterAll(async () => {
        await page.close();
    });

    test.beforeEach(async({}, testInfo) => {
        console.log(`================================Started Test Execution for :  ${testInfo.title}`);       
        await page.goto("/platform/catalog")    
    })

    test.afterEach(async({}, testInfo) => {
        console.log(`++++++++++++++++++++++++++++++++Completed Test Case Execution | Status  :  ${testInfo.status.toUpperCase()}++++++++++++++++++++`);
        await page.goto(config.environment)  
    })

    test('Catalog - Validate Service Details and count on Catalog page', async () => {
        const [title, subtitle] = await catalog.getPageDetails()
        expect(title).toEqual(genericTestData.catalogPageTitle)
        expect(subtitle[0]).toEqual(genericTestData.catalogPageSubTitle1)
        expect(subtitle[1]).toEqual(genericTestData.catalogPageSubTitle2)
        await catalog.verifyServiceCount()
    })

    test('Catalog - Search Service and Validate its visible', async () => {
        await catalog.searchService(genericTestData.searchService)
        await catalog.verifyServiceCount()
        const services = await catalog.getDisplayedServices()
        expect(services[0]).toEqual(genericTestData.searchService)
    })

    test('Catalog - Apply Category filter and verify applied filter', async () => {
        await catalog.applyCategogy(genericTestData.filter)
        await catalog.verifyServiceCount()
        const filters = await catalog.getAppliedFilterName()
        expect(filters[1]).toEqual(genericTestData.filter)        
    })

    test('Catalog - Apply Delivery Method filter and verify applied filter', async () => {
        await catalog.applyDeliveryMethod(genericTestData.deliveryMethod)
        await catalog.verifyServiceCount()
        const filters = await catalog.getAppliedFilterName()
        expect(filters[1]).toEqual(genericTestData.deliveryMethod)
        expect(filters[2]).toEqual(genericTestData.clearAllText)        
    })
})