var logGenarator = require('../helpers/logGenerator'),
logger = logGenarator.getApplicationLogger();

global.loginStore = async function(browser, url, userName, pwd) {    
     const context = await browser.newContext({
        httpCredentials: {
            username: userName,
            password: pwd
        }
    })    
    const page = await context.newPage()   
    await page.goto(url);     
    logger.info("Navigated to " + url);   
    return page;  
};







